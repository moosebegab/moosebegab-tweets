Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Allen Grady",
      "screen_name" : "JamesAllenGrady",
      "indices" : [ 3, 19 ],
      "id_str" : "930160098",
      "id" : 930160098
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JamesAllenGrady\/status\/747479632627261440\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/LIdbBCYb6l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-UpMQXIAAlfNT.jpg",
      "id_str" : "747479498552188928",
      "id" : 747479498552188928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-UpMQXIAAlfNT.jpg",
      "sizes" : [ {
        "h" : 689,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/LIdbBCYb6l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748300536835936256",
  "text" : "RT @JamesAllenGrady: Just a thought I shared on Facebook re:Pride (LGBT, or other) this a.m. https:\/\/t.co\/LIdbBCYb6l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JamesAllenGrady\/status\/747479632627261440\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/LIdbBCYb6l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-UpMQXIAAlfNT.jpg",
        "id_str" : "747479498552188928",
        "id" : 747479498552188928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-UpMQXIAAlfNT.jpg",
        "sizes" : [ {
          "h" : 689,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/LIdbBCYb6l"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747479632627261440",
    "text" : "Just a thought I shared on Facebook re:Pride (LGBT, or other) this a.m. https:\/\/t.co\/LIdbBCYb6l",
    "id" : 747479632627261440,
    "created_at" : "2016-06-27 17:20:06 +0000",
    "user" : {
      "name" : "James Allen Grady",
      "screen_name" : "JamesAllenGrady",
      "protected" : false,
      "id_str" : "930160098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788787115391844352\/yJWRTsda_normal.jpg",
      "id" : 930160098,
      "verified" : false
    }
  },
  "id" : 748300536835936256,
  "created_at" : "2016-06-29 23:42:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/748270633902018561\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/q6eOgchasG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJkLJuWQAAEuWk.jpg",
      "id_str" : "748270630848577536",
      "id" : 748270630848577536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJkLJuWQAAEuWk.jpg",
      "sizes" : [ {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/q6eOgchasG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/RRlP6dLTFj",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2015\/09\/could-you-be-so-holy-that-you-wouldnt-be-sad-when-your-children-go-to-hell?_ts=1467236590",
      "display_url" : "patheos.com\/blogs\/unfundam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748270633902018561",
  "text" : "Could you be so holy that you wouldn\u2019t be sad when your children go to hell? https:\/\/t.co\/RRlP6dLTFj https:\/\/t.co\/q6eOgchasG",
  "id" : 748270633902018561,
  "created_at" : "2016-06-29 21:43:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "indices" : [ 81, 93 ],
      "id_str" : "2233154425",
      "id" : 2233154425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 38, 42 ]
    }, {
      "text" : "DrunkenFireworks",
      "indices" : [ 60, 77 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/NSaeye8EVL",
      "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
      "display_url" : "bit.ly\/1X8y8YB"
    } ]
  },
  "geo" : { },
  "id_str" : "748260266970873856",
  "text" : "RT @SimonAudio: Follow us &amp; RT to #win the last copy of #DrunkenFireworks by @StephenKing! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen King",
        "screen_name" : "StephenKing",
        "indices" : [ 65, 77 ],
        "id_str" : "2233154425",
        "id" : 2233154425
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SimonAudio\/status\/748242227533586434\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/gcrc23N3rE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJKVr-WEAUVZEE.jpg",
        "id_str" : "748242224538849285",
        "id" : 748242224538849285,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJKVr-WEAUVZEE.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/gcrc23N3rE"
      } ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 22, 26 ]
      }, {
        "text" : "DrunkenFireworks",
        "indices" : [ 44, 61 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/NSaeye8EVL",
        "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
        "display_url" : "bit.ly\/1X8y8YB"
      } ]
    },
    "geo" : { },
    "id_str" : "748242227533586434",
    "text" : "Follow us &amp; RT to #win the last copy of #DrunkenFireworks by @StephenKing! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL https:\/\/t.co\/gcrc23N3rE",
    "id" : 748242227533586434,
    "created_at" : "2016-06-29 19:50:23 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 748260266970873856,
  "created_at" : "2016-06-29 21:02:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "indices" : [ 3, 17 ],
      "id_str" : "2977412266",
      "id" : 2977412266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/FEhCr9rtaA",
      "expanded_url" : "https:\/\/vine.co\/v\/eADzgzzmJJT",
      "display_url" : "vine.co\/v\/eADzgzzmJJT"
    } ]
  },
  "geo" : { },
  "id_str" : "748259759229444096",
  "text" : "RT @farmingmadire: Noses \uD83D\uDC2E\uD83D\uDC2E https:\/\/t.co\/FEhCr9rtaA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/FEhCr9rtaA",
        "expanded_url" : "https:\/\/vine.co\/v\/eADzgzzmJJT",
        "display_url" : "vine.co\/v\/eADzgzzmJJT"
      } ]
    },
    "geo" : { },
    "id_str" : "748113400400646144",
    "text" : "Noses \uD83D\uDC2E\uD83D\uDC2E https:\/\/t.co\/FEhCr9rtaA",
    "id" : 748113400400646144,
    "created_at" : "2016-06-29 11:18:28 +0000",
    "user" : {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "protected" : false,
      "id_str" : "2977412266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723980308874420224\/USPqubG3_normal.jpg",
      "id" : 2977412266,
      "verified" : false
    }
  },
  "id" : 748259759229444096,
  "created_at" : "2016-06-29 21:00:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748259674240192512",
  "text" : "DD started abilify last friday.. has increased anxiety, nausea.. been feeling like she's sick. called psych whos supposed to call back. ugh",
  "id" : 748259674240192512,
  "created_at" : "2016-06-29 20:59:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mentalhealth",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748207915648036864",
  "text" : "what does it mean when someone keeps a journal of sorts but doesnt remember writing half of it? #mentalhealth",
  "id" : 748207915648036864,
  "created_at" : "2016-06-29 17:34:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/748168208671203330\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/6ZeES2zf12",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIG_52WkAAyrHy.jpg",
      "id_str" : "748168183027240960",
      "id" : 748168183027240960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIG_52WkAAyrHy.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6ZeES2zf12"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748207421089255425",
  "text" : "RT @Nigelstewart76: Whitethroat ready for take off https:\/\/t.co\/6ZeES2zf12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/748168208671203330\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/6ZeES2zf12",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIG_52WkAAyrHy.jpg",
        "id_str" : "748168183027240960",
        "id" : 748168183027240960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIG_52WkAAyrHy.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/6ZeES2zf12"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748168208671203330",
    "text" : "Whitethroat ready for take off https:\/\/t.co\/6ZeES2zf12",
    "id" : 748168208671203330,
    "created_at" : "2016-06-29 14:56:15 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 748207421089255425,
  "created_at" : "2016-06-29 17:32:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "indices" : [ 3, 17 ],
      "id_str" : "555307309",
      "id" : 555307309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748207329435357184",
  "text" : "RT @takecareofUUU: Please be kind as U go through life.We need more kind, caring &amp; gentle people. Be 1 of those who spreads kindness#TA htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/takecareofUUU\/status\/748200154608590848\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/RgtyuRzBN6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIkEhhWkAAOXjI.jpg",
        "id_str" : "748200148233261056",
        "id" : 748200148233261056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIkEhhWkAAOXjI.jpg",
        "sizes" : [ {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/RgtyuRzBN6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748200154608590848",
    "text" : "Please be kind as U go through life.We need more kind, caring &amp; gentle people. Be 1 of those who spreads kindness#TA https:\/\/t.co\/RgtyuRzBN6",
    "id" : 748200154608590848,
    "created_at" : "2016-06-29 17:03:12 +0000",
    "user" : {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "protected" : false,
      "id_str" : "555307309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537254454949445634\/7uw1omdM_normal.jpeg",
      "id" : 555307309,
      "verified" : false
    }
  },
  "id" : 748207329435357184,
  "created_at" : "2016-06-29 17:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/743936044236681216\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/sGETMlLoOk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClL94wBWQAAyVdR.jpg",
      "id_str" : "743936039874609152",
      "id" : 743936039874609152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClL94wBWQAAyVdR.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1671,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 1671,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/sGETMlLoOk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748165420121751552",
  "text" : "RT @StarStuff42: How to create a Human from scratch\nWe are made of Star Stuff https:\/\/t.co\/sGETMlLoOk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/743936044236681216\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/sGETMlLoOk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClL94wBWQAAyVdR.jpg",
        "id_str" : "743936039874609152",
        "id" : 743936039874609152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClL94wBWQAAyVdR.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1671,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 1671,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/sGETMlLoOk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743936044236681216",
    "text" : "How to create a Human from scratch\nWe are made of Star Stuff https:\/\/t.co\/sGETMlLoOk",
    "id" : 743936044236681216,
    "created_at" : "2016-06-17 22:39:09 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 748165420121751552,
  "created_at" : "2016-06-29 14:45:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/SqErgdQOfd",
      "expanded_url" : "https:\/\/twitter.com\/WorldAndScience\/status\/746339636801200129",
      "display_url" : "twitter.com\/WorldAndScienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748165326412587009",
  "text" : "wonder how fast this would happen.. like we wouldnt even know it happened? https:\/\/t.co\/SqErgdQOfd",
  "id" : 748165326412587009,
  "created_at" : "2016-06-29 14:44:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748164844331859968",
  "text" : "RT @StarStuff42: With each passing day the genius of Douglas Adams shines brighter and his quip apparently more likely to be true https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/747537345902174208\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ZXQl3XwggX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_HMVpWQAAmc2r.jpg",
        "id_str" : "747535077949718528",
        "id" : 747535077949718528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_HMVpWQAAmc2r.jpg",
        "sizes" : [ {
          "h" : 268,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/ZXQl3XwggX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747537345902174208",
    "text" : "With each passing day the genius of Douglas Adams shines brighter and his quip apparently more likely to be true https:\/\/t.co\/ZXQl3XwggX",
    "id" : 747537345902174208,
    "created_at" : "2016-06-27 21:09:26 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 748164844331859968,
  "created_at" : "2016-06-29 14:42:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LindaMc",
      "screen_name" : "Lindamc97",
      "indices" : [ 3, 13 ],
      "id_str" : "1404788376",
      "id" : 1404788376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748162818550153216",
  "text" : "RT @Lindamc97: Had to zoom in not to startle him. A crane just walking along, amazing to watch. He's going to the beach today.\uD83C\uDF0A\uD83D\uDC59\uD83D\uDE4B\uD83C\uDFFC https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lindamc97\/status\/748111340871417856\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/9mEQWTUYvh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHTSNpUkAAgqZU.jpg",
        "id_str" : "748111322974294016",
        "id" : 748111322974294016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHTSNpUkAAgqZU.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9mEQWTUYvh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Lindamc97\/status\/748111340871417856\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/9mEQWTUYvh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHTSNoUsAErZb_.jpg",
        "id_str" : "748111322970107905",
        "id" : 748111322970107905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHTSNoUsAErZb_.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9mEQWTUYvh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Lindamc97\/status\/748111340871417856\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/9mEQWTUYvh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHTSNqVAAANw2u.jpg",
        "id_str" : "748111322978516992",
        "id" : 748111322978516992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHTSNqVAAANw2u.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9mEQWTUYvh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748111340871417856",
    "text" : "Had to zoom in not to startle him. A crane just walking along, amazing to watch. He's going to the beach today.\uD83C\uDF0A\uD83D\uDC59\uD83D\uDE4B\uD83C\uDFFC https:\/\/t.co\/9mEQWTUYvh",
    "id" : 748111340871417856,
    "created_at" : "2016-06-29 11:10:17 +0000",
    "user" : {
      "name" : "LindaMc",
      "screen_name" : "Lindamc97",
      "protected" : false,
      "id_str" : "1404788376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793155255877902336\/L28SYLbs_normal.jpg",
      "id" : 1404788376,
      "verified" : false
    }
  },
  "id" : 748162818550153216,
  "created_at" : "2016-06-29 14:34:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "indices" : [ 3, 14 ],
      "id_str" : "2441608651",
      "id" : 2441608651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wB40HChpdo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgE9ZUsAE6aDV.jpg",
      "id_str" : "747773545204199425",
      "id" : 747773545204199425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgE9ZUsAE6aDV.jpg",
      "sizes" : [ {
        "h" : 1393,
        "resize" : "fit",
        "w" : 1969
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1393,
        "resize" : "fit",
        "w" : 1969
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 849,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wB40HChpdo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wB40HChpdo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgn5UVEAAH4jE.jpg",
      "id_str" : "747774145404932096",
      "id" : 747774145404932096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgn5UVEAAH4jE.jpg",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 1345
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 1345
      }, {
        "h" : 936,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wB40HChpdo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wB40HChpdo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgvKmUkAE1RC4.jpg",
      "id_str" : "747774270302883841",
      "id" : 747774270302883841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgvKmUkAE1RC4.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1169,
        "resize" : "fit",
        "w" : 1713
      }, {
        "h" : 1169,
        "resize" : "fit",
        "w" : 1713
      } ],
      "display_url" : "pic.twitter.com\/wB40HChpdo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wB40HChpdo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgyTjVYAAhzv-.jpg",
      "id_str" : "747774324245880832",
      "id" : 747774324245880832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgyTjVYAAhzv-.jpg",
      "sizes" : [ {
        "h" : 441,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 1617
      }, {
        "h" : 1049,
        "resize" : "fit",
        "w" : 1617
      } ],
      "display_url" : "pic.twitter.com\/wB40HChpdo"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 91, 97 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 98, 107 ]
    }, {
      "text" : "tokyo",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748162739823050752",
  "text" : "RT @mido3bitte: too far and not good ones but my 1st Striated heron &amp; babies in a nest #birds #wildlife #tokyo https:\/\/t.co\/wB40HChpdo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/wB40HChpdo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgE9ZUsAE6aDV.jpg",
        "id_str" : "747773545204199425",
        "id" : 747773545204199425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgE9ZUsAE6aDV.jpg",
        "sizes" : [ {
          "h" : 1393,
          "resize" : "fit",
          "w" : 1969
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1393,
          "resize" : "fit",
          "w" : 1969
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 849,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/wB40HChpdo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/wB40HChpdo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgn5UVEAAH4jE.jpg",
        "id_str" : "747774145404932096",
        "id" : 747774145404932096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgn5UVEAAH4jE.jpg",
        "sizes" : [ {
          "h" : 530,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1049,
          "resize" : "fit",
          "w" : 1345
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1049,
          "resize" : "fit",
          "w" : 1345
        }, {
          "h" : 936,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/wB40HChpdo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/wB40HChpdo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgvKmUkAE1RC4.jpg",
        "id_str" : "747774270302883841",
        "id" : 747774270302883841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgvKmUkAE1RC4.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1169,
          "resize" : "fit",
          "w" : 1713
        }, {
          "h" : 1169,
          "resize" : "fit",
          "w" : 1713
        } ],
        "display_url" : "pic.twitter.com\/wB40HChpdo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/747774932663164928\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/wB40HChpdo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCgyTjVYAAhzv-.jpg",
        "id_str" : "747774324245880832",
        "id" : 747774324245880832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCgyTjVYAAhzv-.jpg",
        "sizes" : [ {
          "h" : 441,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1049,
          "resize" : "fit",
          "w" : 1617
        }, {
          "h" : 1049,
          "resize" : "fit",
          "w" : 1617
        } ],
        "display_url" : "pic.twitter.com\/wB40HChpdo"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 75, 81 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "tokyo",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747774932663164928",
    "text" : "too far and not good ones but my 1st Striated heron &amp; babies in a nest #birds #wildlife #tokyo https:\/\/t.co\/wB40HChpdo",
    "id" : 747774932663164928,
    "created_at" : "2016-06-28 12:53:31 +0000",
    "user" : {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "protected" : false,
      "id_str" : "2441608651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746727881498206208\/tfRux6Hm_normal.jpg",
      "id" : 2441608651,
      "verified" : false
    }
  },
  "id" : 748162739823050752,
  "created_at" : "2016-06-29 14:34:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "indices" : [ 3, 15 ],
      "id_str" : "17592150",
      "id" : 17592150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Z64qUkopnV",
      "expanded_url" : "http:\/\/wpo.st\/5OWj1",
      "display_url" : "wpo.st\/5OWj1"
    } ]
  },
  "geo" : { },
  "id_str" : "748162509685817344",
  "text" : "RT @thomaspluck: The oldest white oak tree in the country is in New Jersey, and it's dying \u2014 no one knows why https:\/\/t.co\/Z64qUkopnV https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thomaspluck\/status\/748162200230043648\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9GKF0uFr6s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIBhlwWAAE2Rrk.jpg",
        "id_str" : "748162164679114753",
        "id" : 748162164679114753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIBhlwWAAE2Rrk.jpg",
        "sizes" : [ {
          "h" : 798,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 987,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 987,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/9GKF0uFr6s"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/Z64qUkopnV",
        "expanded_url" : "http:\/\/wpo.st\/5OWj1",
        "display_url" : "wpo.st\/5OWj1"
      } ]
    },
    "geo" : { },
    "id_str" : "748162200230043648",
    "text" : "The oldest white oak tree in the country is in New Jersey, and it's dying \u2014 no one knows why https:\/\/t.co\/Z64qUkopnV https:\/\/t.co\/9GKF0uFr6s",
    "id" : 748162200230043648,
    "created_at" : "2016-06-29 14:32:23 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 748162509685817344,
  "created_at" : "2016-06-29 14:33:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carolynstearns",
      "screen_name" : "carolynstearns",
      "indices" : [ 3, 18 ],
      "id_str" : "16176506",
      "id" : 16176506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/carolynstearns\/status\/748119868499595264\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/rMLfUu8qEy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHbCqUWIAA6MJb.jpg",
      "id_str" : "748119851886059520",
      "id" : 748119851886059520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHbCqUWIAA6MJb.jpg",
      "sizes" : [ {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1060
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1060
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1060
      } ],
      "display_url" : "pic.twitter.com\/rMLfUu8qEy"
    } ],
    "hashtags" : [ {
      "text" : "stolenvehicle",
      "indices" : [ 39, 53 ]
    }, {
      "text" : "farming",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748142635232137216",
  "text" : "RT @carolynstearns: still missing day2 #stolenvehicle our iconic milk truck. Isn't #farming hard enough? https:\/\/t.co\/rMLfUu8qEy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/carolynstearns\/status\/748119868499595264\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/rMLfUu8qEy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmHbCqUWIAA6MJb.jpg",
        "id_str" : "748119851886059520",
        "id" : 748119851886059520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmHbCqUWIAA6MJb.jpg",
        "sizes" : [ {
          "h" : 1060,
          "resize" : "fit",
          "w" : 1060
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1060,
          "resize" : "fit",
          "w" : 1060
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1060,
          "resize" : "fit",
          "w" : 1060
        } ],
        "display_url" : "pic.twitter.com\/rMLfUu8qEy"
      } ],
      "hashtags" : [ {
        "text" : "stolenvehicle",
        "indices" : [ 19, 33 ]
      }, {
        "text" : "farming",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 41.756191, -72.228608 ]
    },
    "id_str" : "748119868499595264",
    "text" : "still missing day2 #stolenvehicle our iconic milk truck. Isn't #farming hard enough? https:\/\/t.co\/rMLfUu8qEy",
    "id" : 748119868499595264,
    "created_at" : "2016-06-29 11:44:10 +0000",
    "user" : {
      "name" : "carolynstearns",
      "screen_name" : "carolynstearns",
      "protected" : false,
      "id_str" : "16176506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632170726372413440\/5Ic4iMg8_normal.jpg",
      "id" : 16176506,
      "verified" : false
    }
  },
  "id" : 748142635232137216,
  "created_at" : "2016-06-29 13:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Bessey",
      "screen_name" : "sarahbessey",
      "indices" : [ 3, 15 ],
      "id_str" : "9535262",
      "id" : 9535262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747936171209142272",
  "text" : "RT @sarahbessey: We are already loved. \nAbide in it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747801504707338240",
    "text" : "We are already loved. \nAbide in it.",
    "id" : 747801504707338240,
    "created_at" : "2016-06-28 14:39:06 +0000",
    "user" : {
      "name" : "Sarah Bessey",
      "screen_name" : "sarahbessey",
      "protected" : false,
      "id_str" : "9535262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697882405642764288\/Nc5Cu35i_normal.jpg",
      "id" : 9535262,
      "verified" : false
    }
  },
  "id" : 747936171209142272,
  "created_at" : "2016-06-28 23:34:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 97, 107 ]
    }, {
      "text" : "nwf",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747906634098311168",
  "text" : "RT @CatskillCritter: White-tailed deer browsing in high grass of meadow, lazy, sweet days of the #Catskills summer . . . #nwf https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/747814560187486209\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/DI8z0Xx4Bx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDE_-sWkAEfSD3.jpg",
        "id_str" : "747814141583331329",
        "id" : 747814141583331329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDE_-sWkAEfSD3.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 3072,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/DI8z0Xx4Bx"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 76, 86 ]
      }, {
        "text" : "nwf",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747814560187486209",
    "text" : "White-tailed deer browsing in high grass of meadow, lazy, sweet days of the #Catskills summer . . . #nwf https:\/\/t.co\/DI8z0Xx4Bx",
    "id" : 747814560187486209,
    "created_at" : "2016-06-28 15:30:59 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 747906634098311168,
  "created_at" : "2016-06-28 21:36:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Wysaski",
      "screen_name" : "pleatedjeans",
      "indices" : [ 3, 16 ],
      "id_str" : "135314463",
      "id" : 135314463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747841774685683712",
  "text" : "RT @pleatedjeans: Forget nudity. When you give a speech picture everyone as a dog bc dogs are not judgmental and will like you no matter wh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747468157925761024",
    "text" : "Forget nudity. When you give a speech picture everyone as a dog bc dogs are not judgmental and will like you no matter what.",
    "id" : 747468157925761024,
    "created_at" : "2016-06-27 16:34:30 +0000",
    "user" : {
      "name" : "Jeff Wysaski",
      "screen_name" : "pleatedjeans",
      "protected" : false,
      "id_str" : "135314463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584013178960384000\/s2z39CTQ_normal.jpg",
      "id" : 135314463,
      "verified" : false
    }
  },
  "id" : 747841774685683712,
  "created_at" : "2016-06-28 17:19:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell'sPal\uD83D\uDCCE",
      "screen_name" : "RussellsPal",
      "indices" : [ 3, 15 ],
      "id_str" : "4568288054",
      "id" : 4568288054
    }, {
      "name" : "TongueOutCoosday",
      "screen_name" : "tongueoutcoos",
      "indices" : [ 17, 31 ],
      "id_str" : "4783458341",
      "id" : 4783458341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RussellsPal\/status\/747787289187713025\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/p4Teg5dSQs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCskzBXIAAZZ90.jpg",
      "id_str" : "747787286314688512",
      "id" : 747787286314688512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCskzBXIAAZZ90.jpg",
      "sizes" : [ {
        "h" : 566,
        "resize" : "fit",
        "w" : 363
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 363
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 363
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 363
      } ],
      "display_url" : "pic.twitter.com\/p4Teg5dSQs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747841631798312961",
  "text" : "RT @RussellsPal: @tongueoutcoos https:\/\/t.co\/p4Teg5dSQs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TongueOutCoosday",
        "screen_name" : "tongueoutcoos",
        "indices" : [ 0, 14 ],
        "id_str" : "4783458341",
        "id" : 4783458341
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RussellsPal\/status\/747787289187713025\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/p4Teg5dSQs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmCskzBXIAAZZ90.jpg",
        "id_str" : "747787286314688512",
        "id" : 747787286314688512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmCskzBXIAAZZ90.jpg",
        "sizes" : [ {
          "h" : 566,
          "resize" : "fit",
          "w" : 363
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 363
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 363
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 363
        } ],
        "display_url" : "pic.twitter.com\/p4Teg5dSQs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747787289187713025",
    "in_reply_to_user_id" : 4783458341,
    "text" : "@tongueoutcoos https:\/\/t.co\/p4Teg5dSQs",
    "id" : 747787289187713025,
    "created_at" : "2016-06-28 13:42:37 +0000",
    "in_reply_to_screen_name" : "tongueoutcoos",
    "in_reply_to_user_id_str" : "4783458341",
    "user" : {
      "name" : "Russell'sPal\uD83D\uDCCE",
      "screen_name" : "RussellsPal",
      "protected" : false,
      "id_str" : "4568288054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799396708245524480\/JUukfJT9_normal.jpg",
      "id" : 4568288054,
      "verified" : false
    }
  },
  "id" : 747841631798312961,
  "created_at" : "2016-06-28 17:18:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747841369901793280",
  "text" : "RT @onealexharms: Possible topics for the next podcast: \n\u00B0 choice &amp; obligation \n\u00B0 unschooling \n\u00B0 challenges around empathy \n\u00B0 being yoursel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747822256709996544",
    "text" : "Possible topics for the next podcast: \n\u00B0 choice &amp; obligation \n\u00B0 unschooling \n\u00B0 challenges around empathy \n\u00B0 being yourself \n\nWho\u2019s in?",
    "id" : 747822256709996544,
    "created_at" : "2016-06-28 16:01:34 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 747841369901793280,
  "created_at" : "2016-06-28 17:17:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747841295444480000",
  "text" : "RT @AnnotatedBible: Why does the GOP have an extreme obsession with helping fetuses in the womb but NOT helping children who are already bo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747832543097954306",
    "text" : "Why does the GOP have an extreme obsession with helping fetuses in the womb but NOT helping children who are already born?",
    "id" : 747832543097954306,
    "created_at" : "2016-06-28 16:42:26 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 747841295444480000,
  "created_at" : "2016-06-28 17:17:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/qLNyGv9FUe",
      "expanded_url" : "https:\/\/shar.es\/1lHRHC",
      "display_url" : "shar.es\/1lHRHC"
    } ]
  },
  "geo" : { },
  "id_str" : "747820472352518144",
  "text" : "Texas Town Fires Its Library Cat https:\/\/t.co\/qLNyGv9FUe",
  "id" : 747820472352518144,
  "created_at" : "2016-06-28 15:54:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne A.",
      "screen_name" : "LynneElmira",
      "indices" : [ 3, 15 ],
      "id_str" : "23255171",
      "id" : 23255171
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LynneElmira\/status\/747579701535768576\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/cx4BYzhI46",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_vqHLVAAAvWpA.jpg",
      "id_str" : "747579569926897664",
      "id" : 747579569926897664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_vqHLVAAAvWpA.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cx4BYzhI46"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747584984769191941",
  "text" : "RT @LynneElmira: Sunset over New York State's SENECA LAKE.... https:\/\/t.co\/cx4BYzhI46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LynneElmira\/status\/747579701535768576\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/cx4BYzhI46",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_vqHLVAAAvWpA.jpg",
        "id_str" : "747579569926897664",
        "id" : 747579569926897664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_vqHLVAAAvWpA.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cx4BYzhI46"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747579701535768576",
    "text" : "Sunset over New York State's SENECA LAKE.... https:\/\/t.co\/cx4BYzhI46",
    "id" : 747579701535768576,
    "created_at" : "2016-06-27 23:57:44 +0000",
    "user" : {
      "name" : "Lynne A.",
      "screen_name" : "LynneElmira",
      "protected" : false,
      "id_str" : "23255171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125797710\/YELLOW_ROSE_normal.jpg",
      "id" : 23255171,
      "verified" : false
    }
  },
  "id" : 747584984769191941,
  "created_at" : "2016-06-28 00:18:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "feedly",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/mS7vwyXnm0",
      "expanded_url" : "https:\/\/ilmk.wordpress.com\/2016\/06\/27\/introducing-amazon-inspire-new-free-educational-resource\/",
      "display_url" : "ilmk.wordpress.com\/2016\/06\/27\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747519270762930176",
  "text" : "Introducing Amazon Inspire: new free educational resource https:\/\/t.co\/mS7vwyXnm0 #books #feedly",
  "id" : 747519270762930176,
  "created_at" : "2016-06-27 19:57:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "elizabethforma",
      "indices" : [ 3, 18 ],
      "id_str" : "357606935",
      "id" : 357606935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747518024765235200",
  "text" : "RT @elizabethforma: It\u2019s our choice \u2013 whether to come together as one people and live our values, or to splinter and turn on each other in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loveislove",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742139475799777280",
    "text" : "It\u2019s our choice \u2013 whether to come together as one people and live our values, or to splinter and turn on each other in fear. #loveislove",
    "id" : 742139475799777280,
    "created_at" : "2016-06-12 23:40:13 +0000",
    "user" : {
      "name" : "Elizabeth Warren",
      "screen_name" : "elizabethforma",
      "protected" : false,
      "id_str" : "357606935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793833583576092672\/OZIpLrow_normal.jpg",
      "id" : 357606935,
      "verified" : true
    }
  },
  "id" : 747518024765235200,
  "created_at" : "2016-06-27 19:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OverDrive Libraries",
      "screen_name" : "OverDriveLibs",
      "indices" : [ 88, 102 ],
      "id_str" : "100572292",
      "id" : 100572292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vJAOPWnpv7",
      "expanded_url" : "https:\/\/twitter.com\/KamishVoice\/status\/747477350745522176",
      "display_url" : "twitter.com\/KamishVoice\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747490100905410561",
  "text" : "The Whistlers-Amity Argot (NoSleep Podcast S5E25) then Love May Fail-Matthew Quick from @OverDriveLibs on nexus 7.2 https:\/\/t.co\/vJAOPWnpv7",
  "id" : 747490100905410561,
  "created_at" : "2016-06-27 18:01:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "indices" : [ 3, 19 ],
      "id_str" : "2530698811",
      "id" : 2530698811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/747418807589797888\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/PYWVsZCAya",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl9db6lWMAAMe_y.jpg",
      "id_str" : "747418797330542592",
      "id" : 747418797330542592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl9db6lWMAAMe_y.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/PYWVsZCAya"
    } ],
    "hashtags" : [ {
      "text" : "mondayfunday",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747478664216969220",
  "text" : "RT @JRfromStrickley: Mr Ladybird and his Ladyfriend are having a #mondayfunday \uD83D\uDC1E\uD83D\uDC1E\uD83D\uDCAA\uD83C\uDFFC https:\/\/t.co\/PYWVsZCAya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/747418807589797888\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/PYWVsZCAya",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl9db6lWMAAMe_y.jpg",
        "id_str" : "747418797330542592",
        "id" : 747418797330542592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl9db6lWMAAMe_y.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/PYWVsZCAya"
      } ],
      "hashtags" : [ {
        "text" : "mondayfunday",
        "indices" : [ 44, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747418807589797888",
    "text" : "Mr Ladybird and his Ladyfriend are having a #mondayfunday \uD83D\uDC1E\uD83D\uDC1E\uD83D\uDCAA\uD83C\uDFFC https:\/\/t.co\/PYWVsZCAya",
    "id" : 747418807589797888,
    "created_at" : "2016-06-27 13:18:24 +0000",
    "user" : {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "protected" : false,
      "id_str" : "2530698811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682844561933217792\/DmT71D0G_normal.jpg",
      "id" : 2530698811,
      "verified" : false
    }
  },
  "id" : 747478664216969220,
  "created_at" : "2016-06-27 17:16:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JesusWithoutBaggage",
      "screen_name" : "JesusWOB",
      "indices" : [ 93, 102 ],
      "id_str" : "769608278",
      "id" : 769608278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/UViiOzzcG0",
      "expanded_url" : "https:\/\/jesuswithoutbaggage.wordpress.com\/2016\/06\/27\/how-i-changed-from-disapproving-lgbts-to-being-totally-affirming\/",
      "display_url" : "jesuswithoutbaggage.wordpress.com\/2016\/06\/27\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747457524350205952",
  "text" : "How I Changed from Disapproving LGBTs to Being Totally Affirming https:\/\/t.co\/UViiOzzcG0 via @JesusWOB",
  "id" : 747457524350205952,
  "created_at" : "2016-06-27 15:52:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "indices" : [ 3, 15 ],
      "id_str" : "519836839",
      "id" : 519836839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/747271918571556864\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/2LT9mQvHto",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl7XtaYVYAEFAeT.jpg",
      "id_str" : "747271763365552129",
      "id" : 747271763365552129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl7XtaYVYAEFAeT.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/2LT9mQvHto"
    } ],
    "hashtags" : [ {
      "text" : "whorulesthequadwins",
      "indices" : [ 67, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747426705929736193",
  "text" : "RT @decisiveman: There has been a coup - lambs are at the controls #whorulesthequadwins https:\/\/t.co\/2LT9mQvHto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/747271918571556864\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/2LT9mQvHto",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl7XtaYVYAEFAeT.jpg",
        "id_str" : "747271763365552129",
        "id" : 747271763365552129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl7XtaYVYAEFAeT.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/2LT9mQvHto"
      } ],
      "hashtags" : [ {
        "text" : "whorulesthequadwins",
        "indices" : [ 50, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747271918571556864",
    "text" : "There has been a coup - lambs are at the controls #whorulesthequadwins https:\/\/t.co\/2LT9mQvHto",
    "id" : 747271918571556864,
    "created_at" : "2016-06-27 03:34:43 +0000",
    "user" : {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "protected" : false,
      "id_str" : "519836839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706805650844585984\/Wyw3swZ9_normal.jpg",
      "id" : 519836839,
      "verified" : false
    }
  },
  "id" : 747426705929736193,
  "created_at" : "2016-06-27 13:49:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MuggleNet.com",
      "screen_name" : "MuggleNet",
      "indices" : [ 3, 13 ],
      "id_str" : "14599470",
      "id" : 14599470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747426476891344898",
  "text" : "RT @MuggleNet: BREAKING: Prof McGonagall spotted at 10 Downing Street. Rumour has it that Ministry of Magic is about to take over. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MuggleNet\/status\/747276902591660033\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FLrtlEODBk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl7cYBcUgAECxT0.jpg",
        "id_str" : "747276893452271617",
        "id" : 747276893452271617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl7cYBcUgAECxT0.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/FLrtlEODBk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747276902591660033",
    "text" : "BREAKING: Prof McGonagall spotted at 10 Downing Street. Rumour has it that Ministry of Magic is about to take over. https:\/\/t.co\/FLrtlEODBk",
    "id" : 747276902591660033,
    "created_at" : "2016-06-27 03:54:31 +0000",
    "user" : {
      "name" : "MuggleNet.com",
      "screen_name" : "MuggleNet",
      "protected" : false,
      "id_str" : "14599470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781292451973607424\/GMf5QShN_normal.jpg",
      "id" : 14599470,
      "verified" : false
    }
  },
  "id" : 747426476891344898,
  "created_at" : "2016-06-27 13:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "indices" : [ 3, 18 ],
      "id_str" : "1972360812",
      "id" : 1972360812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747425605373702144",
  "text" : "RT @CityStitchette: Good morning! May luck climb on to your shoulder today. \n(Does anyone else think ladybugs are lucky?) https:\/\/t.co\/mh0Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/747420295624036352\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/mh0ZK5efWD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl9eyRzWAAAGjNZ.jpg",
        "id_str" : "747420281032015872",
        "id" : 747420281032015872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl9eyRzWAAAGjNZ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/mh0ZK5efWD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747420295624036352",
    "text" : "Good morning! May luck climb on to your shoulder today. \n(Does anyone else think ladybugs are lucky?) https:\/\/t.co\/mh0ZK5efWD",
    "id" : 747420295624036352,
    "created_at" : "2016-06-27 13:24:19 +0000",
    "user" : {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "protected" : false,
      "id_str" : "1972360812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765660039294152704\/LtNgIXNF_normal.jpg",
      "id" : 1972360812,
      "verified" : false
    }
  },
  "id" : 747425605373702144,
  "created_at" : "2016-06-27 13:45:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schr\u00F6dinger",
      "screen_name" : "DrSchrodinger15",
      "indices" : [ 3, 19 ],
      "id_str" : "3533397441",
      "id" : 3533397441
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrSchrodinger15\/status\/747089552284749824\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/soavQGryAl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4x5lYWIAAWHaE.jpg",
      "id_str" : "747089453546610688",
      "id" : 747089453546610688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4x5lYWIAAWHaE.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/soavQGryAl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747214069074108416",
  "text" : "RT @DrSchrodinger15: I am an unashamedly nosy neighbour. https:\/\/t.co\/soavQGryAl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrSchrodinger15\/status\/747089552284749824\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/soavQGryAl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4x5lYWIAAWHaE.jpg",
        "id_str" : "747089453546610688",
        "id" : 747089453546610688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4x5lYWIAAWHaE.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/soavQGryAl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747089552284749824",
    "text" : "I am an unashamedly nosy neighbour. https:\/\/t.co\/soavQGryAl",
    "id" : 747089552284749824,
    "created_at" : "2016-06-26 15:30:04 +0000",
    "user" : {
      "name" : "Schr\u00F6dinger",
      "screen_name" : "DrSchrodinger15",
      "protected" : false,
      "id_str" : "3533397441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780821974134222849\/8RUoZj7h_normal.jpg",
      "id" : 3533397441,
      "verified" : false
    }
  },
  "id" : 747214069074108416,
  "created_at" : "2016-06-26 23:44:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746866477354057728",
  "geo" : { },
  "id_str" : "746880409619791873",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep oh no. hope it passes quickly.",
  "id" : 746880409619791873,
  "in_reply_to_status_id" : 746866477354057728,
  "created_at" : "2016-06-26 01:39:00 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/gv9CqFf1Vh",
      "expanded_url" : "http:\/\/nydn.us\/294IVQM",
      "display_url" : "nydn.us\/294IVQM"
    } ]
  },
  "geo" : { },
  "id_str" : "746827478077931520",
  "text" : "Texas mother killed by cops after fatally shooting her daughters https:\/\/t.co\/gv9CqFf1Vh",
  "id" : 746827478077931520,
  "created_at" : "2016-06-25 22:08:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746776249524166656",
  "text" : "RT @marseelee: In Chinese tradition, there is another method of walking meditation that focuses on breathing and visualisation https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/746654877716201477\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/uGbUgMTLdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClympoVWkAAizTf.jpg",
        "id_str" : "746654872368484352",
        "id" : 746654872368484352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClympoVWkAAizTf.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/uGbUgMTLdu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746654877716201477",
    "text" : "In Chinese tradition, there is another method of walking meditation that focuses on breathing and visualisation https:\/\/t.co\/uGbUgMTLdu",
    "id" : 746654877716201477,
    "created_at" : "2016-06-25 10:42:49 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 746776249524166656,
  "created_at" : "2016-06-25 18:45:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pic",
      "screen_name" : "pep_vilamala",
      "indices" : [ 3, 16 ],
      "id_str" : "396698077",
      "id" : 396698077
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pep_vilamala\/status\/731795172191817728\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/xjPP8quukJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cifb07DXIAAi1MQ.jpg",
      "id_str" : "731795166722465792",
      "id" : 731795166722465792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cifb07DXIAAi1MQ.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xjPP8quukJ"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 25, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746736396577181696",
  "text" : "RT @pep_vilamala: Flying #birds https:\/\/t.co\/xjPP8quukJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pep_vilamala\/status\/731795172191817728\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/xjPP8quukJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cifb07DXIAAi1MQ.jpg",
        "id_str" : "731795166722465792",
        "id" : 731795166722465792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cifb07DXIAAi1MQ.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xjPP8quukJ"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 7, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731795172191817728",
    "text" : "Flying #birds https:\/\/t.co\/xjPP8quukJ",
    "id" : 731795172191817728,
    "created_at" : "2016-05-15 10:35:39 +0000",
    "user" : {
      "name" : "Pic",
      "screen_name" : "pep_vilamala",
      "protected" : false,
      "id_str" : "396698077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000748859587\/289a592b2989b6f2dabb76db7fc25947_normal.jpeg",
      "id" : 396698077,
      "verified" : false
    }
  },
  "id" : 746736396577181696,
  "created_at" : "2016-06-25 16:06:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/UUEmZ7SkEA",
      "expanded_url" : "http:\/\/www.goodnewsnetwork.org\/look-trucker-takes-daughters-doll-road-trip\/",
      "display_url" : "goodnewsnetwork.org\/look-trucker-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746446224203595776",
  "text" : "Trucker Posts Hilarious Pics While \u2018Babysitting\u2019 His Daughter\u2019s Doll for the Day https:\/\/t.co\/UUEmZ7SkEA",
  "id" : 746446224203595776,
  "created_at" : "2016-06-24 20:53:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746438679195979776",
  "geo" : { },
  "id_str" : "746440678717165569",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline wowza.. i think he's lost it!",
  "id" : 746440678717165569,
  "in_reply_to_status_id" : 746438679195979776,
  "created_at" : "2016-06-24 20:31:40 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50\uFE0Fbex schwartz",
      "screen_name" : "starbex",
      "indices" : [ 3, 11 ],
      "id_str" : "10047302",
      "id" : 10047302
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/starbex\/status\/746220617041481728\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/0r7KouIHW1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClsbrhFUoAEBSh5.jpg",
      "id_str" : "746220597688967169",
      "id" : 746220597688967169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClsbrhFUoAEBSh5.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0r7KouIHW1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746411496960307200",
  "text" : "RT @starbex: Holy shit, they replaced David Cameron with a cat. https:\/\/t.co\/0r7KouIHW1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/starbex\/status\/746220617041481728\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/0r7KouIHW1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClsbrhFUoAEBSh5.jpg",
        "id_str" : "746220597688967169",
        "id" : 746220597688967169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClsbrhFUoAEBSh5.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/0r7KouIHW1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746220617041481728",
    "text" : "Holy shit, they replaced David Cameron with a cat. https:\/\/t.co\/0r7KouIHW1",
    "id" : 746220617041481728,
    "created_at" : "2016-06-24 05:57:13 +0000",
    "user" : {
      "name" : "\u2B50\uFE0Fbex schwartz",
      "screen_name" : "starbex",
      "protected" : false,
      "id_str" : "10047302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796860368761004032\/XlvPlte2_normal.jpg",
      "id" : 10047302,
      "verified" : true
    }
  },
  "id" : 746411496960307200,
  "created_at" : "2016-06-24 18:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glennon Doyle Melton",
      "screen_name" : "Momastery",
      "indices" : [ 3, 13 ],
      "id_str" : "67647597",
      "id" : 67647597
    }, {
      "name" : "kerri kelly",
      "screen_name" : "kkellyyoga",
      "indices" : [ 35, 46 ],
      "id_str" : "40063287",
      "id" : 40063287
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Momastery\/status\/746353161716248576\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RzDIVG4AMG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CluUPkOWMAAP2ng.jpg",
      "id_str" : "746353158402748416",
      "id" : 746353158402748416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CluUPkOWMAAP2ng.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 745
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 745
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 745
      } ],
      "display_url" : "pic.twitter.com\/RzDIVG4AMG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/U1TyuEA6ma",
      "expanded_url" : "http:\/\/ift.tt\/28SYqe4",
      "display_url" : "ift.tt\/28SYqe4"
    } ]
  },
  "geo" : { },
  "id_str" : "746411110429974528",
  "text" : "RT @Momastery: Truth y'all. Thanks @kkellyyoga https:\/\/t.co\/U1TyuEA6ma https:\/\/t.co\/RzDIVG4AMG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kerri kelly",
        "screen_name" : "kkellyyoga",
        "indices" : [ 20, 31 ],
        "id_str" : "40063287",
        "id" : 40063287
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Momastery\/status\/746353161716248576\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/RzDIVG4AMG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CluUPkOWMAAP2ng.jpg",
        "id_str" : "746353158402748416",
        "id" : 746353158402748416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CluUPkOWMAAP2ng.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 745
        } ],
        "display_url" : "pic.twitter.com\/RzDIVG4AMG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/U1TyuEA6ma",
        "expanded_url" : "http:\/\/ift.tt\/28SYqe4",
        "display_url" : "ift.tt\/28SYqe4"
      } ]
    },
    "geo" : { },
    "id_str" : "746353161716248576",
    "text" : "Truth y'all. Thanks @kkellyyoga https:\/\/t.co\/U1TyuEA6ma https:\/\/t.co\/RzDIVG4AMG",
    "id" : 746353161716248576,
    "created_at" : "2016-06-24 14:43:54 +0000",
    "user" : {
      "name" : "Glennon Doyle Melton",
      "screen_name" : "Momastery",
      "protected" : false,
      "id_str" : "67647597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665203657223204864\/XrxSp5ss_normal.jpg",
      "id" : 67647597,
      "verified" : true
    }
  },
  "id" : 746411110429974528,
  "created_at" : "2016-06-24 18:34:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "indices" : [ 3, 18 ],
      "id_str" : "1972360812",
      "id" : 1972360812
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/746348092782424065\/video\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/HhDVSecV5r",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746347974205317120\/pu\/img\/fQCI0picTTJNRJat.jpg",
      "id_str" : "746347974205317120",
      "id" : 746347974205317120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746347974205317120\/pu\/img\/fQCI0picTTJNRJat.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HhDVSecV5r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746398768069763073",
  "text" : "RT @CityStitchette: Because we need more birdsong this morning . . . https:\/\/t.co\/HhDVSecV5r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/746348092782424065\/video\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/HhDVSecV5r",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746347974205317120\/pu\/img\/fQCI0picTTJNRJat.jpg",
        "id_str" : "746347974205317120",
        "id" : 746347974205317120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746347974205317120\/pu\/img\/fQCI0picTTJNRJat.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HhDVSecV5r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746348092782424065",
    "text" : "Because we need more birdsong this morning . . . https:\/\/t.co\/HhDVSecV5r",
    "id" : 746348092782424065,
    "created_at" : "2016-06-24 14:23:46 +0000",
    "user" : {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "protected" : false,
      "id_str" : "1972360812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765660039294152704\/LtNgIXNF_normal.jpg",
      "id" : 1972360812,
      "verified" : false
    }
  },
  "id" : 746398768069763073,
  "created_at" : "2016-06-24 17:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746336386245103616",
  "text" : "I kept seeing the brexit hashtag but didnt know what it was about. Now I know...",
  "id" : 746336386245103616,
  "created_at" : "2016-06-24 13:37:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VeryBritishProblems",
      "screen_name" : "SoVeryBritish",
      "indices" : [ 3, 17 ],
      "id_str" : "1023072078",
      "id" : 1023072078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746335475821064192",
  "text" : "RT @SoVeryBritish: \"It didn't quite go as planned\" - Translation: I may have caused irreversible damage on a monumental scale",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739456897946931200",
    "text" : "\"It didn't quite go as planned\" - Translation: I may have caused irreversible damage on a monumental scale",
    "id" : 739456897946931200,
    "created_at" : "2016-06-05 14:00:37 +0000",
    "user" : {
      "name" : "VeryBritishProblems",
      "screen_name" : "SoVeryBritish",
      "protected" : false,
      "id_str" : "1023072078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2996456104\/b707959f192bba5c31c07058f91a183b_normal.png",
      "id" : 1023072078,
      "verified" : true
    }
  },
  "id" : 746335475821064192,
  "created_at" : "2016-06-24 13:33:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/N0UqdXIz2V",
      "expanded_url" : "http:\/\/jezebel.com\/interview-with-a-woman-who-recently-had-an-abortion-at-1781972395?utm_medium=sharefromsite&utm_source=Jezebel_twitter",
      "display_url" : "jezebel.com\/interview-with\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746122624204480512",
  "text" : "Interview With a Woman Who Recently Had an Abortion at 32 Weeks https:\/\/t.co\/N0UqdXIz2V",
  "id" : 746122624204480512,
  "created_at" : "2016-06-23 23:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/746035158508249088\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/DfGHqmLpwl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClpzBR0XIAETrLf.jpg",
      "id_str" : "746035154083323905",
      "id" : 746035154083323905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClpzBR0XIAETrLf.jpg",
      "sizes" : [ {
        "h" : 507,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/DfGHqmLpwl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/AuO2v4DS5z",
      "expanded_url" : "http:\/\/lifehacker.com\/281626\/jerry-seinfelds-productivity-secret?_ts=1466703611",
      "display_url" : "lifehacker.com\/281626\/jerry-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746035158508249088",
  "text" : "Jerry Seinfeld's Productivity Secret https:\/\/t.co\/AuO2v4DS5z https:\/\/t.co\/DfGHqmLpwl",
  "id" : 746035158508249088,
  "created_at" : "2016-06-23 17:40:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746013311502790656",
  "text" : "can i do this? &gt; root small #android phone. take phone stuff off. want android, wifi, bluetooth. use as media player.",
  "id" : 746013311502790656,
  "created_at" : "2016-06-23 16:13:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "app",
      "indices" : [ 8, 12 ]
    }, {
      "text" : "audible",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746012365414621184",
  "text" : "want an #app with mp3 controls play, pause, next, back, volume.. maybe in notification or as widget. works with #audible, music, podcasts.",
  "id" : 746012365414621184,
  "created_at" : "2016-06-23 16:09:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745697885413576704",
  "geo" : { },
  "id_str" : "745726012634259458",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous tp?",
  "id" : 745726012634259458,
  "in_reply_to_status_id" : 745697885413576704,
  "created_at" : "2016-06-22 21:11:50 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/kP9RM0GOf6",
      "expanded_url" : "https:\/\/twitter.com\/Woodside_Farm\/status\/745686362339311616",
      "display_url" : "twitter.com\/Woodside_Farm\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745725372667469824",
  "text" : "aww.. https:\/\/t.co\/kP9RM0GOf6",
  "id" : 745725372667469824,
  "created_at" : "2016-06-22 21:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QuantumNothingness",
      "screen_name" : "fuelandseed",
      "indices" : [ 3, 15 ],
      "id_str" : "497652988",
      "id" : 497652988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745703780231020545",
  "text" : "RT @fuelandseed: Sometimes, she regretted having summoned the demon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745703440324583424",
    "text" : "Sometimes, she regretted having summoned the demon.",
    "id" : 745703440324583424,
    "created_at" : "2016-06-22 19:42:09 +0000",
    "user" : {
      "name" : "QuantumNothingness",
      "screen_name" : "fuelandseed",
      "protected" : false,
      "id_str" : "497652988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745739382565416960\/WMxCUN8u_normal.jpg",
      "id" : 497652988,
      "verified" : false
    }
  },
  "id" : 745703780231020545,
  "created_at" : "2016-06-22 19:43:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745702273880301568",
  "geo" : { },
  "id_str" : "745703483047821312",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms thanks! \uD83D\uDE03",
  "id" : 745703483047821312,
  "in_reply_to_status_id" : 745702273880301568,
  "created_at" : "2016-06-22 19:42:19 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 0, 14 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745652770770911233",
  "geo" : { },
  "id_str" : "745678901502971904",
  "in_reply_to_user_id" : 134242072,
  "text" : "@benjamincorey universalism was my starting point which eventually led to God not a person then evolving souls (not static heaven.)",
  "id" : 745678901502971904,
  "in_reply_to_status_id" : 745652770770911233,
  "created_at" : "2016-06-22 18:04:38 +0000",
  "in_reply_to_screen_name" : "BenjaminLCorey",
  "in_reply_to_user_id_str" : "134242072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/745678219580477440\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/ZnQRC79OsW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClkuYtmWEAEwdvk.jpg",
      "id_str" : "745678215398690817",
      "id" : 745678215398690817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClkuYtmWEAEwdvk.jpg",
      "sizes" : [ {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/ZnQRC79OsW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/fJ1r2gxXxH",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/is-christian-universalism-compatible-with-free-will-justice-hell?_ts=1466618510",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745678219580477440",
  "text" : "Is Christian Universalism Compatible With Free Will? Justice? Hell? https:\/\/t.co\/fJ1r2gxXxH https:\/\/t.co\/ZnQRC79OsW",
  "id" : 745678219580477440,
  "created_at" : "2016-06-22 18:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/UZjLQW7En5",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/is-christian-universalism-compatible-with-free-will-justice-hell\/",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745675825085833216",
  "text" : "RT @benjamincorey: Is Christian Universalism Compatible With Free Will? Justice? Hell? Yes, and here's why: https:\/\/t.co\/UZjLQW7En5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/UZjLQW7En5",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/is-christian-universalism-compatible-with-free-will-justice-hell\/",
        "display_url" : "patheos.com\/blogs\/formerly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745652770770911233",
    "text" : "Is Christian Universalism Compatible With Free Will? Justice? Hell? Yes, and here's why: https:\/\/t.co\/UZjLQW7En5",
    "id" : 745652770770911233,
    "created_at" : "2016-06-22 16:20:48 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 745675825085833216,
  "created_at" : "2016-06-22 17:52:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745660845544308736",
  "text" : "RT @TheGoldenMirror: Don't line up with the world. Stay true to yourself and the world will line up with you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745646876263915520",
    "text" : "Don't line up with the world. Stay true to yourself and the world will line up with you.",
    "id" : 745646876263915520,
    "created_at" : "2016-06-22 15:57:23 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 745660845544308736,
  "created_at" : "2016-06-22 16:52:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "appoftheday",
      "indices" : [ 31, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/cmFHgtTFoD",
      "expanded_url" : "http:\/\/get.myappfree.it",
      "display_url" : "get.myappfree.it"
    } ]
  },
  "geo" : { },
  "id_str" : "745653936690954240",
  "text" : "File Manager - File Manager is #appoftheday on myappfree. download it now. https:\/\/t.co\/cmFHgtTFoD",
  "id" : 745653936690954240,
  "created_at" : "2016-06-22 16:25:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745589539994013696",
  "geo" : { },
  "id_str" : "745633894389645312",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms part of my pausing video is to catch slides you feel point was made but I want to read...",
  "id" : 745633894389645312,
  "in_reply_to_status_id" : 745589539994013696,
  "created_at" : "2016-06-22 15:05:48 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745589539994013696",
  "geo" : { },
  "id_str" : "745633300669145088",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms soo much goodness.. i have to keep stopping. only 18 mins through yet started 1 hr ago..lol.",
  "id" : 745633300669145088,
  "in_reply_to_status_id" : 745589539994013696,
  "created_at" : "2016-06-22 15:03:26 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/745462508299780097\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/LNUWbrXaM1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClhqKTmUoAA-nvF.jpg",
      "id_str" : "745462463622062080",
      "id" : 745462463622062080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClhqKTmUoAA-nvF.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/LNUWbrXaM1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745632297387433985",
  "text" : "RT @ErinEFarley: One little bear done. Now to make another with the colors reversed. https:\/\/t.co\/LNUWbrXaM1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/745462508299780097\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/LNUWbrXaM1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClhqKTmUoAA-nvF.jpg",
        "id_str" : "745462463622062080",
        "id" : 745462463622062080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClhqKTmUoAA-nvF.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/LNUWbrXaM1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745462508299780097",
    "text" : "One little bear done. Now to make another with the colors reversed. https:\/\/t.co\/LNUWbrXaM1",
    "id" : 745462508299780097,
    "created_at" : "2016-06-22 03:44:46 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 745632297387433985,
  "created_at" : "2016-06-22 14:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Ns7uguK7GN",
      "expanded_url" : "http:\/\/bookwi.se\/new-kindle-available-pre-order\/",
      "display_url" : "bookwi.se\/new-kindle-ava\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745629926372556801",
  "text" : "RT @adamrshields: New Kindle Available for Pre-Order - slightly smaller, same price and adds Bluetooth audio https:\/\/t.co\/Ns7uguK7GN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Ns7uguK7GN",
        "expanded_url" : "http:\/\/bookwi.se\/new-kindle-available-pre-order\/",
        "display_url" : "bookwi.se\/new-kindle-ava\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745622170546540548",
    "text" : "New Kindle Available for Pre-Order - slightly smaller, same price and adds Bluetooth audio https:\/\/t.co\/Ns7uguK7GN",
    "id" : 745622170546540548,
    "created_at" : "2016-06-22 14:19:13 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 745629926372556801,
  "created_at" : "2016-06-22 14:50:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/745627921092599808\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/Qld8vzGOtw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClkAo_0WgAA4-Qx.jpg",
      "id_str" : "745627917632307200",
      "id" : 745627917632307200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClkAo_0WgAA4-Qx.jpg",
      "sizes" : [ {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Qld8vzGOtw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/mnGXb7pHZZ",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2016\/06\/hell-might-be-empty?_ts=1466606519",
      "display_url" : "patheos.com\/blogs\/unfundam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745627921092599808",
  "text" : "Hell Might Be Empty https:\/\/t.co\/mnGXb7pHZZ https:\/\/t.co\/Qld8vzGOtw",
  "id" : 745627921092599808,
  "created_at" : "2016-06-22 14:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/745627785767563264\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/dLlzFaVaRv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClkAhHLWYAAxuc4.jpg",
      "id_str" : "745627782168862720",
      "id" : 745627782168862720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClkAhHLWYAAxuc4.jpg",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/dLlzFaVaRv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/7uaHH9grhb",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2016\/06\/hell-might-be-empty?_ts=1466606486",
      "display_url" : "patheos.com\/blogs\/unfundam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745627785767563264",
  "text" : "Hell Might Be Empty https:\/\/t.co\/7uaHH9grhb https:\/\/t.co\/dLlzFaVaRv",
  "id" : 745627785767563264,
  "created_at" : "2016-06-22 14:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "feedly",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/aJ8BPqWedr",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2016\/06\/hell-might-be-empty\/",
      "display_url" : "patheos.com\/blogs\/unfundam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745627547908587520",
  "text" : "Hell Might Be Empty https:\/\/t.co\/aJ8BPqWedr #religion #feedly",
  "id" : 745627547908587520,
  "created_at" : "2016-06-22 14:40:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/R6yywXFIWz",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=hJzruVouCf8",
      "display_url" : "youtube.com\/watch?v=hJzruV\u2026"
    }, {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/bjNqyD7MuX",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx28GZ823",
      "display_url" : "tmblr.co\/Zp3-jx28GZ823"
    } ]
  },
  "geo" : { },
  "id_str" : "745617199029751808",
  "text" : "\uD83D\uDCF9 (via https:\/\/t.co\/R6yywXFIWz) \u201CHardcore empathy starts with interrupting the... https:\/\/t.co\/bjNqyD7MuX",
  "id" : 745617199029751808,
  "created_at" : "2016-06-22 13:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/QDlWaNxqDE",
      "expanded_url" : "https:\/\/youtu.be\/hJzruVouCf8",
      "display_url" : "youtu.be\/hJzruVouCf8"
    } ]
  },
  "geo" : { },
  "id_str" : "745616366271631360",
  "text" : "\"Hardcore empathy starts with interrupting the story I'm telling myself\" How to Empathy - Alex Harms https:\/\/t.co\/QDlWaNxqDE",
  "id" : 745616366271631360,
  "created_at" : "2016-06-22 13:56:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745612973385842688",
  "text" : "RT @onealexharms: I keep wondering if a talk starting  with \"let me tell you what an asshole I am\" shouldn't &lt;cough&gt; go on the resume. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/RxF0mJ08L0",
        "expanded_url" : "https:\/\/twitter.com\/moonconf\/status\/744929451306291200",
        "display_url" : "twitter.com\/moonconf\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745589539994013696",
    "text" : "I keep wondering if a talk starting  with \"let me tell you what an asshole I am\" shouldn't &lt;cough&gt; go on the resume. https:\/\/t.co\/RxF0mJ08L0",
    "id" : 745589539994013696,
    "created_at" : "2016-06-22 12:09:33 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 745612973385842688,
  "created_at" : "2016-06-22 13:42:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hearne",
      "screen_name" : "KevinHearne",
      "indices" : [ 3, 15 ],
      "id_str" : "108740062",
      "id" : 108740062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745417725879549952",
  "text" : "RT @KevinHearne: Bob Ross on the importance of including bushes underneath the trees: \"You gotta have a place for the bunny rabbits to live\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745401758990532609",
    "text" : "Bob Ross on the importance of including bushes underneath the trees: \"You gotta have a place for the bunny rabbits to live.\" Preach it, Bob!",
    "id" : 745401758990532609,
    "created_at" : "2016-06-21 23:43:22 +0000",
    "user" : {
      "name" : "Kevin Hearne",
      "screen_name" : "KevinHearne",
      "protected" : false,
      "id_str" : "108740062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598191894431076352\/PjRqL0kE_normal.jpg",
      "id" : 108740062,
      "verified" : true
    }
  },
  "id" : 745417725879549952,
  "created_at" : "2016-06-22 00:46:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/745372662923329536\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/V7e31v3sA5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClgYfAiXEAEyk2M.jpg",
      "id_str" : "745372659328946177",
      "id" : 745372659328946177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClgYfAiXEAEyk2M.jpg",
      "sizes" : [ {
        "h" : 854,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 854,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 854,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/V7e31v3sA5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/FcqpwURjQb",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/friendlyatheist\/2016\/06\/21\/donald-trumps-meeting-with-evangelical-christian-leaders-was-full-of-facepalm-moments?_ts=1466545659",
      "display_url" : "patheos.com\/blogs\/friendly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745372662923329536",
  "text" : "Donald Trump\u2019s Meeting with Evangelical Christian Leaders Was Full of Facepalm Moments https:\/\/t.co\/FcqpwURjQb https:\/\/t.co\/V7e31v3sA5",
  "id" : 745372662923329536,
  "created_at" : "2016-06-21 21:47:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "relativistic",
      "screen_name" : "relativistic_",
      "indices" : [ 3, 17 ],
      "id_str" : "711734161070006272",
      "id" : 711734161070006272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Xs2FwS8oWm",
      "expanded_url" : "https:\/\/twitter.com\/onetrendywoman\/status\/745360699438817281",
      "display_url" : "twitter.com\/onetrendywoman\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745366697838706688",
  "text" : "RT @relativistic_: you didn't answer the question. Why is someone else's private life your business? https:\/\/t.co\/Xs2FwS8oWm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Xs2FwS8oWm",
        "expanded_url" : "https:\/\/twitter.com\/onetrendywoman\/status\/745360699438817281",
        "display_url" : "twitter.com\/onetrendywoman\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745361233126236162",
    "text" : "you didn't answer the question. Why is someone else's private life your business? https:\/\/t.co\/Xs2FwS8oWm",
    "id" : 745361233126236162,
    "created_at" : "2016-06-21 21:02:20 +0000",
    "user" : {
      "name" : "relativistic",
      "screen_name" : "relativistic_",
      "protected" : false,
      "id_str" : "711734161070006272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784460468870144000\/HhpfX7Zw_normal.jpg",
      "id" : 711734161070006272,
      "verified" : false
    }
  },
  "id" : 745366697838706688,
  "created_at" : "2016-06-21 21:24:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Stark",
      "screen_name" : "StopNuclearWar",
      "indices" : [ 3, 18 ],
      "id_str" : "299929232",
      "id" : 299929232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PoliceState",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/SEBWS0A9kN",
      "expanded_url" : "http:\/\/nyti.ms\/28L4GSP",
      "display_url" : "nyti.ms\/28L4GSP"
    } ]
  },
  "geo" : { },
  "id_str" : "745365577263386624",
  "text" : "RT @StopNuclearWar: Chinese Bank Spanks Workers, and the Internet Gives It a Flogging https:\/\/t.co\/SEBWS0A9kN #PoliceState",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PoliceState",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/SEBWS0A9kN",
        "expanded_url" : "http:\/\/nyti.ms\/28L4GSP",
        "display_url" : "nyti.ms\/28L4GSP"
      } ]
    },
    "geo" : { },
    "id_str" : "745361258585587713",
    "text" : "Chinese Bank Spanks Workers, and the Internet Gives It a Flogging https:\/\/t.co\/SEBWS0A9kN #PoliceState",
    "id" : 745361258585587713,
    "created_at" : "2016-06-21 21:02:26 +0000",
    "user" : {
      "name" : "Jesse Stark",
      "screen_name" : "StopNuclearWar",
      "protected" : false,
      "id_str" : "299929232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789157348157689856\/xkO1Cxoj_normal.jpg",
      "id" : 299929232,
      "verified" : false
    }
  },
  "id" : 745365577263386624,
  "created_at" : "2016-06-21 21:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "indices" : [ 3, 18 ],
      "id_str" : "26560483",
      "id" : 26560483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/AJQQtnk3Nj",
      "expanded_url" : "https:\/\/soundcloud.com\/macaudio-2\/waypoint-kangaroo-by-curtis-c-chen-audiobook-excerpt",
      "display_url" : "soundcloud.com\/macaudio-2\/way\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745349948401655809",
  "text" : "RT @MacmillanAudio: My new sounds: Waypoint Kangaroo by Curtis C. Chen audiobook excerpt https:\/\/t.co\/AJQQtnk3Nj on #SoundCloud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/soundcloud.com\" rel=\"nofollow\"\u003ESoundCloud\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoundCloud",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/AJQQtnk3Nj",
        "expanded_url" : "https:\/\/soundcloud.com\/macaudio-2\/waypoint-kangaroo-by-curtis-c-chen-audiobook-excerpt",
        "display_url" : "soundcloud.com\/macaudio-2\/way\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745347273266192384",
    "text" : "My new sounds: Waypoint Kangaroo by Curtis C. Chen audiobook excerpt https:\/\/t.co\/AJQQtnk3Nj on #SoundCloud",
    "id" : 745347273266192384,
    "created_at" : "2016-06-21 20:06:52 +0000",
    "user" : {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "protected" : false,
      "id_str" : "26560483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473834349394010112\/_cwv_j5v_normal.jpeg",
      "id" : 26560483,
      "verified" : true
    }
  },
  "id" : 745349948401655809,
  "created_at" : "2016-06-21 20:17:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SVbizjournal",
      "screen_name" : "SVbizjournal",
      "indices" : [ 3, 16 ],
      "id_str" : "17625154",
      "id" : 17625154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/NaPGHMSUjs",
      "expanded_url" : "http:\/\/bizj.us\/1n0zp8",
      "display_url" : "bizj.us\/1n0zp8"
    } ]
  },
  "geo" : { },
  "id_str" : "745348522506129408",
  "text" : "RT @SVbizjournal: The Dancing Cat lounge in San Jose enables cat-lovers to hang out with cats up for adoption https:\/\/t.co\/NaPGHMSUjs https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SVbizjournal\/status\/745346823368302595\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/HrQ1wOWRz8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clfct4mWQAA9YfL.jpg",
        "id_str" : "745306944198557696",
        "id" : 745306944198557696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clfct4mWQAA9YfL.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HrQ1wOWRz8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/NaPGHMSUjs",
        "expanded_url" : "http:\/\/bizj.us\/1n0zp8",
        "display_url" : "bizj.us\/1n0zp8"
      } ]
    },
    "geo" : { },
    "id_str" : "745346823368302595",
    "text" : "The Dancing Cat lounge in San Jose enables cat-lovers to hang out with cats up for adoption https:\/\/t.co\/NaPGHMSUjs https:\/\/t.co\/HrQ1wOWRz8",
    "id" : 745346823368302595,
    "created_at" : "2016-06-21 20:05:05 +0000",
    "user" : {
      "name" : "SVbizjournal",
      "screen_name" : "SVbizjournal",
      "protected" : false,
      "id_str" : "17625154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3316897902\/a5e5ca8a6a4fcbd0159c55fe88777fda_normal.jpeg",
      "id" : 17625154,
      "verified" : false
    }
  },
  "id" : 745348522506129408,
  "created_at" : "2016-06-21 20:11:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/LkcPQ88qzx",
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/745306222828597249",
      "display_url" : "twitter.com\/CamoDave_\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745348125477470209",
  "text" : "AWWW!! https:\/\/t.co\/LkcPQ88qzx",
  "id" : 745348125477470209,
  "created_at" : "2016-06-21 20:10:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "indices" : [ 3, 16 ],
      "id_str" : "23150269",
      "id" : 23150269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745348016098390016",
  "text" : "RT @beardonabike: You don't have to \"meet God half way\". God will meet you where you are. God's legs are longer, he can close the distance\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745342653131173888",
    "text" : "You don't have to \"meet God half way\". God will meet you where you are. God's legs are longer, he can close the distance between you easily.",
    "id" : 745342653131173888,
    "created_at" : "2016-06-21 19:48:30 +0000",
    "user" : {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "protected" : false,
      "id_str" : "23150269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461260607669293056\/udIfmFCN_normal.jpeg",
      "id" : 23150269,
      "verified" : false
    }
  },
  "id" : 745348016098390016,
  "created_at" : "2016-06-21 20:09:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 7, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/iVHq9WnHCu",
      "expanded_url" : "https:\/\/twitter.com\/BrianRathbone\/status\/745237176808517632",
      "display_url" : "twitter.com\/BrianRathbone\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745243118052704257",
  "text" : "deep.. #woo https:\/\/t.co\/iVHq9WnHCu",
  "id" : 745243118052704257,
  "created_at" : "2016-06-21 13:12:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/745237773918015489\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/YJvJLYXs4f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CledvoxXEAADP37.jpg",
      "id_str" : "745237705076969472",
      "id" : 745237705076969472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CledvoxXEAADP37.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YJvJLYXs4f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745241419317678080",
  "text" : "RT @Nigelstewart76: Robin having it's pick of seeds at the ground feeder https:\/\/t.co\/YJvJLYXs4f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/745237773918015489\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/YJvJLYXs4f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CledvoxXEAADP37.jpg",
        "id_str" : "745237705076969472",
        "id" : 745237705076969472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CledvoxXEAADP37.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YJvJLYXs4f"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745237773918015489",
    "text" : "Robin having it's pick of seeds at the ground feeder https:\/\/t.co\/YJvJLYXs4f",
    "id" : 745237773918015489,
    "created_at" : "2016-06-21 12:51:45 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 745241419317678080,
  "created_at" : "2016-06-21 13:06:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "indices" : [ 3, 15 ],
      "id_str" : "2233154425",
      "id" : 2233154425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745241165935558657",
  "text" : "RT @StephenKing: In America it is easier for a crazy person to get a gun than it is for a sick person to get pain medication. Screwed up pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745214061630136326",
    "text" : "In America it is easier for a crazy person to get a gun than it is for a sick person to get pain medication. Screwed up priorities.",
    "id" : 745214061630136326,
    "created_at" : "2016-06-21 11:17:32 +0000",
    "user" : {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "protected" : false,
      "id_str" : "2233154425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000836981162\/b683f7509ec792c3e481ead332940cdc_normal.jpeg",
      "id" : 2233154425,
      "verified" : true
    }
  },
  "id" : 745241165935558657,
  "created_at" : "2016-06-21 13:05:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "motiwake",
      "screen_name" : "simplelogicpt",
      "indices" : [ 3, 17 ],
      "id_str" : "4193449157",
      "id" : 4193449157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/QlYFGPFvMO",
      "expanded_url" : "http:\/\/bit.ly\/1UhMaTp",
      "display_url" : "bit.ly\/1UhMaTp"
    } ]
  },
  "geo" : { },
  "id_str" : "745240662971420672",
  "text" : "RT @simplelogicpt: Water acting all quantum and stuff\nhttps:\/\/t.co\/QlYFGPFvMO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/QlYFGPFvMO",
        "expanded_url" : "http:\/\/bit.ly\/1UhMaTp",
        "display_url" : "bit.ly\/1UhMaTp"
      } ]
    },
    "geo" : { },
    "id_str" : "744715412907122688",
    "text" : "Water acting all quantum and stuff\nhttps:\/\/t.co\/QlYFGPFvMO",
    "id" : 744715412907122688,
    "created_at" : "2016-06-20 02:16:05 +0000",
    "user" : {
      "name" : "motiwake",
      "screen_name" : "simplelogicpt",
      "protected" : false,
      "id_str" : "4193449157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676592637101654016\/HQFCdOrB_normal.png",
      "id" : 4193449157,
      "verified" : false
    }
  },
  "id" : 745240662971420672,
  "created_at" : "2016-06-21 13:03:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dwaynereaves\/status\/745146216502046720\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/AN3zLdTSlu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CldKffZVAAEsFUI.jpg",
      "id_str" : "745146168217239553",
      "id" : 745146168217239553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CldKffZVAAEsFUI.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/AN3zLdTSlu"
    } ],
    "hashtags" : [ {
      "text" : "StrawberryMoon",
      "indices" : [ 18, 33 ]
    }, {
      "text" : "northcarolina",
      "indices" : [ 34, 48 ]
    }, {
      "text" : "weather",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "ncwx",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745236923699044352",
  "text" : "RT @dwaynereaves: #StrawberryMoon #northcarolina #weather #ncwx https:\/\/t.co\/AN3zLdTSlu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dwaynereaves\/status\/745146216502046720\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/AN3zLdTSlu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CldKffZVAAEsFUI.jpg",
        "id_str" : "745146168217239553",
        "id" : 745146168217239553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CldKffZVAAEsFUI.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/AN3zLdTSlu"
      } ],
      "hashtags" : [ {
        "text" : "StrawberryMoon",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "northcarolina",
        "indices" : [ 16, 30 ]
      }, {
        "text" : "weather",
        "indices" : [ 31, 39 ]
      }, {
        "text" : "ncwx",
        "indices" : [ 40, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745146216502046720",
    "text" : "#StrawberryMoon #northcarolina #weather #ncwx https:\/\/t.co\/AN3zLdTSlu",
    "id" : 745146216502046720,
    "created_at" : "2016-06-21 06:47:56 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 745236923699044352,
  "created_at" : "2016-06-21 12:48:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "9GAG",
      "screen_name" : "9GAG",
      "indices" : [ 3, 8 ],
      "id_str" : "16548023",
      "id" : 16548023
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/9GAG\/status\/745202275610726401\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/yYLChUzkCZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cld9hLEWgAAWqpL.jpg",
      "id_str" : "745202272213303296",
      "id" : 745202272213303296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cld9hLEWgAAWqpL.jpg",
      "sizes" : [ {
        "h" : 687,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/yYLChUzkCZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/OZgIQ16NZe",
      "expanded_url" : "http:\/\/9gag.com\/gag\/a3jYbj7?ref=tp",
      "display_url" : "9gag.com\/gag\/a3jYbj7?re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745236833819365376",
  "text" : "RT @9GAG: I wish all conflicts were like this!\nhttps:\/\/t.co\/OZgIQ16NZe https:\/\/t.co\/yYLChUzkCZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/9GAG\/status\/745202275610726401\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/yYLChUzkCZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cld9hLEWgAAWqpL.jpg",
        "id_str" : "745202272213303296",
        "id" : 745202272213303296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cld9hLEWgAAWqpL.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/yYLChUzkCZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/OZgIQ16NZe",
        "expanded_url" : "http:\/\/9gag.com\/gag\/a3jYbj7?ref=tp",
        "display_url" : "9gag.com\/gag\/a3jYbj7?re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745202275610726401",
    "text" : "I wish all conflicts were like this!\nhttps:\/\/t.co\/OZgIQ16NZe https:\/\/t.co\/yYLChUzkCZ",
    "id" : 745202275610726401,
    "created_at" : "2016-06-21 10:30:42 +0000",
    "user" : {
      "name" : "9GAG",
      "screen_name" : "9GAG",
      "protected" : false,
      "id_str" : "16548023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616147175987265536\/EQm39fW7_normal.png",
      "id" : 16548023,
      "verified" : true
    }
  },
  "id" : 745236833819365376,
  "created_at" : "2016-06-21 12:48:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StumbleUpon",
      "screen_name" : "StumbleUpon",
      "indices" : [ 3, 15 ],
      "id_str" : "15395087",
      "id" : 15395087
    }, {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 17, 24 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StumbleUpon\/status\/723919477209886720\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/BDM9TyaKdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqthZbU8AIO5An.jpg",
      "id_str" : "723581479419179010",
      "id" : 723581479419179010,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqthZbU8AIO5An.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BDM9TyaKdu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/zR2DzYhGXK",
      "expanded_url" : "http:\/\/www.stumbleupon.com\/su\/15zROn\/",
      "display_url" : "stumbleupon.com\/su\/15zROn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "745060640180547584",
  "text" : "RT @StumbleUpon: @PopSci's Most Wanted Gadgets For May\nhttps:\/\/t.co\/zR2DzYhGXK https:\/\/t.co\/BDM9TyaKdu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Popular Science",
        "screen_name" : "PopSci",
        "indices" : [ 0, 7 ],
        "id_str" : "19722699",
        "id" : 19722699
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StumbleUpon\/status\/723919477209886720\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/BDM9TyaKdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqthZbU8AIO5An.jpg",
        "id_str" : "723581479419179010",
        "id" : 723581479419179010,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqthZbU8AIO5An.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BDM9TyaKdu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/zR2DzYhGXK",
        "expanded_url" : "http:\/\/www.stumbleupon.com\/su\/15zROn\/",
        "display_url" : "stumbleupon.com\/su\/15zROn\/"
      } ]
    },
    "geo" : { },
    "id_str" : "723919477209886720",
    "in_reply_to_user_id" : 19722699,
    "text" : "@PopSci's Most Wanted Gadgets For May\nhttps:\/\/t.co\/zR2DzYhGXK https:\/\/t.co\/BDM9TyaKdu",
    "id" : 723919477209886720,
    "created_at" : "2016-04-23 17:00:27 +0000",
    "in_reply_to_screen_name" : "PopSci",
    "in_reply_to_user_id_str" : "19722699",
    "user" : {
      "name" : "StumbleUpon",
      "screen_name" : "StumbleUpon",
      "protected" : false,
      "id_str" : "15395087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2875219118\/a8cd030ee537f2337c0e2d4e5b6e076c_normal.png",
      "id" : 15395087,
      "verified" : true
    }
  },
  "id" : 745060640180547584,
  "created_at" : "2016-06-21 01:07:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Andrews",
      "screen_name" : "ijandrews1",
      "indices" : [ 3, 14 ],
      "id_str" : "4386648017",
      "id" : 4386648017
    }, {
      "name" : "Birding Lothian",
      "screen_name" : "birdinglothian",
      "indices" : [ 112, 127 ],
      "id_str" : "400583338",
      "id" : 400583338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745049511018496000",
  "text" : "RT @ijandrews1: The Queen Eider at Musselburgh again today - not getting on that well with the locals  at times @birdinglothian https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Birding Lothian",
        "screen_name" : "birdinglothian",
        "indices" : [ 96, 111 ],
        "id_str" : "400583338",
        "id" : 400583338
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ijandrews1\/status\/744565201316487168\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JliXUvKq62",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClU6GW_XIAEfuN-.jpg",
        "id_str" : "744565194324647937",
        "id" : 744565194324647937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClU6GW_XIAEfuN-.jpg",
        "sizes" : [ {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/JliXUvKq62"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ijandrews1\/status\/744565201316487168\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JliXUvKq62",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClU6GTvXIAAE_uo.jpg",
        "id_str" : "744565193452232704",
        "id" : 744565193452232704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClU6GTvXIAAE_uo.jpg",
        "sizes" : [ {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/JliXUvKq62"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ijandrews1\/status\/744565201316487168\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JliXUvKq62",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClU6FgTWgAA7wTj.jpg",
        "id_str" : "744565179644542976",
        "id" : 744565179644542976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClU6FgTWgAA7wTj.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/JliXUvKq62"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ijandrews1\/status\/744565201316487168\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JliXUvKq62",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClU6FBPXIAA_lrr.jpg",
        "id_str" : "744565171306307584",
        "id" : 744565171306307584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClU6FBPXIAA_lrr.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/JliXUvKq62"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744565201316487168",
    "text" : "The Queen Eider at Musselburgh again today - not getting on that well with the locals  at times @birdinglothian https:\/\/t.co\/JliXUvKq62",
    "id" : 744565201316487168,
    "created_at" : "2016-06-19 16:19:12 +0000",
    "user" : {
      "name" : "Ian Andrews",
      "screen_name" : "ijandrews1",
      "protected" : false,
      "id_str" : "4386648017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711314333796540420\/6fZeT4Qe_normal.jpg",
      "id" : 4386648017,
      "verified" : false
    }
  },
  "id" : 745049511018496000,
  "created_at" : "2016-06-21 00:23:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 26, 36 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "einstein",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/X5xWFrsz3l",
      "expanded_url" : "https:\/\/igg.me\/p\/1739833\/twtr",
      "display_url" : "igg.me\/p\/1739833\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "744935722461831168",
  "text" : "A Theory of Everything on @indiegogo https:\/\/t.co\/X5xWFrsz3l #physics #einstein",
  "id" : 744935722461831168,
  "created_at" : "2016-06-20 16:51:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "feedly",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/VbXAI5gy9z",
      "expanded_url" : "http:\/\/www.thisamericanlife.org\/radio-archives\/episode\/589\/tell-me-im-fat",
      "display_url" : "thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744934797802409984",
  "text" : "Tell Me I'm Fat https:\/\/t.co\/VbXAI5gy9z #podcasts #feedly",
  "id" : 744934797802409984,
  "created_at" : "2016-06-20 16:47:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelso",
      "screen_name" : "audible",
      "indices" : [ 24, 32 ],
      "id_str" : "1579651",
      "id" : 1579651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/744909265702387712\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/q6T0hkv1Ay",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZzB4LWEAAlqt9.jpg",
      "id_str" : "744909264473427968",
      "id" : 744909264473427968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZzB4LWEAAlqt9.jpg",
      "sizes" : [ {
        "h" : 9,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 9,
        "resize" : "crop",
        "w" : 9
      }, {
        "h" : 9,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 9,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 9,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/q6T0hkv1Ay"
    } ],
    "hashtags" : [ {
      "text" : "audible",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "audiobooks",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/6I1YvtyAmH",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/mighty-streaming-music-without-your-phone?_ts=1466435179#\/comments",
      "display_url" : "indiegogo.com\/projects\/might\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744909265702387712",
  "text" : "so much this!! #audible @audible #audiobooks &gt; Mighty - Streaming Music Without Your Phone https:\/\/t.co\/6I1YvtyAmH https:\/\/t.co\/q6T0hkv1Ay",
  "id" : 744909265702387712,
  "created_at" : "2016-06-20 15:06:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 87, 97 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1Jqe8xUUgR",
      "expanded_url" : "https:\/\/igg.me\/p\/1379933\/twtr",
      "display_url" : "igg.me\/p\/1379933\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "744886485623709697",
  "text" : "fruit flavored cup that tricks the brain into thinking your plain water is flavored on @indiegogo https:\/\/t.co\/1Jqe8xUUgR",
  "id" : 744886485623709697,
  "created_at" : "2016-06-20 13:35:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 54, 64 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/1Jb8VTNVj2",
      "expanded_url" : "https:\/\/igg.me\/p\/1789278\/twtr",
      "display_url" : "igg.me\/p\/1789278\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "744882062532943872",
  "text" : "Runcible The Circular, Extensible, Anti-Smartphone on @indiegogo https:\/\/t.co\/1Jb8VTNVj2",
  "id" : 744882062532943872,
  "created_at" : "2016-06-20 13:18:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 74, 84 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/gzspJSLb7T",
      "expanded_url" : "https:\/\/igg.me\/p\/1727028\/twtr",
      "display_url" : "igg.me\/p\/1727028\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "744876654477074433",
  "text" : "Help make it happen for ZUS Kevlar Charging Cable - Lifetime Guarantee on @indiegogo https:\/\/t.co\/gzspJSLb7T",
  "id" : 744876654477074433,
  "created_at" : "2016-06-20 12:56:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/BvaSszvq2i",
      "expanded_url" : "https:\/\/twitter.com\/hellomaitria\/status\/744696356258910208",
      "display_url" : "twitter.com\/hellomaitria\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744870047164829696",
  "text" : "RT @onealexharms: I guess I always say it was an amazing conversation. But... I think you'll like this. https:\/\/t.co\/BvaSszvq2i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/BvaSszvq2i",
        "expanded_url" : "https:\/\/twitter.com\/hellomaitria\/status\/744696356258910208",
        "display_url" : "twitter.com\/hellomaitria\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744703355675611136",
    "text" : "I guess I always say it was an amazing conversation. But... I think you'll like this. https:\/\/t.co\/BvaSszvq2i",
    "id" : 744703355675611136,
    "created_at" : "2016-06-20 01:28:10 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 744870047164829696,
  "created_at" : "2016-06-20 12:30:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/C7jtdd303B",
      "expanded_url" : "http:\/\/www.stitcher.com\/podcast\/the-geek-joy-podcast",
      "display_url" : "stitcher.com\/podcast\/the-ge\u2026"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/WyMIOlwJTB",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/podcast\/the-geek-joy-podcast\/id1075146058?mt=2",
      "display_url" : "itunes.apple.com\/us\/podcast\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744648170425171968",
  "text" : "RT @onealexharms: The Geek Joy Podcast is on Stitcher:  https:\/\/t.co\/C7jtdd303B and iTunes: https:\/\/t.co\/WyMIOlwJTB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/C7jtdd303B",
        "expanded_url" : "http:\/\/www.stitcher.com\/podcast\/the-geek-joy-podcast",
        "display_url" : "stitcher.com\/podcast\/the-ge\u2026"
      }, {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/WyMIOlwJTB",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/podcast\/the-geek-joy-podcast\/id1075146058?mt=2",
        "display_url" : "itunes.apple.com\/us\/podcast\/the\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "744641947915194368",
    "geo" : { },
    "id_str" : "744642382554095616",
    "in_reply_to_user_id" : 15349954,
    "text" : "The Geek Joy Podcast is on Stitcher:  https:\/\/t.co\/C7jtdd303B and iTunes: https:\/\/t.co\/WyMIOlwJTB",
    "id" : 744642382554095616,
    "in_reply_to_status_id" : 744641947915194368,
    "created_at" : "2016-06-19 21:25:53 +0000",
    "in_reply_to_screen_name" : "onealexharms",
    "in_reply_to_user_id_str" : "15349954",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 744648170425171968,
  "created_at" : "2016-06-19 21:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744648133901160448",
  "text" : "RT @onealexharms: Juicy podcast episode about depression, energy, financial security, existential angst, &amp; creating your own story. Coming\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744641947915194368",
    "text" : "Juicy podcast episode about depression, energy, financial security, existential angst, &amp; creating your own story. Coming tonight at 9!",
    "id" : 744641947915194368,
    "created_at" : "2016-06-19 21:24:09 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 744648133901160448,
  "created_at" : "2016-06-19 21:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audible",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "audiobooks",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "music",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "podcasts",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744562525904175104",
  "text" : "wondering if i could use cell phone buttons with #audible app (or similar?) like to pause, play, next, back? #audiobooks #music #podcasts",
  "id" : 744562525904175104,
  "created_at" : "2016-06-19 16:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/744189872500510720\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Q3pnuJZkGd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClPkvh3WIAEhH5z.jpg",
      "id_str" : "744189868641755137",
      "id" : 744189868641755137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClPkvh3WIAEhH5z.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/Q3pnuJZkGd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/zBlsvhm9Ej",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nolongerquivering\/2016\/06\/nlq-question-of-the-week-how-do-you-stop-worrying-about-hell\/?_ts=1466263661#comment-2737461529",
      "display_url" : "patheos.com\/blogs\/nolonger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744189872500510720",
  "text" : "NLQ Question of the Week: How do You Stop Worrying About Hell? https:\/\/t.co\/zBlsvhm9Ej https:\/\/t.co\/Q3pnuJZkGd",
  "id" : 744189872500510720,
  "created_at" : "2016-06-18 15:27:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/744188158980595712\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/y9RE3y2in7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClPjL1cXEAATXhB.jpg",
      "id_str" : "744188155910361088",
      "id" : 744188155910361088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClPjL1cXEAATXhB.jpg",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/y9RE3y2in7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/QELggGGaky",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nolongerquivering\/2016\/06\/nlq-question-of-the-week-how-do-you-stop-worrying-about-hell\/?_ts=1466263253#comment-2735364197",
      "display_url" : "patheos.com\/blogs\/nolonger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744188158980595712",
  "text" : "NLQ Question of the Week: How do You Stop Worrying About Hell? https:\/\/t.co\/QELggGGaky https:\/\/t.co\/y9RE3y2in7",
  "id" : 744188158980595712,
  "created_at" : "2016-06-18 15:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asymptotic Binary",
      "screen_name" : "asymbina",
      "indices" : [ 3, 12 ],
      "id_str" : "93638430",
      "id" : 93638430
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/asymbina\/status\/744007313384701952\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/FGKdaoBf1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClM-qiGXIAQFe6I.jpg",
      "id_str" : "744007263875178500",
      "id" : 744007263875178500,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClM-qiGXIAQFe6I.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 604
      } ],
      "display_url" : "pic.twitter.com\/FGKdaoBf1O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744163365891760128",
  "text" : "RT @asymbina: Every time I see this photo my soul feels a little better. https:\/\/t.co\/FGKdaoBf1O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/asymbina\/status\/744007313384701952\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/FGKdaoBf1O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClM-qiGXIAQFe6I.jpg",
        "id_str" : "744007263875178500",
        "id" : 744007263875178500,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClM-qiGXIAQFe6I.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 604
        } ],
        "display_url" : "pic.twitter.com\/FGKdaoBf1O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744007313384701952",
    "text" : "Every time I see this photo my soul feels a little better. https:\/\/t.co\/FGKdaoBf1O",
    "id" : 744007313384701952,
    "created_at" : "2016-06-18 03:22:21 +0000",
    "user" : {
      "name" : "Asymptotic Binary",
      "screen_name" : "asymbina",
      "protected" : false,
      "id_str" : "93638430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730455380988465152\/Z8lTbsE7_normal.jpg",
      "id" : 93638430,
      "verified" : false
    }
  },
  "id" : 744163365891760128,
  "created_at" : "2016-06-18 13:42:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Care.com",
      "screen_name" : "CareDotCom",
      "indices" : [ 3, 14 ],
      "id_str" : "16785615",
      "id" : 16785615
    }, {
      "name" : "Parents Magazine",
      "screen_name" : "parentsmagazine",
      "indices" : [ 97, 113 ],
      "id_str" : "29730065",
      "id" : 29730065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/fTLD1RDOdN",
      "expanded_url" : "http:\/\/bit.ly\/1V2e8le",
      "display_url" : "bit.ly\/1V2e8le"
    } ]
  },
  "geo" : { },
  "id_str" : "744163066540081152",
  "text" : "RT @CareDotCom: Mom's Photo of Son Playing Where Alligator Attack Happened Shuts Down Haters via @parentsmagazine https:\/\/t.co\/fTLD1RDOdN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Parents Magazine",
        "screen_name" : "parentsmagazine",
        "indices" : [ 81, 97 ],
        "id_str" : "29730065",
        "id" : 29730065
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/fTLD1RDOdN",
        "expanded_url" : "http:\/\/bit.ly\/1V2e8le",
        "display_url" : "bit.ly\/1V2e8le"
      } ]
    },
    "geo" : { },
    "id_str" : "743947837084311554",
    "text" : "Mom's Photo of Son Playing Where Alligator Attack Happened Shuts Down Haters via @parentsmagazine https:\/\/t.co\/fTLD1RDOdN",
    "id" : 743947837084311554,
    "created_at" : "2016-06-17 23:26:00 +0000",
    "user" : {
      "name" : "Care.com",
      "screen_name" : "CareDotCom",
      "protected" : false,
      "id_str" : "16785615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709841311432572928\/eUER-WRB_normal.jpg",
      "id" : 16785615,
      "verified" : true
    }
  },
  "id" : 744163066540081152,
  "created_at" : "2016-06-18 13:41:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743976060170051586",
  "geo" : { },
  "id_str" : "743987267350433792",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre trailer looked interesting. i'll put on my list.",
  "id" : 743987267350433792,
  "in_reply_to_status_id" : 743976060170051586,
  "created_at" : "2016-06-18 02:02:41 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 34, 44 ]
    }, {
      "text" : "android",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/5fOclefjRl",
      "expanded_url" : "http:\/\/msimonides.github.io\/homerplayer\/",
      "display_url" : "msimonides.github.io\/homerplayer\/"
    } ]
  },
  "geo" : { },
  "id_str" : "743918312048988160",
  "text" : "interesting &gt; Homer Player: an #audiobook player for the elderly https:\/\/t.co\/5fOclefjRl #android",
  "id" : 743918312048988160,
  "created_at" : "2016-06-17 21:28:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/743868062357659648\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/GkUkBXXD4b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClLADvDWgAICG1k.jpg",
      "id_str" : "743868058872217602",
      "id" : 743868058872217602,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClLADvDWgAICG1k.jpg",
      "sizes" : [ {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/GkUkBXXD4b"
    } ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 3, 8 ]
    }, {
      "text" : "INTP",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/sPZou71J1B",
      "expanded_url" : "https:\/\/www.16personalities.com\/intp-personality?_ts=1466186936",
      "display_url" : "16personalities.com\/intp-personali\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743868062357659648",
  "text" : "im #INFP but this snippet is me. #INTP https:\/\/t.co\/sPZou71J1B https:\/\/t.co\/GkUkBXXD4b",
  "id" : 743868062357659648,
  "created_at" : "2016-06-17 18:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/1cVWyFTRoy",
      "expanded_url" : "https:\/\/twitter.com\/Charmantides\/status\/743840065013616640",
      "display_url" : "twitter.com\/Charmantides\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743866983087738889",
  "text" : "not that I really know you, but from yr tweets.. yeah, sounds like you.. def the logician, vigorous intellect.. https:\/\/t.co\/1cVWyFTRoy",
  "id" : 743866983087738889,
  "created_at" : "2016-06-17 18:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Ravelry",
      "screen_name" : "ravelry",
      "indices" : [ 74, 82 ],
      "id_str" : "15139049",
      "id" : 15139049
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/743848520893890560\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/zfd56gPZDd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClKuSClUkAAO8rm.jpg",
      "id_str" : "743848513423839232",
      "id" : 743848513423839232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClKuSClUkAAO8rm.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/zfd56gPZDd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Mtgo7MXaeb",
      "expanded_url" : "http:\/\/www.ravelry.com\/patterns\/library\/peeking-cat-butt-coaster",
      "display_url" : "ravelry.com\/patterns\/libra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743865744077824002",
  "text" : "RT @ErinEFarley: Never disappointed with the fun patterns you can find on @ravelry https:\/\/t.co\/Mtgo7MXaeb https:\/\/t.co\/zfd56gPZDd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ravelry",
        "screen_name" : "ravelry",
        "indices" : [ 57, 65 ],
        "id_str" : "15139049",
        "id" : 15139049
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/743848520893890560\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/zfd56gPZDd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClKuSClUkAAO8rm.jpg",
        "id_str" : "743848513423839232",
        "id" : 743848513423839232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClKuSClUkAAO8rm.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/zfd56gPZDd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/Mtgo7MXaeb",
        "expanded_url" : "http:\/\/www.ravelry.com\/patterns\/library\/peeking-cat-butt-coaster",
        "display_url" : "ravelry.com\/patterns\/libra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743848520893890560",
    "text" : "Never disappointed with the fun patterns you can find on @ravelry https:\/\/t.co\/Mtgo7MXaeb https:\/\/t.co\/zfd56gPZDd",
    "id" : 743848520893890560,
    "created_at" : "2016-06-17 16:51:22 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 743865744077824002,
  "created_at" : "2016-06-17 17:59:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dreamerrambling",
      "screen_name" : "Dreamerrambling",
      "indices" : [ 100, 116 ],
      "id_str" : "2885893736",
      "id" : 2885893736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/1wcwJ3ZtSa",
      "expanded_url" : "https:\/\/dreamerrambling.wordpress.com\/2013\/12\/11\/it-is-hard-being-an-infp\/",
      "display_url" : "dreamerrambling.wordpress.com\/2013\/12\/11\/it-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743835919623520256",
  "text" : "\"Every day I feel like I am actually an alien masquerading as a human.\" https:\/\/t.co\/1wcwJ3ZtSa via @Dreamerrambling #INFP",
  "id" : 743835919623520256,
  "created_at" : "2016-06-17 16:01:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dreamerrambling",
      "screen_name" : "Dreamerrambling",
      "indices" : [ 114, 130 ],
      "id_str" : "2885893736",
      "id" : 2885893736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/1wcwJ3ZtSa",
      "expanded_url" : "https:\/\/dreamerrambling.wordpress.com\/2013\/12\/11\/it-is-hard-being-an-infp\/",
      "display_url" : "dreamerrambling.wordpress.com\/2013\/12\/11\/it-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743835701389713408",
  "text" : "\"It\u2019s like you\u2019re on an entirely different wavelength from everyone else around you.\" https:\/\/t.co\/1wcwJ3ZtSa via @Dreamerrambling #INFP",
  "id" : 743835701389713408,
  "created_at" : "2016-06-17 16:00:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "indices" : [ 3, 12 ],
      "id_str" : "75372132",
      "id" : 75372132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FridayListens",
      "indices" : [ 20, 34 ]
    }, {
      "text" : "ThisIsTheAuthor",
      "indices" : [ 72, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/RUgZWMyJbZ",
      "expanded_url" : "http:\/\/ow.ly\/Mhhr301lIbs",
      "display_url" : "ow.ly\/Mhhr301lIbs"
    } ]
  },
  "geo" : { },
  "id_str" : "743824006416072704",
  "text" : "RT @PRHAudio: Happy #FridayListens! RT by 11:59pm EST to enter to win a #ThisIsTheAuthor speaker. US Only. https:\/\/t.co\/RUgZWMyJbZ https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PRHAudio\/status\/743791623214141440\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/60UTI8Lo2k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClJ6iaVWgAAKea-.jpg",
        "id_str" : "743791620072570880",
        "id" : 743791620072570880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClJ6iaVWgAAKea-.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/60UTI8Lo2k"
      } ],
      "hashtags" : [ {
        "text" : "FridayListens",
        "indices" : [ 6, 20 ]
      }, {
        "text" : "ThisIsTheAuthor",
        "indices" : [ 58, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/RUgZWMyJbZ",
        "expanded_url" : "http:\/\/ow.ly\/Mhhr301lIbs",
        "display_url" : "ow.ly\/Mhhr301lIbs"
      } ]
    },
    "geo" : { },
    "id_str" : "743791623214141440",
    "text" : "Happy #FridayListens! RT by 11:59pm EST to enter to win a #ThisIsTheAuthor speaker. US Only. https:\/\/t.co\/RUgZWMyJbZ https:\/\/t.co\/60UTI8Lo2k",
    "id" : 743791623214141440,
    "created_at" : "2016-06-17 13:05:16 +0000",
    "user" : {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "protected" : false,
      "id_str" : "75372132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606215515279753216\/KBzpETdK_normal.jpg",
      "id" : 75372132,
      "verified" : false
    }
  },
  "id" : 743824006416072704,
  "created_at" : "2016-06-17 15:13:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 51, 59 ]
    }, {
      "text" : "audiobooks",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "podcasts",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "music",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743822866727243777",
  "text" : "tiny phone posh $50 .. someone needs to make smart #android mp3 player for #audiobooks #podcasts #music .. take out cam.",
  "id" : 743822866727243777,
  "created_at" : "2016-06-17 15:09:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743573835639840772",
  "text" : "RT @onealexharms: I\u2019m bout to get really busy, but I don\u2019t care: The Geek Joy Podcast is coming back. New episode this Sunday evening.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743573304838074368",
    "text" : "I\u2019m bout to get really busy, but I don\u2019t care: The Geek Joy Podcast is coming back. New episode this Sunday evening.",
    "id" : 743573304838074368,
    "created_at" : "2016-06-16 22:37:45 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 743573835639840772,
  "created_at" : "2016-06-16 22:39:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Michael Urie",
      "screen_name" : "michaelurie",
      "indices" : [ 83, 95 ],
      "id_str" : "17357428",
      "id" : 17357428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LilyandtheOctopus",
      "indices" : [ 56, 74 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NSaeye8EVL",
      "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
      "display_url" : "bit.ly\/1X8y8YB"
    } ]
  },
  "geo" : { },
  "id_str" : "743534521895759876",
  "text" : "RT @SimonAudio: Follow &amp; RT to win the last copy of #LilyandtheOctopus read by @michaelurie! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Urie",
        "screen_name" : "michaelurie",
        "indices" : [ 67, 79 ],
        "id_str" : "17357428",
        "id" : 17357428
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SimonAudio\/status\/743531176019828737\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/cdQeW8g0lA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClGNqYeWQAA6b_1.jpg",
        "id_str" : "743531172756602880",
        "id" : 743531172756602880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClGNqYeWQAA6b_1.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/cdQeW8g0lA"
      } ],
      "hashtags" : [ {
        "text" : "LilyandtheOctopus",
        "indices" : [ 40, 58 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/NSaeye8EVL",
        "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
        "display_url" : "bit.ly\/1X8y8YB"
      } ]
    },
    "geo" : { },
    "id_str" : "743531176019828737",
    "text" : "Follow &amp; RT to win the last copy of #LilyandtheOctopus read by @michaelurie! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL https:\/\/t.co\/cdQeW8g0lA",
    "id" : 743531176019828737,
    "created_at" : "2016-06-16 19:50:21 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 743534521895759876,
  "created_at" : "2016-06-16 20:03:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743533224131969024",
  "text" : "RT @Mahala: Did you know that if you take OTC sleep aids and Melatonin together, you WILL sleep? It'll take 3 days to wake up, but you'll s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743530862357028864",
    "text" : "Did you know that if you take OTC sleep aids and Melatonin together, you WILL sleep? It'll take 3 days to wake up, but you'll sleep.",
    "id" : 743530862357028864,
    "created_at" : "2016-06-16 19:49:06 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 743533224131969024,
  "created_at" : "2016-06-16 19:58:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Michael Urie",
      "screen_name" : "michaelurie",
      "indices" : [ 80, 92 ],
      "id_str" : "17357428",
      "id" : 17357428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LilyandtheOctopus",
      "indices" : [ 53, 71 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/NSaeye8EVL",
      "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
      "display_url" : "bit.ly\/1X8y8YB"
    } ]
  },
  "geo" : { },
  "id_str" : "743520941729259521",
  "text" : "RT @SimonAudio: Follow &amp; RT to win 4\/5 copies of #LilyandtheOctopus read by @michaelurie! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Urie",
        "screen_name" : "michaelurie",
        "indices" : [ 64, 76 ],
        "id_str" : "17357428",
        "id" : 17357428
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SimonAudio\/status\/743512282139852800\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DOZvVRF7tL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClF8emSWAAAdufw.jpg",
        "id_str" : "743512278608248832",
        "id" : 743512278608248832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClF8emSWAAAdufw.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/DOZvVRF7tL"
      } ],
      "hashtags" : [ {
        "text" : "LilyandtheOctopus",
        "indices" : [ 37, 55 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/NSaeye8EVL",
        "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
        "display_url" : "bit.ly\/1X8y8YB"
      } ]
    },
    "geo" : { },
    "id_str" : "743512282139852800",
    "text" : "Follow &amp; RT to win 4\/5 copies of #LilyandtheOctopus read by @michaelurie! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL https:\/\/t.co\/DOZvVRF7tL",
    "id" : 743512282139852800,
    "created_at" : "2016-06-16 18:35:16 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 743520941729259521,
  "created_at" : "2016-06-16 19:09:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Simon & Schuster",
      "screen_name" : "SimonBooks",
      "indices" : [ 122, 133 ],
      "id_str" : "74478182",
      "id" : 74478182
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "LilyandtheOctopus",
      "indices" : [ 54, 72 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/NSaeye8EVL",
      "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
      "display_url" : "bit.ly\/1X8y8YB"
    } ]
  },
  "geo" : { },
  "id_str" : "743500137981419520",
  "text" : "RT @SimonAudio: Follow &amp; RT to #win 3\/5 copies of #LilyandtheOctopus on audio! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL @SimonBooks https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simon & Schuster",
        "screen_name" : "SimonBooks",
        "indices" : [ 106, 117 ],
        "id_str" : "74478182",
        "id" : 74478182
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SimonAudio\/status\/743493444170092546\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/6V85S6V00y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClFrWI8UsAA99RG.jpg",
        "id_str" : "743493441594634240",
        "id" : 743493441594634240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClFrWI8UsAA99RG.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/6V85S6V00y"
      } ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "LilyandtheOctopus",
        "indices" : [ 38, 56 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 67, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/NSaeye8EVL",
        "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
        "display_url" : "bit.ly\/1X8y8YB"
      } ]
    },
    "geo" : { },
    "id_str" : "743493444170092546",
    "text" : "Follow &amp; RT to #win 3\/5 copies of #LilyandtheOctopus on audio! #Sweeps rules: https:\/\/t.co\/NSaeye8EVL @SimonBooks https:\/\/t.co\/6V85S6V00y",
    "id" : 743493444170092546,
    "created_at" : "2016-06-16 17:20:25 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 743500137981419520,
  "created_at" : "2016-06-16 17:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "feedly",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/mkV8YxKkGA",
      "expanded_url" : "http:\/\/birdnote.org\/show\/loons-go-fishing",
      "display_url" : "birdnote.org\/show\/loons-go-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743450836567728128",
  "text" : "Loons Go Fishing https:\/\/t.co\/mkV8YxKkGA #podcasts #feedly",
  "id" : 743450836567728128,
  "created_at" : "2016-06-16 14:31:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 28, 35 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/sQzb6HHV4x",
      "expanded_url" : "http:\/\/kottke.org\/16\/06\/facebook-is-wrong-text-is-deathless",
      "display_url" : "kottke.org\/16\/06\/facebook\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743450551048863744",
  "text" : "Wrapping up language day on @kottke with a short post on why Facebook is wrong and text is the best https:\/\/t.co\/sQzb6HHV4x",
  "id" : 743450551048863744,
  "created_at" : "2016-06-16 14:29:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Thorne",
      "screen_name" : "HoptonHouseBnB",
      "indices" : [ 3, 18 ],
      "id_str" : "19490740",
      "id" : 19490740
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HoptonHouseBnB\/status\/743151639889125376\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Mzts9dYeFa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClA0dzBXIAAGpKd.jpg",
      "id_str" : "743151625032900608",
      "id" : 743151625032900608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClA0dzBXIAAGpKd.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Mzts9dYeFa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/iI35YN7ehm",
      "expanded_url" : "http:\/\/www.wildthornknitting.co.uk",
      "display_url" : "wildthornknitting.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "743178994527277056",
  "text" : "RT @HoptonHouseBnB: Nearly ready for tomorrow's knitting workshop - can we tempt you? \uD83D\uDE09 https:\/\/t.co\/iI35YN7ehm https:\/\/t.co\/Mzts9dYeFa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HoptonHouseBnB\/status\/743151639889125376\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/Mzts9dYeFa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClA0dzBXIAAGpKd.jpg",
        "id_str" : "743151625032900608",
        "id" : 743151625032900608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClA0dzBXIAAGpKd.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Mzts9dYeFa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/iI35YN7ehm",
        "expanded_url" : "http:\/\/www.wildthornknitting.co.uk",
        "display_url" : "wildthornknitting.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "743151639889125376",
    "text" : "Nearly ready for tomorrow's knitting workshop - can we tempt you? \uD83D\uDE09 https:\/\/t.co\/iI35YN7ehm https:\/\/t.co\/Mzts9dYeFa",
    "id" : 743151639889125376,
    "created_at" : "2016-06-15 18:42:12 +0000",
    "user" : {
      "name" : "Karen Thorne",
      "screen_name" : "HoptonHouseBnB",
      "protected" : false,
      "id_str" : "19490740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2865839034\/011aa15868ca074d7281f7d11c429dee_normal.jpeg",
      "id" : 19490740,
      "verified" : false
    }
  },
  "id" : 743178994527277056,
  "created_at" : "2016-06-15 20:30:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "clicks n' whistles",
      "screen_name" : "oceanCRIES",
      "indices" : [ 3, 14 ],
      "id_str" : "422305556",
      "id" : 422305556
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeaWorld",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "SeaSanctuary",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/UhO7A69zsG",
      "expanded_url" : "http:\/\/www.wctv.tv\/content\/news\/SeaWorld-wont-release-orcas-into-sea-cages--383011701.html",
      "display_url" : "wctv.tv\/content\/news\/S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743148444974456833",
  "text" : "RT @oceanCRIES: so #SeaWorld calls a #SeaSanctuary a 'sea-cage'\nthen what shld they call their CEMENT TANKS?\nhttps:\/\/t.co\/UhO7A69zsG https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oceanCRIES\/status\/743089761519276032\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/dMIHp4vQ3E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck_8MqHWsAACHn4.jpg",
        "id_str" : "743089757933187072",
        "id" : 743089757933187072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck_8MqHWsAACHn4.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dMIHp4vQ3E"
      } ],
      "hashtags" : [ {
        "text" : "SeaWorld",
        "indices" : [ 3, 12 ]
      }, {
        "text" : "SeaSanctuary",
        "indices" : [ 21, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/UhO7A69zsG",
        "expanded_url" : "http:\/\/www.wctv.tv\/content\/news\/SeaWorld-wont-release-orcas-into-sea-cages--383011701.html",
        "display_url" : "wctv.tv\/content\/news\/S\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743089761519276032",
    "text" : "so #SeaWorld calls a #SeaSanctuary a 'sea-cage'\nthen what shld they call their CEMENT TANKS?\nhttps:\/\/t.co\/UhO7A69zsG https:\/\/t.co\/dMIHp4vQ3E",
    "id" : 743089761519276032,
    "created_at" : "2016-06-15 14:36:19 +0000",
    "user" : {
      "name" : "clicks n' whistles",
      "screen_name" : "oceanCRIES",
      "protected" : false,
      "id_str" : "422305556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1659891932\/floating_normal.jpg",
      "id" : 422305556,
      "verified" : false
    }
  },
  "id" : 743148444974456833,
  "created_at" : "2016-06-15 18:29:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I luv being Teamster",
      "screen_name" : "JimKilbane",
      "indices" : [ 3, 14 ],
      "id_str" : "500391228",
      "id" : 500391228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743147410315223040",
  "text" : "RT @JimKilbane: I'm so proud. It doesn't look like much but the birds in my paperbox hatched. I'm the proud father of some birds. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JimKilbane\/status\/743095266434265089\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/JtWBDALZjj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClABNGiXAAEE5YI.jpg",
        "id_str" : "743095263120785409",
        "id" : 743095263120785409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClABNGiXAAEE5YI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JtWBDALZjj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743095266434265089",
    "text" : "I'm so proud. It doesn't look like much but the birds in my paperbox hatched. I'm the proud father of some birds. https:\/\/t.co\/JtWBDALZjj",
    "id" : 743095266434265089,
    "created_at" : "2016-06-15 14:58:12 +0000",
    "user" : {
      "name" : "I luv being Teamster",
      "screen_name" : "JimKilbane",
      "protected" : false,
      "id_str" : "500391228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796113022620143616\/QTSRZLVi_normal.jpg",
      "id" : 500391228,
      "verified" : false
    }
  },
  "id" : 743147410315223040,
  "created_at" : "2016-06-15 18:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Talking Points Memo",
      "screen_name" : "TPM",
      "indices" : [ 84, 88 ],
      "id_str" : "14717197",
      "id" : 14717197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/PPVVNMDK6W",
      "expanded_url" : "http:\/\/talkingpointsmemo.com\/livewire\/spencer-cox-lgbt-orlando-vigil",
      "display_url" : "talkingpointsmemo.com\/livewire\/spenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743137181384970242",
  "text" : "GOPer Apologizes To LGBT Community At Orlando Vigil: 'My Heart Has Changed' (VIDEO) @TPM https:\/\/t.co\/PPVVNMDK6W",
  "id" : 743137181384970242,
  "created_at" : "2016-06-15 17:44:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Daily News",
      "screen_name" : "NYDailyNews",
      "indices" : [ 97, 109 ],
      "id_str" : "9763482",
      "id" : 9763482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/KNrj7oO91k",
      "expanded_url" : "http:\/\/nydn.us\/RedneckonOrlando",
      "display_url" : "nydn.us\/RedneckonOrlan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743135197349158912",
  "text" : "No jokes from Liberal Redneck Trae Crowder after the Orlando massacre (Warning: Strong Language) @nydailynews https:\/\/t.co\/KNrj7oO91k",
  "id" : 743135197349158912,
  "created_at" : "2016-06-15 17:36:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#Q13FOX",
      "screen_name" : "Q13FOX",
      "indices" : [ 107, 114 ],
      "id_str" : "17070252",
      "id" : 17070252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8Rz9s2SPmZ",
      "expanded_url" : "http:\/\/via.q13fox.com\/dRYWb",
      "display_url" : "via.q13fox.com\/dRYWb"
    } ]
  },
  "geo" : { },
  "id_str" : "743128734241280000",
  "text" : "VIDEO: Police officer praised after two vicious dogs charged \u2014 and he did this https:\/\/t.co\/8Rz9s2SPmZ via @Q13FOX",
  "id" : 743128734241280000,
  "created_at" : "2016-06-15 17:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FayObserver.com",
      "screen_name" : "fayobserver",
      "indices" : [ 3, 15 ],
      "id_str" : "13210422",
      "id" : 13210422
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fayobserver\/status\/743068064468455424\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/BNiR2JuZ4d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck_kxZ4WEAAeOxO.jpg",
      "id_str" : "743064000951357440",
      "id" : 743064000951357440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck_kxZ4WEAAeOxO.jpg",
      "sizes" : [ {
        "h" : 673,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/BNiR2JuZ4d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Tf7Ehxh3Vn",
      "expanded_url" : "http:\/\/bit.ly\/1Uz59s7",
      "display_url" : "bit.ly\/1Uz59s7"
    } ]
  },
  "geo" : { },
  "id_str" : "743080106034335744",
  "text" : "RT @fayobserver: Orlando authorities search for boy dragged into water by gator https:\/\/t.co\/Tf7Ehxh3Vn https:\/\/t.co\/BNiR2JuZ4d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fayobserver\/status\/743068064468455424\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/BNiR2JuZ4d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck_kxZ4WEAAeOxO.jpg",
        "id_str" : "743064000951357440",
        "id" : 743064000951357440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck_kxZ4WEAAeOxO.jpg",
        "sizes" : [ {
          "h" : 673,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/BNiR2JuZ4d"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/Tf7Ehxh3Vn",
        "expanded_url" : "http:\/\/bit.ly\/1Uz59s7",
        "display_url" : "bit.ly\/1Uz59s7"
      } ]
    },
    "geo" : { },
    "id_str" : "743068064468455424",
    "text" : "Orlando authorities search for boy dragged into water by gator https:\/\/t.co\/Tf7Ehxh3Vn https:\/\/t.co\/BNiR2JuZ4d",
    "id" : 743068064468455424,
    "created_at" : "2016-06-15 13:10:06 +0000",
    "user" : {
      "name" : "FayObserver.com",
      "screen_name" : "fayobserver",
      "protected" : false,
      "id_str" : "13210422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735234152761561088\/t2_dzvDQ_normal.jpg",
      "id" : 13210422,
      "verified" : false
    }
  },
  "id" : 743080106034335744,
  "created_at" : "2016-06-15 13:57:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDE36",
      "screen_name" : "case_face",
      "indices" : [ 3, 13 ],
      "id_str" : "16166177",
      "id" : 16166177
    }, {
      "name" : "Jared Yates Sexton",
      "screen_name" : "JYSexton",
      "indices" : [ 16, 25 ],
      "id_str" : "325385270",
      "id" : 325385270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/WI9NaTZltc",
      "expanded_url" : "https:\/\/storify.com\/case_face\/a-trump-rally-in-greensboro-anger-in-here-is-palpa",
      "display_url" : "storify.com\/case_face\/a-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743078022899769344",
  "text" : "RT @case_face: .@JYSexton attended the Trmp event in Greensboro tonight and it is horrifying.\nI storify'd it here:\nhttps:\/\/t.co\/WI9NaTZltc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Yates Sexton",
        "screen_name" : "JYSexton",
        "indices" : [ 1, 10 ],
        "id_str" : "325385270",
        "id" : 325385270
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/WI9NaTZltc",
        "expanded_url" : "https:\/\/storify.com\/case_face\/a-trump-rally-in-greensboro-anger-in-here-is-palpa",
        "display_url" : "storify.com\/case_face\/a-tr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742890971679969280",
    "text" : ".@JYSexton attended the Trmp event in Greensboro tonight and it is horrifying.\nI storify'd it here:\nhttps:\/\/t.co\/WI9NaTZltc",
    "id" : 742890971679969280,
    "created_at" : "2016-06-15 01:26:24 +0000",
    "user" : {
      "name" : "\uD83D\uDE36",
      "screen_name" : "case_face",
      "protected" : false,
      "id_str" : "16166177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791346039085158400\/v691HWlY_normal.jpg",
      "id" : 16166177,
      "verified" : false
    }
  },
  "id" : 743078022899769344,
  "created_at" : "2016-06-15 13:49:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Yates Sexton",
      "screen_name" : "JYSexton",
      "indices" : [ 3, 12 ],
      "id_str" : "325385270",
      "id" : 325385270
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JYSexton\/status\/742501971127590914\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/QSd2VhuSK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck3lkQhWYAEhZ7A.jpg",
      "id_str" : "742501924658896897",
      "id" : 742501924658896897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck3lkQhWYAEhZ7A.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/QSd2VhuSK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743077692803809280",
  "text" : "RT @JYSexton: Seems like a reasonable place to nap. https:\/\/t.co\/QSd2VhuSK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JYSexton\/status\/742501971127590914\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/QSd2VhuSK1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck3lkQhWYAEhZ7A.jpg",
        "id_str" : "742501924658896897",
        "id" : 742501924658896897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck3lkQhWYAEhZ7A.jpg",
        "sizes" : [ {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/QSd2VhuSK1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742501971127590914",
    "text" : "Seems like a reasonable place to nap. https:\/\/t.co\/QSd2VhuSK1",
    "id" : 742501971127590914,
    "created_at" : "2016-06-13 23:40:39 +0000",
    "user" : {
      "name" : "Jared Yates Sexton",
      "screen_name" : "JYSexton",
      "protected" : false,
      "id_str" : "325385270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559044780848459778\/l9wuoKNh_normal.jpeg",
      "id" : 325385270,
      "verified" : true
    }
  },
  "id" : 743077692803809280,
  "created_at" : "2016-06-15 13:48:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abdul \uD83D\uDE80",
      "screen_name" : "Advil",
      "indices" : [ 3, 9 ],
      "id_str" : "14417243",
      "id" : 14417243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ymEVVFKmvd",
      "expanded_url" : "http:\/\/www.eso.org\/public\/images\/potw1624a\/",
      "display_url" : "eso.org\/public\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742887054187593728",
  "text" : "RT @Advil: source of the image : https:\/\/t.co\/ymEVVFKmvd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/ymEVVFKmvd",
        "expanded_url" : "http:\/\/www.eso.org\/public\/images\/potw1624a\/",
        "display_url" : "eso.org\/public\/images\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "742883856584413185",
    "geo" : { },
    "id_str" : "742886089346699264",
    "in_reply_to_user_id" : 14417243,
    "text" : "source of the image : https:\/\/t.co\/ymEVVFKmvd",
    "id" : 742886089346699264,
    "in_reply_to_status_id" : 742883856584413185,
    "created_at" : "2016-06-15 01:07:00 +0000",
    "in_reply_to_screen_name" : "Advil",
    "in_reply_to_user_id_str" : "14417243",
    "user" : {
      "name" : "abdul \uD83D\uDE80",
      "screen_name" : "Advil",
      "protected" : false,
      "id_str" : "14417243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793286827889266694\/mDWDIM1Q_normal.jpg",
      "id" : 14417243,
      "verified" : true
    }
  },
  "id" : 742887054187593728,
  "created_at" : "2016-06-15 01:10:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Falin",
      "screen_name" : "ClintFalin",
      "indices" : [ 3, 14 ],
      "id_str" : "390396654",
      "id" : 390396654
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ClintFalin\/status\/742768118901145600\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/yQ6t8bxU0X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7XqVcWYAQFnO3.jpg",
      "id_str" : "742768110873239556",
      "id" : 742768110873239556,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7XqVcWYAQFnO3.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/yQ6t8bxU0X"
    } ],
    "hashtags" : [ {
      "text" : "LoveIsLove",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742849917333450752",
  "text" : "RT @ClintFalin: We're never gonna beat Canada.\n\nBaby moose spotted with pride flag.\n\n#LoveIsLove https:\/\/t.co\/yQ6t8bxU0X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ClintFalin\/status\/742768118901145600\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/yQ6t8bxU0X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7XqVcWYAQFnO3.jpg",
        "id_str" : "742768110873239556",
        "id" : 742768110873239556,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7XqVcWYAQFnO3.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/yQ6t8bxU0X"
      } ],
      "hashtags" : [ {
        "text" : "LoveIsLove",
        "indices" : [ 69, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742768118901145600",
    "text" : "We're never gonna beat Canada.\n\nBaby moose spotted with pride flag.\n\n#LoveIsLove https:\/\/t.co\/yQ6t8bxU0X",
    "id" : 742768118901145600,
    "created_at" : "2016-06-14 17:18:14 +0000",
    "user" : {
      "name" : "Clint Falin",
      "screen_name" : "ClintFalin",
      "protected" : false,
      "id_str" : "390396654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798419214998601728\/zFg8iC1M_normal.jpg",
      "id" : 390396654,
      "verified" : false
    }
  },
  "id" : 742849917333450752,
  "created_at" : "2016-06-14 22:43:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0d9u2VdCx6",
      "expanded_url" : "http:\/\/wapo.st\/1U4LkJt",
      "display_url" : "wapo.st\/1U4LkJt"
    } ]
  },
  "geo" : { },
  "id_str" : "742515762313695232",
  "text" : "RT @washingtonpost: \"Donald Trump just banned the Washington Post from covering him. That should bother everyone.\" https:\/\/t.co\/0d9u2VdCx6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Cillizza",
        "screen_name" : "TheFix",
        "indices" : [ 123, 130 ],
        "id_str" : "14412533",
        "id" : 14412533
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/0d9u2VdCx6",
        "expanded_url" : "http:\/\/wapo.st\/1U4LkJt",
        "display_url" : "wapo.st\/1U4LkJt"
      } ]
    },
    "geo" : { },
    "id_str" : "742495779865165824",
    "text" : "\"Donald Trump just banned the Washington Post from covering him. That should bother everyone.\" https:\/\/t.co\/0d9u2VdCx6 via @TheFix",
    "id" : 742495779865165824,
    "created_at" : "2016-06-13 23:16:03 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753656134565785600\/iQ1GX-ov_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 742515762313695232,
  "created_at" : "2016-06-14 00:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. K. Young",
      "screen_name" : "nativebackyard",
      "indices" : [ 3, 18 ],
      "id_str" : "225143784",
      "id" : 225143784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/hoSl67FtGS",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/world-europe-36475672",
      "display_url" : "bbc.com\/news\/world-eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742507625686966272",
  "text" : "RT @nativebackyard: Monique, the hen who is sailing around the world - BBC News https:\/\/t.co\/hoSl67FtGS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/hoSl67FtGS",
        "expanded_url" : "http:\/\/www.bbc.com\/news\/world-europe-36475672",
        "display_url" : "bbc.com\/news\/world-eur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742503408909877249",
    "text" : "Monique, the hen who is sailing around the world - BBC News https:\/\/t.co\/hoSl67FtGS",
    "id" : 742503408909877249,
    "created_at" : "2016-06-13 23:46:22 +0000",
    "user" : {
      "name" : "R. K. Young",
      "screen_name" : "nativebackyard",
      "protected" : false,
      "id_str" : "225143784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3686231189\/b60f64d1bf01f0aba898694bc2d6e113_normal.jpeg",
      "id" : 225143784,
      "verified" : false
    }
  },
  "id" : 742507625686966272,
  "created_at" : "2016-06-14 00:03:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742472716142432260",
  "text" : "RT @JeremyCShipp: So Trump \"revoked\" the Washington Post's press credentials? That's not how it works. America isn't a dictatorship, yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742471670145777665",
    "text" : "So Trump \"revoked\" the Washington Post's press credentials? That's not how it works. America isn't a dictatorship, yet.",
    "id" : 742471670145777665,
    "created_at" : "2016-06-13 21:40:15 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 742472716142432260,
  "created_at" : "2016-06-13 21:44:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "indices" : [ 3, 18 ],
      "id_str" : "46822887",
      "id" : 46822887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742472493483626497",
  "text" : "RT @AngryBlackLady: I don't want people not to see me as a Black woman; I want people to see me as a Black woman and treat me like a human\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "742470051530452992",
    "geo" : { },
    "id_str" : "742470257265287168",
    "in_reply_to_user_id" : 46822887,
    "text" : "I don't want people not to see me as a Black woman; I want people to see me as a Black woman and treat me like a human regardless.",
    "id" : 742470257265287168,
    "in_reply_to_status_id" : 742470051530452992,
    "created_at" : "2016-06-13 21:34:38 +0000",
    "in_reply_to_screen_name" : "AngryBlackLady",
    "in_reply_to_user_id_str" : "46822887",
    "user" : {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "protected" : false,
      "id_str" : "46822887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790644001330171904\/E3uUevS__normal.jpg",
      "id" : 46822887,
      "verified" : true
    }
  },
  "id" : 742472493483626497,
  "created_at" : "2016-06-13 21:43:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hurt Blogger | Britt",
      "screen_name" : "HurtBlogger",
      "indices" : [ 3, 15 ],
      "id_str" : "377037698",
      "id" : 377037698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotWorking",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742472415004004353",
  "text" : "RT @HurtBlogger: This change in my pain med plan has me wanting to gnaw my shoulders\/elbows\/wrists\/knees\/hell... all of it OFF. #NotWorking",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NotWorking",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742471495000023041",
    "text" : "This change in my pain med plan has me wanting to gnaw my shoulders\/elbows\/wrists\/knees\/hell... all of it OFF. #NotWorking",
    "id" : 742471495000023041,
    "created_at" : "2016-06-13 21:39:33 +0000",
    "user" : {
      "name" : "Hurt Blogger | Britt",
      "screen_name" : "HurtBlogger",
      "protected" : false,
      "id_str" : "377037698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727960370875228160\/YV3NivJK_normal.jpg",
      "id" : 377037698,
      "verified" : false
    }
  },
  "id" : 742472415004004353,
  "created_at" : "2016-06-13 21:43:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742434400063868928",
  "text" : "RT @BrianRathbone: If life is a dance, mine is the funky chicken.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742433446685990912",
    "text" : "If life is a dance, mine is the funky chicken.",
    "id" : 742433446685990912,
    "created_at" : "2016-06-13 19:08:22 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 742434400063868928,
  "created_at" : "2016-06-13 19:12:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 84, 98 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/K14ti8V9oW",
      "expanded_url" : "https:\/\/shar.es\/1JYW4q",
      "display_url" : "shar.es\/1JYW4q"
    } ]
  },
  "geo" : { },
  "id_str" : "742432346591404036",
  "text" : "\u201CBut that\u2019s what the Bible says about hell.\u201D Stop that! https:\/\/t.co\/K14ti8V9oW via @UnfundieXians",
  "id" : 742432346591404036,
  "created_at" : "2016-06-13 19:03:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fightforthegood",
      "indices" : [ 116, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742386793962733568",
  "text" : "RT @yssirhchrissy: The hate in the world seems insurmountable today, seeping from every corner. We must remember to #fightforthegood https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/yssirhchrissy\/status\/742167341711101952\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/hEMu4U6anO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cky1QwFXAAAPEF3.jpg",
        "id_str" : "742167337999204352",
        "id" : 742167337999204352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cky1QwFXAAAPEF3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 823
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 823
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 823
        } ],
        "display_url" : "pic.twitter.com\/hEMu4U6anO"
      } ],
      "hashtags" : [ {
        "text" : "fightforthegood",
        "indices" : [ 97, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742167341711101952",
    "text" : "The hate in the world seems insurmountable today, seeping from every corner. We must remember to #fightforthegood https:\/\/t.co\/hEMu4U6anO",
    "id" : 742167341711101952,
    "created_at" : "2016-06-13 01:30:57 +0000",
    "user" : {
      "name" : "Christina Fritts",
      "screen_name" : "cm_fritts",
      "protected" : false,
      "id_str" : "4857778713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793612914867462146\/RbQATwyZ_normal.jpg",
      "id" : 4857778713,
      "verified" : false
    }
  },
  "id" : 742386793962733568,
  "created_at" : "2016-06-13 16:02:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 0, 9 ],
      "id_str" : "352053266",
      "id" : 352053266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742378790026936320",
  "in_reply_to_user_id" : 352053266,
  "text" : "@coursera need a wishlist within Coursera so I can keep list of courses I'm interested in rather than bookmarking them. thx.",
  "id" : 742378790026936320,
  "created_at" : "2016-06-13 15:31:10 +0000",
  "in_reply_to_screen_name" : "coursera",
  "in_reply_to_user_id_str" : "352053266",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Collective Evolution",
      "screen_name" : "CollectiveEvol",
      "indices" : [ 85, 100 ],
      "id_str" : "57241134",
      "id" : 57241134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/7wxPZRXemX",
      "expanded_url" : "http:\/\/www.collective-evolution.com\/2016\/06\/11\/suicide-attempt-by-seaworld-orca-shocks-tourists-video\/",
      "display_url" : "collective-evolution.com\/2016\/06\/11\/sui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742361950601019392",
  "text" : "Suicide Attempt By Seaworld Orca Shocks Tourists (VIDEO) https:\/\/t.co\/7wxPZRXemX via @collectiveevol",
  "id" : 742361950601019392,
  "created_at" : "2016-06-13 14:24:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dessy Levinson",
      "screen_name" : "whyiwatch",
      "indices" : [ 3, 13 ],
      "id_str" : "80671883",
      "id" : 80671883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742158175030419457",
  "text" : "RT @whyiwatch: So saddened by the violence. We are capable of so much beauty, yet fear negates potential &amp; reduces us to hate. Fight back!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742152157340815360",
    "text" : "So saddened by the violence. We are capable of so much beauty, yet fear negates potential &amp; reduces us to hate. Fight back! Love is power.",
    "id" : 742152157340815360,
    "created_at" : "2016-06-13 00:30:37 +0000",
    "user" : {
      "name" : "Dessy Levinson",
      "screen_name" : "whyiwatch",
      "protected" : false,
      "id_str" : "80671883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1254904271\/whyiwatch_normal.jpg",
      "id" : 80671883,
      "verified" : false
    }
  },
  "id" : 742158175030419457,
  "created_at" : "2016-06-13 00:54:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/nDcyE6GyQN",
      "expanded_url" : "https:\/\/twitter.com\/SammyAJackson\/status\/741621644939034626",
      "display_url" : "twitter.com\/SammyAJackson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742009111538216960",
  "text" : "want non-apple version of this for #audiobooks , music, podcasts. w bookmarking, buttons (play,pause,next,prev,vol) https:\/\/t.co\/nDcyE6GyQN",
  "id" : 742009111538216960,
  "created_at" : "2016-06-12 15:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742007033461932032",
  "text" : "we have been conditioned by the powerful to live in fear so we can be controlled. to stop the fear.. stop feeding it.",
  "id" : 742007033461932032,
  "created_at" : "2016-06-12 14:53:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leyla \u2744\uFE0F",
      "screen_name" : "GrumpyLeyla",
      "indices" : [ 3, 15 ],
      "id_str" : "254658807",
      "id" : 254658807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GrumpyLeyla\/status\/741973593811255300\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/JCgaZIifFC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkwFCREWgAAJpGb.jpg",
      "id_str" : "741973575108820992",
      "id" : 741973575108820992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkwFCREWgAAJpGb.jpg",
      "sizes" : [ {
        "h" : 998,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 998,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 433
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 998,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/JCgaZIifFC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742005364443512832",
  "text" : "RT @GrumpyLeyla: saY IT LOUDER FOR THE PEOPLE IN THE BACK https:\/\/t.co\/JCgaZIifFC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GrumpyLeyla\/status\/741973593811255300\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/JCgaZIifFC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkwFCREWgAAJpGb.jpg",
        "id_str" : "741973575108820992",
        "id" : 741973575108820992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkwFCREWgAAJpGb.jpg",
        "sizes" : [ {
          "h" : 998,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/JCgaZIifFC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741973593811255300",
    "text" : "saY IT LOUDER FOR THE PEOPLE IN THE BACK https:\/\/t.co\/JCgaZIifFC",
    "id" : 741973593811255300,
    "created_at" : "2016-06-12 12:41:04 +0000",
    "user" : {
      "name" : "Leyla \u2744\uFE0F",
      "screen_name" : "GrumpyLeyla",
      "protected" : false,
      "id_str" : "254658807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776413746646413312\/D_IKAooi_normal.jpg",
      "id" : 254658807,
      "verified" : false
    }
  },
  "id" : 742005364443512832,
  "created_at" : "2016-06-12 14:47:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/JZ1Q1SrQ35",
      "expanded_url" : "https:\/\/igg.me\/at\/onebyonedvd\/x",
      "display_url" : "igg.me\/at\/onebyonedvd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741793691103334400",
  "text" : "just watched One By One (Rik Mayall) \"question everything\" \"wake up now\" https:\/\/t.co\/JZ1Q1SrQ35",
  "id" : 741793691103334400,
  "created_at" : "2016-06-12 00:46:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Bible",
      "screen_name" : "ohholybible",
      "indices" : [ 3, 15 ],
      "id_str" : "524460502",
      "id" : 524460502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741792176326246400",
  "text" : "RT @ohholybible: For everyone who asks receives; those who seek find; and to those who knock, the door will be opened. -Matthew 7:8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741782799745572864",
    "text" : "For everyone who asks receives; those who seek find; and to those who knock, the door will be opened. -Matthew 7:8",
    "id" : 741782799745572864,
    "created_at" : "2016-06-12 00:02:55 +0000",
    "user" : {
      "name" : "Holy Bible",
      "screen_name" : "ohholybible",
      "protected" : false,
      "id_str" : "524460502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436660006360870913\/jm550BsN_normal.jpeg",
      "id" : 524460502,
      "verified" : false
    }
  },
  "id" : 741792176326246400,
  "created_at" : "2016-06-12 00:40:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah Austin",
      "screen_name" : "DebsSweet",
      "indices" : [ 3, 13 ],
      "id_str" : "19102093",
      "id" : 19102093
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DebsSweet\/status\/741755703858241537\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/5UR5eYyHRW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cks-3y3UkAQKJsP.jpg",
      "id_str" : "741755691900112900",
      "id" : 741755691900112900,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cks-3y3UkAQKJsP.jpg",
      "sizes" : [ {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      } ],
      "display_url" : "pic.twitter.com\/5UR5eYyHRW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741768522347499520",
  "text" : "RT @DebsSweet: Dogs are angels...... https:\/\/t.co\/5UR5eYyHRW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DebsSweet\/status\/741755703858241537\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/5UR5eYyHRW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cks-3y3UkAQKJsP.jpg",
        "id_str" : "741755691900112900",
        "id" : 741755691900112900,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cks-3y3UkAQKJsP.jpg",
        "sizes" : [ {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        } ],
        "display_url" : "pic.twitter.com\/5UR5eYyHRW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741755703858241537",
    "text" : "Dogs are angels...... https:\/\/t.co\/5UR5eYyHRW",
    "id" : 741755703858241537,
    "created_at" : "2016-06-11 22:15:15 +0000",
    "user" : {
      "name" : "Deborah Austin",
      "screen_name" : "DebsSweet",
      "protected" : false,
      "id_str" : "19102093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630893753104859136\/QaKQGzft_normal.jpg",
      "id" : 19102093,
      "verified" : false
    }
  },
  "id" : 741768522347499520,
  "created_at" : "2016-06-11 23:06:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logical Analysis",
      "screen_name" : "LogicalAnalysis",
      "indices" : [ 3, 19 ],
      "id_str" : "138509803",
      "id" : 138509803
    }, {
      "name" : "The Telegraph",
      "screen_name" : "Telegraph",
      "indices" : [ 91, 101 ],
      "id_str" : "16343974",
      "id" : 16343974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ltQYYHIU6a",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/culture\/9475585\/Searching-for-Grigori-Perelman-Russias-reclusive-maths-genius.html",
      "display_url" : "telegraph.co.uk\/culture\/947558\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741758114702233600",
  "text" : "RT @LogicalAnalysis: Searching for Grigori Perelman, Russia\u2019s reclusive maths genius | via @Telegraph https:\/\/t.co\/ltQYYHIU6a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Telegraph",
        "screen_name" : "Telegraph",
        "indices" : [ 70, 80 ],
        "id_str" : "16343974",
        "id" : 16343974
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ltQYYHIU6a",
        "expanded_url" : "http:\/\/www.telegraph.co.uk\/culture\/9475585\/Searching-for-Grigori-Perelman-Russias-reclusive-maths-genius.html",
        "display_url" : "telegraph.co.uk\/culture\/947558\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "741754637414342656",
    "text" : "Searching for Grigori Perelman, Russia\u2019s reclusive maths genius | via @Telegraph https:\/\/t.co\/ltQYYHIU6a",
    "id" : 741754637414342656,
    "created_at" : "2016-06-11 22:11:01 +0000",
    "user" : {
      "name" : "Logical Analysis",
      "screen_name" : "LogicalAnalysis",
      "protected" : false,
      "id_str" : "138509803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792250209136812032\/6c2qUyu8_normal.jpg",
      "id" : 138509803,
      "verified" : false
    }
  },
  "id" : 741758114702233600,
  "created_at" : "2016-06-11 22:24:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mic",
      "screen_name" : "mic",
      "indices" : [ 3, 7 ],
      "id_str" : "139909832",
      "id" : 139909832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/YamQEsiKjt",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/cdf2c763-83fe-402d-95da-add4b3a3c842",
      "display_url" : "amp.twimg.com\/v\/cdf2c763-83f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741749805660180481",
  "text" : "RT @mic: This is what happened after a Yale-bound valedictorian in Texas revealed she is an undocumented immigrant:\nhttps:\/\/t.co\/YamQEsiKjt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/YamQEsiKjt",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/cdf2c763-83fe-402d-95da-add4b3a3c842",
        "display_url" : "amp.twimg.com\/v\/cdf2c763-83f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740929938715475969",
    "text" : "This is what happened after a Yale-bound valedictorian in Texas revealed she is an undocumented immigrant:\nhttps:\/\/t.co\/YamQEsiKjt",
    "id" : 740929938715475969,
    "created_at" : "2016-06-09 15:33:57 +0000",
    "user" : {
      "name" : "Mic",
      "screen_name" : "mic",
      "protected" : false,
      "id_str" : "139909832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800724913648603140\/M7di-DhA_normal.jpg",
      "id" : 139909832,
      "verified" : true
    }
  },
  "id" : 741749805660180481,
  "created_at" : "2016-06-11 21:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3tags",
      "screen_name" : "3tags_org",
      "indices" : [ 3, 13 ],
      "id_str" : "2862375177",
      "id" : 2862375177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "archeology",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "history",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/dt0DQUqls1",
      "expanded_url" : "http:\/\/flip.it\/f0KnL",
      "display_url" : "flip.it\/f0KnL"
    } ]
  },
  "geo" : { },
  "id_str" : "741736424991526912",
  "text" : "RT @3tags_org: New DNA Study Shows Humans Bred With Unknown Species https:\/\/t.co\/dt0DQUqls1  #science #archeology #history https:\/\/t.co\/giZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/3tags_org\/status\/739256706312474624\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/giZFlRm3Ix",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkJD_XTWYAAI9Vs.jpg",
        "id_str" : "739228044708175872",
        "id" : 739228044708175872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkJD_XTWYAAI9Vs.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/giZFlRm3Ix"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "archeology",
        "indices" : [ 87, 98 ]
      }, {
        "text" : "history",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/dt0DQUqls1",
        "expanded_url" : "http:\/\/flip.it\/f0KnL",
        "display_url" : "flip.it\/f0KnL"
      } ]
    },
    "geo" : { },
    "id_str" : "739256706312474624",
    "text" : "New DNA Study Shows Humans Bred With Unknown Species https:\/\/t.co\/dt0DQUqls1  #science #archeology #history https:\/\/t.co\/giZFlRm3Ix",
    "id" : 739256706312474624,
    "created_at" : "2016-06-05 00:45:08 +0000",
    "user" : {
      "name" : "3tags",
      "screen_name" : "3tags_org",
      "protected" : false,
      "id_str" : "2862375177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611563696024875008\/GLwO7Qq-_normal.png",
      "id" : 2862375177,
      "verified" : false
    }
  },
  "id" : 741736424991526912,
  "created_at" : "2016-06-11 20:58:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/741035848372785152\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/aKQaj8JPZo",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ckit5m1WkAEHThq.jpg",
      "id_str" : "741033343890919425",
      "id" : 741033343890919425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ckit5m1WkAEHThq.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 378
      } ],
      "display_url" : "pic.twitter.com\/aKQaj8JPZo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741657979972399104",
  "text" : "RT @StarStuff42: Our Solar System in Action (all this going around milky way which is traveling through space) https:\/\/t.co\/aKQaj8JPZo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/741035848372785152\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/aKQaj8JPZo",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ckit5m1WkAEHThq.jpg",
        "id_str" : "741033343890919425",
        "id" : 741033343890919425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ckit5m1WkAEHThq.jpg",
        "sizes" : [ {
          "h" : 372,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 378
        } ],
        "display_url" : "pic.twitter.com\/aKQaj8JPZo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741035848372785152",
    "text" : "Our Solar System in Action (all this going around milky way which is traveling through space) https:\/\/t.co\/aKQaj8JPZo",
    "id" : 741035848372785152,
    "created_at" : "2016-06-09 22:34:48 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 741657979972399104,
  "created_at" : "2016-06-11 15:46:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741657756864786432",
  "text" : "trying to find hours worked app but they all want specific times. DH tracks hours for workers and creates invoices manually.",
  "id" : 741657756864786432,
  "created_at" : "2016-06-11 15:46:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifeandstuff",
      "indices" : [ 43, 56 ]
    }, {
      "text" : "feedly",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "chickens",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/6jmAJT8IHn",
      "expanded_url" : "http:\/\/thedancingdonkey.blogspot.com\/2016\/06\/dont-get-attached.html",
      "display_url" : "thedancingdonkey.blogspot.com\/2016\/06\/dont-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741645866902147072",
  "text" : "Don't Get Attached https:\/\/t.co\/6jmAJT8IHn #lifeandstuff #feedly #chickens",
  "id" : 741645866902147072,
  "created_at" : "2016-06-11 14:58:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StackSocial",
      "screen_name" : "StackSocial",
      "indices" : [ 92, 104 ],
      "id_str" : "243742269",
      "id" : 243742269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Cb2izZzG3F",
      "expanded_url" : "https:\/\/stacksocial.com\/giveaways\/the-10-years-of-netflix-giveaway?gid=1070557",
      "display_url" : "stacksocial.com\/giveaways\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741623308043616257",
  "text" : "The Netflix 10-Year Premium Subscription Giveaway | StackSocial https:\/\/t.co\/Cb2izZzG3F via @StackSocial",
  "id" : 741623308043616257,
  "created_at" : "2016-06-11 13:29:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741404000667480064",
  "text" : "RT @Nigelstewart76: Just been out and checked this we fella he's fine in the bushes all fluffed up sleeping safe for the night \uD83D\uDC4D https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/741382469165932545\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/W0Wk1tCd5A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CknradqWsAA1U0F.jpg",
        "id_str" : "741382453550559232",
        "id" : 741382453550559232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknradqWsAA1U0F.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/W0Wk1tCd5A"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741382469165932545",
    "text" : "Just been out and checked this we fella he's fine in the bushes all fluffed up sleeping safe for the night \uD83D\uDC4D https:\/\/t.co\/W0Wk1tCd5A",
    "id" : 741382469165932545,
    "created_at" : "2016-06-10 21:32:09 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 741404000667480064,
  "created_at" : "2016-06-10 22:57:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soni\u01B8\u0335\u0321\u04DC\u0335\u0328\u0304\u01B7",
      "screen_name" : "theredpillpusha",
      "indices" : [ 3, 19 ],
      "id_str" : "22614274",
      "id" : 22614274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741305593902829569",
  "text" : "RT @theredpillpusha: Adulting is a horrible scam....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741087209240035328",
    "text" : "Adulting is a horrible scam....",
    "id" : 741087209240035328,
    "created_at" : "2016-06-10 01:58:54 +0000",
    "user" : {
      "name" : "Soni\u01B8\u0335\u0321\u04DC\u0335\u0328\u0304\u01B7",
      "screen_name" : "theredpillpusha",
      "protected" : false,
      "id_str" : "22614274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763372248879292417\/wNiNBkL6_normal.jpg",
      "id" : 22614274,
      "verified" : false
    }
  },
  "id" : 741305593902829569,
  "created_at" : "2016-06-10 16:26:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wisdom",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "truth",
      "indices" : [ 8, 14 ]
    }, {
      "text" : "youhavethepower",
      "indices" : [ 15, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/ba6NlDvKmU",
      "expanded_url" : "https:\/\/twitter.com\/bend_time\/status\/741278074306760706",
      "display_url" : "twitter.com\/bend_time\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741297942334722048",
  "text" : "#wisdom #truth #youhavethepower https:\/\/t.co\/ba6NlDvKmU",
  "id" : 741297942334722048,
  "created_at" : "2016-06-10 15:56:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741278074306760706",
  "geo" : { },
  "id_str" : "741297712474251264",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time \"If your story keeps you playing small, then it\u2019s time to decide to tell a different version.\"",
  "id" : 741297712474251264,
  "in_reply_to_status_id" : 741278074306760706,
  "created_at" : "2016-06-10 15:55:21 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741276653956026368",
  "geo" : { },
  "id_str" : "741292628675792896",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe 9 DAYS?? Get to the Hospital, STAT!!",
  "id" : 741292628675792896,
  "in_reply_to_status_id" : 741276653956026368,
  "created_at" : "2016-06-10 15:35:09 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abraham",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "loa",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "quote",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/NBGht9q0Wj",
      "expanded_url" : "https:\/\/moosebegab.wordpress.com\/2016\/06\/10\/818\/",
      "display_url" : "moosebegab.wordpress.com\/2016\/06\/10\/818\/"
    } ]
  },
  "geo" : { },
  "id_str" : "741287508592472064",
  "text" : "pondering my emotions https:\/\/t.co\/NBGht9q0Wj #abraham-hicks #loa #quote",
  "id" : 741287508592472064,
  "created_at" : "2016-06-10 15:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 84, 99 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/tUxIODIXy4",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/06\/preachers-put-fear-god-church-attendees\/",
      "display_url" : "brucegerencser.net\/2016\/06\/preach\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741269732771430400",
  "text" : "How Preachers Put the Fear of God into Church Attendees https:\/\/t.co\/tUxIODIXy4 via @BruceGerencser",
  "id" : 741269732771430400,
  "created_at" : "2016-06-10 14:04:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ZLt2PgShmx",
      "expanded_url" : "http:\/\/bookwi.se\/fear-of-physics\/",
      "display_url" : "bookwi.se\/fear-of-physic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741264640320102400",
  "text" : "RT @adamrshields: Book Review: Fear of Physics: A Guide for the Perplexed by Lawrence Krauss https:\/\/t.co\/ZLt2PgShmx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/ZLt2PgShmx",
        "expanded_url" : "http:\/\/bookwi.se\/fear-of-physics\/",
        "display_url" : "bookwi.se\/fear-of-physic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "741249320872083458",
    "text" : "Book Review: Fear of Physics: A Guide for the Perplexed by Lawrence Krauss https:\/\/t.co\/ZLt2PgShmx",
    "id" : 741249320872083458,
    "created_at" : "2016-06-10 12:43:04 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 741264640320102400,
  "created_at" : "2016-06-10 13:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3093\u3002\u9CE5\u57A2",
      "screen_name" : "rereren925",
      "indices" : [ 3, 14 ],
      "id_str" : "730276487878742016",
      "id" : 730276487878742016
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rereren925\/status\/740826632479444992\/video\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/pHIrSEtBYO",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740826569673936896\/pu\/img\/L_26N0aF8YHE5_Cs.jpg",
      "id_str" : "740826569673936896",
      "id" : 740826569673936896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740826569673936896\/pu\/img\/L_26N0aF8YHE5_Cs.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pHIrSEtBYO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741024875310112768",
  "text" : "RT @rereren925: \u30DD\u30C3\u30DD\u304C\u512A\u3057\u3044\u4E8B\u3092\u3044\u3044\u4E8B\u306B\u5927\u80C6\u306B\u306A\u3063\u3066\u3044\u304F\u9EC4\u8272\u3044\u3084\u3064\u3002 https:\/\/t.co\/pHIrSEtBYO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rereren925\/status\/740826632479444992\/video\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/pHIrSEtBYO",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740826569673936896\/pu\/img\/L_26N0aF8YHE5_Cs.jpg",
        "id_str" : "740826569673936896",
        "id" : 740826569673936896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740826569673936896\/pu\/img\/L_26N0aF8YHE5_Cs.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pHIrSEtBYO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740826632479444992",
    "text" : "\u30DD\u30C3\u30DD\u304C\u512A\u3057\u3044\u4E8B\u3092\u3044\u3044\u4E8B\u306B\u5927\u80C6\u306B\u306A\u3063\u3066\u3044\u304F\u9EC4\u8272\u3044\u3084\u3064\u3002 https:\/\/t.co\/pHIrSEtBYO",
    "id" : 740826632479444992,
    "created_at" : "2016-06-09 08:43:27 +0000",
    "user" : {
      "name" : "\u308C\u3093\u3002\u9CE5\u57A2",
      "screen_name" : "rereren925",
      "protected" : false,
      "id_str" : "730276487878742016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779255474952646656\/FvLabmIf_normal.jpg",
      "id" : 730276487878742016,
      "verified" : false
    }
  },
  "id" : 741024875310112768,
  "created_at" : "2016-06-09 21:51:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Heroys Artist",
      "screen_name" : "JoseHeroys",
      "indices" : [ 3, 14 ],
      "id_str" : "3577990937",
      "id" : 3577990937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "30dayswild",
      "indices" : [ 106, 117 ]
    }, {
      "text" : "springwatch",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741008524717752320",
  "text" : "RT @JoseHeroys: Mobbing alarm calls during this shoot - local birds thought my crochet magpie was real! \uD83D\uDE04 #30dayswild #springwatch https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoseHeroys\/status\/740985040377679872\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/lfdu5VFZRN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiB8MuWgAAtZLn.jpg",
        "id_str" : "740985009910218752",
        "id" : 740985009910218752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiB8MuWgAAtZLn.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/lfdu5VFZRN"
      } ],
      "hashtags" : [ {
        "text" : "30dayswild",
        "indices" : [ 90, 101 ]
      }, {
        "text" : "springwatch",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740985040377679872",
    "text" : "Mobbing alarm calls during this shoot - local birds thought my crochet magpie was real! \uD83D\uDE04 #30dayswild #springwatch https:\/\/t.co\/lfdu5VFZRN",
    "id" : 740985040377679872,
    "created_at" : "2016-06-09 19:12:55 +0000",
    "user" : {
      "name" : "Jose Heroys Artist",
      "screen_name" : "JoseHeroys",
      "protected" : false,
      "id_str" : "3577990937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640907744938168321\/X6Zm9Fhk_normal.jpg",
      "id" : 3577990937,
      "verified" : false
    }
  },
  "id" : 741008524717752320,
  "created_at" : "2016-06-09 20:46:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0391\u03C4\u03B7\u03B5\u03B9s\u03C4 \u0395ng\u03B9n\u03B5\u03B5r",
      "screen_name" : "AtheistEngineer",
      "indices" : [ 3, 19 ],
      "id_str" : "2707065429",
      "id" : 2707065429
    }, {
      "name" : "NIGELTEAPOT",
      "screen_name" : "NIGELTEAPOT",
      "indices" : [ 36, 48 ],
      "id_str" : "2820916967",
      "id" : 2820916967
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/f9r8birfzI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlklWUAAPPkm.jpg",
      "id_str" : "741005511898845184",
      "id" : 741005511898845184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlklWUAAPPkm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 468
      } ],
      "display_url" : "pic.twitter.com\/f9r8birfzI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/f9r8birfzI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlknWkAAPWwU.jpg",
      "id_str" : "741005511907250176",
      "id" : 741005511907250176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlknWkAAPWwU.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/f9r8birfzI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/f9r8birfzI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlloXIAArJ09.jpg",
      "id_str" : "741005512179916800",
      "id" : 741005512179916800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlloXIAArJ09.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/f9r8birfzI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/f9r8birfzI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlm-XIAEWSHc.jpg",
      "id_str" : "741005512540626945",
      "id" : 741005512540626945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlm-XIAEWSHc.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/f9r8birfzI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741008290470055936",
  "text" : "RT @AtheistEngineer: I'm in hell. \n\n@NIGELTEAPOT https:\/\/t.co\/f9r8birfzI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NIGELTEAPOT",
        "screen_name" : "NIGELTEAPOT",
        "indices" : [ 15, 27 ],
        "id_str" : "2820916967",
        "id" : 2820916967
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/f9r8birfzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlklWUAAPPkm.jpg",
        "id_str" : "741005511898845184",
        "id" : 741005511898845184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlklWUAAPPkm.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/f9r8birfzI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/f9r8birfzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlknWkAAPWwU.jpg",
        "id_str" : "741005511907250176",
        "id" : 741005511907250176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlknWkAAPWwU.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/f9r8birfzI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/f9r8birfzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlloXIAArJ09.jpg",
        "id_str" : "741005512179916800",
        "id" : 741005512179916800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlloXIAArJ09.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/f9r8birfzI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/741005526067228673\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/f9r8birfzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiUlm-XIAEWSHc.jpg",
        "id_str" : "741005512540626945",
        "id" : 741005512540626945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiUlm-XIAEWSHc.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/f9r8birfzI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "741002808552357888",
    "geo" : { },
    "id_str" : "741005526067228673",
    "in_reply_to_user_id" : 2820916967,
    "text" : "I'm in hell. \n\n@NIGELTEAPOT https:\/\/t.co\/f9r8birfzI",
    "id" : 741005526067228673,
    "in_reply_to_status_id" : 741002808552357888,
    "created_at" : "2016-06-09 20:34:19 +0000",
    "in_reply_to_screen_name" : "NIGELTEAPOT",
    "in_reply_to_user_id_str" : "2820916967",
    "user" : {
      "name" : "\u0391\u03C4\u03B7\u03B5\u03B9s\u03C4 \u0395ng\u03B9n\u03B5\u03B5r",
      "screen_name" : "AtheistEngineer",
      "protected" : false,
      "id_str" : "2707065429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795746275886936065\/EaCY4SoL_normal.jpg",
      "id" : 2707065429,
      "verified" : false
    }
  },
  "id" : 741008290470055936,
  "created_at" : "2016-06-09 20:45:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/c84wmDcmCP",
      "expanded_url" : "https:\/\/twitter.com\/DailyMailUK\/status\/740594017096851456",
      "display_url" : "twitter.com\/DailyMailUK\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741007667104260096",
  "text" : "Nudity FTW!! https:\/\/t.co\/c84wmDcmCP",
  "id" : 741007667104260096,
  "created_at" : "2016-06-09 20:42:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741007134972891137",
  "text" : "when DD really cries becuz news Hillary Clinton over Bernie. : ( DH, DD having deep political conversation.",
  "id" : 741007134972891137,
  "created_at" : "2016-06-09 20:40:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740988434920144896",
  "text" : "Don't worry. The Universe always has a Plan B.",
  "id" : 740988434920144896,
  "created_at" : "2016-06-09 19:26:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "indices" : [ 3, 19 ],
      "id_str" : "289118612",
      "id" : 289118612
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TomthunkitsMind\/status\/740885432196583424\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/82koj8RnZR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkgnX4aUoAIZA3r.jpg",
      "id_str" : "740885429935710210",
      "id" : 740885429935710210,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkgnX4aUoAIZA3r.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/82koj8RnZR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740987911601049601",
  "text" : "RT @TomthunkitsMind: Word Of The Day. https:\/\/t.co\/82koj8RnZR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TomthunkitsMind\/status\/740885432196583424\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/82koj8RnZR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkgnX4aUoAIZA3r.jpg",
        "id_str" : "740885429935710210",
        "id" : 740885429935710210,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkgnX4aUoAIZA3r.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/82koj8RnZR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740885432196583424",
    "text" : "Word Of The Day. https:\/\/t.co\/82koj8RnZR",
    "id" : 740885432196583424,
    "created_at" : "2016-06-09 12:37:06 +0000",
    "user" : {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "protected" : false,
      "id_str" : "289118612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720292487898783746\/B736BdgO_normal.jpg",
      "id" : 289118612,
      "verified" : false
    }
  },
  "id" : 740987911601049601,
  "created_at" : "2016-06-09 19:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/716726991861506049\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/QAfarbiKYe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJTZrFUsAAjabW.jpg",
      "id_str" : "716726991232217088",
      "id" : 716726991232217088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJTZrFUsAAjabW.jpg",
      "sizes" : [ {
        "h" : 215,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/QAfarbiKYe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740915162350243840",
  "text" : "RT @StarStuff42: The entire Universe is to the observable Universe as the observable Universe is to an atom. https:\/\/t.co\/QAfarbiKYe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/716726991861506049\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/QAfarbiKYe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJTZrFUsAAjabW.jpg",
        "id_str" : "716726991232217088",
        "id" : 716726991232217088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJTZrFUsAAjabW.jpg",
        "sizes" : [ {
          "h" : 215,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/QAfarbiKYe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716726991861506049",
    "text" : "The entire Universe is to the observable Universe as the observable Universe is to an atom. https:\/\/t.co\/QAfarbiKYe",
    "id" : 716726991861506049,
    "created_at" : "2016-04-03 20:40:05 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 740915162350243840,
  "created_at" : "2016-06-09 14:35:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 3, 10 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/730351803611545603\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/2qq0uxwj1p",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiILyuGWsAUUBRH.jpg",
      "id_str" : "730159055583490053",
      "id" : 730159055583490053,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiILyuGWsAUUBRH.jpg",
      "sizes" : [ {
        "h" : 710,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2qq0uxwj1p"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/XFO4Bv0c1N",
      "expanded_url" : "http:\/\/po.st\/ieOGc8",
      "display_url" : "po.st\/ieOGc8"
    } ]
  },
  "geo" : { },
  "id_str" : "740914566079647744",
  "text" : "RT @PopSci: See the \u201Cdoom spiral\u201D that perfectly explains global warming https:\/\/t.co\/XFO4Bv0c1N https:\/\/t.co\/2qq0uxwj1p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/730351803611545603\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/2qq0uxwj1p",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiILyuGWsAUUBRH.jpg",
        "id_str" : "730159055583490053",
        "id" : 730159055583490053,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiILyuGWsAUUBRH.jpg",
        "sizes" : [ {
          "h" : 710,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/2qq0uxwj1p"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/XFO4Bv0c1N",
        "expanded_url" : "http:\/\/po.st\/ieOGc8",
        "display_url" : "po.st\/ieOGc8"
      } ]
    },
    "geo" : { },
    "id_str" : "730351803611545603",
    "text" : "See the \u201Cdoom spiral\u201D that perfectly explains global warming https:\/\/t.co\/XFO4Bv0c1N https:\/\/t.co\/2qq0uxwj1p",
    "id" : 730351803611545603,
    "created_at" : "2016-05-11 11:00:13 +0000",
    "user" : {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "protected" : false,
      "id_str" : "19722699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793561660833267712\/Y5RPH9Te_normal.jpg",
      "id" : 19722699,
      "verified" : true
    }
  },
  "id" : 740914566079647744,
  "created_at" : "2016-06-09 14:32:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Machine Vids\uD83E\uDD16",
      "screen_name" : "EducationalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2625176466",
      "id" : 2625176466
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Learn_Things\/status\/689285212149280768\/video\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ewOL4dkFxP",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689285196777132032\/pu\/img\/tOr0GJ-njCFeuO5b.jpg",
      "id_str" : "689285196777132032",
      "id" : 689285196777132032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689285196777132032\/pu\/img\/tOr0GJ-njCFeuO5b.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 202
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 202
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 202
      } ],
      "display_url" : "pic.twitter.com\/ewOL4dkFxP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740913987534135298",
  "text" : "RT @EducationalPics: Let me just PHYSICS myself out of this hole https:\/\/t.co\/ewOL4dkFxP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Learn_Things\/status\/689285212149280768\/video\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/ewOL4dkFxP",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689285196777132032\/pu\/img\/tOr0GJ-njCFeuO5b.jpg",
        "id_str" : "689285196777132032",
        "id" : 689285196777132032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689285196777132032\/pu\/img\/tOr0GJ-njCFeuO5b.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 202
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 202
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 202
        } ],
        "display_url" : "pic.twitter.com\/ewOL4dkFxP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717365728693723136",
    "text" : "Let me just PHYSICS myself out of this hole https:\/\/t.co\/ewOL4dkFxP",
    "id" : 717365728693723136,
    "created_at" : "2016-04-05 14:58:12 +0000",
    "user" : {
      "name" : "Machine Vids\uD83E\uDD16",
      "screen_name" : "EducationalPics",
      "protected" : false,
      "id_str" : "2625176466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799421028808015872\/GVDlcuaZ_normal.jpg",
      "id" : 2625176466,
      "verified" : false
    }
  },
  "id" : 740913987534135298,
  "created_at" : "2016-06-09 14:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/738459680112971776\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/QItO7yckPT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj-JKdaVAAAItWU.jpg",
      "id_str" : "738459676698804224",
      "id" : 738459676698804224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj-JKdaVAAAItWU.jpg",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/QItO7yckPT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740913345226809344",
  "text" : "RT @SciencePorn: Physics Porn https:\/\/t.co\/QItO7yckPT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/738459680112971776\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/QItO7yckPT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj-JKdaVAAAItWU.jpg",
        "id_str" : "738459676698804224",
        "id" : 738459676698804224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj-JKdaVAAAItWU.jpg",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/QItO7yckPT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738459680112971776",
    "text" : "Physics Porn https:\/\/t.co\/QItO7yckPT",
    "id" : 738459680112971776,
    "created_at" : "2016-06-02 19:58:02 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 740913345226809344,
  "created_at" : "2016-06-09 14:28:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740913184438165506",
  "text" : "RT @Nigelstewart76: Does anyone know what might have nested in this box? Under a bridge with stream sat for a hour nothing in or out. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/740788417865338880\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/u94JU0j6de",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkfPHdWW0AQYR7b.jpg",
        "id_str" : "740788390770167812",
        "id" : 740788390770167812,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkfPHdWW0AQYR7b.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/u94JU0j6de"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740788417865338880",
    "text" : "Does anyone know what might have nested in this box? Under a bridge with stream sat for a hour nothing in or out. https:\/\/t.co\/u94JU0j6de",
    "id" : 740788417865338880,
    "created_at" : "2016-06-09 06:11:36 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 740913184438165506,
  "created_at" : "2016-06-09 14:27:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/RIj8Q16guy",
      "expanded_url" : "https:\/\/www.overdrive.com\/search?q=The+Dead+and+the+Gone",
      "display_url" : "overdrive.com\/search?q=The+D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740738986373746688",
  "text" : "Finished \"The Dead and the Gone\" by Susan Beth Pfeffer  #audiobook from my Library. Find this &amp; more at https:\/\/t.co\/RIj8Q16guy.",
  "id" : 740738986373746688,
  "created_at" : "2016-06-09 02:55:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Grayson",
      "screen_name" : "TheBabyGuyNYC",
      "indices" : [ 3, 17 ],
      "id_str" : "81505840",
      "id" : 81505840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740705778080829440",
  "text" : "RT @TheBabyGuyNYC: Having dated someone who went through \"reform therapy\" I can tell you it's torture. Please RT this &amp; spread word  https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/OPMPtNmndD",
        "expanded_url" : "https:\/\/twitter.com\/jeremymjordan\/status\/739209879680888832",
        "display_url" : "twitter.com\/jeremymjordan\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740694103369863168",
    "text" : "Having dated someone who went through \"reform therapy\" I can tell you it's torture. Please RT this &amp; spread word  https:\/\/t.co\/OPMPtNmndD",
    "id" : 740694103369863168,
    "created_at" : "2016-06-08 23:56:50 +0000",
    "user" : {
      "name" : "Jamie Grayson",
      "screen_name" : "TheBabyGuyNYC",
      "protected" : false,
      "id_str" : "81505840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700726024993005568\/DY85Osn1_normal.jpg",
      "id" : 81505840,
      "verified" : true
    }
  },
  "id" : 740705778080829440,
  "created_at" : "2016-06-09 00:43:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740691187208753152",
  "geo" : { },
  "id_str" : "740693391957209088",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 or you've had a strange breakdown ; )",
  "id" : 740693391957209088,
  "in_reply_to_status_id" : 740691187208753152,
  "created_at" : "2016-06-08 23:54:00 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/TeX5sZCRoc",
      "expanded_url" : "https:\/\/twitter.com\/JohnPiper\/status\/739970421689360384",
      "display_url" : "twitter.com\/JohnPiper\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740688558420299780",
  "text" : "hmm... https:\/\/t.co\/TeX5sZCRoc",
  "id" : 740688558420299780,
  "created_at" : "2016-06-08 23:34:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Solomon",
      "screen_name" : "solomonmissouri",
      "indices" : [ 3, 19 ],
      "id_str" : "21063822",
      "id" : 21063822
    }, {
      "name" : "John Piper",
      "screen_name" : "JohnPiper",
      "indices" : [ 98, 108 ],
      "id_str" : "27500565",
      "id" : 27500565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740687739620892672",
  "text" : "RT @solomonmissouri: i have so many questions but most importantly why is your God so darn stabby @JohnPiper ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Piper",
        "screen_name" : "JohnPiper",
        "indices" : [ 77, 87 ],
        "id_str" : "27500565",
        "id" : 27500565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "740616545781592064",
    "geo" : { },
    "id_str" : "740617133864931329",
    "in_reply_to_user_id" : 21063822,
    "text" : "i have so many questions but most importantly why is your God so darn stabby @JohnPiper ?",
    "id" : 740617133864931329,
    "in_reply_to_status_id" : 740616545781592064,
    "created_at" : "2016-06-08 18:50:59 +0000",
    "in_reply_to_screen_name" : "solomonmissouri",
    "in_reply_to_user_id_str" : "21063822",
    "user" : {
      "name" : "Solomon",
      "screen_name" : "solomonmissouri",
      "protected" : false,
      "id_str" : "21063822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726125177151455232\/U4tQYAjZ_normal.jpg",
      "id" : 21063822,
      "verified" : false
    }
  },
  "id" : 740687739620892672,
  "created_at" : "2016-06-08 23:31:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Jordan",
      "screen_name" : "JeremyMJordan",
      "indices" : [ 3, 17 ],
      "id_str" : "30412891",
      "id" : 30412891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740557841807867904",
  "text" : "RT @JeremyMJordan: My amazing friends &amp; fans, PLEASE help us save my sweet gay cousin Sarah who's trapped at a boarding facility in TX. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/mtVHMY1fdI",
        "expanded_url" : "http:\/\/gofundme.com\/27v8gac",
        "display_url" : "gofundme.com\/27v8gac"
      } ]
    },
    "geo" : { },
    "id_str" : "739209879680888832",
    "text" : "My amazing friends &amp; fans, PLEASE help us save my sweet gay cousin Sarah who's trapped at a boarding facility in TX. https:\/\/t.co\/mtVHMY1fdI",
    "id" : 739209879680888832,
    "created_at" : "2016-06-04 21:39:03 +0000",
    "user" : {
      "name" : "Jeremy Jordan",
      "screen_name" : "JeremyMJordan",
      "protected" : false,
      "id_str" : "30412891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793352986865049600\/BeoXdvl__normal.jpg",
      "id" : 30412891,
      "verified" : true
    }
  },
  "id" : 740557841807867904,
  "created_at" : "2016-06-08 14:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740556802723590148",
  "text" : "ahh.. im more of who I was when I was young. nothing matters. even as a kid the world had no meaning. just me and my thoughts.",
  "id" : 740556802723590148,
  "created_at" : "2016-06-08 14:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Wolman",
      "screen_name" : "jakobwolman",
      "indices" : [ 3, 15 ],
      "id_str" : "14358804",
      "id" : 14358804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740556102304157696",
  "text" : "RT @jakobwolman: \"It's very hard to hate someone you understand. \"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740439612561199104",
    "text" : "\"It's very hard to hate someone you understand. \"",
    "id" : 740439612561199104,
    "created_at" : "2016-06-08 07:05:34 +0000",
    "user" : {
      "name" : "Jakob Wolman",
      "screen_name" : "jakobwolman",
      "protected" : false,
      "id_str" : "14358804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1368350147\/jakob_normal.jpg",
      "id" : 14358804,
      "verified" : false
    }
  },
  "id" : 740556102304157696,
  "created_at" : "2016-06-08 14:48:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Edelman",
      "screen_name" : "kerihw",
      "indices" : [ 3, 10 ],
      "id_str" : "751482725287227393",
      "id" : 751482725287227393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740555525205700610",
  "text" : "RT @kerihw: arguing on twitter is like having a sex in a canoe, it's totally possible but it's not a medium that is optimised for the task",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740452821062037504",
    "text" : "arguing on twitter is like having a sex in a canoe, it's totally possible but it's not a medium that is optimised for the task",
    "id" : 740452821062037504,
    "created_at" : "2016-06-08 07:58:04 +0000",
    "user" : {
      "name" : "joe",
      "screen_name" : "mutablejoe",
      "protected" : false,
      "id_str" : "43328711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793375853321326592\/zHaxmFpf_normal.jpg",
      "id" : 43328711,
      "verified" : false
    }
  },
  "id" : 740555525205700610,
  "created_at" : "2016-06-08 14:46:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLBOOK",
      "screen_name" : "LOLBOOKcom",
      "indices" : [ 3, 14 ],
      "id_str" : "2820857447",
      "id" : 2820857447
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LOLBOOKcom\/status\/740328222282416130\/video\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/pkt85UrQja",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740328073376104448\/pu\/img\/186n4KRZyJJabINa.jpg",
      "id_str" : "740328073376104448",
      "id" : 740328073376104448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740328073376104448\/pu\/img\/186n4KRZyJJabINa.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/pkt85UrQja"
    } ],
    "hashtags" : [ {
      "text" : "funny",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "chicken",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "rooster",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "farming",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "lol",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "LOLBook",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740553717699739648",
  "text" : "RT @LOLBOOKcom: Chicken got caught sleeping on the job... #funny #chicken #rooster #farming #lol #LOLBook https:\/\/t.co\/pkt85UrQja",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LOLBOOKcom\/status\/740328222282416130\/video\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/pkt85UrQja",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740328073376104448\/pu\/img\/186n4KRZyJJabINa.jpg",
        "id_str" : "740328073376104448",
        "id" : 740328073376104448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/740328073376104448\/pu\/img\/186n4KRZyJJabINa.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/pkt85UrQja"
      } ],
      "hashtags" : [ {
        "text" : "funny",
        "indices" : [ 42, 48 ]
      }, {
        "text" : "chicken",
        "indices" : [ 49, 57 ]
      }, {
        "text" : "rooster",
        "indices" : [ 58, 66 ]
      }, {
        "text" : "farming",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "lol",
        "indices" : [ 76, 80 ]
      }, {
        "text" : "LOLBook",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740328222282416130",
    "text" : "Chicken got caught sleeping on the job... #funny #chicken #rooster #farming #lol #LOLBook https:\/\/t.co\/pkt85UrQja",
    "id" : 740328222282416130,
    "created_at" : "2016-06-07 23:42:57 +0000",
    "user" : {
      "name" : "LOLBOOK",
      "screen_name" : "LOLBOOKcom",
      "protected" : false,
      "id_str" : "2820857447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727444953211670528\/NVR5KSn7_normal.jpg",
      "id" : 2820857447,
      "verified" : false
    }
  },
  "id" : 740553717699739648,
  "created_at" : "2016-06-08 14:38:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/UUnCADxTqf",
      "expanded_url" : "http:\/\/go.shr.lc\/28jkWoG",
      "display_url" : "go.shr.lc\/28jkWoG"
    } ]
  },
  "geo" : { },
  "id_str" : "740539265264852992",
  "text" : "Woman Takes to Facebook to Identify Her Dog\u2019s \u201CDrive-by Love Bomber\u201D - https:\/\/t.co\/UUnCADxTqf",
  "id" : 740539265264852992,
  "created_at" : "2016-06-08 13:41:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "indices" : [ 3, 17 ],
      "id_str" : "555307309",
      "id" : 555307309
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TA",
      "indices" : [ 131, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740280898269159425",
  "text" : "RT @takecareofUUU: Never let negative people take your Happiness.U work hard to stay Positive.Limit Negativity. Welcome Positivity.#TA http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/takecareofUUU\/status\/740268177788141568\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/CilORkKy8y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkX1-3BUgAAAUSd.jpg",
        "id_str" : "740268174042497024",
        "id" : 740268174042497024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkX1-3BUgAAAUSd.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CilORkKy8y"
      } ],
      "hashtags" : [ {
        "text" : "TA",
        "indices" : [ 112, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740268177788141568",
    "text" : "Never let negative people take your Happiness.U work hard to stay Positive.Limit Negativity. Welcome Positivity.#TA https:\/\/t.co\/CilORkKy8y",
    "id" : 740268177788141568,
    "created_at" : "2016-06-07 19:44:21 +0000",
    "user" : {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "protected" : false,
      "id_str" : "555307309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537254454949445634\/7uw1omdM_normal.jpeg",
      "id" : 555307309,
      "verified" : false
    }
  },
  "id" : 740280898269159425,
  "created_at" : "2016-06-07 20:34:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pHPUNJUa9l",
      "expanded_url" : "https:\/\/vine.co\/v\/i3MDjWtjWpJ",
      "display_url" : "vine.co\/v\/i3MDjWtjWpJ"
    } ]
  },
  "geo" : { },
  "id_str" : "740280816329216001",
  "text" : "RT @1CatShepherd: Marley has melted in this soporific heat so like a puddle she is leaking a cat tail off her shelf https:\/\/t.co\/pHPUNJUa9l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/pHPUNJUa9l",
        "expanded_url" : "https:\/\/vine.co\/v\/i3MDjWtjWpJ",
        "display_url" : "vine.co\/v\/i3MDjWtjWpJ"
      } ]
    },
    "geo" : { },
    "id_str" : "740251961698701312",
    "text" : "Marley has melted in this soporific heat so like a puddle she is leaking a cat tail off her shelf https:\/\/t.co\/pHPUNJUa9l",
    "id" : 740251961698701312,
    "created_at" : "2016-06-07 18:39:55 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 740280816329216001,
  "created_at" : "2016-06-07 20:34:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Dame",
      "screen_name" : "jacksondame",
      "indices" : [ 3, 15 ],
      "id_str" : "476019403",
      "id" : 476019403
    }, {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 60, 73 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacksondame\/status\/739837460004274177\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/xfBN1PZyrd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRuO0rUoAAjjq6.jpg",
      "id_str" : "739837439733178368",
      "id" : 739837439733178368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRuO0rUoAAjjq6.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/xfBN1PZyrd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739869751137177600",
  "text" : "RT @jacksondame: Look what just came in the mail! An ARC of @mikemchargue's upcoming book! Can't wait to dive in. https:\/\/t.co\/xfBN1PZyrd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science Mike",
        "screen_name" : "mikemchargue",
        "indices" : [ 43, 56 ],
        "id_str" : "6091632",
        "id" : 6091632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacksondame\/status\/739837460004274177\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/xfBN1PZyrd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRuO0rUoAAjjq6.jpg",
        "id_str" : "739837439733178368",
        "id" : 739837439733178368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRuO0rUoAAjjq6.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/xfBN1PZyrd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739837460004274177",
    "text" : "Look what just came in the mail! An ARC of @mikemchargue's upcoming book! Can't wait to dive in. https:\/\/t.co\/xfBN1PZyrd",
    "id" : 739837460004274177,
    "created_at" : "2016-06-06 15:12:50 +0000",
    "user" : {
      "name" : "Jackson Dame",
      "screen_name" : "jacksondame",
      "protected" : false,
      "id_str" : "476019403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769126314204917760\/MycbpTNv_normal.jpg",
      "id" : 476019403,
      "verified" : false
    }
  },
  "id" : 739869751137177600,
  "created_at" : "2016-06-06 17:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Robertson",
      "screen_name" : "probzz",
      "indices" : [ 3, 10 ],
      "id_str" : "264348615",
      "id" : 264348615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/probzz\/status\/739840892253540354\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/rws4m6oa5F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRxXl0VAAAVg0V.jpg",
      "id_str" : "739840888898125824",
      "id" : 739840888898125824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRxXl0VAAAVg0V.jpg",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/rws4m6oa5F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739858229677678592",
  "text" : "RT @probzz: \uD83D\uDC26\uD83D\uDC26\uD83D\uDC26BIRDS\uD83D\uDC26\uD83D\uDC26\uD83D\uDC26 https:\/\/t.co\/rws4m6oa5F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/probzz\/status\/739840892253540354\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/rws4m6oa5F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRxXl0VAAAVg0V.jpg",
        "id_str" : "739840888898125824",
        "id" : 739840888898125824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRxXl0VAAAVg0V.jpg",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/rws4m6oa5F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739840892253540354",
    "text" : "\uD83D\uDC26\uD83D\uDC26\uD83D\uDC26BIRDS\uD83D\uDC26\uD83D\uDC26\uD83D\uDC26 https:\/\/t.co\/rws4m6oa5F",
    "id" : 739840892253540354,
    "created_at" : "2016-06-06 15:26:28 +0000",
    "user" : {
      "name" : "Paul Robertson",
      "screen_name" : "probzz",
      "protected" : false,
      "id_str" : "264348615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780995451470381057\/n4a-WGMM_normal.jpg",
      "id" : 264348615,
      "verified" : false
    }
  },
  "id" : 739858229677678592,
  "created_at" : "2016-06-06 16:35:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/739836338938216448\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/DpvV8rdFgB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRtOiBWEAAi4Kt.jpg",
      "id_str" : "739836335213645824",
      "id" : 739836335213645824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRtOiBWEAAi4Kt.jpg",
      "sizes" : [ {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/DpvV8rdFgB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/bgFk9LM7SY",
      "expanded_url" : "http:\/\/notes.baty.net\/2016\/05\/28\/0058.html?_ts=1465225699",
      "display_url" : "notes.baty.net\/2016\/05\/28\/005\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739836338938216448",
  "text" : "https:\/\/t.co\/bgFk9LM7SY https:\/\/t.co\/DpvV8rdFgB",
  "id" : 739836338938216448,
  "created_at" : "2016-06-06 15:08:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "feedly",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/gZSuuNIdB5",
      "expanded_url" : "http:\/\/scripting.com\/2016\/06\/06\/1307.html",
      "display_url" : "scripting.com\/2016\/06\/06\/130\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739824413311442944",
  "text" : "Rivers are still the best way to get news via the web https:\/\/t.co\/gZSuuNIdB5 #tech #feedly",
  "id" : 739824413311442944,
  "created_at" : "2016-06-06 14:21:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Odell Photo",
      "screen_name" : "angelhugs64",
      "indices" : [ 3, 15 ],
      "id_str" : "52611727",
      "id" : 52611727
    }, {
      "name" : "Dutchess Tourism",
      "screen_name" : "dutchesstourism",
      "indices" : [ 54, 70 ],
      "id_str" : "20096144",
      "id" : 20096144
    }, {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 71, 87 ],
      "id_str" : "102313523",
      "id" : 102313523
    }, {
      "name" : "I LOVE NEW YORK",
      "screen_name" : "I_LOVE_NY",
      "indices" : [ 88, 98 ],
      "id_str" : "46164502",
      "id" : 46164502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/angelhugs64\/status\/739409705035010048\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/BY2w8iZlkS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkLpLudUkAIY4YQ.jpg",
      "id_str" : "739409676501028866",
      "id" : 739409676501028866,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkLpLudUkAIY4YQ.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/BY2w8iZlkS"
    } ],
    "hashtags" : [ {
      "text" : "beforetherain",
      "indices" : [ 17, 31 ]
    }, {
      "text" : "clouds",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "Poughkeepsie",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739603528155561985",
  "text" : "RT @angelhugs64: #beforetherain #clouds #Poughkeepsie @dutchesstourism @TheHudsonValley @I_LOVE_NY https:\/\/t.co\/BY2w8iZlkS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dutchess Tourism",
        "screen_name" : "dutchesstourism",
        "indices" : [ 37, 53 ],
        "id_str" : "20096144",
        "id" : 20096144
      }, {
        "name" : "The Hudson Valley",
        "screen_name" : "TheHudsonValley",
        "indices" : [ 54, 70 ],
        "id_str" : "102313523",
        "id" : 102313523
      }, {
        "name" : "I LOVE NEW YORK",
        "screen_name" : "I_LOVE_NY",
        "indices" : [ 71, 81 ],
        "id_str" : "46164502",
        "id" : 46164502
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/angelhugs64\/status\/739409705035010048\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/BY2w8iZlkS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkLpLudUkAIY4YQ.jpg",
        "id_str" : "739409676501028866",
        "id" : 739409676501028866,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkLpLudUkAIY4YQ.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/BY2w8iZlkS"
      } ],
      "hashtags" : [ {
        "text" : "beforetherain",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "clouds",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "Poughkeepsie",
        "indices" : [ 23, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739409705035010048",
    "text" : "#beforetherain #clouds #Poughkeepsie @dutchesstourism @TheHudsonValley @I_LOVE_NY https:\/\/t.co\/BY2w8iZlkS",
    "id" : 739409705035010048,
    "created_at" : "2016-06-05 10:53:05 +0000",
    "user" : {
      "name" : "Carolyn Odell Photo",
      "screen_name" : "angelhugs64",
      "protected" : false,
      "id_str" : "52611727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511690233436733440\/CAL0SbuQ_normal.jpeg",
      "id" : 52611727,
      "verified" : false
    }
  },
  "id" : 739603528155561985,
  "created_at" : "2016-06-05 23:43:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MBEDDED",
      "screen_name" : "mbeddedmaximum",
      "indices" : [ 87, 102 ],
      "id_str" : "3304579344",
      "id" : 3304579344
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/738836874320437248\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/egc3E4KU0Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDgOIdUkAQSql2.jpg",
      "id_str" : "738836872282017796",
      "id" : 738836872282017796,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDgOIdUkAQSql2.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/egc3E4KU0Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/WkOW1tuMPE",
      "expanded_url" : "https:\/\/mbeddedmaximum.com\/2016\/06\/02\/earths-core-is-younger-than-its-surface\/",
      "display_url" : "mbeddedmaximum.com\/2016\/06\/02\/ear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739593529270411264",
  "text" : "RT @StarStuff42: Earth's Core is Younger Than It's Surface https:\/\/t.co\/WkOW1tuMPE via @mbeddedmaximum https:\/\/t.co\/egc3E4KU0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitshot.com\" rel=\"nofollow\"\u003ETwitshot.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MBEDDED",
        "screen_name" : "mbeddedmaximum",
        "indices" : [ 70, 85 ],
        "id_str" : "3304579344",
        "id" : 3304579344
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/738836874320437248\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/egc3E4KU0Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDgOIdUkAQSql2.jpg",
        "id_str" : "738836872282017796",
        "id" : 738836872282017796,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDgOIdUkAQSql2.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/egc3E4KU0Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/WkOW1tuMPE",
        "expanded_url" : "https:\/\/mbeddedmaximum.com\/2016\/06\/02\/earths-core-is-younger-than-its-surface\/",
        "display_url" : "mbeddedmaximum.com\/2016\/06\/02\/ear\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738836874320437248",
    "text" : "Earth's Core is Younger Than It's Surface https:\/\/t.co\/WkOW1tuMPE via @mbeddedmaximum https:\/\/t.co\/egc3E4KU0Y",
    "id" : 738836874320437248,
    "created_at" : "2016-06-03 20:56:52 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 739593529270411264,
  "created_at" : "2016-06-05 23:03:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socrates Incarnate",
      "screen_name" : "attnhumanbeing",
      "indices" : [ 3, 18 ],
      "id_str" : "722264223368097793",
      "id" : 722264223368097793
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatshaming",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739592762266357764",
  "text" : "RT @attnhumanbeing: I'm sick of this #fatshaming.  Women and men gain weight for various reasons.  Appearances are often misleading.  https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fatshaming",
        "indices" : [ 17, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/DrR76dVzfR",
        "expanded_url" : "https:\/\/twitter.com\/huffingtonpost\/status\/738898868251832320",
        "display_url" : "twitter.com\/huffingtonpost\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738905824853131264",
    "text" : "I'm sick of this #fatshaming.  Women and men gain weight for various reasons.  Appearances are often misleading.  https:\/\/t.co\/DrR76dVzfR",
    "id" : 738905824853131264,
    "created_at" : "2016-06-04 01:30:51 +0000",
    "user" : {
      "name" : "Socrates Incarnate",
      "screen_name" : "attnhumanbeing",
      "protected" : false,
      "id_str" : "722264223368097793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739606689872240640\/ST1Ujj4V_normal.jpg",
      "id" : 722264223368097793,
      "verified" : false
    }
  },
  "id" : 739592762266357764,
  "created_at" : "2016-06-05 23:00:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "confettiforeveryone",
      "indices" : [ 15, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739582858768097280",
  "geo" : { },
  "id_str" : "739590456321953792",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist #confettiforeveryone lol",
  "id" : 739590456321953792,
  "in_reply_to_status_id" : 739582858768097280,
  "created_at" : "2016-06-05 22:51:20 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739577416646004736",
  "text" : "RT @damienechols: Hell is something you carry around with you, not somewhere you go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739576141086855168",
    "text" : "Hell is something you carry around with you, not somewhere you go.",
    "id" : 739576141086855168,
    "created_at" : "2016-06-05 21:54:27 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 739577416646004736,
  "created_at" : "2016-06-05 21:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivian",
      "screen_name" : "VanguardVivian",
      "indices" : [ 3, 18 ],
      "id_str" : "16738904",
      "id" : 16738904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739568983385444353",
  "text" : "RT @VanguardVivian: Unsolicited comments on someone\u2019s diet are always a no-no, whether you\u2019re fat-shaming them, telling them to eat meat, o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739563022742609921",
    "text" : "Unsolicited comments on someone\u2019s diet are always a no-no, whether you\u2019re fat-shaming them, telling them to eat meat, or telling them not to",
    "id" : 739563022742609921,
    "created_at" : "2016-06-05 21:02:19 +0000",
    "user" : {
      "name" : "Vivian",
      "screen_name" : "VanguardVivian",
      "protected" : false,
      "id_str" : "16738904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797928814013718532\/8LPYG8F4_normal.jpg",
      "id" : 16738904,
      "verified" : false
    }
  },
  "id" : 739568983385444353,
  "created_at" : "2016-06-05 21:26:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Dv3rrpaaG8",
      "expanded_url" : "http:\/\/johnpavlovitz.com\/2015\/09\/23\/when-your-heart-gets-out-of-hell-finding-a-fear-less-faith\/?utm_campaign=coschedule&utm_source=twitter&utm_medium=johnpavlovitz",
      "display_url" : "johnpavlovitz.com\/2015\/09\/23\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739492303241412612",
  "text" : "RT @johnpavlovitz: When Your Heart Gets Out Of Hell (Finding A Fear-Less Faith) https:\/\/t.co\/Dv3rrpaaG8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/Dv3rrpaaG8",
        "expanded_url" : "http:\/\/johnpavlovitz.com\/2015\/09\/23\/when-your-heart-gets-out-of-hell-finding-a-fear-less-faith\/?utm_campaign=coschedule&utm_source=twitter&utm_medium=johnpavlovitz",
        "display_url" : "johnpavlovitz.com\/2015\/09\/23\/whe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739487029139013633",
    "text" : "When Your Heart Gets Out Of Hell (Finding A Fear-Less Faith) https:\/\/t.co\/Dv3rrpaaG8",
    "id" : 739487029139013633,
    "created_at" : "2016-06-05 16:00:21 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 739492303241412612,
  "created_at" : "2016-06-05 16:21:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Patton",
      "screen_name" : "StanRockPatton",
      "indices" : [ 3, 18 ],
      "id_str" : "2330774683",
      "id" : 2330774683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739463535768576000",
  "text" : "RT @StanRockPatton: Living sacrifice entails deliberately not taking a stand. It means mercy over justice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738952616684617728",
    "text" : "Living sacrifice entails deliberately not taking a stand. It means mercy over justice.",
    "id" : 738952616684617728,
    "created_at" : "2016-06-04 04:36:47 +0000",
    "user" : {
      "name" : "Stan Patton",
      "screen_name" : "StanRockPatton",
      "protected" : false,
      "id_str" : "2330774683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740814216148439040\/ctvPreQs_normal.jpg",
      "id" : 2330774683,
      "verified" : false
    }
  },
  "id" : 739463535768576000,
  "created_at" : "2016-06-05 14:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/739395772026916864\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QZ7e0bqsU7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkLchvvXAAAa_kV.jpg",
      "id_str" : "739395761151082496",
      "id" : 739395761151082496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkLchvvXAAAa_kV.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/QZ7e0bqsU7"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/739395772026916864\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QZ7e0bqsU7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkLchwKWgAAKaYI.jpg",
      "id_str" : "739395761264295936",
      "id" : 739395761264295936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkLchwKWgAAKaYI.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1224
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1224
      } ],
      "display_url" : "pic.twitter.com\/QZ7e0bqsU7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739461977102254080",
  "text" : "RT @marseelee: Remember everything is spirit \u2013 death is an illusion https:\/\/t.co\/QZ7e0bqsU7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/739395772026916864\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/QZ7e0bqsU7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkLchvvXAAAa_kV.jpg",
        "id_str" : "739395761151082496",
        "id" : 739395761151082496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkLchvvXAAAa_kV.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/QZ7e0bqsU7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/739395772026916864\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/QZ7e0bqsU7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkLchwKWgAAKaYI.jpg",
        "id_str" : "739395761264295936",
        "id" : 739395761264295936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkLchwKWgAAKaYI.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1224
        } ],
        "display_url" : "pic.twitter.com\/QZ7e0bqsU7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739395772026916864",
    "text" : "Remember everything is spirit \u2013 death is an illusion https:\/\/t.co\/QZ7e0bqsU7",
    "id" : 739395772026916864,
    "created_at" : "2016-06-05 09:57:44 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 739461977102254080,
  "created_at" : "2016-06-05 14:20:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sour Senseless",
      "screen_name" : "soursenseless",
      "indices" : [ 3, 17 ],
      "id_str" : "391283081",
      "id" : 391283081
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/soursenseless\/status\/738854248822112256\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Pj2AmQlH3q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDv8I3UYAArYAl.jpg",
      "id_str" : "738854155339456512",
      "id" : 738854155339456512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDv8I3UYAArYAl.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/Pj2AmQlH3q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739245373412216833",
  "text" : "RT @soursenseless: After years on Reddit I found the one good thing https:\/\/t.co\/Pj2AmQlH3q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/soursenseless\/status\/738854248822112256\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/Pj2AmQlH3q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDv8I3UYAArYAl.jpg",
        "id_str" : "738854155339456512",
        "id" : 738854155339456512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDv8I3UYAArYAl.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/Pj2AmQlH3q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738854248822112256",
    "text" : "After years on Reddit I found the one good thing https:\/\/t.co\/Pj2AmQlH3q",
    "id" : 738854248822112256,
    "created_at" : "2016-06-03 22:05:54 +0000",
    "user" : {
      "name" : "Sour Senseless",
      "screen_name" : "soursenseless",
      "protected" : false,
      "id_str" : "391283081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477042984207151104\/R43t5yDR_normal.jpeg",
      "id" : 391283081,
      "verified" : false
    }
  },
  "id" : 739245373412216833,
  "created_at" : "2016-06-05 00:00:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739228414373138432",
  "text" : "RT @AWorldOutOfMind: Hell: It's not a punishment if you can't ever escape your pain, it's just torture, used as a threat to keep people in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739227282888396800",
    "text" : "Hell: It's not a punishment if you can't ever escape your pain, it's just torture, used as a threat to keep people in line. Terrorism.",
    "id" : 739227282888396800,
    "created_at" : "2016-06-04 22:48:13 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 739228414373138432,
  "created_at" : "2016-06-04 22:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "indices" : [ 3, 16 ],
      "id_str" : "23150269",
      "id" : 23150269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739224827354095616",
  "text" : "RT @beardonabike: I find that most Americans filter Jesus through the lens of their politics instead of filtering their politics through th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736683644756975616",
    "text" : "I find that most Americans filter Jesus through the lens of their politics instead of filtering their politics through the lens of Jesus.",
    "id" : 736683644756975616,
    "created_at" : "2016-05-28 22:20:42 +0000",
    "user" : {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "protected" : false,
      "id_str" : "23150269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461260607669293056\/udIfmFCN_normal.jpeg",
      "id" : 23150269,
      "verified" : false
    }
  },
  "id" : 739224827354095616,
  "created_at" : "2016-06-04 22:38:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "indices" : [ 0, 13 ],
      "id_str" : "23150269",
      "id" : 23150269
    }, {
      "name" : "Rethinking Hell",
      "screen_name" : "RethinkingHell",
      "indices" : [ 14, 29 ],
      "id_str" : "633367768",
      "id" : 633367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739182951057883136",
  "geo" : { },
  "id_str" : "739198871088340995",
  "in_reply_to_user_id" : 23150269,
  "text" : "@beardonabike @RethinkingHell approx 53:28 \"universalism deserves a place at the table\" becuz \"empathy\"",
  "id" : 739198871088340995,
  "in_reply_to_status_id" : 739182951057883136,
  "created_at" : "2016-06-04 20:55:19 +0000",
  "in_reply_to_screen_name" : "beardonabike",
  "in_reply_to_user_id_str" : "23150269",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739182246687543297",
  "text" : "im tired. never have energy. im bored. so bored.",
  "id" : 739182246687543297,
  "created_at" : "2016-06-04 19:49:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/SqW0HmRFPK",
      "expanded_url" : "http:\/\/goo.gl\/RIF7C1",
      "display_url" : "goo.gl\/RIF7C1"
    } ]
  },
  "geo" : { },
  "id_str" : "739170581854212096",
  "text" : "RT @openculture: Learn to Think Like a Philosopher w\/ Oxford\u2019s Free Course Critical Reasoning For Beginners \nhttps:\/\/t.co\/SqW0HmRFPK https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/739157540664020994\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/yt3jowHMV3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHxr8IVAAITqrs.jpg",
        "id_str" : "739137551043198978",
        "id" : 739137551043198978,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHxr8IVAAITqrs.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/yt3jowHMV3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/SqW0HmRFPK",
        "expanded_url" : "http:\/\/goo.gl\/RIF7C1",
        "display_url" : "goo.gl\/RIF7C1"
      } ]
    },
    "geo" : { },
    "id_str" : "739157540664020994",
    "text" : "Learn to Think Like a Philosopher w\/ Oxford\u2019s Free Course Critical Reasoning For Beginners \nhttps:\/\/t.co\/SqW0HmRFPK https:\/\/t.co\/yt3jowHMV3",
    "id" : 739157540664020994,
    "created_at" : "2016-06-04 18:11:05 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74425623\/open_culture_white_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 739170581854212096,
  "created_at" : "2016-06-04 19:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/KReo7Mpwfd",
      "expanded_url" : "https:\/\/vine.co\/v\/iYp56EgZOdV",
      "display_url" : "vine.co\/v\/iYp56EgZOdV"
    } ]
  },
  "geo" : { },
  "id_str" : "739169308350251008",
  "text" : "RT @1CatShepherd: Ovenmitt is such a dog of a cat..... Following the human everywhere  https:\/\/t.co\/KReo7Mpwfd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/KReo7Mpwfd",
        "expanded_url" : "https:\/\/vine.co\/v\/iYp56EgZOdV",
        "display_url" : "vine.co\/v\/iYp56EgZOdV"
      } ]
    },
    "geo" : { },
    "id_str" : "739169067874045952",
    "text" : "Ovenmitt is such a dog of a cat..... Following the human everywhere  https:\/\/t.co\/KReo7Mpwfd",
    "id" : 739169067874045952,
    "created_at" : "2016-06-04 18:56:53 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 739169308350251008,
  "created_at" : "2016-06-04 18:57:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/5jCxHUMpVL",
      "expanded_url" : "https:\/\/twitter.com\/cassandra17lina\/status\/739129583262441472",
      "display_url" : "twitter.com\/cassandra17lin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739162538059915264",
  "text" : "whats around the corner? : ) https:\/\/t.co\/5jCxHUMpVL",
  "id" : 739162538059915264,
  "created_at" : "2016-06-04 18:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Jackdaws",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "RedDeer",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "BushyPark",
      "indices" : [ 99, 109 ]
    }, {
      "text" : "London",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739161932444401664",
  "text" : "RT @missmuckyduck: It's no good hiding in the bracken hoping the #Jackdaws won't see you.\n#RedDeer #BushyPark #London https:\/\/t.co\/8Uc1NxGy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/missmuckyduck\/status\/739098468753494016\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/8Uc1NxGyAa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHOH6SWsAAvx5r.jpg",
        "id_str" : "739098449166118912",
        "id" : 739098449166118912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHOH6SWsAAvx5r.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/8Uc1NxGyAa"
      } ],
      "hashtags" : [ {
        "text" : "Jackdaws",
        "indices" : [ 46, 55 ]
      }, {
        "text" : "RedDeer",
        "indices" : [ 71, 79 ]
      }, {
        "text" : "BushyPark",
        "indices" : [ 80, 90 ]
      }, {
        "text" : "London",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739098468753494016",
    "text" : "It's no good hiding in the bracken hoping the #Jackdaws won't see you.\n#RedDeer #BushyPark #London https:\/\/t.co\/8Uc1NxGyAa",
    "id" : 739098468753494016,
    "created_at" : "2016-06-04 14:16:21 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 739161932444401664,
  "created_at" : "2016-06-04 18:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/739152665075159041\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Pa4yHLk3C6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkH_YlyXEAAQPPj.jpg",
      "id_str" : "739152611790753792",
      "id" : 739152611790753792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkH_YlyXEAAQPPj.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Pa4yHLk3C6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739152868616372225",
  "text" : "RT @Nigelstewart76: Lovely flowers https:\/\/t.co\/Pa4yHLk3C6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/739152665075159041\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/Pa4yHLk3C6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkH_YlyXEAAQPPj.jpg",
        "id_str" : "739152611790753792",
        "id" : 739152611790753792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkH_YlyXEAAQPPj.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Pa4yHLk3C6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739152665075159041",
    "text" : "Lovely flowers https:\/\/t.co\/Pa4yHLk3C6",
    "id" : 739152665075159041,
    "created_at" : "2016-06-04 17:51:42 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 739152868616372225,
  "created_at" : "2016-06-04 17:52:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darryl McAdams",
      "screen_name" : "psygnisfive",
      "indices" : [ 3, 15 ],
      "id_str" : "3393781",
      "id" : 3393781
    }, {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "indices" : [ 17, 28 ],
      "id_str" : "15767534",
      "id" : 15767534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739144253268447232",
  "text" : "RT @psygnisfive: @micahbales i've recently found myself pondering what things would be like if our culture didnt have an exclusively puniti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Micah Bales",
        "screen_name" : "micahbales",
        "indices" : [ 0, 11 ],
        "id_str" : "15767534",
        "id" : 15767534
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "739120861307887620",
    "geo" : { },
    "id_str" : "739135249393668097",
    "in_reply_to_user_id" : 15767534,
    "text" : "@micahbales i've recently found myself pondering what things would be like if our culture didnt have an exclusively punitive idea of justice",
    "id" : 739135249393668097,
    "in_reply_to_status_id" : 739120861307887620,
    "created_at" : "2016-06-04 16:42:30 +0000",
    "in_reply_to_screen_name" : "micahbales",
    "in_reply_to_user_id_str" : "15767534",
    "user" : {
      "name" : "Darryl McAdams",
      "screen_name" : "psygnisfive",
      "protected" : false,
      "id_str" : "3393781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478184468998418433\/y99ACDSt_normal.jpeg",
      "id" : 3393781,
      "verified" : false
    }
  },
  "id" : 739144253268447232,
  "created_at" : "2016-06-04 17:18:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/738900644447330305\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/ahf26XEGCL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkEaN9aWYAA3Cl8.jpg",
      "id_str" : "738900640991174656",
      "id" : 738900640991174656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkEaN9aWYAA3Cl8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ahf26XEGCL"
    } ],
    "hashtags" : [ {
      "text" : "ThoughtOfTheday",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738903135943544832",
  "text" : "RT @mercola: Agree? #ThoughtOfTheday https:\/\/t.co\/ahf26XEGCL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/738900644447330305\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/ahf26XEGCL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkEaN9aWYAA3Cl8.jpg",
        "id_str" : "738900640991174656",
        "id" : 738900640991174656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkEaN9aWYAA3Cl8.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ahf26XEGCL"
      } ],
      "hashtags" : [ {
        "text" : "ThoughtOfTheday",
        "indices" : [ 7, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738900644447330305",
    "text" : "Agree? #ThoughtOfTheday https:\/\/t.co\/ahf26XEGCL",
    "id" : 738900644447330305,
    "created_at" : "2016-06-04 01:10:16 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 738903135943544832,
  "created_at" : "2016-06-04 01:20:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738869047299854336",
  "text" : "RT @SciencePorn: This is the \"Angel Oak\" tree which can be found in South Carolina \u2013 It's estimated to be up to 1400 years old. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/738868281885503488\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/dHz8ZFX278",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkD8ySRWYAAtA6t.jpg",
        "id_str" : "738868279717027840",
        "id" : 738868279717027840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkD8ySRWYAAtA6t.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/dHz8ZFX278"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738868281885503488",
    "text" : "This is the \"Angel Oak\" tree which can be found in South Carolina \u2013 It's estimated to be up to 1400 years old. https:\/\/t.co\/dHz8ZFX278",
    "id" : 738868281885503488,
    "created_at" : "2016-06-03 23:01:40 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 738869047299854336,
  "created_at" : "2016-06-03 23:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Chesler",
      "screen_name" : "RickChesler",
      "indices" : [ 3, 15 ],
      "id_str" : "17554456",
      "id" : 17554456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "England",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/TIv7dYXXOM",
      "expanded_url" : "http:\/\/ow.ly\/nnbz300R0Kt",
      "display_url" : "ow.ly\/nnbz300R0Kt"
    } ]
  },
  "geo" : { },
  "id_str" : "738767741147025408",
  "text" : "RT @RickChesler: Found: The Oldest Handwritten Document Ever Discovered in #England https:\/\/t.co\/TIv7dYXXOM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "England",
        "indices" : [ 58, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/TIv7dYXXOM",
        "expanded_url" : "http:\/\/ow.ly\/nnbz300R0Kt",
        "display_url" : "ow.ly\/nnbz300R0Kt"
      } ]
    },
    "geo" : { },
    "id_str" : "738766088377389056",
    "text" : "Found: The Oldest Handwritten Document Ever Discovered in #England https:\/\/t.co\/TIv7dYXXOM",
    "id" : 738766088377389056,
    "created_at" : "2016-06-03 16:15:35 +0000",
    "user" : {
      "name" : "Rick Chesler",
      "screen_name" : "RickChesler",
      "protected" : false,
      "id_str" : "17554456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772163787654737920\/_e3IDVfp_normal.jpg",
      "id" : 17554456,
      "verified" : false
    }
  },
  "id" : 738767741147025408,
  "created_at" : "2016-06-03 16:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/738765328554004480\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/2pAgP470aZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkCfJmRWYAEBWWR.jpg",
      "id_str" : "738765326129717249",
      "id" : 738765326129717249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkCfJmRWYAEBWWR.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/2pAgP470aZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738766657867382787",
  "text" : "RT @ItsFoodPorn: Chocolate Chip Caramel Cookies https:\/\/t.co\/2pAgP470aZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/738765328554004480\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/2pAgP470aZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkCfJmRWYAEBWWR.jpg",
        "id_str" : "738765326129717249",
        "id" : 738765326129717249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkCfJmRWYAEBWWR.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/2pAgP470aZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738765328554004480",
    "text" : "Chocolate Chip Caramel Cookies https:\/\/t.co\/2pAgP470aZ",
    "id" : 738765328554004480,
    "created_at" : "2016-06-03 16:12:34 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 738766657867382787,
  "created_at" : "2016-06-03 16:17:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/738752986193793025\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/KICVcY6vmx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkCT7KjWYAAA2g9.jpg",
      "id_str" : "738752983542947840",
      "id" : 738752983542947840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkCT7KjWYAAA2g9.jpg",
      "sizes" : [ {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/KICVcY6vmx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pUJNAL2AIV",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/06\/church-of-christ-preacher-al-shannon-says-women-who-dress-immodestly-risk-rape-by-lustful-men?_ts=1464967408",
      "display_url" : "brucegerencser.net\/2016\/06\/church\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738752986193793025",
  "text" : "Church of Christ Preacher Al Shannon Says Women Who Dress \"Immodestly\" Risk Rape by Lust... https:\/\/t.co\/pUJNAL2AIV https:\/\/t.co\/KICVcY6vmx",
  "id" : 738752986193793025,
  "created_at" : "2016-06-03 15:23:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738741250086608896",
  "text" : "everything is zika now? what happened to ebola? and the one before that? etc, etc.",
  "id" : 738741250086608896,
  "created_at" : "2016-06-03 14:36:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda",
      "screen_name" : "YoliWriter",
      "indices" : [ 3, 14 ],
      "id_str" : "2743357531",
      "id" : 2743357531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738739539552919553",
  "text" : "RT @YoliWriter: White people, no one is asking you to apologize for your ancestors. We are asking you to dismantle the systems they built a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738218885380374528",
    "text" : "White people, no one is asking you to apologize for your ancestors. We are asking you to dismantle the systems they built and you maintain.",
    "id" : 738218885380374528,
    "created_at" : "2016-06-02 04:01:12 +0000",
    "user" : {
      "name" : "Yolanda",
      "screen_name" : "YoliWriter",
      "protected" : false,
      "id_str" : "2743357531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630960066242310145\/VL_bcwOA_normal.jpg",
      "id" : 2743357531,
      "verified" : false
    }
  },
  "id" : 738739539552919553,
  "created_at" : "2016-06-03 14:30:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "indices" : [ 0, 15 ],
      "id_str" : "24254537",
      "id" : 24254537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738533618989965313",
  "geo" : { },
  "id_str" : "738536884847185921",
  "in_reply_to_user_id" : 24254537,
  "text" : "@GrumpyTheology aww.. so content.",
  "id" : 738536884847185921,
  "in_reply_to_status_id" : 738533618989965313,
  "created_at" : "2016-06-03 01:04:49 +0000",
  "in_reply_to_screen_name" : "GrumpyTheology",
  "in_reply_to_user_id_str" : "24254537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 3, 19 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 127, 130 ]
    }, {
      "text" : "hb2",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738522274253398017",
  "text" : "RT @proudliberalmom: Then kept them away from family &amp; friends. 90% of molestation is done by a friend\/family member. 90%. #p2 #hb2   https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 106, 109 ]
      }, {
        "text" : "hb2",
        "indices" : [ 110, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/4YpjxSH2j0",
        "expanded_url" : "https:\/\/twitter.com\/sbridgeman64\/status\/738136916265078784",
        "display_url" : "twitter.com\/sbridgeman64\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738519160917872640",
    "text" : "Then kept them away from family &amp; friends. 90% of molestation is done by a friend\/family member. 90%. #p2 #hb2   https:\/\/t.co\/4YpjxSH2j0",
    "id" : 738519160917872640,
    "created_at" : "2016-06-02 23:54:23 +0000",
    "user" : {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "protected" : false,
      "id_str" : "292671486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742835194340605953\/oTbZt40x_normal.jpg",
      "id" : 292671486,
      "verified" : false
    }
  },
  "id" : 738522274253398017,
  "created_at" : "2016-06-03 00:06:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/637729516945862657\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/MJjTGx7ipi",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CNmrnctWoAQOZjv.png",
      "id_str" : "637729516459302916",
      "id" : 637729516459302916,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CNmrnctWoAQOZjv.png",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/MJjTGx7ipi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738522028370579456",
  "text" : "RT @SciencePorn: This is how fast the space probe is. https:\/\/t.co\/MJjTGx7ipi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/637729516945862657\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/MJjTGx7ipi",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CNmrnctWoAQOZjv.png",
        "id_str" : "637729516459302916",
        "id" : 637729516459302916,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CNmrnctWoAQOZjv.png",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/MJjTGx7ipi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738519833373990912",
    "text" : "This is how fast the space probe is. https:\/\/t.co\/MJjTGx7ipi",
    "id" : 738519833373990912,
    "created_at" : "2016-06-02 23:57:03 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 738522028370579456,
  "created_at" : "2016-06-03 00:05:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738494072718012416",
  "text" : "RT @Snapzu_Science: Fun Fact: Pluto takes 248 years to orbit the Sun.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738493172444057600",
    "text" : "Fun Fact: Pluto takes 248 years to orbit the Sun.",
    "id" : 738493172444057600,
    "created_at" : "2016-06-02 22:11:07 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 738494072718012416,
  "created_at" : "2016-06-02 22:14:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Zahnd",
      "screen_name" : "BrianZahnd",
      "indices" : [ 3, 14 ],
      "id_str" : "20794662",
      "id" : 20794662
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BrianZahnd\/status\/738159163755233281\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/FUcBPvKfxv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj532FIUUAAnqbZ.jpg",
      "id_str" : "738159159909044224",
      "id" : 738159159909044224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj532FIUUAAnqbZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1203,
        "resize" : "fit",
        "w" : 1911
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FUcBPvKfxv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/HnRetMDo4M",
      "expanded_url" : "http:\/\/brianzahnd.com\/2016\/06\/the-faceless-white-giant\/",
      "display_url" : "brianzahnd.com\/2016\/06\/the-fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738487158546169856",
  "text" : "RT @BrianZahnd: My theologically terrorized adolescence...thanks to Jack Chick. https:\/\/t.co\/HnRetMDo4M https:\/\/t.co\/FUcBPvKfxv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrianZahnd\/status\/738159163755233281\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/FUcBPvKfxv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj532FIUUAAnqbZ.jpg",
        "id_str" : "738159159909044224",
        "id" : 738159159909044224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj532FIUUAAnqbZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1203,
          "resize" : "fit",
          "w" : 1911
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FUcBPvKfxv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/HnRetMDo4M",
        "expanded_url" : "http:\/\/brianzahnd.com\/2016\/06\/the-faceless-white-giant\/",
        "display_url" : "brianzahnd.com\/2016\/06\/the-fa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738159163755233281",
    "text" : "My theologically terrorized adolescence...thanks to Jack Chick. https:\/\/t.co\/HnRetMDo4M https:\/\/t.co\/FUcBPvKfxv",
    "id" : 738159163755233281,
    "created_at" : "2016-06-02 00:03:53 +0000",
    "user" : {
      "name" : "Brian Zahnd",
      "screen_name" : "BrianZahnd",
      "protected" : false,
      "id_str" : "20794662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741503756932505600\/Oh_Sb0E3_normal.jpg",
      "id" : 20794662,
      "verified" : false
    }
  },
  "id" : 738487158546169856,
  "created_at" : "2016-06-02 21:47:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/738486102294691840\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/TQchNTdpJ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj-hMUpWsAAtJCI.jpg",
      "id_str" : "738486096984715264",
      "id" : 738486096984715264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj-hMUpWsAAtJCI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/TQchNTdpJ7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/qN4jLwpkw3",
      "expanded_url" : "http:\/\/brianzahnd.com\/2016\/06\/the-faceless-white-giant?_ts=1464903775",
      "display_url" : "brianzahnd.com\/2016\/06\/the-fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738486102294691840",
  "text" : "The Faceless White Giant - Brian Zahnd https:\/\/t.co\/qN4jLwpkw3 https:\/\/t.co\/TQchNTdpJ7",
  "id" : 738486102294691840,
  "created_at" : "2016-06-02 21:43:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 3, 17 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/irl55M2cgY",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2016\/06\/from-protester-to-peacemaker-a-day-in-the-life-of-a-former-sidewalk-counselor\/",
      "display_url" : "patheos.com\/blogs\/unfundam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738410559725576192",
  "text" : "RT @UnfundieXians: From Protester to Peacemaker: A Day in the Life of a (Former) Sidewalk Counselor https:\/\/t.co\/irl55M2cgY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/irl55M2cgY",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2016\/06\/from-protester-to-peacemaker-a-day-in-the-life-of-a-former-sidewalk-counselor\/",
        "display_url" : "patheos.com\/blogs\/unfundam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738340197029445632",
    "text" : "From Protester to Peacemaker: A Day in the Life of a (Former) Sidewalk Counselor https:\/\/t.co\/irl55M2cgY",
    "id" : 738340197029445632,
    "created_at" : "2016-06-02 12:03:15 +0000",
    "user" : {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "protected" : false,
      "id_str" : "780850862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000612253854\/d369ca7c4cc3d27a5fe05ca11521b685_normal.jpeg",
      "id" : 780850862,
      "verified" : false
    }
  },
  "id" : 738410559725576192,
  "created_at" : "2016-06-02 16:42:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Fall",
      "screen_name" : "tim_fall",
      "indices" : [ 75, 84 ],
      "id_str" : "1232979043",
      "id" : 1232979043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/CuqQtzTOwT",
      "expanded_url" : "https:\/\/timfall.wordpress.com\/2016\/06\/02\/introverted-nihilists-really-know-how-to-party\/",
      "display_url" : "timfall.wordpress.com\/2016\/06\/02\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738410141436026884",
  "text" : "Introverted Nihilists Really Know How To Party https:\/\/t.co\/CuqQtzTOwT via @tim_fall",
  "id" : 738410141436026884,
  "created_at" : "2016-06-02 16:41:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/johnpavlovitz\/status\/738373408010964992\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/1oSvTDw78c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj86syCWgAA3i5F.jpg",
      "id_str" : "738373404932341760",
      "id" : 738373404932341760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj86syCWgAA3i5F.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/1oSvTDw78c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738379624447660032",
  "text" : "RT @johnpavlovitz: Love Now. https:\/\/t.co\/1oSvTDw78c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/johnpavlovitz\/status\/738373408010964992\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/1oSvTDw78c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj86syCWgAA3i5F.jpg",
        "id_str" : "738373404932341760",
        "id" : 738373404932341760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj86syCWgAA3i5F.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/1oSvTDw78c"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738373408010964992",
    "text" : "Love Now. https:\/\/t.co\/1oSvTDw78c",
    "id" : 738373408010964992,
    "created_at" : "2016-06-02 14:15:13 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 738379624447660032,
  "created_at" : "2016-06-02 14:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738379300102152192",
  "text" : "RT @jacqueduncalf: \"Ppsst over ere, i know yer can't see me but if yer see any of me mates looking for me tell them i went that way\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/738377435029352448\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/CIvB3ONKA9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj8-XJ4XIAA0n8i.jpg",
        "id_str" : "738377431422279680",
        "id" : 738377431422279680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj8-XJ4XIAA0n8i.jpg",
        "sizes" : [ {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1071,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/CIvB3ONKA9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738377435029352448",
    "text" : "\"Ppsst over ere, i know yer can't see me but if yer see any of me mates looking for me tell them i went that way\" https:\/\/t.co\/CIvB3ONKA9",
    "id" : 738377435029352448,
    "created_at" : "2016-06-02 14:31:13 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 738379300102152192,
  "created_at" : "2016-06-02 14:38:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dick King-Smith HQ",
      "screen_name" : "DickKingSmith",
      "indices" : [ 3, 17 ],
      "id_str" : "2275883743",
      "id" : 2275883743
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DickKingSmith\/status\/738376775848361988\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/abwAcNeAjA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj89w1gWgAABkx5.jpg",
      "id_str" : "738376773117837312",
      "id" : 738376773117837312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj89w1gWgAABkx5.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/abwAcNeAjA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738379209421279233",
  "text" : "RT @DickKingSmith: Onward, noble steed... https:\/\/t.co\/abwAcNeAjA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DickKingSmith\/status\/738376775848361988\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/abwAcNeAjA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj89w1gWgAABkx5.jpg",
        "id_str" : "738376773117837312",
        "id" : 738376773117837312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj89w1gWgAABkx5.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/abwAcNeAjA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738376775848361988",
    "text" : "Onward, noble steed... https:\/\/t.co\/abwAcNeAjA",
    "id" : 738376775848361988,
    "created_at" : "2016-06-02 14:28:36 +0000",
    "user" : {
      "name" : "Dick King-Smith HQ",
      "screen_name" : "DickKingSmith",
      "protected" : false,
      "id_str" : "2275883743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650626555991998464\/iYH9jea4_normal.jpg",
      "id" : 2275883743,
      "verified" : false
    }
  },
  "id" : 738379209421279233,
  "created_at" : "2016-06-02 14:38:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/GgoYIKvTQt",
      "expanded_url" : "https:\/\/twitter.com\/peatreebojangle\/status\/738325681428402176",
      "display_url" : "twitter.com\/peatreebojangl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738375862186299392",
  "text" : "this cant be true... https:\/\/t.co\/GgoYIKvTQt",
  "id" : 738375862186299392,
  "created_at" : "2016-06-02 14:24:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Groome",
      "screen_name" : "Patrick_Groome",
      "indices" : [ 3, 18 ],
      "id_str" : "2172587311",
      "id" : 2172587311
    }, {
      "name" : "peatree bojangles",
      "screen_name" : "peatreebojangle",
      "indices" : [ 20, 36 ],
      "id_str" : "25502207",
      "id" : 25502207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738375528999194624",
  "text" : "RT @Patrick_Groome: @peatreebojangle It can't be true. It just can't. It's too horrifying to contemplate it being true.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "peatree bojangles",
        "screen_name" : "peatreebojangle",
        "indices" : [ 0, 16 ],
        "id_str" : "25502207",
        "id" : 25502207
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "738325681428402176",
    "geo" : { },
    "id_str" : "738359764611039232",
    "in_reply_to_user_id" : 25502207,
    "text" : "@peatreebojangle It can't be true. It just can't. It's too horrifying to contemplate it being true.",
    "id" : 738359764611039232,
    "in_reply_to_status_id" : 738325681428402176,
    "created_at" : "2016-06-02 13:21:00 +0000",
    "in_reply_to_screen_name" : "peatreebojangle",
    "in_reply_to_user_id_str" : "25502207",
    "user" : {
      "name" : "Patrick Groome",
      "screen_name" : "Patrick_Groome",
      "protected" : false,
      "id_str" : "2172587311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434046911687819265\/AoLy48-6_normal.jpeg",
      "id" : 2172587311,
      "verified" : false
    }
  },
  "id" : 738375528999194624,
  "created_at" : "2016-06-02 14:23:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/e7j1KQG94B",
      "expanded_url" : "https:\/\/twitter.com\/GrillinChillin9\/status\/586208972954181632",
      "display_url" : "twitter.com\/GrillinChillin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738373606586122249",
  "text" : "hehehe.. true. https:\/\/t.co\/e7j1KQG94B",
  "id" : 738373606586122249,
  "created_at" : "2016-06-02 14:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan",
      "screen_name" : "geminicat7",
      "indices" : [ 3, 14 ],
      "id_str" : "1704413916",
      "id" : 1704413916
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/geminicat7\/status\/737985058234109952\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/f1QfhF40wY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3ZbwCWUAAPfd9.jpg",
      "id_str" : "737984984733077504",
      "id" : 737984984733077504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3ZbwCWUAAPfd9.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f1QfhF40wY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738372109597040640",
  "text" : "RT @geminicat7: She's having a little chat with me ... https:\/\/t.co\/f1QfhF40wY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/geminicat7\/status\/737985058234109952\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/f1QfhF40wY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3ZbwCWUAAPfd9.jpg",
        "id_str" : "737984984733077504",
        "id" : 737984984733077504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3ZbwCWUAAPfd9.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/f1QfhF40wY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737985058234109952",
    "text" : "She's having a little chat with me ... https:\/\/t.co\/f1QfhF40wY",
    "id" : 737985058234109952,
    "created_at" : "2016-06-01 12:32:03 +0000",
    "user" : {
      "name" : "Jan",
      "screen_name" : "geminicat7",
      "protected" : false,
      "id_str" : "1704413916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566524030535352320\/e64XS3wl_normal.jpeg",
      "id" : 1704413916,
      "verified" : false
    }
  },
  "id" : 738372109597040640,
  "created_at" : "2016-06-02 14:10:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/738356814748786689\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/o8mmldssHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj8riiUWsAAjVnt.jpg",
      "id_str" : "738356736239775744",
      "id" : 738356736239775744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj8riiUWsAAjVnt.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/o8mmldssHh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/738356814748786689\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/o8mmldssHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj8ritHXEAAQfEw.jpg",
      "id_str" : "738356739138064384",
      "id" : 738356739138064384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj8ritHXEAAQfEw.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/o8mmldssHh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738371748345839616",
  "text" : "RT @Salmonae1: Time for under wing bed.All in,now settle down. https:\/\/t.co\/o8mmldssHh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/738356814748786689\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/o8mmldssHh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj8riiUWsAAjVnt.jpg",
        "id_str" : "738356736239775744",
        "id" : 738356736239775744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj8riiUWsAAjVnt.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/o8mmldssHh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/738356814748786689\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/o8mmldssHh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj8ritHXEAAQfEw.jpg",
        "id_str" : "738356739138064384",
        "id" : 738356739138064384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj8ritHXEAAQfEw.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/o8mmldssHh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738356814748786689",
    "text" : "Time for under wing bed.All in,now settle down. https:\/\/t.co\/o8mmldssHh",
    "id" : 738356814748786689,
    "created_at" : "2016-06-02 13:09:17 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 738371748345839616,
  "created_at" : "2016-06-02 14:08:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/738173793017860097\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/0uw6LL3LVs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj6FJUuUYAAv7ee.jpg",
      "id_str" : "738173784163639296",
      "id" : 738173784163639296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj6FJUuUYAAv7ee.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0uw6LL3LVs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738173793017860097",
  "text" : "We're Listening to The Redemption Engine by James L. Sutter tonight. https:\/\/t.co\/0uw6LL3LVs",
  "id" : 738173793017860097,
  "created_at" : "2016-06-02 01:02:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738102159753912320",
  "geo" : { },
  "id_str" : "738138267200028673",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ugh. sorry you're not feeling well.",
  "id" : 738138267200028673,
  "in_reply_to_status_id" : 738102159753912320,
  "created_at" : "2016-06-01 22:40:51 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Reader",
      "screen_name" : "AbiReader",
      "indices" : [ 3, 13 ],
      "id_str" : "1227440088",
      "id" : 1227440088
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/738014832784506881\/video\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/QIUY2XUGWG",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/738014679566422016\/pu\/img\/423B11S5zHaulvsn.jpg",
      "id_str" : "738014679566422016",
      "id" : 738014679566422016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/738014679566422016\/pu\/img\/423B11S5zHaulvsn.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QIUY2XUGWG"
    } ],
    "hashtags" : [ {
      "text" : "happycows",
      "indices" : [ 59, 69 ]
    }, {
      "text" : "WorldMilkDay",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "teamdairy",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738137474891812864",
  "text" : "RT @AbiReader: Fancy doing this for your co-worker? We do! #happycows #WorldMilkDay #teamdairy https:\/\/t.co\/QIUY2XUGWG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/738014832784506881\/video\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/QIUY2XUGWG",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/738014679566422016\/pu\/img\/423B11S5zHaulvsn.jpg",
        "id_str" : "738014679566422016",
        "id" : 738014679566422016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/738014679566422016\/pu\/img\/423B11S5zHaulvsn.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QIUY2XUGWG"
      } ],
      "hashtags" : [ {
        "text" : "happycows",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "WorldMilkDay",
        "indices" : [ 55, 68 ]
      }, {
        "text" : "teamdairy",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738014832784506881",
    "text" : "Fancy doing this for your co-worker? We do! #happycows #WorldMilkDay #teamdairy https:\/\/t.co\/QIUY2XUGWG",
    "id" : 738014832784506881,
    "created_at" : "2016-06-01 14:30:22 +0000",
    "user" : {
      "name" : "Abi Reader",
      "screen_name" : "AbiReader",
      "protected" : false,
      "id_str" : "1227440088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632430031659098112\/LHjg68y-_normal.png",
      "id" : 1227440088,
      "verified" : false
    }
  },
  "id" : 738137474891812864,
  "created_at" : "2016-06-01 22:37:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim",
      "screen_name" : "jammyjimm",
      "indices" : [ 3, 13 ],
      "id_str" : "351148871",
      "id" : 351148871
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jammyjimm\/status\/737705729822449664\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/eUci5mlkS9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjzbcxRUYAEoY1y.jpg",
      "id_str" : "737705726290714625",
      "id" : 737705726290714625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjzbcxRUYAEoY1y.jpg",
      "sizes" : [ {
        "h" : 1583,
        "resize" : "fit",
        "w" : 2311
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eUci5mlkS9"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/jammyjimm\/status\/737705729822449664\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/eUci5mlkS9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjzbc4TUkAE5Eo6.jpg",
      "id_str" : "737705728178163713",
      "id" : 737705728178163713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjzbc4TUkAE5Eo6.jpg",
      "sizes" : [ {
        "h" : 830,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2303
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eUci5mlkS9"
    } ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738113261086904320",
  "text" : "RT @jammyjimm: 2\/2 However, the Red Grouse and Golden Plover came right down to the car by themselves #birding https:\/\/t.co\/eUci5mlkS9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jammyjimm\/status\/737705729822449664\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/eUci5mlkS9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjzbcxRUYAEoY1y.jpg",
        "id_str" : "737705726290714625",
        "id" : 737705726290714625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjzbcxRUYAEoY1y.jpg",
        "sizes" : [ {
          "h" : 1583,
          "resize" : "fit",
          "w" : 2311
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eUci5mlkS9"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/jammyjimm\/status\/737705729822449664\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/eUci5mlkS9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjzbc4TUkAE5Eo6.jpg",
        "id_str" : "737705728178163713",
        "id" : 737705728178163713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjzbc4TUkAE5Eo6.jpg",
        "sizes" : [ {
          "h" : 830,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1866,
          "resize" : "fit",
          "w" : 2303
        }, {
          "h" : 275,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eUci5mlkS9"
      } ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737705729822449664",
    "text" : "2\/2 However, the Red Grouse and Golden Plover came right down to the car by themselves #birding https:\/\/t.co\/eUci5mlkS9",
    "id" : 737705729822449664,
    "created_at" : "2016-05-31 18:02:06 +0000",
    "user" : {
      "name" : "Jim",
      "screen_name" : "jammyjimm",
      "protected" : false,
      "id_str" : "351148871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797761888520208384\/lwycKUXP_normal.jpg",
      "id" : 351148871,
      "verified" : false
    }
  },
  "id" : 738113261086904320,
  "created_at" : "2016-06-01 21:01:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738095001217990657",
  "text" : "so much &gt; aha, yes, this &lt; Rob Bell \/ Everything is Spiritual (2016 Tour Film)",
  "id" : 738095001217990657,
  "created_at" : "2016-06-01 19:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/c3NwUQUHPt",
      "expanded_url" : "https:\/\/youtu.be\/JT09JbaEh_I",
      "display_url" : "youtu.be\/JT09JbaEh_I"
    } ]
  },
  "geo" : { },
  "id_str" : "738092168666025986",
  "text" : "expand, self transcend and move forward - Rob Bell \/ Everything is Spiritual  https:\/\/t.co\/c3NwUQUHPt",
  "id" : 738092168666025986,
  "created_at" : "2016-06-01 19:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738063308209684480",
  "text" : "I am an exotic cocktail.. lol.. i like it! Thanks, Rob Bell.",
  "id" : 738063308209684480,
  "created_at" : "2016-06-01 17:42:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/c3NwUQUHPt",
      "expanded_url" : "https:\/\/youtu.be\/JT09JbaEh_I",
      "display_url" : "youtu.be\/JT09JbaEh_I"
    } ]
  },
  "geo" : { },
  "id_str" : "738055931834011648",
  "text" : "Rob Bell \/ Everything is Spiritual (2016 Tour Film) https:\/\/t.co\/c3NwUQUHPt \"The sun gives itself for the life of the universe.\"",
  "id" : 738055931834011648,
  "created_at" : "2016-06-01 17:13:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "indices" : [ 3, 18 ],
      "id_str" : "148856572",
      "id" : 148856572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738019896601280512",
  "text" : "RT @Audiobook_Comm: HAPPY AUDIOBOOK MONTH! To help you get in the mood, we're hosting a Sweepstakes where you'll have the chance to... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/PeU6g90cai",
        "expanded_url" : "http:\/\/fb.me\/5xnVLEGYB",
        "display_url" : "fb.me\/5xnVLEGYB"
      } ]
    },
    "geo" : { },
    "id_str" : "738014385080147968",
    "text" : "HAPPY AUDIOBOOK MONTH! To help you get in the mood, we're hosting a Sweepstakes where you'll have the chance to... https:\/\/t.co\/PeU6g90cai",
    "id" : 738014385080147968,
    "created_at" : "2016-06-01 14:28:35 +0000",
    "user" : {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "protected" : false,
      "id_str" : "148856572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716970602259738624\/qDTP4Z12_normal.jpg",
      "id" : 148856572,
      "verified" : false
    }
  },
  "id" : 738019896601280512,
  "created_at" : "2016-06-01 14:50:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hachette Audio",
      "screen_name" : "HachetteAudio",
      "indices" : [ 3, 17 ],
      "id_str" : "300912850",
      "id" : 300912850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveAudiobooks",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738019700051988481",
  "text" : "RT @HachetteAudio: It's June 1st, which means... Happy Audiobook Month!!! Tell us what you enjoy about listening by using #LoveAudiobooks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveAudiobooks",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737994880857845761",
    "text" : "It's June 1st, which means... Happy Audiobook Month!!! Tell us what you enjoy about listening by using #LoveAudiobooks",
    "id" : 737994880857845761,
    "created_at" : "2016-06-01 13:11:05 +0000",
    "user" : {
      "name" : "Hachette Audio",
      "screen_name" : "HachetteAudio",
      "protected" : false,
      "id_str" : "300912850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743507206369337344\/m3bGhEJM_normal.jpg",
      "id" : 300912850,
      "verified" : false
    }
  },
  "id" : 738019700051988481,
  "created_at" : "2016-06-01 14:49:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaska Dispatch News",
      "screen_name" : "adndotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "15828025",
      "id" : 15828025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/tX5eN33d8x",
      "expanded_url" : "http:\/\/www.adn.com\/slideshow\/alaska-news\/2016\/05\/31\/moose-gives-birth-in-the-parking-lot-of-an-anchorage-hardware-store\/",
      "display_url" : "adn.com\/slideshow\/alas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738016440595447809",
  "text" : "RT @adndotcom: A moose calf was born in the parking lot of an East Anchorage hardware store (with video)\nhttps:\/\/t.co\/tX5eN33d8x https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/adndotcom\/status\/738002401093910528\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Ev1JghbxMC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3pRanWEAIc10E.jpg",
        "id_str" : "738002399370022914",
        "id" : 738002399370022914,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3pRanWEAIc10E.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 962,
          "resize" : "fit",
          "w" : 1484
        } ],
        "display_url" : "pic.twitter.com\/Ev1JghbxMC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/tX5eN33d8x",
        "expanded_url" : "http:\/\/www.adn.com\/slideshow\/alaska-news\/2016\/05\/31\/moose-gives-birth-in-the-parking-lot-of-an-anchorage-hardware-store\/",
        "display_url" : "adn.com\/slideshow\/alas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738002401093910528",
    "text" : "A moose calf was born in the parking lot of an East Anchorage hardware store (with video)\nhttps:\/\/t.co\/tX5eN33d8x https:\/\/t.co\/Ev1JghbxMC",
    "id" : 738002401093910528,
    "created_at" : "2016-06-01 13:40:58 +0000",
    "user" : {
      "name" : "Alaska Dispatch News",
      "screen_name" : "adndotcom",
      "protected" : false,
      "id_str" : "15828025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485112369412980736\/SJldw3c7_normal.jpeg",
      "id" : 15828025,
      "verified" : true
    }
  },
  "id" : 738016440595447809,
  "created_at" : "2016-06-01 14:36:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Swanwatchselfie",
      "indices" : [ 92, 108 ]
    }, {
      "text" : "springwatch",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "countryfile",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738015423707381760",
  "text" : "RT @Swanwhisperer: Swanwatch is Proving to be Popular with 900+ swan watchers around the Uk #Swanwatchselfie #springwatch #countryfile http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737965062602817536\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FWJdYxSJfh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3HPa3XEAAErzv.jpg",
        "id_str" : "737964981682114560",
        "id" : 737964981682114560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3HPa3XEAAErzv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FWJdYxSJfh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737965062602817536\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FWJdYxSJfh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3HPqaWgAAkCEx.jpg",
        "id_str" : "737964985855410176",
        "id" : 737964985855410176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3HPqaWgAAkCEx.jpg",
        "sizes" : [ {
          "h" : 347,
          "resize" : "fit",
          "w" : 463
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 463
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 463
        } ],
        "display_url" : "pic.twitter.com\/FWJdYxSJfh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737965062602817536\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FWJdYxSJfh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3HNq_XIAA6qaE.jpg",
        "id_str" : "737964951650902016",
        "id" : 737964951650902016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3HNq_XIAA6qaE.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 233
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 233
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 233
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 233
        } ],
        "display_url" : "pic.twitter.com\/FWJdYxSJfh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737965062602817536\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FWJdYxSJfh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj3HRzFWEAAufCI.jpg",
        "id_str" : "737965022542958592",
        "id" : 737965022542958592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj3HRzFWEAAufCI.jpg",
        "sizes" : [ {
          "h" : 610,
          "resize" : "fit",
          "w" : 415
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 415
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 415
        } ],
        "display_url" : "pic.twitter.com\/FWJdYxSJfh"
      } ],
      "hashtags" : [ {
        "text" : "Swanwatchselfie",
        "indices" : [ 73, 89 ]
      }, {
        "text" : "springwatch",
        "indices" : [ 90, 102 ]
      }, {
        "text" : "countryfile",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737965062602817536",
    "text" : "Swanwatch is Proving to be Popular with 900+ swan watchers around the Uk #Swanwatchselfie #springwatch #countryfile https:\/\/t.co\/FWJdYxSJfh",
    "id" : 737965062602817536,
    "created_at" : "2016-06-01 11:12:36 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 738015423707381760,
  "created_at" : "2016-06-01 14:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]