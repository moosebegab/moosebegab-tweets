Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agent of Chaos\u2199\uFE0F\u2199\uFE0F\u2199\uFE0F",
      "screen_name" : "RealFoodChoice",
      "indices" : [ 3, 18 ],
      "id_str" : "309646250",
      "id" : 309646250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384842192205795328",
  "text" : "RT @RealFoodChoice: We, the people don't have a government. They, the corporations, do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384720352041271296",
    "text" : "We, the people don't have a government. They, the corporations, do.",
    "id" : 384720352041271296,
    "created_at" : "2013-09-30 16:44:14 +0000",
    "user" : {
      "name" : "Agent of Chaos\u2199\uFE0F\u2199\uFE0F\u2199\uFE0F",
      "screen_name" : "RealFoodChoice",
      "protected" : false,
      "id_str" : "309646250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797971923573608448\/VONFAboR_normal.jpg",
      "id" : 309646250,
      "verified" : false
    }
  },
  "id" : 384842192205795328,
  "created_at" : "2013-10-01 00:48:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 0, 11 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384820586251575296",
  "geo" : { },
  "id_str" : "384821835377823744",
  "in_reply_to_user_id" : 187357122,
  "text" : "@Wolf_Mommy teehee.. loved this reply. : )",
  "id" : 384821835377823744,
  "in_reply_to_status_id" : 384820586251575296,
  "created_at" : "2013-09-30 23:27:29 +0000",
  "in_reply_to_screen_name" : "Wolf_Mommy",
  "in_reply_to_user_id_str" : "187357122",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384816557831909376",
  "text" : "RT @PisseArtiste: Horrors of Canadian healthcare: into ER, triaged, X-rays, assessment, discharged in about two hours. Out of pocket cost: \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384816187080597506",
    "text" : "Horrors of Canadian healthcare: into ER, triaged, X-rays, assessment, discharged in about two hours. Out of pocket cost: $0.",
    "id" : 384816187080597506,
    "created_at" : "2013-09-30 23:05:03 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 384816557831909376,
  "created_at" : "2013-09-30 23:06:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384814819146100736",
  "text" : "@1stCitizenKane pass the popcorn, please.",
  "id" : 384814819146100736,
  "created_at" : "2013-09-30 22:59:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corporations",
      "indices" : [ 14, 27 ]
    }, {
      "text" : "individuals",
      "indices" : [ 40, 52 ]
    }, {
      "text" : "serfs",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384812521900609536",
  "text" : "RT @KellyRek: #Corporations do not want #individuals to be empowered ~~&gt; They instead want us to be their #serfs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corporations",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "individuals",
        "indices" : [ 26, 38 ]
      }, {
        "text" : "serfs",
        "indices" : [ 95, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384812147647066112",
    "text" : "#Corporations do not want #individuals to be empowered ~~&gt; They instead want us to be their #serfs.",
    "id" : 384812147647066112,
    "created_at" : "2013-09-30 22:49:00 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 384812521900609536,
  "created_at" : "2013-09-30 22:50:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384810108661678080",
  "text" : ". @1stCitizenKane sighhhhh......",
  "id" : 384810108661678080,
  "created_at" : "2013-09-30 22:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CaroleODell\/status\/384798357555658753\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/alI2TYppTJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVcUES3CAAAZ1qy.jpg",
      "id_str" : "384798357178155008",
      "id" : 384798357178155008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVcUES3CAAAZ1qy.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/alI2TYppTJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384800617719275520",
  "text" : "RT @CaroleODell: And today in Florida.... 7 wood storks. http:\/\/t.co\/alI2TYppTJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CaroleODell\/status\/384798357555658753\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/alI2TYppTJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVcUES3CAAAZ1qy.jpg",
        "id_str" : "384798357178155008",
        "id" : 384798357178155008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVcUES3CAAAZ1qy.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 2560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/alI2TYppTJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384798357555658753",
    "text" : "And today in Florida.... 7 wood storks. http:\/\/t.co\/alI2TYppTJ",
    "id" : 384798357555658753,
    "created_at" : "2013-09-30 21:54:12 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 384800617719275520,
  "created_at" : "2013-09-30 22:03:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Sarah Kendzior",
      "screen_name" : "sarahkendzior",
      "indices" : [ 22, 36 ],
      "id_str" : "47475039",
      "id" : 47475039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384790931460747264",
  "text" : "RT @CharlesBivona: RT @sarahkendzior: BREAKING: The United States of America",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Kendzior",
        "screen_name" : "sarahkendzior",
        "indices" : [ 3, 17 ],
        "id_str" : "47475039",
        "id" : 47475039
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "384788396146577408",
    "geo" : { },
    "id_str" : "384789000432930816",
    "in_reply_to_user_id" : 47475039,
    "text" : "RT @sarahkendzior: BREAKING: The United States of America",
    "id" : 384789000432930816,
    "in_reply_to_status_id" : 384788396146577408,
    "created_at" : "2013-09-30 21:17:01 +0000",
    "in_reply_to_screen_name" : "sarahkendzior",
    "in_reply_to_user_id_str" : "47475039",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 384790931460747264,
  "created_at" : "2013-09-30 21:24:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384783910996959232",
  "geo" : { },
  "id_str" : "384790314528948224",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste will you get good pain meds? lol",
  "id" : 384790314528948224,
  "in_reply_to_status_id" : 384783910996959232,
  "created_at" : "2013-09-30 21:22:14 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew E. Kaufman",
      "screen_name" : "andrewekaufman",
      "indices" : [ 3, 18 ],
      "id_str" : "160072595",
      "id" : 160072595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384734312945315840",
  "text" : "RT @andrewekaufman: 100 free, pre-release copies of DARKNESS &amp; SHADOWS, just waiting to land on Kindles. \n\nJust follow the link, and... htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/ircBB0jMCJ",
        "expanded_url" : "http:\/\/fb.me\/2lskxh8WE",
        "display_url" : "fb.me\/2lskxh8WE"
      } ]
    },
    "geo" : { },
    "id_str" : "384733547925606400",
    "text" : "100 free, pre-release copies of DARKNESS &amp; SHADOWS, just waiting to land on Kindles. \n\nJust follow the link, and... http:\/\/t.co\/ircBB0jMCJ",
    "id" : 384733547925606400,
    "created_at" : "2013-09-30 17:36:40 +0000",
    "user" : {
      "name" : "Andrew E. Kaufman",
      "screen_name" : "andrewekaufman",
      "protected" : false,
      "id_str" : "160072595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760406705888894976\/oedKdkGg_normal.jpg",
      "id" : 160072595,
      "verified" : false
    }
  },
  "id" : 384734312945315840,
  "created_at" : "2013-09-30 17:39:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 27, 39 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nature",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "Travel",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "Photo",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "Bluebirds",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384716695174017025",
  "text" : "RT @KerriFar: Precious! RT @MartinBelan: #Nature &amp; #Travel #Photo of the Day, 5 Fledgling #Bluebirds on a Branch - 9\/30\/13 http:\/\/t.co\/Jav7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Belan",
        "screen_name" : "MartinBelan",
        "indices" : [ 13, 25 ],
        "id_str" : "28461779",
        "id" : 28461779
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 27, 34 ]
      }, {
        "text" : "Travel",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "Photo",
        "indices" : [ 49, 55 ]
      }, {
        "text" : "Bluebirds",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Jav7bSLDYV",
        "expanded_url" : "http:\/\/bit.ly\/18CHSkf",
        "display_url" : "bit.ly\/18CHSkf"
      } ]
    },
    "geo" : { },
    "id_str" : "384710534312251392",
    "text" : "Precious! RT @MartinBelan: #Nature &amp; #Travel #Photo of the Day, 5 Fledgling #Bluebirds on a Branch - 9\/30\/13 http:\/\/t.co\/Jav7bSLDYV",
    "id" : 384710534312251392,
    "created_at" : "2013-09-30 16:05:13 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 384716695174017025,
  "created_at" : "2013-09-30 16:29:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 0, 9 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 10, 22 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384710534312251392",
  "geo" : { },
  "id_str" : "384716674269589504",
  "in_reply_to_user_id" : 12088232,
  "text" : "@KerriFar @MartinBelan squee!",
  "id" : 384716674269589504,
  "in_reply_to_status_id" : 384710534312251392,
  "created_at" : "2013-09-30 16:29:37 +0000",
  "in_reply_to_screen_name" : "KerriFar",
  "in_reply_to_user_id_str" : "12088232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Princeton Nature",
      "screen_name" : "PrincetonNature",
      "indices" : [ 68, 84 ],
      "id_str" : "1112357712",
      "id" : 1112357712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/j4ZPRjxFoA",
      "expanded_url" : "http:\/\/wp.me\/p1VcTe-6it",
      "display_url" : "wp.me\/p1VcTe-6it"
    }, {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/stlPdy65EL",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/2013\/09\/17\/migration-sweepstakes-enter-to-win-everything-you-need-to-make-the-most-of-fall-birdwatching\/",
      "display_url" : "blog.press.princeton.edu\/2013\/09\/17\/mig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384708741414666240",
  "text" : "Win a copy of The Warbler Guide &amp; a pair of Zeiss binoculars at @princetonnature http:\/\/t.co\/j4ZPRjxFoA http:\/\/t.co\/stlPdy65EL",
  "id" : 384708741414666240,
  "created_at" : "2013-09-30 15:58:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipodtouch",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384693430766428160",
  "text" : "hey twitter.. is it worth upgrading from .7mp to 5mp camera? #ipodtouch 4 to ipodtouch 5",
  "id" : 384693430766428160,
  "created_at" : "2013-09-30 14:57:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384669762774921216",
  "geo" : { },
  "id_str" : "384684459204694016",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld aww.. bless you. listening is under-rated.",
  "id" : 384684459204694016,
  "in_reply_to_status_id" : 384669762774921216,
  "created_at" : "2013-09-30 14:21:36 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Zuckerman",
      "screen_name" : "EthanZ",
      "indices" : [ 3, 10 ],
      "id_str" : "1051171",
      "id" : 1051171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384681717799202817",
  "text" : "RT @EthanZ: As our dysfunctional gov't prepares to shutdown, thoughts on a healthcare system that would be worth fighting for: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5uohmesJAY",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/sep\/30\/single-payer-cure-healthcare-reform",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "384676565490995200",
    "text" : "As our dysfunctional gov't prepares to shutdown, thoughts on a healthcare system that would be worth fighting for: http:\/\/t.co\/5uohmesJAY",
    "id" : 384676565490995200,
    "created_at" : "2013-09-30 13:50:14 +0000",
    "user" : {
      "name" : "Ethan Zuckerman",
      "screen_name" : "EthanZ",
      "protected" : false,
      "id_str" : "1051171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659351758704136193\/5jUqQnv0_normal.jpg",
      "id" : 1051171,
      "verified" : false
    }
  },
  "id" : 384681717799202817,
  "created_at" : "2013-09-30 14:10:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384463183215206400",
  "text" : "i really dont like autumn weather.. i can die of the heat and freeze to death in same day.. ugh.",
  "id" : 384463183215206400,
  "created_at" : "2013-09-29 23:42:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384461432181370881",
  "text" : "RT @adamrshields: Also anyone that wants to post guest reviews to Bookwi.se, I would love to talk. I have a baby coming in 5 weeks &amp; need s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384457207234166784",
    "text" : "Also anyone that wants to post guest reviews to Bookwi.se, I would love to talk. I have a baby coming in 5 weeks &amp; need some more reviews",
    "id" : 384457207234166784,
    "created_at" : "2013-09-29 23:18:35 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 384461432181370881,
  "created_at" : "2013-09-29 23:35:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384452274774626304",
  "geo" : { },
  "id_str" : "384453934850396160",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields lol",
  "id" : 384453934850396160,
  "in_reply_to_status_id" : 384452274774626304,
  "created_at" : "2013-09-29 23:05:35 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallSt",
      "indices" : [ 3, 16 ],
      "id_str" : "335369838",
      "id" : 335369838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384414094012317696",
  "text" : "RT @OccupyWallSt: Not three weeks ago, we had $ to go to war, but now we can't support basic needs for our communities. How does that work?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shutdown",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384308346985381888",
    "text" : "Not three weeks ago, we had $ to go to war, but now we can't support basic needs for our communities. How does that work? #shutdown",
    "id" : 384308346985381888,
    "created_at" : "2013-09-29 13:27:04 +0000",
    "user" : {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallSt",
      "protected" : false,
      "id_str" : "335369838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688157754343555074\/2dEO8rYB_normal.png",
      "id" : 335369838,
      "verified" : false
    }
  },
  "id" : 384414094012317696,
  "created_at" : "2013-09-29 20:27:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384343161717280768",
  "geo" : { },
  "id_str" : "384343964431577088",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni oh dear ((hugs))",
  "id" : 384343964431577088,
  "in_reply_to_status_id" : 384343161717280768,
  "created_at" : "2013-09-29 15:48:36 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384330850403250176",
  "text" : "wondering if i want to wear gloves w my prom dress...",
  "id" : 384330850403250176,
  "created_at" : "2013-09-29 14:56:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384325947500945410",
  "geo" : { },
  "id_str" : "384327724686258176",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater &lt;3",
  "id" : 384327724686258176,
  "in_reply_to_status_id" : 384325947500945410,
  "created_at" : "2013-09-29 14:44:04 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384327619677663233",
  "text" : "RT @TyrusBooks: Anyway, it's Sunday, and I love you all, and I hope you have a great day. No matter how much they try to stop us, we are no\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384323922902007808",
    "text" : "Anyway, it's Sunday, and I love you all, and I hope you have a great day. No matter how much they try to stop us, we are not doomed. #love",
    "id" : 384323922902007808,
    "created_at" : "2013-09-29 14:28:58 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 384327619677663233,
  "created_at" : "2013-09-29 14:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384313980518268928",
  "text" : "RT @CaroleODell: When we stop speaking freely, we cease to be free.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384302570212036608",
    "text" : "When we stop speaking freely, we cease to be free.",
    "id" : 384302570212036608,
    "created_at" : "2013-09-29 13:04:07 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 384313980518268928,
  "created_at" : "2013-09-29 13:49:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthWarehouse.com",
      "screen_name" : "healthwarehouse",
      "indices" : [ 74, 90 ],
      "id_str" : "3924841",
      "id" : 3924841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 51, 59 ]
    }, {
      "text" : "ACA",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384312080079130626",
  "text" : "i currently pay &lt; 50 for 3 mo supply of generic #effexor (tier 3) from @healthwarehouse .. cheaper than insurance. #ACA",
  "id" : 384312080079130626,
  "created_at" : "2013-09-29 13:41:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    }, {
      "name" : "hcole",
      "screen_name" : "hencole",
      "indices" : [ 102, 110 ],
      "id_str" : "485806762",
      "id" : 485806762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nurses",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "HealthCare",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384143564008992768",
  "text" : "RT @KellyRek: Changing licensing restrictions to allow #nurses to do #HealthCare ... Link provided by @hencole =&gt; [Mercatus] http:\/\/t.co\/Et\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hcole",
        "screen_name" : "hencole",
        "indices" : [ 88, 96 ],
        "id_str" : "485806762",
        "id" : 485806762
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nurses",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "HealthCare",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Etiv7Hyd20",
        "expanded_url" : "http:\/\/bit.ly\/15ybMSV",
        "display_url" : "bit.ly\/15ybMSV"
      } ]
    },
    "geo" : { },
    "id_str" : "383550455294328832",
    "text" : "Changing licensing restrictions to allow #nurses to do #HealthCare ... Link provided by @hencole =&gt; [Mercatus] http:\/\/t.co\/Etiv7Hyd20",
    "id" : 383550455294328832,
    "created_at" : "2013-09-27 11:15:29 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 384143564008992768,
  "created_at" : "2013-09-29 02:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 92, 101 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/wIiHNdi4RF",
      "expanded_url" : "http:\/\/www.upworthy.com\/a-hidden-camera-show-goes-to-texas-it-did-not-expect-to-find-this?g=2&c=ufb2",
      "display_url" : "upworthy.com\/a-hidden-camer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384139169632509952",
  "text" : "RT @atheistlady76: A hidden camera show goes to Texas. It did not expect to find this. (via @Upworthy) http:\/\/t.co\/wIiHNdi4RF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Upworthy",
        "screen_name" : "Upworthy",
        "indices" : [ 73, 82 ],
        "id_str" : "524396430",
        "id" : 524396430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/wIiHNdi4RF",
        "expanded_url" : "http:\/\/www.upworthy.com\/a-hidden-camera-show-goes-to-texas-it-did-not-expect-to-find-this?g=2&c=ufb2",
        "display_url" : "upworthy.com\/a-hidden-camer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "384134532984614912",
    "text" : "A hidden camera show goes to Texas. It did not expect to find this. (via @Upworthy) http:\/\/t.co\/wIiHNdi4RF",
    "id" : 384134532984614912,
    "created_at" : "2013-09-29 01:56:24 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 384139169632509952,
  "created_at" : "2013-09-29 02:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/UvrWs1iYRK",
      "expanded_url" : "http:\/\/www.naturalnews.com\/042258_coma_patients_fully_conscious_paralyzed.html",
      "display_url" : "naturalnews.com\/042258_coma_pa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384095708325748736",
  "text" : "RT @HealthRanger: Man diagnosed as 'comatose' for 23 years was actually fully conscious, but paralyzed http:\/\/t.co\/UvrWs1iYRK via @HealthRa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthRanger",
        "screen_name" : "HealthRanger",
        "indices" : [ 112, 125 ],
        "id_str" : "15843059",
        "id" : 15843059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/UvrWs1iYRK",
        "expanded_url" : "http:\/\/www.naturalnews.com\/042258_coma_patients_fully_conscious_paralyzed.html",
        "display_url" : "naturalnews.com\/042258_coma_pa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "384085167851044867",
    "text" : "Man diagnosed as 'comatose' for 23 years was actually fully conscious, but paralyzed http:\/\/t.co\/UvrWs1iYRK via @HealthRanger",
    "id" : 384085167851044867,
    "created_at" : "2013-09-28 22:40:14 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 384095708325748736,
  "created_at" : "2013-09-28 23:22:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne T. Donahue",
      "screen_name" : "annetdonahue",
      "indices" : [ 3, 16 ],
      "id_str" : "22419345",
      "id" : 22419345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384094174439428096",
  "text" : "RT @annetdonahue: \"Mommy, WHY did adults hate Miley Cyrus so much?\" - \"Well honey, she grew up on the stage they created for her, then reac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384084806440468481",
    "text" : "\"Mommy, WHY did adults hate Miley Cyrus so much?\" - \"Well honey, she grew up on the stage they created for her, then reacted accordingly.\"",
    "id" : 384084806440468481,
    "created_at" : "2013-09-28 22:38:48 +0000",
    "user" : {
      "name" : "Anne T. Donahue",
      "screen_name" : "annetdonahue",
      "protected" : false,
      "id_str" : "22419345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800763078237360128\/ZKf723fW_normal.jpg",
      "id" : 22419345,
      "verified" : true
    }
  },
  "id" : 384094174439428096,
  "created_at" : "2013-09-28 23:16:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Bev",
      "screen_name" : "Justbirds1",
      "indices" : [ 17, 28 ],
      "id_str" : "291680688",
      "id" : 291680688
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "photography",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/BWM6Jeazy8",
      "expanded_url" : "http:\/\/goo.gl\/yddGu",
      "display_url" : "goo.gl\/yddGu"
    } ]
  },
  "geo" : { },
  "id_str" : "384092689160876032",
  "text" : "RT @KerriFar: RT @Justbirds1: Two of a Kind http:\/\/t.co\/BWM6Jeazy8 #birds #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bev",
        "screen_name" : "Justbirds1",
        "indices" : [ 3, 14 ],
        "id_str" : "291680688",
        "id" : 291680688
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "photography",
        "indices" : [ 60, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/BWM6Jeazy8",
        "expanded_url" : "http:\/\/goo.gl\/yddGu",
        "display_url" : "goo.gl\/yddGu"
      } ]
    },
    "in_reply_to_status_id_str" : "384068267687804928",
    "geo" : { },
    "id_str" : "384091529276821504",
    "in_reply_to_user_id" : 291680688,
    "text" : "RT @Justbirds1: Two of a Kind http:\/\/t.co\/BWM6Jeazy8 #birds #photography",
    "id" : 384091529276821504,
    "in_reply_to_status_id" : 384068267687804928,
    "created_at" : "2013-09-28 23:05:31 +0000",
    "in_reply_to_screen_name" : "Justbirds1",
    "in_reply_to_user_id_str" : "291680688",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 384092689160876032,
  "created_at" : "2013-09-28 23:10:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonny Eachus",
      "screen_name" : "eachus",
      "indices" : [ 0, 7 ],
      "id_str" : "17164665",
      "id" : 17164665
    }, {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 22, 34 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384070538227773440",
  "geo" : { },
  "id_str" : "384080338298761218",
  "in_reply_to_user_id" : 17164665,
  "text" : "@eachus yes,yes,yes!! @CoyoteSings",
  "id" : 384080338298761218,
  "in_reply_to_status_id" : 384070538227773440,
  "created_at" : "2013-09-28 22:21:03 +0000",
  "in_reply_to_screen_name" : "eachus",
  "in_reply_to_user_id_str" : "17164665",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384080161424932864",
  "text" : "RT @CoyoteSings: Yes, auto insurance is mandatory, unless you don't have a car. Try going without a body... #Obamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384071820971749378",
    "text" : "Yes, auto insurance is mandatory, unless you don't have a car. Try going without a body... #Obamacare",
    "id" : 384071820971749378,
    "created_at" : "2013-09-28 21:47:12 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 384080161424932864,
  "created_at" : "2013-09-28 22:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JohnFugelsang\/status\/384072690375876608\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Ox9BVD9yei",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVSAE64IYAAP84s.jpg",
      "id_str" : "384072690245853184",
      "id" : 384072690245853184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVSAE64IYAAP84s.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 316
      } ],
      "display_url" : "pic.twitter.com\/Ox9BVD9yei"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384079966960222208",
  "text" : "RT @JohnFugelsang: Be an atheist, be a believer, just don't be a dick. http:\/\/t.co\/Ox9BVD9yei",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnFugelsang\/status\/384072690375876608\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/Ox9BVD9yei",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVSAE64IYAAP84s.jpg",
        "id_str" : "384072690245853184",
        "id" : 384072690245853184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVSAE64IYAAP84s.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 316
        } ],
        "display_url" : "pic.twitter.com\/Ox9BVD9yei"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384072690375876608",
    "text" : "Be an atheist, be a believer, just don't be a dick. http:\/\/t.co\/Ox9BVD9yei",
    "id" : 384072690375876608,
    "created_at" : "2013-09-28 21:50:39 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 384079966960222208,
  "created_at" : "2013-09-28 22:19:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 2, 14 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 105, 117 ]
    }, {
      "text" : "liberal",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384077665705029632",
  "geo" : { },
  "id_str" : "384078777052962816",
  "in_reply_to_user_id" : 118573185,
  "text" : ". @CoyoteSings im not thrilled w obamacare (forced into buying a plan; penalty for non-purchase.) I want #SinglePayer. Im #liberal.",
  "id" : 384078777052962816,
  "in_reply_to_status_id" : 384077665705029632,
  "created_at" : "2013-09-28 22:14:50 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384068000879349760",
  "text" : "RT @CoyoteSings: I object to the fact that Obamacare is labeled as \"health care reform.\" I object to any \"reform\" that penalizes you for no\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FAIL",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384067852371652608",
    "text" : "I object to the fact that Obamacare is labeled as \"health care reform.\" I object to any \"reform\" that penalizes you for not buying it. #FAIL",
    "id" : 384067852371652608,
    "created_at" : "2013-09-28 21:31:26 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 384068000879349760,
  "created_at" : "2013-09-28 21:32:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "MinsMessage",
      "indices" : [ 3, 15 ],
      "id_str" : "415567842",
      "id" : 415567842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384064547209752576",
  "text" : "RT @MinsMessage: When you\u2019re on the verge of going insane, you\u2019re either about to become a lunatic or a mystic! Jennifer Starlight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384064354963820544",
    "text" : "When you\u2019re on the verge of going insane, you\u2019re either about to become a lunatic or a mystic! Jennifer Starlight",
    "id" : 384064354963820544,
    "created_at" : "2013-09-28 21:17:32 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "MinsMessage",
      "protected" : false,
      "id_str" : "415567842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645231252\/buddha_light_normal.jpg",
      "id" : 415567842,
      "verified" : false
    }
  },
  "id" : 384064547209752576,
  "created_at" : "2013-09-28 21:18:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384051022953332736",
  "text" : "got a bra at victoria's secret today. impressed with customer service. they made me feel special. : )",
  "id" : 384051022953332736,
  "created_at" : "2013-09-28 20:24:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383972900190969857",
  "text" : "Dear Universe, thank you for the wonderful things you've sent my way. Love, Gabrielle xoxoxo",
  "id" : 383972900190969857,
  "created_at" : "2013-09-28 15:14:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383972524028985344",
  "text" : "RT @angelaharms: Grateful for the people in my life who remind me that I'm a beautiful, sexy, courageous loving badass. :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383964375914409984",
    "text" : "Grateful for the people in my life who remind me that I'm a beautiful, sexy, courageous loving badass. :-)",
    "id" : 383964375914409984,
    "created_at" : "2013-09-28 14:40:15 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 383972524028985344,
  "created_at" : "2013-09-28 15:12:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383972182964965376",
  "text" : "RT @DoreenVirtue444: Everyone is working on a soul-growth lesson.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383969600548773888",
    "text" : "Everyone is working on a soul-growth lesson.",
    "id" : 383969600548773888,
    "created_at" : "2013-09-28 15:01:01 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 383972182964965376,
  "created_at" : "2013-09-28 15:11:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 0, 9 ],
      "id_str" : "64009474",
      "id" : 64009474
    }, {
      "name" : "Superguts\u2122",
      "screen_name" : "superguts",
      "indices" : [ 10, 20 ],
      "id_str" : "56390535",
      "id" : 56390535
    }, {
      "name" : "Marty Beaudet",
      "screen_name" : "AuthorMartyB",
      "indices" : [ 57, 70 ],
      "id_str" : "184512841",
      "id" : 184512841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383949061558005760",
  "geo" : { },
  "id_str" : "383953816598507520",
  "in_reply_to_user_id" : 64009474,
  "text" : "@Adenovir @superguts read \"By a Thread\" by Marty Beaudet @AuthorMartyB .. scare your pants off!",
  "id" : 383953816598507520,
  "in_reply_to_status_id" : 383949061558005760,
  "created_at" : "2013-09-28 13:58:18 +0000",
  "in_reply_to_screen_name" : "Adenovir",
  "in_reply_to_user_id_str" : "64009474",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/EahzWgEgID",
      "expanded_url" : "http:\/\/amzn.to\/12JyWTk",
      "display_url" : "amzn.to\/12JyWTk"
    } ]
  },
  "geo" : { },
  "id_str" : "383780782734835712",
  "text" : "finished Jigsaw Soul by Scott  Middlemist http:\/\/t.co\/EahzWgEgID",
  "id" : 383780782734835712,
  "created_at" : "2013-09-28 02:30:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divine Truth",
      "screen_name" : "DivineTruth_LRE",
      "indices" : [ 3, 19 ],
      "id_str" : "189796455",
      "id" : 189796455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383763120336175104",
  "text" : "RT @DivineTruth_LRE: So, again we say, God is energy of love, and It makes everything existent and alive.(For details:http:\/\/t.co\/aftm5ho8T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/aftm5ho8T0",
        "expanded_url" : "http:\/\/bit.ly\/c85gfW",
        "display_url" : "bit.ly\/c85gfW"
      } ]
    },
    "geo" : { },
    "id_str" : "383761879820013568",
    "text" : "So, again we say, God is energy of love, and It makes everything existent and alive.(For details:http:\/\/t.co\/aftm5ho8T0)",
    "id" : 383761879820013568,
    "created_at" : "2013-09-28 01:15:36 +0000",
    "user" : {
      "name" : "Divine Truth",
      "screen_name" : "DivineTruth_LRE",
      "protected" : false,
      "id_str" : "189796455",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1127135297\/lemriaSymbol_111_normal.JPG",
      "id" : 189796455,
      "verified" : false
    }
  },
  "id" : 383763120336175104,
  "created_at" : "2013-09-28 01:20:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    }, {
      "name" : "Jake Majka",
      "screen_name" : "Pizza_Fiend",
      "indices" : [ 45, 57 ],
      "id_str" : "1965810614",
      "id" : 1965810614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383759198489939968",
  "text" : "@1stCitizenKane why does it suggest in body? @PIZZA_FIEND",
  "id" : 383759198489939968,
  "created_at" : "2013-09-28 01:04:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Majka",
      "screen_name" : "Pizza_Fiend",
      "indices" : [ 0, 12 ],
      "id_str" : "1965810614",
      "id" : 1965810614
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 55, 70 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383758891034873856",
  "text" : "@PIZZA_FIEND yes to this and previous tweets (i agree) @1stCitizenKane",
  "id" : 383758891034873856,
  "created_at" : "2013-09-28 01:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383758185833967617",
  "text" : "@1stCitizenKane good question",
  "id" : 383758185833967617,
  "created_at" : "2013-09-28 01:00:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Majka",
      "screen_name" : "Pizza_Fiend",
      "indices" : [ 0, 12 ],
      "id_str" : "1965810614",
      "id" : 1965810614
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 50, 65 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383757739429990401",
  "text" : "@PIZZA_FIEND what is difference between the two?  @1stCitizenKane",
  "id" : 383757739429990401,
  "created_at" : "2013-09-28 00:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 19, 30 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 55, 67 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/d4r6y3Bm1G",
      "expanded_url" : "http:\/\/www.sanders.senate.gov\/polls\/health-care?utm_source=berniebuzz&utm_medium=email&utm_content=Should+the+government+be+shut+down+unless+the+2010+health+law+is+defunded+prompt_url&utm_campaign=National+Bernie+Buzz+09-28",
      "display_url" : "sanders.senate.gov\/polls\/health-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383747033082769408",
  "text" : "RT @AllOnMedicare: @SenSanders asks you if you support #SinglePayer #MedicareForAll: http:\/\/t.co\/d4r6y3Bm1G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Sanders",
        "screen_name" : "SenSanders",
        "indices" : [ 0, 11 ],
        "id_str" : "29442313",
        "id" : 29442313
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 36, 48 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 49, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/d4r6y3Bm1G",
        "expanded_url" : "http:\/\/www.sanders.senate.gov\/polls\/health-care?utm_source=berniebuzz&utm_medium=email&utm_content=Should+the+government+be+shut+down+unless+the+2010+health+law+is+defunded+prompt_url&utm_campaign=National+Bernie+Buzz+09-28",
        "display_url" : "sanders.senate.gov\/polls\/health-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383726258191740929",
    "in_reply_to_user_id" : 29442313,
    "text" : "@SenSanders asks you if you support #SinglePayer #MedicareForAll: http:\/\/t.co\/d4r6y3Bm1G",
    "id" : 383726258191740929,
    "created_at" : "2013-09-27 22:54:03 +0000",
    "in_reply_to_screen_name" : "SenSanders",
    "in_reply_to_user_id_str" : "29442313",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 383747033082769408,
  "created_at" : "2013-09-28 00:16:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383745550505353218",
  "text" : "RT @nakedpastor: My experience was that I pushed and pushed my idea of God to the limit until the limit broke and God was no longer \"there\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383728260435042304",
    "text" : "My experience was that I pushed and pushed my idea of God to the limit until the limit broke and God was no longer \"there\".",
    "id" : 383728260435042304,
    "created_at" : "2013-09-27 23:02:01 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 383745550505353218,
  "created_at" : "2013-09-28 00:10:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383718381758607361",
  "geo" : { },
  "id_str" : "383720546820567040",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time you know it, girl! ((hugs)) and a ((highfive)) for new response : )",
  "id" : 383720546820567040,
  "in_reply_to_status_id" : 383718381758607361,
  "created_at" : "2013-09-27 22:31:22 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress.com",
      "screen_name" : "eMysteries",
      "indices" : [ 3, 14 ],
      "id_str" : "346852354",
      "id" : 346852354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383712119478181888",
  "text" : "RT @eMysteries: Want to win an advance copy of BORDER ANGELS, Anthony Quinn's follow up to his acclaimed novel, DISAPPEARED?http:\/\/t.co\/GCD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/GCD5YgmOHo",
        "expanded_url" : "http:\/\/mysteriouspress.com\/blog\/win-an-advance-copy-of-anthony-quinns-new-novel-border-angels.asp",
        "display_url" : "mysteriouspress.com\/blog\/win-an-ad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383701591699628033",
    "text" : "Want to win an advance copy of BORDER ANGELS, Anthony Quinn's follow up to his acclaimed novel, DISAPPEARED?http:\/\/t.co\/GCD5YgmOHo",
    "id" : 383701591699628033,
    "created_at" : "2013-09-27 21:16:02 +0000",
    "user" : {
      "name" : "MysteriousPress.com",
      "screen_name" : "eMysteries",
      "protected" : false,
      "id_str" : "346852354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533239878\/MYsteriousPress_copy123_twitter_normal.jpg",
      "id" : 346852354,
      "verified" : false
    }
  },
  "id" : 383712119478181888,
  "created_at" : "2013-09-27 21:57:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383711602320486401",
  "text" : "@weakSquare awww...",
  "id" : 383711602320486401,
  "created_at" : "2013-09-27 21:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383710338345992193",
  "text" : "i almost had a pretty baby blue dress today but it just didnt look quite right and the sheer overblouse was too tight. sigh.",
  "id" : 383710338345992193,
  "created_at" : "2013-09-27 21:50:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxana Jones",
      "screen_name" : "roxanamjones",
      "indices" : [ 3, 16 ],
      "id_str" : "269023982",
      "id" : 269023982
    }, {
      "name" : "Lee Vickers LWi",
      "screen_name" : "LIGHTWorkersi",
      "indices" : [ 97, 111 ],
      "id_str" : "19957685",
      "id" : 19957685
    }, {
      "name" : "Markeithia Silver",
      "screen_name" : "MarkeithiaLavon",
      "indices" : [ 116, 132 ],
      "id_str" : "27170542",
      "id" : 27170542
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsEarthPics\/status\/374895362546618368\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/9qgu2u19EN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTPlWIFIQAAodcV.jpg",
      "id_str" : "374895362290761728",
      "id" : 374895362290761728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTPlWIFIQAAodcV.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 583
      } ],
      "display_url" : "pic.twitter.com\/9qgu2u19EN"
    } ],
    "hashtags" : [ {
      "text" : "HELP",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383630887314657281",
  "text" : "RT @roxanamjones: WE ARE HERE TO #HELP EACH OTHER Sleeping baby turtle! http:\/\/t.co\/9qgu2u19EN\u201D ~@LIGHTWorkersi via @MarkeithiaLavon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lee Vickers LWi",
        "screen_name" : "LIGHTWorkersi",
        "indices" : [ 79, 93 ],
        "id_str" : "19957685",
        "id" : 19957685
      }, {
        "name" : "Markeithia Silver",
        "screen_name" : "MarkeithiaLavon",
        "indices" : [ 98, 114 ],
        "id_str" : "27170542",
        "id" : 27170542
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsEarthPics\/status\/374895362546618368\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/9qgu2u19EN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTPlWIFIQAAodcV.jpg",
        "id_str" : "374895362290761728",
        "id" : 374895362290761728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTPlWIFIQAAodcV.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 583
        } ],
        "display_url" : "pic.twitter.com\/9qgu2u19EN"
      } ],
      "hashtags" : [ {
        "text" : "HELP",
        "indices" : [ 15, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383618706607452160",
    "text" : "WE ARE HERE TO #HELP EACH OTHER Sleeping baby turtle! http:\/\/t.co\/9qgu2u19EN\u201D ~@LIGHTWorkersi via @MarkeithiaLavon",
    "id" : 383618706607452160,
    "created_at" : "2013-09-27 15:46:41 +0000",
    "user" : {
      "name" : "Roxana Jones",
      "screen_name" : "roxanamjones",
      "protected" : false,
      "id_str" : "269023982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625449714264047616\/7rrfNcTx_normal.jpg",
      "id" : 269023982,
      "verified" : false
    }
  },
  "id" : 383630887314657281,
  "created_at" : "2013-09-27 16:35:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 3, 17 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383630389400449024",
  "text" : "RT @LilMissCoyote: Sanity is the disease. Lunacy is the cure. AWOOOOOOOOOOOOOOOOOO!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383626411442851840",
    "text" : "Sanity is the disease. Lunacy is the cure. AWOOOOOOOOOOOOOOOOOO!",
    "id" : 383626411442851840,
    "created_at" : "2013-09-27 16:17:18 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 383630389400449024,
  "created_at" : "2013-09-27 16:33:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383437322106060802",
  "geo" : { },
  "id_str" : "383628965077741568",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia i knew there was a reason i liked you! : ) @weakSquare",
  "id" : 383628965077741568,
  "in_reply_to_status_id" : 383437322106060802,
  "created_at" : "2013-09-27 16:27:27 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prodigal",
      "screen_name" : "Prodigal",
      "indices" : [ 58, 67 ],
      "id_str" : "3028734702",
      "id" : 3028734702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/9gYRoOOZpj",
      "expanded_url" : "http:\/\/shar.es\/KhJ1U",
      "display_url" : "shar.es\/KhJ1U"
    } ]
  },
  "geo" : { },
  "id_str" : "383628302209916928",
  "text" : "She Yelled And Called Me Names http:\/\/t.co\/9gYRoOOZpj via @prodigal #kindness",
  "id" : 383628302209916928,
  "created_at" : "2013-09-27 16:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383355324129742848",
  "geo" : { },
  "id_str" : "383356689774149632",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses the same as yesterday.. senators talking. was watching on\/off. cant remember anything particular..lol",
  "id" : 383356689774149632,
  "in_reply_to_status_id" : 383355324129742848,
  "created_at" : "2013-09-26 22:25:31 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 20, 30 ]
    }, {
      "text" : "insurance",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383355056277307393",
  "text" : "RT @KellyRek: Under #ObamaCare, there's an illusion of \"competition\" &amp; \"choice\" of #insurance plans, when those plans are owned by the SAME\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 6, 16 ]
      }, {
        "text" : "insurance",
        "indices" : [ 73, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383351440095186944",
    "text" : "Under #ObamaCare, there's an illusion of \"competition\" &amp; \"choice\" of #insurance plans, when those plans are owned by the SAME damn company.",
    "id" : 383351440095186944,
    "created_at" : "2013-09-26 22:04:40 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 383355056277307393,
  "created_at" : "2013-09-26 22:19:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 20, 30 ]
    }, {
      "text" : "insurance",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383350684461981696",
  "text" : "RT @KellyRek: Under #ObamaCare, I'd be mandated to buy the more EXPENSIVE #insurance plans to retain access to my doctor. (The cheaper plan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 6, 16 ]
      }, {
        "text" : "insurance",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383350500994719745",
    "text" : "Under #ObamaCare, I'd be mandated to buy the more EXPENSIVE #insurance plans to retain access to my doctor. (The cheaper plans deny that.)",
    "id" : 383350500994719745,
    "created_at" : "2013-09-26 22:00:56 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 383350684461981696,
  "created_at" : "2013-09-26 22:01:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383334544230739969",
  "text" : "RT @SenSanders: The U.S. spends more money on health care while getting less in return than all but two other nations.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383333928662085632",
    "text" : "The U.S. spends more money on health care while getting less in return than all but two other nations.",
    "id" : 383333928662085632,
    "created_at" : "2013-09-26 20:55:05 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 383334544230739969,
  "created_at" : "2013-09-26 20:57:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sara powell",
      "screen_name" : "kaleidoscopesf",
      "indices" : [ 3, 18 ],
      "id_str" : "78859950",
      "id" : 78859950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "US",
      "indices" : [ 29, 32 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 49, 61 ]
    }, {
      "text" : "healthcare",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "obamacare",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/arYV31OoU7",
      "expanded_url" : "http:\/\/fb.me\/10iMV7qrb",
      "display_url" : "fb.me\/10iMV7qrb"
    } ]
  },
  "geo" : { },
  "id_str" : "383332565173534720",
  "text" : "RT @kaleidoscopesf: Yes! The #US is past due for #singlepayer #healthcare. Screw #obamacare. It sucks http:\/\/t.co\/arYV31OoU7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "US",
        "indices" : [ 9, 12 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 29, 41 ]
      }, {
        "text" : "healthcare",
        "indices" : [ 42, 53 ]
      }, {
        "text" : "obamacare",
        "indices" : [ 61, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/arYV31OoU7",
        "expanded_url" : "http:\/\/fb.me\/10iMV7qrb",
        "display_url" : "fb.me\/10iMV7qrb"
      } ]
    },
    "geo" : { },
    "id_str" : "383323820754739200",
    "text" : "Yes! The #US is past due for #singlepayer #healthcare. Screw #obamacare. It sucks http:\/\/t.co\/arYV31OoU7",
    "id" : 383323820754739200,
    "created_at" : "2013-09-26 20:14:55 +0000",
    "user" : {
      "name" : "sara powell",
      "screen_name" : "kaleidoscopesf",
      "protected" : false,
      "id_str" : "78859950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3681691999\/4483d36b9e643e28762912a44ea5e61c_normal.jpeg",
      "id" : 78859950,
      "verified" : false
    }
  },
  "id" : 383332565173534720,
  "created_at" : "2013-09-26 20:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383331362411130880",
  "geo" : { },
  "id_str" : "383332159554998272",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen ((hugs))",
  "id" : 383332159554998272,
  "in_reply_to_status_id" : 383331362411130880,
  "created_at" : "2013-09-26 20:48:03 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 79, 91 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 92, 107 ]
    }, {
      "text" : "AetnaMyHealthy",
      "indices" : [ 108, 123 ]
    }, {
      "text" : "ObamaCare",
      "indices" : [ 124, 134 ]
    }, {
      "text" : "HCR",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/NLxWNZlnZx",
      "expanded_url" : "http:\/\/nader.org\/2013\/09\/26\/people-want-full-medicare-for-all\/",
      "display_url" : "nader.org\/2013\/09\/26\/peo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383332068853157888",
  "text" : "RT @AllOnMedicare: People Want Full Medicare for All -  http:\/\/t.co\/NLxWNZlnZx #SinglePayer #MedicareForAll #AetnaMyHealthy #ObamaCare #HCR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 60, 72 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 73, 88 ]
      }, {
        "text" : "AetnaMyHealthy",
        "indices" : [ 89, 104 ]
      }, {
        "text" : "ObamaCare",
        "indices" : [ 105, 115 ]
      }, {
        "text" : "HCR",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/NLxWNZlnZx",
        "expanded_url" : "http:\/\/nader.org\/2013\/09\/26\/people-want-full-medicare-for-all\/",
        "display_url" : "nader.org\/2013\/09\/26\/peo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383331287651475456",
    "text" : "People Want Full Medicare for All -  http:\/\/t.co\/NLxWNZlnZx #SinglePayer #MedicareForAll #AetnaMyHealthy #ObamaCare #HCR",
    "id" : 383331287651475456,
    "created_at" : "2013-09-26 20:44:35 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 383332068853157888,
  "created_at" : "2013-09-26 20:47:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383330250882416640",
  "text" : "and apple.. the new ipod touch.. have to get 32 or 64gb to get 5mp camera. 16gb only has front cam - 1.2MP",
  "id" : 383330250882416640,
  "created_at" : "2013-09-26 20:40:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383328658074505216",
  "text" : "why oh why amazon.. you only include front cam for hdx7?",
  "id" : 383328658074505216,
  "created_at" : "2013-09-26 20:34:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Science",
      "screen_name" : "HuffPostScience",
      "indices" : [ 3, 19 ],
      "id_str" : "195897346",
      "id" : 195897346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/soDlROrduN",
      "expanded_url" : "http:\/\/huff.to\/1h1XZco",
      "display_url" : "huff.to\/1h1XZco"
    } ]
  },
  "geo" : { },
  "id_str" : "383327725252923394",
  "text" : "RT @HuffPostScience: Psychopaths' lack of empathy has neurological basis, study shows http:\/\/t.co\/soDlROrduN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/soDlROrduN",
        "expanded_url" : "http:\/\/huff.to\/1h1XZco",
        "display_url" : "huff.to\/1h1XZco"
      } ]
    },
    "geo" : { },
    "id_str" : "382980541366435840",
    "text" : "Psychopaths' lack of empathy has neurological basis, study shows http:\/\/t.co\/soDlROrduN",
    "id" : 382980541366435840,
    "created_at" : "2013-09-25 21:30:51 +0000",
    "user" : {
      "name" : "HuffPost Science",
      "screen_name" : "HuffPostScience",
      "protected" : false,
      "id_str" : "195897346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3383390796\/08975b1cfb9bb7298bc4d9e0c4a2fd85_normal.jpeg",
      "id" : 195897346,
      "verified" : true
    }
  },
  "id" : 383327725252923394,
  "created_at" : "2013-09-26 20:30:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383320364442320896",
  "text" : "@weakSquare cool beans! hope they give you some donuts.. yum! : )",
  "id" : 383320364442320896,
  "created_at" : "2013-09-26 20:01:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383294755502690304",
  "text" : "@Skeptical_Lady yup",
  "id" : 383294755502690304,
  "created_at" : "2013-09-26 18:19:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383293193376133120",
  "text" : "@weakSquare um.. why are you on top of a donut shop? lol",
  "id" : 383293193376133120,
  "created_at" : "2013-09-26 18:13:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "Anindya",
      "screen_name" : "AnindyaV",
      "indices" : [ 18, 27 ],
      "id_str" : "360373345",
      "id" : 360373345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383275403898408960",
  "text" : "RT @Jamiastar: RT @AnindyaV: The world spent $1735 billion on war in 2012. It would take approximately $135 billion to totally eradicate po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anindya",
        "screen_name" : "AnindyaV",
        "indices" : [ 3, 12 ],
        "id_str" : "360373345",
        "id" : 360373345
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383274429045669888",
    "text" : "RT @AnindyaV: The world spent $1735 billion on war in 2012. It would take approximately $135 billion to totally eradicate poverty.",
    "id" : 383274429045669888,
    "created_at" : "2013-09-26 16:58:39 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 383275403898408960,
  "created_at" : "2013-09-26 17:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 3, 19 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/H4SwMnovge",
      "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy?ref=hl",
      "display_url" : "facebook.com\/HighlandFarmsO\u2026"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/y4MqrOlspn",
      "expanded_url" : "http:\/\/twitpic.com\/df0r8w",
      "display_url" : "twitpic.com\/df0r8w"
    } ]
  },
  "geo" : { },
  "id_str" : "383264125440102400",
  "text" : "RT @HighlandFarmsME: A COTILLION OF CALVES. 5 of the 6 calves we had born at https:\/\/t.co\/H4SwMnovge  http:\/\/t.co\/y4MqrOlspn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/H4SwMnovge",
        "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy?ref=hl",
        "display_url" : "facebook.com\/HighlandFarmsO\u2026"
      }, {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/y4MqrOlspn",
        "expanded_url" : "http:\/\/twitpic.com\/df0r8w",
        "display_url" : "twitpic.com\/df0r8w"
      } ]
    },
    "geo" : { },
    "id_str" : "383263225883541504",
    "text" : "A COTILLION OF CALVES. 5 of the 6 calves we had born at https:\/\/t.co\/H4SwMnovge  http:\/\/t.co\/y4MqrOlspn",
    "id" : 383263225883541504,
    "created_at" : "2013-09-26 16:14:08 +0000",
    "user" : {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "protected" : false,
      "id_str" : "1050419874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046136643\/52b682fed61ae8e3cd6692fcb7e54ab8_normal.jpeg",
      "id" : 1050419874,
      "verified" : false
    }
  },
  "id" : 383264125440102400,
  "created_at" : "2013-09-26 16:17:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383263289913778176",
  "text" : "@Skeptical_Lady yeah.. i can't wear them. drives me nuts.",
  "id" : 383263289913778176,
  "created_at" : "2013-09-26 16:14:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383250559622324224",
  "text" : "RT @Buddhaworld: Dont fall into the spiritual advancement trap. To much advice nobody can follow. I try to keep it simple and relaxed. Do t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383249997908938752",
    "text" : "Dont fall into the spiritual advancement trap. To much advice nobody can follow. I try to keep it simple and relaxed. Do the same. Buddha v.",
    "id" : 383249997908938752,
    "created_at" : "2013-09-26 15:21:34 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 383250559622324224,
  "created_at" : "2013-09-26 15:23:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383249609889304577",
  "text" : "@weakSquare truth.",
  "id" : 383249609889304577,
  "created_at" : "2013-09-26 15:20:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383249238185877507",
  "text" : "so much wisdom from @Skeptical_Lady this fine morning.. love it! : )",
  "id" : 383249238185877507,
  "created_at" : "2013-09-26 15:18:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/0uBpyulghk",
      "expanded_url" : "http:\/\/www.nbcnews.com\/health\/first-mind-controlled-bionic-leg-groundbreaking-advance-8C11257732",
      "display_url" : "nbcnews.com\/health\/first-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383248221859901441",
  "text" : "RT @JeffreyGuterman: First mind-controlled bionic leg a 'groundbreaking' advance http:\/\/t.co\/0uBpyulghk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/0uBpyulghk",
        "expanded_url" : "http:\/\/www.nbcnews.com\/health\/first-mind-controlled-bionic-leg-groundbreaking-advance-8C11257732",
        "display_url" : "nbcnews.com\/health\/first-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383246270212472832",
    "text" : "First mind-controlled bionic leg a 'groundbreaking' advance http:\/\/t.co\/0uBpyulghk",
    "id" : 383246270212472832,
    "created_at" : "2013-09-26 15:06:45 +0000",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 383248221859901441,
  "created_at" : "2013-09-26 15:14:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383247722846760961",
  "text" : "@Skeptical_Lady good point here. they need compassion.",
  "id" : 383247722846760961,
  "created_at" : "2013-09-26 15:12:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 8, 23 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383242741859090433",
  "text" : "great.. @PeggySueCusses you got me stuck on watching cspan2 ..lol",
  "id" : 383242741859090433,
  "created_at" : "2013-09-26 14:52:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 0, 14 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383235607658364928",
  "geo" : { },
  "id_str" : "383237032224370688",
  "in_reply_to_user_id" : 260028159,
  "text" : "@LilMissCoyote hmmm...",
  "id" : 383237032224370688,
  "in_reply_to_status_id" : 383235607658364928,
  "created_at" : "2013-09-26 14:30:03 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UpPastryPlate",
      "screen_name" : "UpPastryPlate",
      "indices" : [ 3, 17 ],
      "id_str" : "3913861691",
      "id" : 3913861691
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383234804075872256",
  "text" : "RT @UPPastryPlate: What we don't want is the hassle of insurance companies when we go to the doctor. #singlepayer solves that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382904803900153857",
    "text" : "What we don't want is the hassle of insurance companies when we go to the doctor. #singlepayer solves that.",
    "id" : 382904803900153857,
    "created_at" : "2013-09-25 16:29:53 +0000",
    "user" : {
      "name" : "PastryPlate",
      "screen_name" : "PastryPlate",
      "protected" : false,
      "id_str" : "630249182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704317432375189504\/kT2mbarv_normal.jpg",
      "id" : 630249182,
      "verified" : false
    }
  },
  "id" : 383234804075872256,
  "created_at" : "2013-09-26 14:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save The Planet",
      "screen_name" : "SaveThePlanet17",
      "indices" : [ 3, 19 ],
      "id_str" : "1308579547",
      "id" : 1308579547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383234117854191617",
  "text" : "RT @SaveThePlanet17: If we spent half as much improving society as we do on war and military we would have such an advanced society",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382192052114448384",
    "text" : "If we spent half as much improving society as we do on war and military we would have such an advanced society",
    "id" : 382192052114448384,
    "created_at" : "2013-09-23 17:17:40 +0000",
    "user" : {
      "name" : "Save The Planet",
      "screen_name" : "SaveThePlanet17",
      "protected" : false,
      "id_str" : "1308579547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752298910635335680\/oskuFYWg_normal.jpg",
      "id" : 1308579547,
      "verified" : false
    }
  },
  "id" : 383234117854191617,
  "created_at" : "2013-09-26 14:18:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 91, 100 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/FIo2QrqEKs",
      "expanded_url" : "http:\/\/www.upworthy.com\/see-the-scientific-accident-that-may-change-the-world-or-at-least-your-battery-l?g=3&c=ufb2",
      "display_url" : "upworthy.com\/see-the-scient\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383231904859713536",
  "text" : "See the scientific accident that may change the world (or at least your battery life) (via @Upworthy) http:\/\/t.co\/FIo2QrqEKs",
  "id" : 383231904859713536,
  "created_at" : "2013-09-26 14:09:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    }, {
      "name" : "Ed Schultz",
      "screen_name" : "edshow",
      "indices" : [ 103, 110 ],
      "id_str" : "75052666",
      "id" : 75052666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383034463623852033",
  "text" : "RT @Adenovir: So health care is \"sugar\" to Ted Cruz? Like only those who \"deserve\" it should have it?  @edshow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Schultz",
        "screen_name" : "edshow",
        "indices" : [ 89, 96 ],
        "id_str" : "75052666",
        "id" : 75052666
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382975550505381888",
    "text" : "So health care is \"sugar\" to Ted Cruz? Like only those who \"deserve\" it should have it?  @edshow",
    "id" : 382975550505381888,
    "created_at" : "2013-09-25 21:11:01 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 383034463623852033,
  "created_at" : "2013-09-26 01:05:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383006569299861504",
  "text" : "insurance companies.. the thing is, it's not their job to care about the claimants. Their job: stay in and increase profit! #singlepayer",
  "id" : 383006569299861504,
  "created_at" : "2013-09-25 23:14:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/aZbuvBapvL",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/09\/25\/opinion\/shaich-food-stamp-challenge\/index.html?sr=sharebar_twitter",
      "display_url" : "cnn.com\/2013\/09\/25\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382997193583390720",
  "text" : "Panera CEO learns about hunger on his food stamp diet http:\/\/t.co\/aZbuvBapvL",
  "id" : 382997193583390720,
  "created_at" : "2013-09-25 22:37:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/AnAH6yHmsq",
      "expanded_url" : "http:\/\/ti.me\/18pLW5p",
      "display_url" : "ti.me\/18pLW5p"
    } ]
  },
  "geo" : { },
  "id_str" : "382979763163238400",
  "text" : "RT @TIME: Confused about Obamacare? Figure out your insurance costs with this handy calculator | http:\/\/t.co\/AnAH6yHmsq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/AnAH6yHmsq",
        "expanded_url" : "http:\/\/ti.me\/18pLW5p",
        "display_url" : "ti.me\/18pLW5p"
      } ]
    },
    "geo" : { },
    "id_str" : "382977996509835265",
    "text" : "Confused about Obamacare? Figure out your insurance costs with this handy calculator | http:\/\/t.co\/AnAH6yHmsq",
    "id" : 382977996509835265,
    "created_at" : "2013-09-25 21:20:44 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 382979763163238400,
  "created_at" : "2013-09-25 21:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382972528605405184",
  "geo" : { },
  "id_str" : "382973458990104576",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia you as an example.. you defended muslim countries yet so hard christians @weakSquare",
  "id" : 382973458990104576,
  "in_reply_to_status_id" : 382972528605405184,
  "created_at" : "2013-09-25 21:02:42 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382953370798927872",
  "text" : "there is a lot of stress when you have no access to health care. stress is very conducive to... illness! #singlepayer",
  "id" : 382953370798927872,
  "created_at" : "2013-09-25 19:42:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "indices" : [ 3, 15 ],
      "id_str" : "19791234",
      "id" : 19791234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/MqNevVcrJL",
      "expanded_url" : "http:\/\/owl.li\/pbFyi",
      "display_url" : "owl.li\/pbFyi"
    } ]
  },
  "geo" : { },
  "id_str" : "382950546367209472",
  "text" : "RT @Emperor_Bob: Obamacare Premiums Report Shows Low Prices For Uninsured With Wide Variation http:\/\/t.co\/MqNevVcrJL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/MqNevVcrJL",
        "expanded_url" : "http:\/\/owl.li\/pbFyi",
        "display_url" : "owl.li\/pbFyi"
      } ]
    },
    "geo" : { },
    "id_str" : "382948953744236544",
    "text" : "Obamacare Premiums Report Shows Low Prices For Uninsured With Wide Variation http:\/\/t.co\/MqNevVcrJL",
    "id" : 382948953744236544,
    "created_at" : "2013-09-25 19:25:20 +0000",
    "user" : {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "protected" : false,
      "id_str" : "19791234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3352084632\/6ebf06ce559f48c77c691cb928fc62ab_normal.png",
      "id" : 19791234,
      "verified" : false
    }
  },
  "id" : 382950546367209472,
  "created_at" : "2013-09-25 19:31:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382949885831426048",
  "text" : "having access to health care is not like buying a new iphone or a car. #singlepayer",
  "id" : 382949885831426048,
  "created_at" : "2013-09-25 19:29:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382947922385461248",
  "text" : "access to health care is good for all of society. people who are sick or in pain are less able to care for themselves. #singlepayer",
  "id" : 382947922385461248,
  "created_at" : "2013-09-25 19:21:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382947727929126912",
  "text" : "access to health care is good for all of society. people who are sick or in pain are less productive. #singlepayer",
  "id" : 382947727929126912,
  "created_at" : "2013-09-25 19:20:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382946712433590273",
  "text" : "getting access to health care is so intertwined with basic quality of life.. even survival itself. #singlepayer",
  "id" : 382946712433590273,
  "created_at" : "2013-09-25 19:16:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382946351064961025",
  "text" : "I just cant get past the idea that health insurance itself is unethical. #singlepayer",
  "id" : 382946351064961025,
  "created_at" : "2013-09-25 19:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382934662831538178",
  "geo" : { },
  "id_str" : "382938590071623680",
  "in_reply_to_user_id" : 93747129,
  "text" : "@PeggySueCusses thanks.. got it : )",
  "id" : 382938590071623680,
  "in_reply_to_status_id" : 382934662831538178,
  "created_at" : "2013-09-25 18:44:09 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382930153749237760",
  "geo" : { },
  "id_str" : "382934662831538178",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses online or on tv? you got directv? what channel?",
  "id" : 382934662831538178,
  "in_reply_to_status_id" : 382930153749237760,
  "created_at" : "2013-09-25 18:28:32 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/5mdv3obWb3",
      "expanded_url" : "http:\/\/instagram.com\/p\/esXLoMNqQ0\/",
      "display_url" : "instagram.com\/p\/esXLoMNqQ0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "382932592158584832",
  "text" : "Pressgr.am http:\/\/t.co\/5mdv3obWb3",
  "id" : 382932592158584832,
  "created_at" : "2013-09-25 18:20:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 0, 16 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/wzqjqTGeBW",
      "expanded_url" : "http:\/\/preview.tinyurl.com\/nvxhnxq",
      "display_url" : "preview.tinyurl.com\/nvxhnxq"
    } ]
  },
  "geo" : { },
  "id_str" : "382919814370439169",
  "in_reply_to_user_id" : 102313523,
  "text" : "@TheHudsonValley Cornerstone church in Clinton Corners: Free For All (free yardsale) on Sat. 09\/28 9am-3pm. http:\/\/t.co\/wzqjqTGeBW",
  "id" : 382919814370439169,
  "created_at" : "2013-09-25 17:29:32 +0000",
  "in_reply_to_screen_name" : "TheHudsonValley",
  "in_reply_to_user_id_str" : "102313523",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter B. Hoffmeister",
      "screen_name" : "peterbrownhoff",
      "indices" : [ 3, 18 ],
      "id_str" : "276819952",
      "id" : 276819952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382904465428209665",
  "text" : "RT @peterbrownhoff: It's so sad that our school bell sounds like a prison bell.\n\"CELL BLOCK C, INTO YOUR CELLS.\"\n\"CELL BLOCK D, TIME FOR TH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Education",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382903843853324288",
    "text" : "It's so sad that our school bell sounds like a prison bell.\n\"CELL BLOCK C, INTO YOUR CELLS.\"\n\"CELL BLOCK D, TIME FOR THE YARD.\"\n#Education",
    "id" : 382903843853324288,
    "created_at" : "2013-09-25 16:26:05 +0000",
    "user" : {
      "name" : "Peter B. Hoffmeister",
      "screen_name" : "peterbrownhoff",
      "protected" : false,
      "id_str" : "276819952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483642400330371072\/vUjDOBbR_normal.jpeg",
      "id" : 276819952,
      "verified" : false
    }
  },
  "id" : 382904465428209665,
  "created_at" : "2013-09-25 16:28:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382897172645048320",
  "text" : "@1stCitizenKane i saw matrix. never occured to me.. cool beans!",
  "id" : 382897172645048320,
  "created_at" : "2013-09-25 15:59:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382896745698426880",
  "text" : ". @SamsaricWarrior interesting.. cuz I find the opposite. twitter is like my room after school w my besties..lol",
  "id" : 382896745698426880,
  "created_at" : "2013-09-25 15:57:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thembti",
      "screen_name" : "thembti",
      "indices" : [ 98, 106 ],
      "id_str" : "18995500",
      "id" : 18995500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "StressHead",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "mbti",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "myersbriggs",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/FPFbfwGHiz",
      "expanded_url" : "https:\/\/www.cpp.com\/contents\/stress-heads.aspx?type=infp",
      "display_url" : "cpp.com\/contents\/stres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382887517302693889",
  "text" : "Stressors that get me spinning: #INFP #StressHead! #mbti #myersbriggs https:\/\/t.co\/FPFbfwGHiz via @thembti",
  "id" : 382887517302693889,
  "created_at" : "2013-09-25 15:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thembti",
      "screen_name" : "thembti",
      "indices" : [ 65, 73 ],
      "id_str" : "18995500",
      "id" : 18995500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 2, 7 ]
    }, {
      "text" : "mbti",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "myersbriggs",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/wHHBbWDxHL",
      "expanded_url" : "https:\/\/www.cpp.com\/contents\/type-heads.aspx?type=infp",
      "display_url" : "cpp.com\/contents\/type-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382887395844034560",
  "text" : ". #INFP type head #mbti #myersbriggs https:\/\/t.co\/wHHBbWDxHL via @thembti",
  "id" : 382887395844034560,
  "created_at" : "2013-09-25 15:20:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthcare Activists",
      "screen_name" : "singlepayer",
      "indices" : [ 3, 15 ],
      "id_str" : "15883275",
      "id" : 15883275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "p2",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382882192256294912",
  "text" : "RT @singlepayer: Go ahead then.Repeal and replace the #ACA ...with MEDICARE FOR ALL which is the REAL solution to rising hcr costs. #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "p2",
        "indices" : [ 115, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382877589343186944",
    "text" : "Go ahead then.Repeal and replace the #ACA ...with MEDICARE FOR ALL which is the REAL solution to rising hcr costs. #p2",
    "id" : 382877589343186944,
    "created_at" : "2013-09-25 14:41:45 +0000",
    "user" : {
      "name" : "Healthcare Activists",
      "screen_name" : "singlepayer",
      "protected" : false,
      "id_str" : "15883275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616256834878377984\/k6U1OHi-_normal.jpg",
      "id" : 15883275,
      "verified" : false
    }
  },
  "id" : 382882192256294912,
  "created_at" : "2013-09-25 15:00:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 0, 12 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382878336520712192",
  "geo" : { },
  "id_str" : "382881991797911553",
  "in_reply_to_user_id" : 890831,
  "text" : "@scottsigler LOLOL",
  "id" : 382881991797911553,
  "in_reply_to_status_id" : 382878336520712192,
  "created_at" : "2013-09-25 14:59:15 +0000",
  "in_reply_to_screen_name" : "scottsigler",
  "in_reply_to_user_id_str" : "890831",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382721210984841216",
  "geo" : { },
  "id_str" : "382881710737600512",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia every HUMAN sees things from their own perspective. each brain will find evidence to back up the thoughts. @weakSquare",
  "id" : 382881710737600512,
  "in_reply_to_status_id" : 382721210984841216,
  "created_at" : "2013-09-25 14:58:08 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 40, 54 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382881089057857536",
  "text" : "@weakSquare &lt;&lt; what he said...lol @deisidiamonia",
  "id" : 382881089057857536,
  "created_at" : "2013-09-25 14:55:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 2, 13 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382847588221087745",
  "geo" : { },
  "id_str" : "382863911084503040",
  "in_reply_to_user_id" : 39331231,
  "text" : ". @dhammagirl im still working on this but getting better all the time. took awhile for this lesson to imprint..lol.",
  "id" : 382863911084503040,
  "in_reply_to_status_id" : 382847588221087745,
  "created_at" : "2013-09-25 13:47:24 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382863486247653377",
  "text" : "RT @dhammagirl: Change someone's life today...\n\n.. with the Intention \n\n..of paying Attention.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382847588221087745",
    "text" : "Change someone's life today...\n\n.. with the Intention \n\n..of paying Attention.",
    "id" : 382847588221087745,
    "created_at" : "2013-09-25 12:42:32 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 382863486247653377,
  "created_at" : "2013-09-25 13:45:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 0, 11 ],
      "id_str" : "187357122",
      "id" : 187357122
    }, {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 12, 25 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382639013149945856",
  "geo" : { },
  "id_str" : "382663950334427137",
  "in_reply_to_user_id" : 187357122,
  "text" : "@Wolf_Mommy @PisseArtiste thanks for your comments. Trying to understand the anti socialized healthcare view.",
  "id" : 382663950334427137,
  "in_reply_to_status_id" : 382639013149945856,
  "created_at" : "2013-09-25 00:32:49 +0000",
  "in_reply_to_screen_name" : "Wolf_Mommy",
  "in_reply_to_user_id_str" : "187357122",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382644728539267072",
  "text" : "RT @micahjmurray: I find it strange that we spend so much on our Defense, but when it comes to caring for the health of our citizens it's \"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382644290800738304",
    "text" : "I find it strange that we spend so much on our Defense, but when it comes to caring for the health of our citizens it's \"too expensive\"",
    "id" : 382644290800738304,
    "created_at" : "2013-09-24 23:14:42 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 382644728539267072,
  "created_at" : "2013-09-24 23:16:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/DY7eWnsuSh",
      "expanded_url" : "http:\/\/diannaeanderson.net\/blog\/2013\/9\/a-good-dad-buys-the-classism-of-mark-driscolls-masculinity",
      "display_url" : "diannaeanderson.net\/blog\/2013\/9\/a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382643806325055488",
  "text" : "RT @rachelheldevans: Yep. If your theology doesn't work for the poor, it doesn't work: http:\/\/t.co\/DY7eWnsuSh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/DY7eWnsuSh",
        "expanded_url" : "http:\/\/diannaeanderson.net\/blog\/2013\/9\/a-good-dad-buys-the-classism-of-mark-driscolls-masculinity",
        "display_url" : "diannaeanderson.net\/blog\/2013\/9\/a-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382642607995629568",
    "text" : "Yep. If your theology doesn't work for the poor, it doesn't work: http:\/\/t.co\/DY7eWnsuSh",
    "id" : 382642607995629568,
    "created_at" : "2013-09-24 23:08:01 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 382643806325055488,
  "created_at" : "2013-09-24 23:12:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 18, 33 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382642506602532864",
  "text" : "RT @Charmantides: @1stCitizenKane teaching a man to fish. More educated we become more we care more we know. Everyone should know that free\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "2Bits  Semi-Poet \u2629",
        "screen_name" : "1stCitizenKane",
        "indices" : [ 0, 15 ],
        "id_str" : "1071113395",
        "id" : 1071113395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382640546059001856",
    "text" : "@1stCitizenKane teaching a man to fish. More educated we become more we care more we know. Everyone should know that freedom.",
    "id" : 382640546059001856,
    "created_at" : "2013-09-24 22:59:49 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 382642506602532864,
  "created_at" : "2013-09-24 23:07:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 18, 33 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382642489363922944",
  "text" : "RT @Charmantides: @1stCitizenKane Im not patriotic, and its not as good as my parents had it, but free healthcare and no upfront zero inter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "2Bits  Semi-Poet \u2629",
        "screen_name" : "1stCitizenKane",
        "indices" : [ 0, 15 ],
        "id_str" : "1071113395",
        "id" : 1071113395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382640309030498304",
    "text" : "@1stCitizenKane Im not patriotic, and its not as good as my parents had it, but free healthcare and no upfront zero interest HE is like",
    "id" : 382640309030498304,
    "created_at" : "2013-09-24 22:58:53 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 382642489363922944,
  "created_at" : "2013-09-24 23:07:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 102, 114 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/PjVGveKizs",
      "expanded_url" : "http:\/\/huff.to\/15ptAEZ",
      "display_url" : "huff.to\/15ptAEZ"
    } ]
  },
  "geo" : { },
  "id_str" : "382639509445152768",
  "text" : "RT @AllOnMedicare: America's Hidden Epidemic That Obamacare Barely Touches http:\/\/t.co\/PjVGveKizs via @HuffPostPol #singlepayer #medicarefo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Politics",
        "screen_name" : "HuffPostPol",
        "indices" : [ 83, 95 ],
        "id_str" : "15458694",
        "id" : 15458694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 96, 108 ]
      }, {
        "text" : "medicareforall",
        "indices" : [ 109, 124 ]
      }, {
        "text" : "dental",
        "indices" : [ 125, 132 ]
      }, {
        "text" : "teeth",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/PjVGveKizs",
        "expanded_url" : "http:\/\/huff.to\/15ptAEZ",
        "display_url" : "huff.to\/15ptAEZ"
      } ]
    },
    "geo" : { },
    "id_str" : "382638666830458881",
    "text" : "America's Hidden Epidemic That Obamacare Barely Touches http:\/\/t.co\/PjVGveKizs via @HuffPostPol #singlepayer #medicareforall #dental #teeth",
    "id" : 382638666830458881,
    "created_at" : "2013-09-24 22:52:21 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 382639509445152768,
  "created_at" : "2013-09-24 22:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    }, {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 98, 111 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382636566277275648",
  "geo" : { },
  "id_str" : "382638175526477824",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i like you and honestly wanted yr reason why against.. not trying to be a jerk... @PisseArtiste",
  "id" : 382638175526477824,
  "in_reply_to_status_id" : 382636566277275648,
  "created_at" : "2013-09-24 22:50:24 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 66, 80 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Nasty Assassin \u2620\uFE0F",
      "screen_name" : "AssassinGrl",
      "indices" : [ 93, 105 ],
      "id_str" : "41749124",
      "id" : 41749124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382636462002294784",
  "geo" : { },
  "id_str" : "382637466601017345",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia  we all compartmentalize.. even atheists do it : ) @BibleAlsoSays @weakSquare @AssassinGrl",
  "id" : 382637466601017345,
  "in_reply_to_status_id" : 382636462002294784,
  "created_at" : "2013-09-24 22:47:35 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 2, 15 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 16, 27 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/FN8uZvbabP",
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/382633154940764160",
      "display_url" : "twitter.com\/moosebegab\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382633792986304512",
  "text" : ". @PisseArtiste @Wolf_Mommy as Canadians, what say you? &gt;&gt; https:\/\/t.co\/FN8uZvbabP",
  "id" : 382633792986304512,
  "created_at" : "2013-09-24 22:32:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 27, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/1yEyentkqB",
      "expanded_url" : "http:\/\/tl.gd\/n_1rp17hl",
      "display_url" : "tl.gd\/n_1rp17hl"
    } ]
  },
  "geo" : { },
  "id_str" : "382633154940764160",
  "text" : "comments from my peeps re: #singlepayer comment. \"poor quality of care. long waits. denied procedures and (cont) http:\/\/t.co\/1yEyentkqB",
  "id" : 382633154940764160,
  "created_at" : "2013-09-24 22:30:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382632399076478976",
  "text" : "ok.. ima trying to figure this stuff out.. #singlepayer",
  "id" : 382632399076478976,
  "created_at" : "2013-09-24 22:27:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382623218127097856",
  "geo" : { },
  "id_str" : "382626433136226304",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses why would that be bad?",
  "id" : 382626433136226304,
  "in_reply_to_status_id" : 382623218127097856,
  "created_at" : "2013-09-24 22:03:45 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UpPastryPlate",
      "screen_name" : "UpPastryPlate",
      "indices" : [ 3, 17 ],
      "id_str" : "3913861691",
      "id" : 3913861691
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 27, 35 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 57, 69 ]
    }, {
      "text" : "medicareforall",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382622548556410880",
  "text" : "RT @UPPastryPlate: Exactly @tedcruz #Obamacare should be #singlepayer #medicareforall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 8, 16 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 38, 50 ]
      }, {
        "text" : "medicareforall",
        "indices" : [ 51, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382617294867664896",
    "text" : "Exactly @tedcruz #Obamacare should be #singlepayer #medicareforall",
    "id" : 382617294867664896,
    "created_at" : "2013-09-24 21:27:26 +0000",
    "user" : {
      "name" : "PastryPlate",
      "screen_name" : "PastryPlate",
      "protected" : false,
      "id_str" : "630249182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704317432375189504\/kT2mbarv_normal.jpg",
      "id" : 630249182,
      "verified" : false
    }
  },
  "id" : 382622548556410880,
  "created_at" : "2013-09-24 21:48:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382614641123135488",
  "text" : "RT @GeneDoucette: \"The whole concept is un-American. People living here, in the greatest country on Earth, with the most...\" http:\/\/t.co\/3X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/3XHH8Qi0FO",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwvwKXaY",
        "display_url" : "tmblr.co\/ZYrEZwvwKXaY"
      } ]
    },
    "geo" : { },
    "id_str" : "382614261950074880",
    "text" : "\"The whole concept is un-American. People living here, in the greatest country on Earth, with the most...\" http:\/\/t.co\/3XHH8Qi0FO",
    "id" : 382614261950074880,
    "created_at" : "2013-09-24 21:15:23 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 382614641123135488,
  "created_at" : "2013-09-24 21:16:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382611178465148928",
  "text" : "sometimes i read a tweet.. then say to that peep \"i love you\" in my head.",
  "id" : 382611178465148928,
  "created_at" : "2013-09-24 21:03:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 44, 55 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382609913135898625",
  "text" : "RT @AllOnMedicare: Many folks responding to @SenTedCruz 'filibuster' by pointing out #SinglePayer #MedicareForAll solves job\/employment pro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Ted Cruz",
        "screen_name" : "SenTedCruz",
        "indices" : [ 25, 36 ],
        "id_str" : "1074480192",
        "id" : 1074480192
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 66, 78 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 79, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382608375554392065",
    "text" : "Many folks responding to @SenTedCruz 'filibuster' by pointing out #SinglePayer #MedicareForAll solves job\/employment problem.",
    "id" : 382608375554392065,
    "created_at" : "2013-09-24 20:51:59 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 382609913135898625,
  "created_at" : "2013-09-24 20:58:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tooround",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "nothingfits",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382609484771651585",
  "text" : "ps. im still too big for prom dresses. dh should take dd to the party... #tooround #nothingfits",
  "id" : 382609484771651585,
  "created_at" : "2013-09-24 20:56:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Trahant",
      "screen_name" : "TrahantReports",
      "indices" : [ 3, 18 ],
      "id_str" : "28358250",
      "id" : 28358250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382608487919788032",
  "text" : "RT @TrahantReports: So much of Cruz discourse is against employer mandate and about burden on small business. I agree. That's why #singlepa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 110, 122 ]
      }, {
        "text" : "ACA",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382604271776055296",
    "text" : "So much of Cruz discourse is against employer mandate and about burden on small business. I agree. That's why #singlepayer makes sense. #ACA",
    "id" : 382604271776055296,
    "created_at" : "2013-09-24 20:35:41 +0000",
    "user" : {
      "name" : "Mark Trahant",
      "screen_name" : "TrahantReports",
      "protected" : false,
      "id_str" : "28358250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609854907101777920\/FO6r1CCs_normal.jpg",
      "id" : 28358250,
      "verified" : false
    }
  },
  "id" : 382608487919788032,
  "created_at" : "2013-09-24 20:52:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canada",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "AgeDiscrimination",
      "indices" : [ 60, 78 ]
    }, {
      "text" : "USA",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "ObamaCare",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382608414817255424",
  "text" : "RT @KellyRek: In #Canada (under their #SinglePayer system), #AgeDiscrimination is highly illegal ... In #USA (under #ObamaCare), it is a de\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Canada",
        "indices" : [ 3, 10 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 24, 36 ]
      }, {
        "text" : "AgeDiscrimination",
        "indices" : [ 46, 64 ]
      }, {
        "text" : "USA",
        "indices" : [ 90, 94 ]
      }, {
        "text" : "ObamaCare",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382604048978804737",
    "text" : "In #Canada (under their #SinglePayer system), #AgeDiscrimination is highly illegal ... In #USA (under #ObamaCare), it is a de facto mandate.",
    "id" : 382604048978804737,
    "created_at" : "2013-09-24 20:34:48 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 382608414817255424,
  "created_at" : "2013-09-24 20:52:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtfdoesthatmean",
      "indices" : [ 33, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382496309694828544",
  "text" : "i have broadway shows for dreams #wtfdoesthatmean",
  "id" : 382496309694828544,
  "created_at" : "2013-09-24 13:26:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "Chuck Woolery",
      "screen_name" : "chuckwoolery",
      "indices" : [ 23, 36 ],
      "id_str" : "462104542",
      "id" : 462104542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382307595714699264",
  "text" : "RT @PisseArtiste: Yes, @chuckwoolery, ask Canadians about their healthcare. Most of us will tell you we are pretty happy with it actually. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chuck Woolery",
        "screen_name" : "chuckwoolery",
        "indices" : [ 5, 18 ],
        "id_str" : "462104542",
        "id" : 462104542
      }, {
        "name" : "Teddy-Bear-Hugs",
        "screen_name" : "Aquarius1961",
        "indices" : [ 122, 135 ],
        "id_str" : "1275250638",
        "id" : 1275250638
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "382150253958291457",
    "geo" : { },
    "id_str" : "382307125713981440",
    "in_reply_to_user_id" : 462104542,
    "text" : "Yes, @chuckwoolery, ask Canadians about their healthcare. Most of us will tell you we are pretty happy with it actually.  @Aquarius1961",
    "id" : 382307125713981440,
    "in_reply_to_status_id" : 382150253958291457,
    "created_at" : "2013-09-24 00:54:56 +0000",
    "in_reply_to_screen_name" : "chuckwoolery",
    "in_reply_to_user_id_str" : "462104542",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 382307595714699264,
  "created_at" : "2013-09-24 00:56:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovemywildlife",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382303711172636672",
  "text" : "so happy to see a possum on our porch again! its been awhile... #lovemywildlife",
  "id" : 382303711172636672,
  "created_at" : "2013-09-24 00:41:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 3, 18 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LoveHonorTruth\/status\/382299627636011008\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/4YKsBLqHHV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU4zfFiCMAAR9WF.jpg",
      "id_str" : "382299627526959104",
      "id" : 382299627526959104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU4zfFiCMAAR9WF.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 530
      } ],
      "display_url" : "pic.twitter.com\/4YKsBLqHHV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382301956170997760",
  "text" : "RT @LoveHonorTruth: In the beginning... http:\/\/t.co\/4YKsBLqHHV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LoveHonorTruth\/status\/382299627636011008\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/4YKsBLqHHV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BU4zfFiCMAAR9WF.jpg",
        "id_str" : "382299627526959104",
        "id" : 382299627526959104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU4zfFiCMAAR9WF.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 530
        } ],
        "display_url" : "pic.twitter.com\/4YKsBLqHHV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382299627636011008",
    "text" : "In the beginning... http:\/\/t.co\/4YKsBLqHHV",
    "id" : 382299627636011008,
    "created_at" : "2013-09-24 00:25:08 +0000",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "protected" : false,
      "id_str" : "167958125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525129289336107008\/HMsrT9oV_normal.jpeg",
      "id" : 167958125,
      "verified" : false
    }
  },
  "id" : 382301956170997760,
  "created_at" : "2013-09-24 00:34:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 0, 16 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382210645912858624",
  "geo" : { },
  "id_str" : "382220458986196992",
  "in_reply_to_user_id" : 189759304,
  "text" : "@virtusetveritas : (((",
  "id" : 382220458986196992,
  "in_reply_to_status_id" : 382210645912858624,
  "created_at" : "2013-09-23 19:10:33 +0000",
  "in_reply_to_screen_name" : "samanthapfield",
  "in_reply_to_user_id_str" : "189759304",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382170196074430465",
  "geo" : { },
  "id_str" : "382170682135564288",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni Yes!!",
  "id" : 382170682135564288,
  "in_reply_to_status_id" : 382170196074430465,
  "created_at" : "2013-09-23 15:52:45 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382169826833084417",
  "text" : "@1stCitizenKane but no money to feed and care for her people...",
  "id" : 382169826833084417,
  "created_at" : "2013-09-23 15:49:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endoftheworld",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382169362989207553",
  "text" : "@1stCitizenKane we're all gonna die shortly anyway... no bees. #endoftheworld",
  "id" : 382169362989207553,
  "created_at" : "2013-09-23 15:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "Hoffm",
      "indices" : [ 3, 9 ],
      "id_str" : "15678279",
      "id" : 15678279
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Hoffm\/status\/381564392602480640\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/CGdR2RqtKJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUuWywlCAAEBbiG.jpg",
      "id_str" : "381564392220786689",
      "id" : 381564392220786689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUuWywlCAAEBbiG.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/CGdR2RqtKJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382168975255166977",
  "text" : "RT @Hoffm: Four uniformed NYPD officers were at my subway stop tonight asking me to upgrade to iOS 7. Not a joke! http:\/\/t.co\/CGdR2RqtKJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Hoffm\/status\/381564392602480640\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/CGdR2RqtKJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUuWywlCAAEBbiG.jpg",
        "id_str" : "381564392220786689",
        "id" : 381564392220786689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUuWywlCAAEBbiG.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/CGdR2RqtKJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381564392602480640",
    "text" : "Four uniformed NYPD officers were at my subway stop tonight asking me to upgrade to iOS 7. Not a joke! http:\/\/t.co\/CGdR2RqtKJ",
    "id" : 381564392602480640,
    "created_at" : "2013-09-21 23:43:34 +0000",
    "user" : {
      "name" : "Michael Hoffman",
      "screen_name" : "Hoffm",
      "protected" : false,
      "id_str" : "15678279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789588313413939200\/Xja7e1S__normal.jpg",
      "id" : 15678279,
      "verified" : false
    }
  },
  "id" : 382168975255166977,
  "created_at" : "2013-09-23 15:45:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382168520991068160",
  "text" : "RT @rachelheldevans: Think I'll pull a Leslie Knope and leave a message for myself on my phone: \"You can do this. Hang in there. I love you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382163114797461504",
    "text" : "Think I'll pull a Leslie Knope and leave a message for myself on my phone: \"You can do this. Hang in there. I love you.\" :-)",
    "id" : 382163114797461504,
    "created_at" : "2013-09-23 15:22:41 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 382168520991068160,
  "created_at" : "2013-09-23 15:44:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xultar",
      "screen_name" : "Xultar",
      "indices" : [ 0, 7 ],
      "id_str" : "22047952",
      "id" : 22047952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381608710667132928",
  "geo" : { },
  "id_str" : "382168181747363840",
  "in_reply_to_user_id" : 22047952,
  "text" : "@Xultar is this a real photo?? if it is... *smh* ...creepy!",
  "id" : 382168181747363840,
  "in_reply_to_status_id" : 381608710667132928,
  "created_at" : "2013-09-23 15:42:49 +0000",
  "in_reply_to_screen_name" : "Xultar",
  "in_reply_to_user_id_str" : "22047952",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron T. Starks",
      "screen_name" : "StarkyLuv73",
      "indices" : [ 3, 15 ],
      "id_str" : "894194737",
      "id" : 894194737
    }, {
      "name" : "Xultar",
      "screen_name" : "Xultar",
      "indices" : [ 17, 24 ],
      "id_str" : "22047952",
      "id" : 22047952
    }, {
      "name" : "As The Mojito Stirs",
      "screen_name" : "ArrogantDemon",
      "indices" : [ 25, 39 ],
      "id_str" : "364194053",
      "id" : 364194053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382167354005667840",
  "text" : "RT @StarkyLuv73: @Xultar @ArrogantDemon You're just catching on? Whites with guns: \"Patriots\". Minorities with guns: \"Thugs and Criminals\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xultar",
        "screen_name" : "Xultar",
        "indices" : [ 0, 7 ],
        "id_str" : "22047952",
        "id" : 22047952
      }, {
        "name" : "As The Mojito Stirs",
        "screen_name" : "ArrogantDemon",
        "indices" : [ 8, 22 ],
        "id_str" : "364194053",
        "id" : 364194053
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "381608710667132928",
    "geo" : { },
    "id_str" : "381611180281692160",
    "in_reply_to_user_id" : 22047952,
    "text" : "@Xultar @ArrogantDemon You're just catching on? Whites with guns: \"Patriots\". Minorities with guns: \"Thugs and Criminals\"",
    "id" : 381611180281692160,
    "in_reply_to_status_id" : 381608710667132928,
    "created_at" : "2013-09-22 02:49:30 +0000",
    "in_reply_to_screen_name" : "Xultar",
    "in_reply_to_user_id_str" : "22047952",
    "user" : {
      "name" : "Aaron T. Starks",
      "screen_name" : "StarkyLuv73",
      "protected" : false,
      "id_str" : "894194737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797826779645956097\/SLOD8sqQ_normal.jpg",
      "id" : 894194737,
      "verified" : false
    }
  },
  "id" : 382167354005667840,
  "created_at" : "2013-09-23 15:39:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xultar",
      "screen_name" : "Xultar",
      "indices" : [ 3, 10 ],
      "id_str" : "22047952",
      "id" : 22047952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382167308845588480",
  "text" : "RT @Xultar: A black kid has a photo of a gun on his phone &amp; he is automatically a criminal but... When white folk do it... http:\/\/t.co\/h1ga\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Xultar\/status\/381608710667132928\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/h1gaeSJFIS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUu_GbMCQAAxZSJ.jpg",
        "id_str" : "381608710541295616",
        "id" : 381608710541295616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUu_GbMCQAAxZSJ.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/h1gaeSJFIS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381608710667132928",
    "text" : "A black kid has a photo of a gun on his phone &amp; he is automatically a criminal but... When white folk do it... http:\/\/t.co\/h1gaeSJFIS",
    "id" : 381608710667132928,
    "created_at" : "2013-09-22 02:39:41 +0000",
    "user" : {
      "name" : "Xultar",
      "screen_name" : "Xultar",
      "protected" : false,
      "id_str" : "22047952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1503922062\/image_normal.jpg",
      "id" : 22047952,
      "verified" : false
    }
  },
  "id" : 382167308845588480,
  "created_at" : "2013-09-23 15:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earth Pics",
      "screen_name" : "Earth_Post",
      "indices" : [ 3, 14 ],
      "id_str" : "1113747361",
      "id" : 1113747361
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Earth_Post\/status\/378627355289600000\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/S3AdlsJ8OW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUEnktGIQAA3oKr.jpg",
      "id_str" : "378627355209908224",
      "id" : 378627355209908224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUEnktGIQAA3oKr.jpg",
      "sizes" : [ {
        "h" : 662,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/S3AdlsJ8OW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382162395168120832",
  "text" : "RT @Earth_Post: Dandelion sunset. http:\/\/t.co\/S3AdlsJ8OW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Earth_Post\/status\/378627355289600000\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/S3AdlsJ8OW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUEnktGIQAA3oKr.jpg",
        "id_str" : "378627355209908224",
        "id" : 378627355209908224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUEnktGIQAA3oKr.jpg",
        "sizes" : [ {
          "h" : 662,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/S3AdlsJ8OW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378627355289600000",
    "text" : "Dandelion sunset. http:\/\/t.co\/S3AdlsJ8OW",
    "id" : 378627355289600000,
    "created_at" : "2013-09-13 21:12:50 +0000",
    "user" : {
      "name" : "Earth Pics",
      "screen_name" : "Earth_Post",
      "protected" : false,
      "id_str" : "1113747361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774311613683867648\/juz3O3JB_normal.jpg",
      "id" : 1113747361,
      "verified" : false
    }
  },
  "id" : 382162395168120832,
  "created_at" : "2013-09-23 15:19:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/T4uUieNbeQ",
      "expanded_url" : "http:\/\/amzn.to\/1gQzBdt",
      "display_url" : "amzn.to\/1gQzBdt"
    } ]
  },
  "geo" : { },
  "id_str" : "381958972556988416",
  "text" : "finished By A Thread by Marty Beaudet http:\/\/t.co\/T4uUieNbeQ",
  "id" : 381958972556988416,
  "created_at" : "2013-09-23 01:51:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 7, 20 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381787850355654657",
  "geo" : { },
  "id_str" : "381799417122013185",
  "in_reply_to_user_id" : 361815486,
  "text" : "thanks @bookwiseblog ..I picked up Destroying Angel (Righteous Series #5) by Michael Wallace for $1.00 (ive read 1-4)",
  "id" : 381799417122013185,
  "in_reply_to_status_id" : 381787850355654657,
  "created_at" : "2013-09-22 15:17:29 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 28, 40 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381559857674858496",
  "geo" : { },
  "id_str" : "381560343421399040",
  "in_reply_to_user_id" : 31282286,
  "text" : "me, either! ((highfive)) RT @TheOracle13 I do not comply with the rules.",
  "id" : 381560343421399040,
  "in_reply_to_status_id" : 381559857674858496,
  "created_at" : "2013-09-21 23:27:29 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "indices" : [ 3, 18 ],
      "id_str" : "615318971",
      "id" : 615318971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381558055785082880",
  "text" : "RT @CuestionMarque: \"If GOP can call universal HC 'socialized medicine,' then I'll call 4profit HC 'soulless, bastards making money off hum\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381555585730084865",
    "text" : "\"If GOP can call universal HC 'socialized medicine,' then I'll call 4profit HC 'soulless, bastards making money off human pain.\" -Bill Maher",
    "id" : 381555585730084865,
    "created_at" : "2013-09-21 23:08:35 +0000",
    "user" : {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "protected" : false,
      "id_str" : "615318971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2347711009\/5slm7j57n6tf4g5d98ia_normal.jpeg",
      "id" : 615318971,
      "verified" : false
    }
  },
  "id" : 381558055785082880,
  "created_at" : "2013-09-21 23:18:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BaJRFXBkY0",
      "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/pages\/frontline\/sickaroundtheworld\/countries\/",
      "display_url" : "pbs.org\/wgbh\/pages\/fro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381518991639851008",
  "text" : "RT @AllOnMedicare: In Switzerland, the average deductible is $500 - or less! - a year! #ObamaCare must be improved! http:\/\/t.co\/BaJRFXBkY0 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 68, 78 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 120, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/BaJRFXBkY0",
        "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/pages\/frontline\/sickaroundtheworld\/countries\/",
        "display_url" : "pbs.org\/wgbh\/pages\/fro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381518149830447104",
    "text" : "In Switzerland, the average deductible is $500 - or less! - a year! #ObamaCare must be improved! http:\/\/t.co\/BaJRFXBkY0 #SinglePayer",
    "id" : 381518149830447104,
    "created_at" : "2013-09-21 20:39:49 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 381518991639851008,
  "created_at" : "2013-09-21 20:43:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381515740311867392",
  "text" : "im too fat for a prom dress : (",
  "id" : 381515740311867392,
  "created_at" : "2013-09-21 20:30:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381445547422253057",
  "text" : "RT @BrianRathbone: There is no truth; only perception.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381444581365403648",
    "text" : "There is no truth; only perception.",
    "id" : 381444581365403648,
    "created_at" : "2013-09-21 15:47:29 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 381445547422253057,
  "created_at" : "2013-09-21 15:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 26, 38 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Buddhaworld\/status\/381424749319958528\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/JV1xtgdofe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUsXydVCQAAtTMm.jpg",
      "id_str" : "381424749076692992",
      "id" : 381424749076692992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUsXydVCQAAtTMm.jpg",
      "sizes" : [ {
        "h" : 1632,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JV1xtgdofe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381424749319958528",
  "geo" : { },
  "id_str" : "381433742562041856",
  "in_reply_to_user_id" : 40560386,
  "text" : "love black eyed susans RT @Buddhaworld http:\/\/t.co\/JV1xtgdofe",
  "id" : 381433742562041856,
  "in_reply_to_status_id" : 381424749319958528,
  "created_at" : "2013-09-21 15:04:25 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 28, 40 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Buddhaworld\/status\/381425687195709441\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/hHfImY3yWv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUsYpDHCcAAB0Oe.jpg",
      "id_str" : "381425686931468288",
      "id" : 381425686931468288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUsYpDHCcAAB0Oe.jpg",
      "sizes" : [ {
        "h" : 1632,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hHfImY3yWv"
    } ],
    "hashtags" : [ {
      "text" : "flowers",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381425687195709441",
  "geo" : { },
  "id_str" : "381432771723292674",
  "in_reply_to_user_id" : 40560386,
  "text" : "soft and cloudy #flowers RT @Buddhaworld http:\/\/t.co\/hHfImY3yWv",
  "id" : 381432771723292674,
  "in_reply_to_status_id" : 381425687195709441,
  "created_at" : "2013-09-21 15:00:34 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 0, 14 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381427387868930048",
  "geo" : { },
  "id_str" : "381432336635555844",
  "in_reply_to_user_id" : 16494321,
  "text" : "@BrianRathbone LOLOL",
  "id" : 381432336635555844,
  "in_reply_to_status_id" : 381427387868930048,
  "created_at" : "2013-09-21 14:58:50 +0000",
  "in_reply_to_screen_name" : "BrianRathbone",
  "in_reply_to_user_id_str" : "16494321",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 0, 11 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381427962177798144",
  "geo" : { },
  "id_str" : "381432227143225344",
  "in_reply_to_user_id" : 7482152,
  "text" : "@modernevil hope it's a wonderful day for you : )",
  "id" : 381432227143225344,
  "in_reply_to_status_id" : 381427962177798144,
  "created_at" : "2013-09-21 14:58:24 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381430082222292994",
  "geo" : { },
  "id_str" : "381432017537101824",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell well, yeah.. lol",
  "id" : 381432017537101824,
  "in_reply_to_status_id" : 381430082222292994,
  "created_at" : "2013-09-21 14:57:34 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/381430082222292994\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yL2Ct0RdXY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUsco34CYAA5cAN.jpg",
      "id_str" : "381430081962270720",
      "id" : 381430081962270720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUsco34CYAA5cAN.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/yL2Ct0RdXY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/g4Ftjn6ld3",
      "expanded_url" : "http:\/\/9gag.com\/gag\/a6wV86N?ref=mobile",
      "display_url" : "9gag.com\/gag\/a6wV86N?re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381431925614735360",
  "text" : "RT @ChrisCapparell: God: Metaphor for the Universe http:\/\/t.co\/g4Ftjn6ld3\n\nPSH! I'VE BEEN SAYING THAT SHIT FOR YEARS! http:\/\/t.co\/yL2Ct0RdXY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/381430082222292994\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/yL2Ct0RdXY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUsco34CYAA5cAN.jpg",
        "id_str" : "381430081962270720",
        "id" : 381430081962270720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUsco34CYAA5cAN.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/yL2Ct0RdXY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/g4Ftjn6ld3",
        "expanded_url" : "http:\/\/9gag.com\/gag\/a6wV86N?ref=mobile",
        "display_url" : "9gag.com\/gag\/a6wV86N?re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381430082222292994",
    "text" : "God: Metaphor for the Universe http:\/\/t.co\/g4Ftjn6ld3\n\nPSH! I'VE BEEN SAYING THAT SHIT FOR YEARS! http:\/\/t.co\/yL2Ct0RdXY",
    "id" : 381430082222292994,
    "created_at" : "2013-09-21 14:49:52 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 381431925614735360,
  "created_at" : "2013-09-21 14:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "indices" : [ 3, 17 ],
      "id_str" : "38596022",
      "id" : 38596022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381431722983690240",
  "text" : "RT @livingthepoem: Karma's a bitch. Until you befriend her. Then she's not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381431265682927617",
    "text" : "Karma's a bitch. Until you befriend her. Then she's not.",
    "id" : 381431265682927617,
    "created_at" : "2013-09-21 14:54:35 +0000",
    "user" : {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "protected" : false,
      "id_str" : "38596022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741293678854086656\/P_FDuZdJ_normal.jpg",
      "id" : 38596022,
      "verified" : false
    }
  },
  "id" : 381431722983690240,
  "created_at" : "2013-09-21 14:56:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 19, 31 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Buddhaworld\/status\/381431431014006784\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/oUj5H2W4ON",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUsd3XPCUAAUFYU.jpg",
      "id_str" : "381431430410031104",
      "id" : 381431430410031104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUsd3XPCUAAUFYU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1840
      } ],
      "display_url" : "pic.twitter.com\/oUj5H2W4ON"
    } ],
    "hashtags" : [ {
      "text" : "flowers",
      "indices" : [ 7, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381431431014006784",
  "geo" : { },
  "id_str" : "381431666142478336",
  "in_reply_to_user_id" : 40560386,
  "text" : "pretty #flowers RT @Buddhaworld http:\/\/t.co\/oUj5H2W4ON",
  "id" : 381431666142478336,
  "in_reply_to_status_id" : 381431431014006784,
  "created_at" : "2013-09-21 14:56:10 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381414873541771264",
  "geo" : { },
  "id_str" : "381415768413331456",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny hehe",
  "id" : 381415768413331456,
  "in_reply_to_status_id" : 381414873541771264,
  "created_at" : "2013-09-21 13:53:00 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ksV4BzCxaq",
      "expanded_url" : "http:\/\/amzn.to\/O5jhua",
      "display_url" : "amzn.to\/O5jhua"
    } ]
  },
  "geo" : { },
  "id_str" : "381241148700127232",
  "text" : "finished Morgue Drawer Next Door by Jutta Profijt http:\/\/t.co\/ksV4BzCxaq",
  "id" : 381241148700127232,
  "created_at" : "2013-09-21 02:19:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381233309814370304",
  "text" : "RT @PeggySueCusses: If Obama can give waivers to big corporations and all of Congress where are the waivers for the working folks?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381233228087955456",
    "text" : "If Obama can give waivers to big corporations and all of Congress where are the waivers for the working folks?",
    "id" : 381233228087955456,
    "created_at" : "2013-09-21 01:47:39 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 381233309814370304,
  "created_at" : "2013-09-21 01:47:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 3, 15 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381232238215835648",
  "text" : "RT @MotherJones: 3 private prisons in Arizona have 100% occupancy quotas\u2014meaning the state must keep them filled, crime or not. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/LH7EZExCke",
        "expanded_url" : "http:\/\/mojo.ly\/159obfG",
        "display_url" : "mojo.ly\/159obfG"
      } ]
    },
    "geo" : { },
    "id_str" : "381157756943618048",
    "text" : "3 private prisons in Arizona have 100% occupancy quotas\u2014meaning the state must keep them filled, crime or not. http:\/\/t.co\/LH7EZExCke",
    "id" : 381157756943618048,
    "created_at" : "2013-09-20 20:47:45 +0000",
    "user" : {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "protected" : false,
      "id_str" : "18510860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731988002206027776\/c0HB7fbs_normal.jpg",
      "id" : 18510860,
      "verified" : true
    }
  },
  "id" : 381232238215835648,
  "created_at" : "2013-09-21 01:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim C.",
      "screen_name" : "DelGirlsHoops",
      "indices" : [ 3, 17 ],
      "id_str" : "379270752",
      "id" : 379270752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unpopularopinionnight",
      "indices" : [ 67, 89 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 91, 103 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381216364444151809",
  "text" : "RT @DelGirlsHoops: Healthcare for all is a RIGHT not a PRIVILEGE.  #unpopularopinionnight  #singlepayer  not #Obamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "unpopularopinionnight",
        "indices" : [ 48, 70 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 90, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381195396451549184",
    "text" : "Healthcare for all is a RIGHT not a PRIVILEGE.  #unpopularopinionnight  #singlepayer  not #Obamacare",
    "id" : 381195396451549184,
    "created_at" : "2013-09-20 23:17:19 +0000",
    "user" : {
      "name" : "Jim C.",
      "screen_name" : "DelGirlsHoops",
      "protected" : false,
      "id_str" : "379270752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682677623969984512\/h7CIuHiD_normal.png",
      "id" : 379270752,
      "verified" : false
    }
  },
  "id" : 381216364444151809,
  "created_at" : "2013-09-21 00:40:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ER75rFCGjW",
      "expanded_url" : "http:\/\/youtu.be\/x54Jr-NPDCc",
      "display_url" : "youtu.be\/x54Jr-NPDCc"
    } ]
  },
  "geo" : { },
  "id_str" : "381192294461751297",
  "text" : "LOLOL &gt;&gt; The Dressage Horse: http:\/\/t.co\/ER75rFCGjW",
  "id" : 381192294461751297,
  "created_at" : "2013-09-20 23:04:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 16, 25 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/381184813455011840\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/WMxtvvxYra",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUo9kXgCcAIi7mo.jpg",
      "id_str" : "381184813459206146",
      "id" : 381184813459206146,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUo9kXgCcAIi7mo.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/WMxtvvxYra"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381186871880998912",
  "text" : "RT @SangyeH: RT @BobTarte: Our 22-year-old ring-necked dove Howard still comes out to play every day. http:\/\/t.co\/WMxtvvxYra || Aww. I love\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bob Tarte",
        "screen_name" : "BobTarte",
        "indices" : [ 3, 12 ],
        "id_str" : "490591746",
        "id" : 490591746
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/381184813455011840\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/WMxtvvxYra",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUo9kXgCcAIi7mo.jpg",
        "id_str" : "381184813459206146",
        "id" : 381184813459206146,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUo9kXgCcAIi7mo.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/WMxtvvxYra"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381185130775064576",
    "text" : "RT @BobTarte: Our 22-year-old ring-necked dove Howard still comes out to play every day. http:\/\/t.co\/WMxtvvxYra || Aww. I love that!",
    "id" : 381185130775064576,
    "created_at" : "2013-09-20 22:36:31 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 381186871880998912,
  "created_at" : "2013-09-20 22:43:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/8HjoAOaVXB",
      "expanded_url" : "http:\/\/atheismplus.com\/wiki\/index.php?title=Main_Page",
      "display_url" : "atheismplus.com\/wiki\/index.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381179914994458624",
  "text" : "RT @Charmantides: http:\/\/t.co\/8HjoAOaVXB Ive been pressing random page for a bit but still no clues what atheism+ is for. Or is. Or why it \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/8HjoAOaVXB",
        "expanded_url" : "http:\/\/atheismplus.com\/wiki\/index.php?title=Main_Page",
        "display_url" : "atheismplus.com\/wiki\/index.php\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381179228403691520",
    "text" : "http:\/\/t.co\/8HjoAOaVXB Ive been pressing random page for a bit but still no clues what atheism+ is for. Or is. Or why it had to be upgraded.",
    "id" : 381179228403691520,
    "created_at" : "2013-09-20 22:13:04 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 381179914994458624,
  "created_at" : "2013-09-20 22:15:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "progressivephd",
      "screen_name" : "CallOut4",
      "indices" : [ 3, 12 ],
      "id_str" : "990627116",
      "id" : 990627116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381179798636093440",
  "text" : "RT @CallOut4: Drug testing welfare applicants is costly &amp; stigmatizing. How about drug testing corporate welfare applicants? http:\/\/t.co\/g9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jsc5150\/status\/375760194191360000\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/g9iyCloTqL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTb359_CAAADLeJ.jpg",
        "id_str" : "375760194195554304",
        "id" : 375760194195554304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTb359_CAAADLeJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/g9iyCloTqL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381179291054387200",
    "text" : "Drug testing welfare applicants is costly &amp; stigmatizing. How about drug testing corporate welfare applicants? http:\/\/t.co\/g9iyCloTqL",
    "id" : 381179291054387200,
    "created_at" : "2013-09-20 22:13:19 +0000",
    "user" : {
      "name" : "progressivephd",
      "screen_name" : "CallOut4",
      "protected" : false,
      "id_str" : "990627116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3202535746\/c967d0f782877dfd5539de5cb1b6ba6a_normal.png",
      "id" : 990627116,
      "verified" : false
    }
  },
  "id" : 381179798636093440,
  "created_at" : "2013-09-20 22:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piccola Bee",
      "screen_name" : "PicoBee",
      "indices" : [ 3, 11 ],
      "id_str" : "263022323",
      "id" : 263022323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "US",
      "indices" : [ 20, 23 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 59, 71 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 106, 116 ]
    }, {
      "text" : "GOP",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/QXJPbVXjZY",
      "expanded_url" : "http:\/\/tinyurl.com\/9utjou8",
      "display_url" : "tinyurl.com\/9utjou8"
    } ]
  },
  "geo" : { },
  "id_str" : "381179758869893120",
  "text" : "RT @PicoBee: Hello! #US Spends 2.5X MORE than Countries w\/ #SinglePayer Healthcare http:\/\/t.co\/QXJPbVXjZY #Obamacare #GOP http:\/\/t.co\/2ijhW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "US",
        "indices" : [ 7, 10 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 46, 58 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 93, 103 ]
      }, {
        "text" : "GOP",
        "indices" : [ 104, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/QXJPbVXjZY",
        "expanded_url" : "http:\/\/tinyurl.com\/9utjou8",
        "display_url" : "tinyurl.com\/9utjou8"
      }, {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/2ijhWMq81K",
        "expanded_url" : "http:\/\/twitpic.com\/decn2j",
        "display_url" : "twitpic.com\/decn2j"
      } ]
    },
    "geo" : { },
    "id_str" : "381153766193393664",
    "text" : "Hello! #US Spends 2.5X MORE than Countries w\/ #SinglePayer Healthcare http:\/\/t.co\/QXJPbVXjZY #Obamacare #GOP http:\/\/t.co\/2ijhWMq81K",
    "id" : 381153766193393664,
    "created_at" : "2013-09-20 20:31:54 +0000",
    "user" : {
      "name" : "Piccola Bee",
      "screen_name" : "PicoBee",
      "protected" : false,
      "id_str" : "263022323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3001685769\/d7e3969a407ae1bb905da03d2a4087c4_normal.jpeg",
      "id" : 263022323,
      "verified" : false
    }
  },
  "id" : 381179758869893120,
  "created_at" : "2013-09-20 22:15:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381168920385712128",
  "text" : "@Lluminous_ Yes!!",
  "id" : 381168920385712128,
  "created_at" : "2013-09-20 21:32:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381163576808845312",
  "text" : "RT @bcmystery: If you like a thing I don\u2019t like, thats cool. If I like a thing you don\u2019t like, that\u2019s also cool.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381162659812372480",
    "text" : "If you like a thing I don\u2019t like, thats cool. If I like a thing you don\u2019t like, that\u2019s also cool.",
    "id" : 381162659812372480,
    "created_at" : "2013-09-20 21:07:14 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 381163576808845312,
  "created_at" : "2013-09-20 21:10:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381149435184443392",
  "text" : "RT @UnseeingEyes: Find the cure to CANCERS or AIDS...and because there is no money in cures, only treatments...nobody will ever find your b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381148789278404608",
    "text" : "Find the cure to CANCERS or AIDS...and because there is no money in cures, only treatments...nobody will ever find your body. Good luck.",
    "id" : 381148789278404608,
    "created_at" : "2013-09-20 20:12:07 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 381149435184443392,
  "created_at" : "2013-09-20 20:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381149183329071104",
  "text" : "@weakSquare do i get a prize? ps. i googled it.. is that cheating? (i consider it \"researching\"..lol)",
  "id" : 381149183329071104,
  "created_at" : "2013-09-20 20:13:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381145901604941824",
  "text" : "@Cosmicnomica cool beans!",
  "id" : 381145901604941824,
  "created_at" : "2013-09-20 20:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip J Asshole",
      "screen_name" : "MajAsshole",
      "indices" : [ 3, 14 ],
      "id_str" : "526483233",
      "id" : 526483233
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 16, 28 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381129628682702849",
  "text" : "RT @MajAsshole: @BarackObama skip this bullshit #SinglePayer like the rest of the civilized world",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 32, 44 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "381105462520717312",
    "geo" : { },
    "id_str" : "381109346081730560",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama skip this bullshit #SinglePayer like the rest of the civilized world",
    "id" : 381109346081730560,
    "in_reply_to_status_id" : 381105462520717312,
    "created_at" : "2013-09-20 17:35:23 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Philip J Asshole",
      "screen_name" : "MajAsshole",
      "protected" : false,
      "id_str" : "526483233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1901177723\/0mTU35b7_normal",
      "id" : 526483233,
      "verified" : false
    }
  },
  "id" : 381129628682702849,
  "created_at" : "2013-09-20 18:55:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siddharth Bhandari",
      "screen_name" : "CapedShadow",
      "indices" : [ 8, 20 ],
      "id_str" : "260672764",
      "id" : 260672764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ZQFVBPSGU2",
      "expanded_url" : "http:\/\/qr.ae\/TQMU4",
      "display_url" : "qr.ae\/TQMU4"
    } ]
  },
  "geo" : { },
  "id_str" : "381128358303498240",
  "text" : "Post by @CapedShadow: A Day at the Park http:\/\/t.co\/ZQFVBPSGU2",
  "id" : 381128358303498240,
  "created_at" : "2013-09-20 18:50:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381109243568726016",
  "geo" : { },
  "id_str" : "381112708453507072",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg yes, they can. ((hugs))",
  "id" : 381112708453507072,
  "in_reply_to_status_id" : 381109243568726016,
  "created_at" : "2013-09-20 17:48:45 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381100294118969346",
  "text" : "@weakSquare V for Vendetta",
  "id" : 381100294118969346,
  "created_at" : "2013-09-20 16:59:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 2, 17 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381098635309490177",
  "geo" : { },
  "id_str" : "381099558228336641",
  "in_reply_to_user_id" : 63804234,
  "text" : ". @PeggySueCusses we cant afford either and i think forcing ppl to buy health insurance is wrong. we need #singlepayer like other 1st world.",
  "id" : 381099558228336641,
  "in_reply_to_status_id" : 381098635309490177,
  "created_at" : "2013-09-20 16:56:29 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 2, 18 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381097023031631872",
  "geo" : { },
  "id_str" : "381098715341017088",
  "in_reply_to_user_id" : 14364749,
  "text" : ". @shoeofallcosmos why? if you're vacc, you should not get sick.",
  "id" : 381098715341017088,
  "in_reply_to_status_id" : 381097023031631872,
  "created_at" : "2013-09-20 16:53:08 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "indices" : [ 3, 19 ],
      "id_str" : "179121328",
      "id" : 179121328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381093203459309568",
  "text" : "RT @thesilverspiral: Many religions give you a set of rules to follow and call it \"morality.\" That's obedience, not morality, and they are \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381087807747276800",
    "text" : "Many religions give you a set of rules to follow and call it \"morality.\" That's obedience, not morality, and they are not the same thing.",
    "id" : 381087807747276800,
    "created_at" : "2013-09-20 16:09:48 +0000",
    "user" : {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "protected" : false,
      "id_str" : "179121328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476331163322052609\/9eQZmrqN_normal.jpeg",
      "id" : 179121328,
      "verified" : false
    }
  },
  "id" : 381093203459309568,
  "created_at" : "2013-09-20 16:31:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "The Refusers",
      "screen_name" : "the_refusers",
      "indices" : [ 125, 138 ],
      "id_str" : "268117600",
      "id" : 268117600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381084273043714048",
  "geo" : { },
  "id_str" : "381092307602137088",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos i think ppl have right to refuse vacc. regardless of reason. in this case, she has med history prov. injury @the_refusers",
  "id" : 381092307602137088,
  "in_reply_to_status_id" : 381084273043714048,
  "created_at" : "2013-09-20 16:27:41 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Refusers",
      "screen_name" : "the_refusers",
      "indices" : [ 3, 16 ],
      "id_str" : "268117600",
      "id" : 268117600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0ovwtTJh7H",
      "expanded_url" : "http:\/\/fb.me\/16QJdnT32",
      "display_url" : "fb.me\/16QJdnT32"
    } ]
  },
  "geo" : { },
  "id_str" : "381082221047590913",
  "text" : "RT @the_refusers: NY State to six year old girl: Get vaccinated, we don\u2019t care if your doctor says it will kill you. http:\/\/t.co\/0ovwtTJh7H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/0ovwtTJh7H",
        "expanded_url" : "http:\/\/fb.me\/16QJdnT32",
        "display_url" : "fb.me\/16QJdnT32"
      } ]
    },
    "geo" : { },
    "id_str" : "381079833356148736",
    "text" : "NY State to six year old girl: Get vaccinated, we don\u2019t care if your doctor says it will kill you. http:\/\/t.co\/0ovwtTJh7H",
    "id" : 381079833356148736,
    "created_at" : "2013-09-20 15:38:07 +0000",
    "user" : {
      "name" : "The Refusers",
      "screen_name" : "the_refusers",
      "protected" : false,
      "id_str" : "268117600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754058318138658816\/jfNg0Wnf_normal.jpg",
      "id" : 268117600,
      "verified" : false
    }
  },
  "id" : 381082221047590913,
  "created_at" : "2013-09-20 15:47:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381079835486846978",
  "text" : "@1stCitizenKane truth. all in perception. takes time to see the box, outside the box then see there never was any box but what we made.",
  "id" : 381079835486846978,
  "created_at" : "2013-09-20 15:38:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381078348736122882",
  "text" : "RT @DeepakChopra: No elementary particle has absolute properties independent of other particles.Parts can't be be detached from the whole #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 120, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381062085515284480",
    "text" : "No elementary particle has absolute properties independent of other particles.Parts can't be be detached from the whole #CosmicConsciousness",
    "id" : 381062085515284480,
    "created_at" : "2013-09-20 14:27:35 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 381078348736122882,
  "created_at" : "2013-09-20 15:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381067556125036544",
  "text" : "@weakSquare hmmm... ((ponders))",
  "id" : 381067556125036544,
  "created_at" : "2013-09-20 14:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B.",
      "screen_name" : "lov3jonez",
      "indices" : [ 15, 25 ],
      "id_str" : "18738345",
      "id" : 18738345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381058119926702080",
  "geo" : { },
  "id_str" : "381066029922660352",
  "in_reply_to_user_id" : 184401626,
  "text" : "@BasedHippyGod @lov3jonez some ppl still dont get kids are not born blank slate but \"pre-programmed\" .. you work w what you got..lol",
  "id" : 381066029922660352,
  "in_reply_to_status_id" : 381058119926702080,
  "created_at" : "2013-09-20 14:43:16 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380941055253688320",
  "geo" : { },
  "id_str" : "381065372297740289",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia just trying to see your line of thinking...",
  "id" : 381065372297740289,
  "in_reply_to_status_id" : 380941055253688320,
  "created_at" : "2013-09-20 14:40:39 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380941055253688320",
  "geo" : { },
  "id_str" : "381065181339455488",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia dont consider myself christian but i am unique..hehe.",
  "id" : 381065181339455488,
  "in_reply_to_status_id" : 380941055253688320,
  "created_at" : "2013-09-20 14:39:53 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "DC Holt",
      "screen_name" : "poempeddler",
      "indices" : [ 18, 30 ],
      "id_str" : "2375930892",
      "id" : 2375930892
    }, {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 32, 41 ],
      "id_str" : "15754281",
      "id" : 15754281
    }, {
      "name" : "Kate_C",
      "screen_name" : "KC52inNC",
      "indices" : [ 42, 51 ],
      "id_str" : "235475262",
      "id" : 235475262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380843397356871680",
  "text" : "RT @Jamiastar: RT @poempeddler: @USATODAY @KC52inNC can we keep feeding the poor &amp; stop feeding Congress instead? And maybe stop paying Con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DC Holt",
        "screen_name" : "poempeddler",
        "indices" : [ 3, 15 ],
        "id_str" : "2375930892",
        "id" : 2375930892
      }, {
        "name" : "USA TODAY",
        "screen_name" : "USATODAY",
        "indices" : [ 17, 26 ],
        "id_str" : "15754281",
        "id" : 15754281
      }, {
        "name" : "Kate_C",
        "screen_name" : "KC52inNC",
        "indices" : [ 27, 36 ],
        "id_str" : "235475262",
        "id" : 235475262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380843217698037760",
    "text" : "RT @poempeddler: @USATODAY @KC52inNC can we keep feeding the poor &amp; stop feeding Congress instead? And maybe stop paying Congress too?",
    "id" : 380843217698037760,
    "created_at" : "2013-09-19 23:57:53 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 380843397356871680,
  "created_at" : "2013-09-19 23:58:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380839301241532416",
  "text" : "RT @CoyoteSings: How is it we will spend any amount of money to bomb some country into the stone age, but we won't spend enough money to fe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380837689861230592",
    "text" : "How is it we will spend any amount of money to bomb some country into the stone age, but we won't spend enough money to feed our own people?",
    "id" : 380837689861230592,
    "created_at" : "2013-09-19 23:35:55 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 380839301241532416,
  "created_at" : "2013-09-19 23:42:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Midway Journey",
      "screen_name" : "midwayjourney",
      "indices" : [ 13, 27 ],
      "id_str" : "66284191",
      "id" : 66284191
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 79, 88 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/clijSI1SAE",
      "expanded_url" : "http:\/\/www.upworthy.com\/people-should-know-about-this-awful-thing-we-do-and-most-of-us-are-simply-unaware?g=3&c=ufb1",
      "display_url" : "upworthy.com\/people-should-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380820787076153344",
  "text" : "The poignant @MidwayJourney is heartbreaking, horrifying, and beautiful.  (via @Upworthy) http:\/\/t.co\/clijSI1SAE",
  "id" : 380820787076153344,
  "created_at" : "2013-09-19 22:28:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380817065692516352",
  "text" : "RT @JohnCali: This is pretty graphic. Before he dies, what this guy does for his child is beautiful. @TROPFEEST (via @Upworthy) http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Upworthy",
        "screen_name" : "Upworthy",
        "indices" : [ 103, 112 ],
        "id_str" : "524396430",
        "id" : 524396430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Fw7p8twvyA",
        "expanded_url" : "http:\/\/www.upworthy.com\/before-he-dies-what-this-guy-does-for-his-child-is-beautiful?g=2",
        "display_url" : "upworthy.com\/before-he-dies\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380806560156368896",
    "text" : "This is pretty graphic. Before he dies, what this guy does for his child is beautiful. @TROPFEEST (via @Upworthy) http:\/\/t.co\/Fw7p8twvyA",
    "id" : 380806560156368896,
    "created_at" : "2013-09-19 21:32:13 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 380817065692516352,
  "created_at" : "2013-09-19 22:13:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 0, 9 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380806560156368896",
  "geo" : { },
  "id_str" : "380817009144905728",
  "in_reply_to_user_id" : 27094110,
  "text" : "@JohnCali i hate to cry, dammit ((sniffles))",
  "id" : 380817009144905728,
  "in_reply_to_status_id" : 380806560156368896,
  "created_at" : "2013-09-19 22:13:44 +0000",
  "in_reply_to_screen_name" : "JohnCali",
  "in_reply_to_user_id_str" : "27094110",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shay Stewart Bouley",
      "screen_name" : "blackgirlinmain",
      "indices" : [ 3, 19 ],
      "id_str" : "25178222",
      "id" : 25178222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380802862915137536",
  "text" : "RT @blackgirlinmain: People on food stamps often have jobs, why is that not well known. Many people who use benefits have jobs, the jobs do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380787411640254464",
    "text" : "People on food stamps often have jobs, why is that not well known. Many people who use benefits have jobs, the jobs don't pay enough.",
    "id" : 380787411640254464,
    "created_at" : "2013-09-19 20:16:08 +0000",
    "user" : {
      "name" : "Shay Stewart Bouley",
      "screen_name" : "blackgirlinmain",
      "protected" : false,
      "id_str" : "25178222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766397566061772801\/2jS-YuqS_normal.jpg",
      "id" : 25178222,
      "verified" : true
    }
  },
  "id" : 380802862915137536,
  "created_at" : "2013-09-19 21:17:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380749372545183746",
  "text" : "RT @Wolf_Mommy: I would also like to say that I made the call to the doctor this morning: we were seen, xray'd &amp; began treatment within thr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380744881406099456",
    "text" : "I would also like to say that I made the call to the doctor this morning: we were seen, xray'd &amp; began treatment within three hours.",
    "id" : 380744881406099456,
    "created_at" : "2013-09-19 17:27:08 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 380749372545183746,
  "created_at" : "2013-09-19 17:44:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380749219595685888",
  "text" : "RT @Wolf_Mommy: So for all you who think we have second rate medical care here in Canada because its universalized, I say again this is not\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380745055834628097",
    "text" : "So for all you who think we have second rate medical care here in Canada because its universalized, I say again this is not my experience.",
    "id" : 380745055834628097,
    "created_at" : "2013-09-19 17:27:49 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 380749219595685888,
  "created_at" : "2013-09-19 17:44:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Sears",
      "screen_name" : "sears_zc",
      "indices" : [ 3, 12 ],
      "id_str" : "1337309900",
      "id" : 1337309900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380742312575266817",
  "text" : "RT @sears_zc: I hope people realize that after Obamacare starts there will still be tens of millions uninsured &amp; many more with bad insuran\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 132, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380733579002511360",
    "text" : "I hope people realize that after Obamacare starts there will still be tens of millions uninsured &amp; many more with bad insurance #singlepayer",
    "id" : 380733579002511360,
    "created_at" : "2013-09-19 16:42:13 +0000",
    "user" : {
      "name" : "Zach Sears",
      "screen_name" : "sears_zc",
      "protected" : false,
      "id_str" : "1337309900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737164223726247936\/jFI57xYT_normal.jpg",
      "id" : 1337309900,
      "verified" : false
    }
  },
  "id" : 380742312575266817,
  "created_at" : "2013-09-19 17:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "corinne",
      "screen_name" : "corinne565",
      "indices" : [ 3, 14 ],
      "id_str" : "112308211",
      "id" : 112308211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380742273438191616",
  "text" : "RT @corinne565: the problem w\/ Obamacare is it benefits ins co profiteers and NOT patients. we need SinglePayer\/Medicare for all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380720664346632192",
    "text" : "the problem w\/ Obamacare is it benefits ins co profiteers and NOT patients. we need SinglePayer\/Medicare for all.",
    "id" : 380720664346632192,
    "created_at" : "2013-09-19 15:50:54 +0000",
    "user" : {
      "name" : "corinne",
      "screen_name" : "corinne565",
      "protected" : false,
      "id_str" : "112308211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519624035768885248\/TauuEYNN_normal.jpeg",
      "id" : 112308211,
      "verified" : false
    }
  },
  "id" : 380742273438191616,
  "created_at" : "2013-09-19 17:16:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "corinne",
      "screen_name" : "corinne565",
      "indices" : [ 0, 11 ],
      "id_str" : "112308211",
      "id" : 112308211
    }, {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 18, 32 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380720664346632192",
  "geo" : { },
  "id_str" : "380742258120597504",
  "in_reply_to_user_id" : 112308211,
  "text" : "@corinne565 YES!! @AllOnMedicare",
  "id" : 380742258120597504,
  "in_reply_to_status_id" : 380720664346632192,
  "created_at" : "2013-09-19 17:16:42 +0000",
  "in_reply_to_screen_name" : "corinne565",
  "in_reply_to_user_id_str" : "112308211",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inherit My Wind",
      "screen_name" : "StinkyMalloy01",
      "indices" : [ 3, 18 ],
      "id_str" : "385083807",
      "id" : 385083807
    }, {
      "name" : "Aetna",
      "screen_name" : "Aetna",
      "indices" : [ 91, 97 ],
      "id_str" : "16188518",
      "id" : 16188518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380730047906058240",
  "text" : "RT @StinkyMalloy01: I can buy my 3 generics at full price and pay less than the cost of my @Aetna Rx monthly premium. Wonder what the price\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aetna",
        "screen_name" : "Aetna",
        "indices" : [ 71, 77 ],
        "id_str" : "16188518",
        "id" : 16188518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380717720301367297",
    "text" : "I can buy my 3 generics at full price and pay less than the cost of my @Aetna Rx monthly premium. Wonder what the price increase is for?",
    "id" : 380717720301367297,
    "created_at" : "2013-09-19 15:39:12 +0000",
    "user" : {
      "name" : "Inherit My Wind",
      "screen_name" : "StinkyMalloy01",
      "protected" : false,
      "id_str" : "385083807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596804781663920128\/v3GkOodM_normal.png",
      "id" : 385083807,
      "verified" : false
    }
  },
  "id" : 380730047906058240,
  "created_at" : "2013-09-19 16:28:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inherit My Wind",
      "screen_name" : "StinkyMalloy01",
      "indices" : [ 3, 18 ],
      "id_str" : "385083807",
      "id" : 385083807
    }, {
      "name" : "Aetna",
      "screen_name" : "Aetna",
      "indices" : [ 37, 43 ],
      "id_str" : "16188518",
      "id" : 16188518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380729994231574529",
  "text" : "RT @StinkyMalloy01: When questioned, @Aetna gave no reason for premium increase, other than 'med cost increase'. My 3 generics are not incr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aetna",
        "screen_name" : "Aetna",
        "indices" : [ 17, 23 ],
        "id_str" : "16188518",
        "id" : 16188518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380717207375728640",
    "text" : "When questioned, @Aetna gave no reason for premium increase, other than 'med cost increase'. My 3 generics are not increasing. Hmmm.",
    "id" : 380717207375728640,
    "created_at" : "2013-09-19 15:37:10 +0000",
    "user" : {
      "name" : "Inherit My Wind",
      "screen_name" : "StinkyMalloy01",
      "protected" : false,
      "id_str" : "385083807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596804781663920128\/v3GkOodM_normal.png",
      "id" : 385083807,
      "verified" : false
    }
  },
  "id" : 380729994231574529,
  "created_at" : "2013-09-19 16:27:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Watchdog Progressive",
      "screen_name" : "Watchdogsniffer",
      "indices" : [ 2, 18 ],
      "id_str" : "279164084",
      "id" : 279164084
    }, {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 19, 29 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380718993612349440",
  "geo" : { },
  "id_str" : "380722457570586625",
  "in_reply_to_user_id" : 279164084,
  "text" : ". @Watchdogsniffer @Jamiastar yup.. lead us right off the cliff.",
  "id" : 380722457570586625,
  "in_reply_to_status_id" : 380718993612349440,
  "created_at" : "2013-09-19 15:58:02 +0000",
  "in_reply_to_screen_name" : "Watchdogsniffer",
  "in_reply_to_user_id_str" : "279164084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Watchdog Progressive",
      "screen_name" : "Watchdogsniffer",
      "indices" : [ 3, 19 ],
      "id_str" : "279164084",
      "id" : 279164084
    }, {
      "name" : "Susanna",
      "screen_name" : "SusannaMatte",
      "indices" : [ 21, 34 ],
      "id_str" : "270528803",
      "id" : 270528803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380720961676259328",
  "text" : "RT @Watchdogsniffer: @SusannaMatte cont. the best healthcare is when the middlemen - profit takers - are cut out and physicians make the de\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susanna",
        "screen_name" : "SusannaMatte",
        "indices" : [ 0, 13 ],
        "id_str" : "270528803",
        "id" : 270528803
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "380718171063205888",
    "geo" : { },
    "id_str" : "380719864953860098",
    "in_reply_to_user_id" : 270528803,
    "text" : "@SusannaMatte cont. the best healthcare is when the middlemen - profit takers - are cut out and physicians make the decisions.",
    "id" : 380719864953860098,
    "in_reply_to_status_id" : 380718171063205888,
    "created_at" : "2013-09-19 15:47:43 +0000",
    "in_reply_to_screen_name" : "SusannaMatte",
    "in_reply_to_user_id_str" : "270528803",
    "user" : {
      "name" : "Watchdog Progressive",
      "screen_name" : "Watchdogsniffer",
      "protected" : false,
      "id_str" : "279164084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678759140362063872\/4ed1mGey_normal.jpg",
      "id" : 279164084,
      "verified" : false
    }
  },
  "id" : 380720961676259328,
  "created_at" : "2013-09-19 15:52:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380718653869535233",
  "text" : "health insurance company objectives at odds with consumer objectives. you pay a fee to a co. that does not want to service you!",
  "id" : 380718653869535233,
  "created_at" : "2013-09-19 15:42:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380718317117251584",
  "text" : "plus health insurance companies can deny treatment or meds for whatever reason regardless of DR opinion or medical condition",
  "id" : 380718317117251584,
  "created_at" : "2013-09-19 15:41:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aca",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380717291005964288",
  "text" : "forcing ppl to buy health insurance when you have to pay the premium then also percent of bill is not \"affordable\" #aca #singlepayer",
  "id" : 380717291005964288,
  "created_at" : "2013-09-19 15:37:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "indices" : [ 3, 16 ],
      "id_str" : "16744783",
      "id" : 16744783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/IKiGbXG2cP",
      "expanded_url" : "http:\/\/bestsellerlabs.com\/hugh-howeys-clever-book-promotion\/",
      "display_url" : "bestsellerlabs.com\/hugh-howeys-cl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380713826783469568",
  "text" : "RT @LisaTBergren: The cool new WOOL\/DUST promotion. He's a marketing genius! http:\/\/t.co\/IKiGbXG2cP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/IKiGbXG2cP",
        "expanded_url" : "http:\/\/bestsellerlabs.com\/hugh-howeys-clever-book-promotion\/",
        "display_url" : "bestsellerlabs.com\/hugh-howeys-cl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380702466179743744",
    "text" : "The cool new WOOL\/DUST promotion. He's a marketing genius! http:\/\/t.co\/IKiGbXG2cP",
    "id" : 380702466179743744,
    "created_at" : "2013-09-19 14:38:35 +0000",
    "user" : {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "protected" : false,
      "id_str" : "16744783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694980555096457216\/ApJGMyxi_normal.jpg",
      "id" : 16744783,
      "verified" : false
    }
  },
  "id" : 380713826783469568,
  "created_at" : "2013-09-19 15:23:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryan broderick",
      "screen_name" : "ryanpbroderick",
      "indices" : [ 109, 124 ],
      "id_str" : "2841498821",
      "id" : 2841498821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DWgCTB1zpG",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/ryanhatesthis\/oh-my-god-theres-a-cat-in-russia-that-wears-a-bow-tie-and-wo",
      "display_url" : "buzzfeed.com\/ryanhatesthis\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380703403984183296",
  "text" : "Oh My God, There\u2019s A Cat In Russia That Wears A Bow Tie And Works As A Librarian http:\/\/t.co\/DWgCTB1zpG  via @ryanpbroderick",
  "id" : 380703403984183296,
  "created_at" : "2013-09-19 14:42:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eldonphotography",
      "screen_name" : "eldonphoto",
      "indices" : [ 3, 14 ],
      "id_str" : "783808459594608641",
      "id" : 783808459594608641
    }, {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 88, 98 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoPressgram",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/LpszudanyS",
      "expanded_url" : "http:\/\/wp.me\/p28v2W-xY",
      "display_url" : "wp.me\/p28v2W-xY"
    } ]
  },
  "geo" : { },
  "id_str" : "380702732459311105",
  "text" : "RT @EldonPhoto: Setting Up Wordpress To Play Nice With Pressgram http:\/\/t.co\/LpszudanyS @Pressgram #GoPressgram",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pressgram",
        "screen_name" : "Pressgram",
        "indices" : [ 72, 82 ],
        "id_str" : "1066032464",
        "id" : 1066032464
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoPressgram",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/LpszudanyS",
        "expanded_url" : "http:\/\/wp.me\/p28v2W-xY",
        "display_url" : "wp.me\/p28v2W-xY"
      } ]
    },
    "geo" : { },
    "id_str" : "380689065286193153",
    "text" : "Setting Up Wordpress To Play Nice With Pressgram http:\/\/t.co\/LpszudanyS @Pressgram #GoPressgram",
    "id" : 380689065286193153,
    "created_at" : "2013-09-19 13:45:20 +0000",
    "user" : {
      "name" : "Eldon Yoder",
      "screen_name" : "eldoneyoder",
      "protected" : false,
      "id_str" : "80942200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1585380366\/September_2011-6253-Edit_normal.jpg",
      "id" : 80942200,
      "verified" : false
    }
  },
  "id" : 380702732459311105,
  "created_at" : "2013-09-19 14:39:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380687031275241472",
  "text" : "RT @MiMi43770: By now, we should all know our politicians are bought, our TV is propaganda &amp; distraction, and the GOP\/Dem paradigm is to se\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OWS",
        "indices" : [ 139, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380554351246188544",
    "text" : "By now, we should all know our politicians are bought, our TV is propaganda &amp; distraction, and the GOP\/Dem paradigm is to separate us. #OWS",
    "id" : 380554351246188544,
    "created_at" : "2013-09-19 04:50:02 +0000",
    "user" : {
      "name" : "MiMi For Progeny",
      "screen_name" : "_MiMiOh",
      "protected" : false,
      "id_str" : "13738192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798741703716786176\/fKyMwJ0q_normal.jpg",
      "id" : 13738192,
      "verified" : false
    }
  },
  "id" : 380687031275241472,
  "created_at" : "2013-09-19 13:37:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tinashe",
      "screen_name" : "tinasheontweets",
      "indices" : [ 3, 19 ],
      "id_str" : "23497670",
      "id" : 23497670
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christians",
      "indices" : [ 28, 39 ]
    }, {
      "text" : "Friends",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/PwOFXdMswJ",
      "expanded_url" : "http:\/\/redemptionpictures.com\/2013\/08\/22\/friend-of-sinners\/",
      "display_url" : "redemptionpictures.com\/2013\/08\/22\/fri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380685286012747777",
  "text" : "RT @tinasheontweets: Should #Christians be #Friends of 'Sinners'? Here's a thought provoking article http:\/\/t.co\/PwOFXdMswJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Christians",
        "indices" : [ 7, 18 ]
      }, {
        "text" : "Friends",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/PwOFXdMswJ",
        "expanded_url" : "http:\/\/redemptionpictures.com\/2013\/08\/22\/friend-of-sinners\/",
        "display_url" : "redemptionpictures.com\/2013\/08\/22\/fri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374748328434487296",
    "text" : "Should #Christians be #Friends of 'Sinners'? Here's a thought provoking article http:\/\/t.co\/PwOFXdMswJ",
    "id" : 374748328434487296,
    "created_at" : "2013-09-03 04:18:58 +0000",
    "user" : {
      "name" : "Tinashe",
      "screen_name" : "tinasheontweets",
      "protected" : false,
      "id_str" : "23497670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794520969498935296\/pWzZbqzy_normal.jpg",
      "id" : 23497670,
      "verified" : false
    }
  },
  "id" : 380685286012747777,
  "created_at" : "2013-09-19 13:30:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380468564538298368",
  "geo" : { },
  "id_str" : "380491587316219906",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind but.. as @weakSquare said earlier beliefs are not something we choose.. they just are.",
  "id" : 380491587316219906,
  "in_reply_to_status_id" : 380468564538298368,
  "created_at" : "2013-09-19 00:40:38 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex",
      "screen_name" : "SelfExamineLife",
      "indices" : [ 79, 95 ],
      "id_str" : "220219500",
      "id" : 220219500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380490748417675264",
  "text" : "@weakSquare the problem is.. humans as a whole cannot agree on heinous or not. @SelfExamineLife",
  "id" : 380490748417675264,
  "created_at" : "2013-09-19 00:37:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380489641700253696",
  "text" : "RT @ZachsMind: You know what good gun control is? A mind that knows better than to aim one at a fellow human being's head. That's controlli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380468768134012928",
    "text" : "You know what good gun control is? A mind that knows better than to aim one at a fellow human being's head. That's controlling a gun.",
    "id" : 380468768134012928,
    "created_at" : "2013-09-18 23:09:57 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 380489641700253696,
  "created_at" : "2013-09-19 00:32:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 3, 19 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/bKUg7IJJjT",
      "expanded_url" : "http:\/\/bit.ly\/16nNLxT",
      "display_url" : "bit.ly\/16nNLxT"
    } ]
  },
  "geo" : { },
  "id_str" : "380488478699433984",
  "text" : "RT @ChristnNitemare: Ray Comfort says Bill Nye is wrong about moonlight because of Beethoven\u2019s \u2018Moonlight Sonata\u2019 http:\/\/t.co\/bKUg7IJJjT cc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robyn Pennacchia",
        "screen_name" : "RobynElyse",
        "indices" : [ 121, 132 ],
        "id_str" : "803061715",
        "id" : 803061715
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/bKUg7IJJjT",
        "expanded_url" : "http:\/\/bit.ly\/16nNLxT",
        "display_url" : "bit.ly\/16nNLxT"
      } ]
    },
    "geo" : { },
    "id_str" : "380471927757737985",
    "text" : "Ray Comfort says Bill Nye is wrong about moonlight because of Beethoven\u2019s \u2018Moonlight Sonata\u2019 http:\/\/t.co\/bKUg7IJJjT cc: \n@RobynElyse",
    "id" : 380471927757737985,
    "created_at" : "2013-09-18 23:22:31 +0000",
    "user" : {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "protected" : false,
      "id_str" : "116009507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1537898085\/Christian_Nightmares_mug_normal.jpg",
      "id" : 116009507,
      "verified" : false
    }
  },
  "id" : 380488478699433984,
  "created_at" : "2013-09-19 00:28:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380470322505334784",
  "text" : "RT @ZachsMind: The answer is not gun control. We already have gun control. Thousands of laws already on the books and IT'S NOT WORKING.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380468171255189505",
    "text" : "The answer is not gun control. We already have gun control. Thousands of laws already on the books and IT'S NOT WORKING.",
    "id" : 380468171255189505,
    "created_at" : "2013-09-18 23:07:35 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 380470322505334784,
  "created_at" : "2013-09-18 23:16:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Barbara Lee",
      "screen_name" : "RepBarbaraLee",
      "indices" : [ 3, 17 ],
      "id_str" : "248735463",
      "id" : 248735463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SNAP",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380454935055175680",
  "text" : "RT @RepBarbaraLee: House GOP are proposing $40 BILLION in cuts to #SNAP! Cuts are immoral, unconscionable, and economically unsound! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepBarbaraLee\/status\/380092494488141824\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/QD9mqQ699y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUZcHAuCMAAP2p9.jpg",
        "id_str" : "380092494081306624",
        "id" : 380092494081306624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUZcHAuCMAAP2p9.jpg",
        "sizes" : [ {
          "h" : 3000,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QD9mqQ699y"
      } ],
      "hashtags" : [ {
        "text" : "SNAP",
        "indices" : [ 47, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380092494488141824",
    "text" : "House GOP are proposing $40 BILLION in cuts to #SNAP! Cuts are immoral, unconscionable, and economically unsound! http:\/\/t.co\/QD9mqQ699y",
    "id" : 380092494488141824,
    "created_at" : "2013-09-17 22:14:47 +0000",
    "user" : {
      "name" : "Rep. Barbara Lee",
      "screen_name" : "RepBarbaraLee",
      "protected" : false,
      "id_str" : "248735463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430378206353317888\/3QKYak-Z_normal.jpeg",
      "id" : 248735463,
      "verified" : true
    }
  },
  "id" : 380454935055175680,
  "created_at" : "2013-09-18 22:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Trump Resistance",
      "screen_name" : "papaouch",
      "indices" : [ 3, 12 ],
      "id_str" : "57120187",
      "id" : 57120187
    }, {
      "name" : "Anthony Halvorson",
      "screen_name" : "Armbarftw",
      "indices" : [ 14, 24 ],
      "id_str" : "591330751",
      "id" : 591330751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380452067547951104",
  "text" : "RT @papaouch: @Armbarftw There's gotta be a better way. People will postpone seeing a doctor whe it's too late. #SinglePayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Halvorson",
        "screen_name" : "Armbarftw",
        "indices" : [ 0, 10 ],
        "id_str" : "591330751",
        "id" : 591330751
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "380442265585328128",
    "geo" : { },
    "id_str" : "380446862035410944",
    "in_reply_to_user_id" : 591330751,
    "text" : "@Armbarftw There's gotta be a better way. People will postpone seeing a doctor whe it's too late. #SinglePayer",
    "id" : 380446862035410944,
    "in_reply_to_status_id" : 380442265585328128,
    "created_at" : "2013-09-18 21:42:54 +0000",
    "in_reply_to_screen_name" : "Armbarftw",
    "in_reply_to_user_id_str" : "591330751",
    "user" : {
      "name" : "The Trump Resistance",
      "screen_name" : "papaouch",
      "protected" : false,
      "id_str" : "57120187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796727273244266500\/uELlikUb_normal.jpg",
      "id" : 57120187,
      "verified" : false
    }
  },
  "id" : 380452067547951104,
  "created_at" : "2013-09-18 22:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "indices" : [ 12, 28 ],
      "id_str" : "74907005",
      "id" : 74907005
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 39, 47 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ttWWTlPAhM",
      "expanded_url" : "http:\/\/youtu.be\/VZ5bS3_BCDs?a",
      "display_url" : "youtu.be\/VZ5bS3_BCDs?a"
    } ]
  },
  "in_reply_to_status_id_str" : "380423099591581697",
  "geo" : { },
  "id_str" : "380428281905836032",
  "in_reply_to_user_id" : 74907005,
  "text" : "memories RT @RiseofPerdition I liked a @YouTube video http:\/\/t.co\/ttWWTlPAhM  Def Leppard - Photograph",
  "id" : 380428281905836032,
  "in_reply_to_status_id" : 380423099591581697,
  "created_at" : "2013-09-18 20:29:05 +0000",
  "in_reply_to_screen_name" : "Riseofperdition",
  "in_reply_to_user_id_str" : "74907005",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Chase",
      "screen_name" : "BonnieChaseRN",
      "indices" : [ 3, 17 ],
      "id_str" : "769701993971535873",
      "id" : 769701993971535873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380419192035352577",
  "text" : "RT @BonnieChaseRN: With every act of kindness, you radiate peace to the universe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380402923437817856",
    "text" : "With every act of kindness, you radiate peace to the universe.",
    "id" : 380402923437817856,
    "created_at" : "2013-09-18 18:48:19 +0000",
    "user" : {
      "name" : "Curvy Sisters",
      "screen_name" : "CurvySisters",
      "protected" : false,
      "id_str" : "345456338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768813073905823744\/C-uLMA0h_normal.jpg",
      "id" : 345456338,
      "verified" : false
    }
  },
  "id" : 380419192035352577,
  "created_at" : "2013-09-18 19:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 3, 19 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380418979484794880",
  "text" : "RT @hilltopfarmgirl: This calf was born on Saturday morning, the mother will often hide them in long grass returning throughout the day htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/380404574508429313\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/MxE4uc8DuT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUd38e8CMAACQPP.jpg",
        "id_str" : "380404574516817920",
        "id" : 380404574516817920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUd38e8CMAACQPP.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MxE4uc8DuT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380404574508429313",
    "text" : "This calf was born on Saturday morning, the mother will often hide them in long grass returning throughout the day http:\/\/t.co\/MxE4uc8DuT",
    "id" : 380404574508429313,
    "created_at" : "2013-09-18 18:54:52 +0000",
    "user" : {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "protected" : false,
      "id_str" : "457436503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3491566457\/61244b7682c638ad4b0a097321ae762e_normal.jpeg",
      "id" : 457436503,
      "verified" : false
    }
  },
  "id" : 380418979484794880,
  "created_at" : "2013-09-18 19:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Scott",
      "screen_name" : "NESASK",
      "indices" : [ 17, 24 ],
      "id_str" : "20373494",
      "id" : 20373494
    }, {
      "name" : "Dee",
      "screen_name" : "deephil11",
      "indices" : [ 102, 112 ],
      "id_str" : "177810624",
      "id" : 177810624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 39, 45 ]
    }, {
      "text" : "photography",
      "indices" : [ 46, 58 ]
    }, {
      "text" : "nature",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "corvids",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/gZU7Ioip3L",
      "expanded_url" : "http:\/\/twitpic.com\/de28qj",
      "display_url" : "twitpic.com\/de28qj"
    } ]
  },
  "geo" : { },
  "id_str" : "380416679773093888",
  "text" : "RT @gemswinc: RT @NESASK: Common Raven #birds #photography #nature #corvids http:\/\/t.co\/gZU7Ioip3L cc @deephil11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott",
        "screen_name" : "NESASK",
        "indices" : [ 3, 10 ],
        "id_str" : "20373494",
        "id" : 20373494
      }, {
        "name" : "Dee",
        "screen_name" : "deephil11",
        "indices" : [ 88, 98 ],
        "id_str" : "177810624",
        "id" : 177810624
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 25, 31 ]
      }, {
        "text" : "photography",
        "indices" : [ 32, 44 ]
      }, {
        "text" : "nature",
        "indices" : [ 45, 52 ]
      }, {
        "text" : "corvids",
        "indices" : [ 53, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/gZU7Ioip3L",
        "expanded_url" : "http:\/\/twitpic.com\/de28qj",
        "display_url" : "twitpic.com\/de28qj"
      } ]
    },
    "geo" : { },
    "id_str" : "380416211617861632",
    "text" : "RT @NESASK: Common Raven #birds #photography #nature #corvids http:\/\/t.co\/gZU7Ioip3L cc @deephil11",
    "id" : 380416211617861632,
    "created_at" : "2013-09-18 19:41:07 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 380416679773093888,
  "created_at" : "2013-09-18 19:42:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380410878870704128",
  "geo" : { },
  "id_str" : "380411599292346368",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny I was kinda hoping for more details.. but that answer will do..lol : )",
  "id" : 380411599292346368,
  "in_reply_to_status_id" : 380410878870704128,
  "created_at" : "2013-09-18 19:22:47 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380409822643892225",
  "geo" : { },
  "id_str" : "380410521008099328",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny really?",
  "id" : 380410521008099328,
  "in_reply_to_status_id" : 380409822643892225,
  "created_at" : "2013-09-18 19:18:30 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBH Network",
      "screen_name" : "PBHNetwork",
      "indices" : [ 71, 82 ],
      "id_str" : "56254243",
      "id" : 56254243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/jlkTRfPeC5",
      "expanded_url" : "http:\/\/po.st\/ktWvmt",
      "display_url" : "po.st\/ktWvmt"
    } ]
  },
  "geo" : { },
  "id_str" : "380405380351664128",
  "text" : "The Most Important Image Captured By Hubble http:\/\/t.co\/jlkTRfPeC5 via @pbhnetwork",
  "id" : 380405380351664128,
  "created_at" : "2013-09-18 18:58:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NerdAlert",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/U5JYtuuOeU",
      "expanded_url" : "http:\/\/huff.to\/1ema5QD",
      "display_url" : "huff.to\/1ema5QD"
    } ]
  },
  "geo" : { },
  "id_str" : "380402093732810752",
  "text" : "RT @ZeitgeistGhost: #NerdAlert: Earth's Core Spins In 2 Different Directions, Groundbreaking Research Reveals http:\/\/t.co\/U5JYtuuOeU inner \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NerdAlert",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/U5JYtuuOeU",
        "expanded_url" : "http:\/\/huff.to\/1ema5QD",
        "display_url" : "huff.to\/1ema5QD"
      } ]
    },
    "geo" : { },
    "id_str" : "380401176090394627",
    "text" : "#NerdAlert: Earth's Core Spins In 2 Different Directions, Groundbreaking Research Reveals http:\/\/t.co\/U5JYtuuOeU inner solid core spins fast",
    "id" : 380401176090394627,
    "created_at" : "2013-09-18 18:41:22 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 380402093732810752,
  "created_at" : "2013-09-18 18:45:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380400627957764096",
  "text" : "RT @AllOnMedicare: American health care is a transfer upwards from the middle class to wealthy for-profit insurance and hospital executives\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380400295513059328",
    "text" : "American health care is a transfer upwards from the middle class to wealthy for-profit insurance and hospital executives. #SinglePayer NOW!",
    "id" : 380400295513059328,
    "created_at" : "2013-09-18 18:37:52 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 380400627957764096,
  "created_at" : "2013-09-18 18:39:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/mlYU85OPdZ",
      "expanded_url" : "http:\/\/bit.ly\/16l0LnW",
      "display_url" : "bit.ly\/16l0LnW"
    } ]
  },
  "geo" : { },
  "id_str" : "380400356351430656",
  "text" : "RT @screek: Arkansas Bull Elk Lip Curling http:\/\/t.co\/mlYU85OPdZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/mlYU85OPdZ",
        "expanded_url" : "http:\/\/bit.ly\/16l0LnW",
        "display_url" : "bit.ly\/16l0LnW"
      } ]
    },
    "geo" : { },
    "id_str" : "380399848098631680",
    "text" : "Arkansas Bull Elk Lip Curling http:\/\/t.co\/mlYU85OPdZ",
    "id" : 380399848098631680,
    "created_at" : "2013-09-18 18:36:05 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 380400356351430656,
  "created_at" : "2013-09-18 18:38:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380379305814921216",
  "text" : "@weakSquare agree. belief (or non-belief) is the natural result of combination of emotions and reason.",
  "id" : 380379305814921216,
  "created_at" : "2013-09-18 17:14:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4eViCRl7pF",
      "expanded_url" : "http:\/\/www.upworthy.com\/a-debate-between-an-atheist-and-a-christian-has-quite-a-surprising-result?g=2",
      "display_url" : "upworthy.com\/a-debate-betwe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380358336434028544",
  "text" : "RT @TrishScott: I agree with them BOTH and it's a hoot. Check it out. A debate between a heathen and a son of a nun. http:\/\/t.co\/4eViCRl7pF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/4eViCRl7pF",
        "expanded_url" : "http:\/\/www.upworthy.com\/a-debate-between-an-atheist-and-a-christian-has-quite-a-surprising-result?g=2",
        "display_url" : "upworthy.com\/a-debate-betwe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380357353024937984",
    "text" : "I agree with them BOTH and it's a hoot. Check it out. A debate between a heathen and a son of a nun. http:\/\/t.co\/4eViCRl7pF",
    "id" : 380357353024937984,
    "created_at" : "2013-09-18 15:47:14 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 380358336434028544,
  "created_at" : "2013-09-18 15:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeePreviousTweet",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380332025510498305",
  "text" : "RT @Matth3ous: The NHS has to he less complicated than the system we have in America. It has too. #SeePreviousTweet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SeePreviousTweet",
        "indices" : [ 83, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380331266685820928",
    "text" : "The NHS has to he less complicated than the system we have in America. It has too. #SeePreviousTweet",
    "id" : 380331266685820928,
    "created_at" : "2013-09-18 14:03:34 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 380332025510498305,
  "created_at" : "2013-09-18 14:06:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380331933160308737",
  "text" : "RT @Matth3ous: I spent nearly two hours on the phone with insurance companies yesterday, looking like I'll have to spend at least an hour t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380331140818931712",
    "text" : "I spent nearly two hours on the phone with insurance companies yesterday, looking like I'll have to spend at least an hour tomorrow.",
    "id" : 380331140818931712,
    "created_at" : "2013-09-18 14:03:04 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 380331933160308737,
  "created_at" : "2013-09-18 14:06:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380331904882327553",
  "text" : "RT @Matth3ous: I am so sick of dealing with insurance companies. How the smeg do they expect people with a chronic condition and a job deal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380330602010247168",
    "text" : "I am so sick of dealing with insurance companies. How the smeg do they expect people with a chronic condition and a job deal with this?!",
    "id" : 380330602010247168,
    "created_at" : "2013-09-18 14:00:56 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 380331904882327553,
  "created_at" : "2013-09-18 14:06:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380328564299550720",
  "text" : "RT @UnseeingEyes: The key to everything in life is EDUCATION; creating a more informed &amp; intelligent populous; not limiting freedoms.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380174841577758720",
    "text" : "The key to everything in life is EDUCATION; creating a more informed &amp; intelligent populous; not limiting freedoms.",
    "id" : 380174841577758720,
    "created_at" : "2013-09-18 03:42:00 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 380328564299550720,
  "created_at" : "2013-09-18 13:52:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380141889670115328",
  "text" : "RT @AllOnMedicare: It's imperative that we educate others about the humanity of #SinglePayer systems in Canada\/Europe and brutality of our \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380136998435975168",
    "text" : "It's imperative that we educate others about the humanity of #SinglePayer systems in Canada\/Europe and brutality of our system.",
    "id" : 380136998435975168,
    "created_at" : "2013-09-18 01:11:37 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 380141889670115328,
  "created_at" : "2013-09-18 01:31:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380141867687751680",
  "text" : "RT @AllOnMedicare: #SinglePayer is about raising consciousness. How many of you knew how fucked up the US health care system was at 25? #Me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 117, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380136898452131840",
    "text" : "#SinglePayer is about raising consciousness. How many of you knew how fucked up the US health care system was at 25? #MedicareForAll",
    "id" : 380136898452131840,
    "created_at" : "2013-09-18 01:11:13 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 380141867687751680,
  "created_at" : "2013-09-18 01:30:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "breakingoutishardtodo",
      "indices" : [ 109, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380134880405114880",
  "text" : "RT @ChickenJen: I think it's time to color outside the lines. I'm just not sure where the lines are anymore. #breakingoutishardtodo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "breakingoutishardtodo",
        "indices" : [ 93, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380133332383576064",
    "text" : "I think it's time to color outside the lines. I'm just not sure where the lines are anymore. #breakingoutishardtodo",
    "id" : 380133332383576064,
    "created_at" : "2013-09-18 00:57:03 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 380134880405114880,
  "created_at" : "2013-09-18 01:03:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380115539126792194",
  "geo" : { },
  "id_str" : "380124569706577921",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms thank you for replying : ) (but, no, its not about me personally.. just feeling the crazy vibes..lol)",
  "id" : 380124569706577921,
  "in_reply_to_status_id" : 380115539126792194,
  "created_at" : "2013-09-18 00:22:14 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 2, 14 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380115539126792194",
  "geo" : { },
  "id_str" : "380123935506849793",
  "in_reply_to_user_id" : 15349954,
  "text" : ". @angelaharms just referring to this crazy world.. one person says this, another says that. each thinks they're the right stance.. ack!",
  "id" : 380123935506849793,
  "in_reply_to_status_id" : 380115539126792194,
  "created_at" : "2013-09-18 00:19:43 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Rotella",
      "screen_name" : "tankaqueen",
      "indices" : [ 3, 14 ],
      "id_str" : "159558577",
      "id" : 159558577
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "Micropoetry",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380123172869115904",
  "text" : "RT @tankaqueen: Harvest moon\nmy estranged brother I know\nis watching it too.  #haiku #Micropoetry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 62, 68 ]
      }, {
        "text" : "Micropoetry",
        "indices" : [ 69, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380114088195407872",
    "text" : "Harvest moon\nmy estranged brother I know\nis watching it too.  #haiku #Micropoetry",
    "id" : 380114088195407872,
    "created_at" : "2013-09-17 23:40:35 +0000",
    "user" : {
      "name" : "Alexis Rotella",
      "screen_name" : "tankaqueen",
      "protected" : false,
      "id_str" : "159558577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1408416838\/lipprints_normal.jpg",
      "id" : 159558577,
      "verified" : false
    }
  },
  "id" : 380123172869115904,
  "created_at" : "2013-09-18 00:16:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380114828582322177",
  "text" : "just lay down and die. there's no more sense in trying to make it work anymore. it never will.",
  "id" : 380114828582322177,
  "created_at" : "2013-09-17 23:43:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380104845408997376",
  "text" : "@1stCitizenKane all laws are stupid. #freedom",
  "id" : 380104845408997376,
  "created_at" : "2013-09-17 23:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 43, 54 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/yTaGND5Hu7",
      "expanded_url" : "http:\/\/tl.gd\/n_1rn9t9h",
      "display_url" : "tl.gd\/n_1rn9t9h"
    } ]
  },
  "geo" : { },
  "id_str" : "380100189945876480",
  "text" : "No obamacare. We need #singlepayer NOW! RT @SenTedCruz NBC\/WSJ poll: By 2-1 margin, Americans think (cont) http:\/\/t.co\/yTaGND5Hu7",
  "id" : 380100189945876480,
  "created_at" : "2013-09-17 22:45:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380094164404170752",
  "geo" : { },
  "id_str" : "380095629046738944",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 oh my.. glad you're still with us. ((hugs))",
  "id" : 380095629046738944,
  "in_reply_to_status_id" : 380094164404170752,
  "created_at" : "2013-09-17 22:27:14 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not John Green",
      "screen_name" : "realjohngreen",
      "indices" : [ 38, 52 ],
      "id_str" : "2796445679",
      "id" : 2796445679
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 86, 95 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9B2OSv3eTa",
      "expanded_url" : "http:\/\/www.upworthy.com\/his-first-4-sentences-are-interesting-the-5th-blew-my-mind-and-made-me-a-little-sick-2?g=2&c=ufb1",
      "display_url" : "upworthy.com\/his-first-4-se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380079928168828929",
  "text" : "You are anti-health-care reform? Then @realjohngreen is gonna get real with you. (via @Upworthy) http:\/\/t.co\/9B2OSv3eTa",
  "id" : 380079928168828929,
  "created_at" : "2013-09-17 21:24:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380016116333944832",
  "text" : "i couldnt take the small white car i usually will drive.. becuz i lost brakes and backed up into tree.",
  "id" : 380016116333944832,
  "created_at" : "2013-09-17 17:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380013770547818497",
  "text" : "i drove our chrysler pacifica today for 1st time since we got it (months ago.) she was a good girl, gentle w me..lol",
  "id" : 380013770547818497,
  "created_at" : "2013-09-17 17:01:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cam and Lauren",
      "screen_name" : "WrittenWoman",
      "indices" : [ 82, 95 ],
      "id_str" : "272930509",
      "id" : 272930509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/xlwPd5zW8f",
      "expanded_url" : "http:\/\/bit.ly\/184fUxx",
      "display_url" : "bit.ly\/184fUxx"
    } ]
  },
  "geo" : { },
  "id_str" : "379960654548836352",
  "text" : "FYI (If You\u2019ve Read Mrs. Hall\u2019s Post to Teenage Girls) http:\/\/t.co\/xlwPd5zW8f via @WrittenWoman",
  "id" : 379960654548836352,
  "created_at" : "2013-09-17 13:30:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/YY0nVmu4yd",
      "expanded_url" : "http:\/\/amzn.to\/Nnz9pc",
      "display_url" : "amzn.to\/Nnz9pc"
    } ]
  },
  "geo" : { },
  "id_str" : "379793855618772992",
  "text" : "finished Ghost in the Machine (Scott Cullen Mysteries) by Ed James http:\/\/t.co\/YY0nVmu4yd",
  "id" : 379793855618772992,
  "created_at" : "2013-09-17 02:28:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deplorable Dave",
      "screen_name" : "unaccounted_4",
      "indices" : [ 20, 34 ],
      "id_str" : "490093374",
      "id" : 490093374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamacare",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379779403242541056",
  "text" : "RT @health_citizen: @unaccounted_4 - #obamacare is a private insurance system - what we really need is #singlepayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deplorable Dave",
        "screen_name" : "unaccounted_4",
        "indices" : [ 0, 14 ],
        "id_str" : "490093374",
        "id" : 490093374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "obamacare",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "378771091155451904",
    "geo" : { },
    "id_str" : "378834680264814592",
    "in_reply_to_user_id" : 490093374,
    "text" : "@unaccounted_4 - #obamacare is a private insurance system - what we really need is #singlepayer",
    "id" : 378834680264814592,
    "in_reply_to_status_id" : 378771091155451904,
    "created_at" : "2013-09-14 10:56:40 +0000",
    "in_reply_to_screen_name" : "unaccounted_4",
    "in_reply_to_user_id_str" : "490093374",
    "user" : {
      "name" : "Dave Sterrett",
      "screen_name" : "sterrettlaw",
      "protected" : false,
      "id_str" : "1485827456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658262908833517569\/hZYGntOj_normal.jpg",
      "id" : 1485827456,
      "verified" : false
    }
  },
  "id" : 379779403242541056,
  "created_at" : "2013-09-17 01:30:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Elizabeth Esther",
      "screen_name" : "elizabethesther",
      "indices" : [ 61, 77 ],
      "id_str" : "15844821",
      "id" : 15844821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379776834675941376",
  "text" : "RT @micahjmurray: Related: \"I Kissed My Humanity Goodbye\" by @elizabethesther. Even though I'm a guy, this is my story too.  http:\/\/t.co\/wn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elizabeth Esther",
        "screen_name" : "elizabethesther",
        "indices" : [ 43, 59 ],
        "id_str" : "15844821",
        "id" : 15844821
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/wnhupkJ2wp",
        "expanded_url" : "http:\/\/www.elizabethesther.com\/2013\/01\/i-kissed-my-humanity-goodbye-how-the-evangelical-purity-culture-dehumanizes-women.html",
        "display_url" : "elizabethesther.com\/2013\/01\/i-kiss\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379772945809174528",
    "text" : "Related: \"I Kissed My Humanity Goodbye\" by @elizabethesther. Even though I'm a guy, this is my story too.  http:\/\/t.co\/wnhupkJ2wp",
    "id" : 379772945809174528,
    "created_at" : "2013-09-17 01:05:00 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 379776834675941376,
  "created_at" : "2013-09-17 01:20:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 62, 75 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/FT6sZJrBFj",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B007FGJP0S\/ref=cm_sw_r_tw_ask_antBG.12XTERG",
      "display_url" : "amazon.com\/dp\/B007FGJP0S\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379759214849429505",
  "text" : "I just bought: 'Morgue Drawer Next Door' by Jutta Profijt via @amazonkindle $2.00 .. looks like a fun series! http:\/\/t.co\/FT6sZJrBFj",
  "id" : 379759214849429505,
  "created_at" : "2013-09-17 00:10:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379748665100742656",
  "geo" : { },
  "id_str" : "379751493349294080",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell ive always talked to myself. as a kid, would walk the railroad ties in yard, chattering to myself. yeah...",
  "id" : 379751493349294080,
  "in_reply_to_status_id" : 379748665100742656,
  "created_at" : "2013-09-16 23:39:46 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379750214904451072",
  "text" : "ACK!!! my neck is TOO fat for a necklace I have worn before.. OMFGOMFGOMFG",
  "id" : 379750214904451072,
  "created_at" : "2013-09-16 23:34:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "W Smith \uD83D\uDCCE",
      "screen_name" : "WesSmith123",
      "indices" : [ 3, 15 ],
      "id_str" : "61149653",
      "id" : 61149653
    }, {
      "name" : "Ed Schultz",
      "screen_name" : "edshow",
      "indices" : [ 17, 24 ],
      "id_str" : "75052666",
      "id" : 75052666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EdShow",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379741199445139457",
  "text" : "RT @wessmith123: @edshow Its not about rights, it's always been about more money for Gun Mfg's &amp; corrupt politicians #EdShow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Schultz",
        "screen_name" : "edshow",
        "indices" : [ 0, 7 ],
        "id_str" : "75052666",
        "id" : 75052666
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EdShow",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379719528063967233",
    "in_reply_to_user_id" : 75052666,
    "text" : "@edshow Its not about rights, it's always been about more money for Gun Mfg's &amp; corrupt politicians #EdShow",
    "id" : 379719528063967233,
    "created_at" : "2013-09-16 21:32:45 +0000",
    "in_reply_to_screen_name" : "edshow",
    "in_reply_to_user_id_str" : "75052666",
    "user" : {
      "name" : "W Smith \uD83D\uDCCE",
      "screen_name" : "WesSmith123",
      "protected" : false,
      "id_str" : "61149653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797918809952780288\/Ndx6DgwS_normal.jpg",
      "id" : 61149653,
      "verified" : false
    }
  },
  "id" : 379741199445139457,
  "created_at" : "2013-09-16 22:58:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boop",
      "screen_name" : "kyletromblee",
      "indices" : [ 0, 13 ],
      "id_str" : "3420622093",
      "id" : 3420622093
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 14, 28 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379737043246395392",
  "text" : "@KyleTromblee @BibleAlsoSays lady in pink is FOR \"under God\" .. she's talking about atheists? umm..",
  "id" : 379737043246395392,
  "created_at" : "2013-09-16 22:42:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boop",
      "screen_name" : "kyletromblee",
      "indices" : [ 0, 13 ],
      "id_str" : "3420622093",
      "id" : 3420622093
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 14, 28 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379736694661988352",
  "text" : "@KyleTromblee @BibleAlsoSays umm.. the lady in pink @ 1:12 .. children are pawns; inflict their beliefs; force on everyone.. wth??",
  "id" : 379736694661988352,
  "created_at" : "2013-09-16 22:40:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin #J20",
      "screen_name" : "ikev85",
      "indices" : [ 3, 10 ],
      "id_str" : "50832119",
      "id" : 50832119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/QV2ARsmxdl",
      "expanded_url" : "http:\/\/unionsforsinglepayer.org\/news_releases\/2013-08-04",
      "display_url" : "unionsforsinglepayer.org\/news_releases\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379732749638062080",
  "text" : "RT @ikev85: The Medicare for All act would save $592bn in one (1) year http:\/\/t.co\/QV2ARsmxdl #singlepayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/QV2ARsmxdl",
        "expanded_url" : "http:\/\/unionsforsinglepayer.org\/news_releases\/2013-08-04",
        "display_url" : "unionsforsinglepayer.org\/news_releases\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379732102742556672",
    "text" : "The Medicare for All act would save $592bn in one (1) year http:\/\/t.co\/QV2ARsmxdl #singlepayer",
    "id" : 379732102742556672,
    "created_at" : "2013-09-16 22:22:43 +0000",
    "user" : {
      "name" : "Kevin #J20",
      "screen_name" : "ikev85",
      "protected" : false,
      "id_str" : "50832119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800805252060614656\/5ufREIcY_normal.jpg",
      "id" : 50832119,
      "verified" : false
    }
  },
  "id" : 379732749638062080,
  "created_at" : "2013-09-16 22:25:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379730523234398208",
  "text" : "@1stCitizenKane you really like that word hilarious.. lol",
  "id" : 379730523234398208,
  "created_at" : "2013-09-16 22:16:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379730162952044544",
  "text" : "@BibleAlsoSays he's not comfy w a threesome ; ) (oh i amuse myself so..LOL) @weakSquare",
  "id" : 379730162952044544,
  "created_at" : "2013-09-16 22:15:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379728898453688320",
  "geo" : { },
  "id_str" : "379729660960993280",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell its all about perception",
  "id" : 379729660960993280,
  "in_reply_to_status_id" : 379728898453688320,
  "created_at" : "2013-09-16 22:13:00 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/TAwCLGE0Y9",
      "expanded_url" : "http:\/\/huff.to\/1ej94IX",
      "display_url" : "huff.to\/1ej94IX"
    } ]
  },
  "geo" : { },
  "id_str" : "379728766085263360",
  "text" : "RT @HuffPostWeird: Drunk elk terrorizes Sweden http:\/\/t.co\/TAwCLGE0Y9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/TAwCLGE0Y9",
        "expanded_url" : "http:\/\/huff.to\/1ej94IX",
        "display_url" : "huff.to\/1ej94IX"
      } ]
    },
    "geo" : { },
    "id_str" : "379720159201865729",
    "text" : "Drunk elk terrorizes Sweden http:\/\/t.co\/TAwCLGE0Y9",
    "id" : 379720159201865729,
    "created_at" : "2013-09-16 21:35:15 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 379728766085263360,
  "created_at" : "2013-09-16 22:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366354780144156672",
  "geo" : { },
  "id_str" : "379728370663043072",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia hmm.. but you lump all christians together?",
  "id" : 379728370663043072,
  "in_reply_to_status_id" : 366354780144156672,
  "created_at" : "2013-09-16 22:07:53 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bah! Humblog.",
      "screen_name" : "bahhumblog",
      "indices" : [ 0, 11 ],
      "id_str" : "229877290",
      "id" : 229877290
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 12, 26 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379608630691389440",
  "geo" : { },
  "id_str" : "379725302038925313",
  "in_reply_to_user_id" : 229877290,
  "text" : "@bahhumblog @deisidiamonia dont have that problem. dont have real friends.. yay me? lol",
  "id" : 379725302038925313,
  "in_reply_to_status_id" : 379608630691389440,
  "created_at" : "2013-09-16 21:55:41 +0000",
  "in_reply_to_screen_name" : "bahhumblog",
  "in_reply_to_user_id_str" : "229877290",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379713979113021440",
  "geo" : { },
  "id_str" : "379715349098151936",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen yay for bees! : )",
  "id" : 379715349098151936,
  "in_reply_to_status_id" : 379713979113021440,
  "created_at" : "2013-09-16 21:16:08 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/holycutenesss\/status\/379703802992930816\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/76FOcPlzXx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUT6mNnCMAAk7m7.jpg",
      "id_str" : "379703803001319424",
      "id" : 379703803001319424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUT6mNnCMAAk7m7.jpg",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/76FOcPlzXx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/K13sSz3XmF",
      "expanded_url" : "http:\/\/bit.ly\/1eHRtLV",
      "display_url" : "bit.ly\/1eHRtLV"
    } ]
  },
  "geo" : { },
  "id_str" : "379705069500788736",
  "text" : "RT @holycutenesss: Cat chills with toad http:\/\/t.co\/K13sSz3XmF http:\/\/t.co\/76FOcPlzXx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/holycutenesss\/status\/379703802992930816\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/76FOcPlzXx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUT6mNnCMAAk7m7.jpg",
        "id_str" : "379703803001319424",
        "id" : 379703803001319424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUT6mNnCMAAk7m7.jpg",
        "sizes" : [ {
          "h" : 469,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/76FOcPlzXx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/K13sSz3XmF",
        "expanded_url" : "http:\/\/bit.ly\/1eHRtLV",
        "display_url" : "bit.ly\/1eHRtLV"
      } ]
    },
    "geo" : { },
    "id_str" : "379703802992930816",
    "text" : "Cat chills with toad http:\/\/t.co\/K13sSz3XmF http:\/\/t.co\/76FOcPlzXx",
    "id" : 379703802992930816,
    "created_at" : "2013-09-16 20:30:15 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 379705069500788736,
  "created_at" : "2013-09-16 20:35:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bible Lied",
      "screen_name" : "antibible_t",
      "indices" : [ 0, 12 ],
      "id_str" : "825718357",
      "id" : 825718357
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 13, 27 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379643788509347840",
  "geo" : { },
  "id_str" : "379704976798257152",
  "in_reply_to_user_id" : 825718357,
  "text" : "@antibible_t @deisidiamonia thats why i think nice thoughts. keeps my world shiny and clean! ; )",
  "id" : 379704976798257152,
  "in_reply_to_status_id" : 379643788509347840,
  "created_at" : "2013-09-16 20:34:55 +0000",
  "in_reply_to_screen_name" : "antibible_t",
  "in_reply_to_user_id_str" : "825718357",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 35, 41 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MWZmnhPWNs",
      "expanded_url" : "http:\/\/tl.gd\/n_1rmq36f",
      "display_url" : "tl.gd\/n_1rmq36f"
    } ]
  },
  "geo" : { },
  "id_str" : "379698941841137665",
  "text" : "hate it. need #SinglePayer NOW! RT @WebMD New York health care is changing. WebMD walks you through New (cont) http:\/\/t.co\/MWZmnhPWNs",
  "id" : 379698941841137665,
  "created_at" : "2013-09-16 20:10:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379670121960046592",
  "text" : "RT @Matth3ous: I have been on\/off hold with insurance for the past 31 minutes. To get a sight saving medication. This country's insurance s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379669023895846914",
    "text" : "I have been on\/off hold with insurance for the past 31 minutes. To get a sight saving medication. This country's insurance system is fucked.",
    "id" : 379669023895846914,
    "created_at" : "2013-09-16 18:12:03 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 379670121960046592,
  "created_at" : "2013-09-16 18:16:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 30, 37 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HKKfXsiTD5",
      "expanded_url" : "http:\/\/stevecreek.com\/a-buck-crouton\/",
      "display_url" : "stevecreek.com\/a-buck-crouton\/"
    } ]
  },
  "geo" : { },
  "id_str" : "379623394762702848",
  "text" : "RT @ChickenJen: Love this! RT @screek A Buck Crouton  http:\/\/t.co\/HKKfXsiTD5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 14, 21 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/HKKfXsiTD5",
        "expanded_url" : "http:\/\/stevecreek.com\/a-buck-crouton\/",
        "display_url" : "stevecreek.com\/a-buck-crouton\/"
      } ]
    },
    "geo" : { },
    "id_str" : "379622357058342912",
    "text" : "Love this! RT @screek A Buck Crouton  http:\/\/t.co\/HKKfXsiTD5",
    "id" : 379622357058342912,
    "created_at" : "2013-09-16 15:06:37 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 379623394762702848,
  "created_at" : "2013-09-16 15:10:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379618854210527232",
  "text" : "@1stCitizenKane very good point here.",
  "id" : 379618854210527232,
  "created_at" : "2013-09-16 14:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379617514264993793",
  "geo" : { },
  "id_str" : "379618506972475392",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX lucky kid. we dont have that option in NY. (my DD is a senior so mute point for us now..lol)",
  "id" : 379618506972475392,
  "in_reply_to_status_id" : 379617514264993793,
  "created_at" : "2013-09-16 14:51:19 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379394115508510721",
  "geo" : { },
  "id_str" : "379400530893615104",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind thanks for sharing. that was good! \"i would totally hang out with him\" lol",
  "id" : 379400530893615104,
  "in_reply_to_status_id" : 379394115508510721,
  "created_at" : "2013-09-16 00:25:10 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/zEzU2TvTNH",
      "expanded_url" : "http:\/\/www.upworthy.com\/a-debate-between-an-atheist-and-a-christian-has-quite-a-surprising-result",
      "display_url" : "upworthy.com\/a-debate-betwe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379399007677579264",
  "text" : "a debate between a heathen and a son of a nun.  http:\/\/t.co\/zEzU2TvTNH",
  "id" : 379399007677579264,
  "created_at" : "2013-09-16 00:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379395939426779136",
  "text" : "@1stCitizenKane i shouldnt laugh.. but reading that just made me LOL.",
  "id" : 379395939426779136,
  "created_at" : "2013-09-16 00:06:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 3, 11 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/vNVJyiqeYv",
      "expanded_url" : "http:\/\/fb.me\/2CDbpIakM",
      "display_url" : "fb.me\/2CDbpIakM"
    } ]
  },
  "geo" : { },
  "id_str" : "379362151858589696",
  "text" : "RT @arphaus: E-ZPasses Get Read All Over New York (Not Just At Toll Booths) http:\/\/t.co\/vNVJyiqeYv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/vNVJyiqeYv",
        "expanded_url" : "http:\/\/fb.me\/2CDbpIakM",
        "display_url" : "fb.me\/2CDbpIakM"
      } ]
    },
    "geo" : { },
    "id_str" : "379357366833389568",
    "text" : "E-ZPasses Get Read All Over New York (Not Just At Toll Booths) http:\/\/t.co\/vNVJyiqeYv",
    "id" : 379357366833389568,
    "created_at" : "2013-09-15 21:33:39 +0000",
    "user" : {
      "name" : "Arp Laszlo",
      "screen_name" : "thisisarp",
      "protected" : false,
      "id_str" : "7339162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773529857464688640\/ZPr3v43v_normal.jpg",
      "id" : 7339162,
      "verified" : false
    }
  },
  "id" : 379362151858589696,
  "created_at" : "2013-09-15 21:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 0, 10 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379358232977735680",
  "geo" : { },
  "id_str" : "379360311658029056",
  "in_reply_to_user_id" : 536104771,
  "text" : "@LonerW0lf years ago, psychic told my mom i was new soul,thats why life was hard for me but im def not conservative nor principled..lol",
  "id" : 379360311658029056,
  "in_reply_to_status_id" : 379358232977735680,
  "created_at" : "2013-09-15 21:45:21 +0000",
  "in_reply_to_screen_name" : "LonerW0lf",
  "in_reply_to_user_id_str" : "536104771",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379278642326405120",
  "text" : "Don't define yourself into a box. - me",
  "id" : 379278642326405120,
  "created_at" : "2013-09-15 16:20:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 2, 12 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379273908827877377",
  "geo" : { },
  "id_str" : "379275386539876352",
  "in_reply_to_user_id" : 16181537,
  "text" : ". @ZachsMind \"faith just no longer fits\" &lt;&lt; all of life is an exploration. we need to let ppl change.. faith, jobs, ppl, ideas. : )",
  "id" : 379275386539876352,
  "in_reply_to_status_id" : 379273908827877377,
  "created_at" : "2013-09-15 16:07:53 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pressgram",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379255268015501312",
  "text" : "any of my peeps on #pressgram ? looking to follow: nature, animals, landscapes...",
  "id" : 379255268015501312,
  "created_at" : "2013-09-15 14:47:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Hakkens",
      "screen_name" : "davehakkens",
      "indices" : [ 47, 59 ],
      "id_str" : "1101281168",
      "id" : 1101281168
    }, {
      "name" : "Dave Hakkens",
      "screen_name" : "davehakkens",
      "indices" : [ 99, 111 ],
      "id_str" : "1101281168",
      "id" : 1101281168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phonebloks",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/SBbj85gvFv",
      "expanded_url" : "http:\/\/www.phonebloks.com",
      "display_url" : "phonebloks.com"
    } ]
  },
  "geo" : { },
  "id_str" : "379245137668222976",
  "text" : "support phonebloks! - a phone worth keeping by @davehakkens http:\/\/t.co\/SBbj85gvFv #phonebloks via @davehakkens",
  "id" : 379245137668222976,
  "created_at" : "2013-09-15 14:07:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379027886709026816",
  "text" : "waiting for our people to come home. from syracuse. 3 hour drive. me and the dog...",
  "id" : 379027886709026816,
  "created_at" : "2013-09-14 23:44:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 0, 13 ],
      "id_str" : "121055499",
      "id" : 121055499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378963137644359680",
  "geo" : { },
  "id_str" : "378966860105936896",
  "in_reply_to_user_id" : 121055499,
  "text" : "@SpecterTracy sounds like good advice to me : )",
  "id" : 378966860105936896,
  "in_reply_to_status_id" : 378963137644359680,
  "created_at" : "2013-09-14 19:41:54 +0000",
  "in_reply_to_screen_name" : "SpecterTracy",
  "in_reply_to_user_id_str" : "121055499",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378955140977278977",
  "text" : "im watching LMN.. this will not end well for me...",
  "id" : 378955140977278977,
  "created_at" : "2013-09-14 18:55:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378925419224768512",
  "text" : "RT @Buddhaworld: Practice kindness, its results are life changing. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378924274305998848",
    "text" : "Practice kindness, its results are life changing. Buddha volko",
    "id" : 378924274305998848,
    "created_at" : "2013-09-14 16:52:41 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 378925419224768512,
  "created_at" : "2013-09-14 16:57:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "indices" : [ 3, 19 ],
      "id_str" : "191110048",
      "id" : 191110048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378925361897013250",
  "text" : "RT @ScienceThriller: Two more days to enter audiobook thriller giveaway. What if bacteria turned all the gasoline in LA into vinegar? http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/UG9wQMIFpP",
        "expanded_url" : "http:\/\/www.thebigthrill.org\/giveaway\/",
        "display_url" : "thebigthrill.org\/giveaway\/"
      } ]
    },
    "geo" : { },
    "id_str" : "378924599989137408",
    "text" : "Two more days to enter audiobook thriller giveaway. What if bacteria turned all the gasoline in LA into vinegar? http:\/\/t.co\/UG9wQMIFpP",
    "id" : 378924599989137408,
    "created_at" : "2013-09-14 16:53:59 +0000",
    "user" : {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "protected" : false,
      "id_str" : "191110048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509554102632587264\/zmyDrP9j_normal.jpeg",
      "id" : 191110048,
      "verified" : false
    }
  },
  "id" : 378925361897013250,
  "created_at" : "2013-09-14 16:57:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "_2020mojo_",
      "screen_name" : "_2020mojo_",
      "indices" : [ 57, 68 ],
      "id_str" : "13547872",
      "id" : 13547872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378886298380951552",
  "text" : "RT @TrishScott: No need to panic, it's nice out here. RT @_2020mojo_: Help, I thought outside the box, now I can't get back in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "_2020mojo_",
        "screen_name" : "_2020mojo_",
        "indices" : [ 41, 52 ],
        "id_str" : "13547872",
        "id" : 13547872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378865812485844992",
    "text" : "No need to panic, it's nice out here. RT @_2020mojo_: Help, I thought outside the box, now I can't get back in.",
    "id" : 378865812485844992,
    "created_at" : "2013-09-14 13:00:23 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 378886298380951552,
  "created_at" : "2013-09-14 14:21:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378866555955580928",
  "geo" : { },
  "id_str" : "378886091794706432",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ((hugs)) wonderful!",
  "id" : 378886091794706432,
  "in_reply_to_status_id" : 378866555955580928,
  "created_at" : "2013-09-14 14:20:58 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378885248542453760",
  "text" : "@Skeptical_Lady they follow someone who follows you and RT'd you so your name shows up in their timeline &lt;&lt; my guess",
  "id" : 378885248542453760,
  "created_at" : "2013-09-14 14:17:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378876686340587521",
  "geo" : { },
  "id_str" : "378883086693302272",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny poor dear sweet baby... just want to ((hug)) him",
  "id" : 378883086693302272,
  "in_reply_to_status_id" : 378876686340587521,
  "created_at" : "2013-09-14 14:09:01 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Thornton",
      "screen_name" : "mrshllthornton",
      "indices" : [ 29, 44 ],
      "id_str" : "19794894",
      "id" : 19794894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378877717992574977",
  "geo" : { },
  "id_str" : "378882311439122435",
  "in_reply_to_user_id" : 19794894,
  "text" : "that would be me &gt;&gt; RT @mrshllthornton Some people should come with warning labels.",
  "id" : 378882311439122435,
  "in_reply_to_status_id" : 378877717992574977,
  "created_at" : "2013-09-14 14:05:56 +0000",
  "in_reply_to_screen_name" : "mrshllthornton",
  "in_reply_to_user_id_str" : "19794894",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coco Pazzo",
      "screen_name" : "CocoPazzo",
      "indices" : [ 0, 10 ],
      "id_str" : "55712928",
      "id" : 55712928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378656333530025985",
  "geo" : { },
  "id_str" : "378670301585752065",
  "in_reply_to_user_id" : 55712928,
  "text" : "@CocoPazzo i hope so : )",
  "id" : 378670301585752065,
  "in_reply_to_status_id" : 378656333530025985,
  "created_at" : "2013-09-14 00:03:29 +0000",
  "in_reply_to_screen_name" : "CocoPazzo",
  "in_reply_to_user_id_str" : "55712928",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coco Pazzo",
      "screen_name" : "CocoPazzo",
      "indices" : [ 0, 10 ],
      "id_str" : "55712928",
      "id" : 55712928
    }, {
      "name" : "Forrest A Mow",
      "screen_name" : "chipsmow",
      "indices" : [ 83, 92 ],
      "id_str" : "218086325",
      "id" : 218086325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378648463556104192",
  "geo" : { },
  "id_str" : "378654211879092224",
  "in_reply_to_user_id" : 55712928,
  "text" : "@CocoPazzo whoa whoa whoa.. i hope he's got proof. i'd love to see this come down! @chipsmow",
  "id" : 378654211879092224,
  "in_reply_to_status_id" : 378648463556104192,
  "created_at" : "2013-09-13 22:59:33 +0000",
  "in_reply_to_screen_name" : "CocoPazzo",
  "in_reply_to_user_id_str" : "55712928",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Reduce Labour Hours",
      "screen_name" : "SunbeamTiger66",
      "indices" : [ 88, 103 ],
      "id_str" : "1594774508",
      "id" : 1594774508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378645559118020608",
  "geo" : { },
  "id_str" : "378646354362236928",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind depends which type of believers. thats usually blasphemy to most christians. @SunbeamTiger66",
  "id" : 378646354362236928,
  "in_reply_to_status_id" : 378645559118020608,
  "created_at" : "2013-09-13 22:28:20 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378642919520862208",
  "text" : "RT @derekrootboy: I'm now being followed by a lot of people who are only following intelligent, famous people and me. No, I don't understan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378641571236683776",
    "text" : "I'm now being followed by a lot of people who are only following intelligent, famous people and me. No, I don't understand it either.",
    "id" : 378641571236683776,
    "created_at" : "2013-09-13 22:09:20 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 378642919520862208,
  "created_at" : "2013-09-13 22:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378641420443086848",
  "text" : "emotionally repressed? yeah..",
  "id" : 378641420443086848,
  "created_at" : "2013-09-13 22:08:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 2, 12 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378636419016585217",
  "geo" : { },
  "id_str" : "378638230163169280",
  "in_reply_to_user_id" : 536104771,
  "text" : ". @LonerW0lf i absolutely hate to cry.. even when im alone!",
  "id" : 378638230163169280,
  "in_reply_to_status_id" : 378636419016585217,
  "created_at" : "2013-09-13 21:56:03 +0000",
  "in_reply_to_screen_name" : "LonerW0lf",
  "in_reply_to_user_id_str" : "536104771",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378633625366831104",
  "text" : "so what? we were all young once. does miley \"twerking\" or naked wrecking ball affect me? no.",
  "id" : 378633625366831104,
  "created_at" : "2013-09-13 21:37:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PleinairSan",
      "screen_name" : "PleinairSan",
      "indices" : [ 0, 12 ],
      "id_str" : "2546024868",
      "id" : 2546024868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378620579529515008",
  "text" : "@PleinairSan i DO use RT button.. lots 'n lots. In fact, too much. I need to work on tweeting more than RTing.",
  "id" : 378620579529515008,
  "created_at" : "2013-09-13 20:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PleinairSan",
      "screen_name" : "PleinairSan",
      "indices" : [ 0, 12 ],
      "id_str" : "2546024868",
      "id" : 2546024868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378620278235885568",
  "text" : "@PleinairSan yes, i know about rt button next to reply.. would using rt button include the additional @ names (making tweet too long?)",
  "id" : 378620278235885568,
  "created_at" : "2013-09-13 20:44:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378612682326147072",
  "text" : "should i add dumbass to my twitter profile? or is that overkill?",
  "id" : 378612682326147072,
  "created_at" : "2013-09-13 20:14:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378606985219813376",
  "text" : "RT @Buddhaworld: Dont think about the purpose of life, live it. Thats the purpose. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378606230643945474",
    "text" : "Dont think about the purpose of life, live it. Thats the purpose. Buddha volko",
    "id" : 378606230643945474,
    "created_at" : "2013-09-13 19:48:54 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 378606985219813376,
  "created_at" : "2013-09-13 19:51:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yupimaweirdo",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378606833037897728",
  "text" : "i want my prize.. i just got called dumbass on twitter for 1st time!! wooooo! #yupimaweirdo",
  "id" : 378606833037897728,
  "created_at" : "2013-09-13 19:51:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PleinairSan",
      "screen_name" : "PleinairSan",
      "indices" : [ 0, 12 ],
      "id_str" : "2546024868",
      "id" : 2546024868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378604648870842368",
  "text" : "@PleinairSan i wasnt sure if by removing the @ names required use of MT.. so I guess not. i learn something new every day!",
  "id" : 378604648870842368,
  "created_at" : "2013-09-13 19:42:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/OQXisOLNDr",
      "expanded_url" : "http:\/\/wp.me\/p39ts2-Hu",
      "display_url" : "wp.me\/p39ts2-Hu"
    } ]
  },
  "geo" : { },
  "id_str" : "378592142479724544",
  "text" : "RT @Pressgram: DiscoverPress Black and White http:\/\/t.co\/OQXisOLNDr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/OQXisOLNDr",
        "expanded_url" : "http:\/\/wp.me\/p39ts2-Hu",
        "display_url" : "wp.me\/p39ts2-Hu"
      } ]
    },
    "geo" : { },
    "id_str" : "378590216706998272",
    "text" : "DiscoverPress Black and White http:\/\/t.co\/OQXisOLNDr",
    "id" : 378590216706998272,
    "created_at" : "2013-09-13 18:45:16 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 378592142479724544,
  "created_at" : "2013-09-13 18:52:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BT23",
      "screen_name" : "BeTruth23",
      "indices" : [ 48, 58 ],
      "id_str" : "330049031",
      "id" : 330049031
    }, {
      "name" : "Todd Kincannon",
      "screen_name" : "ToddKincannon",
      "indices" : [ 59, 73 ],
      "id_str" : "40930480",
      "id" : 40930480
    }, {
      "name" : "bacon stunt double",
      "screen_name" : "armyantstudios",
      "indices" : [ 74, 89 ],
      "id_str" : "33980726",
      "id" : 33980726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378591970853007361",
  "text" : "@weakSquare yeah.. i could never get past that. @BeTruth23 @ToddKincannon @armyantstudios",
  "id" : 378591970853007361,
  "created_at" : "2013-09-13 18:52:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "indices" : [ 3, 13 ],
      "id_str" : "104553468",
      "id" : 104553468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378586588927647744",
  "text" : "RT @Bhava_Jim: 1% of the population received 95% of the income gains over the last four years.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378584373362036736",
    "text" : "1% of the population received 95% of the income gains over the last four years.",
    "id" : 378584373362036736,
    "created_at" : "2013-09-13 18:22:03 +0000",
    "user" : {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "protected" : false,
      "id_str" : "104553468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2005731750\/Cover9_normal.jpg",
      "id" : 104553468,
      "verified" : false
    }
  },
  "id" : 378586588927647744,
  "created_at" : "2013-09-13 18:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flu",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "seniors",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "vaccines",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378583840010170368",
  "text" : "RT @SangyeH: Last year's #flu shot was only 9% effective in #seniors. A 91% failure rate &amp; they're still pushing it?\n#vaccines",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "flu",
        "indices" : [ 12, 16 ]
      }, {
        "text" : "seniors",
        "indices" : [ 47, 55 ]
      }, {
        "text" : "vaccines",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378582945662922753",
    "text" : "Last year's #flu shot was only 9% effective in #seniors. A 91% failure rate &amp; they're still pushing it?\n#vaccines",
    "id" : 378582945662922753,
    "created_at" : "2013-09-13 18:16:22 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 378583840010170368,
  "created_at" : "2013-09-13 18:19:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PleinairSan",
      "screen_name" : "PleinairSan",
      "indices" : [ 3, 15 ],
      "id_str" : "2546024868",
      "id" : 2546024868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378583037300056065",
  "text" : "MT @PleinairSan Endangering your kids and the health of others is child abuse and assault in itself. Eye for an eye.",
  "id" : 378583037300056065,
  "created_at" : "2013-09-13 18:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378577983545421824",
  "text" : "RT @SangyeH: Lose the ineffective &amp; toxic flu shot. Get your Vit D levels checked. It's been shown to be preventative to flu &amp; to diminish \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378577387065069568",
    "text" : "Lose the ineffective &amp; toxic flu shot. Get your Vit D levels checked. It's been shown to be preventative to flu &amp; to diminish its severity",
    "id" : 378577387065069568,
    "created_at" : "2013-09-13 17:54:17 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 378577983545421824,
  "created_at" : "2013-09-13 17:56:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378575832446271488",
  "geo" : { },
  "id_str" : "378577653336244225",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ahh.. that would make sense!",
  "id" : 378577653336244225,
  "in_reply_to_status_id" : 378575832446271488,
  "created_at" : "2013-09-13 17:55:20 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 31, 41 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378371729368027136",
  "geo" : { },
  "id_str" : "378575201811705856",
  "in_reply_to_user_id" : 95023423,
  "text" : "how is that even possible?? RT @UberFacts Sperm cells actually have a sense of smell.",
  "id" : 378575201811705856,
  "in_reply_to_status_id" : 378371729368027136,
  "created_at" : "2013-09-13 17:45:36 +0000",
  "in_reply_to_screen_name" : "UberFacts",
  "in_reply_to_user_id_str" : "95023423",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PleinairSan",
      "screen_name" : "PleinairSan",
      "indices" : [ 2, 14 ],
      "id_str" : "2546024868",
      "id" : 2546024868
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 30, 46 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378574111212982272",
  "text" : ". @PleinairSan assault ?? o-O @shoeofallcosmos",
  "id" : 378574111212982272,
  "created_at" : "2013-09-13 17:41:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378570899202387969",
  "text" : "RT @Buddhaworld: We are into it up to the neck, whats called life. dont fight it, just keep swimming. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378568699034501120",
    "text" : "We are into it up to the neck, whats called life. dont fight it, just keep swimming. Buddha volko",
    "id" : 378568699034501120,
    "created_at" : "2013-09-13 17:19:45 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 378570899202387969,
  "created_at" : "2013-09-13 17:28:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378565890037395456",
  "geo" : { },
  "id_str" : "378566969256976384",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh no... : (",
  "id" : 378566969256976384,
  "in_reply_to_status_id" : 378565890037395456,
  "created_at" : "2013-09-13 17:12:53 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Shelly! the Pundit",
      "screen_name" : "sjfalcigno",
      "indices" : [ 50, 61 ],
      "id_str" : "498294115",
      "id" : 498294115
    }, {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "indices" : [ 62, 76 ],
      "id_str" : "24798779",
      "id" : 24798779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378560873948020736",
  "geo" : { },
  "id_str" : "378563165803384833",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny laws are made out of fear.. not love @sjfalcigno @StrangerGirl2 @kar776",
  "id" : 378563165803384833,
  "in_reply_to_status_id" : 378560873948020736,
  "created_at" : "2013-09-13 16:57:46 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378546458783260675",
  "text" : "its ironic how i ve spent lifetime looking down becuz shyness.. now i do it becuz easier on eyes..",
  "id" : 378546458783260675,
  "created_at" : "2013-09-13 15:51:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378542810599018496",
  "geo" : { },
  "id_str" : "378545802299199488",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous Yes! lol .. how ya feeling today?",
  "id" : 378545802299199488,
  "in_reply_to_status_id" : 378542810599018496,
  "created_at" : "2013-09-13 15:48:46 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378545204409544704",
  "text" : "also, large stores like sams club, etc.. make me dizzy looking around. both eyes are not converging.",
  "id" : 378545204409544704,
  "created_at" : "2013-09-13 15:46:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378544610227658753",
  "text" : "my left eye has large astigmatism and much blurrier than right eye. mostly i see w right eye. driving takes effort to see.",
  "id" : 378544610227658753,
  "created_at" : "2013-09-13 15:44:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378543897581850624",
  "text" : "sometime after age 30, i complained to DRs about not seeing w both eyes correctly. they never found a problem.. sigh.",
  "id" : 378543897581850624,
  "created_at" : "2013-09-13 15:41:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378543348237103104",
  "text" : "considering getting wavefront lenses. have to go to eye DR that has machine for rx. wondering if it will make diff. in sight.",
  "id" : 378543348237103104,
  "created_at" : "2013-09-13 15:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brigitte",
      "screen_name" : "miffed67",
      "indices" : [ 44, 53 ],
      "id_str" : "21015455",
      "id" : 21015455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/44QIPmxUYS",
      "expanded_url" : "http:\/\/wp.me\/pJQtu-GJ",
      "display_url" : "wp.me\/pJQtu-GJ"
    } ]
  },
  "geo" : { },
  "id_str" : "378335200876711936",
  "text" : "Cocoa's Last Day http:\/\/t.co\/44QIPmxUYS via @miffed67",
  "id" : 378335200876711936,
  "created_at" : "2013-09-13 01:51:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378332762488717312",
  "text" : "I'm in the negative numbers for charisma. Meh.",
  "id" : 378332762488717312,
  "created_at" : "2013-09-13 01:42:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378321629459140608",
  "geo" : { },
  "id_str" : "378324420026040320",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous i hope so! (disclaimer: im not a doctor and have none in my family)",
  "id" : 378324420026040320,
  "in_reply_to_status_id" : 378321629459140608,
  "created_at" : "2013-09-13 01:09:05 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Messersmith",
      "screen_name" : "jmessersmith",
      "indices" : [ 3, 16 ],
      "id_str" : "21209783",
      "id" : 21209783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Keg8kAOt4E",
      "expanded_url" : "http:\/\/instagram.com\/p\/eLeAt6IcNi\/",
      "display_url" : "instagram.com\/p\/eLeAt6IcNi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "378315413550948352",
  "text" : "RT @jmessersmith: A baby squirrel followed me into yoga class tonight. Pretty sure I'm a Disney princess now. http:\/\/t.co\/Keg8kAOt4E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Keg8kAOt4E",
        "expanded_url" : "http:\/\/instagram.com\/p\/eLeAt6IcNi\/",
        "display_url" : "instagram.com\/p\/eLeAt6IcNi\/"
      } ]
    },
    "geo" : { },
    "id_str" : "378303557633843200",
    "text" : "A baby squirrel followed me into yoga class tonight. Pretty sure I'm a Disney princess now. http:\/\/t.co\/Keg8kAOt4E",
    "id" : 378303557633843200,
    "created_at" : "2013-09-12 23:46:11 +0000",
    "user" : {
      "name" : "Jeremy Messersmith",
      "screen_name" : "jmessersmith",
      "protected" : false,
      "id_str" : "21209783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712789723694178306\/gPUPaj7V_normal.jpg",
      "id" : 21209783,
      "verified" : true
    }
  },
  "id" : 378315413550948352,
  "created_at" : "2013-09-13 00:33:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378312404045557760",
  "geo" : { },
  "id_str" : "378315106909569024",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous while im not a fan of flu shots, i'd say it was laying on your stomach (espec. if no support under it.) feel better soon : )",
  "id" : 378315106909569024,
  "in_reply_to_status_id" : 378312404045557760,
  "created_at" : "2013-09-13 00:32:04 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378312133613604864",
  "text" : "RT @jonlieffmd: My updated on animal intelligence highlights several small-brained animals that have exceptional intelligence: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/XDQ10y1720",
        "expanded_url" : "http:\/\/bit.ly\/15eN8d2",
        "display_url" : "bit.ly\/15eN8d2"
      } ]
    },
    "geo" : { },
    "id_str" : "378311075420463104",
    "text" : "My updated on animal intelligence highlights several small-brained animals that have exceptional intelligence: http:\/\/t.co\/XDQ10y1720",
    "id" : 378311075420463104,
    "created_at" : "2013-09-13 00:16:03 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 378312133613604864,
  "created_at" : "2013-09-13 00:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378306538936348672",
  "geo" : { },
  "id_str" : "378311209478418432",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ouch! sat on tall bar stools for a concert once.. never again.",
  "id" : 378311209478418432,
  "in_reply_to_status_id" : 378306538936348672,
  "created_at" : "2013-09-13 00:16:35 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Butterfield",
      "screen_name" : "bilibutterfield",
      "indices" : [ 3, 19 ],
      "id_str" : "301140285",
      "id" : 301140285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378271075668213760",
  "text" : "RT @bilibutterfield: Why are we giving Israel 8 million dollars a day? Could we have a referendum on this? Who's responsible 4 this travest\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378226391407276033",
    "text" : "Why are we giving Israel 8 million dollars a day? Could we have a referendum on this? Who's responsible 4 this travesty?",
    "id" : 378226391407276033,
    "created_at" : "2013-09-12 18:39:33 +0000",
    "user" : {
      "name" : "Billy Butterfield",
      "screen_name" : "bilibutterfield",
      "protected" : false,
      "id_str" : "301140285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2896998388\/8917554ef55b0565d8c61bee92c9fb0e_normal.jpeg",
      "id" : 301140285,
      "verified" : false
    }
  },
  "id" : 378271075668213760,
  "created_at" : "2013-09-12 21:37:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/qoiaC7nSLK",
      "expanded_url" : "http:\/\/bit.ly\/17T1TCN",
      "display_url" : "bit.ly\/17T1TCN"
    } ]
  },
  "geo" : { },
  "id_str" : "378270732687388672",
  "text" : "RT @atheistlady76: How Society Shames Men Dating Trans Women &amp; How This Affects Our Lives http:\/\/t.co\/qoiaC7nSLK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/qoiaC7nSLK",
        "expanded_url" : "http:\/\/bit.ly\/17T1TCN",
        "display_url" : "bit.ly\/17T1TCN"
      } ]
    },
    "geo" : { },
    "id_str" : "378267237355778048",
    "text" : "How Society Shames Men Dating Trans Women &amp; How This Affects Our Lives http:\/\/t.co\/qoiaC7nSLK",
    "id" : 378267237355778048,
    "created_at" : "2013-09-12 21:21:51 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 378270732687388672,
  "created_at" : "2013-09-12 21:35:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pressgramit",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378270324531290112",
  "text" : "RT @Pressgram: What are you drinking\u2026 right now? #pressgramit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pressgramit",
        "indices" : [ 34, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378268421169090560",
    "text" : "What are you drinking\u2026 right now? #pressgramit",
    "id" : 378268421169090560,
    "created_at" : "2013-09-12 21:26:34 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 378270324531290112,
  "created_at" : "2013-09-12 21:34:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378269845302689793",
  "text" : "RT @HealthRanger: CPS threatens to take sick child away from mother for choosing medicinal marijuana over toxic chemotherapy. http:\/\/t.co\/u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/uCjAATAiOk",
        "expanded_url" : "http:\/\/ow.ly\/oPdjK",
        "display_url" : "ow.ly\/oPdjK"
      } ]
    },
    "geo" : { },
    "id_str" : "378269126307098624",
    "text" : "CPS threatens to take sick child away from mother for choosing medicinal marijuana over toxic chemotherapy. http:\/\/t.co\/uCjAATAiOk #health",
    "id" : 378269126307098624,
    "created_at" : "2013-09-12 21:29:22 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 378269845302689793,
  "created_at" : "2013-09-12 21:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/f7TdbUp2bT",
      "expanded_url" : "http:\/\/tinyurl.com\/bm7c73r",
      "display_url" : "tinyurl.com\/bm7c73r"
    } ]
  },
  "geo" : { },
  "id_str" : "378255966233305088",
  "text" : "RT @Soulseedzforall: Everyone has struggles and needs #compassion, especially the prickly ones. http:\/\/t.co\/f7TdbUp2bT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compassion",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/f7TdbUp2bT",
        "expanded_url" : "http:\/\/tinyurl.com\/bm7c73r",
        "display_url" : "tinyurl.com\/bm7c73r"
      } ]
    },
    "geo" : { },
    "id_str" : "378255074885001216",
    "text" : "Everyone has struggles and needs #compassion, especially the prickly ones. http:\/\/t.co\/f7TdbUp2bT",
    "id" : 378255074885001216,
    "created_at" : "2013-09-12 20:33:32 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 378255966233305088,
  "created_at" : "2013-09-12 20:37:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIGERJEONG",
      "screen_name" : "tiger6300",
      "indices" : [ 3, 13 ],
      "id_str" : "221373945",
      "id" : 221373945
    }, {
      "name" : "Animal Life",
      "screen_name" : "MeetAnimals",
      "indices" : [ 18, 30 ],
      "id_str" : "953278568",
      "id" : 953278568
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MeetAnimals\/status\/378163867396108288\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/3aXW8bFKaF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT-CCKIIMAAo-PO.jpg",
      "id_str" : "378163867312205824",
      "id" : 378163867312205824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT-CCKIIMAAo-PO.jpg",
      "sizes" : [ {
        "h" : 692,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 482
      } ],
      "display_url" : "pic.twitter.com\/3aXW8bFKaF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378196089272152064",
  "text" : "RT @tiger6300: RT @MeetAnimals: Beautiful Swans. http:\/\/t.co\/3aXW8bFKaF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtkr.com\" rel=\"nofollow\"\u003Etwtkr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Animal Life",
        "screen_name" : "MeetAnimals",
        "indices" : [ 3, 15 ],
        "id_str" : "953278568",
        "id" : 953278568
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MeetAnimals\/status\/378163867396108288\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/3aXW8bFKaF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BT-CCKIIMAAo-PO.jpg",
        "id_str" : "378163867312205824",
        "id" : 378163867312205824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT-CCKIIMAAo-PO.jpg",
        "sizes" : [ {
          "h" : 692,
          "resize" : "fit",
          "w" : 482
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 482
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 482
        } ],
        "display_url" : "pic.twitter.com\/3aXW8bFKaF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378189261268205569",
    "text" : "RT @MeetAnimals: Beautiful Swans. http:\/\/t.co\/3aXW8bFKaF",
    "id" : 378189261268205569,
    "created_at" : "2013-09-12 16:12:00 +0000",
    "user" : {
      "name" : "TIGERJEONG",
      "screen_name" : "tiger6300",
      "protected" : false,
      "id_str" : "221373945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658197154553462784\/I5JuxZHF_normal.jpg",
      "id" : 221373945,
      "verified" : false
    }
  },
  "id" : 378196089272152064,
  "created_at" : "2013-09-12 16:39:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "indices" : [ 3, 19 ],
      "id_str" : "191110048",
      "id" : 191110048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BookGiveaway",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/yHYl059v4h",
      "expanded_url" : "http:\/\/www.sciencethrillers.com\/book-giveaways\/",
      "display_url" : "sciencethrillers.com\/book-giveaways\/"
    } ]
  },
  "geo" : { },
  "id_str" : "378182710109278209",
  "text" : "RT @ScienceThriller: #BookGiveaway--win free books! Four raffles active now for science fiction fans http:\/\/t.co\/yHYl059v4h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BookGiveaway",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/yHYl059v4h",
        "expanded_url" : "http:\/\/www.sciencethrillers.com\/book-giveaways\/",
        "display_url" : "sciencethrillers.com\/book-giveaways\/"
      } ]
    },
    "geo" : { },
    "id_str" : "378182344365973505",
    "text" : "#BookGiveaway--win free books! Four raffles active now for science fiction fans http:\/\/t.co\/yHYl059v4h",
    "id" : 378182344365973505,
    "created_at" : "2013-09-12 15:44:31 +0000",
    "user" : {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "protected" : false,
      "id_str" : "191110048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509554102632587264\/zmyDrP9j_normal.jpeg",
      "id" : 191110048,
      "verified" : false
    }
  },
  "id" : 378182710109278209,
  "created_at" : "2013-09-12 15:45:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377636864968380416",
  "geo" : { },
  "id_str" : "378171802846887936",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh dear...",
  "id" : 378171802846887936,
  "in_reply_to_status_id" : 377636864968380416,
  "created_at" : "2013-09-12 15:02:38 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 87, 96 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/klAf1CQOUf",
      "expanded_url" : "http:\/\/www.upworthy.com\/a-boy-makes-anti-muslim-comments-in-front-of-an-american-soldier-the-soldiers-reply-priceless?g=3",
      "display_url" : "upworthy.com\/a-boy-makes-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378160169718255617",
  "text" : "A boy makes anti-Muslim comments in front of an American soldier. Bad idea, dude. (via @Upworthy) http:\/\/t.co\/klAf1CQOUf",
  "id" : 378160169718255617,
  "created_at" : "2013-09-12 14:16:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377963384966094848",
  "text" : "RT @TyrusBooks: This goes out to all the misfits, awkward wall flowers growing in suburban gardens, never been in, always on the fringes cr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377961176543395840",
    "text" : "This goes out to all the misfits, awkward wall flowers growing in suburban gardens, never been in, always on the fringes crowd. Keep it up!",
    "id" : 377961176543395840,
    "created_at" : "2013-09-12 01:05:41 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 377963384966094848,
  "created_at" : "2013-09-12 01:14:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377880742048456704",
  "text" : "i am so blessed to have the daughter i have.. her soul is so much more advanced than mine. i am honored.",
  "id" : 377880742048456704,
  "created_at" : "2013-09-11 19:46:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "indices" : [ 0, 10 ],
      "id_str" : "104553468",
      "id" : 104553468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377876596943634432",
  "geo" : { },
  "id_str" : "377880393375952897",
  "in_reply_to_user_id" : 104553468,
  "text" : "@Bhava_Jim my conclusion as well.",
  "id" : 377880393375952897,
  "in_reply_to_status_id" : 377876596943634432,
  "created_at" : "2013-09-11 19:44:41 +0000",
  "in_reply_to_screen_name" : "Bhava_Jim",
  "in_reply_to_user_id_str" : "104553468",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Old Dog Haven",
      "screen_name" : "OldDogHaven",
      "indices" : [ 3, 15 ],
      "id_str" : "30454230",
      "id" : 30454230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377804877084098560",
  "text" : "RT @OldDogHaven: Very sad news for Misty and her adopters from yesterday. As heartbroken as we are for her new family, it is why... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/0YHUYehLGs",
        "expanded_url" : "http:\/\/fb.me\/37Nda1KGt",
        "display_url" : "fb.me\/37Nda1KGt"
      } ]
    },
    "geo" : { },
    "id_str" : "377804459222765568",
    "text" : "Very sad news for Misty and her adopters from yesterday. As heartbroken as we are for her new family, it is why... http:\/\/t.co\/0YHUYehLGs",
    "id" : 377804459222765568,
    "created_at" : "2013-09-11 14:42:57 +0000",
    "user" : {
      "name" : "Old Dog Haven",
      "screen_name" : "OldDogHaven",
      "protected" : false,
      "id_str" : "30454230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590689116565676033\/9ClwTfrJ_normal.png",
      "id" : 30454230,
      "verified" : false
    }
  },
  "id" : 377804877084098560,
  "created_at" : "2013-09-11 14:44:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377804342188707841",
  "text" : "\"bloom where you are planted\" &lt;&lt; i keep this in mind when i feel small.",
  "id" : 377804342188707841,
  "created_at" : "2013-09-11 14:42:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377803839157456896",
  "text" : "apparently, im a good listener ; )",
  "id" : 377803839157456896,
  "created_at" : "2013-09-11 14:40:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377803562752827392",
  "text" : "have a crick in my neck. sat in car for 2 hours talking w MIL after bible study yesterday.",
  "id" : 377803562752827392,
  "created_at" : "2013-09-11 14:39:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seniorprivilege",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377801068240850944",
  "text" : "my DD so excited.. gets to go in late on A days #seniorprivilege",
  "id" : 377801068240850944,
  "created_at" : "2013-09-11 14:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Catherine Drea",
      "screen_name" : "foxglovelane",
      "indices" : [ 17, 30 ],
      "id_str" : "38410778",
      "id" : 38410778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/foxglovelane\/status\/377690266523942912\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/lhhI1PjFlI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT3TS9DIUAAaPKP.jpg",
      "id_str" : "377690266347786240",
      "id" : 377690266347786240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT3TS9DIUAAaPKP.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lhhI1PjFlI"
    } ],
    "hashtags" : [ {
      "text" : "ireland",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377791987153268736",
  "text" : "RT @KerriFar: RT @foxglovelane: Small coastal bird chick pokes her head out of her nest at sunset.     http:\/\/t.co\/lhhI1PjFlI #ireland #nat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Catherine Drea",
        "screen_name" : "foxglovelane",
        "indices" : [ 3, 16 ],
        "id_str" : "38410778",
        "id" : 38410778
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/foxglovelane\/status\/377690266523942912\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/lhhI1PjFlI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BT3TS9DIUAAaPKP.jpg",
        "id_str" : "377690266347786240",
        "id" : 377690266347786240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT3TS9DIUAAaPKP.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lhhI1PjFlI"
      } ],
      "hashtags" : [ {
        "text" : "ireland",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "nature",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377781263215894529",
    "text" : "RT @foxglovelane: Small coastal bird chick pokes her head out of her nest at sunset.     http:\/\/t.co\/lhhI1PjFlI #ireland #nature...",
    "id" : 377781263215894529,
    "created_at" : "2013-09-11 13:10:46 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 377791987153268736,
  "created_at" : "2013-09-11 13:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pressgrammers",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/ALjws10BvM",
      "expanded_url" : "http:\/\/blog.pressgr.am\/go-global\/",
      "display_url" : "blog.pressgr.am\/go-global\/"
    } ]
  },
  "geo" : { },
  "id_str" : "377791611209396224",
  "text" : "RT @Pressgram: Looking to connect with other #pressgrammers? - GET LISTED HERE! - http:\/\/t.co\/ALjws10BvM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pressgrammers",
        "indices" : [ 30, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/ALjws10BvM",
        "expanded_url" : "http:\/\/blog.pressgr.am\/go-global\/",
        "display_url" : "blog.pressgr.am\/go-global\/"
      } ]
    },
    "geo" : { },
    "id_str" : "377783825822400513",
    "text" : "Looking to connect with other #pressgrammers? - GET LISTED HERE! - http:\/\/t.co\/ALjws10BvM",
    "id" : 377783825822400513,
    "created_at" : "2013-09-11 13:20:57 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 377791611209396224,
  "created_at" : "2013-09-11 13:51:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "MyBrownNewfies",
      "indices" : [ 3, 18 ],
      "id_str" : "213161870",
      "id" : 213161870
    }, {
      "name" : "Mary Hone",
      "screen_name" : "RoxyTrvlingDog",
      "indices" : [ 73, 88 ],
      "id_str" : "2499070358",
      "id" : 2499070358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Wk2tuVGRYO",
      "expanded_url" : "http:\/\/goo.gl\/QFjz2G",
      "display_url" : "goo.gl\/QFjz2G"
    } ]
  },
  "geo" : { },
  "id_str" : "377567239123128320",
  "text" : "RT @MyBrownNewfies: More moose pics...Really? http:\/\/t.co\/Wk2tuVGRYO via @RoxyTrvlingDog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Hone",
        "screen_name" : "RoxyTrvlingDog",
        "indices" : [ 53, 68 ],
        "id_str" : "2499070358",
        "id" : 2499070358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/Wk2tuVGRYO",
        "expanded_url" : "http:\/\/goo.gl\/QFjz2G",
        "display_url" : "goo.gl\/QFjz2G"
      } ]
    },
    "geo" : { },
    "id_str" : "377563792936554496",
    "text" : "More moose pics...Really? http:\/\/t.co\/Wk2tuVGRYO via @RoxyTrvlingDog",
    "id" : 377563792936554496,
    "created_at" : "2013-09-10 22:46:37 +0000",
    "user" : {
      "name" : "Jen",
      "screen_name" : "MyBrownNewfies",
      "protected" : false,
      "id_str" : "213161870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000365475755\/208bcb9c6985d9a32fff83387a4379a9_normal.jpeg",
      "id" : 213161870,
      "verified" : false
    }
  },
  "id" : 377567239123128320,
  "created_at" : "2013-09-10 23:00:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "indices" : [ 3, 17 ],
      "id_str" : "24798779",
      "id" : 24798779
    }, {
      "name" : "Dagwood Bumstead",
      "screen_name" : "Daggy1",
      "indices" : [ 73, 80 ],
      "id_str" : "24305174",
      "id" : 24305174
    }, {
      "name" : "Paul Reynolds",
      "screen_name" : "Pr260",
      "indices" : [ 81, 87 ],
      "id_str" : "184301992",
      "id" : 184301992
    }, {
      "name" : "Homunculus aka #Hom",
      "screen_name" : "HomunculusLoikm",
      "indices" : [ 88, 104 ],
      "id_str" : "233933230",
      "id" : 233933230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377555647492943873",
  "text" : "RT @StrangerGirl2: There is no kindness in disgust, shunning, prejudice. @Daggy1 @Pr260 @HomunculusLoikm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dagwood Bumstead",
        "screen_name" : "Daggy1",
        "indices" : [ 54, 61 ],
        "id_str" : "24305174",
        "id" : 24305174
      }, {
        "name" : "Paul Reynolds",
        "screen_name" : "Pr260",
        "indices" : [ 62, 68 ],
        "id_str" : "184301992",
        "id" : 184301992
      }, {
        "name" : "Homunculus aka #Hom",
        "screen_name" : "HomunculusLoikm",
        "indices" : [ 69, 85 ],
        "id_str" : "233933230",
        "id" : 233933230
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "377538748076294144",
    "geo" : { },
    "id_str" : "377540008011640833",
    "in_reply_to_user_id" : 24305174,
    "text" : "There is no kindness in disgust, shunning, prejudice. @Daggy1 @Pr260 @HomunculusLoikm",
    "id" : 377540008011640833,
    "in_reply_to_status_id" : 377538748076294144,
    "created_at" : "2013-09-10 21:12:06 +0000",
    "in_reply_to_screen_name" : "Daggy1",
    "in_reply_to_user_id_str" : "24305174",
    "user" : {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "protected" : false,
      "id_str" : "24798779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615547045726699520\/E413dZ19_normal.jpg",
      "id" : 24798779,
      "verified" : false
    }
  },
  "id" : 377555647492943873,
  "created_at" : "2013-09-10 22:14:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 70, 77 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "Lavaca_AR",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/tXY3lqldSY",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/15807",
      "display_url" : "wildobs.com\/wo\/15807"
    } ]
  },
  "geo" : { },
  "id_str" : "377554509683113984",
  "text" : "RT @wildobs: In case you missed it: Opossum http:\/\/t.co\/tXY3lqldSY by @screek #EOTD #wildlife #Lavaca_AR An Opossum Welcoming Me Home",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 57, 64 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 65, 70 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "Lavaca_AR",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/tXY3lqldSY",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/15807",
        "display_url" : "wildobs.com\/wo\/15807"
      } ]
    },
    "geo" : { },
    "id_str" : "377553507370696704",
    "text" : "In case you missed it: Opossum http:\/\/t.co\/tXY3lqldSY by @screek #EOTD #wildlife #Lavaca_AR An Opossum Welcoming Me Home",
    "id" : 377553507370696704,
    "created_at" : "2013-09-10 22:05:45 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 377554509683113984,
  "created_at" : "2013-09-10 22:09:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abraham",
      "screen_name" : "thenotimer",
      "indices" : [ 0, 11 ],
      "id_str" : "1154412506",
      "id" : 1154412506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377551118173081600",
  "geo" : { },
  "id_str" : "377552961301254144",
  "in_reply_to_user_id" : 1154412506,
  "text" : "@thenotimer yup : ) lol @weakSquare @Stuck_0n_Repeat",
  "id" : 377552961301254144,
  "in_reply_to_status_id" : 377551118173081600,
  "created_at" : "2013-09-10 22:03:35 +0000",
  "in_reply_to_screen_name" : "thenotimer",
  "in_reply_to_user_id_str" : "1154412506",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377552852580724736",
  "text" : "@weakSquare i prefer cotton, myself. @Stuck_0n_Repeat",
  "id" : 377552852580724736,
  "created_at" : "2013-09-10 22:03:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377551652779089920",
  "text" : "@IronAtheist \"God as interpreted for them by their Pastor\" &lt;&lt; bingo! ppl should interpret for themselves.",
  "id" : 377551652779089920,
  "created_at" : "2013-09-10 21:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammy 21st October",
      "screen_name" : "PinkChocoCandy",
      "indices" : [ 3, 18 ],
      "id_str" : "1004732078",
      "id" : 1004732078
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PinkChocoCandy\/status\/377491914557120512\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/eUQXl88JNp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT0e5UyCcAAM4nA.jpg",
      "id_str" : "377491913948950528",
      "id" : 377491913948950528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT0e5UyCcAAM4nA.jpg",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 422
      } ],
      "display_url" : "pic.twitter.com\/eUQXl88JNp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377495477035339777",
  "text" : "RT @PinkChocoCandy: Awwwwwwww.......so sweet. http:\/\/t.co\/eUQXl88JNp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PinkChocoCandy\/status\/377491914557120512\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/eUQXl88JNp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BT0e5UyCcAAM4nA.jpg",
        "id_str" : "377491913948950528",
        "id" : 377491913948950528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT0e5UyCcAAM4nA.jpg",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 422
        } ],
        "display_url" : "pic.twitter.com\/eUQXl88JNp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377491914557120512",
    "text" : "Awwwwwwww.......so sweet. http:\/\/t.co\/eUQXl88JNp",
    "id" : 377491914557120512,
    "created_at" : "2013-09-10 18:01:00 +0000",
    "user" : {
      "name" : "Tammy 21st October",
      "screen_name" : "PinkChocoCandy",
      "protected" : false,
      "id_str" : "1004732078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775665354387300353\/CY0W64GI_normal.jpg",
      "id" : 1004732078,
      "verified" : false
    }
  },
  "id" : 377495477035339777,
  "created_at" : "2013-09-10 18:15:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Penta",
      "screen_name" : "mydigitalmind",
      "indices" : [ 3, 17 ],
      "id_str" : "15259604",
      "id" : 15259604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 42, 48 ]
    }, {
      "text" : "birding",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "photography",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/LR9G0r3hke",
      "expanded_url" : "http:\/\/flic.kr\/p\/fztKb4",
      "display_url" : "flic.kr\/p\/fztKb4"
    } ]
  },
  "geo" : { },
  "id_str" : "377421704705765376",
  "text" : "RT @mydigitalmind: American Crow on Sumac #birds #birding #photography http:\/\/t.co\/LR9G0r3hke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 23, 29 ]
      }, {
        "text" : "birding",
        "indices" : [ 30, 38 ]
      }, {
        "text" : "photography",
        "indices" : [ 39, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/LR9G0r3hke",
        "expanded_url" : "http:\/\/flic.kr\/p\/fztKb4",
        "display_url" : "flic.kr\/p\/fztKb4"
      } ]
    },
    "geo" : { },
    "id_str" : "377420290248028160",
    "text" : "American Crow on Sumac #birds #birding #photography http:\/\/t.co\/LR9G0r3hke",
    "id" : 377420290248028160,
    "created_at" : "2013-09-10 13:16:23 +0000",
    "user" : {
      "name" : "Melissa Penta",
      "screen_name" : "mydigitalmind",
      "protected" : false,
      "id_str" : "15259604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685202966018535424\/eJMP1Mjw_normal.jpg",
      "id" : 15259604,
      "verified" : false
    }
  },
  "id" : 377421704705765376,
  "created_at" : "2013-09-10 13:22:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dykstra Dame",
      "screen_name" : "DykstraDame",
      "indices" : [ 3, 15 ],
      "id_str" : "241776425",
      "id" : 241776425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/eITN6m68xz",
      "expanded_url" : "http:\/\/articles.mercola.com\/sites\/articles\/archive\/2013\/09\/10\/monsanto-bt-corn.aspx",
      "display_url" : "articles.mercola.com\/sites\/articles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377414774054604801",
  "text" : "RT @DykstraDame: Monsanto Decimates Their Credibility: \n http:\/\/t.co\/eITN6m68xz Mother Nature has spoken. She said, and I quote: \"Kiss this\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/eITN6m68xz",
        "expanded_url" : "http:\/\/articles.mercola.com\/sites\/articles\/archive\/2013\/09\/10\/monsanto-bt-corn.aspx",
        "display_url" : "articles.mercola.com\/sites\/articles\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377413682117885953",
    "text" : "Monsanto Decimates Their Credibility: \n http:\/\/t.co\/eITN6m68xz Mother Nature has spoken. She said, and I quote: \"Kiss this, worm!\"",
    "id" : 377413682117885953,
    "created_at" : "2013-09-10 12:50:08 +0000",
    "user" : {
      "name" : "Dykstra Dame",
      "screen_name" : "DykstraDame",
      "protected" : false,
      "id_str" : "241776425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2816861350\/0634fc21274b57efd7c6b1f817f679d5_normal.jpeg",
      "id" : 241776425,
      "verified" : false
    }
  },
  "id" : 377414774054604801,
  "created_at" : "2013-09-10 12:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Face Off",
      "screen_name" : "FaceOffSyfy",
      "indices" : [ 3, 15 ],
      "id_str" : "412589880",
      "id" : 412589880
    }, {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "indices" : [ 42, 47 ],
      "id_str" : "18957524",
      "id" : 18957524
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FaceOffSyfy\/status\/377401468405678081\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/EhwStllsBT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTzMosTIcAAt0pC.jpg",
      "id_str" : "377401468250517504",
      "id" : 377401468250517504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTzMosTIcAAt0pC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EhwStllsBT"
    } ],
    "hashtags" : [ {
      "text" : "FaceOff",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377413213366673408",
  "text" : "RT @FaceOffSyfy: Mother Nature takes over @Syfy on tonight\u2019s all-new #FaceOff! RETWEET if you\u2019ll be watching! http:\/\/t.co\/EhwStllsBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Syfy",
        "screen_name" : "Syfy",
        "indices" : [ 25, 30 ],
        "id_str" : "18957524",
        "id" : 18957524
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FaceOffSyfy\/status\/377401468405678081\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/EhwStllsBT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTzMosTIcAAt0pC.jpg",
        "id_str" : "377401468250517504",
        "id" : 377401468250517504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTzMosTIcAAt0pC.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EhwStllsBT"
      } ],
      "hashtags" : [ {
        "text" : "FaceOff",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377401468405678081",
    "text" : "Mother Nature takes over @Syfy on tonight\u2019s all-new #FaceOff! RETWEET if you\u2019ll be watching! http:\/\/t.co\/EhwStllsBT",
    "id" : 377401468405678081,
    "created_at" : "2013-09-10 12:01:36 +0000",
    "user" : {
      "name" : "Face Off",
      "screen_name" : "FaceOffSyfy",
      "protected" : false,
      "id_str" : "412589880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680041863244591104\/eAwtkImU_normal.png",
      "id" : 412589880,
      "verified" : true
    }
  },
  "id" : 377413213366673408,
  "created_at" : "2013-09-10 12:48:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "APenAndADream",
      "screen_name" : "APenAndADream",
      "indices" : [ 11, 25 ],
      "id_str" : "740926623759863808",
      "id" : 740926623759863808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377405517708419072",
  "geo" : { },
  "id_str" : "377411126486503425",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous @APenAndADream heehee",
  "id" : 377411126486503425,
  "in_reply_to_status_id" : 377405517708419072,
  "created_at" : "2013-09-10 12:39:59 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377408219255042049",
  "text" : "woke to sound of turkeys in my yard getting their morning bugs",
  "id" : 377408219255042049,
  "created_at" : "2013-09-10 12:28:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377194871745822721",
  "text" : "sooo precious.. family of turkeys crossed our front yard while i was doing dishes. : )",
  "id" : 377194871745822721,
  "created_at" : "2013-09-09 22:20:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Zk4Rfj8pGL",
      "expanded_url" : "http:\/\/tiffanihillpatterson.com\/2013\/09\/why-should-my-daughter-be-responsible-for-your-sons-thoughts\/",
      "display_url" : "tiffanihillpatterson.com\/2013\/09\/why-sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377178421098315777",
  "text" : "RT @Wolf_Mommy: Why should my daughter be responsible for your son's thoughts? http:\/\/t.co\/Zk4Rfj8pGL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Zk4Rfj8pGL",
        "expanded_url" : "http:\/\/tiffanihillpatterson.com\/2013\/09\/why-should-my-daughter-be-responsible-for-your-sons-thoughts\/",
        "display_url" : "tiffanihillpatterson.com\/2013\/09\/why-sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377174094745059328",
    "text" : "Why should my daughter be responsible for your son's thoughts? http:\/\/t.co\/Zk4Rfj8pGL",
    "id" : 377174094745059328,
    "created_at" : "2013-09-09 20:58:06 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 377178421098315777,
  "created_at" : "2013-09-09 21:15:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 126, 139 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Gx0iQIL9er",
      "expanded_url" : "http:\/\/www.naturalnews.com\/041965_TPP_GMO_labeling_Monsanto.html",
      "display_url" : "naturalnews.com\/041965_TPP_GMO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377132493658271744",
  "text" : "Monsanto leading super-secret 'above Congress' Obama trade scheme to outlaw GMO labeling worldwide http:\/\/t.co\/Gx0iQIL9er via @HealthRanger",
  "id" : 377132493658271744,
  "created_at" : "2013-09-09 18:12:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377130149755375617",
  "geo" : { },
  "id_str" : "377130780306075648",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater uh-oh ((backing away slowly))",
  "id" : 377130780306075648,
  "in_reply_to_status_id" : 377130149755375617,
  "created_at" : "2013-09-09 18:05:59 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377130603398709249",
  "text" : "RT @ZachsMind: IT JUST DOESN'T MATTER!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377130413786820608",
    "text" : "IT JUST DOESN'T MATTER!",
    "id" : 377130413786820608,
    "created_at" : "2013-09-09 18:04:32 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 377130603398709249,
  "created_at" : "2013-09-09 18:05:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Patton Oswalt",
      "screen_name" : "pattonoswalt",
      "indices" : [ 39, 52 ],
      "id_str" : "139162440",
      "id" : 139162440
    }, {
      "name" : "Felicia Day",
      "screen_name" : "feliciaday",
      "indices" : [ 53, 64 ],
      "id_str" : "7861312",
      "id" : 7861312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377096608283766784",
  "geo" : { },
  "id_str" : "377098757428371457",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind wow.. just.. wow. loved it! @pattonoswalt @feliciaday",
  "id" : 377098757428371457,
  "in_reply_to_status_id" : 377096608283766784,
  "created_at" : "2013-09-09 15:58:44 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 12, 22 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/kW7evDEUrv",
      "expanded_url" : "http:\/\/zachsmind.wordpress.com\/2012\/09\/22\/let-x-equal-x-atheism-skeptic-religion-christian-omgwtf-feminism-bible-etc\/",
      "display_url" : "zachsmind.wordpress.com\/2012\/09\/22\/let\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377069832769781762",
  "text" : "@weakSquare @ZachsMind http:\/\/t.co\/kW7evDEUrv",
  "id" : 377069832769781762,
  "created_at" : "2013-09-09 14:03:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 74, 84 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377067777716006914",
  "text" : "@weakSquare he wrote an awesome post about it. was aha moment for me..lol @ZachsMind",
  "id" : 377067777716006914,
  "created_at" : "2013-09-09 13:55:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/FyDp0Vovey",
      "expanded_url" : "http:\/\/wp.me\/p39ts2-EO",
      "display_url" : "wp.me\/p39ts2-EO"
    } ]
  },
  "geo" : { },
  "id_str" : "377065909761736705",
  "text" : "RT @Pressgram: The Best Instagram Alternative http:\/\/t.co\/FyDp0Vovey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/FyDp0Vovey",
        "expanded_url" : "http:\/\/wp.me\/p39ts2-EO",
        "display_url" : "wp.me\/p39ts2-EO"
      } ]
    },
    "geo" : { },
    "id_str" : "377043284708716544",
    "text" : "The Best Instagram Alternative http:\/\/t.co\/FyDp0Vovey",
    "id" : 377043284708716544,
    "created_at" : "2013-09-09 12:18:18 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 377065909761736705,
  "created_at" : "2013-09-09 13:48:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "APenAndADream",
      "screen_name" : "APenAndADream",
      "indices" : [ 11, 25 ],
      "id_str" : "740926623759863808",
      "id" : 740926623759863808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377053367253872640",
  "geo" : { },
  "id_str" : "377064737374101504",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous @APenAndADream oh la la ; )",
  "id" : 377064737374101504,
  "in_reply_to_status_id" : 377053367253872640,
  "created_at" : "2013-09-09 13:43:33 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377056297281003521",
  "geo" : { },
  "id_str" : "377063759077834752",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind yeah.. that was a great post! did you give him link? @weakSquare",
  "id" : 377063759077834752,
  "in_reply_to_status_id" : 377056297281003521,
  "created_at" : "2013-09-09 13:39:40 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/I6ZYzoZkPh",
      "expanded_url" : "http:\/\/amzn.to\/TOuXAI",
      "display_url" : "amzn.to\/TOuXAI"
    } ]
  },
  "geo" : { },
  "id_str" : "376892353354948608",
  "text" : "finished So Help Me God by Larry D. Thompson http:\/\/t.co\/I6ZYzoZkPh",
  "id" : 376892353354948608,
  "created_at" : "2013-09-09 02:18:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/BXhofl1OXY",
      "expanded_url" : "http:\/\/blog.pressgr.am\/go-global\/nifty-50\/",
      "display_url" : "blog.pressgr.am\/go-global\/nift\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376796055091703809",
  "text" : "RT @Pressgram: Still trying to fill in a few states - we're at 30%! - The Nifty 50 http:\/\/t.co\/BXhofl1OXY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/BXhofl1OXY",
        "expanded_url" : "http:\/\/blog.pressgr.am\/go-global\/nifty-50\/",
        "display_url" : "blog.pressgr.am\/go-global\/nift\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376795426222911489",
    "text" : "Still trying to fill in a few states - we're at 30%! - The Nifty 50 http:\/\/t.co\/BXhofl1OXY",
    "id" : 376795426222911489,
    "created_at" : "2013-09-08 19:53:24 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 376796055091703809,
  "created_at" : "2013-09-08 19:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376767640011669504",
  "text" : "@1stCitizenKane well, yeah.. im curious if there are statistics. i bet most.",
  "id" : 376767640011669504,
  "created_at" : "2013-09-08 18:03:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376765003719667712",
  "text" : "@1stCitizenKane curious.. how many end up broke?",
  "id" : 376765003719667712,
  "created_at" : "2013-09-08 17:52:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376573948039028739",
  "geo" : { },
  "id_str" : "376764755521720321",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl gratitude for having you in my timeline.. the quiet water that brings me calm and insight. ((hugs))",
  "id" : 376764755521720321,
  "in_reply_to_status_id" : 376573948039028739,
  "created_at" : "2013-09-08 17:51:32 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376739273354915840",
  "geo" : { },
  "id_str" : "376740407154978816",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses aww.. i just wanna ((hug)) you! : )",
  "id" : 376740407154978816,
  "in_reply_to_status_id" : 376739273354915840,
  "created_at" : "2013-09-08 16:14:47 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Featherfields",
      "screen_name" : "Featherfields",
      "indices" : [ 3, 17 ],
      "id_str" : "260392799",
      "id" : 260392799
    }, {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "indices" : [ 20, 31 ],
      "id_str" : "200405814",
      "id" : 200405814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truestory",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376740138258165760",
  "text" : "RT @Featherfields: \u201C@ftcreature: When you flip a picture of bats hanging upside down they become exceptionally sassier. #truestory http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Featured Creature",
        "screen_name" : "ftcreature",
        "indices" : [ 1, 12 ],
        "id_str" : "200405814",
        "id" : 200405814
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/376435052747718656\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/MiXX26axgp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTldr5UIcAAJbqu.jpg",
        "id_str" : "376435052563165184",
        "id" : 376435052563165184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTldr5UIcAAJbqu.jpg",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/MiXX26axgp"
      } ],
      "hashtags" : [ {
        "text" : "truestory",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "376435052747718656",
    "geo" : { },
    "id_str" : "376440124894371840",
    "in_reply_to_user_id" : 200405814,
    "text" : "\u201C@ftcreature: When you flip a picture of bats hanging upside down they become exceptionally sassier. #truestory http:\/\/t.co\/MiXX26axgp\u201D",
    "id" : 376440124894371840,
    "in_reply_to_status_id" : 376435052747718656,
    "created_at" : "2013-09-07 20:21:34 +0000",
    "in_reply_to_screen_name" : "ftcreature",
    "in_reply_to_user_id_str" : "200405814",
    "user" : {
      "name" : "Featherfields",
      "screen_name" : "Featherfields",
      "protected" : false,
      "id_str" : "260392799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1261042828\/goldfinch_normal.jpg",
      "id" : 260392799,
      "verified" : false
    }
  },
  "id" : 376740138258165760,
  "created_at" : "2013-09-08 16:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376733726513704960",
  "text" : "RT @PeggySueCusses: NJ School to Throw Away Students\u2019 Lunches If They Don\u2019t Have Enough Money to Pay for Them | Fox News Insider http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.att.com\" rel=\"nofollow\"\u003EAT&T Browser Bar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/uET9eghvtN",
        "expanded_url" : "http:\/\/bit.ly\/1esLDLV",
        "display_url" : "bit.ly\/1esLDLV"
      } ]
    },
    "geo" : { },
    "id_str" : "376732534388064256",
    "text" : "NJ School to Throw Away Students\u2019 Lunches If They Don\u2019t Have Enough Money to Pay for Them | Fox News Insider http:\/\/t.co\/uET9eghvtN",
    "id" : 376732534388064256,
    "created_at" : "2013-09-08 15:43:30 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 376733726513704960,
  "created_at" : "2013-09-08 15:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376719381931118592",
  "text" : "RT @MrsBlueBird69: I'm not very good at participating \n\nin Life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376710127786926080",
    "text" : "I'm not very good at participating \n\nin Life.",
    "id" : 376710127786926080,
    "created_at" : "2013-09-08 14:14:28 +0000",
    "user" : {
      "name" : "Dodgeball survivor",
      "screen_name" : "_MrsBlueBird_",
      "protected" : false,
      "id_str" : "576804857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797502367990251520\/ml0i9RFF_normal.jpg",
      "id" : 576804857,
      "verified" : false
    }
  },
  "id" : 376719381931118592,
  "created_at" : "2013-09-08 14:51:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376718433053720576",
  "text" : "@1stCitizenKane she's an entertainer, not a singer.",
  "id" : 376718433053720576,
  "created_at" : "2013-09-08 14:47:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/9g3u6m3RF7",
      "expanded_url" : "http:\/\/pressgr.am\/switch\/",
      "display_url" : "pressgr.am\/switch\/"
    } ]
  },
  "in_reply_to_status_id_str" : "376716804368113664",
  "geo" : { },
  "id_str" : "376718098188886016",
  "in_reply_to_user_id" : 29913475,
  "text" : "@grouchypuppy http:\/\/t.co\/9g3u6m3RF7 &lt;&lt; your photos are YOUR photos. I'll follow if you're on there. I love Cleo &lt;3",
  "id" : 376718098188886016,
  "in_reply_to_status_id" : 376716804368113664,
  "created_at" : "2013-09-08 14:46:08 +0000",
  "in_reply_to_screen_name" : "grouchypuppy",
  "in_reply_to_user_id_str" : "29913475",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 0, 13 ],
      "id_str" : "121055499",
      "id" : 121055499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376541940352688129",
  "geo" : { },
  "id_str" : "376716866531500032",
  "in_reply_to_user_id" : 121055499,
  "text" : "@SpecterTracy yeah.. i often have the planes fly right over my head..lol",
  "id" : 376716866531500032,
  "in_reply_to_status_id" : 376541940352688129,
  "created_at" : "2013-09-08 14:41:14 +0000",
  "in_reply_to_screen_name" : "SpecterTracy",
  "in_reply_to_user_id_str" : "121055499",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 0, 15 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376507613309321216",
  "geo" : { },
  "id_str" : "376508274297692161",
  "in_reply_to_user_id" : 272595921,
  "text" : "@ducksandclucks wth??? : (((",
  "id" : 376508274297692161,
  "in_reply_to_status_id" : 376507613309321216,
  "created_at" : "2013-09-08 00:52:22 +0000",
  "in_reply_to_screen_name" : "ducksandclucks",
  "in_reply_to_user_id_str" : "272595921",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376499234414944257",
  "geo" : { },
  "id_str" : "376499706647429120",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind yup...",
  "id" : 376499706647429120,
  "in_reply_to_status_id" : 376499234414944257,
  "created_at" : "2013-09-08 00:18:19 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376493220077010944",
  "geo" : { },
  "id_str" : "376495774487429120",
  "in_reply_to_user_id" : 140291463,
  "text" : "@SkypilotOfHope lovely : )",
  "id" : 376495774487429120,
  "in_reply_to_status_id" : 376493220077010944,
  "created_at" : "2013-09-08 00:02:42 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/oeHERZq2iY",
      "expanded_url" : "http:\/\/pressgr.am\/switch",
      "display_url" : "pressgr.am\/switch"
    } ]
  },
  "geo" : { },
  "id_str" : "376495280255811585",
  "text" : "RT @Pressgram: Have you made the switch? http:\/\/t.co\/oeHERZq2iY &lt;~~ 3 clicks. that was easy. pass it on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/oeHERZq2iY",
        "expanded_url" : "http:\/\/pressgr.am\/switch",
        "display_url" : "pressgr.am\/switch"
      } ]
    },
    "geo" : { },
    "id_str" : "376492525051080704",
    "text" : "Have you made the switch? http:\/\/t.co\/oeHERZq2iY &lt;~~ 3 clicks. that was easy. pass it on.",
    "id" : 376492525051080704,
    "created_at" : "2013-09-07 23:49:47 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 376495280255811585,
  "created_at" : "2013-09-08 00:00:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376495214455574528",
  "text" : "@IronAtheist Never!! ((curls back up for nap under my rock))",
  "id" : 376495214455574528,
  "created_at" : "2013-09-08 00:00:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    }, {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 127, 140 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/vqnJ0r0J9R",
      "expanded_url" : "http:\/\/buzz.naturalnews.com\/000981-Amish_parents-parental_rights-chemotherapy.html",
      "display_url" : "buzz.naturalnews.com\/000981-Amish_p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376481718426804224",
  "text" : "RT @HealthRanger: Ohio judge reasserts rights of Amish parents who refuse chemo for their daughter  http:\/\/t.co\/vqnJ0r0J9R via @HealthRanger",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthRanger",
        "screen_name" : "HealthRanger",
        "indices" : [ 109, 122 ],
        "id_str" : "15843059",
        "id" : 15843059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/vqnJ0r0J9R",
        "expanded_url" : "http:\/\/buzz.naturalnews.com\/000981-Amish_parents-parental_rights-chemotherapy.html",
        "display_url" : "buzz.naturalnews.com\/000981-Amish_p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376480942782558208",
    "text" : "Ohio judge reasserts rights of Amish parents who refuse chemo for their daughter  http:\/\/t.co\/vqnJ0r0J9R via @HealthRanger",
    "id" : 376480942782558208,
    "created_at" : "2013-09-07 23:03:46 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 376481718426804224,
  "created_at" : "2013-09-07 23:06:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376473463805861888",
  "text" : "saw a really cool movie the other night.. \"Lars and the Real Girl\" it was touching and funny.",
  "id" : 376473463805861888,
  "created_at" : "2013-09-07 22:34:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 0, 13 ],
      "id_str" : "121055499",
      "id" : 121055499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376456919465992192",
  "geo" : { },
  "id_str" : "376472679059968000",
  "in_reply_to_user_id" : 121055499,
  "text" : "@SpecterTracy no-ghosters would say that Spain can be proven by accepted science while ghosts cannot...",
  "id" : 376472679059968000,
  "in_reply_to_status_id" : 376456919465992192,
  "created_at" : "2013-09-07 22:30:55 +0000",
  "in_reply_to_screen_name" : "SpecterTracy",
  "in_reply_to_user_id_str" : "121055499",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376459911716024320",
  "geo" : { },
  "id_str" : "376469506962386944",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind i dont get why ppl dont get separation of church and state... sigh...",
  "id" : 376469506962386944,
  "in_reply_to_status_id" : 376459911716024320,
  "created_at" : "2013-09-07 22:18:19 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HPV",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "vaccines",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "Gardasil",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "boys",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "Canada",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/0JoUNaYyrd",
      "expanded_url" : "http:\/\/ow.ly\/onq3W",
      "display_url" : "ow.ly\/onq3W"
    } ]
  },
  "geo" : { },
  "id_str" : "376468746031755264",
  "text" : "RT @drbloem: #HPV #vaccines #Gardasil now pushed onto #boys in #Canada\u0094 - http:\/\/t.co\/0JoUNaYyrd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HPV",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "vaccines",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "Gardasil",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "boys",
        "indices" : [ 41, 46 ]
      }, {
        "text" : "Canada",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/0JoUNaYyrd",
        "expanded_url" : "http:\/\/ow.ly\/onq3W",
        "display_url" : "ow.ly\/onq3W"
      } ]
    },
    "geo" : { },
    "id_str" : "376465481848598528",
    "text" : "#HPV #vaccines #Gardasil now pushed onto #boys in #Canada\u0094 - http:\/\/t.co\/0JoUNaYyrd",
    "id" : 376465481848598528,
    "created_at" : "2013-09-07 22:02:19 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 376468746031755264,
  "created_at" : "2013-09-07 22:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376451243465781248",
  "geo" : { },
  "id_str" : "376453309210427393",
  "in_reply_to_user_id" : 140291463,
  "text" : "@SkypilotOfHope so precious..lol",
  "id" : 376453309210427393,
  "in_reply_to_status_id" : 376451243465781248,
  "created_at" : "2013-09-07 21:13:57 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Z",
      "screen_name" : "zorabet",
      "indices" : [ 3, 11 ],
      "id_str" : "17767454",
      "id" : 17767454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376439905590579200",
  "text" : "RT @zorabet: \"boston public schools will now serve free breakfast AND lunch to ALL students\" GOD BLESS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376439103354462208",
    "text" : "\"boston public schools will now serve free breakfast AND lunch to ALL students\" GOD BLESS",
    "id" : 376439103354462208,
    "created_at" : "2013-09-07 20:17:30 +0000",
    "user" : {
      "name" : "Sarah Z",
      "screen_name" : "zorabet",
      "protected" : false,
      "id_str" : "17767454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791385466188595200\/tlcJFXp1_normal.jpg",
      "id" : 17767454,
      "verified" : false
    }
  },
  "id" : 376439905590579200,
  "created_at" : "2013-09-07 20:20:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 3, 19 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/3IyX9svLki",
      "expanded_url" : "http:\/\/twitpic.com\/dc9ilc",
      "display_url" : "twitpic.com\/dc9ilc"
    } ]
  },
  "geo" : { },
  "id_str" : "376121393164722176",
  "text" : "RT @HighlandFarmsME: \"I am too cute -- and I know it!\" (Our newest calf, Montana, born last week.)  http:\/\/t.co\/3IyX9svLki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/3IyX9svLki",
        "expanded_url" : "http:\/\/twitpic.com\/dc9ilc",
        "display_url" : "twitpic.com\/dc9ilc"
      } ]
    },
    "geo" : { },
    "id_str" : "376121112368664579",
    "text" : "\"I am too cute -- and I know it!\" (Our newest calf, Montana, born last week.)  http:\/\/t.co\/3IyX9svLki",
    "id" : 376121112368664579,
    "created_at" : "2013-09-06 23:13:55 +0000",
    "user" : {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "protected" : false,
      "id_str" : "1050419874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046136643\/52b682fed61ae8e3cd6692fcb7e54ab8_normal.jpeg",
      "id" : 1050419874,
      "verified" : false
    }
  },
  "id" : 376121393164722176,
  "created_at" : "2013-09-06 23:15:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376121223366709248",
  "text" : "@ThePlushGourmet he is awesome : )",
  "id" : 376121223366709248,
  "created_at" : "2013-09-06 23:14:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/7yyJ55VSil",
      "expanded_url" : "http:\/\/moosebegab.tumblr.com\/post\/60476444381\/when-youre-eleven",
      "display_url" : "moosebegab.tumblr.com\/post\/604764443\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376088128181649408",
  "text" : "When you're eleven... - My Tumblr http:\/\/t.co\/7yyJ55VSil",
  "id" : 376088128181649408,
  "created_at" : "2013-09-06 21:02:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376085494284976128",
  "geo" : { },
  "id_str" : "376087380546953219",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth HA! lol",
  "id" : 376087380546953219,
  "in_reply_to_status_id" : 376085494284976128,
  "created_at" : "2013-09-06 20:59:53 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376077292092420096",
  "text" : "im addicted to this gin rummy app on my #KindleFire &gt;&gt; Gin Rummy by AI Factory Limited .. i really dont know how to play, tho..lol",
  "id" : 376077292092420096,
  "created_at" : "2013-09-06 20:19:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nifty50",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "gopressgram",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/BXhofl1OXY",
      "expanded_url" : "http:\/\/blog.pressgr.am\/go-global\/nifty-50\/",
      "display_url" : "blog.pressgr.am\/go-global\/nift\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376075426877018112",
  "text" : "RT @Pressgram: We are missing a BUNCH in the US! - http:\/\/t.co\/BXhofl1OXY #nifty50 #gopressgram \u2026 \u2026 Let\u2019s fill it up!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nifty50",
        "indices" : [ 59, 67 ]
      }, {
        "text" : "gopressgram",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/BXhofl1OXY",
        "expanded_url" : "http:\/\/blog.pressgr.am\/go-global\/nifty-50\/",
        "display_url" : "blog.pressgr.am\/go-global\/nift\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376073456762101760",
    "text" : "We are missing a BUNCH in the US! - http:\/\/t.co\/BXhofl1OXY #nifty50 #gopressgram \u2026 \u2026 Let\u2019s fill it up!",
    "id" : 376073456762101760,
    "created_at" : "2013-09-06 20:04:33 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 376075426877018112,
  "created_at" : "2013-09-06 20:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 3, 13 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/oeHERZq2iY",
      "expanded_url" : "http:\/\/pressgr.am\/switch",
      "display_url" : "pressgr.am\/switch"
    } ]
  },
  "geo" : { },
  "id_str" : "376063774941134848",
  "text" : "RT @Pressgram: Have you made the \u201Cswitch\u201D yet? http:\/\/t.co\/oeHERZq2iY \u2026 \u2026 more importantly, have you gotten others to do it too? #gopressgr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gopressgram",
        "indices" : [ 114, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/oeHERZq2iY",
        "expanded_url" : "http:\/\/pressgr.am\/switch",
        "display_url" : "pressgr.am\/switch"
      } ]
    },
    "geo" : { },
    "id_str" : "376062930518700033",
    "text" : "Have you made the \u201Cswitch\u201D yet? http:\/\/t.co\/oeHERZq2iY \u2026 \u2026 more importantly, have you gotten others to do it too? #gopressgram",
    "id" : 376062930518700033,
    "created_at" : "2013-09-06 19:22:44 +0000",
    "user" : {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "protected" : false,
      "id_str" : "1066032464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458769588298059777\/W7ou22sK_normal.png",
      "id" : 1066032464,
      "verified" : false
    }
  },
  "id" : 376063774941134848,
  "created_at" : "2013-09-06 19:26:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376051234513637376",
  "geo" : { },
  "id_str" : "376058961255886850",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg lol",
  "id" : 376058961255886850,
  "in_reply_to_status_id" : 376051234513637376,
  "created_at" : "2013-09-06 19:06:57 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "indices" : [ 3, 12 ],
      "id_str" : "8234572",
      "id" : 8234572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/9CnUJ0VO41",
      "expanded_url" : "http:\/\/www.livingdigitally.net\/2013\/09\/free-copies-of-kingmaker.html",
      "display_url" : "livingdigitally.net\/2013\/09\/free-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376014004155473922",
  "text" : "RT @cantrell: Want a free copy of Kingmaker? http:\/\/t.co\/9CnUJ0VO41",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/9CnUJ0VO41",
        "expanded_url" : "http:\/\/www.livingdigitally.net\/2013\/09\/free-copies-of-kingmaker.html",
        "display_url" : "livingdigitally.net\/2013\/09\/free-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376008626798088192",
    "text" : "Want a free copy of Kingmaker? http:\/\/t.co\/9CnUJ0VO41",
    "id" : 376008626798088192,
    "created_at" : "2013-09-06 15:46:57 +0000",
    "user" : {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "protected" : false,
      "id_str" : "8234572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3466700371\/ca68118063303c7fe19a3cf79e68a9f8_normal.jpeg",
      "id" : 8234572,
      "verified" : true
    }
  },
  "id" : 376014004155473922,
  "created_at" : "2013-09-06 16:08:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/15vbu9yXmt",
      "expanded_url" : "https:\/\/www.lightstock.com\/partner_faqs",
      "display_url" : "lightstock.com\/partner_faqs"
    } ]
  },
  "geo" : { },
  "id_str" : "376011299471106048",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves fyi: https:\/\/t.co\/15vbu9yXmt",
  "id" : 376011299471106048,
  "created_at" : "2013-09-06 15:57:34 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pressgram",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375985588794449920",
  "text" : "if you're on pressgr.am and post nature, animal photos.. i might follow you. reply w your username. #pressgram",
  "id" : 375985588794449920,
  "created_at" : "2013-09-06 14:15:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "indices" : [ 3, 17 ],
      "id_str" : "169354425",
      "id" : 169354425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/kL99E0KfHX",
      "expanded_url" : "http:\/\/dld.bz\/cPrmw",
      "display_url" : "dld.bz\/cPrmw"
    } ]
  },
  "geo" : { },
  "id_str" : "375984394063736832",
  "text" : "RT @MontyMcSquill: We Love Sarah Silverman's Heartfelt Obituary for Her Dog, Duck http:\/\/t.co\/kL99E0KfHX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/kL99E0KfHX",
        "expanded_url" : "http:\/\/dld.bz\/cPrmw",
        "display_url" : "dld.bz\/cPrmw"
      } ]
    },
    "geo" : { },
    "id_str" : "375975496187904000",
    "text" : "We Love Sarah Silverman's Heartfelt Obituary for Her Dog, Duck http:\/\/t.co\/kL99E0KfHX",
    "id" : 375975496187904000,
    "created_at" : "2013-09-06 13:35:18 +0000",
    "user" : {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "protected" : false,
      "id_str" : "169354425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083700728\/McSquill_normal.jpg",
      "id" : 169354425,
      "verified" : false
    }
  },
  "id" : 375984394063736832,
  "created_at" : "2013-09-06 14:10:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 0, 15 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375772315528613888",
  "geo" : { },
  "id_str" : "375773993577357313",
  "in_reply_to_user_id" : 272595921,
  "text" : "@ducksandclucks pressgr.am .. like instagram but you own your photos. it's an ios app (also offers wp plugin to post to wp blogs)",
  "id" : 375773993577357313,
  "in_reply_to_status_id" : 375772315528613888,
  "created_at" : "2013-09-06 00:14:36 +0000",
  "in_reply_to_screen_name" : "ducksandclucks",
  "in_reply_to_user_id_str" : "272595921",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375744641707958272",
  "text" : "@BibleAlsoSays hmm.. now i have to rethink the point i was trying to make..lol @weakSquare",
  "id" : 375744641707958272,
  "created_at" : "2013-09-05 22:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 61, 75 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375742858042433536",
  "text" : "@weakSquare yes DS.. that assertion is what i was asking BAS @BibleAlsoSays",
  "id" : 375742858042433536,
  "created_at" : "2013-09-05 22:10:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 18, 28 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    }, {
      "name" : "Chris Lema",
      "screen_name" : "chrislema",
      "indices" : [ 70, 80 ],
      "id_str" : "17370471",
      "id" : 17370471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/pucl4lJRUg",
      "expanded_url" : "http:\/\/chrislema.com\/pressgram-is-live",
      "display_url" : "chrislema.com\/pressgram-is-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375740321075707905",
  "text" : "I just downloaded @pressgram and entered to win a free iPad mini from @chrislema at http:\/\/t.co\/pucl4lJRUg",
  "id" : 375740321075707905,
  "created_at" : "2013-09-05 22:00:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375707717580505088",
  "text" : "@weakSquare LOLOL",
  "id" : 375707717580505088,
  "created_at" : "2013-09-05 19:51:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/pressgr.am\/\" rel=\"nofollow\"\u003EPressgram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/375701419158159360\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/PBGplXOdtg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTbCcyqIEAAXhKi.jpg",
      "id_str" : "375701418822602752",
      "id" : 375701418822602752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTbCcyqIEAAXhKi.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/PBGplXOdtg"
    } ],
    "hashtags" : [ {
      "text" : "dogs",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "aussie",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375701419158159360",
  "text" : "Dog licking toes. #dogs #aussie http:\/\/t.co\/PBGplXOdtg",
  "id" : 375701419158159360,
  "created_at" : "2013-09-05 19:26:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 0, 15 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ducksofpressgram",
      "indices" : [ 39, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375692789688053760",
  "geo" : { },
  "id_str" : "375698970841849857",
  "in_reply_to_user_id" : 272595921,
  "text" : "@ducksandclucks you could be the first #ducksofpressgram : ) (no affiliation, just a cool app)",
  "id" : 375698970841849857,
  "in_reply_to_status_id" : 375692789688053760,
  "created_at" : "2013-09-05 19:16:29 +0000",
  "in_reply_to_screen_name" : "ducksandclucks",
  "in_reply_to_user_id_str" : "272595921",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "APenAndADream",
      "screen_name" : "APenAndADream",
      "indices" : [ 11, 25 ],
      "id_str" : "740926623759863808",
      "id" : 740926623759863808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375691516141793280",
  "geo" : { },
  "id_str" : "375694326002499584",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous @APenAndADream awwww... : )",
  "id" : 375694326002499584,
  "in_reply_to_status_id" : 375691516141793280,
  "created_at" : "2013-09-05 18:58:02 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375652565863505921",
  "geo" : { },
  "id_str" : "375674426173308928",
  "in_reply_to_user_id" : 93747129,
  "text" : "@BibleAlsoSays no reply to that point? @weakSquare",
  "id" : 375674426173308928,
  "in_reply_to_status_id" : 375652565863505921,
  "created_at" : "2013-09-05 17:38:57 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375672999153635329",
  "text" : "EVERYTHING is perception.",
  "id" : 375672999153635329,
  "created_at" : "2013-09-05 17:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375664265698361344",
  "text" : "everything IS alive...",
  "id" : 375664265698361344,
  "created_at" : "2013-09-05 16:58:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375661787758096386",
  "text" : "yup.. im so open-minded.. i have no brains. They fell out a long time ago.",
  "id" : 375661787758096386,
  "created_at" : "2013-09-05 16:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375657163655360512",
  "text" : "we are definitely not all born equal.",
  "id" : 375657163655360512,
  "created_at" : "2013-09-05 16:30:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375655216449744896",
  "text" : "@BibleAlsoSays found a link to a lecture i can watch.. cool.. @weakSquare",
  "id" : 375655216449744896,
  "created_at" : "2013-09-05 16:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375653322268487680",
  "text" : "@BibleAlsoSays interesting.. what is your thought on 9\/11, BAS.. just curious.. @weakSquare",
  "id" : 375653322268487680,
  "created_at" : "2013-09-05 16:15:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375652565863505921",
  "text" : "@BibleAlsoSays according to your thinking.. a gay person is broken.  @weakSquare",
  "id" : 375652565863505921,
  "created_at" : "2013-09-05 16:12:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375650640061419522",
  "text" : "@BibleAlsoSays nobody is \"broken\" .. just unique. broken sinners is a peeve of mine re: christianity @weakSquare",
  "id" : 375650640061419522,
  "created_at" : "2013-09-05 16:04:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Little",
      "screen_name" : "littlewoz",
      "indices" : [ 3, 13 ],
      "id_str" : "2225145971",
      "id" : 2225145971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375646878383108097",
  "text" : "RT @LittleWoz: The \"shaming mom\" created a storm with her \"FYI girls\" post. Great response. FYI (if you're a teenage boy) http:\/\/t.co\/RsmMG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noshame",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/RsmMGpYcmD",
        "expanded_url" : "http:\/\/wp.me\/p2Kwk0-AD",
        "display_url" : "wp.me\/p2Kwk0-AD"
      } ]
    },
    "geo" : { },
    "id_str" : "375640098500395008",
    "text" : "The \"shaming mom\" created a storm with her \"FYI girls\" post. Great response. FYI (if you're a teenage boy) http:\/\/t.co\/RsmMGpYcmD #noshame",
    "id" : 375640098500395008,
    "created_at" : "2013-09-05 15:22:33 +0000",
    "user" : {
      "name" : "Woz",
      "screen_name" : "SagedMama",
      "protected" : false,
      "id_str" : "24999398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744872447384518657\/vS26pYyD_normal.jpg",
      "id" : 24999398,
      "verified" : false
    }
  },
  "id" : 375646878383108097,
  "created_at" : "2013-09-05 15:49:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375641019687002113",
  "text" : "RT @CharlesBivona: \"I'm very disturbed by this general idea that every time we see something bad in the world we should bomb it.\" @AlanGray\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rep. Alan Grayson",
        "screen_name" : "AlanGrayson",
        "indices" : [ 111, 123 ],
        "id_str" : "41017380",
        "id" : 41017380
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 124, 127 ]
      }, {
        "text" : "ows",
        "indices" : [ 128, 132 ]
      }, {
        "text" : "Syria",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375639438225059840",
    "text" : "\"I'm very disturbed by this general idea that every time we see something bad in the world we should bomb it.\" @AlanGrayson #p2 #ows #Syria",
    "id" : 375639438225059840,
    "created_at" : "2013-09-05 15:19:55 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 375641019687002113,
  "created_at" : "2013-09-05 15:26:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Pruveadenti",
      "screen_name" : "beckypruves",
      "indices" : [ 3, 15 ],
      "id_str" : "751843585",
      "id" : 751843585
    }, {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 17, 31 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Singlepayer",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375640978712821760",
  "text" : "RT @beckypruves: @AllOnMedicare #Singlepayer This is a non-partisan, humanitarian issue.  Everybody in! Nobody out!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 0, 14 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Singlepayer",
        "indices" : [ 15, 27 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "375629479403458560",
    "geo" : { },
    "id_str" : "375636261643362304",
    "in_reply_to_user_id" : 1067293117,
    "text" : "@AllOnMedicare #Singlepayer This is a non-partisan, humanitarian issue.  Everybody in! Nobody out!",
    "id" : 375636261643362304,
    "in_reply_to_status_id" : 375629479403458560,
    "created_at" : "2013-09-05 15:07:18 +0000",
    "in_reply_to_screen_name" : "AllOnMedicare",
    "in_reply_to_user_id_str" : "1067293117",
    "user" : {
      "name" : "Rebecca Pruveadenti",
      "screen_name" : "beckypruves",
      "protected" : false,
      "id_str" : "751843585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000417037655\/592c70fb6596f2dcfe4f39cecdfdf95d_normal.jpeg",
      "id" : 751843585,
      "verified" : false
    }
  },
  "id" : 375640978712821760,
  "created_at" : "2013-09-05 15:26:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375632404209082368",
  "geo" : { },
  "id_str" : "375640427874881537",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos insurance is a scam. concept makes sense but then PROFIT motive added.",
  "id" : 375640427874881537,
  "in_reply_to_status_id" : 375632404209082368,
  "created_at" : "2013-09-05 15:23:51 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375636203930152960",
  "geo" : { },
  "id_str" : "375638561241853953",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell it sends out neg energy into the world which is attracted to other neg energy. large enough it creates a neg event.",
  "id" : 375638561241853953,
  "in_reply_to_status_id" : 375636203930152960,
  "created_at" : "2013-09-05 15:16:26 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "indices" : [ 3, 17 ],
      "id_str" : "26642006",
      "id" : 26642006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375638135004094464",
  "text" : "RT @Alyssa_Milano: My sex tape was leaked. Not sure what to say. Going to post the link myself to try to control the situation\u261B http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/rMICHDeioC",
        "expanded_url" : "http:\/\/j.mp\/14YM0dB",
        "display_url" : "j.mp\/14YM0dB"
      } ]
    },
    "geo" : { },
    "id_str" : "375301974117593088",
    "text" : "My sex tape was leaked. Not sure what to say. Going to post the link myself to try to control the situation\u261B http:\/\/t.co\/rMICHDeioC",
    "id" : 375301974117593088,
    "created_at" : "2013-09-04 16:58:58 +0000",
    "user" : {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "protected" : false,
      "id_str" : "26642006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797077615064457217\/mSJCnze-_normal.jpg",
      "id" : 26642006,
      "verified" : true
    }
  },
  "id" : 375638135004094464,
  "created_at" : "2013-09-05 15:14:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Darth",
      "screen_name" : "DarthNihilus1",
      "indices" : [ 112, 126 ],
      "id_str" : "554040658",
      "id" : 554040658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375637427638923264",
  "text" : "@BibleAlsoSays \"You are cliche to me\" &lt;&lt; we all do this but we need to see ppl as individuals @weakSquare @DarthNihilus1",
  "id" : 375637427638923264,
  "created_at" : "2013-09-05 15:11:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375634504099979264",
  "geo" : { },
  "id_str" : "375635692002357248",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos 50\/60 degrees. wanting to put socks on, wear a sweater.",
  "id" : 375635692002357248,
  "in_reply_to_status_id" : 375634504099979264,
  "created_at" : "2013-09-05 15:05:02 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375634027765460992",
  "text" : "didnt get much of a summer. rather pissed about that. now school starts and cold mornings. UGH.",
  "id" : 375634027765460992,
  "created_at" : "2013-09-05 14:58:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1stdayofschool",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375633601418633217",
  "text" : "i keep forgetting my DD is not upstairs sleeping o-O #1stdayofschool",
  "id" : 375633601418633217,
  "created_at" : "2013-09-05 14:56:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samwise Aaron",
      "screen_name" : "samwis",
      "indices" : [ 3, 10 ],
      "id_str" : "16285802",
      "id" : 16285802
    }, {
      "name" : "Aetna",
      "screen_name" : "AetnaHelp",
      "indices" : [ 12, 22 ],
      "id_str" : "488810967",
      "id" : 488810967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375630308457975808",
  "text" : "RT @samwis: @AetnaHelp apparently I get better prices for my blood pressure meds when I DON'T use you. NO Thank You for costing 6* xtra for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aetna",
        "screen_name" : "AetnaHelp",
        "indices" : [ 0, 10 ],
        "id_str" : "488810967",
        "id" : 488810967
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "349147497949691907",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.1948792, -118.396948 ]
    },
    "id_str" : "375608001593217024",
    "in_reply_to_user_id" : 488810967,
    "text" : "@AetnaHelp apparently I get better prices for my blood pressure meds when I DON'T use you. NO Thank You for costing 6* xtra for over a year.",
    "id" : 375608001593217024,
    "in_reply_to_status_id" : 349147497949691907,
    "created_at" : "2013-09-05 13:15:00 +0000",
    "in_reply_to_screen_name" : "AetnaHelp",
    "in_reply_to_user_id_str" : "488810967",
    "user" : {
      "name" : "Samwise Aaron",
      "screen_name" : "samwis",
      "protected" : false,
      "id_str" : "16285802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608210311\/Samwise_Bearded_Leaven_Las_Vegas_normal.jpg",
      "id" : 16285802,
      "verified" : false
    }
  },
  "id" : 375630308457975808,
  "created_at" : "2013-09-05 14:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/pressgr.am\/\" rel=\"nofollow\"\u003EPressgram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/375625757235904512\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/61TiMAlK7P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTZ9osfIYAAu6lq.jpg",
      "id_str" : "375625757021986816",
      "id" : 375625757021986816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTZ9osfIYAAu6lq.jpg",
      "sizes" : [ {
        "h" : 721,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/61TiMAlK7P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375625757235904512",
  "text" : "He made it! http:\/\/t.co\/61TiMAlK7P",
  "id" : 375625757235904512,
  "created_at" : "2013-09-05 14:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375427556658651136",
  "text" : "Bible study starts up again next week. I feel like such a different person from when we stopped last June. Dunno why.",
  "id" : 375427556658651136,
  "created_at" : "2013-09-05 01:17:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375427066998833152",
  "text" : "Tomorrow my DD starts her senior year of HS.",
  "id" : 375427066998833152,
  "created_at" : "2013-09-05 01:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375425565928726528",
  "text" : "I like Chrissy on MasterChef.",
  "id" : 375425565928726528,
  "created_at" : "2013-09-05 01:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Missandrei",
      "screen_name" : "OHTheMaryD",
      "indices" : [ 3, 14 ],
      "id_str" : "433645820",
      "id" : 433645820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375425035840016384",
  "text" : "RT @OHTheMaryD: So a 7 y.o. straight A student was sent home from school for having the AUDACITY to wear her hair the way it naturally grow\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375414901927608321",
    "text" : "So a 7 y.o. straight A student was sent home from school for having the AUDACITY to wear her hair the way it naturally grows out of her head",
    "id" : 375414901927608321,
    "created_at" : "2013-09-05 00:27:42 +0000",
    "user" : {
      "name" : "Missandrei",
      "screen_name" : "OHTheMaryD",
      "protected" : false,
      "id_str" : "433645820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798739868968976384\/ei_wNf-K_normal.jpg",
      "id" : 433645820,
      "verified" : false
    }
  },
  "id" : 375425035840016384,
  "created_at" : "2013-09-05 01:07:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/GwtgKbPUXf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=I_FdmdbyGZo&list=PLVrg5xLmCvhFPgnrb7K-_LfoAjwWoQ5JK",
      "display_url" : "youtube.com\/watch?v=I_Fdmd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375417892344320000",
  "text" : "Republican Represents God, Not His Constituents (and the ppl clap): http:\/\/t.co\/GwtgKbPUXf",
  "id" : 375417892344320000,
  "created_at" : "2013-09-05 00:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACIM",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375308911521198080",
  "text" : "i believe everything and nothing at the same time. that's what happens when you've read #ACIM .. LOL",
  "id" : 375308911521198080,
  "created_at" : "2013-09-04 17:26:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375302423079690240",
  "text" : "@weakSquare oh dear.. while im not extreme consp. theorist, i believe many do have some merit. and im def anti-hpv vax.",
  "id" : 375302423079690240,
  "created_at" : "2013-09-04 17:00:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375297886881189888",
  "text" : "@weakSquare if referring to 9-11, then you'll unfollow as i dont believe govt story of what happened...",
  "id" : 375297886881189888,
  "created_at" : "2013-09-04 16:42:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "book",
      "indices" : [ 58, 63 ]
    }, {
      "text" : "socialmedia",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/VN59XCxMFn",
      "expanded_url" : "http:\/\/ebks.to\/14IsFfJ",
      "display_url" : "ebks.to\/14IsFfJ"
    } ]
  },
  "geo" : { },
  "id_str" : "375269952359374848",
  "text" : "RT @ebookfriendly: Concept: Kuote grabs text from a paper #book and makes it instantly available in #socialmedia http:\/\/t.co\/VN59XCxMFn htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/375195031591600128\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/O86CUO3rUE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTT15K9CQAAD3Fp.jpg",
        "id_str" : "375195031520296960",
        "id" : 375195031520296960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTT15K9CQAAD3Fp.jpg",
        "sizes" : [ {
          "h" : 283,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 522
        } ],
        "display_url" : "pic.twitter.com\/O86CUO3rUE"
      } ],
      "hashtags" : [ {
        "text" : "book",
        "indices" : [ 39, 44 ]
      }, {
        "text" : "socialmedia",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/VN59XCxMFn",
        "expanded_url" : "http:\/\/ebks.to\/14IsFfJ",
        "display_url" : "ebks.to\/14IsFfJ"
      } ]
    },
    "geo" : { },
    "id_str" : "375195031591600128",
    "text" : "Concept: Kuote grabs text from a paper #book and makes it instantly available in #socialmedia http:\/\/t.co\/VN59XCxMFn http:\/\/t.co\/O86CUO3rUE",
    "id" : 375195031591600128,
    "created_at" : "2013-09-04 09:54:00 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 375269952359374848,
  "created_at" : "2013-09-04 14:51:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375020473437790208",
  "text" : "we have new bathroom fish. friend was giving them away. 3 mediumish size goldfish.",
  "id" : 375020473437790208,
  "created_at" : "2013-09-03 22:20:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375018199857000448",
  "geo" : { },
  "id_str" : "375019354057744384",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 nonononononononononono.....",
  "id" : 375019354057744384,
  "in_reply_to_status_id" : 375018199857000448,
  "created_at" : "2013-09-03 22:15:56 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "precious",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375019056597716992",
  "text" : "o.m.g. just had fam of turkeys crossing in driveway as we were pulling in.. had to stop for last baby who was dawdling..hehe #precious",
  "id" : 375019056597716992,
  "created_at" : "2013-09-03 22:14:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374985094127046656",
  "text" : "trying to find a dress for prom theme bday party. ugh. im too fat!!",
  "id" : 374985094127046656,
  "created_at" : "2013-09-03 19:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anniversary",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374919073143848961",
  "text" : "25 years later and I'm still laughing. I definitely got the better deal. Poor DH..lol #anniversary",
  "id" : 374919073143848961,
  "created_at" : "2013-09-03 15:37:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snow White",
      "screen_name" : "HalfSanePrness",
      "indices" : [ 0, 15 ],
      "id_str" : "400415766",
      "id" : 400415766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374692599526744064",
  "geo" : { },
  "id_str" : "374695956739944448",
  "in_reply_to_user_id" : 400415766,
  "text" : "@HalfSanePrness awww.. precious!!",
  "id" : 374695956739944448,
  "in_reply_to_status_id" : 374692599526744064,
  "created_at" : "2013-09-03 00:50:52 +0000",
  "in_reply_to_screen_name" : "HalfSanePrness",
  "in_reply_to_user_id_str" : "400415766",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 3, 17 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374672272126009345",
  "text" : "RT @johnnie_cakes: Knowing what you want is important, but so is not overlooking something\/someone because they don't fit on a predetermine\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374670859719299072",
    "text" : "Knowing what you want is important, but so is not overlooking something\/someone because they don't fit on a predetermined list.",
    "id" : 374670859719299072,
    "created_at" : "2013-09-02 23:11:08 +0000",
    "user" : {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "protected" : false,
      "id_str" : "16901470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765066200657166336\/h3XngAjO_normal.jpg",
      "id" : 16901470,
      "verified" : false
    }
  },
  "id" : 374672272126009345,
  "created_at" : "2013-09-02 23:16:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda",
      "screen_name" : "DebtTrut",
      "indices" : [ 3, 12 ],
      "id_str" : "251927949",
      "id" : 251927949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Dc2fCdSwiF",
      "expanded_url" : "http:\/\/www.upworthy.com\/a-bunch-of-young-geniuses-just-made-a-corrupt-corporation-freak-out-big-time-time-for-round",
      "display_url" : "upworthy.com\/a-bunch-of-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374663731239583744",
  "text" : "RT @DebtTrut: THIS IS THE 1ST REALLY BIG STEP IN 'WE THE PEOPLE' TAKING DOWN THE FOSSIL FUEL INDUSTRY: http:\/\/t.co\/Dc2fCdSwiF  Posted on FB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Dc2fCdSwiF",
        "expanded_url" : "http:\/\/www.upworthy.com\/a-bunch-of-young-geniuses-just-made-a-corrupt-corporation-freak-out-big-time-time-for-round",
        "display_url" : "upworthy.com\/a-bunch-of-you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374655734257954816",
    "text" : "THIS IS THE 1ST REALLY BIG STEP IN 'WE THE PEOPLE' TAKING DOWN THE FOSSIL FUEL INDUSTRY: http:\/\/t.co\/Dc2fCdSwiF  Posted on FBk by Gene Stone",
    "id" : 374655734257954816,
    "created_at" : "2013-09-02 22:11:02 +0000",
    "user" : {
      "name" : "Linda",
      "screen_name" : "DebtTrut",
      "protected" : false,
      "id_str" : "251927949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712683654242152449\/MWjpSFfg_normal.jpg",
      "id" : 251927949,
      "verified" : false
    }
  },
  "id" : 374663731239583744,
  "created_at" : "2013-09-02 22:42:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374663659919667201",
  "text" : "RT @adamrshields: Lots of Kindle Book have dropped in price over the past few days - why you should set up an ereaderiq account http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/YwTe6Oy8My",
        "expanded_url" : "http:\/\/wp.me\/p1pu8r-6sW",
        "display_url" : "wp.me\/p1pu8r-6sW"
      } ]
    },
    "geo" : { },
    "id_str" : "374657718390255616",
    "text" : "Lots of Kindle Book have dropped in price over the past few days - why you should set up an ereaderiq account http:\/\/t.co\/YwTe6Oy8My",
    "id" : 374657718390255616,
    "created_at" : "2013-09-02 22:18:55 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 374663659919667201,
  "created_at" : "2013-09-02 22:42:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374659332622667776",
  "text" : "i lose all rationality when it comes to lightning o-O",
  "id" : 374659332622667776,
  "created_at" : "2013-09-02 22:25:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IPA",
      "indices" : [ 72, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374559699418365952",
  "text" : "Dear Universe.. please give me patience.. oh and im still waiting on my #IPA request. Thanks bunches!!",
  "id" : 374559699418365952,
  "created_at" : "2013-09-02 15:49:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 72, 82 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/DMmhLuDaUO",
      "expanded_url" : "http:\/\/shar.es\/zB6Kc",
      "display_url" : "shar.es\/zB6Kc"
    } ]
  },
  "geo" : { },
  "id_str" : "374559301722832896",
  "text" : "RT @DwayneReaves: Solar Panels all over N.C\n http:\/\/t.co\/DMmhLuDaUO via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 54, 64 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/DMmhLuDaUO",
        "expanded_url" : "http:\/\/shar.es\/zB6Kc",
        "display_url" : "shar.es\/zB6Kc"
      } ]
    },
    "geo" : { },
    "id_str" : "374558879259955200",
    "text" : "Solar Panels all over N.C\n http:\/\/t.co\/DMmhLuDaUO via @sharethis",
    "id" : 374558879259955200,
    "created_at" : "2013-09-02 15:46:10 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 374559301722832896,
  "created_at" : "2013-09-02 15:47:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374558836385775616",
  "text" : "RT @TheDailyHug: You get nothing out of feeling unworthy. So, knock it off.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374558621344206848",
    "text" : "You get nothing out of feeling unworthy. So, knock it off.",
    "id" : 374558621344206848,
    "created_at" : "2013-09-02 15:45:08 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 374558836385775616,
  "created_at" : "2013-09-02 15:46:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374553793712517122",
  "text" : "arg.. DH just does NOT get timing. You simply DO NOT hog ONLY bathroom if you expect to leave house w 3 females in tow!!!",
  "id" : 374553793712517122,
  "created_at" : "2013-09-02 15:25:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374547147514851328",
  "text" : "RT @ZigerShamisen: Two or more people can see a rainbow, without it ever existing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374412686752088065",
    "text" : "Two or more people can see a rainbow, without it ever existing.",
    "id" : 374412686752088065,
    "created_at" : "2013-09-02 06:05:15 +0000",
    "user" : {
      "name" : "\u8001\u864E",
      "screen_name" : "ShibumiKiDo",
      "protected" : false,
      "id_str" : "163578867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799138418441584641\/pc2bZJLz_normal.jpg",
      "id" : 163578867,
      "verified" : false
    }
  },
  "id" : 374547147514851328,
  "created_at" : "2013-09-02 14:59:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Physics",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "quantum",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374536188087914497",
  "geo" : { },
  "id_str" : "374546852265205760",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i actually sort of understood some of it.. (but dont ask which parts cuz i dunno..lol) #Physics #quantum",
  "id" : 374546852265205760,
  "in_reply_to_status_id" : 374536188087914497,
  "created_at" : "2013-09-02 14:58:22 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/4LrnlAgbfn",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ASRpIym_jFM&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=ASRpIy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374546370784292864",
  "text" : "RT @VirgoJohnny: Watch \"The Higgs Boson, Part II: What is Mass?\" on YouTube - https:\/\/t.co\/4LrnlAgbfn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/4LrnlAgbfn",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ASRpIym_jFM&feature=youtube_gdata_player",
        "display_url" : "youtube.com\/watch?v=ASRpIy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374536188087914497",
    "text" : "Watch \"The Higgs Boson, Part II: What is Mass?\" on YouTube - https:\/\/t.co\/4LrnlAgbfn",
    "id" : 374536188087914497,
    "created_at" : "2013-09-02 14:16:00 +0000",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 374546370784292864,
  "created_at" : "2013-09-02 14:56:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "maparocar1977",
      "screen_name" : "Rawrshock",
      "indices" : [ 53, 63 ],
      "id_str" : "2982190319",
      "id" : 2982190319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374545196798599170",
  "text" : "@BibleAlsoSays becuz humans are emotional creatures. @Rawrshock @weakSquare",
  "id" : 374545196798599170,
  "created_at" : "2013-09-02 14:51:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    }, {
      "name" : "OMGFacts Tech",
      "screen_name" : "OMGFactsTech",
      "indices" : [ 17, 30 ],
      "id_str" : "705412420546596864",
      "id" : 705412420546596864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374303490509520897",
  "text" : "RT @OMGFacts: RT @OMGFactsTech Daniel Nocera has created an 'artificial leaf.' It mimics photosynthesis and can be used to create electrici\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OMGFacts Tech",
        "screen_name" : "OMGFactsTech",
        "indices" : [ 3, 16 ],
        "id_str" : "705412420546596864",
        "id" : 705412420546596864
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374298579625852928",
    "text" : "RT @OMGFactsTech Daniel Nocera has created an 'artificial leaf.' It mimics photosynthesis and can be used to create electricity!",
    "id" : 374298579625852928,
    "created_at" : "2013-09-01 22:31:50 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 374303490509520897,
  "created_at" : "2013-09-01 22:51:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 3, 13 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374302969132355584",
  "text" : "RT @UberFacts: If we put a giant mirror 10 light years away from Earth and looked at it through a telescope, theoretically we'd see 20 year\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374298642825637888",
    "text" : "If we put a giant mirror 10 light years away from Earth and looked at it through a telescope, theoretically we'd see 20 years into the past.",
    "id" : 374298642825637888,
    "created_at" : "2013-09-01 22:32:05 +0000",
    "user" : {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "protected" : false,
      "id_str" : "95023423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615696617165885440\/JDbUuo9H_normal.jpg",
      "id" : 95023423,
      "verified" : true
    }
  },
  "id" : 374302969132355584,
  "created_at" : "2013-09-01 22:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "Chloe Dykstra",
      "screen_name" : "skydart",
      "indices" : [ 86, 94 ],
      "id_str" : "14111650",
      "id" : 14111650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374231539887792128",
  "geo" : { },
  "id_str" : "374236606158229504",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist DD &amp; I saw that.. we were like \"you go, girl!!\" shouting at tv..lol @skydart",
  "id" : 374236606158229504,
  "in_reply_to_status_id" : 374231539887792128,
  "created_at" : "2013-09-01 18:25:34 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374232421723828224",
  "geo" : { },
  "id_str" : "374236079563350017",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist ((thumbsup))",
  "id" : 374236079563350017,
  "in_reply_to_status_id" : 374232421723828224,
  "created_at" : "2013-09-01 18:23:28 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "indices" : [ 3, 18 ],
      "id_str" : "615318971",
      "id" : 615318971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374224271125385216",
  "text" : "RT @CuestionMarque: America's depraved PrivatePrison system delivers dividends to PrivateInvestors everytime another citizen goes to jail h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BjpEFWo1Ln",
        "expanded_url" : "http:\/\/theeconomiccollapseblog.com\/archives\/private-prisons-the-more-americans-they-put-behind-bars-the-more-money-they-make",
        "display_url" : "theeconomiccollapseblog.com\/archives\/priva\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374195396286742528",
    "text" : "America's depraved PrivatePrison system delivers dividends to PrivateInvestors everytime another citizen goes to jail http:\/\/t.co\/BjpEFWo1Ln",
    "id" : 374195396286742528,
    "created_at" : "2013-09-01 15:41:49 +0000",
    "user" : {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "protected" : false,
      "id_str" : "615318971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2347711009\/5slm7j57n6tf4g5d98ia_normal.jpeg",
      "id" : 615318971,
      "verified" : false
    }
  },
  "id" : 374224271125385216,
  "created_at" : "2013-09-01 17:36:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/6GYOR3JT4M",
      "expanded_url" : "http:\/\/stevecreek.com\/a-lucky-mourning-dove-fledgling\/",
      "display_url" : "stevecreek.com\/a-lucky-mourni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374191574474694657",
  "text" : "RT @screek: A Lucky Mourning Dove Fledgling http:\/\/t.co\/6GYOR3JT4M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/6GYOR3JT4M",
        "expanded_url" : "http:\/\/stevecreek.com\/a-lucky-mourning-dove-fledgling\/",
        "display_url" : "stevecreek.com\/a-lucky-mourni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374189721791913984",
    "text" : "A Lucky Mourning Dove Fledgling http:\/\/t.co\/6GYOR3JT4M",
    "id" : 374189721791913984,
    "created_at" : "2013-09-01 15:19:16 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 374191574474694657,
  "created_at" : "2013-09-01 15:26:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "iraqvet1980",
      "screen_name" : "iraqvet1980",
      "indices" : [ 16, 28 ],
      "id_str" : "2542494326",
      "id" : 2542494326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374189645170364417",
  "geo" : { },
  "id_str" : "374191446904938496",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind haha @iraqvet1980",
  "id" : 374191446904938496,
  "in_reply_to_status_id" : 374189645170364417,
  "created_at" : "2013-09-01 15:26:07 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374187702281043968",
  "geo" : { },
  "id_str" : "374189050959101952",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell tae kwon do : )",
  "id" : 374189050959101952,
  "in_reply_to_status_id" : 374187702281043968,
  "created_at" : "2013-09-01 15:16:36 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 33, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374186306165014528",
  "geo" : { },
  "id_str" : "374187385589751808",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell we learn this in #TKD .. those having more trouble need the most encouragement, more often.",
  "id" : 374187385589751808,
  "in_reply_to_status_id" : 374186306165014528,
  "created_at" : "2013-09-01 15:09:59 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374184963064594433",
  "text" : "dont know if its liver or menopause but often wake up w hot feet, feeling ill. usually fades after 1st cup of coffee. weird.",
  "id" : 374184963064594433,
  "created_at" : "2013-09-01 15:00:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]