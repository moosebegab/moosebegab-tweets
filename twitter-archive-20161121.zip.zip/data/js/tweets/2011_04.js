Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 96, 111 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/rOAhJsJ",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/politics\/obamas-white-house-correspondents-dinner-speech\/2011\/04\/30\/AFMDqbOF_video.html",
      "display_url" : "washingtonpost.com\/politics\/obama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "64531467857965056",
  "text" : "Obama's White House Correspondents' Dinner speech - The Washington Post http:\/\/t.co\/rOAhJsJ via @washingtonpost",
  "id" : 64531467857965056,
  "created_at" : "2011-05-01 03:27:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64515746058870784",
  "text" : "@Skandhasattva I like the purple lines! pretty! lol",
  "id" : 64515746058870784,
  "created_at" : "2011-05-01 02:25:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64505614361042944",
  "text" : "RT @dhammagirl: Sometimes you just need to get out of your head...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64503534078533632",
    "text" : "Sometimes you just need to get out of your head...",
    "id" : 64503534078533632,
    "created_at" : "2011-05-01 01:36:55 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 64505614361042944,
  "created_at" : "2011-05-01 01:45:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64502126235222016",
  "geo" : { },
  "id_str" : "64502533946736640",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope aww.. adorable!",
  "id" : 64502533946736640,
  "in_reply_to_status_id" : 64502126235222016,
  "created_at" : "2011-05-01 01:32:57 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64502296582701056",
  "text" : "we had a nice dinner out at chinese buffet : )",
  "id" : 64502296582701056,
  "created_at" : "2011-05-01 01:32:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64502092211040256",
  "text" : "the loss of my parents (one passed, other nursing home) has taught me to treasure my inlaws even more",
  "id" : 64502092211040256,
  "created_at" : "2011-05-01 01:31:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64499965870878720",
  "text" : "sending lots o' love to my tweeps \u2665 you keep me going!",
  "id" : 64499965870878720,
  "created_at" : "2011-05-01 01:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64406047678398464",
  "geo" : { },
  "id_str" : "64406630955098112",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld LOL.. agreed! ; )",
  "id" : 64406630955098112,
  "in_reply_to_status_id" : 64406047678398464,
  "created_at" : "2011-04-30 19:11:52 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64392949676523520",
  "geo" : { },
  "id_str" : "64393638477705217",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle yes, you are! take a break from worrying. do something you enjoy, even for 5 mins! ((hugs))",
  "id" : 64393638477705217,
  "in_reply_to_status_id" : 64392949676523520,
  "created_at" : "2011-04-30 18:20:14 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64392535006658561",
  "geo" : { },
  "id_str" : "64393283496976384",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle ((hugs)) I hope you dont know how to read it either...",
  "id" : 64393283496976384,
  "in_reply_to_status_id" : 64392535006658561,
  "created_at" : "2011-04-30 18:18:49 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64389392294363136",
  "geo" : { },
  "id_str" : "64391502943617024",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld ...and nothing is impossible : )",
  "id" : 64391502943617024,
  "in_reply_to_status_id" : 64389392294363136,
  "created_at" : "2011-04-30 18:11:45 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64390075726839808",
  "geo" : { },
  "id_str" : "64391213637316608",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves you sound better : ) have a great Saturday. we're doing chinese buffet later..yay!",
  "id" : 64391213637316608,
  "in_reply_to_status_id" : 64390075726839808,
  "created_at" : "2011-04-30 18:10:36 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AbrahamLIVE Quotes",
      "screen_name" : "MyAbrahamLIVE",
      "indices" : [ 3, 17 ],
      "id_str" : "290585371",
      "id" : 290585371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64379744195592192",
  "text" : "RT @MyAbrahamLIVE: \"The more specifically you're focused on unwanted, the worse you feel. The more specifically you're focused on wanted ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64351689867657216",
    "text" : "\"The more specifically you're focused on unwanted, the worse you feel. The more specifically you're focused on wanted, the better you feel.\"",
    "id" : 64351689867657216,
    "created_at" : "2011-04-30 15:33:33 +0000",
    "user" : {
      "name" : "AbrahamLIVE Quotes",
      "screen_name" : "MyAbrahamLIVE",
      "protected" : false,
      "id_str" : "290585371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1333097529\/Abraham_LIVE_thumbnail_normal.png",
      "id" : 290585371,
      "verified" : false
    }
  },
  "id" : 64379744195592192,
  "created_at" : "2011-04-30 17:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64374501743407104",
  "text" : "RT @taraburner: For as he thinks within himself, so he is...Proverbs 23:7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64374065246371840",
    "text" : "For as he thinks within himself, so he is...Proverbs 23:7",
    "id" : 64374065246371840,
    "created_at" : "2011-04-30 17:02:27 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 64374501743407104,
  "created_at" : "2011-04-30 17:04:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64373420359561216",
  "text" : "RT @JohnCali: ...you have these incurable illnesses, or these unchangeable conditions. But we say, they are only \"unchangeab\u2026 (cont) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64372815041806337",
    "text" : "...you have these incurable illnesses, or these unchangeable conditions. But we say, they are only \"unchangeab\u2026 (cont) http:\/\/deck.ly\/~TVbWt",
    "id" : 64372815041806337,
    "created_at" : "2011-04-30 16:57:29 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 64373420359561216,
  "created_at" : "2011-04-30 16:59:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Boudreau",
      "screen_name" : "threecifer",
      "indices" : [ 3, 14 ],
      "id_str" : "246038746",
      "id" : 246038746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64370765851672576",
  "text" : "RT @threecifer: \"Horror in the Cage\" is SO on. Tic-toc...check out Belinda & Rich's challenge http:\/\/bit.ly\/khWzln  then cheer on your f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64360613966655488",
    "text" : "\"Horror in the Cage\" is SO on. Tic-toc...check out Belinda & Rich's challenge http:\/\/bit.ly\/khWzln  then cheer on your fave horror writer.",
    "id" : 64360613966655488,
    "created_at" : "2011-04-30 16:09:00 +0000",
    "user" : {
      "name" : "Al Boudreau",
      "screen_name" : "threecifer",
      "protected" : false,
      "id_str" : "246038746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1455997842\/Al_Work__2__normal.jpg",
      "id" : 246038746,
      "verified" : false
    }
  },
  "id" : 64370765851672576,
  "created_at" : "2011-04-30 16:49:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "indices" : [ 3, 13 ],
      "id_str" : "23812887",
      "id" : 23812887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64338024254808064",
  "text" : "RT @LizBorino: Not everyone will like you, or me. That's ok. The people that matter will.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64301231316799488",
    "text" : "Not everyone will like you, or me. That's ok. The people that matter will.",
    "id" : 64301231316799488,
    "created_at" : "2011-04-30 12:13:02 +0000",
    "user" : {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "protected" : false,
      "id_str" : "23812887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489066924773371905\/AJv5YOCl_normal.jpeg",
      "id" : 23812887,
      "verified" : false
    }
  },
  "id" : 64338024254808064,
  "created_at" : "2011-04-30 14:39:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "indices" : [ 3, 17 ],
      "id_str" : "8833312",
      "id" : 8833312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64337459445628928",
  "text" : "RT @MicheleKnight: http:\/\/bit.ly\/k6lMug Science can soon erase traumatic memories",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64308010654240768",
    "text" : "http:\/\/bit.ly\/k6lMug Science can soon erase traumatic memories",
    "id" : 64308010654240768,
    "created_at" : "2011-04-30 12:39:59 +0000",
    "user" : {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "protected" : false,
      "id_str" : "8833312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616164060292337664\/DM_Io58r_normal.jpg",
      "id" : 8833312,
      "verified" : false
    }
  },
  "id" : 64337459445628928,
  "created_at" : "2011-04-30 14:37:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 3, 10 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64337306827505664",
  "text" : "RT @SsmDad: \"Emancipate yourselves from mental slavery, none but ourselves can free our minds.\" - Bob Marley",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64308095093964800",
    "text" : "\"Emancipate yourselves from mental slavery, none but ourselves can free our minds.\" - Bob Marley",
    "id" : 64308095093964800,
    "created_at" : "2011-04-30 12:40:19 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "protected" : false,
      "id_str" : "122393631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649760376880525312\/faJeQ4K3_normal.jpg",
      "id" : 122393631,
      "verified" : false
    }
  },
  "id" : 64337306827505664,
  "created_at" : "2011-04-30 14:36:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "indices" : [ 3, 18 ],
      "id_str" : "29574025",
      "id" : 29574025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64337136136097792",
  "text" : "RT @KindleObsessed: ATTN AUTHORS:\n\nIf u have a free ebook you would like listed on this weeks Freebie post please send me the info.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64310853872267264",
    "text" : "ATTN AUTHORS:\n\nIf u have a free ebook you would like listed on this weeks Freebie post please send me the info.",
    "id" : 64310853872267264,
    "created_at" : "2011-04-30 12:51:17 +0000",
    "user" : {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "protected" : false,
      "id_str" : "29574025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526178477213380608\/oLhvSdVV_normal.jpeg",
      "id" : 29574025,
      "verified" : false
    }
  },
  "id" : 64337136136097792,
  "created_at" : "2011-04-30 14:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64336523474112512",
  "text" : "RT @stevetheseeker: When you're desire for truth is greater than what you want it to be, then there's no stopping your spiritual growth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64314120899534848",
    "text" : "When you're desire for truth is greater than what you want it to be, then there's no stopping your spiritual growth.",
    "id" : 64314120899534848,
    "created_at" : "2011-04-30 13:04:15 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 64336523474112512,
  "created_at" : "2011-04-30 14:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "indices" : [ 3, 9 ],
      "id_str" : "9930742",
      "id" : 9930742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64336378040815616",
  "text" : "RT @sween: My morning wood just met my wife's morning wouldn't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64316251962486784",
    "text" : "My morning wood just met my wife's morning wouldn't.",
    "id" : 64316251962486784,
    "created_at" : "2011-04-30 13:12:44 +0000",
    "user" : {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "protected" : false,
      "id_str" : "9930742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576723767402983424\/xLGkIHkA_normal.jpeg",
      "id" : 9930742,
      "verified" : true
    }
  },
  "id" : 64336378040815616,
  "created_at" : "2011-04-30 14:32:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ryan",
      "screen_name" : "ChrisDelorey",
      "indices" : [ 3, 16 ],
      "id_str" : "190100756",
      "id" : 190100756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64123360052916224",
  "text" : "RT @chrisdelorey: Hate is the absence of love -- life without light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64120048377266176",
    "text" : "Hate is the absence of love -- life without light.",
    "id" : 64120048377266176,
    "created_at" : "2011-04-30 00:13:05 +0000",
    "user" : {
      "name" : "Christine DeLorey",
      "screen_name" : "the9numbers",
      "protected" : false,
      "id_str" : "24301880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1288489336\/ChristineDeLorey_normal.jpg",
      "id" : 24301880,
      "verified" : false
    }
  },
  "id" : 64123360052916224,
  "created_at" : "2011-04-30 00:26:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Gifts of Debbie Ford",
      "screen_name" : "Debbie_Ford",
      "indices" : [ 17, 29 ],
      "id_str" : "22986272",
      "id" : 22986272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64123237101084672",
  "text" : "RT @JohnCali: RT @Debbie_Ford: Past hurts and resentments cloud your perception.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gifts of Debbie Ford",
        "screen_name" : "Debbie_Ford",
        "indices" : [ 3, 15 ],
        "id_str" : "22986272",
        "id" : 22986272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64120717532344322",
    "text" : "RT @Debbie_Ford: Past hurts and resentments cloud your perception.",
    "id" : 64120717532344322,
    "created_at" : "2011-04-30 00:15:45 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 64123237101084672,
  "created_at" : "2011-04-30 00:25:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 0, 11 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64118774223216640",
  "geo" : { },
  "id_str" : "64120043113418752",
  "in_reply_to_user_id" : 8449382,
  "text" : "@quantafire wasnt interested in watching it but then I liked it.",
  "id" : 64120043113418752,
  "in_reply_to_status_id" : 64118774223216640,
  "created_at" : "2011-04-30 00:13:04 +0000",
  "in_reply_to_screen_name" : "quantafire",
  "in_reply_to_user_id_str" : "8449382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64114766205034496",
  "geo" : { },
  "id_str" : "64118601451442176",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 ((hugs))",
  "id" : 64118601451442176,
  "in_reply_to_status_id" : 64114766205034496,
  "created_at" : "2011-04-30 00:07:20 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "helen",
      "screen_name" : "liberalchik",
      "indices" : [ 3, 15 ],
      "id_str" : "31291086",
      "id" : 31291086
    }, {
      "name" : "Steve Weinstein",
      "screen_name" : "steveweinstein",
      "indices" : [ 98, 113 ],
      "id_str" : "47728859",
      "id" : 47728859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64117772510175232",
  "text" : "RT @liberalchik: i am retweeting my own tweet because you MUST read this. http:\/\/bit.ly\/iTCUJ0 by @steveweinstein. excellent steve.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Weinstein",
        "screen_name" : "steveweinstein",
        "indices" : [ 81, 96 ],
        "id_str" : "47728859",
        "id" : 47728859
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64113932410957824",
    "text" : "i am retweeting my own tweet because you MUST read this. http:\/\/bit.ly\/iTCUJ0 by @steveweinstein. excellent steve.",
    "id" : 64113932410957824,
    "created_at" : "2011-04-29 23:48:47 +0000",
    "user" : {
      "name" : "helen",
      "screen_name" : "liberalchik",
      "protected" : false,
      "id_str" : "31291086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3532686694\/65a1199fd9345bbb541bc1817a4505bd_normal.jpeg",
      "id" : 31291086,
      "verified" : false
    }
  },
  "id" : 64117772510175232,
  "created_at" : "2011-04-30 00:04:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64104290263904256",
  "text" : "the kitties don't trust me & I find that very disconcerting. sigh.",
  "id" : 64104290263904256,
  "created_at" : "2011-04-29 23:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64094960198238208",
  "text" : "\"Life is just a very long horror movie.. we all die in the end.\" - me",
  "id" : 64094960198238208,
  "created_at" : "2011-04-29 22:33:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64086859717947392",
  "geo" : { },
  "id_str" : "64087447528681472",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth oh I'd be screaming w glee, too..hehe. Love it!",
  "id" : 64087447528681472,
  "in_reply_to_status_id" : 64086859717947392,
  "created_at" : "2011-04-29 22:03:32 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64087112047271936",
  "text" : "@Skandhasattva we have old tall pine trees on property here. oh, if they could talk.",
  "id" : 64087112047271936,
  "created_at" : "2011-04-29 22:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64059015222661120",
  "text" : "@Skandhasattva cherry blossom? lovely!",
  "id" : 64059015222661120,
  "created_at" : "2011-04-29 20:10:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64035913327587328",
  "text" : "Cool lil machine - Apple Newton Features and Software http:\/\/bit.ly\/mgC7Hj",
  "id" : 64035913327587328,
  "created_at" : "2011-04-29 18:38:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 0, 10 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63997416503906304",
  "geo" : { },
  "id_str" : "64001944942952449",
  "in_reply_to_user_id" : 82447359,
  "text" : "@ScottBaio glad she's on the mend. hope she continues w no further complications ((hugs))",
  "id" : 64001944942952449,
  "in_reply_to_status_id" : 63997416503906304,
  "created_at" : "2011-04-29 16:23:47 +0000",
  "in_reply_to_screen_name" : "ScottBaio",
  "in_reply_to_user_id_str" : "82447359",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin",
      "screen_name" : "infpBlog",
      "indices" : [ 3, 12 ],
      "id_str" : "48772319",
      "id" : 48772319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63984776377409537",
  "text" : "RT @infpBlog: I wonder how many opportunities I miss just because I have a habit of doing something else.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63983330311409664",
    "text" : "I wonder how many opportunities I miss just because I have a habit of doing something else.",
    "id" : 63983330311409664,
    "created_at" : "2011-04-29 15:09:49 +0000",
    "user" : {
      "name" : "Corin",
      "screen_name" : "infpBlog",
      "protected" : false,
      "id_str" : "48772319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1423053271\/avatar4768_3.gif_normal.jpg",
      "id" : 48772319,
      "verified" : false
    }
  },
  "id" : 63984776377409537,
  "created_at" : "2011-04-29 15:15:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin",
      "screen_name" : "infpBlog",
      "indices" : [ 3, 12 ],
      "id_str" : "48772319",
      "id" : 48772319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63984758362882049",
  "text" : "RT @infpBlog: At work, I missed a parking space at the front door that I didn't see because I'm so use to parking in the spaces next to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63983046713548800",
    "text" : "At work, I missed a parking space at the front door that I didn't see because I'm so use to parking in the spaces next to the front door.",
    "id" : 63983046713548800,
    "created_at" : "2011-04-29 15:08:41 +0000",
    "user" : {
      "name" : "Corin",
      "screen_name" : "infpBlog",
      "protected" : false,
      "id_str" : "48772319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1423053271\/avatar4768_3.gif_normal.jpg",
      "id" : 48772319,
      "verified" : false
    }
  },
  "id" : 63984758362882049,
  "created_at" : "2011-04-29 15:15:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Shurley",
      "screen_name" : "ThatNeilGuy",
      "indices" : [ 3, 15 ],
      "id_str" : "24069679",
      "id" : 24069679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63971950946553857",
  "text" : "RT @ThatNeilGuy: Good news for those who take the bible seriously but not literally: 'Jesus for the Non-Religious' http:\/\/amzn.to\/lZx87u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FridayListens",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63969909033537536",
    "text" : "Good news for those who take the bible seriously but not literally: 'Jesus for the Non-Religious' http:\/\/amzn.to\/lZx87u #FridayListens",
    "id" : 63969909033537536,
    "created_at" : "2011-04-29 14:16:29 +0000",
    "user" : {
      "name" : "Neil Shurley",
      "screen_name" : "ThatNeilGuy",
      "protected" : false,
      "id_str" : "24069679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795398718346432512\/ApzCpPHh_normal.jpg",
      "id" : 24069679,
      "verified" : true
    }
  },
  "id" : 63971950946553857,
  "created_at" : "2011-04-29 14:24:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63969062144843776",
  "text" : "RT @bunnybuddhism: The wise bunny knows to sit and breathe if the world begins to crumble around him.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63962680179961856",
    "text" : "The wise bunny knows to sit and breathe if the world begins to crumble around him.",
    "id" : 63962680179961856,
    "created_at" : "2011-04-29 13:47:45 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 63969062144843776,
  "created_at" : "2011-04-29 14:13:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63967854818623488",
  "geo" : { },
  "id_str" : "63968325675397120",
  "in_reply_to_user_id" : 18219084,
  "text" : "@byoung210 I'm going to miss him! ((sob))",
  "id" : 63968325675397120,
  "in_reply_to_status_id" : 63967854818623488,
  "created_at" : "2011-04-29 14:10:11 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheWitchWriter",
      "screen_name" : "TheWitchWriter",
      "indices" : [ 3, 18 ],
      "id_str" : "16734047",
      "id" : 16734047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63944896461012992",
  "text" : "RT @TheWitchWriter: The Universe really needed today, the outpouring of love and happiness and joy coming from the world for this occasion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63944198642085888",
    "text" : "The Universe really needed today, the outpouring of love and happiness and joy coming from the world for this occasion.",
    "id" : 63944198642085888,
    "created_at" : "2011-04-29 12:34:19 +0000",
    "user" : {
      "name" : "TheWitchWriter",
      "screen_name" : "TheWitchWriter",
      "protected" : false,
      "id_str" : "16734047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2256545512\/blue_normal.jpg",
      "id" : 16734047,
      "verified" : false
    }
  },
  "id" : 63944896461012992,
  "created_at" : "2011-04-29 12:37:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63944700566048769",
  "text" : "@Skandhasattva sorry to hear you're not feeling well. hope testing brings \"easy to take care of\" answer. ((hugs))",
  "id" : 63944700566048769,
  "created_at" : "2011-04-29 12:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63942605280514049",
  "text" : "RT @LukeRomyn: Everyone's good at something. Unfortunately for some that just means they're good at doing things badly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63924085440253952",
    "text" : "Everyone's good at something. Unfortunately for some that just means they're good at doing things badly.",
    "id" : 63924085440253952,
    "created_at" : "2011-04-29 11:14:24 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 63942605280514049,
  "created_at" : "2011-04-29 12:27:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VaBeachQuilter",
      "screen_name" : "vabeachquilter",
      "indices" : [ 22, 37 ],
      "id_str" : "23753093",
      "id" : 23753093
    }, {
      "name" : "Speedy Bankroll",
      "screen_name" : "earthlifeinst",
      "indices" : [ 42, 56 ],
      "id_str" : "2162266735",
      "id" : 2162266735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63633220184457217",
  "text" : "RT @EarthLifeShop: RT @vabeachquilter: RT @earthlifeinst: Moose with Me Photograph by Dagmar Magdalena Ceki - http:\/\/bit.ly\/e6Ro8c #moos ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VaBeachQuilter",
        "screen_name" : "vabeachquilter",
        "indices" : [ 3, 18 ],
        "id_str" : "23753093",
        "id" : 23753093
      }, {
        "name" : "Speedy Bankroll",
        "screen_name" : "earthlifeinst",
        "indices" : [ 23, 37 ],
        "id_str" : "2162266735",
        "id" : 2162266735
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moose",
        "indices" : [ 112, 118 ]
      }, {
        "text" : "sweden",
        "indices" : [ 119, 126 ]
      }, {
        "text" : "sverige",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63630410692820993",
    "text" : "RT @vabeachquilter: RT @earthlifeinst: Moose with Me Photograph by Dagmar Magdalena Ceki - http:\/\/bit.ly\/e6Ro8c #moose #sweden #sverige",
    "id" : 63630410692820993,
    "created_at" : "2011-04-28 15:47:26 +0000",
    "user" : {
      "name" : "Dagmar Magdalena",
      "screen_name" : "BatyaHavDesign",
      "protected" : false,
      "id_str" : "25688058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602426519487647744\/kogV47_M_normal.jpg",
      "id" : 25688058,
      "verified" : false
    }
  },
  "id" : 63633220184457217,
  "created_at" : "2011-04-28 15:58:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63331597897826304",
  "text" : "RT @BrianMerritt: Find your complicity in the very evil you abhor.  William Sloan Coffin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63327747581288448",
    "text" : "Find your complicity in the very evil you abhor.  William Sloan Coffin",
    "id" : 63327747581288448,
    "created_at" : "2011-04-27 19:44:46 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 63331597897826304,
  "created_at" : "2011-04-27 20:00:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63313094419562496",
  "text" : "RT @thesexyatheist: go for the six pack, http:\/\/bit.ly\/dkjzBF stay for the content.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63309059633332224",
    "text" : "go for the six pack, http:\/\/bit.ly\/dkjzBF stay for the content.",
    "id" : 63309059633332224,
    "created_at" : "2011-04-27 18:30:30 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 63313094419562496,
  "created_at" : "2011-04-27 18:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63297119569723392",
  "text" : "weird sound outside. like giant insects from horror movie o-O",
  "id" : 63297119569723392,
  "created_at" : "2011-04-27 17:43:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juliet Ulman",
      "screen_name" : "papertyger",
      "indices" : [ 3, 14 ],
      "id_str" : "18078425",
      "id" : 18078425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63296738827583488",
  "text" : "RT @papertyger: Cats. Where they do not belong. http:\/\/getoutoftherecat.tumblr.com\/ Get out of there, cats!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63287372263079938",
    "text" : "Cats. Where they do not belong. http:\/\/getoutoftherecat.tumblr.com\/ Get out of there, cats!",
    "id" : 63287372263079938,
    "created_at" : "2011-04-27 17:04:20 +0000",
    "user" : {
      "name" : "Juliet Ulman",
      "screen_name" : "papertyger",
      "protected" : false,
      "id_str" : "18078425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1116435054\/tiger-little_normal.jpg",
      "id" : 18078425,
      "verified" : false
    }
  },
  "id" : 63296738827583488,
  "created_at" : "2011-04-27 17:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Bergeron",
      "screen_name" : "Tom_Bergeron",
      "indices" : [ 3, 16 ],
      "id_str" : "30333898",
      "id" : 30333898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63253514280906752",
  "text" : "RT @Tom_Bergeron: Obama has released his birth certificate.  Trump now trying to prove Hawaii isn't really a state.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63248244100182016",
    "text" : "Obama has released his birth certificate.  Trump now trying to prove Hawaii isn't really a state.",
    "id" : 63248244100182016,
    "created_at" : "2011-04-27 14:28:51 +0000",
    "user" : {
      "name" : "Tom Bergeron",
      "screen_name" : "Tom_Bergeron",
      "protected" : false,
      "id_str" : "30333898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772777851590479872\/hnR_YtB8_normal.jpg",
      "id" : 30333898,
      "verified" : true
    }
  },
  "id" : 63253514280906752,
  "created_at" : "2011-04-27 14:49:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "Rocky_Mountain_National_Park_CO",
      "indices" : [ 90, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63220049107881984",
  "text" : "RT @wildobs: Today's wildlife encounter: Moose http:\/\/wildobs.com\/wo\/8428 #EOTD #wildlife #Rocky_Mountain_National_Park_CO Bull Moose",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 61, 66 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "Rocky_Mountain_National_Park_CO",
        "indices" : [ 77, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63212131750903808",
    "text" : "Today's wildlife encounter: Moose http:\/\/wildobs.com\/wo\/8428 #EOTD #wildlife #Rocky_Mountain_National_Park_CO Bull Moose",
    "id" : 63212131750903808,
    "created_at" : "2011-04-27 12:05:21 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 63220049107881984,
  "created_at" : "2011-04-27 12:36:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vermont",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63052169028435968",
  "text" : "RT @SangyeH: Tenet of #Vermont's single-payer health care: \"Health care is a right, not a privilege. \"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vermont",
        "indices" : [ 9, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63051190484742144",
    "text" : "Tenet of #Vermont's single-payer health care: \"Health care is a right, not a privilege. \"",
    "id" : 63051190484742144,
    "created_at" : "2011-04-27 01:25:49 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 63052169028435968,
  "created_at" : "2011-04-27 01:29:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63046339335962624",
  "geo" : { },
  "id_str" : "63047968097435649",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 you tell yr mom to take her abx & get better. ((hugs)) glad caught early!",
  "id" : 63047968097435649,
  "in_reply_to_status_id" : 63046339335962624,
  "created_at" : "2011-04-27 01:13:01 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip DeFranco",
      "screen_name" : "PhillyD",
      "indices" : [ 3, 11 ],
      "id_str" : "6351572",
      "id" : 6351572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63046733650857984",
  "text" : "RT @PhillyD: Sometimes when I'm about to feel sorry for myself I remember that everyone else is fucked up in the head too.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63045010458820608",
    "text" : "Sometimes when I'm about to feel sorry for myself I remember that everyone else is fucked up in the head too.",
    "id" : 63045010458820608,
    "created_at" : "2011-04-27 01:01:16 +0000",
    "user" : {
      "name" : "Philip DeFranco",
      "screen_name" : "PhillyD",
      "protected" : false,
      "id_str" : "6351572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798910236727779328\/LxbBgqs9_normal.jpg",
      "id" : 6351572,
      "verified" : true
    }
  },
  "id" : 63046733650857984,
  "created_at" : "2011-04-27 01:08:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63037212207493120",
  "geo" : { },
  "id_str" : "63037776731447296",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle you are awesome! \u2665",
  "id" : 63037776731447296,
  "in_reply_to_status_id" : 63037212207493120,
  "created_at" : "2011-04-27 00:32:31 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S.A. Barton Writes!",
      "screen_name" : "Tao23",
      "indices" : [ 3, 9 ],
      "id_str" : "16083327",
      "id" : 16083327
    }, {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 14, 26 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63035858290348034",
  "text" : "RT @Tao23: RT @GeorgeTakei: In case you missed it : TN bill will prevent use of word \"gay\" by teachers. I'm lending my name: \"It's okay  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Takei",
        "screen_name" : "GeorgeTakei",
        "indices" : [ 3, 15 ],
        "id_str" : "237845487",
        "id" : 237845487
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63033203367223296",
    "text" : "RT @GeorgeTakei: In case you missed it : TN bill will prevent use of word \"gay\" by teachers. I'm lending my name: \"It's okay to be Takei.\"",
    "id" : 63033203367223296,
    "created_at" : "2011-04-27 00:14:21 +0000",
    "user" : {
      "name" : "S.A. Barton Writes!",
      "screen_name" : "Tao23",
      "protected" : false,
      "id_str" : "16083327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791089490731425793\/2zMkkgXV_normal.jpg",
      "id" : 16083327,
      "verified" : false
    }
  },
  "id" : 63035858290348034,
  "created_at" : "2011-04-27 00:24:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thriller",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "authors",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63029989905403905",
  "text" : "RT @ThrillersRockT: #Thriller #authors out there interested in helping with the ThrillersRockTwitter stream\/blog\/possible radio show? DM me!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thriller",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "authors",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63029444528455680",
    "text" : "#Thriller #authors out there interested in helping with the ThrillersRockTwitter stream\/blog\/possible radio show? DM me!",
    "id" : 63029444528455680,
    "created_at" : "2011-04-26 23:59:25 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 63029989905403905,
  "created_at" : "2011-04-27 00:01:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63023907564830720",
  "geo" : { },
  "id_str" : "63027514125189121",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves hey, what's going on? did you take your blog down?",
  "id" : 63027514125189121,
  "in_reply_to_status_id" : 63023907564830720,
  "created_at" : "2011-04-26 23:51:45 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/17ASECh",
      "expanded_url" : "http:\/\/www.mediabistro.com\/ebooknewser\/mobihandler-a-library-for-kindle-ebooks_b9649",
      "display_url" : "mediabistro.com\/ebooknewser\/mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "62955174393683968",
  "text" : "RT @thDigitalReader: MobiHandler \u2013 a Library For Kindle eBooks http:\/\/t.co\/17ASECh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 61 ],
        "url" : "http:\/\/t.co\/17ASECh",
        "expanded_url" : "http:\/\/www.mediabistro.com\/ebooknewser\/mobihandler-a-library-for-kindle-ebooks_b9649",
        "display_url" : "mediabistro.com\/ebooknewser\/mo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "62941529198702592",
    "text" : "MobiHandler \u2013 a Library For Kindle eBooks http:\/\/t.co\/17ASECh",
    "id" : 62941529198702592,
    "created_at" : "2011-04-26 18:10:04 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 62955174393683968,
  "created_at" : "2011-04-26 19:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 3, 16 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62937612280803329",
  "text" : "RT @ralphmacchio: Glad all enjoyed the wax-on homage in last nights Paso. If u get me 2 the finale... We'll break out the most famous mo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62920141658271745",
    "text" : "Glad all enjoyed the wax-on homage in last nights Paso. If u get me 2 the finale... We'll break out the most famous move from that film :)",
    "id" : 62920141658271745,
    "created_at" : "2011-04-26 16:45:05 +0000",
    "user" : {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "protected" : false,
      "id_str" : "44163738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535851580667346944\/DCmtbKbq_normal.jpeg",
      "id" : 44163738,
      "verified" : true
    }
  },
  "id" : 62937612280803329,
  "created_at" : "2011-04-26 17:54:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Stacy",
      "screen_name" : "lindastacy",
      "indices" : [ 3, 14 ],
      "id_str" : "14333861",
      "id" : 14333861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62937286383382528",
  "text" : "RT @lindastacy: Silly robin build a nest on a chair on the deck. Now what do I do? Leave it, move it, sweep it away? http:\/\/yfrog.com\/gy ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62921499228651520",
    "text" : "Silly robin build a nest on a chair on the deck. Now what do I do? Leave it, move it, sweep it away? http:\/\/yfrog.com\/gyflfuaj",
    "id" : 62921499228651520,
    "created_at" : "2011-04-26 16:50:29 +0000",
    "user" : {
      "name" : "Linda Stacy",
      "screen_name" : "lindastacy",
      "protected" : false,
      "id_str" : "14333861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52562805\/eyes_normal.jpg",
      "id" : 14333861,
      "verified" : false
    }
  },
  "id" : 62937286383382528,
  "created_at" : "2011-04-26 17:53:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62925623307419648",
  "geo" : { },
  "id_str" : "62934849601814528",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal ((hugs))",
  "id" : 62934849601814528,
  "in_reply_to_status_id" : 62925623307419648,
  "created_at" : "2011-04-26 17:43:32 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62912303946940416",
  "text" : "RT @Seeds4Parents: Give a child a toy and they\u2019ll have fun for a while. Teach a child to allow imagination and they\u2019ll have fun for a li ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62908130165661696",
    "text" : "Give a child a toy and they\u2019ll have fun for a while. Teach a child to allow imagination and they\u2019ll have fun for a lifetime",
    "id" : 62908130165661696,
    "created_at" : "2011-04-26 15:57:21 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 62912303946940416,
  "created_at" : "2011-04-26 16:13:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott_hurst",
      "screen_name" : "scott_hurst",
      "indices" : [ 3, 15 ],
      "id_str" : "15971968",
      "id" : 15971968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62912269889175552",
  "text" : "RT @scott_hurst: I notice that gay adults were predominately raised in hetero households and in hetero culture. Somehow they didn't catc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62900539125538816",
    "text" : "I notice that gay adults were predominately raised in hetero households and in hetero culture. Somehow they didn't catch the hetero.",
    "id" : 62900539125538816,
    "created_at" : "2011-04-26 15:27:11 +0000",
    "user" : {
      "name" : "scott_hurst",
      "screen_name" : "scott_hurst",
      "protected" : false,
      "id_str" : "15971968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836974221\/avatar_normal.png",
      "id" : 15971968,
      "verified" : false
    }
  },
  "id" : 62912269889175552,
  "created_at" : "2011-04-26 16:13:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 0, 9 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62909720326979584",
  "geo" : { },
  "id_str" : "62912001608921088",
  "in_reply_to_user_id" : 46375814,
  "text" : "@BayBitch : ( I hope you can get some",
  "id" : 62912001608921088,
  "in_reply_to_status_id" : 62909720326979584,
  "created_at" : "2011-04-26 16:12:44 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62900043698544640",
  "text" : "RT @Moonrust: Baby Geese Swimming in Dog's Water Bowl http:\/\/bit.ly\/gDRvZ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62896147232071680",
    "text" : "Baby Geese Swimming in Dog's Water Bowl http:\/\/bit.ly\/gDRvZ6",
    "id" : 62896147232071680,
    "created_at" : "2011-04-26 15:09:44 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 62900043698544640,
  "created_at" : "2011-04-26 15:25:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rkclibrary",
      "screen_name" : "rkclibrary",
      "indices" : [ 3, 14 ],
      "id_str" : "15390085",
      "id" : 15390085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62864448465022976",
  "text" : "RT @rkclibrary: dotEPUB: dotEPUB is software in the cloud that allows you to convert any webpage into an e-book. http:\/\/dotepub.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62853692340178945",
    "text" : "dotEPUB: dotEPUB is software in the cloud that allows you to convert any webpage into an e-book. http:\/\/dotepub.com\/",
    "id" : 62853692340178945,
    "created_at" : "2011-04-26 12:21:02 +0000",
    "user" : {
      "name" : "rkclibrary",
      "screen_name" : "rkclibrary",
      "protected" : false,
      "id_str" : "15390085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1576539075\/RKClibrary_normal.jpg",
      "id" : 15390085,
      "verified" : false
    }
  },
  "id" : 62864448465022976,
  "created_at" : "2011-04-26 13:03:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 3, 16 ],
      "id_str" : "88882302",
      "id" : 88882302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62863007402831872",
  "text" : "RT @TweetTheBook: Want your thriller posted as \"The Thrill of the Week\"? Free ad at The Writing Bomb. http:\/\/thewritingbomb.blogspot.com ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/futuretweets.com\" rel=\"nofollow\"\u003E Futuretweets V2 - old\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thrillers",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62860453772136448",
    "text" : "Want your thriller posted as \"The Thrill of the Week\"? Free ad at The Writing Bomb. http:\/\/thewritingbomb.blogspot.com\/ #thrillers",
    "id" : 62860453772136448,
    "created_at" : "2011-04-26 12:47:54 +0000",
    "user" : {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "protected" : false,
      "id_str" : "88882302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723538520174780416\/myOVJeXG_normal.jpg",
      "id" : 88882302,
      "verified" : false
    }
  },
  "id" : 62863007402831872,
  "created_at" : "2011-04-26 12:58:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 98, 113 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62845980575408129",
  "text" : "RT @BrianMerritt: How I Paid Only 1% of My Income in Federal Income Tax http:\/\/huff.to\/hnyBtx via @huffingtonpost",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 80, 95 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62838609451040769",
    "text" : "How I Paid Only 1% of My Income in Federal Income Tax http:\/\/huff.to\/hnyBtx via @huffingtonpost",
    "id" : 62838609451040769,
    "created_at" : "2011-04-26 11:21:06 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 62845980575408129,
  "created_at" : "2011-04-26 11:50:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62675874675310592",
  "text" : "Did you know...? In Kindle store: under Product Details, find \"tell us about a lower price\" & submit url or store",
  "id" : 62675874675310592,
  "created_at" : "2011-04-26 00:34:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62623952509468672",
  "text" : "RT @JeremyCShipp: Authors: send me a link to your Amazon book(s) and I'll click your tag boxes. I'd love for you to click mine: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62623474602090498",
    "text" : "Authors: send me a link to your Amazon book(s) and I'll click your tag boxes. I'd love for you to click mine: http:\/\/tinyurl.com\/mrswsx",
    "id" : 62623474602090498,
    "created_at" : "2011-04-25 21:06:14 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 62623952509468672,
  "created_at" : "2011-04-25 21:08:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "b",
      "screen_name" : "byepluto",
      "indices" : [ 13, 22 ],
      "id_str" : "992780209",
      "id" : 992780209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62619601472733184",
  "geo" : { },
  "id_str" : "62621228883648514",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem @byepluto omgness.. that is good! lol",
  "id" : 62621228883648514,
  "in_reply_to_status_id" : 62619601472733184,
  "created_at" : "2011-04-25 20:57:19 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "b",
      "screen_name" : "byepluto",
      "indices" : [ 20, 29 ],
      "id_str" : "992780209",
      "id" : 992780209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62621041578614784",
  "text" : "RT @mindymayhem: RT @byepluto: This made me chuckle: Tennessee\u2019s \u2018Don\u2019t say gay\u2019 bill doesn\u2019t go far enough by Alexandra Petri http:\/\/wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "b",
        "screen_name" : "byepluto",
        "indices" : [ 3, 12 ],
        "id_str" : "992780209",
        "id" : 992780209
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62619601472733184",
    "text" : "RT @byepluto: This made me chuckle: Tennessee\u2019s \u2018Don\u2019t say gay\u2019 bill doesn\u2019t go far enough by Alexandra Petri http:\/\/wapo.st\/gbnEiF",
    "id" : 62619601472733184,
    "created_at" : "2011-04-25 20:50:51 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 62621041578614784,
  "created_at" : "2011-04-25 20:56:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62617054724886528",
  "text" : "http:\/\/psychcentral.com\/personality-patterns\/ My Results: http:\/\/on.fb.me\/e6bTf7",
  "id" : 62617054724886528,
  "created_at" : "2011-04-25 20:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62589740444168192",
  "text" : "categories and tags confuse me.",
  "id" : 62589740444168192,
  "created_at" : "2011-04-25 18:52:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "indices" : [ 3, 16 ],
      "id_str" : "15175368",
      "id" : 15175368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62589412860637184",
  "text" : "RT @theofficenbc: Send a Dundie! Choose from Michael's categories or make up your own, then add your photo and send to a friend! http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theoffice",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62588328419139585",
    "text" : "Send a Dundie! Choose from Michael's categories or make up your own, then add your photo and send to a friend! http:\/\/nbc.co\/qt #theoffice",
    "id" : 62588328419139585,
    "created_at" : "2011-04-25 18:46:34 +0000",
    "user" : {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "protected" : false,
      "id_str" : "15175368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3672312614\/17217191debc391b060a6798b6c2ad10_normal.jpeg",
      "id" : 15175368,
      "verified" : true
    }
  },
  "id" : 62589412860637184,
  "created_at" : "2011-04-25 18:50:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62587189187461121",
  "text" : "the man is trying to kill me. he sprayed stuff all over. cough, cough...",
  "id" : 62587189187461121,
  "created_at" : "2011-04-25 18:42:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62582979280642048",
  "geo" : { },
  "id_str" : "62583939491041280",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope im so sorry!",
  "id" : 62583939491041280,
  "in_reply_to_status_id" : 62582979280642048,
  "created_at" : "2011-04-25 18:29:08 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62526964862423040",
  "text" : "@Tideliar happy birthday : )",
  "id" : 62526964862423040,
  "created_at" : "2011-04-25 14:42:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "animalrescue",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62525074510581760",
  "text" : "$70K in pet products & supplies for your fav shelter? http:\/\/bit.ly\/eEcRQQ #animalrescue",
  "id" : 62525074510581760,
  "created_at" : "2011-04-25 14:35:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62501759020576768",
  "geo" : { },
  "id_str" : "62516591593660416",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope ((hugs))",
  "id" : 62516591593660416,
  "in_reply_to_status_id" : 62501759020576768,
  "created_at" : "2011-04-25 14:01:31 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62514612767162368",
  "text" : "RT @hauntedcomputer: isn't it funny how issues need a \"vs.\"? Dem vs. GOP, Kindle vs. Nook, indie vs. trad. No wonder people get so mad a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62510362204979200",
    "text" : "isn't it funny how issues need a \"vs.\"? Dem vs. GOP, Kindle vs. Nook, indie vs. trad. No wonder people get so mad about little things",
    "id" : 62510362204979200,
    "created_at" : "2011-04-25 13:36:46 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 62514612767162368,
  "created_at" : "2011-04-25 13:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62333696010756096",
  "geo" : { },
  "id_str" : "62335280736239616",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 lol : )",
  "id" : 62335280736239616,
  "in_reply_to_status_id" : 62333696010756096,
  "created_at" : "2011-04-25 02:01:03 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62326799216033792",
  "text" : "I so want a pet dragon.",
  "id" : 62326799216033792,
  "created_at" : "2011-04-25 01:27:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "indices" : [ 3, 13 ],
      "id_str" : "22380908",
      "id" : 22380908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62319225829728257",
  "text" : "RT @BethLayne: If you don't want to bring more of the same into your life, don't give the same your focus. Whatever you are focusing on  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "62315489602449408",
    "text" : "If you don't want to bring more of the same into your life, don't give the same your focus. Whatever you are focusing on continues.",
    "id" : 62315489602449408,
    "created_at" : "2011-04-25 00:42:25 +0000",
    "user" : {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "protected" : false,
      "id_str" : "22380908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796841124904116224\/6H0GAfoZ_normal.jpg",
      "id" : 22380908,
      "verified" : false
    }
  },
  "id" : 62319225829728257,
  "created_at" : "2011-04-25 00:57:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62317167022055425",
  "text" : "what an interesting day...",
  "id" : 62317167022055425,
  "created_at" : "2011-04-25 00:49:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62171377649725440",
  "text" : "3B??? &gt;&gt; Obama Administration req'd $3 billion in Foreign Military Financing for Israel for the fiscal year 2011. http:\/\/bit.ly\/ieIINr",
  "id" : 62171377649725440,
  "created_at" : "2011-04-24 15:09:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Adam R. B. Jack",
      "screen_name" : "adam_jack",
      "indices" : [ 70, 80 ],
      "id_str" : "11798892",
      "id" : 11798892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "Coal_Creek_Canyon_CO",
      "indices" : [ 97, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61949637149458432",
  "text" : "RT @wildobs: For the late crowd: Turkey http:\/\/wildobs.com\/wo\/8309 by @adam_jack #EOTD #wildlife #Coal_Creek_Canyon_CO Turkey on the Roof",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam R. B. Jack",
        "screen_name" : "adam_jack",
        "indices" : [ 57, 67 ],
        "id_str" : "11798892",
        "id" : 11798892
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 68, 73 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 74, 83 ]
      }, {
        "text" : "Coal_Creek_Canyon_CO",
        "indices" : [ 84, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61943762762481664",
    "text" : "For the late crowd: Turkey http:\/\/wildobs.com\/wo\/8309 by @adam_jack #EOTD #wildlife #Coal_Creek_Canyon_CO Turkey on the Roof",
    "id" : 61943762762481664,
    "created_at" : "2011-04-24 00:05:18 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 61949637149458432,
  "created_at" : "2011-04-24 00:28:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61945760211673088",
  "geo" : { },
  "id_str" : "61949322614415360",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 ((hugs)) you tell 'em! : )",
  "id" : 61949322614415360,
  "in_reply_to_status_id" : 61945760211673088,
  "created_at" : "2011-04-24 00:27:24 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baron Barmy Bonkers",
      "screen_name" : "SirRanty",
      "indices" : [ 3, 12 ],
      "id_str" : "120808660",
      "id" : 120808660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61912895956582400",
  "text" : "RT @SirRanty: WHO DID IT?????",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61906519679188992",
    "text" : "WHO DID IT?????",
    "id" : 61906519679188992,
    "created_at" : "2011-04-23 21:37:19 +0000",
    "user" : {
      "name" : "Baron Barmy Bonkers",
      "screen_name" : "SirRanty",
      "protected" : true,
      "id_str" : "120808660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628637036820492293\/pls07J1q_normal.jpg",
      "id" : 120808660,
      "verified" : false
    }
  },
  "id" : 61912895956582400,
  "created_at" : "2011-04-23 22:02:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61893630113222656",
  "geo" : { },
  "id_str" : "61896001031651329",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise oh yuk. I feel for ya.. have had lots of those. feel better soon! ((hugs))",
  "id" : 61896001031651329,
  "in_reply_to_status_id" : 61893630113222656,
  "created_at" : "2011-04-23 20:55:31 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    }, {
      "name" : "kim cormack",
      "screen_name" : "kimcormack",
      "indices" : [ 47, 58 ],
      "id_str" : "106835731",
      "id" : 106835731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61895667303448576",
  "text" : "RT @WestofMars: You know this because?????  RT @kimcormack: Nutmeg is extremely poisonous if injected intravenously.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kim cormack",
        "screen_name" : "kimcormack",
        "indices" : [ 31, 42 ],
        "id_str" : "106835731",
        "id" : 106835731
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61895493873184768",
    "text" : "You know this because?????  RT @kimcormack: Nutmeg is extremely poisonous if injected intravenously.",
    "id" : 61895493873184768,
    "created_at" : "2011-04-23 20:53:30 +0000",
    "user" : {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "protected" : false,
      "id_str" : "34258680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454321783588413442\/gndVsGba_normal.png",
      "id" : 34258680,
      "verified" : false
    }
  },
  "id" : 61895667303448576,
  "created_at" : "2011-04-23 20:54:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61895547501555712",
  "text" : "in other news, I'm starving waiting for dinner and just spent a lot of time adding tags to http:\/\/budurl.com\/myreads ...",
  "id" : 61895547501555712,
  "created_at" : "2011-04-23 20:53:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddToAny",
      "screen_name" : "AddToAny",
      "indices" : [ 70, 79 ],
      "id_str" : "21849140",
      "id" : 21849140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61854836970360832",
  "text" : "Blind Dog Uses Sounds Off Leaves For Direction http:\/\/j.mp\/hTNqIr via @AddToAny",
  "id" : 61854836970360832,
  "created_at" : "2011-04-23 18:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina L. Diamond",
      "screen_name" : "ninatypewriter",
      "indices" : [ 3, 18 ],
      "id_str" : "171656520",
      "id" : 171656520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61835748038545408",
  "text" : "RT @ninatypewriter: Since iPhones know where you are, soon they'll give you hell for it: \"At the McDonald's drive-thru again? You've had ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61832863313690625",
    "text" : "Since iPhones know where you are, soon they'll give you hell for it: \"At the McDonald's drive-thru again? You've had enough fries!\"",
    "id" : 61832863313690625,
    "created_at" : "2011-04-23 16:44:38 +0000",
    "user" : {
      "name" : "Nina L. Diamond",
      "screen_name" : "ninatypewriter",
      "protected" : false,
      "id_str" : "171656520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458687512395788289\/1MfaX0M0_normal.jpeg",
      "id" : 171656520,
      "verified" : false
    }
  },
  "id" : 61835748038545408,
  "created_at" : "2011-04-23 16:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 4, 19 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/ziP0B8S",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gZLzCeGfrNM&feature=share",
      "display_url" : "youtube.com\/watch?v=gZLzCe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "61817890860576768",
  "text" : "See @anamericanmonk video -- Karma 'Cause and Effect' http:\/\/t.co\/ziP0B8S & get the book.. I did!",
  "id" : 61817890860576768,
  "created_at" : "2011-04-23 15:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Morgan",
      "screen_name" : "ImTracyMorgan",
      "indices" : [ 3, 17 ],
      "id_str" : "2284003653",
      "id" : 2284003653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61815140097589248",
  "text" : "RT @ImTracyMorgan: When God asks what you've done with your life, try not to say \"Didn't you read my tweets?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61612771569184768",
    "text" : "When God asks what you've done with your life, try not to say \"Didn't you read my tweets?\"",
    "id" : 61612771569184768,
    "created_at" : "2011-04-23 02:10:04 +0000",
    "user" : {
      "name" : "Kevin Heart",
      "screen_name" : "kevinheart4reaI",
      "protected" : false,
      "id_str" : "243905514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452949789827543040\/PB-Ze1T0_normal.jpeg",
      "id" : 243905514,
      "verified" : false
    }
  },
  "id" : 61815140097589248,
  "created_at" : "2011-04-23 15:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/ArloXtq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gZLzCeGfrNM&feature=share",
      "display_url" : "youtube.com\/watch?v=gZLzCe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "61803380770746368",
  "text" : "RT @AnAmericanMonk: Karma 'Cause and Effect' http:\/\/t.co\/ArloXtq via @youtube my newest video",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 49, 57 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 44 ],
        "url" : "http:\/\/t.co\/ArloXtq",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gZLzCeGfrNM&feature=share",
        "display_url" : "youtube.com\/watch?v=gZLzCe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "61798232128368640",
    "text" : "Karma 'Cause and Effect' http:\/\/t.co\/ArloXtq via @youtube my newest video",
    "id" : 61798232128368640,
    "created_at" : "2011-04-23 14:27:01 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 61803380770746368,
  "created_at" : "2011-04-23 14:47:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 74, 89 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61803267646164992",
  "text" : "RT @hayhaypeirsol: \"You attract to you what you are, NOT what you want.\" -@AnAmericanMonk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven L Hairfield",
        "screen_name" : "AnAmericanMonk",
        "indices" : [ 55, 70 ],
        "id_str" : "31231020",
        "id" : 31231020
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61673368805584897",
    "text" : "\"You attract to you what you are, NOT what you want.\" -@AnAmericanMonk",
    "id" : 61673368805584897,
    "created_at" : "2011-04-23 06:10:51 +0000",
    "user" : {
      "name" : "hayley peirsol",
      "screen_name" : "HayleyPeirsol",
      "protected" : false,
      "id_str" : "129384395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2544127966\/image_normal.jpg",
      "id" : 129384395,
      "verified" : false
    }
  },
  "id" : 61803267646164992,
  "created_at" : "2011-04-23 14:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Milligan, MPA",
      "screen_name" : "justasked",
      "indices" : [ 3, 13 ],
      "id_str" : "27418630",
      "id" : 27418630
    }, {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 86, 96 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bullying",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "writer",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61802863181049856",
  "text" : "RT @justasked: Inspiring post about #bullying from an awesome human being and #writer @LukeRomyn http:\/\/lukeromyn.com\/blog\/2011\/04\/23\/bu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Romyn",
        "screen_name" : "LukeRomyn",
        "indices" : [ 71, 81 ],
        "id_str" : "24636191",
        "id" : 24636191
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bullying",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "writer",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "blogchat",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61793259239915520",
    "text" : "Inspiring post about #bullying from an awesome human being and #writer @LukeRomyn http:\/\/lukeromyn.com\/blog\/2011\/04\/23\/bullying\/ #blogchat",
    "id" : 61793259239915520,
    "created_at" : "2011-04-23 14:07:15 +0000",
    "user" : {
      "name" : "Ed Milligan, MPA",
      "screen_name" : "justasked",
      "protected" : false,
      "id_str" : "27418630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2863015110\/7e3c080e726a1fc3384d2655f0665cc6_normal.jpeg",
      "id" : 27418630,
      "verified" : false
    }
  },
  "id" : 61802863181049856,
  "created_at" : "2011-04-23 14:45:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "indices" : [ 20, 28 ],
      "id_str" : "14232408",
      "id" : 14232408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61801116014354433",
  "text" : "RT @MartijnLinssen: @offgrid Thought you might like my latest: Resurrection. What are you waiting for? \nhttp:\/\/bit.ly\/hN6Dtp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Offgrid",
        "screen_name" : "offgrid",
        "indices" : [ 0, 8 ],
        "id_str" : "14232408",
        "id" : 14232408
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61782365390909440",
    "in_reply_to_user_id" : 14232408,
    "text" : "@offgrid Thought you might like my latest: Resurrection. What are you waiting for? \nhttp:\/\/bit.ly\/hN6Dtp",
    "id" : 61782365390909440,
    "created_at" : "2011-04-23 13:23:58 +0000",
    "in_reply_to_screen_name" : "offgrid",
    "in_reply_to_user_id_str" : "14232408",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 61801116014354433,
  "created_at" : "2011-04-23 14:38:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61564731080704000",
  "text" : "RT @ChrisGroove1: All cats on death row were saved for Good Friday xcept for CHRIS. Healthy. Young. No rescu\u2026 (cont) http:\/\/deck.ly\/~0QKHE",
  "id" : 61564731080704000,
  "created_at" : "2011-04-22 22:59:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 3, 15 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61547273510854656",
  "text" : "RT @PuaTamandua: Watch Cinco's 4 part adventure http:\/\/www.youtube.com\/watch?v=s2OYUBTr2Ng http:\/\/fb.me\/wKPqG2aU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61542245031096320",
    "text" : "Watch Cinco's 4 part adventure http:\/\/www.youtube.com\/watch?v=s2OYUBTr2Ng http:\/\/fb.me\/wKPqG2aU",
    "id" : 61542245031096320,
    "created_at" : "2011-04-22 21:29:49 +0000",
    "user" : {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "protected" : false,
      "id_str" : "17218256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63782435\/shirt_normal.jpg",
      "id" : 17218256,
      "verified" : false
    }
  },
  "id" : 61547273510854656,
  "created_at" : "2011-04-22 21:49:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "indices" : [ 3, 17 ],
      "id_str" : "169354425",
      "id" : 169354425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61546702783524864",
  "text" : "RT @MontyMcSquill: Service Dog for Girl With Brain Cancer Bites Another Child http:\/\/bit.ly\/fjn0b2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61543913621700608",
    "text" : "Service Dog for Girl With Brain Cancer Bites Another Child http:\/\/bit.ly\/fjn0b2",
    "id" : 61543913621700608,
    "created_at" : "2011-04-22 21:36:27 +0000",
    "user" : {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "protected" : false,
      "id_str" : "169354425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083700728\/McSquill_normal.jpg",
      "id" : 169354425,
      "verified" : false
    }
  },
  "id" : 61546702783524864,
  "created_at" : "2011-04-22 21:47:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61520791828840448",
  "text" : "RT @ChrisGroove1: RT All cats have been SAVED from death row  2day Brooklyn but CHRIS! $300 pledge to RESCUE who pulls him HURRY  http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61518331026481152",
    "text" : "RT All cats have been SAVED from death row  2day Brooklyn but CHRIS! $300 pledge to RESCUE who pulls him HURRY  http:\/\/on.fb.me\/eNvTyX",
    "id" : 61518331026481152,
    "created_at" : "2011-04-22 19:54:47 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 61520791828840448,
  "created_at" : "2011-04-22 20:04:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61506115854282752",
  "text" : "I want to change my name to Ezra.",
  "id" : 61506115854282752,
  "created_at" : "2011-04-22 19:06:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61505998799646720",
  "text" : "RT @ChrisGroove1: Omc loading that last Tweet on dialup was like giving birth....come on come on push push...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61505596783996928",
    "text" : "Omc loading that last Tweet on dialup was like giving birth....come on come on push push...",
    "id" : 61505596783996928,
    "created_at" : "2011-04-22 19:04:11 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 61505998799646720,
  "created_at" : "2011-04-22 19:05:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Morgan",
      "screen_name" : "ImTracyMorgan",
      "indices" : [ 3, 17 ],
      "id_str" : "2284003653",
      "id" : 2284003653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61496503713280000",
  "text" : "RT @ImTracyMorgan: FACEBOOK is the second most popular word that starts with ''F and ends with K''.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61351086656716800",
    "text" : "FACEBOOK is the second most popular word that starts with ''F and ends with K''.",
    "id" : 61351086656716800,
    "created_at" : "2011-04-22 08:50:13 +0000",
    "user" : {
      "name" : "Kevin Heart",
      "screen_name" : "kevinheart4reaI",
      "protected" : false,
      "id_str" : "243905514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452949789827543040\/PB-Ze1T0_normal.jpeg",
      "id" : 243905514,
      "verified" : false
    }
  },
  "id" : 61496503713280000,
  "created_at" : "2011-04-22 18:28:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 3, 14 ],
      "id_str" : "76225852",
      "id" : 76225852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61489242618085377",
  "text" : "RT @TraLeeFitz: Policing Pregnancy | The Nation http:\/\/bit.ly\/edRMPd \/\/ The assholes who push this bullshit are politicized sociopaths.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61485742655938560",
    "text" : "Policing Pregnancy | The Nation http:\/\/bit.ly\/edRMPd \/\/ The assholes who push this bullshit are politicized sociopaths. Disgusting.",
    "id" : 61485742655938560,
    "created_at" : "2011-04-22 17:45:18 +0000",
    "user" : {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "protected" : false,
      "id_str" : "76225852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798982593702023168\/XfVHvWY7_normal.jpg",
      "id" : 76225852,
      "verified" : false
    }
  },
  "id" : 61489242618085377,
  "created_at" : "2011-04-22 17:59:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "indices" : [ 3, 16 ],
      "id_str" : "84714448",
      "id" : 84714448
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 26, 36 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61476131274108928",
  "text" : "RT @Thinking_mom: Ha Ha! \"@neiltyson: We can't communicate with any \"lower\" species on Earth. Maybe aliens can't communicate with us for ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 8, 18 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61467243883659265",
    "text" : "Ha Ha! \"@neiltyson: We can't communicate with any \"lower\" species on Earth. Maybe aliens can't communicate with us for the same reasons.\"",
    "id" : 61467243883659265,
    "created_at" : "2011-04-22 16:31:47 +0000",
    "user" : {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "protected" : false,
      "id_str" : "84714448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792761883749154816\/N4CNeldE_normal.jpg",
      "id" : 84714448,
      "verified" : false
    }
  },
  "id" : 61476131274108928,
  "created_at" : "2011-04-22 17:07:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Raynor",
      "screen_name" : "ShaneRaynor",
      "indices" : [ 3, 15 ],
      "id_str" : "17818522",
      "id" : 17818522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/gW4DBRg",
      "expanded_url" : "http:\/\/www.ministrymatters.com\/all\/article\/entry\/1005\/the-logic-of-hell",
      "display_url" : "ministrymatters.com\/all\/article\/en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "61470873114263553",
  "text" : "RT @ShaneRaynor: The Logic of Hell -- http:\/\/t.co\/gW4DBRg -- Adam Hamilton takes a look at the doctrine of eternal punishment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 40 ],
        "url" : "http:\/\/t.co\/gW4DBRg",
        "expanded_url" : "http:\/\/www.ministrymatters.com\/all\/article\/entry\/1005\/the-logic-of-hell",
        "display_url" : "ministrymatters.com\/all\/article\/en\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "61460717693452288",
    "text" : "The Logic of Hell -- http:\/\/t.co\/gW4DBRg -- Adam Hamilton takes a look at the doctrine of eternal punishment.",
    "id" : 61460717693452288,
    "created_at" : "2011-04-22 16:05:51 +0000",
    "user" : {
      "name" : "Shane Raynor",
      "screen_name" : "ShaneRaynor",
      "protected" : false,
      "id_str" : "17818522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712651613941280768\/73kqi-uY_normal.jpg",
      "id" : 17818522,
      "verified" : false
    }
  },
  "id" : 61470873114263553,
  "created_at" : "2011-04-22 16:46:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Amy Jane Gruber",
      "screen_name" : "AmyJane",
      "indices" : [ 15, 23 ],
      "id_str" : "641433",
      "id" : 641433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61444921239945216",
  "text" : "RT @BestAt: RT @AmyJane: I saw a bumper sticker that said \u201CMidwives help people out\u201D and I can\u2019t stop chuckling about it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy Jane Gruber",
        "screen_name" : "AmyJane",
        "indices" : [ 3, 11 ],
        "id_str" : "641433",
        "id" : 641433
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61444365477888000",
    "text" : "RT @AmyJane: I saw a bumper sticker that said \u201CMidwives help people out\u201D and I can\u2019t stop chuckling about it.",
    "id" : 61444365477888000,
    "created_at" : "2011-04-22 15:00:52 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 61444921239945216,
  "created_at" : "2011-04-22 15:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61444832622673920",
  "text" : "RT @MyNatureApps: To celebrate Earth Day & promote an Education in Nature all of our apps are Free today!!  www.mynaturesite.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61444298083807233",
    "text" : "To celebrate Earth Day & promote an Education in Nature all of our apps are Free today!!  www.mynaturesite.com",
    "id" : 61444298083807233,
    "created_at" : "2011-04-22 15:00:36 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 61444832622673920,
  "created_at" : "2011-04-22 15:02:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 0, 10 ],
      "id_str" : "56280847",
      "id" : 56280847
    }, {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 60, 73 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61433979701702657",
  "geo" : { },
  "id_str" : "61441660135030784",
  "in_reply_to_user_id" : 56280847,
  "text" : "@DougDorow scavenger's daughter by mike mcintyre, phobia by @golden_books , ivrrac by peter robert jordan",
  "id" : 61441660135030784,
  "in_reply_to_status_id" : 61433979701702657,
  "created_at" : "2011-04-22 14:50:07 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61439394829185024",
  "text" : "RT @mssuzcatsilver: Does anyone know where Henry cat has gone? Lol  http:\/\/twitpic.com\/4o0ia8 daft cat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61437993843556352",
    "text" : "Does anyone know where Henry cat has gone? Lol  http:\/\/twitpic.com\/4o0ia8 daft cat",
    "id" : 61437993843556352,
    "created_at" : "2011-04-22 14:35:33 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 61439394829185024,
  "created_at" : "2011-04-22 14:41:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61437310541119488",
  "text" : "RT @hauntedcomputer: I am contributing to Earth Day by sitting here quietly and decomposing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61436444387979264",
    "text" : "I am contributing to Earth Day by sitting here quietly and decomposing",
    "id" : 61436444387979264,
    "created_at" : "2011-04-22 14:29:24 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 61437310541119488,
  "created_at" : "2011-04-22 14:32:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 0, 10 ],
      "id_str" : "56280847",
      "id" : 56280847
    }, {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 22, 32 ],
      "id_str" : "14428947",
      "id" : 14428947
    }, {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 88, 103 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61433979701702657",
  "geo" : { },
  "id_str" : "61436254499246080",
  "in_reply_to_user_id" : 56280847,
  "text" : "@DougDorow day one by @bcmystery , no good deed by @MPMcDonald64 , season of harvest by @KreelanWarrior",
  "id" : 61436254499246080,
  "in_reply_to_status_id" : 61433979701702657,
  "created_at" : "2011-04-22 14:28:39 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 0, 10 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61433979701702657",
  "geo" : { },
  "id_str" : "61435633582874624",
  "in_reply_to_user_id" : 56280847,
  "text" : "@DougDorow my choice of genre so you'll find a bunch here: http:\/\/budurl.com\/myreads",
  "id" : 61435633582874624,
  "in_reply_to_status_id" : 61433979701702657,
  "created_at" : "2011-04-22 14:26:11 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 35, 45 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61433979701702657",
  "geo" : { },
  "id_str" : "61435250970083329",
  "in_reply_to_user_id" : 56280847,
  "text" : "ive heard 9th district is good ; ) @DougDorow",
  "id" : 61435250970083329,
  "in_reply_to_status_id" : 61433979701702657,
  "created_at" : "2011-04-22 14:24:39 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61433231672754176",
  "text" : "..I would rather be able to buy books for my library (specifically ebooks and particular books)",
  "id" : 61433231672754176,
  "created_at" : "2011-04-22 14:16:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61432867699433472",
  "text" : "found this thing called librarybin where you buy book & percent goes to yr library district... good idea but...",
  "id" : 61432867699433472,
  "created_at" : "2011-04-22 14:15:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Beck",
      "screen_name" : "TheKevinBeck",
      "indices" : [ 3, 16 ],
      "id_str" : "299086582",
      "id" : 299086582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61244594540642304",
  "text" : "RT @TheKevinBeck: Seeing the kingdom of heaven while having breakfast with Buddha. http:\/\/bit.ly\/f945UV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61243227860254720",
    "text" : "Seeing the kingdom of heaven while having breakfast with Buddha. http:\/\/bit.ly\/f945UV",
    "id" : 61243227860254720,
    "created_at" : "2011-04-22 01:41:38 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "protected" : true,
      "id_str" : "21812702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747936103886270464\/QfwMeqJj_normal.jpg",
      "id" : 21812702,
      "verified" : false
    }
  },
  "id" : 61244594540642304,
  "created_at" : "2011-04-22 01:47:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darlene Wiggins",
      "screen_name" : "Diamondsongrass",
      "indices" : [ 3, 19 ],
      "id_str" : "46929478",
      "id" : 46929478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61241012936392704",
  "text" : "RT @Diamondsongrass: One day I said to God --\nI'm going to search\nFor the meaning to my existence\nI'm going to find the talent within (c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61238119051177984",
    "text" : "One day I said to God --\nI'm going to search\nFor the meaning to my existence\nI'm going to find the talent within (cont) http:\/\/tl.gd\/a0b3te",
    "id" : 61238119051177984,
    "created_at" : "2011-04-22 01:21:19 +0000",
    "user" : {
      "name" : "Darlene Wiggins",
      "screen_name" : "Diamondsongrass",
      "protected" : false,
      "id_str" : "46929478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1826084222\/picture_of_white_daisy_flower_normal.jpg",
      "id" : 46929478,
      "verified" : false
    }
  },
  "id" : 61241012936392704,
  "created_at" : "2011-04-22 01:32:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61240216970735616",
  "text" : "RT @SangyeH: We can state opinions--even strong ones-- without degrading others.  It's never ok or helpful to increase hatred in the world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61228521934163968",
    "text" : "We can state opinions--even strong ones-- without degrading others.  It's never ok or helpful to increase hatred in the world.",
    "id" : 61228521934163968,
    "created_at" : "2011-04-22 00:43:11 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 61240216970735616,
  "created_at" : "2011-04-22 01:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliott Teters",
      "screen_name" : "Elliott_Teters",
      "indices" : [ 3, 18 ],
      "id_str" : "46923217",
      "id" : 46923217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61240023323918337",
  "text" : "RT @Elliott_Teters: Happy Thursday my Twitter Friends. I am very grateful for each of you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61229475458854912",
    "text" : "Happy Thursday my Twitter Friends. I am very grateful for each of you!",
    "id" : 61229475458854912,
    "created_at" : "2011-04-22 00:46:59 +0000",
    "user" : {
      "name" : "Elliott Teters",
      "screen_name" : "Elliott_Teters",
      "protected" : false,
      "id_str" : "46923217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774089006678093825\/yzGaGcF5_normal.jpg",
      "id" : 46923217,
      "verified" : false
    }
  },
  "id" : 61240023323918337,
  "created_at" : "2011-04-22 01:28:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61173202507927552",
  "text" : "@Tideliar hubby & I love ppl watching, too. esp. at the mall. we're always pointing out ppl to each other..lol",
  "id" : 61173202507927552,
  "created_at" : "2011-04-21 21:03:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61171572572033024",
  "text" : "I made a cake. It looks terrible.. all lop-sided.",
  "id" : 61171572572033024,
  "created_at" : "2011-04-21 20:56:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61151185045946368",
  "text" : "we had a nice chat about dreams we have had",
  "id" : 61151185045946368,
  "created_at" : "2011-04-21 19:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61151013616353280",
  "text" : "my DD loves looking up what dreams mean. I dreamt about a high wave crashing down on a beach (I was behind 2 sets of doors)",
  "id" : 61151013616353280,
  "created_at" : "2011-04-21 19:35:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61150420126531584",
  "text" : "sometimes I just want to shave my head",
  "id" : 61150420126531584,
  "created_at" : "2011-04-21 19:32:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "indices" : [ 3, 13 ],
      "id_str" : "34858888",
      "id" : 34858888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61085960368164864",
  "text" : "RT @Hayzlenut: How To Make Bacon Lip Balm http:\/\/6sen.se\/hXXOB6 I MUST do this, if only to horrify co workers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.my6sense.com\" rel=\"nofollow\"\u003Emy6sense\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61085130529325056",
    "text" : "How To Make Bacon Lip Balm http:\/\/6sen.se\/hXXOB6 I MUST do this, if only to horrify co workers",
    "id" : 61085130529325056,
    "created_at" : "2011-04-21 15:13:24 +0000",
    "user" : {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "protected" : false,
      "id_str" : "34858888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1329378381\/profile_normal.jpg",
      "id" : 34858888,
      "verified" : false
    }
  },
  "id" : 61085960368164864,
  "created_at" : "2011-04-21 15:16:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60890891333795840",
  "text" : "RT @CrystalLewis: In case you missed it... I recount my futile quest for a \"pure\" Christian belief system. http:\/\/fb.me\/W8Lu9HTk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60882077310136320",
    "text" : "In case you missed it... I recount my futile quest for a \"pure\" Christian belief system. http:\/\/fb.me\/W8Lu9HTk",
    "id" : 60882077310136320,
    "created_at" : "2011-04-21 01:46:33 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 60890891333795840,
  "created_at" : "2011-04-21 02:21:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60878360041099265",
  "text" : "RT @SpiritMaterial: All that we see or seem, is but a dream within a dream. ~Edgar Allan Poe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60877575739817984",
    "text" : "All that we see or seem, is but a dream within a dream. ~Edgar Allan Poe",
    "id" : 60877575739817984,
    "created_at" : "2011-04-21 01:28:39 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 60878360041099265,
  "created_at" : "2011-04-21 01:31:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60875397092491264",
  "geo" : { },
  "id_str" : "60875843467096064",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps btw, how is your hand doing?",
  "id" : 60875843467096064,
  "in_reply_to_status_id" : 60875397092491264,
  "created_at" : "2011-04-21 01:21:46 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60874978958127104",
  "text" : "RT @MyNatureApps: Don't forget this Friday ALL our apps are FREE for Earth Day  ----&gt; www.mynaturesite.com stop by in and see us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60874240978718720",
    "text" : "Don't forget this Friday ALL our apps are FREE for Earth Day  ----&gt; www.mynaturesite.com stop by in and see us.",
    "id" : 60874240978718720,
    "created_at" : "2011-04-21 01:15:24 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 60874978958127104,
  "created_at" : "2011-04-21 01:18:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St. Martin's Press",
      "screen_name" : "StMartinsPress",
      "indices" : [ 3, 18 ],
      "id_str" : "227660675",
      "id" : 227660675
    }, {
      "name" : "Business Insider",
      "screen_name" : "businessinsider",
      "indices" : [ 118, 134 ],
      "id_str" : "20562637",
      "id" : 20562637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/qd5JCbD",
      "expanded_url" : "http:\/\/read.bi\/dFDVbK",
      "display_url" : "read.bi\/dFDVbK"
    } ]
  },
  "geo" : { },
  "id_str" : "60771493407236096",
  "text" : "RT @StMartinsPress: Sarah Palin's Version Of Trig's Birth May Be More Troubling Than The Hoax http:\/\/t.co\/qd5JCbD via @businessinsider",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Business Insider",
        "screen_name" : "businessinsider",
        "indices" : [ 98, 114 ],
        "id_str" : "20562637",
        "id" : 20562637
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 93 ],
        "url" : "http:\/\/t.co\/qd5JCbD",
        "expanded_url" : "http:\/\/read.bi\/dFDVbK",
        "display_url" : "read.bi\/dFDVbK"
      } ]
    },
    "geo" : { },
    "id_str" : "60763815482114048",
    "text" : "Sarah Palin's Version Of Trig's Birth May Be More Troubling Than The Hoax http:\/\/t.co\/qd5JCbD via @businessinsider",
    "id" : 60763815482114048,
    "created_at" : "2011-04-20 17:56:37 +0000",
    "user" : {
      "name" : "St. Martin's Press",
      "screen_name" : "StMartinsPress",
      "protected" : false,
      "id_str" : "227660675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1194862874\/Flatiron_normal.jpg",
      "id" : 227660675,
      "verified" : true
    }
  },
  "id" : 60771493407236096,
  "created_at" : "2011-04-20 18:27:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60737514490695680",
  "text" : "RT @HealthRanger: Radiation exposure chart admits cancer radiotherapy delivers fatal dose to patients.  http:\/\/ow.ly\/4Ei3w #health #natu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "naturalnews",
        "indices" : [ 113, 125 ]
      }, {
        "text" : "radiation",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60729030420336640",
    "text" : "Radiation exposure chart admits cancer radiotherapy delivers fatal dose to patients.  http:\/\/ow.ly\/4Ei3w #health #naturalnews #radiation",
    "id" : 60729030420336640,
    "created_at" : "2011-04-20 15:38:23 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 60737514490695680,
  "created_at" : "2011-04-20 16:12:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 3, 16 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60700806357319680",
  "text" : "RT @AmazonKindle: We\u2019re excited to announce that library lending is coming to Kindle later this year. http:\/\/bit.ly\/gILhpj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60694769193598976",
    "text" : "We\u2019re excited to announce that library lending is coming to Kindle later this year. http:\/\/bit.ly\/gILhpj",
    "id" : 60694769193598976,
    "created_at" : "2011-04-20 13:22:15 +0000",
    "user" : {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "protected" : false,
      "id_str" : "84249568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512411639908298752\/z8wZ_AlQ_normal.jpeg",
      "id" : 84249568,
      "verified" : true
    }
  },
  "id" : 60700806357319680,
  "created_at" : "2011-04-20 13:46:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60534672337276928",
  "text" : "RT @CrystalLewis: My theology in three words: God is bigger.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60527621531897856",
    "text" : "My theology in three words: God is bigger.",
    "id" : 60527621531897856,
    "created_at" : "2011-04-20 02:18:04 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 60534672337276928,
  "created_at" : "2011-04-20 02:46:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Penn",
      "screen_name" : "thecreativepenn",
      "indices" : [ 3, 19 ],
      "id_str" : "19017772",
      "id" : 19017772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60502393053384704",
  "text" : "RT @thecreativepenn: Kindle ebook signings now possible with new app http:\/\/bit.ly\/h66A51 (fantastic!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60443212296372224",
    "text" : "Kindle ebook signings now possible with new app http:\/\/bit.ly\/h66A51 (fantastic!)",
    "id" : 60443212296372224,
    "created_at" : "2011-04-19 20:42:39 +0000",
    "user" : {
      "name" : "Joanna Penn",
      "screen_name" : "thecreativepenn",
      "protected" : false,
      "id_str" : "19017772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3256698210\/2e23d0469d6b2e59fa73eee5f3b1d7a1_normal.jpeg",
      "id" : 19017772,
      "verified" : false
    }
  },
  "id" : 60502393053384704,
  "created_at" : "2011-04-20 00:37:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60495775498633216",
  "geo" : { },
  "id_str" : "60498167967395841",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ouch! Ive been in hospital a few times. hated it.. (well, except 4 pain meds..lol)",
  "id" : 60498167967395841,
  "in_reply_to_status_id" : 60495775498633216,
  "created_at" : "2011-04-20 00:21:01 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60497697693630465",
  "text" : "@Skandhasattva im sorry you're having these experiences : (",
  "id" : 60497697693630465,
  "created_at" : "2011-04-20 00:19:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60491800175067136",
  "text" : "its been too long...",
  "id" : 60491800175067136,
  "created_at" : "2011-04-19 23:55:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60491484704686080",
  "text" : "@Skandhasattva thats kind of sad...",
  "id" : 60491484704686080,
  "created_at" : "2011-04-19 23:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60455405536550912",
  "text" : "I wanna smack the judge on The People's Court. She drives me crazy!!",
  "id" : 60455405536550912,
  "created_at" : "2011-04-19 21:31:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60338108591378432",
  "text" : "Iran: Dog Ownership to Be Outlawed Under Lawmakers' Plan  http:\/\/yhoo.it\/hNsgUC",
  "id" : 60338108591378432,
  "created_at" : "2011-04-19 13:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FunnyOneLiners",
      "screen_name" : "Funnyoneliners",
      "indices" : [ 3, 18 ],
      "id_str" : "40885516",
      "id" : 40885516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60334288066973696",
  "text" : "RT @funnyoneliners: There's always one person in any organization who knows what's really going on. This person must be fired.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60311371061002240",
    "text" : "There's always one person in any organization who knows what's really going on. This person must be fired.",
    "id" : 60311371061002240,
    "created_at" : "2011-04-19 11:58:46 +0000",
    "user" : {
      "name" : "FunnyOneLiners",
      "screen_name" : "Funnyoneliners",
      "protected" : false,
      "id_str" : "40885516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642168488195436544\/kiOSQaiM_normal.jpg",
      "id" : 40885516,
      "verified" : false
    }
  },
  "id" : 60334288066973696,
  "created_at" : "2011-04-19 13:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxanne Krystalli",
      "screen_name" : "rkrystalli",
      "indices" : [ 3, 14 ],
      "id_str" : "29317977",
      "id" : 29317977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grateful",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60334216147251200",
  "text" : "RT @rkrystalli: Today I am #grateful for the conversations, community and love that have come into my life through Twitter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grateful",
        "indices" : [ 11, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60316005058093056",
    "text" : "Today I am #grateful for the conversations, community and love that have come into my life through Twitter.",
    "id" : 60316005058093056,
    "created_at" : "2011-04-19 12:17:10 +0000",
    "user" : {
      "name" : "Roxanne Krystalli",
      "screen_name" : "rkrystalli",
      "protected" : false,
      "id_str" : "29317977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661227650296320000\/UW3Yx6r7_normal.jpg",
      "id" : 29317977,
      "verified" : false
    }
  },
  "id" : 60334216147251200,
  "created_at" : "2011-04-19 13:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60333994918682624",
  "text" : "RT @hvspca: WEBSITE HELP WANTED!!!!  Do you have experience setting up webstores \/ website shopping carts with links to... http:\/\/fb.me\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60318939384774657",
    "text" : "WEBSITE HELP WANTED!!!!  Do you have experience setting up webstores \/ website shopping carts with links to... http:\/\/fb.me\/QCs8d37I",
    "id" : 60318939384774657,
    "created_at" : "2011-04-19 12:28:50 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 60333994918682624,
  "created_at" : "2011-04-19 13:28:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60333577967108096",
  "text" : "RT @modernevil: Did you know I have 23 different titles available for your kindle? Horror, SciFi, Fantasy, philosophy, romance & more: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 138 ],
        "url" : "http:\/\/t.co\/3BAgIBp",
        "expanded_url" : "http:\/\/www.amazon.com\/gp\/redirect.html?ie=UTF8&location=http%3A%2F%2Fwww.amazon.com%2Fgp%2Fentity%2FTeel-McClanahan%2FB003Z2SPL6%3Fie%3DUTF8%26ref_%3Dsr_ntt_srch_lnk_1%26qid%3D1303218222%26sr%3D8-1&tag=teemcc-20&linkCode=ur2&camp=1789&creative=390957",
        "display_url" : "amazon.com\/gp\/redirect.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "60328415819071488",
    "text" : "Did you know I have 23 different titles available for your kindle? Horror, SciFi, Fantasy, philosophy, romance & more: http:\/\/t.co\/3BAgIBp",
    "id" : 60328415819071488,
    "created_at" : "2011-04-19 13:06:29 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 60333577967108096,
  "created_at" : "2011-04-19 13:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60326391878647808",
  "text" : "RT @BayBitch: You authors are bad influences.Every time I see a new book, I just gotta have it. You are overfeeding my addiction. (Yes,  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60325033133871104",
    "text" : "You authors are bad influences.Every time I see a new book, I just gotta have it. You are overfeeding my addiction. (Yes, I like your books)",
    "id" : 60325033133871104,
    "created_at" : "2011-04-19 12:53:03 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 60326391878647808,
  "created_at" : "2011-04-19 12:58:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60151348024451072",
  "text" : "RT @brandonrofl: We were meant to live for so much more. Have we lost ourselves?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60151142738436097",
    "text" : "We were meant to live for so much more. Have we lost ourselves?",
    "id" : 60151142738436097,
    "created_at" : "2011-04-19 01:22:04 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 60151348024451072,
  "created_at" : "2011-04-19 01:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60146375307952128",
  "text" : "RT @AnAmericanMonk: We are all much greater than we think ourselves to be especially when we open the heart to life and it's experiences.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60146027344314368",
    "text" : "We are all much greater than we think ourselves to be especially when we open the heart to life and it's experiences.",
    "id" : 60146027344314368,
    "created_at" : "2011-04-19 01:01:45 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 60146375307952128,
  "created_at" : "2011-04-19 01:03:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "WREG News Channel 3",
      "screen_name" : "3onyourside",
      "indices" : [ 10, 22 ],
      "id_str" : "14976738",
      "id" : 14976738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60110864908431360",
  "text" : "@Tideliar @3onyourside the ppl w intent to harm always find a way around laws. we're litigating ourselves to extinction.",
  "id" : 60110864908431360,
  "created_at" : "2011-04-18 22:42:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60106170899251200",
  "text" : "New FREE promotional opportunity for independent publishers and self-publishers http:\/\/bit.ly\/e19ULj",
  "id" : 60106170899251200,
  "created_at" : "2011-04-18 22:23:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60105276505849856",
  "text" : "Thriller writers: do you want to be interviewed? http:\/\/bit.ly\/gTJxYp",
  "id" : 60105276505849856,
  "created_at" : "2011-04-18 22:19:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60087676539371521",
  "text" : "RT @drbloem: Aspartame Rebranded as AminoSweet http:\/\/bit.ly\/8YbE5s #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 55, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60069877842591744",
    "text" : "Aspartame Rebranded as AminoSweet http:\/\/bit.ly\/8YbE5s #health",
    "id" : 60069877842591744,
    "created_at" : "2011-04-18 19:59:09 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 60087676539371521,
  "created_at" : "2011-04-18 21:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One Green Planet",
      "screen_name" : "OneGreenPlanet",
      "indices" : [ 3, 18 ],
      "id_str" : "134555743",
      "id" : 134555743
    }, {
      "name" : "Gene Baur",
      "screen_name" : "genebaur",
      "indices" : [ 24, 33 ],
      "id_str" : "31766093",
      "id" : 31766093
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Contest",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "vegan",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60085384696176640",
  "text" : "RT @OneGreenPlanet: WIN @GeneBaur\u2019s Best-selling book! Enter our #Contest here http:\/\/bit.ly\/gho3Ez #vegan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gene Baur",
        "screen_name" : "genebaur",
        "indices" : [ 4, 13 ],
        "id_str" : "31766093",
        "id" : 31766093
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Contest",
        "indices" : [ 45, 53 ]
      }, {
        "text" : "vegan",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60024989444882432",
    "text" : "WIN @GeneBaur\u2019s Best-selling book! Enter our #Contest here http:\/\/bit.ly\/gho3Ez #vegan",
    "id" : 60024989444882432,
    "created_at" : "2011-04-18 17:00:47 +0000",
    "user" : {
      "name" : "One Green Planet",
      "screen_name" : "OneGreenPlanet",
      "protected" : false,
      "id_str" : "134555743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791991204531634176\/0oAI_TjW_normal.jpg",
      "id" : 134555743,
      "verified" : false
    }
  },
  "id" : 60085384696176640,
  "created_at" : "2011-04-18 21:00:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 0, 13 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60073997387313153",
  "geo" : { },
  "id_str" : "60085123705618432",
  "in_reply_to_user_id" : 85400142,
  "text" : "@worldtreeman exactly. this is something I have pondered.",
  "id" : 60085123705618432,
  "in_reply_to_status_id" : 60073997387313153,
  "created_at" : "2011-04-18 20:59:44 +0000",
  "in_reply_to_screen_name" : "worldtreeman",
  "in_reply_to_user_id_str" : "85400142",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60084826203627520",
  "text" : "@Tideliar ack. what's OED?",
  "id" : 60084826203627520,
  "created_at" : "2011-04-18 20:58:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    }, {
      "name" : "Kindle Bargains",
      "screen_name" : "KindleBargains",
      "indices" : [ 43, 58 ],
      "id_str" : "279283693",
      "id" : 279283693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60084257908994048",
  "text" : "RT @JeremyCShipp: Authors: Send a tweet to @KindleBargains with a link to your Kindle book(s), and I'll help you promote your work for free.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kindle Bargains",
        "screen_name" : "KindleBargains",
        "indices" : [ 25, 40 ],
        "id_str" : "279283693",
        "id" : 279283693
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60074829780492289",
    "text" : "Authors: Send a tweet to @KindleBargains with a link to your Kindle book(s), and I'll help you promote your work for free.",
    "id" : 60074829780492289,
    "created_at" : "2011-04-18 20:18:50 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 60084257908994048,
  "created_at" : "2011-04-18 20:56:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 73, 79 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60040104357527552",
  "text" : "Do animals feel empathy?: Scientific American - http:\/\/bit.ly\/dHQTqL via @sciam",
  "id" : 60040104357527552,
  "created_at" : "2011-04-18 18:00:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59980787222720513",
  "text" : "RT @namenick: Blogged: 40+ free tools for authors http:\/\/bit.ly\/gfMH6J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59980369612648448",
    "text" : "Blogged: 40+ free tools for authors http:\/\/bit.ly\/gfMH6J",
    "id" : 59980369612648448,
    "created_at" : "2011-04-18 14:03:29 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 59980787222720513,
  "created_at" : "2011-04-18 14:05:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merralin",
      "screen_name" : "Merralin",
      "indices" : [ 3, 12 ],
      "id_str" : "4783081",
      "id" : 4783081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59976605879119872",
  "text" : "RT @Merralin: Genre Watch: New Mysteries and Thrillers for the Kindle http:\/\/bit.ly\/hSUBZ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59975713666764800",
    "text" : "Genre Watch: New Mysteries and Thrillers for the Kindle http:\/\/bit.ly\/hSUBZ4",
    "id" : 59975713666764800,
    "created_at" : "2011-04-18 13:44:59 +0000",
    "user" : {
      "name" : "Merralin",
      "screen_name" : "Merralin",
      "protected" : false,
      "id_str" : "4783081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790742885977042945\/9hm4MN_o_normal.jpg",
      "id" : 4783081,
      "verified" : false
    }
  },
  "id" : 59976605879119872,
  "created_at" : "2011-04-18 13:48:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CJ Lyons",
      "screen_name" : "cjlyonswriter",
      "indices" : [ 3, 17 ],
      "id_str" : "17312174",
      "id" : 17312174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http:\/\/t.co\/jaPWIbZ",
      "expanded_url" : "http:\/\/marketingwithheart.blogspot.com\/2011\/04\/why-do-people-buy-books.html",
      "display_url" : "marketingwithheart.blogspot.com\/2011\/04\/why-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "59976454636707840",
  "text" : "RT @cjlyonswriter: Why DO people buy books? http:\/\/t.co\/jaPWIbZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 44 ],
        "url" : "http:\/\/t.co\/jaPWIbZ",
        "expanded_url" : "http:\/\/marketingwithheart.blogspot.com\/2011\/04\/why-do-people-buy-books.html",
        "display_url" : "marketingwithheart.blogspot.com\/2011\/04\/why-do\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "59948021311483904",
    "text" : "Why DO people buy books? http:\/\/t.co\/jaPWIbZ",
    "id" : 59948021311483904,
    "created_at" : "2011-04-18 11:54:56 +0000",
    "user" : {
      "name" : "CJ Lyons",
      "screen_name" : "cjlyonswriter",
      "protected" : false,
      "id_str" : "17312174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1188960586\/CJheadshotlores_normal.jpg",
      "id" : 17312174,
      "verified" : false
    }
  },
  "id" : 59976454636707840,
  "created_at" : "2011-04-18 13:47:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 3, 16 ],
      "id_str" : "256540769",
      "id" : 256540769
    }, {
      "name" : "TopSuspense",
      "screen_name" : "TopSuspense",
      "indices" : [ 85, 97 ],
      "id_str" : "220879221",
      "id" : 220879221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "crime",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "suspense",
      "indices" : [ 114, 123 ]
    }, {
      "text" : "mystery",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59975889206775808",
  "text" : "RT @HarryShannon: PLS RT You connect to 12 award-winning authors with just one click @TOPSUSPENSE  #kindle #crime #suspense #mystery #bo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TopSuspense",
        "screen_name" : "TopSuspense",
        "indices" : [ 67, 79 ],
        "id_str" : "220879221",
        "id" : 220879221
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "crime",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "suspense",
        "indices" : [ 96, 105 ]
      }, {
        "text" : "mystery",
        "indices" : [ 106, 114 ]
      }, {
        "text" : "books",
        "indices" : [ 115, 121 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 122, 129 ]
      }, {
        "text" : "fiction",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59973397576294400",
    "text" : "PLS RT You connect to 12 award-winning authors with just one click @TOPSUSPENSE  #kindle #crime #suspense #mystery #books #ebooks #fiction",
    "id" : 59973397576294400,
    "created_at" : "2011-04-18 13:35:46 +0000",
    "user" : {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "protected" : false,
      "id_str" : "256540769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798645625289965568\/8ai82ECm_normal.jpg",
      "id" : 256540769,
      "verified" : false
    }
  },
  "id" : 59975889206775808,
  "created_at" : "2011-04-18 13:45:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rescue",
      "indices" : [ 56, 63 ]
    }, {
      "text" : "dog",
      "indices" : [ 64, 68 ]
    }, {
      "text" : "MD",
      "indices" : [ 69, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59946491317456896",
  "text" : "What a sad pic. Want to hug her! http:\/\/on.fb.me\/ht0Pau #rescue #dog #MD",
  "id" : 59946491317456896,
  "created_at" : "2011-04-18 11:48:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59796204351008768",
  "text" : "how true... http:\/\/amzn.com\/k\/19T7ZUNHFB66F #Kindle",
  "id" : 59796204351008768,
  "created_at" : "2011-04-18 01:51:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 0, 14 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59750855259332608",
  "geo" : { },
  "id_str" : "59755046069469184",
  "in_reply_to_user_id" : 244989679,
  "text" : "@GaribaldiRous big ((hugs)) 4 Melly. I could see how close they were.",
  "id" : 59755046069469184,
  "in_reply_to_status_id" : 59750855259332608,
  "created_at" : "2011-04-17 23:08:07 +0000",
  "in_reply_to_screen_name" : "GaribaldiRous",
  "in_reply_to_user_id_str" : "244989679",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59754684352700416",
  "text" : "RT @Buddhaworld: some people, and very few are aware of it, live only for one short moment to change history, like standing in the way o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59751018958831616",
    "text" : "some people, and very few are aware of it, live only for one short moment to change history, like standing in the way of a marksman.",
    "id" : 59751018958831616,
    "created_at" : "2011-04-17 22:52:07 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 59754684352700416,
  "created_at" : "2011-04-17 23:06:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59751018958831616",
  "geo" : { },
  "id_str" : "59754648894046208",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld I believe this to be so, I really do.",
  "id" : 59754648894046208,
  "in_reply_to_status_id" : 59751018958831616,
  "created_at" : "2011-04-17 23:06:33 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 71, 83 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59751563614367744",
  "geo" : { },
  "id_str" : "59754433722073089",
  "in_reply_to_user_id" : 40560386,
  "text" : "I have learned, like it or not, I DO matter. It's a weird feeling..lol @Buddhaworld",
  "id" : 59754433722073089,
  "in_reply_to_status_id" : 59751563614367744,
  "created_at" : "2011-04-17 23:05:41 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59754237185368064",
  "text" : "RT @Buddhaworld: many of us die, not even realising what important impact our humble existance made in the wheel of history.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59751563614367744",
    "text" : "many of us die, not even realising what important impact our humble existance made in the wheel of history.",
    "id" : 59751563614367744,
    "created_at" : "2011-04-17 22:54:17 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 59754237185368064,
  "created_at" : "2011-04-17 23:04:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59754139567136768",
  "text" : "RT @Buddhaworld: every creature has a special meaning to the universe, without it all would be different.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59751844938911744",
    "text" : "every creature has a special meaning to the universe, without it all would be different.",
    "id" : 59751844938911744,
    "created_at" : "2011-04-17 22:55:24 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 59754139567136768,
  "created_at" : "2011-04-17 23:04:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 3, 15 ],
      "id_str" : "11963132",
      "id" : 11963132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59750024569044992",
  "text" : "RT @whitneyhess: I am blessed. Think about it, and if you are too, please RT.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getscopeapp.com\" rel=\"nofollow\"\u003EScope App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59728110035288066",
    "text" : "I am blessed. Think about it, and if you are too, please RT.",
    "id" : 59728110035288066,
    "created_at" : "2011-04-17 21:21:05 +0000",
    "user" : {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "protected" : false,
      "id_str" : "11963132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798174174145560576\/VXOChW0c_normal.jpg",
      "id" : 11963132,
      "verified" : true
    }
  },
  "id" : 59750024569044992,
  "created_at" : "2011-04-17 22:48:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59749443276255233",
  "text" : "RT @JeremyCShipp: Life is like a box. A really big box filled with all sorts of stuff.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59737132197097472",
    "text" : "Life is like a box. A really big box filled with all sorts of stuff.",
    "id" : 59737132197097472,
    "created_at" : "2011-04-17 21:56:56 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 59749443276255233,
  "created_at" : "2011-04-17 22:45:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K-Med",
      "screen_name" : "Kevin__Medeiros",
      "indices" : [ 5, 21 ],
      "id_str" : "13374242",
      "id" : 13374242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "equality",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59749345528004608",
  "text" : "from @Kevin__Medeiros - facebook group \"Proudly Wear Pink\" http:\/\/j.mp\/fNdSXe This is in response to the recent J.Crew Ad #LGBT #equality",
  "id" : 59749345528004608,
  "created_at" : "2011-04-17 22:45:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Brown",
      "screen_name" : "FrugaleReader",
      "indices" : [ 3, 17 ],
      "id_str" : "199456136",
      "id" : 199456136
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Easter",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59659820336300034",
  "text" : "RT @FrugaleReader: #Easter (4\/24) just opened up for a sponsored Frugal Find of the Day on TFeR - If interested, please ping me to let m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Easter",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59657821549117440",
    "text" : "#Easter (4\/24) just opened up for a sponsored Frugal Find of the Day on TFeR - If interested, please ping me to let me know! :)",
    "id" : 59657821549117440,
    "created_at" : "2011-04-17 16:41:47 +0000",
    "user" : {
      "name" : "Elizabeth Brown",
      "screen_name" : "FrugaleReader",
      "protected" : false,
      "id_str" : "199456136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1322880132\/ETB_Photo_TEOTP_normal.jpg",
      "id" : 199456136,
      "verified" : false
    }
  },
  "id" : 59659820336300034,
  "created_at" : "2011-04-17 16:49:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59659681827782656",
  "text" : "I chatter to myself over at http:\/\/abfabgab.wordpress.com : )",
  "id" : 59659681827782656,
  "created_at" : "2011-04-17 16:49:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Wilson",
      "screen_name" : "LorraineWDC",
      "indices" : [ 3, 15 ],
      "id_str" : "22981318",
      "id" : 22981318
    }, {
      "name" : "Don Millard",
      "screen_name" : "OTOOLEFAN",
      "indices" : [ 20, 30 ],
      "id_str" : "27512951",
      "id" : 27512951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59651627484852224",
  "text" : "RT @LorraineWDC: RT @OTOOLEFAN: Sarah Palin was paid twice as much as what a teacher makes in a year to say teachers make too much money ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Don Millard",
        "screen_name" : "OTOOLEFAN",
        "indices" : [ 3, 13 ],
        "id_str" : "27512951",
        "id" : 27512951
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wiunion",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59650063894462464",
    "text" : "RT @OTOOLEFAN: Sarah Palin was paid twice as much as what a teacher makes in a year to say teachers make too much money.  #wiunion",
    "id" : 59650063894462464,
    "created_at" : "2011-04-17 16:10:58 +0000",
    "user" : {
      "name" : "Lorraine Wilson",
      "screen_name" : "LorraineWDC",
      "protected" : false,
      "id_str" : "22981318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083588661\/7a08d2f9-712b-4bc2-a92c-cb439e5ac043_normal.png",
      "id" : 22981318,
      "verified" : false
    }
  },
  "id" : 59651627484852224,
  "created_at" : "2011-04-17 16:17:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59638746190053376",
  "geo" : { },
  "id_str" : "59641609888862208",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep oh... tree limbs? lol",
  "id" : 59641609888862208,
  "in_reply_to_status_id" : 59638746190053376,
  "created_at" : "2011-04-17 15:37:22 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59638297831538689",
  "text" : "RT @DeepakChopra: \"Who am I ? \" is the most fundamental question.  The answer to it is the answer to all cosmic riddles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59636558311075840",
    "text" : "\"Who am I ? \" is the most fundamental question.  The answer to it is the answer to all cosmic riddles",
    "id" : 59636558311075840,
    "created_at" : "2011-04-17 15:17:18 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 59638297831538689,
  "created_at" : "2011-04-17 15:24:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 0, 13 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59632881730990080",
  "geo" : { },
  "id_str" : "59633700379443200",
  "in_reply_to_user_id" : 18306792,
  "text" : "@morsemusings back at ya! : )",
  "id" : 59633700379443200,
  "in_reply_to_status_id" : 59632881730990080,
  "created_at" : "2011-04-17 15:05:56 +0000",
  "in_reply_to_screen_name" : "morsemusings",
  "in_reply_to_user_id_str" : "18306792",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59629296452513792",
  "geo" : { },
  "id_str" : "59633513883910144",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH we love to feed birds, squirrels, crows & whomever else strolls thru..lol",
  "id" : 59633513883910144,
  "in_reply_to_status_id" : 59629296452513792,
  "created_at" : "2011-04-17 15:05:12 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 0, 13 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59616113960566784",
  "geo" : { },
  "id_str" : "59631519190360065",
  "in_reply_to_user_id" : 18306792,
  "text" : "@morsemusings me, too. INFP",
  "id" : 59631519190360065,
  "in_reply_to_status_id" : 59616113960566784,
  "created_at" : "2011-04-17 14:57:16 +0000",
  "in_reply_to_screen_name" : "morsemusings",
  "in_reply_to_user_id_str" : "18306792",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59631435392360448",
  "text" : "RT @morsemusings: Just took a FREE personality test http:\/\/bit.ly\/eU12Jm - I'm a Dreamy Idealist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59616113960566784",
    "text" : "Just took a FREE personality test http:\/\/bit.ly\/eU12Jm - I'm a Dreamy Idealist",
    "id" : 59616113960566784,
    "created_at" : "2011-04-17 13:56:03 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 59631435392360448,
  "created_at" : "2011-04-17 14:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "ejbe",
      "screen_name" : "ejbe",
      "indices" : [ 31, 36 ],
      "id_str" : "21027168",
      "id" : 21027168
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 38, 51 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59630563321069568",
  "text" : "RT @DeepakChopra: No--thing RT @ejbe: @DeepakChopra define \"nothing\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ejbe",
        "screen_name" : "ejbe",
        "indices" : [ 13, 18 ],
        "id_str" : "21027168",
        "id" : 21027168
      }, {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 20, 33 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59618744091148288",
    "text" : "No--thing RT @ejbe: @DeepakChopra define \"nothing\"",
    "id" : 59618744091148288,
    "created_at" : "2011-04-17 14:06:30 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 59630563321069568,
  "created_at" : "2011-04-17 14:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59630422883184640",
  "text" : "RT @DeepakChopra: Where does thought come from? Welcome your thoughts (wherever they come from :) )",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59619365196275713",
    "text" : "Where does thought come from? Welcome your thoughts (wherever they come from :) )",
    "id" : 59619365196275713,
    "created_at" : "2011-04-17 14:08:58 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 59630422883184640,
  "created_at" : "2011-04-17 14:52:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 8, 22 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59629283508891648",
  "text" : "Wishing @Wylieknowords a Birthday endued with joy. Wish him a HB with an unusual word!",
  "id" : 59629283508891648,
  "created_at" : "2011-04-17 14:48:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59627710724571136",
  "text" : "good morning my lovely tweeps!",
  "id" : 59627710724571136,
  "created_at" : "2011-04-17 14:42:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59423645872832512",
  "text" : "RT @BayBitch: I don't have issues. I have entire subscriptions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59421407251140608",
    "text" : "I don't have issues. I have entire subscriptions.",
    "id" : 59421407251140608,
    "created_at" : "2011-04-17 01:02:22 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 59423645872832512,
  "created_at" : "2011-04-17 01:11:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Rayburn",
      "screen_name" : "topshelfebooks",
      "indices" : [ 3, 18 ],
      "id_str" : "231431785",
      "id" : 231431785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59421918503243776",
  "text" : "RT @topshelfebooks: Help ConneryBeagle! http:\/\/nblo.gs\/gKbQi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59413702704758784",
    "text" : "Help ConneryBeagle! http:\/\/nblo.gs\/gKbQi",
    "id" : 59413702704758784,
    "created_at" : "2011-04-17 00:31:45 +0000",
    "user" : {
      "name" : "Misty Rayburn",
      "screen_name" : "topshelfebooks",
      "protected" : false,
      "id_str" : "231431785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704834759629938688\/o3bRCVgp_normal.jpg",
      "id" : 231431785,
      "verified" : false
    }
  },
  "id" : 59421918503243776,
  "created_at" : "2011-04-17 01:04:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Amtrak",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59410013793435648",
  "text" : "RT @ShhDragon: #Amtrak emergency update:  The harrowing end of civilization is nigh.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Amtrak",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59408278479831040",
    "text" : "#Amtrak emergency update:  The harrowing end of civilization is nigh.",
    "id" : 59408278479831040,
    "created_at" : "2011-04-17 00:10:12 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 59410013793435648,
  "created_at" : "2011-04-17 00:17:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59409505812881408",
  "text" : "RT @NewMindMirror: Is the Universe Fundamentally Inexplicable? The Hawking Paradox  (DOCUVIDEO 9 mins)  http:\/\/su.pr\/7RTl0W  #physics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "physics",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59407728623366144",
    "text" : "Is the Universe Fundamentally Inexplicable? The Hawking Paradox  (DOCUVIDEO 9 mins)  http:\/\/su.pr\/7RTl0W  #physics",
    "id" : 59407728623366144,
    "created_at" : "2011-04-17 00:08:00 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 59409505812881408,
  "created_at" : "2011-04-17 00:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59401009826496512",
  "geo" : { },
  "id_str" : "59403742881136640",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH its crazy windy here. been windy all day.",
  "id" : 59403742881136640,
  "in_reply_to_status_id" : 59401009826496512,
  "created_at" : "2011-04-16 23:52:10 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59391537385193472",
  "text" : "RT @SangyeH: I don't follow back peeps who engage in name-calling, even if we agree on politics.  \"Be the change u want to see in the wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59383728329338880",
    "text" : "I don't follow back peeps who engage in name-calling, even if we agree on politics.  \"Be the change u want to see in the world,\" u know?",
    "id" : 59383728329338880,
    "created_at" : "2011-04-16 22:32:38 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 59391537385193472,
  "created_at" : "2011-04-16 23:03:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59383728329338880",
  "geo" : { },
  "id_str" : "59387521779507200",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH ((handclapping)) : )",
  "id" : 59387521779507200,
  "in_reply_to_status_id" : 59383728329338880,
  "created_at" : "2011-04-16 22:47:43 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59359539539083264",
  "text" : "RT @drbloem: Hormone Replacement Success - Rhythmic Dosing versus Low-Dose Static Dosing http:\/\/bit.ly\/91bgUc #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59357564600713217",
    "text" : "Hormone Replacement Success - Rhythmic Dosing versus Low-Dose Static Dosing http:\/\/bit.ly\/91bgUc #health",
    "id" : 59357564600713217,
    "created_at" : "2011-04-16 20:48:40 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 59359539539083264,
  "created_at" : "2011-04-16 20:56:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59348877471531008",
  "geo" : { },
  "id_str" : "59358738385076224",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle yeah, there shld be by now...",
  "id" : 59358738385076224,
  "in_reply_to_status_id" : 59348877471531008,
  "created_at" : "2011-04-16 20:53:20 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59358433052344320",
  "text" : "RT @Reverend_Sue: RT @AdvocateGuy 2 go against the dominant thinking of ur friends, people u see every day is perhaps the most difficult ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59350135141969920",
    "text" : "RT @AdvocateGuy 2 go against the dominant thinking of ur friends, people u see every day is perhaps the most difficult act of heroism. #LGBT",
    "id" : 59350135141969920,
    "created_at" : "2011-04-16 20:19:09 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 59358433052344320,
  "created_at" : "2011-04-16 20:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "handmade",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59358363770814464",
  "text" : "RT @EarthLifeShop: Got that Moosy Feeling Treasury@Etsy: http:\/\/etsy.me\/fSe25L #handmade",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "handmade",
        "indices" : [ 60, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59350383629316096",
    "text" : "Got that Moosy Feeling Treasury@Etsy: http:\/\/etsy.me\/fSe25L #handmade",
    "id" : 59350383629316096,
    "created_at" : "2011-04-16 20:20:08 +0000",
    "user" : {
      "name" : "Dagmar Magdalena",
      "screen_name" : "BatyaHavDesign",
      "protected" : false,
      "id_str" : "25688058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602426519487647744\/kogV47_M_normal.jpg",
      "id" : 25688058,
      "verified" : false
    }
  },
  "id" : 59358363770814464,
  "created_at" : "2011-04-16 20:51:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greetingcard",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59358064846974976",
  "text" : "RT @EarthLifeShop: Moose with Me Photograph by Dagmar Magdalena Ceki -  Fine Art Prints and Posters http:\/\/bit.ly\/e6Ro8c #greetingcard # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "greetingcard",
        "indices" : [ 102, 115 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 116, 125 ]
      }, {
        "text" : "moose",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59352969589702656",
    "text" : "Moose with Me Photograph by Dagmar Magdalena Ceki -  Fine Art Prints and Posters http:\/\/bit.ly\/e6Ro8c #greetingcard #wildlife #moose",
    "id" : 59352969589702656,
    "created_at" : "2011-04-16 20:30:25 +0000",
    "user" : {
      "name" : "Dagmar Magdalena",
      "screen_name" : "BatyaHavDesign",
      "protected" : false,
      "id_str" : "25688058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602426519487647744\/kogV47_M_normal.jpg",
      "id" : 25688058,
      "verified" : false
    }
  },
  "id" : 59358064846974976,
  "created_at" : "2011-04-16 20:50:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59347518223421440",
  "text" : "it's a mental thing. weekends are extremely boring to me.",
  "id" : 59347518223421440,
  "created_at" : "2011-04-16 20:08:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59346386319187968",
  "geo" : { },
  "id_str" : "59347344205946880",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle which is why even as a youngster, had decided I wld not do rad, chemo if I ever got cancer.",
  "id" : 59347344205946880,
  "in_reply_to_status_id" : 59346386319187968,
  "created_at" : "2011-04-16 20:08:04 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59346386319187968",
  "geo" : { },
  "id_str" : "59346982015209472",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle at the risk of inciting ppl, I believe such treatments exist but are considered quackery, etc. Pharma rules healthcare.",
  "id" : 59346982015209472,
  "in_reply_to_status_id" : 59346386319187968,
  "created_at" : "2011-04-16 20:06:37 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59346060430151680",
  "text" : "So unusual, I keep yawning today. Having another cup o' joe...",
  "id" : 59346060430151680,
  "created_at" : "2011-04-16 20:02:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59345849368592384",
  "text" : "just finished reading The Trophy Hunter. Didn't really care for it.",
  "id" : 59345849368592384,
  "created_at" : "2011-04-16 20:02:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SMOOCH",
      "screen_name" : "Cheesyyeasty",
      "indices" : [ 3, 16 ],
      "id_str" : "245008738",
      "id" : 245008738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59337313972518912",
  "text" : "RT @Cheesyyeasty: Ahh hunting. There is nothing more life affirming than being out in nature and murdering it's inhabitants.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58921616331124736",
    "text" : "Ahh hunting. There is nothing more life affirming than being out in nature and murdering it's inhabitants.",
    "id" : 58921616331124736,
    "created_at" : "2011-04-15 15:56:22 +0000",
    "user" : {
      "name" : "SMOOCH",
      "screen_name" : "Cheesyyeasty",
      "protected" : false,
      "id_str" : "245008738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1251971967\/image_normal.jpg",
      "id" : 245008738,
      "verified" : false
    }
  },
  "id" : 59337313972518912,
  "created_at" : "2011-04-16 19:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59314003536650240",
  "text" : "no place to live.. either weather or laws.. eek!",
  "id" : 59314003536650240,
  "created_at" : "2011-04-16 17:55:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59293952607666177",
  "geo" : { },
  "id_str" : "59298783929962497",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time Japan is sinking?",
  "id" : 59298783929962497,
  "in_reply_to_status_id" : 59293952607666177,
  "created_at" : "2011-04-16 16:55:06 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59289751269806080",
  "text" : "RT @petsalive: http:\/\/yfrog.com\/h4v0h6j Baby squirrel cuteness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yfrog.com\" rel=\"nofollow\"\u003EYfrog\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59289239636025344",
    "text" : "http:\/\/yfrog.com\/h4v0h6j Baby squirrel cuteness.",
    "id" : 59289239636025344,
    "created_at" : "2011-04-16 16:17:10 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 59289751269806080,
  "created_at" : "2011-04-16 16:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Laube",
      "screen_name" : "TheAncientBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "155754927",
      "id" : 155754927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freebies",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59286690950426625",
  "text" : "RT @TheAncientBooks: Ancient Awakening free at Smashwords.  http:\/\/bit.ly\/gNCu8c   just use coupon \"ZL66E\".  Enjoy!  #freebies",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freebies",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59286507533508608",
    "text" : "Ancient Awakening free at Smashwords.  http:\/\/bit.ly\/gNCu8c   just use coupon \"ZL66E\".  Enjoy!  #freebies",
    "id" : 59286507533508608,
    "created_at" : "2011-04-16 16:06:19 +0000",
    "user" : {
      "name" : "Matthew Laube",
      "screen_name" : "TheAncientBooks",
      "protected" : false,
      "id_str" : "155754927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2374550641\/isswkigc6yzrowrlrh4d_normal.jpeg",
      "id" : 155754927,
      "verified" : false
    }
  },
  "id" : 59286690950426625,
  "created_at" : "2011-04-16 16:07:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59285979848130560",
  "geo" : { },
  "id_str" : "59286572243230720",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep Congrats!! there is something to be said for long term relationships. I've seen how hubs & I evolved together thru years. : )",
  "id" : 59286572243230720,
  "in_reply_to_status_id" : 59285979848130560,
  "created_at" : "2011-04-16 16:06:34 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59284516065386497",
  "geo" : { },
  "id_str" : "59285295731970048",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench sorry to hear that ((hugs))",
  "id" : 59285295731970048,
  "in_reply_to_status_id" : 59284516065386497,
  "created_at" : "2011-04-16 16:01:30 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59283834759413760",
  "geo" : { },
  "id_str" : "59285131524968449",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep Do you follow @Reverend_Sue ? She's BIG #LGBT supporter & she's awesome : )",
  "id" : 59285131524968449,
  "in_reply_to_status_id" : 59283834759413760,
  "created_at" : "2011-04-16 16:00:51 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "indices" : [ 3, 15 ],
      "id_str" : "17210956",
      "id" : 17210956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59282549511434240",
  "text" : "RT @kempruffner: Whenever I feel blue, I start breathing again",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59282416128368640",
    "text" : "Whenever I feel blue, I start breathing again",
    "id" : 59282416128368640,
    "created_at" : "2011-04-16 15:50:04 +0000",
    "user" : {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "protected" : false,
      "id_str" : "17210956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63757772\/china_bike_normal.jpg",
      "id" : 17210956,
      "verified" : false
    }
  },
  "id" : 59282549511434240,
  "created_at" : "2011-04-16 15:50:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrafficWave",
      "screen_name" : "trafficwave",
      "indices" : [ 3, 15 ],
      "id_str" : "19056688",
      "id" : 19056688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59282300076167168",
  "text" : "RT @trafficwave: Because it's worth repeating: \n\n\"Everyone is looking to get 'Results' fast. However, before anyone can get... http:\/\/fb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59278786138603520",
    "text" : "Because it's worth repeating: \n\n\"Everyone is looking to get 'Results' fast. However, before anyone can get... http:\/\/fb.me\/XK5vY5Kp",
    "id" : 59278786138603520,
    "created_at" : "2011-04-16 15:35:38 +0000",
    "user" : {
      "name" : "TrafficWave",
      "screen_name" : "trafficwave",
      "protected" : false,
      "id_str" : "19056688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722953530084990985\/g0_SQc_R_normal.jpg",
      "id" : 19056688,
      "verified" : false
    }
  },
  "id" : 59282300076167168,
  "created_at" : "2011-04-16 15:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59254590171914240",
  "text" : "RT @bunnybuddhism: A half-eaten carrot is not a matter of which half is gone and which remains; it is simply a half-eaten carrot.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59249892966674432",
    "text" : "A half-eaten carrot is not a matter of which half is gone and which remains; it is simply a half-eaten carrot.",
    "id" : 59249892966674432,
    "created_at" : "2011-04-16 13:40:49 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 59254590171914240,
  "created_at" : "2011-04-16 13:59:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 72, 84 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59063996355059712",
  "text" : "RT @ZachsMind: Cats are not owned: they choose to let you feed them. RT @GeorgeTakei: Your cat does not love you.  It tolerates you day  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Takei",
        "screen_name" : "GeorgeTakei",
        "indices" : [ 57, 69 ],
        "id_str" : "237845487",
        "id" : 237845487
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PurrDiem",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59057552540966912",
    "text" : "Cats are not owned: they choose to let you feed them. RT @GeorgeTakei: Your cat does not love you.  It tolerates you day to day.  #PurrDiem",
    "id" : 59057552540966912,
    "created_at" : "2011-04-16 00:56:32 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 59063996355059712,
  "created_at" : "2011-04-16 01:22:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59054427415379970",
  "text" : "RT @petsalive: Very last day to vote...until midnight tonight! If you didnt today, be sure to get it done! Plz! http:\/\/votetosavelives.org",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/\" rel=\"nofollow\"\u003ETwitBird iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59044130763968512",
    "text" : "Very last day to vote...until midnight tonight! If you didnt today, be sure to get it done! Plz! http:\/\/votetosavelives.org",
    "id" : 59044130763968512,
    "created_at" : "2011-04-16 00:03:12 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 59054427415379970,
  "created_at" : "2011-04-16 00:44:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59023838993850368",
  "text" : "and what is life.. but a long game? : )",
  "id" : 59023838993850368,
  "created_at" : "2011-04-15 22:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 3, 13 ],
      "id_str" : "41457590",
      "id" : 41457590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59023723767934976",
  "text" : "RT @38harmony: ~ I don't get nervous in any situation. There's no such thing as nerves when you're playing games.  ~ Shaquille O'Neal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59014794627387392",
    "text" : "~ I don't get nervous in any situation. There's no such thing as nerves when you're playing games.  ~ Shaquille O'Neal",
    "id" : 59014794627387392,
    "created_at" : "2011-04-15 22:06:38 +0000",
    "user" : {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "protected" : false,
      "id_str" : "41457590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1671334755\/2-HH-5-27-7_normal.jpg",
      "id" : 41457590,
      "verified" : false
    }
  },
  "id" : 59023723767934976,
  "created_at" : "2011-04-15 22:42:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "indices" : [ 3, 15 ],
      "id_str" : "17210956",
      "id" : 17210956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59014011794112513",
  "text" : "RT @kempruffner: If laughter is the best medicine this means logically that comedians are drug dealers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59008116045512705",
    "text" : "If laughter is the best medicine this means logically that comedians are drug dealers.",
    "id" : 59008116045512705,
    "created_at" : "2011-04-15 21:40:05 +0000",
    "user" : {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "protected" : false,
      "id_str" : "17210956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63757772\/china_bike_normal.jpg",
      "id" : 17210956,
      "verified" : false
    }
  },
  "id" : 59014011794112513,
  "created_at" : "2011-04-15 22:03:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59012969039790080",
  "text" : "Im so proud Im her mother...",
  "id" : 59012969039790080,
  "created_at" : "2011-04-15 21:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58986090706636800",
  "text" : "I watched new for awhile. Dont think Ive seen most recent eps.",
  "id" : 58986090706636800,
  "created_at" : "2011-04-15 20:12:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58985722484502528",
  "text" : "watching old Law & Order show",
  "id" : 58985722484502528,
  "created_at" : "2011-04-15 20:11:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "theology",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "bible",
      "indices" : [ 123, 129 ]
    }, {
      "text" : "uu",
      "indices" : [ 130, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/lHguBQs",
      "expanded_url" : "http:\/\/www.crystalstmarielewis.com\/2011\/04\/seven-reasons-why-i-dont-believe-in.html",
      "display_url" : "crystalstmarielewis.com\/2011\/04\/seven-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "58985423208321024",
  "text" : "RT @CrystalLewis: Latest blog post: Seven Reasons Why I Don't Believe In Hell ... http:\/\/t.co\/lHguBQs  #religion #theology #bible #uu #u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "religion",
        "indices" : [ 85, 94 ]
      }, {
        "text" : "theology",
        "indices" : [ 95, 104 ]
      }, {
        "text" : "bible",
        "indices" : [ 105, 111 ]
      }, {
        "text" : "uu",
        "indices" : [ 112, 115 ]
      }, {
        "text" : "uua",
        "indices" : [ 116, 120 ]
      }, {
        "text" : "faith",
        "indices" : [ 121, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http:\/\/t.co\/lHguBQs",
        "expanded_url" : "http:\/\/www.crystalstmarielewis.com\/2011\/04\/seven-reasons-why-i-dont-believe-in.html",
        "display_url" : "crystalstmarielewis.com\/2011\/04\/seven-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "58982435597205504",
    "text" : "Latest blog post: Seven Reasons Why I Don't Believe In Hell ... http:\/\/t.co\/lHguBQs  #religion #theology #bible #uu #uua #faith",
    "id" : 58982435597205504,
    "created_at" : "2011-04-15 19:58:03 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 58985423208321024,
  "created_at" : "2011-04-15 20:09:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58984024307286016",
  "geo" : { },
  "id_str" : "58985234292670465",
  "in_reply_to_user_id" : 23539037,
  "text" : "@RMoGib Not me. Phone is evil. I avoid at all cost.",
  "id" : 58985234292670465,
  "in_reply_to_status_id" : 58984024307286016,
  "created_at" : "2011-04-15 20:09:10 +0000",
  "in_reply_to_screen_name" : "OhYouGirl",
  "in_reply_to_user_id_str" : "23539037",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baron Barmy Bonkers",
      "screen_name" : "SirRanty",
      "indices" : [ 0, 9 ],
      "id_str" : "120808660",
      "id" : 120808660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58983589202755584",
  "geo" : { },
  "id_str" : "58985131834224640",
  "in_reply_to_user_id" : 120808660,
  "text" : "@SirRanty old V or new V?",
  "id" : 58985131834224640,
  "in_reply_to_status_id" : 58983589202755584,
  "created_at" : "2011-04-15 20:08:45 +0000",
  "in_reply_to_screen_name" : "SirRanty",
  "in_reply_to_user_id_str" : "120808660",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58978254794670080",
  "text" : "I love my Kindle. Feel free to hate me for it.",
  "id" : 58978254794670080,
  "created_at" : "2011-04-15 19:41:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58978056227921920",
  "text" : "Most of politics is out of the vortex.",
  "id" : 58978056227921920,
  "created_at" : "2011-04-15 19:40:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 3, 19 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58965894805721088",
  "text" : "RT @simonwoodwrites: A LITTLE SOMETHING FOR THE WEEKEND: Just because it made me laugh.\n\"God forgives you. Yes. Even for that.\"\n~A Local ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58962943173337088",
    "text" : "A LITTLE SOMETHING FOR THE WEEKEND: Just because it made me laugh.\n\"God forgives you. Yes. Even for that.\"\n~A Local Church Message board",
    "id" : 58962943173337088,
    "created_at" : "2011-04-15 18:40:35 +0000",
    "user" : {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "protected" : false,
      "id_str" : "30077179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786815188955570176\/XPC8uW7z_normal.jpg",
      "id" : 30077179,
      "verified" : false
    }
  },
  "id" : 58965894805721088,
  "created_at" : "2011-04-15 18:52:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58948206066802688",
  "text" : "Mass. mom who withheld son's meds gets 8-10 years http:\/\/yhoo.it\/gLVK5i",
  "id" : 58948206066802688,
  "created_at" : "2011-04-15 17:42:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58939503531921408",
  "text" : "RT @hauntedcomputer: tracking down the people who unfollow you always sounds creepy to me. If everybody likes you, you ain't saying nothing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58937144806350848",
    "text" : "tracking down the people who unfollow you always sounds creepy to me. If everybody likes you, you ain't saying nothing",
    "id" : 58937144806350848,
    "created_at" : "2011-04-15 16:58:04 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 58939503531921408,
  "created_at" : "2011-04-15 17:07:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58939104313880576",
  "text" : "RT @Moonrust: Hungarian Collector Shows Off World\u2019s Smallest Library http:\/\/bit.ly\/eKdvw9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58935328131645442",
    "text" : "Hungarian Collector Shows Off World\u2019s Smallest Library http:\/\/bit.ly\/eKdvw9",
    "id" : 58935328131645442,
    "created_at" : "2011-04-15 16:50:51 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 58939104313880576,
  "created_at" : "2011-04-15 17:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58935966454390784",
  "text" : "RT @HealthRanger: Armed agents kidnap child from mother who used holistic treatments instead of pharmaceutical drugs. http:\/\/ow.ly\/4BaVl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 119, 126 ]
      }, {
        "text" : "naturalnews",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58933481287331840",
    "text" : "Armed agents kidnap child from mother who used holistic treatments instead of pharmaceutical drugs. http:\/\/ow.ly\/4BaVl #health #naturalnews",
    "id" : 58933481287331840,
    "created_at" : "2011-04-15 16:43:31 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 58935966454390784,
  "created_at" : "2011-04-15 16:53:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 70, 83 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58934069777547264",
  "text" : "Torturing someone for eternity is not \"justice.\" http:\/\/bit.ly\/gy9GGZ @CrystalLewis",
  "id" : 58934069777547264,
  "created_at" : "2011-04-15 16:45:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AbrahamHicks",
      "indices" : [ 88, 101 ]
    }, {
      "text" : "LoA",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "Abraham",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "quotes",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58932100572774400",
  "text" : "RT @abe_quotes: ...Give your attention to something, anything, other than the illness.\n\n#AbrahamHicks #LoA #Abraham #quotes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AbrahamHicks",
        "indices" : [ 72, 85 ]
      }, {
        "text" : "LoA",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "Abraham",
        "indices" : [ 91, 99 ]
      }, {
        "text" : "quotes",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58931932980969473",
    "text" : "...Give your attention to something, anything, other than the illness.\n\n#AbrahamHicks #LoA #Abraham #quotes",
    "id" : 58931932980969473,
    "created_at" : "2011-04-15 16:37:22 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 58932100572774400,
  "created_at" : "2011-04-15 16:38:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58932086966452224",
  "text" : "RT @abe_quotes: In every moment that you are thinking about the illness, you are adding a little more fuel to the fire, so to speak...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58931926593056768",
    "text" : "In every moment that you are thinking about the illness, you are adding a little more fuel to the fire, so to speak...",
    "id" : 58931926593056768,
    "created_at" : "2011-04-15 16:37:20 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 58932086966452224,
  "created_at" : "2011-04-15 16:37:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58928122640334848",
  "geo" : { },
  "id_str" : "58931025060954112",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulzMayBe big ((hugs))",
  "id" : 58931025060954112,
  "in_reply_to_status_id" : 58928122640334848,
  "created_at" : "2011-04-15 16:33:45 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Lamb",
      "screen_name" : "KristenLambTX",
      "indices" : [ 3, 17 ],
      "id_str" : "15202253",
      "id" : 15202253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58929982520569856",
  "text" : "RT @KristenLambTX: Does LIKING an author matter? If a writer is a jerk, will u stop buying his books? Give ur opinion http:\/\/bit.ly\/ec8C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pubtip",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58914481035685888",
    "text" : "Does LIKING an author matter? If a writer is a jerk, will u stop buying his books? Give ur opinion http:\/\/bit.ly\/ec8Cpe #pubtip #amwriting",
    "id" : 58914481035685888,
    "created_at" : "2011-04-15 15:28:01 +0000",
    "user" : {
      "name" : "Kristen Lamb",
      "screen_name" : "KristenLambTX",
      "protected" : false,
      "id_str" : "15202253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666377447646990336\/koaddexv_normal.png",
      "id" : 15202253,
      "verified" : false
    }
  },
  "id" : 58929982520569856,
  "created_at" : "2011-04-15 16:29:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Lucado",
      "screen_name" : "MaxLucado",
      "indices" : [ 3, 13 ],
      "id_str" : "16588111",
      "id" : 16588111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58929820754649088",
  "text" : "RT @MaxLucado: My wife says that introverts tweet more than extroverts. Agree or disagree?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58916987740504064",
    "text" : "My wife says that introverts tweet more than extroverts. Agree or disagree?",
    "id" : 58916987740504064,
    "created_at" : "2011-04-15 15:37:59 +0000",
    "user" : {
      "name" : "Max Lucado",
      "screen_name" : "MaxLucado",
      "protected" : false,
      "id_str" : "16588111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571678568280801280\/mNmWsHTN_normal.jpeg",
      "id" : 16588111,
      "verified" : true
    }
  },
  "id" : 58929820754649088,
  "created_at" : "2011-04-15 16:28:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58920143186706432",
  "geo" : { },
  "id_str" : "58929513232470016",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles Im a sheep person myself.. but I like you anyway ; )",
  "id" : 58929513232470016,
  "in_reply_to_status_id" : 58920143186706432,
  "created_at" : "2011-04-15 16:27:45 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Defenders Wildlife",
      "screen_name" : "Defenders",
      "indices" : [ 3, 13 ],
      "id_str" : "15309072",
      "id" : 15309072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winforwildlife",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58928780089110529",
  "text" : "RT @Defenders: #winforwildlife! Bison now have 75,000 more acres to roam free in Montana.\nhttp:\/\/dfnd.us\/gJC16U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smallact.com\/\" rel=\"nofollow\"\u003ESMX:Thrive\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "winforwildlife",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58925851328258048",
    "text" : "#winforwildlife! Bison now have 75,000 more acres to roam free in Montana.\nhttp:\/\/dfnd.us\/gJC16U",
    "id" : 58925851328258048,
    "created_at" : "2011-04-15 16:13:12 +0000",
    "user" : {
      "name" : "Defenders Wildlife",
      "screen_name" : "Defenders",
      "protected" : false,
      "id_str" : "15309072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1152365714\/DOW-color-logo_twitter_normal.jpg",
      "id" : 15309072,
      "verified" : false
    }
  },
  "id" : 58928780089110529,
  "created_at" : "2011-04-15 16:24:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 113, 123 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58911384817250304",
  "text" : "RT @TyrusBooks: 1st 50 pages available of future Tyrus titles. Scott O'Connor's UNTOUCHABLE http:\/\/bit.ly\/gyslvT @bcmystery COUNTY LINE  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Cameron",
        "screen_name" : "bcmystery",
        "indices" : [ 97, 107 ],
        "id_str" : "14428947",
        "id" : 14428947
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58903390670958592",
    "text" : "1st 50 pages available of future Tyrus titles. Scott O'Connor's UNTOUCHABLE http:\/\/bit.ly\/gyslvT @bcmystery COUNTY LINE http:\/\/bit.ly\/eHabl2",
    "id" : 58903390670958592,
    "created_at" : "2011-04-15 14:43:57 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 58911384817250304,
  "created_at" : "2011-04-15 15:15:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58908164946526208",
  "geo" : { },
  "id_str" : "58910558258348032",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle ((hugs)) I hate the idea of anyone in pain.",
  "id" : 58910558258348032,
  "in_reply_to_status_id" : 58908164946526208,
  "created_at" : "2011-04-15 15:12:26 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58907300567597056",
  "text" : "RT @petsalive: Be sure to scroll down to NY -Pets Alive Animal Sanctuary (There are other Pets Alive so make sure you pick NY!). http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58884570443022337",
    "text" : "Be sure to scroll down to NY -Pets Alive Animal Sanctuary (There are other Pets Alive so make sure you pick NY!). http:\/\/votetosavelives.org",
    "id" : 58884570443022337,
    "created_at" : "2011-04-15 13:29:10 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 58907300567597056,
  "created_at" : "2011-04-15 14:59:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 0, 9 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58890788188327939",
  "geo" : { },
  "id_str" : "58891825586515969",
  "in_reply_to_user_id" : 46375814,
  "text" : "@BayBitch lol",
  "id" : 58891825586515969,
  "in_reply_to_status_id" : 58890788188327939,
  "created_at" : "2011-04-15 13:58:00 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58890578120814592",
  "text" : "RT @CrystalLewis: My tastebuds said: \"Thank you for the McGriddle\" but my digestive system is now saying \"Why in the world did you send  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58890078117834752",
    "text" : "My tastebuds said: \"Thank you for the McGriddle\" but my digestive system is now saying \"Why in the world did you send that thing down here?\"",
    "id" : 58890078117834752,
    "created_at" : "2011-04-15 13:51:03 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 58890578120814592,
  "created_at" : "2011-04-15 13:53:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 16, 27 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58890348293922817",
  "text" : "RT @TyrusBooks: @moosebegab Good books beget good books beget good reading. Who am I to get in the way of all that begetting?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "58888821701484545",
    "geo" : { },
    "id_str" : "58889649485119489",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab Good books beget good books beget good reading. Who am I to get in the way of all that begetting?",
    "id" : 58889649485119489,
    "in_reply_to_status_id" : 58888821701484545,
    "created_at" : "2011-04-15 13:49:21 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 58890348293922817,
  "created_at" : "2011-04-15 13:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 0, 9 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58888894808207360",
  "geo" : { },
  "id_str" : "58890149777522688",
  "in_reply_to_user_id" : 46375814,
  "text" : "@BayBitch exicting? that's a new one... but sounds good to me. I have cover for my K3 but still check them out..hehe",
  "id" : 58890149777522688,
  "in_reply_to_status_id" : 58888894808207360,
  "created_at" : "2011-04-15 13:51:20 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "indices" : [ 70, 85 ],
      "id_str" : "233966512",
      "id" : 233966512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58886188957835264",
  "geo" : { },
  "id_str" : "58889520988426240",
  "in_reply_to_user_id" : 233966512,
  "text" : "waiting for kindle version : ) (I saw your note on site..it's coming) @authorkingsley",
  "id" : 58889520988426240,
  "in_reply_to_status_id" : 58886188957835264,
  "created_at" : "2011-04-15 13:48:50 +0000",
  "in_reply_to_screen_name" : "authorkingsley",
  "in_reply_to_user_id_str" : "233966512",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CTState Library",
      "screen_name" : "LibraryofCT",
      "indices" : [ 3, 15 ],
      "id_str" : "72633501",
      "id" : 72633501
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebooks",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58888947861954560",
  "text" : "RT @LibraryofCT: 'But You Can't Sign eBooks?' Well, Now You Can! http:\/\/ow.ly\/4Az8i via Time.com #ebooks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebooks",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58885221176721408",
    "text" : "'But You Can't Sign eBooks?' Well, Now You Can! http:\/\/ow.ly\/4Az8i via Time.com #ebooks",
    "id" : 58885221176721408,
    "created_at" : "2011-04-15 13:31:45 +0000",
    "user" : {
      "name" : "CTState Library",
      "screen_name" : "LibraryofCT",
      "protected" : false,
      "id_str" : "72633501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596049150485069824\/M-L7kJPh_normal.jpg",
      "id" : 72633501,
      "verified" : false
    }
  },
  "id" : 58888947861954560,
  "created_at" : "2011-04-15 13:46:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 56, 67 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58887389598318592",
  "geo" : { },
  "id_str" : "58888821701484545",
  "in_reply_to_user_id" : 67336993,
  "text" : "omg'ness.. again? you're giving away the store! LOL ; ) @TyrusBooks",
  "id" : 58888821701484545,
  "in_reply_to_status_id" : 58887389598318592,
  "created_at" : "2011-04-15 13:46:03 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Abella Studios",
      "screen_name" : "abellastudios",
      "indices" : [ 22, 36 ],
      "id_str" : "108475858",
      "id" : 108475858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58710774356508672",
  "text" : "RT @Dwayne_Reaves: RT @abellastudios: Do everything with Love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Abella Studios",
        "screen_name" : "abellastudios",
        "indices" : [ 3, 17 ],
        "id_str" : "108475858",
        "id" : 108475858
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58706787662168064",
    "text" : "RT @abellastudios: Do everything with Love.",
    "id" : 58706787662168064,
    "created_at" : "2011-04-15 01:42:43 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 58710774356508672,
  "created_at" : "2011-04-15 01:58:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "indices" : [ 3, 16 ],
      "id_str" : "15175368",
      "id" : 15175368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "willferrell",
      "indices" : [ 95, 107 ]
    }, {
      "text" : "theoffice",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58701005310787584",
  "text" : "RT @theofficenbc: Stoked that Deangelo Vickers is trending!!! Boom! This is why our fans rock. #willferrell #theoffice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "willferrell",
        "indices" : [ 77, 89 ]
      }, {
        "text" : "theoffice",
        "indices" : [ 90, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58700774905098240",
    "text" : "Stoked that Deangelo Vickers is trending!!! Boom! This is why our fans rock. #willferrell #theoffice",
    "id" : 58700774905098240,
    "created_at" : "2011-04-15 01:18:50 +0000",
    "user" : {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "protected" : false,
      "id_str" : "15175368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3672312614\/17217191debc391b060a6798b6c2ad10_normal.jpeg",
      "id" : 15175368,
      "verified" : true
    }
  },
  "id" : 58701005310787584,
  "created_at" : "2011-04-15 01:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "indices" : [ 3, 16 ],
      "id_str" : "15175368",
      "id" : 15175368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheOffice",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "willferrell",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58696955085324288",
  "text" : "RT @theofficenbc: Hey #TheOffice fans! Let's gets #willferrell trending tonight, shall we? Deangelo Vickers deserves it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheOffice",
        "indices" : [ 4, 14 ]
      }, {
        "text" : "willferrell",
        "indices" : [ 32, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58696880154087424",
    "text" : "Hey #TheOffice fans! Let's gets #willferrell trending tonight, shall we? Deangelo Vickers deserves it!",
    "id" : 58696880154087424,
    "created_at" : "2011-04-15 01:03:21 +0000",
    "user" : {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "protected" : false,
      "id_str" : "15175368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3672312614\/17217191debc391b060a6798b6c2ad10_normal.jpeg",
      "id" : 15175368,
      "verified" : true
    }
  },
  "id" : 58696955085324288,
  "created_at" : "2011-04-15 01:03:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58665151498432514",
  "text" : "RT @petsalive: Scary.  Just today and tomorrow left and we dropped to #50. If we drop to 51 we are OUT. PLEASE VOTE, FB & RT! http:\/\/vot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58517715769507841",
    "text" : "Scary.  Just today and tomorrow left and we dropped to #50. If we drop to 51 we are OUT. PLEASE VOTE, FB & RT! http:\/\/votetosavelives.org",
    "id" : 58517715769507841,
    "created_at" : "2011-04-14 13:11:25 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 58665151498432514,
  "created_at" : "2011-04-14 22:57:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58620744669724672",
  "text" : "RT @BayBitch: only a lawyer would send an 8 pg doc. that was 7 pgs of instructions for one question.....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58618751507116032",
    "text" : "only a lawyer would send an 8 pg doc. that was 7 pgs of instructions for one question.....",
    "id" : 58618751507116032,
    "created_at" : "2011-04-14 19:52:54 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 58620744669724672,
  "created_at" : "2011-04-14 20:00:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 56, 64 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/44c0K1L",
      "expanded_url" : "http:\/\/kindle401.com\/contests\/free-kindle-gelaskins-promotion\/",
      "display_url" : "kindle401.com\/contests\/free-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "58616853672636418",
  "text" : "Free Kindle Gelaskins Promotion http:\/\/t.co\/44c0K1L via @AddThis",
  "id" : 58616853672636418,
  "created_at" : "2011-04-14 19:45:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58610379911204864",
  "text" : "RT @paulocoelho: It is not too late to be what you might have been, right?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58610022749446144",
    "text" : "It is not too late to be what you might have been, right?",
    "id" : 58610022749446144,
    "created_at" : "2011-04-14 19:18:13 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 58610379911204864,
  "created_at" : "2011-04-14 19:19:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58607825630396417",
  "geo" : { },
  "id_str" : "58609044709064704",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books hehe ((hugs)) I feel like I have much to do yet. But it will sure feel good when time comes to fly free (no body) : )",
  "id" : 58609044709064704,
  "in_reply_to_status_id" : 58607825630396417,
  "created_at" : "2011-04-14 19:14:19 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58607237693845505",
  "text" : "my only concern of leaving my earthly life is my daughter. how she would cope, etc. she's so sensitive.",
  "id" : 58607237693845505,
  "created_at" : "2011-04-14 19:07:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58606994608766976",
  "text" : "im only 45. the thought of living another 20 - 30 yrs w this body and its issues does not thrill me at all.",
  "id" : 58606994608766976,
  "created_at" : "2011-04-14 19:06:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58606692144910336",
  "text" : "after the first hour I have to make an effort to see on my laptop. starts to blur. eyes hurt. bleh.",
  "id" : 58606692144910336,
  "created_at" : "2011-04-14 19:04:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58605910834159616",
  "text" : "RT @FreeRangeKids: Now we're supposed to be scared every time a van is parked next to us in the parking lot? http:\/\/aol.it\/eApeX3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58604552835969024",
    "text" : "Now we're supposed to be scared every time a van is parked next to us in the parking lot? http:\/\/aol.it\/eApeX3",
    "id" : 58604552835969024,
    "created_at" : "2011-04-14 18:56:28 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 58605910834159616,
  "created_at" : "2011-04-14 19:01:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baron Barmy Bonkers",
      "screen_name" : "SirRanty",
      "indices" : [ 3, 12 ],
      "id_str" : "120808660",
      "id" : 120808660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58604924367417346",
  "text" : "RT @SirRanty: *silence*.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58596544315793409",
    "text" : "*silence*.",
    "id" : 58596544315793409,
    "created_at" : "2011-04-14 18:24:39 +0000",
    "user" : {
      "name" : "Baron Barmy Bonkers",
      "screen_name" : "SirRanty",
      "protected" : true,
      "id_str" : "120808660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628637036820492293\/pls07J1q_normal.jpg",
      "id" : 120808660,
      "verified" : false
    }
  },
  "id" : 58604924367417346,
  "created_at" : "2011-04-14 18:57:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "indices" : [ 19, 29 ],
      "id_str" : "15368940",
      "id" : 15368940
    }, {
      "name" : "Leadfoot _LA",
      "screen_name" : "Leadfoot_LA",
      "indices" : [ 34, 46 ],
      "id_str" : "244622806",
      "id" : 244622806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58595372456624128",
  "text" : "RT @mimismutts: RT @GottaLaff: RT @Leadfoot_LA: Palin's faked pregnancy hits Gawker: http:\/\/gawker.com\/#!5791915\/di. \/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laffy",
        "screen_name" : "GottaLaff",
        "indices" : [ 3, 13 ],
        "id_str" : "15368940",
        "id" : 15368940
      }, {
        "name" : "Leadfoot _LA",
        "screen_name" : "Leadfoot_LA",
        "indices" : [ 18, 30 ],
        "id_str" : "244622806",
        "id" : 244622806
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58592073527468032",
    "text" : "RT @GottaLaff: RT @Leadfoot_LA: Palin's faked pregnancy hits Gawker: http:\/\/gawker.com\/#!5791915\/di. \/",
    "id" : 58592073527468032,
    "created_at" : "2011-04-14 18:06:53 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 58595372456624128,
  "created_at" : "2011-04-14 18:20:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58590331704320000",
  "text" : "my eyes hurt.",
  "id" : 58590331704320000,
  "created_at" : "2011-04-14 17:59:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E.J. Stevens",
      "screen_name" : "EJStevensAuthor",
      "indices" : [ 3, 19 ],
      "id_str" : "75689163",
      "id" : 75689163
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpiritGuideSeries",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58574959299149824",
  "text" : "RT @EJStevensAuthor: E.J.'s Teen Lit Day Giveaway! Tweet to win YA #SpiritGuideSeries ebooks. Easy peasy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SpiritGuideSeries",
        "indices" : [ 46, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58566913579692032",
    "text" : "E.J.'s Teen Lit Day Giveaway! Tweet to win YA #SpiritGuideSeries ebooks. Easy peasy!",
    "id" : 58566913579692032,
    "created_at" : "2011-04-14 16:26:54 +0000",
    "user" : {
      "name" : "E.J. Stevens",
      "screen_name" : "EJStevensAuthor",
      "protected" : false,
      "id_str" : "75689163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447882314513543168\/eRVcCOBG_normal.jpeg",
      "id" : 75689163,
      "verified" : false
    }
  },
  "id" : 58574959299149824,
  "created_at" : "2011-04-14 16:58:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "indices" : [ 3, 15 ],
      "id_str" : "45727491",
      "id" : 45727491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58574726028738560",
  "text" : "RT @kindleworld: More quotes from Amazon re $114 KindleSO + ads-in-ebooks requested by a columnist, & other oddities. http:\/\/bit.ly\/kwk3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58568927755767809",
    "text" : "More quotes from Amazon re $114 KindleSO + ads-in-ebooks requested by a columnist, & other oddities. http:\/\/bit.ly\/kwk3so #kindle",
    "id" : 58568927755767809,
    "created_at" : "2011-04-14 16:34:55 +0000",
    "user" : {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "protected" : false,
      "id_str" : "45727491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477176032563167233\/rnTxZldx_normal.jpeg",
      "id" : 45727491,
      "verified" : false
    }
  },
  "id" : 58574726028738560,
  "created_at" : "2011-04-14 16:57:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B.J. Novak",
      "screen_name" : "bjnovak",
      "indices" : [ 3, 11 ],
      "id_str" : "28644174",
      "id" : 28644174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheOffice",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58574258720346114",
  "text" : "RT @bjnovak: Will Ferrell joins #TheOffice tonight as new manager Deangelo Vickers. April 14th, 9pm, NBC.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheOffice",
        "indices" : [ 19, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58555436521099265",
    "text" : "Will Ferrell joins #TheOffice tonight as new manager Deangelo Vickers. April 14th, 9pm, NBC.",
    "id" : 58555436521099265,
    "created_at" : "2011-04-14 15:41:18 +0000",
    "user" : {
      "name" : "B.J. Novak",
      "screen_name" : "bjnovak",
      "protected" : false,
      "id_str" : "28644174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740436182107049984\/y0N8Sqbi_normal.jpg",
      "id" : 28644174,
      "verified" : true
    }
  },
  "id" : 58574258720346114,
  "created_at" : "2011-04-14 16:56:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 3, 16 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58561627842297856",
  "text" : "RT @GoblinWriter: 5 Medical Science Fiction Ebooks for $3 or Less -- http:\/\/bit.ly\/f181lg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58560321828298752",
    "text" : "5 Medical Science Fiction Ebooks for $3 or Less -- http:\/\/bit.ly\/f181lg",
    "id" : 58560321828298752,
    "created_at" : "2011-04-14 16:00:43 +0000",
    "user" : {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "protected" : false,
      "id_str" : "95730042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1558192985\/goblin-pic_normal.jpg",
      "id" : 95730042,
      "verified" : false
    }
  },
  "id" : 58561627842297856,
  "created_at" : "2011-04-14 16:05:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleAuthors",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58550181716688896",
  "text" : "#KindleAuthors Tell your story on Kinderati.\n\nOne of the best ways to provoke interest in your book is to tell (cont) http:\/\/tl.gd\/9rgek8",
  "id" : 58550181716688896,
  "created_at" : "2011-04-14 15:20:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baron Barmy Bonkers",
      "screen_name" : "SirRanty",
      "indices" : [ 0, 9 ],
      "id_str" : "120808660",
      "id" : 120808660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58536404594077696",
  "geo" : { },
  "id_str" : "58537166095122432",
  "in_reply_to_user_id" : 120808660,
  "text" : "@SirRanty Nope",
  "id" : 58537166095122432,
  "in_reply_to_status_id" : 58536404594077696,
  "created_at" : "2011-04-14 14:28:42 +0000",
  "in_reply_to_screen_name" : "SirRanty",
  "in_reply_to_user_id_str" : "120808660",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndieHorror.org",
      "screen_name" : "IndieHorror",
      "indices" : [ 3, 15 ],
      "id_str" : "229531530",
      "id" : 229531530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58533638983270401",
  "text" : "RT @IndieHorror: Network with other horror authors using more than 140 characters at http:\/\/IndieHorror.org\/ =) We'd love to have you ar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58533032625319936",
    "text" : "Network with other horror authors using more than 140 characters at http:\/\/IndieHorror.org\/ =) We'd love to have you around!",
    "id" : 58533032625319936,
    "created_at" : "2011-04-14 14:12:17 +0000",
    "user" : {
      "name" : "IndieHorror.org",
      "screen_name" : "IndieHorror",
      "protected" : false,
      "id_str" : "229531530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1227488379\/IndieTwitter_normal.png",
      "id" : 229531530,
      "verified" : false
    }
  },
  "id" : 58533638983270401,
  "created_at" : "2011-04-14 14:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58533159234584576",
  "text" : "RT @BayBitch: I like being 55. I can now take advantage of the \"senior\" menus... I no longer get carded for alcohol, but I do get carded ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58532661098061825",
    "text" : "I like being 55. I can now take advantage of the \"senior\" menus... I no longer get carded for alcohol, but I do get carded for food!",
    "id" : 58532661098061825,
    "created_at" : "2011-04-14 14:10:48 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 58533159234584576,
  "created_at" : "2011-04-14 14:12:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Finder",
      "screen_name" : "JoeFinder",
      "indices" : [ 3, 13 ],
      "id_str" : "20776696",
      "id" : 20776696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58532018887204865",
  "text" : "RT @JoeFinder: Congratulations to this year's Thriller Award nominees! http:\/\/thrillerwriters.org\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58523880851111937",
    "text" : "Congratulations to this year's Thriller Award nominees! http:\/\/thrillerwriters.org\/",
    "id" : 58523880851111937,
    "created_at" : "2011-04-14 13:35:55 +0000",
    "user" : {
      "name" : "Joseph Finder",
      "screen_name" : "JoeFinder",
      "protected" : false,
      "id_str" : "20776696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712726103652245504\/g3GVe5Wm_normal.jpg",
      "id" : 20776696,
      "verified" : true
    }
  },
  "id" : 58532018887204865,
  "created_at" : "2011-04-14 14:08:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58531071209381888",
  "text" : "RT @JimBrownBooks: I need new running shoes because my current shoes insist on walking #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 68, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58530128120123392",
    "text" : "I need new running shoes because my current shoes insist on walking #fb",
    "id" : 58530128120123392,
    "created_at" : "2011-04-14 14:00:44 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 58531071209381888,
  "created_at" : "2011-04-14 14:04:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Lancashire Lass",
      "screen_name" : "Kakabel",
      "indices" : [ 16, 24 ],
      "id_str" : "26728419",
      "id" : 26728419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58525088496107520",
  "geo" : { },
  "id_str" : "58526517138964480",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver @Kakabel I dont follow so it would be impolite to ask : )",
  "id" : 58526517138964480,
  "in_reply_to_status_id" : 58525088496107520,
  "created_at" : "2011-04-14 13:46:23 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58524556226330624",
  "text" : "crows in yard grabbing up the popcorn \u2665",
  "id" : 58524556226330624,
  "created_at" : "2011-04-14 13:38:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 0, 9 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58519013260664832",
  "geo" : { },
  "id_str" : "58523396467736576",
  "in_reply_to_user_id" : 46375814,
  "text" : "@BayBitch yay!!",
  "id" : 58523396467736576,
  "in_reply_to_status_id" : 58519013260664832,
  "created_at" : "2011-04-14 13:33:59 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58354782582214656",
  "geo" : { },
  "id_str" : "58355285047259136",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes I \u2665 this song. have a great sign language version on my tumblr..lol",
  "id" : 58355285047259136,
  "in_reply_to_status_id" : 58354782582214656,
  "created_at" : "2011-04-14 02:25:58 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58352511819579393",
  "geo" : { },
  "id_str" : "58354711052554240",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott how I felt about our mally who passed in 2006 \u2665",
  "id" : 58354711052554240,
  "in_reply_to_status_id" : 58352511819579393,
  "created_at" : "2011-04-14 02:23:41 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58352193752928256",
  "geo" : { },
  "id_str" : "58354319723999232",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott ((hugs))",
  "id" : 58354319723999232,
  "in_reply_to_status_id" : 58352193752928256,
  "created_at" : "2011-04-14 02:22:08 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "indices" : [ 3, 13 ],
      "id_str" : "22380908",
      "id" : 22380908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58353447287795712",
  "text" : "RT @BethLayne: Your emotional reactions contain messages to you from you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58349508802777088",
    "text" : "Your emotional reactions contain messages to you from you.",
    "id" : 58349508802777088,
    "created_at" : "2011-04-14 02:03:01 +0000",
    "user" : {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "protected" : false,
      "id_str" : "22380908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796841124904116224\/6H0GAfoZ_normal.jpg",
      "id" : 22380908,
      "verified" : false
    }
  },
  "id" : 58353447287795712,
  "created_at" : "2011-04-14 02:18:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 0, 14 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58259397486456832",
  "in_reply_to_user_id" : 145083191,
  "text" : "@JimBrownBooks I hope Chaplin is ok. (u dont have 2 reply)",
  "id" : 58259397486456832,
  "created_at" : "2011-04-13 20:04:57 +0000",
  "in_reply_to_screen_name" : "JimBrownBooks",
  "in_reply_to_user_id_str" : "145083191",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sex",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "love",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/jImKyio",
      "expanded_url" : "http:\/\/www.jennascribbles.com\/2011\/03\/22\/how-often-do-married-couples-have-sex\/",
      "display_url" : "jennascribbles.com\/2011\/03\/22\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "58249907974316033",
  "text" : "RT @JAScribbles: Preliminary survey results - How Often Do Couples Have #Sex? http:\/\/t.co\/jImKyio #love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sex",
        "indices" : [ 55, 59 ]
      }, {
        "text" : "love",
        "indices" : [ 81, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 80 ],
        "url" : "http:\/\/t.co\/jImKyio",
        "expanded_url" : "http:\/\/www.jennascribbles.com\/2011\/03\/22\/how-often-do-married-couples-have-sex\/",
        "display_url" : "jennascribbles.com\/2011\/03\/22\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "58247569003913216",
    "text" : "Preliminary survey results - How Often Do Couples Have #Sex? http:\/\/t.co\/jImKyio #love",
    "id" : 58247569003913216,
    "created_at" : "2011-04-13 19:17:57 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 58249907974316033,
  "created_at" : "2011-04-13 19:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58244987682439168",
  "geo" : { },
  "id_str" : "58249523331469313",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes like you, I avoid negative ppl & situations. you know what happened? ... I got happier. Amazing! : )",
  "id" : 58249523331469313,
  "in_reply_to_status_id" : 58244987682439168,
  "created_at" : "2011-04-13 19:25:43 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 0, 13 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58245550822277120",
  "geo" : { },
  "id_str" : "58249106065342465",
  "in_reply_to_user_id" : 88325042,
  "text" : "@MurderNovels it looks good! I left my comment there. Nothing too exciting, though..lol.",
  "id" : 58249106065342465,
  "in_reply_to_status_id" : 58245550822277120,
  "created_at" : "2011-04-13 19:24:03 +0000",
  "in_reply_to_screen_name" : "MurderNovels",
  "in_reply_to_user_id_str" : "88325042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 0, 13 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58241466253852672",
  "geo" : { },
  "id_str" : "58243081396424704",
  "in_reply_to_user_id" : 88325042,
  "text" : "@MurderNovels c'mon, you didn't? makes me feel bad! lol",
  "id" : 58243081396424704,
  "in_reply_to_status_id" : 58241466253852672,
  "created_at" : "2011-04-13 19:00:07 +0000",
  "in_reply_to_screen_name" : "MurderNovels",
  "in_reply_to_user_id_str" : "88325042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    }, {
      "name" : "Brad Walsh",
      "screen_name" : "BradWalsh",
      "indices" : [ 21, 31 ],
      "id_str" : "15173253",
      "id" : 15173253
    }, {
      "name" : "\u0394\u220FDR\u03A3W",
      "screen_name" : "andrethuo",
      "indices" : [ 59, 69 ],
      "id_str" : "22531312",
      "id" : 22531312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58242831092948992",
  "text" : "RT @Squirrely007: RT @bradwalsh You're a fucking idiot. RT @andrethuo Am not against gay rights & shit, but telling kids it's okay to be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brad Walsh",
        "screen_name" : "BradWalsh",
        "indices" : [ 3, 13 ],
        "id_str" : "15173253",
        "id" : 15173253
      }, {
        "name" : "\u0394\u220FDR\u03A3W",
        "screen_name" : "andrethuo",
        "indices" : [ 41, 51 ],
        "id_str" : "22531312",
        "id" : 22531312
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fact",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58240003435806720",
    "text" : "RT @bradwalsh You're a fucking idiot. RT @andrethuo Am not against gay rights & shit, but telling kids it's okay to be gay is wrong #Fact",
    "id" : 58240003435806720,
    "created_at" : "2011-04-13 18:47:53 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 58242831092948992,
  "created_at" : "2011-04-13 18:59:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58239831498690560",
  "text" : "RT @fearfuldogs: dog transport help needed NY-VT-CT-NH short rtes well organized contact sheri_bee@yahoo.com 4 details",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58239221332320256",
    "text" : "dog transport help needed NY-VT-CT-NH short rtes well organized contact sheri_bee@yahoo.com 4 details",
    "id" : 58239221332320256,
    "created_at" : "2011-04-13 18:44:47 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 58239831498690560,
  "created_at" : "2011-04-13 18:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "JesusOfNaz316",
      "indices" : [ 3, 17 ],
      "id_str" : "109687064",
      "id" : 109687064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58235604739178496",
  "text" : "RT @JesusOfNaz316: HappyEndings are not happy enough if they do not include everyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58234334334816256",
    "text" : "HappyEndings are not happy enough if they do not include everyone.",
    "id" : 58234334334816256,
    "created_at" : "2011-04-13 18:25:21 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "JesusOfNaz316",
      "protected" : false,
      "id_str" : "109687064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663841137\/RL000458.jpg_thinking_normal.jpg",
      "id" : 109687064,
      "verified" : false
    }
  },
  "id" : 58235604739178496,
  "created_at" : "2011-04-13 18:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 0, 13 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58218529253634048",
  "geo" : { },
  "id_str" : "58229816029220864",
  "in_reply_to_user_id" : 88325042,
  "text" : "@MurderNovels was going to comment I love my Kindle but think everyone should get the reader that suits their needs.",
  "id" : 58229816029220864,
  "in_reply_to_status_id" : 58218529253634048,
  "created_at" : "2011-04-13 18:07:24 +0000",
  "in_reply_to_screen_name" : "MurderNovels",
  "in_reply_to_user_id_str" : "88325042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 0, 13 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58218529253634048",
  "geo" : { },
  "id_str" : "58229542405410816",
  "in_reply_to_user_id" : 88325042,
  "text" : "@MurderNovels maybe http:\/\/disqus.com\/ would work for you",
  "id" : 58229542405410816,
  "in_reply_to_status_id" : 58218529253634048,
  "created_at" : "2011-04-13 18:06:19 +0000",
  "in_reply_to_screen_name" : "MurderNovels",
  "in_reply_to_user_id_str" : "88325042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 0, 13 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58218529253634048",
  "geo" : { },
  "id_str" : "58228950312292352",
  "in_reply_to_user_id" : 88325042,
  "text" : "@MurderNovels hehe..ok : )",
  "id" : 58228950312292352,
  "in_reply_to_status_id" : 58218529253634048,
  "created_at" : "2011-04-13 18:03:58 +0000",
  "in_reply_to_screen_name" : "MurderNovels",
  "in_reply_to_user_id_str" : "88325042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58217611191783425",
  "text" : "RT @neardeathdoc: Meeting with Elana Durham tonight. She died AND Priest said last rites over her, returned to tell of her experience.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58215959164493824",
    "text" : "Meeting with Elana Durham tonight. She died AND Priest said last rites over her, returned to tell of her experience.",
    "id" : 58215959164493824,
    "created_at" : "2011-04-13 17:12:20 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 58217611191783425,
  "created_at" : "2011-04-13 17:18:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58217402080563200",
  "text" : "RT @neardeathdoc: Durham's story is supported by medical records & an affidavit by the Priest who gave last rites. Dead brains CAN think.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58216868791595008",
    "text" : "Durham's story is supported by medical records & an affidavit by the Priest who gave last rites. Dead brains CAN think.",
    "id" : 58216868791595008,
    "created_at" : "2011-04-13 17:15:57 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 58217402080563200,
  "created_at" : "2011-04-13 17:18:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 0, 13 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58217204507885569",
  "in_reply_to_user_id" : 88325042,
  "text" : "@MurderNovels fyi: your feedback isnt working on bobmoats site. get error.",
  "id" : 58217204507885569,
  "created_at" : "2011-04-13 17:17:17 +0000",
  "in_reply_to_screen_name" : "MurderNovels",
  "in_reply_to_user_id_str" : "88325042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 3, 16 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58211724960079873",
  "text" : "RT @MurderNovels: \"Kindle Reader VS The Nook Color - My opinion\" is now available to read on my blog at http:\/\/bobmoats.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58209533335568384",
    "text" : "\"Kindle Reader VS The Nook Color - My opinion\" is now available to read on my blog at http:\/\/bobmoats.com",
    "id" : 58209533335568384,
    "created_at" : "2011-04-13 16:46:48 +0000",
    "user" : {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "protected" : false,
      "id_str" : "88325042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2060694033\/BloodSplat_normal.jpg",
      "id" : 88325042,
      "verified" : false
    }
  },
  "id" : 58211724960079873,
  "created_at" : "2011-04-13 16:55:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnheartstype",
      "screen_name" : "Johnheartstype",
      "indices" : [ 3, 18 ],
      "id_str" : "2542551966",
      "id" : 2542551966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58187930384080896",
  "text" : "RT @Johnheartstype: Today, I'm drawing what I can only describe as an anthropomorphic antimicrobial rectal lube insertion device...for w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "isthisreallife",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58185909115428864",
    "text" : "Today, I'm drawing what I can only describe as an anthropomorphic antimicrobial rectal lube insertion device...for work. #isthisreallife?",
    "id" : 58185909115428864,
    "created_at" : "2011-04-13 15:12:56 +0000",
    "user" : {
      "name" : "John Hanawalt",
      "screen_name" : "thelastwalt",
      "protected" : false,
      "id_str" : "115837697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798396402913202177\/U6beZk7K_normal.jpg",
      "id" : 115837697,
      "verified" : false
    }
  },
  "id" : 58187930384080896,
  "created_at" : "2011-04-13 15:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58181095556005888",
  "text" : "BAD&gt;&gt; carrying around pet fish & reptiles on their keyrings, phones, etc in China (and possibly other places) http:\/\/bit.ly\/dSaqln",
  "id" : 58181095556005888,
  "created_at" : "2011-04-13 14:53:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle114",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58165614065364992",
  "text" : "I should have created, used hashtag #kindle114 for the comments on ad-supported kindle..lol",
  "id" : 58165614065364992,
  "created_at" : "2011-04-13 13:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 16, 27 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58165043279298560",
  "text" : "RT @TrishScott: @moosebegab I would never use an ad supported kindle. It's tough enough to read a most blogs any more. I think the price ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "58148190947508224",
    "geo" : { },
    "id_str" : "58162420329365504",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab I would never use an ad supported kindle. It's tough enough to read a most blogs any more. I think the price should be $0.00.",
    "id" : 58162420329365504,
    "in_reply_to_status_id" : 58148190947508224,
    "created_at" : "2011-04-13 13:39:36 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 58165043279298560,
  "created_at" : "2011-04-13 13:50:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 87, 92 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/V3eaFc1",
      "expanded_url" : "http:\/\/www.woot.com\/sale\/18748",
      "display_url" : "woot.com\/sale\/18748"
    } ]
  },
  "geo" : { },
  "id_str" : "58163568071278592",
  "text" : "Barnes & Noble NOOK 3G + WiFi eReader for $99.99 + $5 shipping http:\/\/t.co\/V3eaFc1 via @woot",
  "id" : 58163568071278592,
  "created_at" : "2011-04-13 13:44:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paperly",
      "screen_name" : "paperly",
      "indices" : [ 3, 11 ],
      "id_str" : "19408313",
      "id" : 19408313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58158549842403329",
  "text" : "RT @paperly: H Schultz writes in \"Upward\": Starbucks is not a transactional business. Neither is Paperly. It's not just paper, it's a pe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58156578020397056",
    "text" : "H Schultz writes in \"Upward\": Starbucks is not a transactional business. Neither is Paperly. It's not just paper, it's a personalized gift.",
    "id" : 58156578020397056,
    "created_at" : "2011-04-13 13:16:23 +0000",
    "user" : {
      "name" : "Paperly",
      "screen_name" : "paperly",
      "protected" : false,
      "id_str" : "19408313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591681355496337409\/eHQTdhyE_normal.png",
      "id" : 19408313,
      "verified" : false
    }
  },
  "id" : 58158549842403329,
  "created_at" : "2011-04-13 13:24:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58154365789278209",
  "geo" : { },
  "id_str" : "58155051306328064",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell lol",
  "id" : 58155051306328064,
  "in_reply_to_status_id" : 58154365789278209,
  "created_at" : "2011-04-13 13:10:19 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58153008869027840",
  "text" : "@animalswisdom apparently thats how it works from description. and you can customize prefs. not bad but should still b less.",
  "id" : 58153008869027840,
  "created_at" : "2011-04-13 13:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 0, 16 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58151828075986944",
  "geo" : { },
  "id_str" : "58152200525979648",
  "in_reply_to_user_id" : 111579405,
  "text" : "@thDigitalReader LUCKY!!",
  "id" : 58152200525979648,
  "in_reply_to_status_id" : 58151828075986944,
  "created_at" : "2011-04-13 12:58:59 +0000",
  "in_reply_to_screen_name" : "thDigitalReader",
  "in_reply_to_user_id_str" : "111579405",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58152024025477120",
  "text" : "RT @GaribaldiRous: We're #1! We're #1! RT @Geeta_Sngh: Beavers are the 2nd largest rodent in the world after the capybara. http:\/\/bit.ly ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58151772279148544",
    "text" : "We're #1! We're #1! RT @Geeta_Sngh: Beavers are the 2nd largest rodent in the world after the capybara. http:\/\/bit.ly\/eo7Ypb",
    "id" : 58151772279148544,
    "created_at" : "2011-04-13 12:57:17 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 58152024025477120,
  "created_at" : "2011-04-13 12:58:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58148925990899712",
  "geo" : { },
  "id_str" : "58151072967045120",
  "in_reply_to_user_id" : 18219084,
  "text" : "at least $39 off I agree @byoung210",
  "id" : 58151072967045120,
  "in_reply_to_status_id" : 58148925990899712,
  "created_at" : "2011-04-13 12:54:30 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 76, 88 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58149592025415680",
  "geo" : { },
  "id_str" : "58150630841266176",
  "in_reply_to_user_id" : 71118021,
  "text" : "yeah, my feeling, too. I mean reg K3-wifi is $139.. $25 off, not impressed. @CaroleODell",
  "id" : 58150630841266176,
  "in_reply_to_status_id" : 58149592025415680,
  "created_at" : "2011-04-13 12:52:45 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58150134344716288",
  "text" : "Im not against ad supported Kindle as long as they have non-ad K option. and ads dont stop you from reading.",
  "id" : 58150134344716288,
  "created_at" : "2011-04-13 12:50:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58149838189101057",
  "text" : "I guess the ads on this Kindle will be on screensaver and bottom of screen? not interfering w reading?",
  "id" : 58149838189101057,
  "created_at" : "2011-04-13 12:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58148717815021568",
  "geo" : { },
  "id_str" : "58149389272752130",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles hehe.. are you my twin? lol yeah, I prefer more solitary work.",
  "id" : 58149389272752130,
  "in_reply_to_status_id" : 58148717815021568,
  "created_at" : "2011-04-13 12:47:49 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58148190947508224",
  "text" : "wonder how the new $25 less, ad supported Kindle will fly.. should have made it more $$ off I think.",
  "id" : 58148190947508224,
  "created_at" : "2011-04-13 12:43:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 0, 9 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abraham",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58144981600305152",
  "geo" : { },
  "id_str" : "58146415788032000",
  "in_reply_to_user_id" : 15396585,
  "text" : "@Moonrust what worked\/works 4 me: keep reaching 4 better feeling (after time, gets ezr 2 do so) #abraham-hicks ((hugs))",
  "id" : 58146415788032000,
  "in_reply_to_status_id" : 58144981600305152,
  "created_at" : "2011-04-13 12:36:00 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "indices" : [ 0, 10 ],
      "id_str" : "34858888",
      "id" : 34858888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58138885665992705",
  "geo" : { },
  "id_str" : "58139752242745344",
  "in_reply_to_user_id" : 34858888,
  "text" : "@Hayzlenut lacking creativity, they are missing out on wonders of the world : )",
  "id" : 58139752242745344,
  "in_reply_to_status_id" : 58138885665992705,
  "created_at" : "2011-04-13 12:09:31 +0000",
  "in_reply_to_screen_name" : "Hayzlenut",
  "in_reply_to_user_id_str" : "34858888",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 0, 12 ],
      "id_str" : "130344581",
      "id" : 130344581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58135570240643073",
  "geo" : { },
  "id_str" : "58136567331553280",
  "in_reply_to_user_id" : 130344581,
  "text" : "@_karmadorje go to their profile.. see round settings button? click. there is option to report for spam.",
  "id" : 58136567331553280,
  "in_reply_to_status_id" : 58135570240643073,
  "created_at" : "2011-04-13 11:56:52 +0000",
  "in_reply_to_screen_name" : "_karmadorje",
  "in_reply_to_user_id_str" : "130344581",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58135733969494016",
  "text" : "RT @neardeathdoc: I am a man struggling to understand the divine & lessons of love from children. If I ever act like a Guru, kick me in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58135422777303040",
    "text" : "I am a man struggling to understand the divine & lessons of love from children. If I ever act like a Guru, kick me in the balls please",
    "id" : 58135422777303040,
    "created_at" : "2011-04-13 11:52:19 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 58135733969494016,
  "created_at" : "2011-04-13 11:53:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/posterous.com\" rel=\"nofollow\"\u003EPosterous\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "indices" : [ 0, 10 ],
      "id_str" : "34858888",
      "id" : 34858888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58135606542344192",
  "in_reply_to_user_id" : 34858888,
  "text" : "@Hayzlenut I thought this was a really cool idea! I can see this concept taking off and ppl having virtual vacation ... http:\/\/post.ly\/1tDBZ",
  "id" : 58135606542344192,
  "created_at" : "2011-04-13 11:53:03 +0000",
  "in_reply_to_screen_name" : "Hayzlenut",
  "in_reply_to_user_id_str" : "34858888",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58134568238202880",
  "text" : "RT @petsalive: Oh no. With just 3 days left we dropped to 49. Still in it, but it is getting close. PLEASE vote, FB & RT! Http:\/\/votetos ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/\" rel=\"nofollow\"\u003ETwitBird iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58134083699613696",
    "text" : "Oh no. With just 3 days left we dropped to 49. Still in it, but it is getting close. PLEASE vote, FB & RT! Http:\/\/votetosavelives.org",
    "id" : 58134083699613696,
    "created_at" : "2011-04-13 11:47:00 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 58134568238202880,
  "created_at" : "2011-04-13 11:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58133671751843840",
  "text" : "good morning my sweet peeps. enjoying my coffee : )",
  "id" : 58133671751843840,
  "created_at" : "2011-04-13 11:45:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57990959861993473",
  "text" : "good night my loves \u2665",
  "id" : 57990959861993473,
  "created_at" : "2011-04-13 02:18:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57986122936102912",
  "text" : "I don't fear death.. but I do fear pain. I don't care to know pain.",
  "id" : 57986122936102912,
  "created_at" : "2011-04-13 01:59:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhirawit",
      "screen_name" : "LiveDhirawit",
      "indices" : [ 3, 16 ],
      "id_str" : "69262313",
      "id" : 69262313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57985585192767488",
  "text" : "RT @LiveDhirawit: The Fear of Death is the most unjustified of all fears - Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57962960382996480",
    "text" : "The Fear of Death is the most unjustified of all fears - Albert Einstein",
    "id" : 57962960382996480,
    "created_at" : "2011-04-13 00:27:01 +0000",
    "user" : {
      "name" : "Dhirawit",
      "screen_name" : "LiveDhirawit",
      "protected" : false,
      "id_str" : "69262313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735013340452249600\/OXkpwQwR_normal.jpg",
      "id" : 69262313,
      "verified" : false
    }
  },
  "id" : 57985585192767488,
  "created_at" : "2011-04-13 01:56:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57949908933685249",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 ((hugs)) 2U .. dont know if you saw my comments to deckly messages",
  "id" : 57949908933685249,
  "created_at" : "2011-04-12 23:35:09 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bronx Zoo's Cobra",
      "screen_name" : "BronxZoosCobra",
      "indices" : [ 3, 18 ],
      "id_str" : "273531261",
      "id" : 273531261
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freebronxzooscobra",
      "indices" : [ 105, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57941371801182208",
  "text" : "RT @BronxZoosCobra: Children 2 years and under are always free at The Bronx Zoo. Um. Hello. I'm under 2. #freebronxzooscobra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freebronxzooscobra",
        "indices" : [ 85, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57935905297666048",
    "text" : "Children 2 years and under are always free at The Bronx Zoo. Um. Hello. I'm under 2. #freebronxzooscobra",
    "id" : 57935905297666048,
    "created_at" : "2011-04-12 22:39:30 +0000",
    "user" : {
      "name" : "Bronx Zoo's Cobra",
      "screen_name" : "BronxZoosCobra",
      "protected" : false,
      "id_str" : "273531261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1296024799\/TWITTER-DEFAULT_2__normal.jpg",
      "id" : 273531261,
      "verified" : false
    }
  },
  "id" : 57941371801182208,
  "created_at" : "2011-04-12 23:01:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57928514988548097",
  "geo" : { },
  "id_str" : "57930802935242752",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle (((hugs))) from anesthesia? I had some bad reactions.",
  "id" : 57930802935242752,
  "in_reply_to_status_id" : 57928514988548097,
  "created_at" : "2011-04-12 22:19:14 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "indices" : [ 3, 18 ],
      "id_str" : "17621549",
      "id" : 17621549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57930344334241792",
  "text" : "RT @ReikiAwakening: Need a gift? I will create an acrostic poem on any name for $5. http:\/\/fiverr.com\/266116",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57929937918767105",
    "text" : "Need a gift? I will create an acrostic poem on any name for $5. http:\/\/fiverr.com\/266116",
    "id" : 57929937918767105,
    "created_at" : "2011-04-12 22:15:48 +0000",
    "user" : {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "protected" : false,
      "id_str" : "17621549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487076852842778625\/uKEYUGdu_normal.jpeg",
      "id" : 17621549,
      "verified" : false
    }
  },
  "id" : 57930344334241792,
  "created_at" : "2011-04-12 22:17:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sacred Witness",
      "screen_name" : "SacredWitness",
      "indices" : [ 3, 17 ],
      "id_str" : "3085133691",
      "id" : 3085133691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57927852137529344",
  "text" : "RT @SacredWitness: Unexpected Visitor http:\/\/carlaroyal.com\/2010\/01\/unexpected-visitor\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57926654932164608",
    "text" : "Unexpected Visitor http:\/\/carlaroyal.com\/2010\/01\/unexpected-visitor\/",
    "id" : 57926654932164608,
    "created_at" : "2011-04-12 22:02:45 +0000",
    "user" : {
      "name" : "Carla Royal",
      "screen_name" : "CarlaRoyal",
      "protected" : false,
      "id_str" : "28894048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823476520\/13fdf78af18d23f2cf1dc63aceb88301_normal.jpeg",
      "id" : 28894048,
      "verified" : false
    }
  },
  "id" : 57927852137529344,
  "created_at" : "2011-04-12 22:07:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 52, 66 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 96, 108 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exotic",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "animals",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57925094793682944",
  "text" : "peeps, if you want to follow a fun capybara, follow @GaribaldiRous & a queenly anteater, follow @PuaTamandua #exotic #animals",
  "id" : 57925094793682944,
  "created_at" : "2011-04-12 21:56:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57924150098006016",
  "text" : "RT @BayBitch: Since there's only one of me, do I qualify as endangered?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57922683115016192",
    "text" : "Since there's only one of me, do I qualify as endangered?",
    "id" : 57922683115016192,
    "created_at" : "2011-04-12 21:46:58 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 57924150098006016,
  "created_at" : "2011-04-12 21:52:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "indices" : [ 0, 14 ],
      "id_str" : "30038832",
      "id" : 30038832
    }, {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 15, 24 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57922058482491392",
  "geo" : { },
  "id_str" : "57923612455354368",
  "in_reply_to_user_id" : 30038832,
  "text" : "@LilithsPriest @BayBitch haha I do that all the time (see word as another word) : )",
  "id" : 57923612455354368,
  "in_reply_to_status_id" : 57922058482491392,
  "created_at" : "2011-04-12 21:50:40 +0000",
  "in_reply_to_screen_name" : "LilithsPriest",
  "in_reply_to_user_id_str" : "30038832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57905167420489728",
  "text" : "RT @UnseeingEyes: A lady once told me in a Direct Message...\"I'm very sorry but I have to stop following you because you are too positiv ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57904323635593216",
    "text" : "A lady once told me in a Direct Message...\"I'm very sorry but I have to stop following you because you are too positive & make me sick.\"",
    "id" : 57904323635593216,
    "created_at" : "2011-04-12 20:34:01 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 57905167420489728,
  "created_at" : "2011-04-12 20:37:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57904881197006849",
  "text" : "\"Abolishing rights for one is abolishing rights for all.\" - @Reverend_Sue http:\/\/bit.ly\/ieT92w",
  "id" : 57904881197006849,
  "created_at" : "2011-04-12 20:36:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57877659820109825",
  "text" : "RT @BayBitch: I am Not trying to be Difficult...it happens naturally",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57877308836548608",
    "text" : "I am Not trying to be Difficult...it happens naturally",
    "id" : 57877308836548608,
    "created_at" : "2011-04-12 18:46:40 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 57877659820109825,
  "created_at" : "2011-04-12 18:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57877164112089088",
  "text" : "RT @BayBitch: If things were turned around, I seriously doubt that one cat would take in 26 old ladies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57876178035412992",
    "text" : "If things were turned around, I seriously doubt that one cat would take in 26 old ladies.",
    "id" : 57876178035412992,
    "created_at" : "2011-04-12 18:42:10 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 57877164112089088,
  "created_at" : "2011-04-12 18:46:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 83, 88 ]
    }, {
      "text" : "equality",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57872425093828608",
  "text" : "lunch or gay-lunch? http:\/\/bit.ly\/hPosyG hey, @Reverend_Sue you will like this : ) #LGBT #equality",
  "id" : 57872425093828608,
  "created_at" : "2011-04-12 18:27:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOH8 Campaign",
      "screen_name" : "NOH8Campaign",
      "indices" : [ 3, 16 ],
      "id_str" : "32774989",
      "id" : 32774989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NOH8",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 108, 113 ]
    }, {
      "text" : "NOH8Worldwide",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57872353471893504",
  "text" : "RT @NOH8Campaign: \"Those who deny freedom to others deserve it not for themselves.\" - Abraham Lincoln #NOH8 #LGBT #NOH8Worldwide",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NOH8",
        "indices" : [ 84, 89 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 90, 95 ]
      }, {
        "text" : "NOH8Worldwide",
        "indices" : [ 96, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57612973413371904",
    "text" : "\"Those who deny freedom to others deserve it not for themselves.\" - Abraham Lincoln #NOH8 #LGBT #NOH8Worldwide",
    "id" : 57612973413371904,
    "created_at" : "2011-04-12 01:16:17 +0000",
    "user" : {
      "name" : "NOH8 Campaign",
      "screen_name" : "NOH8Campaign",
      "protected" : false,
      "id_str" : "32774989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790969172234764288\/hBs2JudQ_normal.jpg",
      "id" : 32774989,
      "verified" : true
    }
  },
  "id" : 57872353471893504,
  "created_at" : "2011-04-12 18:26:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57868096660176897",
  "text" : "RT @BrianMerritt: I need to write something on what my dog teaches me about life",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57867425621880832",
    "text" : "I need to write something on what my dog teaches me about life",
    "id" : 57867425621880832,
    "created_at" : "2011-04-12 18:07:24 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 57868096660176897,
  "created_at" : "2011-04-12 18:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "Gerty-Z \uD83C\uDF7B",
      "screen_name" : "GertyZ",
      "indices" : [ 10, 17 ],
      "id_str" : "147357742",
      "id" : 147357742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57865400410574848",
  "text" : "@Tideliar @GertyZ Dir.of Fac. Dev. dont u need 2B a ppl person for that? lol",
  "id" : 57865400410574848,
  "created_at" : "2011-04-12 17:59:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 0, 9 ],
      "id_str" : "374293471",
      "id" : 374293471
    }, {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 21, 32 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57862367278661632",
  "geo" : { },
  "id_str" : "57864649613377536",
  "in_reply_to_user_id" : 46375814,
  "text" : "@BayBitch I followed @caplinrous until his untimely death in Jan. now following his \"brother\" garibaldirous",
  "id" : 57864649613377536,
  "in_reply_to_status_id" : 57862367278661632,
  "created_at" : "2011-04-12 17:56:22 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57863581575806976",
  "text" : "RT @petsalive: Just got an amazing offer.  Tanana M, one of our supporters is promising to match EVERY dollar up to $1000 on the chip-in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57860791650631680",
    "text" : "Just got an amazing offer.  Tanana M, one of our supporters is promising to match EVERY dollar up to $1000 on the chip-in!  Petsalive.com",
    "id" : 57860791650631680,
    "created_at" : "2011-04-12 17:41:02 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 57863581575806976,
  "created_at" : "2011-04-12 17:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "Gerty-Z \uD83C\uDF7B",
      "screen_name" : "GertyZ",
      "indices" : [ 10, 17 ],
      "id_str" : "147357742",
      "id" : 147357742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57862927398612992",
  "text" : "@Tideliar @GertyZ whaddya doing ordering folders? youre a scientist for chrissake... ; )",
  "id" : 57862927398612992,
  "created_at" : "2011-04-12 17:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57862321162297345",
  "text" : "RT @petsalive: The average horse costs $400 a month in hay, feed, hoof trimming & care.  Seniors are even more costly to care for.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57862068270923776",
    "text" : "The average horse costs $400 a month in hay, feed, hoof trimming & care.  Seniors are even more costly to care for.",
    "id" : 57862068270923776,
    "created_at" : "2011-04-12 17:46:06 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 57862321162297345,
  "created_at" : "2011-04-12 17:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57862279634501632",
  "text" : "RT @petsalive: And yet the donations for our horses total just $100 a month!  We could really use some help.  We used to have 18. Now ju ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57862167889838080",
    "text" : "And yet the donations for our horses total just $100 a month!  We could really use some help.  We used to have 18. Now just 7.",
    "id" : 57862167889838080,
    "created_at" : "2011-04-12 17:46:30 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 57862279634501632,
  "created_at" : "2011-04-12 17:46:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 0, 9 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57860457645617152",
  "geo" : { },
  "id_str" : "57862005427675136",
  "in_reply_to_user_id" : 46375814,
  "text" : "@BayBitch do you like Capybaras or Anteaters? I follow...",
  "id" : 57862005427675136,
  "in_reply_to_status_id" : 57860457645617152,
  "created_at" : "2011-04-12 17:45:51 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57850443103080449",
  "geo" : { },
  "id_str" : "57859915242409984",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I dont get flashes but I do get hot easily. cant wear long sleeves. no coat in car. heat makes me nauseous.",
  "id" : 57859915242409984,
  "in_reply_to_status_id" : 57850443103080449,
  "created_at" : "2011-04-12 17:37:33 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57859460282064897",
  "text" : "@Tideliar uh-oh",
  "id" : 57859460282064897,
  "created_at" : "2011-04-12 17:35:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hewson",
      "screen_name" : "david_hewson",
      "indices" : [ 3, 16 ],
      "id_str" : "1483231",
      "id" : 1483231
    }, {
      "name" : "Shercuck Holmes",
      "screen_name" : "OHNOITSKEN",
      "indices" : [ 18, 29 ],
      "id_str" : "194456040",
      "id" : 194456040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57849167766233088",
  "text" : "RT @david_hewson: @ohnoitsken Am doubtless showing great cultural ignorance here - who or what is Snooki?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shercuck Holmes",
        "screen_name" : "OHNOITSKEN",
        "indices" : [ 0, 11 ],
        "id_str" : "194456040",
        "id" : 194456040
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57842163832201216",
    "text" : "@ohnoitsken Am doubtless showing great cultural ignorance here - who or what is Snooki?",
    "id" : 57842163832201216,
    "created_at" : "2011-04-12 16:27:01 +0000",
    "user" : {
      "name" : "David Hewson",
      "screen_name" : "david_hewson",
      "protected" : false,
      "id_str" : "1483231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789199739623346176\/I6hcjeXN_normal.jpg",
      "id" : 1483231,
      "verified" : true
    }
  },
  "id" : 57849167766233088,
  "created_at" : "2011-04-12 16:54:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57845764688318464",
  "text" : "apparently, menopause is associated with several symptoms.",
  "id" : 57845764688318464,
  "created_at" : "2011-04-12 16:41:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57845410370289664",
  "text" : "RT @DeepakChopra: Know that you are greater than any result, good or bad. Identify yourself with the bigger picture and not the minute d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57843965038297088",
    "text" : "Know that you are greater than any result, good or bad. Identify yourself with the bigger picture and not the minute details.",
    "id" : 57843965038297088,
    "created_at" : "2011-04-12 16:34:10 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 57845410370289664,
  "created_at" : "2011-04-12 16:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57843888643248128",
  "text" : "RT @Buddhaworld: but where do our thoughts go?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57842873013514240",
    "text" : "but where do our thoughts go?",
    "id" : 57842873013514240,
    "created_at" : "2011-04-12 16:29:50 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 57843888643248128,
  "created_at" : "2011-04-12 16:33:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "JoeMyGod",
      "screen_name" : "JoeMyGod",
      "indices" : [ 20, 29 ],
      "id_str" : "16490790",
      "id" : 16490790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57843346902753280",
  "text" : "RT @mindymayhem: RT @JoeMyGod: New From JMG: J. Crew Ad Draws Wingnut Fire: Anti-gay sites are going nuts about the above J. Crew ad...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JoeMyGod",
        "screen_name" : "JoeMyGod",
        "indices" : [ 3, 12 ],
        "id_str" : "16490790",
        "id" : 16490790
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57841223045619712",
    "text" : "RT @JoeMyGod: New From JMG: J. Crew Ad Draws Wingnut Fire: Anti-gay sites are going nuts about the above J. Crew ad... http:\/\/bit.ly\/i8e6d7",
    "id" : 57841223045619712,
    "created_at" : "2011-04-12 16:23:16 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 57843346902753280,
  "created_at" : "2011-04-12 16:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "indices" : [ 3, 18 ],
      "id_str" : "233966512",
      "id" : 233966512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57826079360024576",
  "text" : "RT @authorkingsley: They say it's better to be poor & happy than rich & miserable, but how about a compromise like moderately rich & jus ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57824894406246400",
    "text" : "They say it's better to be poor & happy than rich & miserable, but how about a compromise like moderately rich & just moody? Princess Diana",
    "id" : 57824894406246400,
    "created_at" : "2011-04-12 15:18:23 +0000",
    "user" : {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "protected" : false,
      "id_str" : "233966512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1206687416\/ian-spinaker-90ppi-smallest_normal.JPG",
      "id" : 233966512,
      "verified" : false
    }
  },
  "id" : 57826079360024576,
  "created_at" : "2011-04-12 15:23:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57825904159768576",
  "text" : "I dont get hot flashes.. I get night sweats.",
  "id" : 57825904159768576,
  "created_at" : "2011-04-12 15:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57820155828379648",
  "text" : "RT @GraveStomper: Every time you settle in your life you create grief.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57815594002690048",
    "text" : "Every time you settle in your life you create grief.",
    "id" : 57815594002690048,
    "created_at" : "2011-04-12 14:41:26 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 57820155828379648,
  "created_at" : "2011-04-12 14:59:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "booksinyourpants",
      "indices" : [ 54, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57785435774124032",
  "text" : "RT @squintinginfog: 90 Min in Heaven... In your pants #booksinyourpants",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "booksinyourpants",
        "indices" : [ 34, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57785211974451200",
    "text" : "90 Min in Heaven... In your pants #booksinyourpants",
    "id" : 57785211974451200,
    "created_at" : "2011-04-12 12:40:42 +0000",
    "user" : {
      "name" : "Christi Bowman",
      "screen_name" : "fastingfoody",
      "protected" : false,
      "id_str" : "199743576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499337090\/fastingfoody_normal.jpg",
      "id" : 199743576,
      "verified" : false
    }
  },
  "id" : 57785435774124032,
  "created_at" : "2011-04-12 12:41:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57782556346695681",
  "text" : "RT @Moonrust: New Yorkers get UFO sighting hotline http:\/\/bit.ly\/f34uUy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57778860695105536",
    "text" : "New Yorkers get UFO sighting hotline http:\/\/bit.ly\/f34uUy",
    "id" : 57778860695105536,
    "created_at" : "2011-04-12 12:15:28 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 57782556346695681,
  "created_at" : "2011-04-12 12:30:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carlosaleman",
      "screen_name" : "carlosaleman",
      "indices" : [ 3, 16 ],
      "id_str" : "11025612",
      "id" : 11025612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57781523209924608",
  "text" : "RT @carlosaleman: Good morning twitterverse -be awesome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57780069887787009",
    "text" : "Good morning twitterverse -be awesome",
    "id" : 57780069887787009,
    "created_at" : "2011-04-12 12:20:16 +0000",
    "user" : {
      "name" : "carlosaleman",
      "screen_name" : "carlosaleman",
      "protected" : false,
      "id_str" : "11025612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758121858528968704\/BKkOFzfj_normal.jpg",
      "id" : 11025612,
      "verified" : false
    }
  },
  "id" : 57781523209924608,
  "created_at" : "2011-04-12 12:26:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57781207081025536",
  "text" : "the dog is weird. ended up in sissy's top bunk again. got her back in our BR but she whined til we opened door. back to sissy's room. o-O",
  "id" : 57781207081025536,
  "created_at" : "2011-04-12 12:24:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http:\/\/t.co\/3CFxHUN",
      "expanded_url" : "http:\/\/shar.es\/H3LjK",
      "display_url" : "shar.es\/H3LjK"
    } ]
  },
  "geo" : { },
  "id_str" : "57778539851812865",
  "text" : "WWE: Inside WWE &gt; Injury forces Edge to retire http:\/\/t.co\/3CFxHUN",
  "id" : 57778539851812865,
  "created_at" : "2011-04-12 12:14:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57599552802390016",
  "geo" : { },
  "id_str" : "57601807404380160",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses its still a temp... feel better!",
  "id" : 57601807404380160,
  "in_reply_to_status_id" : 57599552802390016,
  "created_at" : "2011-04-12 00:31:55 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diversity",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57600544864342016",
  "text" : "RT @Reverend_Sue: The Bible is NOT the way of the world. It is only the way for some NOT all. Open your mind and heart. #diversity #reli ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "diversity",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "religion",
        "indices" : [ 113, 122 ]
      }, {
        "text" : "spirituality",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57599562067619840",
    "text" : "The Bible is NOT the way of the world. It is only the way for some NOT all. Open your mind and heart. #diversity #religion #spirituality",
    "id" : 57599562067619840,
    "created_at" : "2011-04-12 00:23:00 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 57600544864342016,
  "created_at" : "2011-04-12 00:26:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jimerson",
      "screen_name" : "pauljimerson",
      "indices" : [ 3, 16 ],
      "id_str" : "57501485",
      "id" : 57501485
    }, {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 18, 30 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57599808747220992",
  "text" : "RT @pauljimerson: @oceanshaman I guess I'm fascinated w sociopathy bec I just can't imagine it. How does one have no conscience? Seems i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GRAY",
        "screen_name" : "oceanshaman",
        "indices" : [ 0, 12 ],
        "id_str" : "45674330",
        "id" : 45674330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "57579267491495936",
    "geo" : { },
    "id_str" : "57585643181719552",
    "in_reply_to_user_id" : 45674330,
    "text" : "@oceanshaman I guess I'm fascinated w sociopathy bec I just can't imagine it. How does one have no conscience? Seems impossible....",
    "id" : 57585643181719552,
    "in_reply_to_status_id" : 57579267491495936,
    "created_at" : "2011-04-11 23:27:41 +0000",
    "in_reply_to_screen_name" : "oceanshaman",
    "in_reply_to_user_id_str" : "45674330",
    "user" : {
      "name" : "Paul Jimerson",
      "screen_name" : "pauljimerson",
      "protected" : false,
      "id_str" : "57501485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/367607779\/Paul_for_web_avatars_normal.jpg",
      "id" : 57501485,
      "verified" : false
    }
  },
  "id" : 57599808747220992,
  "created_at" : "2011-04-12 00:23:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57592242503819264",
  "geo" : { },
  "id_str" : "57599023154085888",
  "in_reply_to_user_id" : 23539037,
  "text" : "@RMoGib im sorry ((hugs)) \u007B|_| &lt;-- beer mug",
  "id" : 57599023154085888,
  "in_reply_to_status_id" : 57592242503819264,
  "created_at" : "2011-04-12 00:20:51 +0000",
  "in_reply_to_screen_name" : "OhYouGirl",
  "in_reply_to_user_id_str" : "23539037",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57594390906028032",
  "geo" : { },
  "id_str" : "57598192883220480",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awww.. that is nice! : )",
  "id" : 57598192883220480,
  "in_reply_to_status_id" : 57594390906028032,
  "created_at" : "2011-04-12 00:17:33 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57591489953415168",
  "text" : "oh bleh. hubby being cranky",
  "id" : 57591489953415168,
  "created_at" : "2011-04-11 23:50:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Jason Maybe",
      "screen_name" : "Jason_maybe",
      "indices" : [ 15, 27 ],
      "id_str" : "156686588",
      "id" : 156686588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57569540711780352",
  "text" : "RT @BestAt: RT @Jason_maybe: Million dollar idea: Twitter comedy tour. If only we could convince people who tweet to go outside.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Maybe",
        "screen_name" : "Jason_maybe",
        "indices" : [ 3, 15 ],
        "id_str" : "156686588",
        "id" : 156686588
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57566466697990144",
    "text" : "RT @Jason_maybe: Million dollar idea: Twitter comedy tour. If only we could convince people who tweet to go outside.",
    "id" : 57566466697990144,
    "created_at" : "2011-04-11 22:11:29 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 57569540711780352,
  "created_at" : "2011-04-11 22:23:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookLending.com",
      "screen_name" : "BookLending",
      "indices" : [ 3, 15 ],
      "id_str" : "233470432",
      "id" : 233470432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57569214814359552",
  "text" : "RT @BookLending: A $114 KINDLE?!  Amazon just announced that you can now order a Kindle Wi-Fi for just $114 - the catch?  Small ads... h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57568663426969600",
    "text" : "A $114 KINDLE?!  Amazon just announced that you can now order a Kindle Wi-Fi for just $114 - the catch?  Small ads... http:\/\/fb.me\/ZjaXdiGj",
    "id" : 57568663426969600,
    "created_at" : "2011-04-11 22:20:13 +0000",
    "user" : {
      "name" : "BookLending.com",
      "screen_name" : "BookLending",
      "protected" : false,
      "id_str" : "233470432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1209411096\/logo-kindle_normal.gif",
      "id" : 233470432,
      "verified" : false
    }
  },
  "id" : 57569214814359552,
  "created_at" : "2011-04-11 22:22:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "indices" : [ 3, 16 ],
      "id_str" : "15175368",
      "id" : 15175368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57565605271838721",
  "text" : "RT @theofficenbc: Here's one (or 3) more reason(s) we are extending Steve's farewell episode: AMAZING guest stars! Find out who joins us ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57559193493848064",
    "text" : "Here's one (or 3) more reason(s) we are extending Steve's farewell episode: AMAZING guest stars! Find out who joins us: http:\/\/bit.ly\/iaUfG9",
    "id" : 57559193493848064,
    "created_at" : "2011-04-11 21:42:35 +0000",
    "user" : {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "protected" : false,
      "id_str" : "15175368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3672312614\/17217191debc391b060a6798b6c2ad10_normal.jpeg",
      "id" : 15175368,
      "verified" : true
    }
  },
  "id" : 57565605271838721,
  "created_at" : "2011-04-11 22:08:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57564676527108097",
  "text" : "RT @RevDebra: Did you hear this?  Glenn Beck, on radio show today, suggested only \u201Chookers\u201D go to Planned Parenthood.  How many of us wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57564089458757632",
    "text" : "Did you hear this?  Glenn Beck, on radio show today, suggested only \u201Chookers\u201D go to Planned Parenthood.  How many of us would that include?",
    "id" : 57564089458757632,
    "created_at" : "2011-04-11 22:02:03 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 57564676527108097,
  "created_at" : "2011-04-11 22:04:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Barnett",
      "screen_name" : "katy_rose_x",
      "indices" : [ 3, 15 ],
      "id_str" : "708550095948652544",
      "id" : 708550095948652544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57552964532969473",
  "text" : "RT @Katy_Rose_x: The BBC said the Royal Wedding is the most anticipated event of April, phft yeah as if! Doctor Who's coming back on foo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57537517431439360",
    "text" : "The BBC said the Royal Wedding is the most anticipated event of April, phft yeah as if! Doctor Who's coming back on fools ;D",
    "id" : 57537517431439360,
    "created_at" : "2011-04-11 20:16:27 +0000",
    "user" : {
      "name" : "Evie",
      "screen_name" : "EvieMay_x",
      "protected" : false,
      "id_str" : "51171573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780795306917101568\/59MWBJic_normal.jpg",
      "id" : 51171573,
      "verified" : false
    }
  },
  "id" : 57552964532969473,
  "created_at" : "2011-04-11 21:17:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "indices" : [ 3, 13 ],
      "id_str" : "34858888",
      "id" : 34858888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57546362039959552",
  "text" : "RT @Hayzlenut: RT @IrisTramm: I can't think of a stinkin' blog name. \/How about My Stinkin Blog?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57541843386249216",
    "text" : "RT @IrisTramm: I can't think of a stinkin' blog name. \/How about My Stinkin Blog?",
    "id" : 57541843386249216,
    "created_at" : "2011-04-11 20:33:39 +0000",
    "user" : {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "protected" : false,
      "id_str" : "34858888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1329378381\/profile_normal.jpg",
      "id" : 34858888,
      "verified" : false
    }
  },
  "id" : 57546362039959552,
  "created_at" : "2011-04-11 20:51:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Bischoff",
      "screen_name" : "susan_bischoff",
      "indices" : [ 0, 15 ],
      "id_str" : "19793768",
      "id" : 19793768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57536185333055488",
  "geo" : { },
  "id_str" : "57537810160304128",
  "in_reply_to_user_id" : 19793768,
  "text" : "@susan_bischoff ME, TOO! lol cool beans",
  "id" : 57537810160304128,
  "in_reply_to_status_id" : 57536185333055488,
  "created_at" : "2011-04-11 20:17:37 +0000",
  "in_reply_to_screen_name" : "susan_bischoff",
  "in_reply_to_user_id_str" : "19793768",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57526075030388736",
  "text" : "funneled into behavioral \u201Ctherapy\u201D programs with an emphasis on looking more normal http:\/\/bit.ly\/dXghJq (what is normal?)",
  "id" : 57526075030388736,
  "created_at" : "2011-04-11 19:30:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57522615383896064",
  "text" : "Quantico,Pentagon deny official visits to Pfc Bradley Manning http:\/\/bit.ly\/gLWA9X reminds me of No Good Deed by @MPMcDonald64 Scary!",
  "id" : 57522615383896064,
  "created_at" : "2011-04-11 19:17:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57518650218909697",
  "text" : "my DD comes home \"Im infected!\" a student gave her a christian booklet at lunch today o-O",
  "id" : 57518650218909697,
  "created_at" : "2011-04-11 19:01:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hammons",
      "screen_name" : "TheBeanStraw",
      "indices" : [ 3, 16 ],
      "id_str" : "236673427",
      "id" : 236673427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57509065030516737",
  "text" : "RT @TheBeanStraw: I couldn't sleep. My wife said, \"Try counting sheep.\" Just a I was falling asleep, a farmer came out and told me to ge ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57506789477978113",
    "text" : "I couldn't sleep. My wife said, \"Try counting sheep.\" Just a I was falling asleep, a farmer came out and told me to get off his property.",
    "id" : 57506789477978113,
    "created_at" : "2011-04-11 18:14:21 +0000",
    "user" : {
      "name" : "David Hammons",
      "screen_name" : "TheBeanStraw",
      "protected" : false,
      "id_str" : "236673427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1216125480\/My_Pic_normal.jpg",
      "id" : 236673427,
      "verified" : false
    }
  },
  "id" : 57509065030516737,
  "created_at" : "2011-04-11 18:23:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheila Gillette",
      "screen_name" : "SheilaGillette",
      "indices" : [ 3, 18 ],
      "id_str" : "64866573",
      "id" : 64866573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57507035373244416",
  "text" : "RT @SheilaGillette: THEO - Cultivating Miracles http:\/\/aweber.com\/t\/2O8YE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.aweber.com\" rel=\"nofollow\"\u003EAWeber Email Marketing\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57504449375113216",
    "text" : "THEO - Cultivating Miracles http:\/\/aweber.com\/t\/2O8YE",
    "id" : 57504449375113216,
    "created_at" : "2011-04-11 18:05:03 +0000",
    "user" : {
      "name" : "Sheila Gillette",
      "screen_name" : "SheilaGillette",
      "protected" : false,
      "id_str" : "64866573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2200268900\/IMG_3705_low_res_cropped_normal.jpg",
      "id" : 64866573,
      "verified" : false
    }
  },
  "id" : 57507035373244416,
  "created_at" : "2011-04-11 18:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Marriage",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57492594866925569",
  "text" : "RT @Reverend_Sue: Marriage is not something that needs to be defended. #Marriage is about love and acceptance...so why not treat it that ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Marriage",
        "indices" : [ 53, 62 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 124, 129 ]
      }, {
        "text" : "DOMA",
        "indices" : [ 130, 135 ]
      }, {
        "text" : "p2",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57491922129928192",
    "text" : "Marriage is not something that needs to be defended. #Marriage is about love and acceptance...so why not treat it that way? #LGBT #DOMA #p2",
    "id" : 57491922129928192,
    "created_at" : "2011-04-11 17:15:17 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 57492594866925569,
  "created_at" : "2011-04-11 17:17:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAs for Earth(lings)",
      "screen_name" : "EarthActivists",
      "indices" : [ 3, 18 ],
      "id_str" : "269710482",
      "id" : 269710482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57481551914598400",
  "text" : "RT @EarthActivists: RT to Make Earth Nuke-free ... http:\/\/bit.ly\/Nuke-FREE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/cyg-one.net\/TweetBot\" rel=\"nofollow\"\u003ECyG TweetBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57471773884690432",
    "text" : "RT to Make Earth Nuke-free ... http:\/\/bit.ly\/Nuke-FREE",
    "id" : 57471773884690432,
    "created_at" : "2011-04-11 15:55:13 +0000",
    "user" : {
      "name" : "EAs for Earth(lings)",
      "screen_name" : "EarthActivists",
      "protected" : false,
      "id_str" : "269710482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2298039201\/7v97jjc8v0tl0zq3cvx3_normal.png",
      "id" : 269710482,
      "verified" : false
    }
  },
  "id" : 57481551914598400,
  "created_at" : "2011-04-11 16:34:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57477060737765376",
  "text" : "RT @scottsigler: Yes, of course, someone disagreeing with your view means they are \"brainwashed,\" \"stupid,\" \"being used,\" or \"declaring  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57461522766630912",
    "text" : "Yes, of course, someone disagreeing with your view means they are \"brainwashed,\" \"stupid,\" \"being used,\" or \"declaring war on X.\"",
    "id" : 57461522766630912,
    "created_at" : "2011-04-11 15:14:29 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 57477060737765376,
  "created_at" : "2011-04-11 16:16:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "krystina",
      "screen_name" : "vegansalt",
      "indices" : [ 17, 27 ],
      "id_str" : "93669287",
      "id" : 93669287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57475567846572033",
  "text" : "RT @gemswinc: RT @vegansalt Dem\/Rep is the new Coke\/Pepsi. They laugh all the way to the bank, at our expense.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "krystina",
        "screen_name" : "vegansalt",
        "indices" : [ 3, 13 ],
        "id_str" : "93669287",
        "id" : 93669287
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57468527862484992",
    "text" : "RT @vegansalt Dem\/Rep is the new Coke\/Pepsi. They laugh all the way to the bank, at our expense.",
    "id" : 57468527862484992,
    "created_at" : "2011-04-11 15:42:19 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 57475567846572033,
  "created_at" : "2011-04-11 16:10:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57458717507059712",
  "text" : "Celebrate National Library Week 2011 http:\/\/bit.ly\/eWakev",
  "id" : 57458717507059712,
  "created_at" : "2011-04-11 15:03:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "OSHO International",
      "screen_name" : "OSHOtimes",
      "indices" : [ 19, 29 ],
      "id_str" : "308673983",
      "id" : 308673983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57453014889406464",
  "text" : "RT @TrishScott: RT @oshotimes: Religions are strange: they are against everything that can lead you to some truth. Osho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OSHO International",
        "screen_name" : "OSHOtimes",
        "indices" : [ 3, 13 ],
        "id_str" : "308673983",
        "id" : 308673983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57451554088824832",
    "text" : "RT @oshotimes: Religions are strange: they are against everything that can lead you to some truth. Osho",
    "id" : 57451554088824832,
    "created_at" : "2011-04-11 14:34:52 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 57453014889406464,
  "created_at" : "2011-04-11 14:40:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrrlScientist",
      "screen_name" : "GrrlScientist",
      "indices" : [ 11, 25 ],
      "id_str" : "27834920",
      "id" : 27834920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57452794067685376",
  "text" : "Sigh... RT @GrrlScientist: it's homeopathy awareness week? how about calling it like it is: quackery awareness week?",
  "id" : 57452794067685376,
  "created_at" : "2011-04-11 14:39:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57425389361967104",
  "geo" : { },
  "id_str" : "57425983371878400",
  "in_reply_to_user_id" : 18219084,
  "text" : "I prefer to think my bacon comes from the bacon fairy @byoung210",
  "id" : 57425983371878400,
  "in_reply_to_status_id" : 57425389361967104,
  "created_at" : "2011-04-11 12:53:16 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57423320852865025",
  "geo" : { },
  "id_str" : "57425179223142401",
  "in_reply_to_user_id" : 18219084,
  "text" : "I really didnt need to read that... : ( @byoung210",
  "id" : 57425179223142401,
  "in_reply_to_status_id" : 57423320852865025,
  "created_at" : "2011-04-11 12:50:04 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    }, {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 50, 65 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57416152191733761",
  "text" : "RT @JAScribbles: Bah!! Looks very complicated. RT @ReformedBuddha: My new gadget arrived http:\/\/i.imgur.com\/duNhd.jpg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Receiving Prosperity",
        "screen_name" : "reformedbuddha",
        "indices" : [ 33, 48 ],
        "id_str" : "2169069864",
        "id" : 2169069864
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57414940587327489",
    "text" : "Bah!! Looks very complicated. RT @ReformedBuddha: My new gadget arrived http:\/\/i.imgur.com\/duNhd.jpg",
    "id" : 57414940587327489,
    "created_at" : "2011-04-11 12:09:23 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 57416152191733761,
  "created_at" : "2011-04-11 12:14:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57412708978528256",
  "text" : "RT @petsalive: You're doing it!!  We are #47 today!  Other shelters are snapping at our heels though, please keep voting: http:\/\/www.Vot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57401822918352896",
    "text" : "You're doing it!!  We are #47 today!  Other shelters are snapping at our heels though, please keep voting: http:\/\/www.VoteToSaveLives.org",
    "id" : 57401822918352896,
    "created_at" : "2011-04-11 11:17:15 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 57412708978528256,
  "created_at" : "2011-04-11 12:00:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57253632986460160",
  "text" : "Cee-Lo Green \"Fuck you\" Sign language performance http:\/\/bit.ly\/dWumJg",
  "id" : 57253632986460160,
  "created_at" : "2011-04-11 01:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57249548233486337",
  "text" : "RT @NewMindMirror: What's My Personality Quiz: 16 Character Types Based upon the Myers\/Briggs standard  http:\/\/su.pr\/3uMkS9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57248499758145536",
    "text" : "What's My Personality Quiz: 16 Character Types Based upon the Myers\/Briggs standard  http:\/\/su.pr\/3uMkS9",
    "id" : 57248499758145536,
    "created_at" : "2011-04-11 01:08:00 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 57249548233486337,
  "created_at" : "2011-04-11 01:12:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57149553043963904",
  "text" : "Sample Sunday \u00AB My Ebook Blog http:\/\/bit.ly\/hBv990",
  "id" : 57149553043963904,
  "created_at" : "2011-04-10 18:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57149417760899073",
  "text" : "Ebook Authors I Follow \u00AB My Ebook Blog http:\/\/bit.ly\/g5G7KI",
  "id" : 57149417760899073,
  "created_at" : "2011-04-10 18:34:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "0iD",
      "screen_name" : "0iD",
      "indices" : [ 3, 7 ],
      "id_str" : "17836935",
      "id" : 17836935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57144252257402880",
  "text" : "RT @0iD: Wow, what an enormous cock! :o http:\/\/bit.ly\/eYV05q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57132591941287936",
    "text" : "Wow, what an enormous cock! :o http:\/\/bit.ly\/eYV05q",
    "id" : 57132591941287936,
    "created_at" : "2011-04-10 17:27:26 +0000",
    "user" : {
      "name" : "0iD",
      "screen_name" : "0iD",
      "protected" : false,
      "id_str" : "17836935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2623523784\/bovw7nyglquhhe5sf2yh_normal.jpeg",
      "id" : 17836935,
      "verified" : false
    }
  },
  "id" : 57144252257402880,
  "created_at" : "2011-04-10 18:13:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gadget_girl66",
      "screen_name" : "gadget_girl66",
      "indices" : [ 0, 14 ],
      "id_str" : "15946890",
      "id" : 15946890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57129519491977216",
  "geo" : { },
  "id_str" : "57133036332007424",
  "in_reply_to_user_id" : 15946890,
  "text" : "@gadget_girl66 oh no. feel better. ((hugs))",
  "id" : 57133036332007424,
  "in_reply_to_status_id" : 57129519491977216,
  "created_at" : "2011-04-10 17:29:11 +0000",
  "in_reply_to_screen_name" : "gadget_girl66",
  "in_reply_to_user_id_str" : "15946890",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 91, 100 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/zXJutcO",
      "expanded_url" : "http:\/\/www.passwordincorrect.com\/2011\/04\/06\/poll-which-is-your-primary-e-reading-device-computer-e-reader-tablet-mobile-phone\/",
      "display_url" : "passwordincorrect.com\/2011\/04\/06\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "57109070880051200",
  "text" : "What is your primary e-reading device? [poll] | Password Incorrect http:\/\/t.co\/zXJutcO via @namenick",
  "id" : 57109070880051200,
  "created_at" : "2011-04-10 15:53:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bronx Zoo's Cobra",
      "screen_name" : "BronxZoosCobra",
      "indices" : [ 3, 18 ],
      "id_str" : "273531261",
      "id" : 273531261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57097306163515392",
  "text" : "RT @BronxZoosCobra: I know the zoo doesn't like it when you tap on the glass, but I don't mind it. In fact, feel free to tap really hard ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57093274837585920",
    "text" : "I know the zoo doesn't like it when you tap on the glass, but I don't mind it. In fact, feel free to tap really hard. With a hammer even.",
    "id" : 57093274837585920,
    "created_at" : "2011-04-10 14:51:12 +0000",
    "user" : {
      "name" : "Bronx Zoo's Cobra",
      "screen_name" : "BronxZoosCobra",
      "protected" : false,
      "id_str" : "273531261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1296024799\/TWITTER-DEFAULT_2__normal.jpg",
      "id" : 273531261,
      "verified" : false
    }
  },
  "id" : 57097306163515392,
  "created_at" : "2011-04-10 15:07:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57097142698917888",
  "text" : "RT @TrishScott: Free today! An Introduction to Animal & Nature Communication http:\/\/ow.ly\/4x1hM Click \"contact\" & send an email - I'll s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57094278685532161",
    "text" : "Free today! An Introduction to Animal & Nature Communication http:\/\/ow.ly\/4x1hM Click \"contact\" & send an email - I'll send you the link",
    "id" : 57094278685532161,
    "created_at" : "2011-04-10 14:55:11 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 57097142698917888,
  "created_at" : "2011-04-10 15:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57088767378464768",
  "text" : "What\u2019s More Exciting than a Moose Track? \u2014 My Nature Site http:\/\/bit.ly\/fkCUBk",
  "id" : 57088767378464768,
  "created_at" : "2011-04-10 14:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56913429855870977",
  "text" : "against another is against ourself http:\/\/amzn.com\/k\/1Q3539LGZOBSE #Kindle",
  "id" : 56913429855870977,
  "created_at" : "2011-04-10 02:56:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56905985561870336",
  "geo" : { },
  "id_str" : "56911166718492672",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell : )",
  "id" : 56911166718492672,
  "in_reply_to_status_id" : 56905985561870336,
  "created_at" : "2011-04-10 02:47:34 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56907612276523008",
  "geo" : { },
  "id_str" : "56909034216898561",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle well I'm sorry you have 2 go thru all that. I'll get over cranky soon enough.",
  "id" : 56909034216898561,
  "in_reply_to_status_id" : 56907612276523008,
  "created_at" : "2011-04-10 02:39:05 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56908218995191808",
  "text" : "I just finished reading Heartsick today & it didn't sit well w me. Too damn depressing.",
  "id" : 56908218995191808,
  "created_at" : "2011-04-10 02:35:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56907492986335232",
  "text" : "Oh twitter... How did I live without thee? Lol",
  "id" : 56907492986335232,
  "created_at" : "2011-04-10 02:32:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56905555628920832",
  "geo" : { },
  "id_str" : "56906534076170242",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle you are a dear. Did I read you getting chemo? ((hugs)) xo",
  "id" : 56906534076170242,
  "in_reply_to_status_id" : 56905555628920832,
  "created_at" : "2011-04-10 02:29:09 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Berg",
      "screen_name" : "yehudaberg",
      "indices" : [ 3, 14 ],
      "id_str" : "16341217",
      "id" : 16341217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56905960542830592",
  "text" : "RT @yehudaberg: No one messes with the universal system --- you cant mess with the universal system",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55130869458939904",
    "text" : "No one messes with the universal system --- you cant mess with the universal system",
    "id" : 55130869458939904,
    "created_at" : "2011-04-05 04:53:18 +0000",
    "user" : {
      "name" : "Yehuda Berg",
      "screen_name" : "yehudaberg",
      "protected" : false,
      "id_str" : "16341217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1748378441\/newyehudaav_normal.jpg",
      "id" : 16341217,
      "verified" : true
    }
  },
  "id" : 56905960542830592,
  "created_at" : "2011-04-10 02:26:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56905869731954689",
  "text" : "And every other comm is for new pharm drug.. Argh!!",
  "id" : 56905869731954689,
  "created_at" : "2011-04-10 02:26:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56905674591969280",
  "text" : "And that Subaru commercial w the beeping REALLY grates on me! Ugh",
  "id" : 56905674591969280,
  "created_at" : "2011-04-10 02:25:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56905304587239425",
  "text" : "Now I'm cranky...",
  "id" : 56905304587239425,
  "created_at" : "2011-04-10 02:24:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56905225931464704",
  "text" : "Good thing no one reads my tweets cuz that's a spoiler, ain't it? Well I'm not deleting it.",
  "id" : 56905225931464704,
  "created_at" : "2011-04-10 02:23:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56903833527390208",
  "text" : "This is why I hate to watch tv...",
  "id" : 56903833527390208,
  "created_at" : "2011-04-10 02:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beinghuman",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56903509521596416",
  "text" : "George really killed Mitchell? Omg... #beinghuman",
  "id" : 56903509521596416,
  "created_at" : "2011-04-10 02:17:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56835557283729408",
  "text" : "love in the library http:\/\/bit.ly\/hnPoPs",
  "id" : 56835557283729408,
  "created_at" : "2011-04-09 21:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56831384433602561",
  "text" : "RT @GraveStomper: If you expect excellent people to appear in your life then you must first be excellent.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56827594758307841",
    "text" : "If you expect excellent people to appear in your life then you must first be excellent.",
    "id" : 56827594758307841,
    "created_at" : "2011-04-09 21:15:29 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 56831384433602561,
  "created_at" : "2011-04-09 21:30:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 3, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56805249448558593",
  "text" : "at #TKD, Sr.Master said \"dont take wrong way but yr too good natured\" I need to get mad at my board..lol",
  "id" : 56805249448558593,
  "created_at" : "2011-04-09 19:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Decorah",
      "indices" : [ 22, 30 ]
    }, {
      "text" : "Eagles",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56804339632717824",
  "text" : "Why am I watching the #Decorah #Eagles ? Makes me nervous..and worried about smallest one. Oy!",
  "id" : 56804339632717824,
  "created_at" : "2011-04-09 19:43:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    }, {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 15, 25 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56780056848113664",
  "text" : "@HEATHENRABBIT @ID_vs_EGO sometimes tone doesnt convey. hope son is doing ok. ((hugs))",
  "id" : 56780056848113664,
  "created_at" : "2011-04-09 18:06:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChiefJoseph",
      "indices" : [ 65, 77 ]
    }, {
      "text" : "quotes",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56766982892175360",
  "text" : "RT @JohnCali: Death is not the end of you, only a new beginning. #ChiefJoseph #quotes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChiefJoseph",
        "indices" : [ 51, 63 ]
      }, {
        "text" : "quotes",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56762119068200960",
    "text" : "Death is not the end of you, only a new beginning. #ChiefJoseph #quotes",
    "id" : 56762119068200960,
    "created_at" : "2011-04-09 16:55:18 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 56766982892175360,
  "created_at" : "2011-04-09 17:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Devine RCE",
      "screen_name" : "LarryDevine",
      "indices" : [ 3, 15 ],
      "id_str" : "21057434",
      "id" : 21057434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56745321597911040",
  "text" : "RT @LarryDevine: \"The act of forgiveness is tough but it is the only way to forge ahead into blessings.\"\nEsther Anarfi Minkah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56738796326232064",
    "text" : "\"The act of forgiveness is tough but it is the only way to forge ahead into blessings.\"\nEsther Anarfi Minkah",
    "id" : 56738796326232064,
    "created_at" : "2011-04-09 15:22:37 +0000",
    "user" : {
      "name" : "Larry Devine RCE",
      "screen_name" : "LarryDevine",
      "protected" : false,
      "id_str" : "21057434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501020933176295424\/RyvC_vFX_normal.jpeg",
      "id" : 21057434,
      "verified" : false
    }
  },
  "id" : 56745321597911040,
  "created_at" : "2011-04-09 15:48:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56745182955192320",
  "text" : "RT @GraveStomper: Remember: no matter how much you blame others or deny this fact: this is YOUR life.  And no one will rescue you from i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56740412844556288",
    "text" : "Remember: no matter how much you blame others or deny this fact: this is YOUR life.  And no one will rescue you from its momentum but YOU.",
    "id" : 56740412844556288,
    "created_at" : "2011-04-09 15:29:03 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 56745182955192320,
  "created_at" : "2011-04-09 15:48:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56734762299174912",
  "text" : "Canine grocery-getter shops for owner http:\/\/yhoo.it\/hh8Pnn",
  "id" : 56734762299174912,
  "created_at" : "2011-04-09 15:06:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56729981648244736",
  "text" : "The Owl Bookmark Blog: New Blog Design + Giveaway! http:\/\/bit.ly\/hbIopg",
  "id" : 56729981648244736,
  "created_at" : "2011-04-09 14:47:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "indices" : [ 70, 80 ],
      "id_str" : "34858888",
      "id" : 34858888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/FXUmh2D",
      "expanded_url" : "http:\/\/hayzlenut.posterous.com\/vacation-in-my-mind-a-10-day-photo-adventire",
      "display_url" : "hayzlenut.posterous.com\/vacation-in-my\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "56479385586368512",
  "text" : "Vacation in my mind: a 10 day photo adventure http:\/\/t.co\/FXUmh2D via @Hayzlenut",
  "id" : 56479385586368512,
  "created_at" : "2011-04-08 22:11:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56457512651735041",
  "text" : "RT @mssuzcatsilver: Plz get the loose\/ lose right. Loose is when something is too big, 'lose' is when U have lost something! They are no ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56453216996573184",
    "text" : "Plz get the loose\/ lose right. Loose is when something is too big, 'lose' is when U have lost something! They are not interchangeable!",
    "id" : 56453216996573184,
    "created_at" : "2011-04-08 20:27:50 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 56457512651735041,
  "created_at" : "2011-04-08 20:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Stine",
      "screen_name" : "RL_Stine",
      "indices" : [ 3, 12 ],
      "id_str" : "94891659",
      "id" : 94891659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56438510424555520",
  "text" : "RT @RL_Stine: ..\"The squirrel was acting erratic.\" Squirrel also charged with resisting arrest. Alarming video: http:\/\/tinyurl.com\/3jq5pg4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56431945176985600",
    "text" : "..\"The squirrel was acting erratic.\" Squirrel also charged with resisting arrest. Alarming video: http:\/\/tinyurl.com\/3jq5pg4",
    "id" : 56431945176985600,
    "created_at" : "2011-04-08 19:03:18 +0000",
    "user" : {
      "name" : "R.L. Stine",
      "screen_name" : "RL_Stine",
      "protected" : false,
      "id_str" : "94891659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672804002149584898\/15pbuJ0z_normal.jpg",
      "id" : 94891659,
      "verified" : true
    }
  },
  "id" : 56438510424555520,
  "created_at" : "2011-04-08 19:29:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Stine",
      "screen_name" : "RL_Stine",
      "indices" : [ 3, 12 ],
      "id_str" : "94891659",
      "id" : 94891659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56438497401257984",
  "text" : "RT @RL_Stine: An alert TX police officer subdued a baby squirrel by pepper spraying it in front of screaming middlegraders. Said the off ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56431566292914176",
    "text" : "An alert TX police officer subdued a baby squirrel by pepper spraying it in front of screaming middlegraders. Said the officer...",
    "id" : 56431566292914176,
    "created_at" : "2011-04-08 19:01:48 +0000",
    "user" : {
      "name" : "R.L. Stine",
      "screen_name" : "RL_Stine",
      "protected" : false,
      "id_str" : "94891659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672804002149584898\/15pbuJ0z_normal.jpg",
      "id" : 94891659,
      "verified" : true
    }
  },
  "id" : 56438497401257984,
  "created_at" : "2011-04-08 19:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 92, 102 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56421117400842240",
  "text" : "RT @SangyeH: Deer Protects Mother Goose in a Cemetery http:\/\/bit.ly\/geWBWO This is amazing! @JALPalyul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 79, 89 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56394532157276160",
    "text" : "Deer Protects Mother Goose in a Cemetery http:\/\/bit.ly\/geWBWO This is amazing! @JALPalyul",
    "id" : 56394532157276160,
    "created_at" : "2011-04-08 16:34:38 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 56421117400842240,
  "created_at" : "2011-04-08 18:20:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56378838669729793",
  "text" : "Story of a goose who befriends a retired man in the park. http:\/\/bit.ly\/eWnY8I",
  "id" : 56378838669729793,
  "created_at" : "2011-04-08 15:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 0, 10 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56370681365008384",
  "text" : "@ID_vs_EGO ((hugs))",
  "id" : 56370681365008384,
  "created_at" : "2011-04-08 14:59:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56360175904370688",
  "text" : "Boy, 10, buys The Fridge\u2019s Super Bowl ring then returns it  http:\/\/yhoo.it\/hRq2Ti",
  "id" : 56360175904370688,
  "created_at" : "2011-04-08 14:18:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 0, 14 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56356806351519744",
  "in_reply_to_user_id" : 145083191,
  "text" : "@JimBrownBooks give chaplin smooches from me. hope he's ok! ((hugs))",
  "id" : 56356806351519744,
  "created_at" : "2011-04-08 14:04:44 +0000",
  "in_reply_to_screen_name" : "JimBrownBooks",
  "in_reply_to_user_id_str" : "145083191",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56355719573798912",
  "text" : "RT @BrianMerritt: I am no longer convinced that love should be at the center of our ethics, but life.  Love is it's most important compo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56350762070065152",
    "text" : "I am no longer convinced that love should be at the center of our ethics, but life.  Love is it's most important component.",
    "id" : 56350762070065152,
    "created_at" : "2011-04-08 13:40:43 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 56355719573798912,
  "created_at" : "2011-04-08 14:00:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56355422428344320",
  "text" : "RT @petsalive: We pulled into spot 55!!  We HAVE to be in the top 50 to be eligible for the $100k.  COME ON!  Keep voting! http:\/\/www.Vo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56353255688634369",
    "text" : "We pulled into spot 55!!  We HAVE to be in the top 50 to be eligible for the $100k.  COME ON!  Keep voting! http:\/\/www.VoteToSaveLives.org",
    "id" : 56353255688634369,
    "created_at" : "2011-04-08 13:50:37 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 56355422428344320,
  "created_at" : "2011-04-08 13:59:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 55, 65 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56351557826002944",
  "text" : "RT @TyrusBooks: Those of you who haven't jumped on the @bcmystery train, might I suggest Day One? In a little more than a month you can  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Cameron",
        "screen_name" : "bcmystery",
        "indices" : [ 39, 49 ],
        "id_str" : "14428947",
        "id" : 14428947
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56349549014421505",
    "text" : "Those of you who haven't jumped on the @bcmystery train, might I suggest Day One? In a little more than a month you can get County Line.",
    "id" : 56349549014421505,
    "created_at" : "2011-04-08 13:35:54 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 56351557826002944,
  "created_at" : "2011-04-08 13:43:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 0, 13 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56348213346713600",
  "geo" : { },
  "id_str" : "56350777312153600",
  "in_reply_to_user_id" : 17355721,
  "text" : "@RichardMabry no you're not the only one. I get annoyed w ppl who dont use an AR..send from personal email,you have 2 ask 2B removed.",
  "id" : 56350777312153600,
  "in_reply_to_status_id" : 56348213346713600,
  "created_at" : "2011-04-08 13:40:46 +0000",
  "in_reply_to_screen_name" : "RichardMabry",
  "in_reply_to_user_id_str" : "17355721",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56350219398418433",
  "text" : "RT @RichardMabry: Am I the only one miffed about apparently legitimate broadcast messages that don't include an \"unsubscribe\" link?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56348213346713600",
    "text" : "Am I the only one miffed about apparently legitimate broadcast messages that don't include an \"unsubscribe\" link?",
    "id" : 56348213346713600,
    "created_at" : "2011-04-08 13:30:35 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 56350219398418433,
  "created_at" : "2011-04-08 13:38:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56347380819304449",
  "text" : "RT @BayBitch: Great the voices in my head learned how to speak Spanish and now I can't understand them",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56346022997266432",
    "text" : "Great the voices in my head learned how to speak Spanish and now I can't understand them",
    "id" : 56346022997266432,
    "created_at" : "2011-04-08 13:21:53 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 56347380819304449,
  "created_at" : "2011-04-08 13:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56347223591628800",
  "text" : "RT @BayBitch: A good friend will say \"don't do it.\" Your best friend will say \"We need more fireworks\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56346448777850880",
    "text" : "A good friend will say \"don't do it.\" Your best friend will say \"We need more fireworks\"",
    "id" : 56346448777850880,
    "created_at" : "2011-04-08 13:23:34 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 56347223591628800,
  "created_at" : "2011-04-08 13:26:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56110408523726848",
  "text" : "RT @UnseeingEyes: We're headed towards the direction of GIVING UP EVERYTHING for \"our best interests & well being.\" This is what's happe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56106707960606720",
    "text" : "We're headed towards the direction of GIVING UP EVERYTHING for \"our best interests & well being.\" This is what's happening.",
    "id" : 56106707960606720,
    "created_at" : "2011-04-07 21:30:56 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 56110408523726848,
  "created_at" : "2011-04-07 21:45:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/znNZnzq",
      "expanded_url" : "http:\/\/dwaynes-word.blogspot.com\/2011\/04\/who-said-so.html",
      "display_url" : "dwaynes-word.blogspot.com\/2011\/04\/who-sa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "55810577171361793",
  "text" : "RT @Dwayne_Reaves: Who said so? http:\/\/t.co\/znNZnzq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 32 ],
        "url" : "http:\/\/t.co\/znNZnzq",
        "expanded_url" : "http:\/\/dwaynes-word.blogspot.com\/2011\/04\/who-said-so.html",
        "display_url" : "dwaynes-word.blogspot.com\/2011\/04\/who-sa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "55806325967429632",
    "text" : "Who said so? http:\/\/t.co\/znNZnzq",
    "id" : 55806325967429632,
    "created_at" : "2011-04-07 01:37:19 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 55810577171361793,
  "created_at" : "2011-04-07 01:54:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 0, 11 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55804833189478401",
  "geo" : { },
  "id_str" : "55806395609661440",
  "in_reply_to_user_id" : 34258680,
  "text" : "@WestofMars omg'ness.. ((hugs)) for you & dear kitty!",
  "id" : 55806395609661440,
  "in_reply_to_status_id" : 55804833189478401,
  "created_at" : "2011-04-07 01:37:36 +0000",
  "in_reply_to_screen_name" : "WestofMars",
  "in_reply_to_user_id_str" : "34258680",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 112, 120 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Jesus",
      "indices" : [ 42, 48 ]
    }, {
      "text" : "Heaven",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "Hell",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "religion",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/DPXv15k",
      "expanded_url" : "http:\/\/www.crystalstmarielewis.com\/2011\/04\/eternal-life-what-if-jesus-wasnt.html",
      "display_url" : "crystalstmarielewis.com\/2011\/04\/eterna\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "55806012376088577",
  "text" : "RT @CrystalLewis: \"Eternal Life\": What If #Jesus Wasn't Talking About #Heaven or #Hell? http:\/\/t.co\/DPXv15k via @AddThis #religion #love ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AddThis",
        "screen_name" : "addthis",
        "indices" : [ 94, 102 ],
        "id_str" : "15907720",
        "id" : 15907720
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Jesus",
        "indices" : [ 24, 30 ]
      }, {
        "text" : "Heaven",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "Hell",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "religion",
        "indices" : [ 103, 112 ]
      }, {
        "text" : "lovewins",
        "indices" : [ 113, 122 ]
      }, {
        "text" : "theology",
        "indices" : [ 123, 132 ]
      }, {
        "text" : "bible",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 89 ],
        "url" : "http:\/\/t.co\/DPXv15k",
        "expanded_url" : "http:\/\/www.crystalstmarielewis.com\/2011\/04\/eternal-life-what-if-jesus-wasnt.html",
        "display_url" : "crystalstmarielewis.com\/2011\/04\/eterna\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "55804924356866048",
    "text" : "\"Eternal Life\": What If #Jesus Wasn't Talking About #Heaven or #Hell? http:\/\/t.co\/DPXv15k via @AddThis #religion #lovewins #theology #bible",
    "id" : 55804924356866048,
    "created_at" : "2011-04-07 01:31:45 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 55806012376088577,
  "created_at" : "2011-04-07 01:36:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55709853666127872",
  "text" : "[Giveaway] Win: an eReader Travel Bag from Borsa Bella Design! | Pixel of Ink http:\/\/bit.ly\/fpR1mi",
  "id" : 55709853666127872,
  "created_at" : "2011-04-06 19:13:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55671453705703425",
  "text" : "RT @SpiritualNurse: \"Choose being kind over being right, and you'll be right every time.\" - Richard Carlson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55670158995357696",
    "text" : "\"Choose being kind over being right, and you'll be right every time.\" - Richard Carlson",
    "id" : 55670158995357696,
    "created_at" : "2011-04-06 16:36:14 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 55671453705703425,
  "created_at" : "2011-04-06 16:41:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55653118515494912",
  "text" : "RT @adampknave: Book thing #1: Any book reviewers out there wanna review Stays Crunchy in Milk or Strange Angel (ebook versions to be se ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55652501889888256",
    "text" : "Book thing #1: Any book reviewers out there wanna review Stays Crunchy in Milk or Strange Angel (ebook versions to be sent) - let me know.",
    "id" : 55652501889888256,
    "created_at" : "2011-04-06 15:26:05 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 55653118515494912,
  "created_at" : "2011-04-06 15:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55645920968192000",
  "text" : "RT @petsalive: We dropped to 66!! We need your votes to get us into the top 50 to contend for $100k.  Please vote every day http:\/\/www.V ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55644383470559233",
    "text" : "We dropped to 66!! We need your votes to get us into the top 50 to contend for $100k.  Please vote every day http:\/\/www.VoteToSaveLives.org",
    "id" : 55644383470559233,
    "created_at" : "2011-04-06 14:53:49 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 55645920968192000,
  "created_at" : "2011-04-06 14:59:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55636205718618114",
  "text" : "@Skandhasattva I think its nice : ) lol",
  "id" : 55636205718618114,
  "created_at" : "2011-04-06 14:21:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55635697167642624",
  "text" : "RT @DarciaHelle: If today is the first day of the rest of my life, what was yesterday?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55634901294260224",
    "text" : "If today is the first day of the rest of my life, what was yesterday?",
    "id" : 55634901294260224,
    "created_at" : "2011-04-06 14:16:08 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 55635697167642624,
  "created_at" : "2011-04-06 14:19:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55623088821370881",
  "text" : "RT @mssuzcatsilver: On this day of your life, I believe God wants you to know...that being \"right\" has nothing to do with it.\n\nThe (cont ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55622538868432896",
    "text" : "On this day of your life, I believe God wants you to know...that being \"right\" has nothing to do with it.\n\nThe (cont) http:\/\/tl.gd\/9mn1e2",
    "id" : 55622538868432896,
    "created_at" : "2011-04-06 13:27:01 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 55623088821370881,
  "created_at" : "2011-04-06 13:29:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55619520026513408",
  "text" : "I had given up getting books from library. I was always returning late, incurring fines. With my Kindle, I have ez access to books.",
  "id" : 55619520026513408,
  "created_at" : "2011-04-06 13:15:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55618678980485120",
  "text" : "...but for reading in bed, love my Kindle. consistant font & ez page turn. : )",
  "id" : 55618678980485120,
  "created_at" : "2011-04-06 13:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55618245612417024",
  "text" : "I love my Kindle but still love pbooks. Have many on my desk & shelf. Sometimes I just grab one, open to any page & read..lol",
  "id" : 55618245612417024,
  "created_at" : "2011-04-06 13:09:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55616299866406912",
  "geo" : { },
  "id_str" : "55617520601796608",
  "in_reply_to_user_id" : 18219084,
  "text" : "@byoung210 yeah..",
  "id" : 55617520601796608,
  "in_reply_to_status_id" : 55616299866406912,
  "created_at" : "2011-04-06 13:07:04 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55614228907823104",
  "geo" : { },
  "id_str" : "55617042455339008",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 I love the smell of books & texture of pages.",
  "id" : 55617042455339008,
  "in_reply_to_status_id" : 55614228907823104,
  "created_at" : "2011-04-06 13:05:10 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sojourner5",
      "screen_name" : "sojourner5",
      "indices" : [ 3, 14 ],
      "id_str" : "18115781",
      "id" : 18115781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55616391935565824",
  "text" : "RT @sojourner5: Sometimes the questions are complicated and the answers are simple. - Dr. Seuss",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55614666629586944",
    "text" : "Sometimes the questions are complicated and the answers are simple. - Dr. Seuss",
    "id" : 55614666629586944,
    "created_at" : "2011-04-06 12:55:44 +0000",
    "user" : {
      "name" : "sojourner5",
      "screen_name" : "sojourner5",
      "protected" : false,
      "id_str" : "18115781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425145524\/lantern2_normal.jpg",
      "id" : 18115781,
      "verified" : false
    }
  },
  "id" : 55616391935565824,
  "created_at" : "2011-04-06 13:02:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55613250309595136",
  "text" : "I dont get the animosity against Kindle from pbook lovers. Its all about choice, ppl!",
  "id" : 55613250309595136,
  "created_at" : "2011-04-06 12:50:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55439733660205056",
  "geo" : { },
  "id_str" : "55442050505641984",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves : )",
  "id" : 55442050505641984,
  "in_reply_to_status_id" : 55439733660205056,
  "created_at" : "2011-04-06 01:29:49 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55436896544899072",
  "geo" : { },
  "id_str" : "55438159265271808",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves thx 4 sharing yr DDs art.. that blog post. she's good. felt bad she was upset about the spill,tho..lol",
  "id" : 55438159265271808,
  "in_reply_to_status_id" : 55436896544899072,
  "created_at" : "2011-04-06 01:14:21 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55436896544899072",
  "geo" : { },
  "id_str" : "55437826929590272",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves im good, thx 4 asking.",
  "id" : 55437826929590272,
  "in_reply_to_status_id" : 55436896544899072,
  "created_at" : "2011-04-06 01:13:02 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55428445747945473",
  "geo" : { },
  "id_str" : "55436931168878592",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott interesting...",
  "id" : 55436931168878592,
  "in_reply_to_status_id" : 55428445747945473,
  "created_at" : "2011-04-06 01:09:29 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Inspirational Women",
      "screen_name" : "FamousWomen",
      "indices" : [ 22, 34 ],
      "id_str" : "128472974",
      "id" : 128472974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55436175451758592",
  "text" : "RT @Dwayne_Reaves: RT @FamousWomen: There are no mistakes in life, just lessons.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Inspirational Women",
        "screen_name" : "FamousWomen",
        "indices" : [ 3, 15 ],
        "id_str" : "128472974",
        "id" : 128472974
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55434148806008832",
    "text" : "RT @FamousWomen: There are no mistakes in life, just lessons.",
    "id" : 55434148806008832,
    "created_at" : "2011-04-06 00:58:25 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 55436175451758592,
  "created_at" : "2011-04-06 01:06:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55434335322521600",
  "geo" : { },
  "id_str" : "55435945360625664",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist awww, she sure loves that cow. very sweet story.",
  "id" : 55435945360625664,
  "in_reply_to_status_id" : 55434335322521600,
  "created_at" : "2011-04-06 01:05:33 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55421721137782784",
  "text" : "RT @stevetheseeker: The doorway to heaven is to become the open door.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55421266961760256",
    "text" : "The doorway to heaven is to become the open door.",
    "id" : 55421266961760256,
    "created_at" : "2011-04-06 00:07:14 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 55421721137782784,
  "created_at" : "2011-04-06 00:09:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55369523422961664",
  "text" : "RT @iwuvwes: Sounds a little strange to say \"Give these needy folks some cat litter,\" but that's exactly what this is: http:\/\/ow.ly\/4tK1I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55369126625021952",
    "text" : "Sounds a little strange to say \"Give these needy folks some cat litter,\" but that's exactly what this is: http:\/\/ow.ly\/4tK1I",
    "id" : 55369126625021952,
    "created_at" : "2011-04-05 20:40:03 +0000",
    "user" : {
      "name" : "Wesley",
      "screen_name" : "wuvtags",
      "protected" : false,
      "id_str" : "195433961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1244223989\/beaglepup_normal.gif",
      "id" : 195433961,
      "verified" : false
    }
  },
  "id" : 55369523422961664,
  "created_at" : "2011-04-05 20:41:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55369040859906048",
  "text" : "@Skandhasattva umm..thats creepy?",
  "id" : 55369040859906048,
  "created_at" : "2011-04-05 20:39:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan",
      "screen_name" : "FUZZY_TIGERZ",
      "indices" : [ 0, 13 ],
      "id_str" : "2907290939",
      "id" : 2907290939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55368963739226112",
  "in_reply_to_user_id" : 61921510,
  "text" : "@Fuzzy_Tigerz Happy Birthday! (hubby demanded it or he would beat us o-O )",
  "id" : 55368963739226112,
  "created_at" : "2011-04-05 20:39:24 +0000",
  "in_reply_to_screen_name" : "JenyG",
  "in_reply_to_user_id_str" : "61921510",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55368280390647809",
  "text" : "@Tideliar YES!!",
  "id" : 55368280390647809,
  "created_at" : "2011-04-05 20:36:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wisdom",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55359401355259904",
  "text" : "My Tumblr, In the moment http:\/\/bit.ly\/igniXj #wisdom",
  "id" : 55359401355259904,
  "created_at" : "2011-04-05 20:01:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 4, 17 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "John Peter  Thompson",
      "screen_name" : "InvasiveNotes",
      "indices" : [ 18, 32 ],
      "id_str" : "41100077",
      "id" : 41100077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55357381428776961",
  "geo" : { },
  "id_str" : "55358680580890624",
  "in_reply_to_user_id" : 36008885,
  "text" : "yes @UnseeingEyes @InvasiveNotes hate when that happens.. share great insight and hear the crickets..lol",
  "id" : 55358680580890624,
  "in_reply_to_status_id" : 55357381428776961,
  "created_at" : "2011-04-05 19:58:32 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 11, 24 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55356955597877249",
  "geo" : { },
  "id_str" : "55358351634219010",
  "in_reply_to_user_id" : 36008885,
  "text" : "absolutely @UnseeingEyes Ive met some great ppl on twitter. Love learning & interacting! : )",
  "id" : 55358351634219010,
  "in_reply_to_status_id" : 55356955597877249,
  "created_at" : "2011-04-05 19:57:14 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55355256095256576",
  "geo" : { },
  "id_str" : "55356442483507200",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes I only follow those who interest me. I dont do the follow back thing. I try to ignore the numbers..lol",
  "id" : 55356442483507200,
  "in_reply_to_status_id" : 55355256095256576,
  "created_at" : "2011-04-05 19:49:39 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BittenbyBooks.com",
      "screen_name" : "BittenbyBooks",
      "indices" : [ 103, 117 ],
      "id_str" : "14463494",
      "id" : 14463494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55344502143070208",
  "text" : "Author Tessa Adams Release Party \"Hidden Embers\" & $100 Amazon Gift Card Contest  http:\/\/bit.ly\/gAG36K @bittenbybooks",
  "id" : 55344502143070208,
  "created_at" : "2011-04-05 19:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55331701349560320",
  "text" : "RT @BayBitch: Smile like you have a severed head in your freezer.... :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55326894165467136",
    "text" : "Smile like you have a severed head in your freezer.... :D",
    "id" : 55326894165467136,
    "created_at" : "2011-04-05 17:52:14 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 55331701349560320,
  "created_at" : "2011-04-05 18:11:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55331526040240128",
  "text" : "RT @BayBitch: I'm not weird, I'm just a limited edition...like peppermint eggnog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55327613501177856",
    "text" : "I'm not weird, I'm just a limited edition...like peppermint eggnog",
    "id" : 55327613501177856,
    "created_at" : "2011-04-05 17:55:05 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 55331526040240128,
  "created_at" : "2011-04-05 18:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Abraham",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "Hicks",
      "indices" : [ 105, 111 ]
    }, {
      "text" : "Quotes",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "LoA",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55330836593115136",
  "text" : "RT @abe_quotes: ...You're feeling fear because you're not in the Vortex. \n\nPeriod. That's all.\n\n#Abraham #Hicks #Quotes #LoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abraham",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "Hicks",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "Quotes",
        "indices" : [ 96, 103 ]
      }, {
        "text" : "LoA",
        "indices" : [ 104, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55330691470209024",
    "text" : "...You're feeling fear because you're not in the Vortex. \n\nPeriod. That's all.\n\n#Abraham #Hicks #Quotes #LoA",
    "id" : 55330691470209024,
    "created_at" : "2011-04-05 18:07:19 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 55330836593115136,
  "created_at" : "2011-04-05 18:07:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55330820516360192",
  "text" : "RT @abe_quotes: ...You're not afraid because you're having a nervous breakdown. \n\n...You're not afraid because you're out of control...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55330617889525760",
    "text" : "...You're not afraid because you're having a nervous breakdown. \n\n...You're not afraid because you're out of control...",
    "id" : 55330617889525760,
    "created_at" : "2011-04-05 18:07:01 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 55330820516360192,
  "created_at" : "2011-04-05 18:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NGs_Calibreforum",
      "screen_name" : "Calibreforum",
      "indices" : [ 57, 70 ],
      "id_str" : "57641627",
      "id" : 57641627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55302880235749377",
  "text" : "I love how I can email books from my laptop 2 kindle via @Calibreforum software! ezpz! calibre FTW!",
  "id" : 55302880235749377,
  "created_at" : "2011-04-05 16:16:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55300736090775552",
  "geo" : { },
  "id_str" : "55302095229812736",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms feel better ((hugs))",
  "id" : 55302095229812736,
  "in_reply_to_status_id" : 55300736090775552,
  "created_at" : "2011-04-05 16:13:41 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Backlist eBooks",
      "screen_name" : "BacklisteBooks",
      "indices" : [ 3, 18 ],
      "id_str" : "180456479",
      "id" : 180456479
    }, {
      "name" : "Doranna Durgin",
      "screen_name" : "DorannaDurgin",
      "indices" : [ 23, 37 ],
      "id_str" : "22592787",
      "id" : 22592787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55300878319620096",
  "text" : "RT @BacklisteBooks: RT @dorannadurgin: Award-Winning authors; 16 stories: THE HEART OF DOG--and help for a sick dog.  http:\/\/ow.ly\/4tBUc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Doranna Durgin",
        "screen_name" : "DorannaDurgin",
        "indices" : [ 3, 17 ],
        "id_str" : "22592787",
        "id" : 22592787
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55298817909735424",
    "text" : "RT @dorannadurgin: Award-Winning authors; 16 stories: THE HEART OF DOG--and help for a sick dog.  http:\/\/ow.ly\/4tBUc",
    "id" : 55298817909735424,
    "created_at" : "2011-04-05 16:00:40 +0000",
    "user" : {
      "name" : "Backlist eBooks",
      "screen_name" : "BacklisteBooks",
      "protected" : false,
      "id_str" : "180456479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148017025\/BEB_square_246px_normal.jpg",
      "id" : 180456479,
      "verified" : false
    }
  },
  "id" : 55300878319620096,
  "created_at" : "2011-04-05 16:08:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "nook",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "ebook",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55300832509440001",
  "text" : "RT @byoung210: Looking for Book Reviewers: http:\/\/wp.me\/p15Plj-eR #kindle #nook #ebook http:\/\/wp.me\/p15Plj-eR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 51, 58 ]
      }, {
        "text" : "nook",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "ebook",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55299033052352512",
    "text" : "Looking for Book Reviewers: http:\/\/wp.me\/p15Plj-eR #kindle #nook #ebook http:\/\/wp.me\/p15Plj-eR",
    "id" : 55299033052352512,
    "created_at" : "2011-04-05 16:01:31 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 55300832509440001,
  "created_at" : "2011-04-05 16:08:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55288609275785216",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks I did! I should have said I \"purchased\".. lol",
  "id" : 55288609275785216,
  "created_at" : "2011-04-05 15:20:06 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55285424012271616",
  "geo" : { },
  "id_str" : "55287910894804992",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks TY! I chose \"Frozen Stiff\" by Mary Logue",
  "id" : 55287910894804992,
  "in_reply_to_status_id" : 55285424012271616,
  "created_at" : "2011-04-05 15:17:19 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 3, 14 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55284697181327360",
  "text" : "RT @quantafire: There is no escape.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55284510958424064",
    "text" : "There is no escape.",
    "id" : 55284510958424064,
    "created_at" : "2011-04-05 15:03:49 +0000",
    "user" : {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "protected" : false,
      "id_str" : "8449382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2943941501\/b15b399a7823bad25f64b6482704e678_normal.jpeg",
      "id" : 8449382,
      "verified" : false
    }
  },
  "id" : 55284697181327360,
  "created_at" : "2011-04-05 15:04:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55280391594065920",
  "geo" : { },
  "id_str" : "55284365294440448",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks YES! : )",
  "id" : 55284365294440448,
  "in_reply_to_status_id" : 55280391594065920,
  "created_at" : "2011-04-05 15:03:14 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55271520859197440",
  "text" : "RT @nuart11: Facebook asks what I\u2019m thinking. Twitter asks what I\u2019m doing. Foursquare asks where I am. The internet has turned into a cr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54904014785085440",
    "text" : "Facebook asks what I\u2019m thinking. Twitter asks what I\u2019m doing. Foursquare asks where I am. The internet has turned into a crazy girlfriend.",
    "id" : 54904014785085440,
    "created_at" : "2011-04-04 13:51:51 +0000",
    "user" : {
      "name" : "Martyn Reed",
      "screen_name" : "NuartFestival",
      "protected" : false,
      "id_str" : "19143733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753207190941536256\/0QbTJzwO_normal.jpg",
      "id" : 19143733,
      "verified" : false
    }
  },
  "id" : 55271520859197440,
  "created_at" : "2011-04-05 14:12:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55262078713348096",
  "text" : "love my vanilla coffee..yum!",
  "id" : 55262078713348096,
  "created_at" : "2011-04-05 13:34:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54953183792992256",
  "text" : "thinks pork is culprit for off stomach today.",
  "id" : 54953183792992256,
  "created_at" : "2011-04-04 17:07:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54952696121278465",
  "text" : "Karate Kid Fights Off 'DWTS' Foes - ABC News http:\/\/abcn.ws\/ewFMYY",
  "id" : 54952696121278465,
  "created_at" : "2011-04-04 17:05:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChiefJoseph",
      "indices" : [ 63, 75 ]
    }, {
      "text" : "quotes",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54933993119940608",
  "text" : "RT @JohnCali: Daily affirmation: I have an abundance of money. #ChiefJoseph #quotes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChiefJoseph",
        "indices" : [ 49, 61 ]
      }, {
        "text" : "quotes",
        "indices" : [ 62, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54932595905007616",
    "text" : "Daily affirmation: I have an abundance of money. #ChiefJoseph #quotes",
    "id" : 54932595905007616,
    "created_at" : "2011-04-04 15:45:26 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 54933993119940608,
  "created_at" : "2011-04-04 15:50:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 3, 14 ],
      "id_str" : "76225852",
      "id" : 76225852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54933724869042176",
  "text" : "RT @TraLeeFitz: We are too busy mopping the floor to turn off the faucet. - Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54926735040462848",
    "text" : "We are too busy mopping the floor to turn off the faucet. - Unknown",
    "id" : 54926735040462848,
    "created_at" : "2011-04-04 15:22:08 +0000",
    "user" : {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "protected" : false,
      "id_str" : "76225852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798982593702023168\/XfVHvWY7_normal.jpg",
      "id" : 76225852,
      "verified" : false
    }
  },
  "id" : 54933724869042176,
  "created_at" : "2011-04-04 15:49:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54917477850824704",
  "geo" : { },
  "id_str" : "54921547072278530",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott thx 4 referral. im now subscribed to newsletter & will check out site.",
  "id" : 54921547072278530,
  "in_reply_to_status_id" : 54917477850824704,
  "created_at" : "2011-04-04 15:01:31 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54918598401081344",
  "geo" : { },
  "id_str" : "54921219308388352",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad I can empathize w that. Feel better ((hugs))",
  "id" : 54921219308388352,
  "in_reply_to_status_id" : 54918598401081344,
  "created_at" : "2011-04-04 15:00:13 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54917341800169473",
  "text" : "so last night, first lay down, had bubbling from stomach on up. No pain. happened 1xB4. keeping head up a bit helped. acid??",
  "id" : 54917341800169473,
  "created_at" : "2011-04-04 14:44:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    }, {
      "name" : "Kenny Silanskas",
      "screen_name" : "webkenny",
      "indices" : [ 25, 34 ],
      "id_str" : "12082342",
      "id" : 12082342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54909652923719680",
  "geo" : { },
  "id_str" : "54916398648016896",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal ((hugs)) glad @webkenny is w you! : )",
  "id" : 54916398648016896,
  "in_reply_to_status_id" : 54909652923719680,
  "created_at" : "2011-04-04 14:41:04 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54915243607998464",
  "text" : "stomach off again.. sigh.",
  "id" : 54915243607998464,
  "created_at" : "2011-04-04 14:36:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We Speak your mind",
      "screen_name" : "TweetyQuote",
      "indices" : [ 3, 15 ],
      "id_str" : "188361824",
      "id" : 188361824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tweetyquote",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54898836577062912",
  "text" : "RT @TweetyQuote: Life is better when you decide you don't care. #Tweetyquote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tweetyquote",
        "indices" : [ 47, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54885849648734208",
    "text" : "Life is better when you decide you don't care. #Tweetyquote",
    "id" : 54885849648734208,
    "created_at" : "2011-04-04 12:39:40 +0000",
    "user" : {
      "name" : "We Speak your mind",
      "screen_name" : "TweetyQuote",
      "protected" : false,
      "id_str" : "188361824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1246043981\/Untitlsed-1_normal.jpg",
      "id" : 188361824,
      "verified" : false
    }
  },
  "id" : 54898836577062912,
  "created_at" : "2011-04-04 13:31:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54895990544662528",
  "text" : "RT @Dwayne_Reaves: \"My 10 yr old artist!\" http:\/\/bit.ly\/fVFvh6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54885793164038145",
    "text" : "\"My 10 yr old artist!\" http:\/\/bit.ly\/fVFvh6",
    "id" : 54885793164038145,
    "created_at" : "2011-04-04 12:39:27 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 54895990544662528,
  "created_at" : "2011-04-04 13:19:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54882713307578368",
  "geo" : { },
  "id_str" : "54883880972464128",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books YVW : )",
  "id" : 54883880972464128,
  "in_reply_to_status_id" : 54882713307578368,
  "created_at" : "2011-04-04 12:31:51 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett L Hutsko",
      "screen_name" : "glhutsko",
      "indices" : [ 3, 12 ],
      "id_str" : "230700879",
      "id" : 230700879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54883504131014656",
  "text" : "RT @glhutsko: No act of kindness, no matter how small, is ever wasted. - Aesop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/grandslambiz.com\/\" rel=\"nofollow\"\u003Eglhlaptop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54735847978844160",
    "text" : "No act of kindness, no matter how small, is ever wasted. - Aesop",
    "id" : 54735847978844160,
    "created_at" : "2011-04-04 02:43:37 +0000",
    "user" : {
      "name" : "Garrett L Hutsko",
      "screen_name" : "glhutsko",
      "protected" : false,
      "id_str" : "230700879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1199126164\/Image_00031a_normal.jpg",
      "id" : 230700879,
      "verified" : false
    }
  },
  "id" : 54883504131014656,
  "created_at" : "2011-04-04 12:30:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54721089976287232",
  "geo" : { },
  "id_str" : "54723574698754048",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott yes, the whole western medicine needs an overhaul",
  "id" : 54723574698754048,
  "in_reply_to_status_id" : 54721089976287232,
  "created_at" : "2011-04-04 01:54:51 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54720890272890880",
  "geo" : { },
  "id_str" : "54723402132504577",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts absolutely.. we all have egos and those egos will fight to remain in charge",
  "id" : 54723402132504577,
  "in_reply_to_status_id" : 54720890272890880,
  "created_at" : "2011-04-04 01:54:10 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 76, 87 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54711406334971904",
  "geo" : { },
  "id_str" : "54712093705904128",
  "in_reply_to_user_id" : 6994832,
  "text" : "you have got a good point there missy! they get something out of it.. hmm.. @TrishScott",
  "id" : 54712093705904128,
  "in_reply_to_status_id" : 54711406334971904,
  "created_at" : "2011-04-04 01:09:14 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 63, 74 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54709364480688129",
  "geo" : { },
  "id_str" : "54711771470106624",
  "in_reply_to_user_id" : 6994832,
  "text" : "all \"insurance\" is about profit .. health insurance is a fraud @TrishScott",
  "id" : 54711771470106624,
  "in_reply_to_status_id" : 54709364480688129,
  "created_at" : "2011-04-04 01:07:57 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54710721526775808",
  "text" : "I just don't get atheists & christians arguing w each other.",
  "id" : 54710721526775808,
  "created_at" : "2011-04-04 01:03:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54696801361596417",
  "text" : "RT @stevetheseeker: There is no outer religion, doctrine, ritual, prayer , guru, savior or organization that can save you.   It's all in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54696623246295040",
    "text" : "There is no outer religion, doctrine, ritual, prayer , guru, savior or organization that can save you.   It's all inside you.",
    "id" : 54696623246295040,
    "created_at" : "2011-04-04 00:07:45 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 54696801361596417,
  "created_at" : "2011-04-04 00:08:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54695286592905217",
  "text" : "\"you survived because you did something\" says my DD to tv show \"I survived\" .. god she amazes me! : )",
  "id" : 54695286592905217,
  "created_at" : "2011-04-04 00:02:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54592413381033984",
  "text" : "My Tumblr, In the moment http:\/\/bit.ly\/garmnX",
  "id" : 54592413381033984,
  "created_at" : "2011-04-03 17:13:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54573497078390786",
  "text" : "RT @DeepakChopra: Be not the reaction but the observer of the reaction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54382494736326656",
    "text" : "Be not the reaction but the observer of the reaction",
    "id" : 54382494736326656,
    "created_at" : "2011-04-03 03:19:31 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 54573497078390786,
  "created_at" : "2011-04-03 15:58:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54351059988135938",
  "text" : "@Reformation_Now very wise grandmother. thx 4 sharing. so true!",
  "id" : 54351059988135938,
  "created_at" : "2011-04-03 01:14:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IlluminativeVisions",
      "screen_name" : "Illumnative_Vis",
      "indices" : [ 3, 19 ],
      "id_str" : "103718492",
      "id" : 103718492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54350580168130560",
  "text" : "RT @Illumnative_Vis: The purpose of our lives is to be happy.\nDalai Lama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54328830583771136",
    "text" : "The purpose of our lives is to be happy.\nDalai Lama",
    "id" : 54328830583771136,
    "created_at" : "2011-04-02 23:46:17 +0000",
    "user" : {
      "name" : "IlluminativeVisions",
      "screen_name" : "Illumnative_Vis",
      "protected" : false,
      "id_str" : "103718492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1168008902\/asian_sunrisemodified_normal.png",
      "id" : 103718492,
      "verified" : false
    }
  },
  "id" : 54350580168130560,
  "created_at" : "2011-04-03 01:12:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 44, 53 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54347600052240385",
  "geo" : { },
  "id_str" : "54348375344156673",
  "in_reply_to_user_id" : 27094110,
  "text" : "like taking off a tight shoe.. I love that! @JohnCali",
  "id" : 54348375344156673,
  "in_reply_to_status_id" : 54347600052240385,
  "created_at" : "2011-04-03 01:03:57 +0000",
  "in_reply_to_screen_name" : "JohnCali",
  "in_reply_to_user_id_str" : "27094110",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54348210663194624",
  "text" : "RT @JohnCali: Dying is the easiest thing you will ever do, because you\u2019re reemerging back into the world of spirit...bac\u2026 (cont) http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54347600052240385",
    "text" : "Dying is the easiest thing you will ever do, because you\u2019re reemerging back into the world of spirit...bac\u2026 (cont) http:\/\/deck.ly\/~34Qhc",
    "id" : 54347600052240385,
    "created_at" : "2011-04-03 01:00:52 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 54348210663194624,
  "created_at" : "2011-04-03 01:03:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 14, 27 ],
      "id_str" : "124594428",
      "id" : 124594428
    }, {
      "name" : "Linda Welch",
      "screen_name" : "welch6331",
      "indices" : [ 28, 38 ],
      "id_str" : "23035566",
      "id" : 23035566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54340161869316096",
  "text" : "These writers @golden_books @welch6331 make it easy to purchase their books! (see their pages)",
  "id" : 54340161869316096,
  "created_at" : "2011-04-03 00:31:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 7, 20 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54276305201532928",
  "geo" : { },
  "id_str" : "54282162467373057",
  "in_reply_to_user_id" : 35585695,
  "text" : "ribbit @derekrootboy",
  "id" : 54282162467373057,
  "in_reply_to_status_id" : 54276305201532928,
  "created_at" : "2011-04-02 20:40:50 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54240530778963968",
  "text" : "RT @TrishScott: The leading cause of death is birth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54240318639456256",
    "text" : "The leading cause of death is birth.",
    "id" : 54240318639456256,
    "created_at" : "2011-04-02 17:54:34 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 54240530778963968,
  "created_at" : "2011-04-02 17:55:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54240070198239232",
  "text" : "teen nephew spending time w us today. He & DD both love video games. Nice!",
  "id" : 54240070198239232,
  "created_at" : "2011-04-02 17:53:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54220591661719554",
  "text" : "@BibleAlsoSays good article, thx. multitude of religions made me wonder since little what it was all about...",
  "id" : 54220591661719554,
  "created_at" : "2011-04-02 16:36:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 4, 14 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54220245732298752",
  "text" : "hey @DougDorow how's the 9th district doing? almost ready?",
  "id" : 54220245732298752,
  "created_at" : "2011-04-02 16:34:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54207766440587264",
  "text" : "@BibleAlsoSays YES totally agree! think not just follow what we've been told to do",
  "id" : 54207766440587264,
  "created_at" : "2011-04-02 15:45:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 74, 88 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54207412118360064",
  "text" : "but who says what is \"right\"? where is that exact line? I cant find it... @BibleAlsoSays",
  "id" : 54207412118360064,
  "created_at" : "2011-04-02 15:43:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 122, 136 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54205257101750272",
  "text" : "wellll..I cant agree w that. I think religious or not we all, by nature, raise our children the way \"we\" think is \"right\" @BibleAlsoSays",
  "id" : 54205257101750272,
  "created_at" : "2011-04-02 15:35:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 88, 102 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54204675796385793",
  "text" : "thank god?? hehe.. just kidding ; ) I use that as expression.. like bless you 4 sneezes @BibleAlsoSays",
  "id" : 54204675796385793,
  "created_at" : "2011-04-02 15:32:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 36, 50 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54201575006142464",
  "text" : "dont we all inculcate our children? @BibleAlsoSays",
  "id" : 54201575006142464,
  "created_at" : "2011-04-02 15:20:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Covino & Rich",
      "screen_name" : "CovinoandRich",
      "indices" : [ 3, 17 ],
      "id_str" : "17873794",
      "id" : 17873794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54197061360418816",
  "text" : "RT @CovinoandRich: Why are people surprised that Snookie got paid more than a Nobel prize winner to speak? Supply and demand homies! It' ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54194153130692608",
    "text" : "Why are people surprised that Snookie got paid more than a Nobel prize winner to speak? Supply and demand homies! It's your own fault!",
    "id" : 54194153130692608,
    "created_at" : "2011-04-02 14:51:07 +0000",
    "user" : {
      "name" : "Covino & Rich",
      "screen_name" : "CovinoandRich",
      "protected" : false,
      "id_str" : "17873794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789898439861547008\/Lef0MR9X_normal.jpg",
      "id" : 17873794,
      "verified" : true
    }
  },
  "id" : 54197061360418816,
  "created_at" : "2011-04-02 15:02:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin-Health Nut News",
      "screen_name" : "unhealthytruth",
      "indices" : [ 3, 18 ],
      "id_str" : "18093097",
      "id" : 18093097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54196739355316224",
  "text" : "RT @unhealthytruth: Need proof that Big Food doesn't use food dyes in their products in other countries? Check out this picture =&gt; ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54192870609002496",
    "text" : "Need proof that Big Food doesn't use food dyes in their products in other countries? Check out this picture =&gt; http:\/\/twitpic.com\/4g3tzd",
    "id" : 54192870609002496,
    "created_at" : "2011-04-02 14:46:01 +0000",
    "user" : {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "protected" : false,
      "id_str" : "25056239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684904916184256512\/Zr_EBvr0_normal.jpg",
      "id" : 25056239,
      "verified" : false
    }
  },
  "id" : 54196739355316224,
  "created_at" : "2011-04-02 15:01:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54189696313597952",
  "text" : "RT @hauntedcomputer: some people watch TV. I watch Twitter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54189411461644288",
    "text" : "some people watch TV. I watch Twitter",
    "id" : 54189411461644288,
    "created_at" : "2011-04-02 14:32:17 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 54189696313597952,
  "created_at" : "2011-04-02 14:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54189111656972289",
  "text" : "RT @TrishScott: LOL RT @helloinhere: Existence is a con.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54175041486729216",
    "text" : "LOL RT @helloinhere: Existence is a con.",
    "id" : 54175041486729216,
    "created_at" : "2011-04-02 13:35:11 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 54189111656972289,
  "created_at" : "2011-04-02 14:31:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54001670841057280",
  "geo" : { },
  "id_str" : "54004693789192192",
  "in_reply_to_user_id" : 133780513,
  "text" : "@Twyttlededum you got it ((hugs))",
  "id" : 54004693789192192,
  "in_reply_to_status_id" : 54001670841057280,
  "created_at" : "2011-04-02 02:18:17 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53998025013596160",
  "text" : "@statue_dog resistance is futile! lol",
  "id" : 53998025013596160,
  "created_at" : "2011-04-02 01:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53891758362341376",
  "text" : "I have eaten too many girl scout cookies...",
  "id" : 53891758362341376,
  "created_at" : "2011-04-01 18:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53891610622181376",
  "text" : "My laptop got hijacked. Hubby is running a program to try 2 fix.",
  "id" : 53891610622181376,
  "created_at" : "2011-04-01 18:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getfanged",
      "screen_name" : "getfanged",
      "indices" : [ 3, 13 ],
      "id_str" : "295045472",
      "id" : 295045472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53872437137375232",
  "text" : "RT @getfanged: Only 100 more followers until we give away another Amazon.com gift card!  Anyone who RTs, and the next 100 followers, hav ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53864575568842752",
    "text" : "Only 100 more followers until we give away another Amazon.com gift card!  Anyone who RTs, and the next 100 followers, have a chance to win!",
    "id" : 53864575568842752,
    "created_at" : "2011-04-01 17:01:30 +0000",
    "user" : {
      "name" : "DarkMedia",
      "screen_name" : "DarkMediaOnline",
      "protected" : false,
      "id_str" : "239169186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000039912498\/2cca0586eb8ebcc5a8b0f7ebe3ee2ca7_normal.jpeg",
      "id" : 239169186,
      "verified" : false
    }
  },
  "id" : 53872437137375232,
  "created_at" : "2011-04-01 17:32:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "romance",
      "indices" : [ 42, 50 ]
    }, {
      "text" : "selfpub",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "indieauthor",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53836035720871936",
  "text" : "RT @JAScribbles: Update - I need one more #romance ebook for my giveaway. SUCH AWESOME friends you all are. :-) #selfpub #indieauthor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "romance",
        "indices" : [ 25, 33 ]
      }, {
        "text" : "selfpub",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "indieauthor",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53835550473453568",
    "text" : "Update - I need one more #romance ebook for my giveaway. SUCH AWESOME friends you all are. :-) #selfpub #indieauthor",
    "id" : 53835550473453568,
    "created_at" : "2011-04-01 15:06:10 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 53836035720871936,
  "created_at" : "2011-04-01 15:08:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/zPaSxfP",
      "expanded_url" : "http:\/\/www.newscientist.com\/article\/dn20328-ravens-kiss-and-make-up-after-a-brawl.html",
      "display_url" : "newscientist.com\/article\/dn2032\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "53833556232912896",
  "text" : "RT @Jambodhi: Ravens kiss and make up after a brawl - 01 April 2011 - New Scientist http:\/\/t.co\/zPaSxfP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 89 ],
        "url" : "http:\/\/t.co\/zPaSxfP",
        "expanded_url" : "http:\/\/www.newscientist.com\/article\/dn20328-ravens-kiss-and-make-up-after-a-brawl.html",
        "display_url" : "newscientist.com\/article\/dn2032\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "53829157624360960",
    "text" : "Ravens kiss and make up after a brawl - 01 April 2011 - New Scientist http:\/\/t.co\/zPaSxfP",
    "id" : 53829157624360960,
    "created_at" : "2011-04-01 14:40:45 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 53833556232912896,
  "created_at" : "2011-04-01 14:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfpub",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "indieauthor",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53832675752034304",
  "text" : "RT @JAScribbles: Ok - I need one more ebook for my giveaway. I am looking for thriller, suspense, or horror. #selfpub #indieauthor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfpub",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "indieauthor",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53832226546257921",
    "text" : "Ok - I need one more ebook for my giveaway. I am looking for thriller, suspense, or horror. #selfpub #indieauthor",
    "id" : 53832226546257921,
    "created_at" : "2011-04-01 14:52:57 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 53832675752034304,
  "created_at" : "2011-04-01 14:54:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53813604817973248",
  "text" : "RT @JAScribbles: Morning author friends. I am planning another ebook giveaway. If you have a title you'd like to donate @ me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53811710712229888",
    "text" : "Morning author friends. I am planning another ebook giveaway. If you have a title you'd like to donate @ me.",
    "id" : 53811710712229888,
    "created_at" : "2011-04-01 13:31:26 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 53813604817973248,
  "created_at" : "2011-04-01 13:38:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53804635550515200",
  "text" : "Lonely linky needs yr book giveaways! http:\/\/budurl.com\/readerswinlinky Plz RT-TY",
  "id" : 53804635550515200,
  "created_at" : "2011-04-01 13:03:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]