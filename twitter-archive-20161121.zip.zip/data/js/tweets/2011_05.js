Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Network Mktg Mag",
      "screen_name" : "TNMM",
      "indices" : [ 3, 8 ],
      "id_str" : "6167582",
      "id" : 6167582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75731208255975424",
  "text" : "RT @TNMM: ASK Yourself this question, \"If no one told me who I was, who would I be?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75524837736587264",
    "text" : "ASK Yourself this question, \"If no one told me who I was, who would I be?",
    "id" : 75524837736587264,
    "created_at" : "2011-05-31 11:31:39 +0000",
    "user" : {
      "name" : "The Network Mktg Mag",
      "screen_name" : "TNMM",
      "protected" : false,
      "id_str" : "6167582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447651683\/Cover_2009_October_normal.jpg",
      "id" : 6167582,
      "verified" : false
    }
  },
  "id" : 75731208255975424,
  "created_at" : "2011-06-01 01:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 21, 28 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75713234396651521",
  "text" : "omg.. cute alert! RT @Mahala: I found this while mowing http:\/\/yfrog.com\/h7f7xhlj",
  "id" : 75713234396651521,
  "created_at" : "2011-06-01 00:00:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75706540102926336",
  "text" : "@Skandhasattva hubby is everyone's \"fix it!\" guy..lol",
  "id" : 75706540102926336,
  "created_at" : "2011-05-31 23:33:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75705615732834306",
  "text" : "@Skandhasattva uh-oh",
  "id" : 75705615732834306,
  "created_at" : "2011-05-31 23:29:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75704603496300544",
  "geo" : { },
  "id_str" : "75705256662675456",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awww...",
  "id" : 75705256662675456,
  "in_reply_to_status_id" : 75704603496300544,
  "created_at" : "2011-05-31 23:28:34 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75700729607757824",
  "text" : "@tragic_pizza write a love letter highlighting special memories through the years",
  "id" : 75700729607757824,
  "created_at" : "2011-05-31 23:10:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75666852679917568",
  "geo" : { },
  "id_str" : "75667729931186177",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist well, alrighty then...",
  "id" : 75667729931186177,
  "in_reply_to_status_id" : 75666852679917568,
  "created_at" : "2011-05-31 20:59:27 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75667138521735168",
  "text" : "RT @ceebee308: Our cat ate our aloe plant so now when she scratches us, we heal instantly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75662124143214592",
    "text" : "Our cat ate our aloe plant so now when she scratches us, we heal instantly.",
    "id" : 75662124143214592,
    "created_at" : "2011-05-31 20:37:10 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 75667138521735168,
  "created_at" : "2011-05-31 20:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75665401807253504",
  "text" : "A Kindle World blog: new Nook vs Kindle: features http:\/\/bit.ly\/iX3MwC good article shows comparison (choose whats important 2U)",
  "id" : 75665401807253504,
  "created_at" : "2011-05-31 20:50:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75652361917448192",
  "text" : "RT @ceebee308: If appendices and gall bladders aren\u2019t really necessary, why do they keep putting them in new people they make?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75652058413404160",
    "text" : "If appendices and gall bladders aren\u2019t really necessary, why do they keep putting them in new people they make?",
    "id" : 75652058413404160,
    "created_at" : "2011-05-31 19:57:10 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 75652361917448192,
  "created_at" : "2011-05-31 19:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75652278824091649",
  "text" : "LOLOL!!! 7 Sex Tips from Cosmo That Will Put You in the Hospital Cracked.com http:\/\/bit.ly\/kLf57P",
  "id" : 75652278824091649,
  "created_at" : "2011-05-31 19:58:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 3, 16 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75647523901018112",
  "text" : "RT @bigfishgames: FREE on iPad and iPhone: Everest: Hidden Expedition Get the FULL version FREE sponsored by iSplash http:\/\/bigfi.sh\/lI5P7O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75638461897510912",
    "text" : "FREE on iPad and iPhone: Everest: Hidden Expedition Get the FULL version FREE sponsored by iSplash http:\/\/bigfi.sh\/lI5P7O",
    "id" : 75638461897510912,
    "created_at" : "2011-05-31 19:03:09 +0000",
    "user" : {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "protected" : false,
      "id_str" : "14124789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676860668365029376\/hAOsWfK1_normal.jpg",
      "id" : 14124789,
      "verified" : false
    }
  },
  "id" : 75647523901018112,
  "created_at" : "2011-05-31 19:39:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75631589819817984",
  "geo" : { },
  "id_str" : "75632840116674560",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous I have the 1st one as well. had a sony 505 for about 18 months..loved it.",
  "id" : 75632840116674560,
  "in_reply_to_status_id" : 75631589819817984,
  "created_at" : "2011-05-31 18:40:48 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75631589819817984",
  "geo" : { },
  "id_str" : "75632468224524288",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous I have an ebook blog with many links at http:\/\/budurl.com\/myebookblog you might find useful : )",
  "id" : 75632468224524288,
  "in_reply_to_status_id" : 75631589819817984,
  "created_at" : "2011-05-31 18:39:20 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75630201320652800",
  "geo" : { },
  "id_str" : "75630663100940289",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous hehe..then you're either a Kindler or a Koboer..lol",
  "id" : 75630663100940289,
  "in_reply_to_status_id" : 75630201320652800,
  "created_at" : "2011-05-31 18:32:09 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75629071257710592",
  "geo" : { },
  "id_str" : "75630004804915200",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous which reader do you use?",
  "id" : 75630004804915200,
  "in_reply_to_status_id" : 75629071257710592,
  "created_at" : "2011-05-31 18:29:32 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Glen Munro",
      "screen_name" : "gm_pentaxfan",
      "indices" : [ 72, 85 ],
      "id_str" : "93662694",
      "id" : 93662694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "Waterton_Lakes_National_Park",
      "indices" : [ 102, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75629002089435136",
  "text" : "RT @wildobs: In case you missed it: Moose http:\/\/wildobs.com\/wo\/3677 by @gm_pentaxfan #EOTD #wildlife #Waterton_Lakes_National_Park",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glen Munro",
        "screen_name" : "gm_pentaxfan",
        "indices" : [ 59, 72 ],
        "id_str" : "93662694",
        "id" : 93662694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 73, 78 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 79, 88 ]
      }, {
        "text" : "Waterton_Lakes_National_Park",
        "indices" : [ 89, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75623939598057472",
    "text" : "In case you missed it: Moose http:\/\/wildobs.com\/wo\/3677 by @gm_pentaxfan #EOTD #wildlife #Waterton_Lakes_National_Park",
    "id" : 75623939598057472,
    "created_at" : "2011-05-31 18:05:26 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 75629002089435136,
  "created_at" : "2011-05-31 18:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyfully Reviewed",
      "screen_name" : "JoyfullyReviewd",
      "indices" : [ 3, 19 ],
      "id_str" : "15359153",
      "id" : 15359153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75613895766708224",
  "text" : "RT @JoyfullyReviewd: ATTN AUTHORS\/PUBLISHERS: Want 2 participate in JR's Lori Foster's Reader Appreciation Weekend Giveaway? mail me: jo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75611852134027265",
    "text" : "ATTN AUTHORS\/PUBLISHERS: Want 2 participate in JR's Lori Foster's Reader Appreciation Weekend Giveaway? mail me: joyfully.contests@gmail.com",
    "id" : 75611852134027265,
    "created_at" : "2011-05-31 17:17:25 +0000",
    "user" : {
      "name" : "Joyfully Reviewed",
      "screen_name" : "JoyfullyReviewd",
      "protected" : false,
      "id_str" : "15359153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800093706846109696\/27l_Ko79_normal.jpg",
      "id" : 15359153,
      "verified" : false
    }
  },
  "id" : 75613895766708224,
  "created_at" : "2011-05-31 17:25:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Alan",
      "screen_name" : "Patrick_Alan",
      "indices" : [ 3, 16 ],
      "id_str" : "53185169",
      "id" : 53185169
    }, {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 45, 60 ],
      "id_str" : "24616866",
      "id" : 24616866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75603683781525505",
  "text" : "RT @Patrick_Alan: This is how I proposed. RT @andrewtshaffer: \"He slapped her round pert ass. 'I think I'm going to like being married t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/app\" rel=\"nofollow\"\u003ESeesmic Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Shaffer",
        "screen_name" : "andrewtshaffer",
        "indices" : [ 27, 42 ],
        "id_str" : "24616866",
        "id" : 24616866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75602573259845632",
    "text" : "This is how I proposed. RT @andrewtshaffer: \"He slapped her round pert ass. 'I think I'm going to like being married to you,' he said.\"",
    "id" : 75602573259845632,
    "created_at" : "2011-05-31 16:40:32 +0000",
    "user" : {
      "name" : "Patrick Alan",
      "screen_name" : "Patrick_Alan",
      "protected" : false,
      "id_str" : "53185169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1384280433\/ME2_normal.JPG",
      "id" : 53185169,
      "verified" : false
    }
  },
  "id" : 75603683781525505,
  "created_at" : "2011-05-31 16:44:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75601968751575040",
  "text" : "RT @andrewtshaffer: \"He emptied his seed into her and it crossed his mind that this was how she had become pregnant the first time.\" #sm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smarthero",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75598137745604609",
    "text" : "\"He emptied his seed into her and it crossed his mind that this was how she had become pregnant the first time.\" #smarthero",
    "id" : 75598137745604609,
    "created_at" : "2011-05-31 16:22:55 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 75601968751575040,
  "created_at" : "2011-05-31 16:38:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75596964850438144",
  "geo" : { },
  "id_str" : "75600230468423680",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy sign of genius = use of word \"antipathy\"",
  "id" : 75600230468423680,
  "in_reply_to_status_id" : 75596964850438144,
  "created_at" : "2011-05-31 16:31:14 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75597127413268480",
  "geo" : { },
  "id_str" : "75600132325916672",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy I like the jokes. Politics is over my head. Its like greek to me so I skip over.",
  "id" : 75600132325916672,
  "in_reply_to_status_id" : 75597127413268480,
  "created_at" : "2011-05-31 16:30:50 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75597378119409664",
  "geo" : { },
  "id_str" : "75599940763652096",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy I never know who I lose for what. Ppl come & go. Think they expect me to follow back,I dont,they leave.",
  "id" : 75599940763652096,
  "in_reply_to_status_id" : 75597378119409664,
  "created_at" : "2011-05-31 16:30:05 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75595606516695040",
  "geo" : { },
  "id_str" : "75596016820301824",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy what cats would those be?",
  "id" : 75596016820301824,
  "in_reply_to_status_id" : 75595606516695040,
  "created_at" : "2011-05-31 16:14:29 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75592711364804609",
  "text" : "dear universe,dont know why you have me going to bible study but thx for giving me patience..hehe",
  "id" : 75592711364804609,
  "created_at" : "2011-05-31 16:01:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyrical Press",
      "screen_name" : "lyricalpress",
      "indices" : [ 3, 16 ],
      "id_str" : "176693088",
      "id" : 176693088
    }, {
      "name" : "Lyrical Press",
      "screen_name" : "lyricalpress",
      "indices" : [ 87, 100 ],
      "id_str" : "176693088",
      "id" : 176693088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75525558108307456",
  "text" : "RT @lyricalpress: Retweet this post for a chance to a win a $20 for Lyrical's store if @lyricalpress reaches 200 followers today!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lyrical Press",
        "screen_name" : "lyricalpress",
        "indices" : [ 69, 82 ],
        "id_str" : "176693088",
        "id" : 176693088
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75504980940947456",
    "text" : "Retweet this post for a chance to a win a $20 for Lyrical's store if @lyricalpress reaches 200 followers today!",
    "id" : 75504980940947456,
    "created_at" : "2011-05-31 10:12:44 +0000",
    "user" : {
      "name" : "Lyrical Press",
      "screen_name" : "lyricalpress",
      "protected" : false,
      "id_str" : "176693088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750726981155753984\/oMgg_By__normal.jpg",
      "id" : 176693088,
      "verified" : false
    }
  },
  "id" : 75525558108307456,
  "created_at" : "2011-05-31 11:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75511597161922560",
  "geo" : { },
  "id_str" : "75525347151593472",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell GM. coffee could be better but sun is out : )",
  "id" : 75525347151593472,
  "in_reply_to_status_id" : 75511597161922560,
  "created_at" : "2011-05-31 11:33:40 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 3, 16 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75357635473440768",
  "text" : "RT @JoanneMFirth: I think it's time to call the exterminator, but I hate pesticides. Any non-toxic solutions to spiders would be appreci ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75355288265428992",
    "text" : "I think it's time to call the exterminator, but I hate pesticides. Any non-toxic solutions to spiders would be appreciated. Thanks!",
    "id" : 75355288265428992,
    "created_at" : "2011-05-31 00:17:55 +0000",
    "user" : {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "protected" : false,
      "id_str" : "133780513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781251467135029255\/diCGFaAe_normal.jpg",
      "id" : 133780513,
      "verified" : false
    }
  },
  "id" : 75357635473440768,
  "created_at" : "2011-05-31 00:27:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75323921997639680",
  "text" : "it turned out to be a good day.. well, except I did have 3 beers and now feel a little ill.",
  "id" : 75323921997639680,
  "created_at" : "2011-05-30 22:13:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75244473004732416",
  "geo" : { },
  "id_str" : "75323207162413056",
  "in_reply_to_user_id" : 210259527,
  "text" : "@SarahakaLegion TY : )",
  "id" : 75323207162413056,
  "in_reply_to_status_id" : 75244473004732416,
  "created_at" : "2011-05-30 22:10:26 +0000",
  "in_reply_to_screen_name" : "YK_Greene",
  "in_reply_to_user_id_str" : "210259527",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75234508068233216",
  "text" : "@Skandhasattva I havent had a girl friend since teen. I miss having a female to giggle with. but I do have my DD & we giggle A LOT! : )",
  "id" : 75234508068233216,
  "created_at" : "2011-05-30 16:17:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75233618875793408",
  "text" : "@Skandhasattva you sound like hubby..lol",
  "id" : 75233618875793408,
  "created_at" : "2011-05-30 16:14:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75233044906258433",
  "text" : "I only wear a bra when absolutely have to (ie. in front of ppl).. cant do it today so wearing 2 tshirts.",
  "id" : 75233044906258433,
  "created_at" : "2011-05-30 16:12:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75231663092793344",
  "text" : "RT @petsalive: Is there anyone out there that can transport these mini donkeys from Banner Elk, NC to Pets Alive? http:\/\/yfrog.com\/h0268p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75224646127063040",
    "text" : "Is there anyone out there that can transport these mini donkeys from Banner Elk, NC to Pets Alive? http:\/\/yfrog.com\/h0268p",
    "id" : 75224646127063040,
    "created_at" : "2011-05-30 15:38:47 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 75231663092793344,
  "created_at" : "2011-05-30 16:06:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyrical Press",
      "screen_name" : "lyricalpress",
      "indices" : [ 3, 16 ],
      "id_str" : "176693088",
      "id" : 176693088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75215866354073601",
  "text" : "RT @lyricalpress: Retweet this for a chance to win a $20 gift certificate to Lyrical's store if we can reach 200 followers by the end of ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75214160639696897",
    "text" : "Retweet this for a chance to win a $20 gift certificate to Lyrical's store if we can reach 200 followers by the end of the day!",
    "id" : 75214160639696897,
    "created_at" : "2011-05-30 14:57:07 +0000",
    "user" : {
      "name" : "Lyrical Press",
      "screen_name" : "lyricalpress",
      "protected" : false,
      "id_str" : "176693088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750726981155753984\/oMgg_By__normal.jpg",
      "id" : 176693088,
      "verified" : false
    }
  },
  "id" : 75215866354073601,
  "created_at" : "2011-05-30 15:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75212698878607360",
  "text" : "love reading book, st therese of lisieux, the little flower. all about the little things. I am perfect just as I am.",
  "id" : 75212698878607360,
  "created_at" : "2011-05-30 14:51:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75212052997734400",
  "text" : "RT @ceebee308: There is a method behind my madness. I just haven\u2019t figured it out yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75211733781848064",
    "text" : "There is a method behind my madness. I just haven\u2019t figured it out yet.",
    "id" : 75211733781848064,
    "created_at" : "2011-05-30 14:47:29 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 75212052997734400,
  "created_at" : "2011-05-30 14:48:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75211930280787968",
  "text" : "I cant do much but I can do little things.",
  "id" : 75211930280787968,
  "created_at" : "2011-05-30 14:48:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75211683324379138",
  "text" : "RT @sparklekaz: The oak sleeps in the acorn, the bird waits in the egg, & in the highest vision of the soul, a waking angel stirs. James ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75211072059080704",
    "text" : "The oak sleeps in the acorn, the bird waits in the egg, & in the highest vision of the soul, a waking angel stirs. James Allen",
    "id" : 75211072059080704,
    "created_at" : "2011-05-30 14:44:51 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 75211683324379138,
  "created_at" : "2011-05-30 14:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah-Jayne Gratton",
      "screen_name" : "grattongirl",
      "indices" : [ 3, 15 ],
      "id_str" : "16615594",
      "id" : 16615594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75209370857766912",
  "text" : "RT @grattongirl: Never underestimate the power of a kind tweet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75197776966856705",
    "text" : "Never underestimate the power of a kind tweet.",
    "id" : 75197776966856705,
    "created_at" : "2011-05-30 13:52:01 +0000",
    "user" : {
      "name" : "Sarah-Jayne Gratton",
      "screen_name" : "grattongirl",
      "protected" : false,
      "id_str" : "16615594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767649005975302144\/l0aWheGn_normal.jpg",
      "id" : 16615594,
      "verified" : true
    }
  },
  "id" : 75209370857766912,
  "created_at" : "2011-05-30 14:38:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75206512267636736",
  "text" : "@Skandhasattva really?? guess Im not the only one..hehe.. well, except I have none, well.. hubby..but he doesnt count cuz we're married..lol",
  "id" : 75206512267636736,
  "created_at" : "2011-05-30 14:26:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Facebook",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "fb",
      "indices" : [ 109, 112 ]
    }, {
      "text" : "socialmedia",
      "indices" : [ 113, 125 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75205112137658368",
  "text" : "RT @Reverend_Sue: Here it is! The OFFICIAL Reverend Sue #Facebook is up and running!  http:\/\/on.fb.me\/jK7b3u #fb #socialmedia #LGBT #equ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Facebook",
        "indices" : [ 38, 47 ]
      }, {
        "text" : "fb",
        "indices" : [ 91, 94 ]
      }, {
        "text" : "socialmedia",
        "indices" : [ 95, 107 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 108, 113 ]
      }, {
        "text" : "equality",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "humanrights",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75194928887635968",
    "text" : "Here it is! The OFFICIAL Reverend Sue #Facebook is up and running!  http:\/\/on.fb.me\/jK7b3u #fb #socialmedia #LGBT #equality #humanrights",
    "id" : 75194928887635968,
    "created_at" : "2011-05-30 13:40:42 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 75205112137658368,
  "created_at" : "2011-05-30 14:21:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75016105940361216",
  "text" : "RT @TheGodLight: It takes more than one person to argue, if all you show is love, every argument will die a death.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75011254007250944",
    "text" : "It takes more than one person to argue, if all you show is love, every argument will die a death.",
    "id" : 75011254007250944,
    "created_at" : "2011-05-30 01:30:51 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 75016105940361216,
  "created_at" : "2011-05-30 01:50:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74894643220856832",
  "text" : "RT @SarahakaLegion: A family in ruins. A son missing 4 a yr. Time to remember all that matters, time for a FAMILY PICNIC http:\/\/goo.gl\/8vuNs",
  "id" : 74894643220856832,
  "created_at" : "2011-05-29 17:47:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74891174955065344",
  "text" : "lol http:\/\/amzn.com\/k\/CKLF3JS1L0Y3 #Kindle",
  "id" : 74891174955065344,
  "created_at" : "2011-05-29 17:33:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74881438985617408",
  "geo" : { },
  "id_str" : "74885087749091328",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver yes ma'am! : )",
  "id" : 74885087749091328,
  "in_reply_to_status_id" : 74881438985617408,
  "created_at" : "2011-05-29 17:09:30 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74885001107349504",
  "text" : "RT @mssuzcatsilver: Remember money is another form of energy, an exchange. Bless all that U have & when you buy anything  & for the choi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "suzcat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74881438985617408",
    "text" : "Remember money is another form of energy, an exchange. Bless all that U have & when you buy anything  & for the choices it gives u #suzcat",
    "id" : 74881438985617408,
    "created_at" : "2011-05-29 16:55:00 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 74885001107349504,
  "created_at" : "2011-05-29 17:09:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74857178003025921",
  "text" : "RT @JosephRanseth: Welcome to the first day of the rest of your life. Are you excited yet? :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74851489364975616",
    "text" : "Welcome to the first day of the rest of your life. Are you excited yet? :)",
    "id" : 74851489364975616,
    "created_at" : "2011-05-29 14:56:00 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 74857178003025921,
  "created_at" : "2011-05-29 15:18:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Miss Xclusive",
      "screen_name" : "MissHipHopNRnB",
      "indices" : [ 22, 37 ],
      "id_str" : "237573246",
      "id" : 237573246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74850500264198145",
  "text" : "RT @Dwayne_Reaves: RT @MissHipHopNRnB: Some people create their own storms, then get upset when it rains. via @2jazzy4jus1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Miss Xclusive",
        "screen_name" : "MissHipHopNRnB",
        "indices" : [ 3, 18 ],
        "id_str" : "237573246",
        "id" : 237573246
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74850068271857665",
    "text" : "RT @MissHipHopNRnB: Some people create their own storms, then get upset when it rains. via @2jazzy4jus1",
    "id" : 74850068271857665,
    "created_at" : "2011-05-29 14:50:21 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 74850500264198145,
  "created_at" : "2011-05-29 14:52:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74848087193034752",
  "text" : "good morning my sweets",
  "id" : 74848087193034752,
  "created_at" : "2011-05-29 14:42:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74654383673053186",
  "geo" : { },
  "id_str" : "74656357005000704",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves you need to have faith that in letting go will bring you joy. you cant see it & it looks cloudy but the sun is waiting 4U",
  "id" : 74656357005000704,
  "in_reply_to_status_id" : 74654383673053186,
  "created_at" : "2011-05-29 02:00:37 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74592057808785408",
  "text" : "@HEATHENRABBIT LOL.. poor kitties",
  "id" : 74592057808785408,
  "created_at" : "2011-05-28 21:45:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74570278751043584",
  "geo" : { },
  "id_str" : "74579194796978176",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist books & rock have been my lifeline",
  "id" : 74579194796978176,
  "in_reply_to_status_id" : 74570278751043584,
  "created_at" : "2011-05-28 20:54:00 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74574232780161024",
  "geo" : { },
  "id_str" : "74578246074765312",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist breathe, acknowledge, let it go. it will pass (temporary.) You'll make it!",
  "id" : 74578246074765312,
  "in_reply_to_status_id" : 74574232780161024,
  "created_at" : "2011-05-28 20:50:14 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 0, 12 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74558878632783872",
  "geo" : { },
  "id_str" : "74577415988457472",
  "in_reply_to_user_id" : 17218256,
  "text" : "@PuaTamandua Cincoa, Cinco Lil, Cinca...",
  "id" : 74577415988457472,
  "in_reply_to_status_id" : 74558878632783872,
  "created_at" : "2011-05-28 20:46:56 +0000",
  "in_reply_to_screen_name" : "PuaTamandua",
  "in_reply_to_user_id_str" : "17218256",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Scott Bell",
      "screen_name" : "jamesscottbell",
      "indices" : [ 3, 18 ],
      "id_str" : "22575417",
      "id" : 22575417
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badwritingadvice",
      "indices" : [ 107, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74549284179165184",
  "text" : "RT @jamesscottbell: If a scene you are writing is dull, just write \"heaving bosom\" somewhere and continue. #badwritingadvice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "badwritingadvice",
        "indices" : [ 87, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74529154946703360",
    "text" : "If a scene you are writing is dull, just write \"heaving bosom\" somewhere and continue. #badwritingadvice",
    "id" : 74529154946703360,
    "created_at" : "2011-05-28 17:35:09 +0000",
    "user" : {
      "name" : "James Scott Bell",
      "screen_name" : "jamesscottbell",
      "protected" : false,
      "id_str" : "22575417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1639060099\/JSB_at_Angels_Flight_normal.jpg",
      "id" : 22575417,
      "verified" : false
    }
  },
  "id" : 74549284179165184,
  "created_at" : "2011-05-28 18:55:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74530954588323841",
  "geo" : { },
  "id_str" : "74549044264960000",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen you are such a doll! ((hugs))",
  "id" : 74549044264960000,
  "in_reply_to_status_id" : 74530954588323841,
  "created_at" : "2011-05-28 18:54:11 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74547991226236929",
  "geo" : { },
  "id_str" : "74548832574259201",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist ((hugs))",
  "id" : 74548832574259201,
  "in_reply_to_status_id" : 74547991226236929,
  "created_at" : "2011-05-28 18:53:21 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Damned",
      "screen_name" : "DamnedAtheists",
      "indices" : [ 49, 64 ],
      "id_str" : "37147987",
      "id" : 37147987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheism",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74545825841299456",
  "text" : "dont want to convert anyone. live & let live. RT @DamnedAtheists: Do You Want to Convert an Atheist? http:\/\/bit.ly\/mAmJcC #atheism",
  "id" : 74545825841299456,
  "created_at" : "2011-05-28 18:41:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAIL",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74542787932069889",
  "text" : "RT @Matth3ous: Life at a brainwashing \"school for troubled teens\" http:\/\/pulsene.ws\/1LckP #FAIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FAIL",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74541726668296192",
    "text" : "Life at a brainwashing \"school for troubled teens\" http:\/\/pulsene.ws\/1LckP #FAIL",
    "id" : 74541726668296192,
    "created_at" : "2011-05-28 18:25:07 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 74542787932069889,
  "created_at" : "2011-05-28 18:29:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Betcher",
      "screen_name" : "JohnBetcher",
      "indices" : [ 3, 15 ],
      "id_str" : "53730065",
      "id" : 53730065
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "booksupport",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "IAN1",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "amwriting",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74538239888863233",
  "text" : "RT @JohnBetcher: If your tweets might help or interest authors, use my new hashtag - #booksupport. Thanks. :) #IAN1 #amwriting #amreadin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "booksupport",
        "indices" : [ 68, 80 ]
      }, {
        "text" : "IAN1",
        "indices" : [ 93, 98 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 99, 109 ]
      }, {
        "text" : "amreading",
        "indices" : [ 110, 120 ]
      }, {
        "text" : "books",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "authors",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74537659502039040",
    "text" : "If your tweets might help or interest authors, use my new hashtag - #booksupport. Thanks. :) #IAN1 #amwriting #amreading #books #authors",
    "id" : 74537659502039040,
    "created_at" : "2011-05-28 18:08:57 +0000",
    "user" : {
      "name" : "John Betcher",
      "screen_name" : "JohnBetcher",
      "protected" : false,
      "id_str" : "53730065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740262527\/John_Grand_Canyon_normal.jpg",
      "id" : 53730065,
      "verified" : false
    }
  },
  "id" : 74538239888863233,
  "created_at" : "2011-05-28 18:11:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Royle",
      "screen_name" : "sgroyle",
      "indices" : [ 0, 8 ],
      "id_str" : "181103297",
      "id" : 181103297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74534439891382272",
  "geo" : { },
  "id_str" : "74535768906932224",
  "in_reply_to_user_id" : 181103297,
  "text" : "@sgroyle YVW - it was a fabulous read!",
  "id" : 74535768906932224,
  "in_reply_to_status_id" : 74534439891382272,
  "created_at" : "2011-05-28 18:01:26 +0000",
  "in_reply_to_screen_name" : "sgroyle",
  "in_reply_to_user_id_str" : "181103297",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74526413381832704",
  "text" : "RT @petsalive: Those of U that R using the Pets Alive credit card -THANK YOU!!  We just got a chk for $356 from Capital One! http:\/\/tiny ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74525819506143232",
    "text" : "Those of U that R using the Pets Alive credit card -THANK YOU!!  We just got a chk for $356 from Capital One! http:\/\/tinyurl.com\/petsalivecc",
    "id" : 74525819506143232,
    "created_at" : "2011-05-28 17:21:54 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 74526413381832704,
  "created_at" : "2011-05-28 17:24:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suzcat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74526198243397632",
  "text" : "RT @mssuzcatsilver: Kundalini Reiki attunements http:\/\/www.suzcatsilverdesigns.co.uk\/80190\/info.php?p=12 more of what I do, #suzcat (plz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "suzcat",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74524838374555648",
    "text" : "Kundalini Reiki attunements http:\/\/www.suzcatsilverdesigns.co.uk\/80190\/info.php?p=12 more of what I do, #suzcat (plz DM if u r interested)",
    "id" : 74524838374555648,
    "created_at" : "2011-05-28 17:18:00 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 74526198243397632,
  "created_at" : "2011-05-28 17:23:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74508487094304769",
  "geo" : { },
  "id_str" : "74511301367439360",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott LOLOL",
  "id" : 74511301367439360,
  "in_reply_to_status_id" : 74508487094304769,
  "created_at" : "2011-05-28 16:24:13 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74511098971308032",
  "text" : "@ReformedBuddha LOLOL",
  "id" : 74511098971308032,
  "created_at" : "2011-05-28 16:23:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "angelbracelets",
      "indices" : [ 108, 123 ]
    }, {
      "text" : "love",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74510978510884864",
  "text" : "RT @mssuzcatsilver: Do u need an angel in yr life? http:\/\/www.suzcatsilverdesigns.co.uk\/80190\/info.php?p=7 \r#angelbracelets #love #bless ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "angelbracelets",
        "indices" : [ 88, 103 ]
      }, {
        "text" : "love",
        "indices" : [ 104, 109 ]
      }, {
        "text" : "blessings",
        "indices" : [ 110, 120 ]
      }, {
        "text" : "suzcat",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74509490774482944",
    "text" : "Do u need an angel in yr life? http:\/\/www.suzcatsilverdesigns.co.uk\/80190\/info.php?p=7 \r#angelbracelets #love #blessings  #suzcat",
    "id" : 74509490774482944,
    "created_at" : "2011-05-28 16:17:01 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 74510978510884864,
  "created_at" : "2011-05-28 16:22:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74507048271876097",
  "geo" : { },
  "id_str" : "74508191030980608",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen he's got issues. havent seen him in over a year now. hes making effort to reach out. gd4me2 practice compassion",
  "id" : 74508191030980608,
  "in_reply_to_status_id" : 74507048271876097,
  "created_at" : "2011-05-28 16:11:51 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74507200780959744",
  "text" : "@ReformedBuddha love it! hehe",
  "id" : 74507200780959744,
  "created_at" : "2011-05-28 16:07:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74505625148719104",
  "geo" : { },
  "id_str" : "74506465972457472",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen I can see my parents laughing as well..lol",
  "id" : 74506465972457472,
  "in_reply_to_status_id" : 74505625148719104,
  "created_at" : "2011-05-28 16:05:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74505144301137920",
  "text" : "I have to hide my parents on monday. brother visiting & he doesnt want his 6yr old son to \"dwell\" on them.. i find this rather hysterical.",
  "id" : 74505144301137920,
  "created_at" : "2011-05-28 15:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74497964533497856",
  "text" : "bad coffee aint worth it...",
  "id" : 74497964533497856,
  "created_at" : "2011-05-28 15:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74284275037511680",
  "geo" : { },
  "id_str" : "74289935573725186",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy maybe he did.. and the rest of us are too dumb to see it? ; )",
  "id" : 74289935573725186,
  "in_reply_to_status_id" : 74284275037511680,
  "created_at" : "2011-05-28 01:44:35 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Royle",
      "screen_name" : "sgroyle",
      "indices" : [ 3, 11 ],
      "id_str" : "181103297",
      "id" : 181103297
    }, {
      "name" : "Elizabeth Brown",
      "screen_name" : "FrugaleReader",
      "indices" : [ 13, 27 ],
      "id_str" : "199456136",
      "id" : 199456136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74279527743897600",
  "text" : "RT @sgroyle: @FrugaleReader I dropped, Tag to 99 cents. Now #23 in Technothrillers on Amazon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elizabeth Brown",
        "screen_name" : "FrugaleReader",
        "indices" : [ 0, 14 ],
        "id_str" : "199456136",
        "id" : 199456136
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "74258956033339392",
    "geo" : { },
    "id_str" : "74277156573814784",
    "in_reply_to_user_id" : 199456136,
    "text" : "@FrugaleReader I dropped, Tag to 99 cents. Now #23 in Technothrillers on Amazon",
    "id" : 74277156573814784,
    "in_reply_to_status_id" : 74258956033339392,
    "created_at" : "2011-05-28 00:53:48 +0000",
    "in_reply_to_screen_name" : "FrugaleReader",
    "in_reply_to_user_id_str" : "199456136",
    "user" : {
      "name" : "Simon Royle",
      "screen_name" : "sgroyle",
      "protected" : false,
      "id_str" : "181103297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3255243117\/c5cf7b84a7660bf228da49c57f32c9f2_normal.jpeg",
      "id" : 181103297,
      "verified" : false
    }
  },
  "id" : 74279527743897600,
  "created_at" : "2011-05-28 01:03:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74262357001515008",
  "geo" : { },
  "id_str" : "74262680965349376",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 need a ((hug)) ?",
  "id" : 74262680965349376,
  "in_reply_to_status_id" : 74262357001515008,
  "created_at" : "2011-05-27 23:56:17 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K-Med",
      "screen_name" : "Kevin__Medeiros",
      "indices" : [ 0, 16 ],
      "id_str" : "13374242",
      "id" : 13374242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74255079556907008",
  "geo" : { },
  "id_str" : "74262253125378048",
  "in_reply_to_user_id" : 13374242,
  "text" : "@Kevin__Medeiros nope",
  "id" : 74262253125378048,
  "in_reply_to_status_id" : 74255079556907008,
  "created_at" : "2011-05-27 23:54:35 +0000",
  "in_reply_to_screen_name" : "Kevin__Medeiros",
  "in_reply_to_user_id_str" : "13374242",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heehee",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74253202329047040",
  "text" : "RT @derekrootboy: the good thing about women is... .... no, don't give me any clues. i'll get there eventually. #heehee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "heehee",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74252617735356416",
    "text" : "the good thing about women is... .... no, don't give me any clues. i'll get there eventually. #heehee",
    "id" : 74252617735356416,
    "created_at" : "2011-05-27 23:16:18 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 74253202329047040,
  "created_at" : "2011-05-27 23:18:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74253087321239553",
  "text" : "RT @PinarAkal1: \u263CHappy tweets attract happy people into your life.\u263C I'm glad you are here!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74252773050417152",
    "text" : "\u263CHappy tweets attract happy people into your life.\u263C I'm glad you are here!",
    "id" : 74252773050417152,
    "created_at" : "2011-05-27 23:16:55 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 74253087321239553,
  "created_at" : "2011-05-27 23:18:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74249695815413761",
  "geo" : { },
  "id_str" : "74251489949921280",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver my impression: hold tight to course. im ok.",
  "id" : 74251489949921280,
  "in_reply_to_status_id" : 74249695815413761,
  "created_at" : "2011-05-27 23:11:49 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Reine",
      "screen_name" : "ReineM",
      "indices" : [ 23, 30 ],
      "id_str" : "21428927",
      "id" : 21428927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74250672597499904",
  "text" : "RT @mssuzcatsilver: RT @ReineM: There is nothing, No-thing in your existence more important then love. It may take lifetimes to see this ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reine",
        "screen_name" : "ReineM",
        "indices" : [ 3, 10 ],
        "id_str" : "21428927",
        "id" : 21428927
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74250250994466816",
    "text" : "RT @ReineM: There is nothing, No-thing in your existence more important then love. It may take lifetimes to see this. An absolute truth.",
    "id" : 74250250994466816,
    "created_at" : "2011-05-27 23:06:54 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 74250672597499904,
  "created_at" : "2011-05-27 23:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74247646608494592",
  "geo" : { },
  "id_str" : "74249236010643457",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver not really? I dont know what to focus on... I seem to fly in the wind..lol",
  "id" : 74249236010643457,
  "in_reply_to_status_id" : 74247646608494592,
  "created_at" : "2011-05-27 23:02:52 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 15, 30 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 32, 43 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74247354928209920",
  "text" : "TY ((hugs)) RT @mssuzcatsilver: @moosebegab   Kuthumi - Stay Focused",
  "id" : 74247354928209920,
  "created_at" : "2011-05-27 22:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 23, 36 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74245666007826433",
  "text" : "RT @mssuzcatsilver: RT @DeepakChopra: Life is NOW. NOW is Eternal Presence. GOD IS NOW not in a book of religion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 3, 16 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74244939042668544",
    "text" : "RT @DeepakChopra: Life is NOW. NOW is Eternal Presence. GOD IS NOW not in a book of religion.",
    "id" : 74244939042668544,
    "created_at" : "2011-05-27 22:45:47 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 74245666007826433,
  "created_at" : "2011-05-27 22:48:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74242519910711296",
  "geo" : { },
  "id_str" : "74243412014022656",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver me, plz?",
  "id" : 74243412014022656,
  "in_reply_to_status_id" : 74242519910711296,
  "created_at" : "2011-05-27 22:39:43 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74240311509008384",
  "text" : "had my life been different, I could be sitting in jail today",
  "id" : 74240311509008384,
  "created_at" : "2011-05-27 22:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PureConsciousness",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74239355006369793",
  "text" : "RT @DeepakChopra: #PureConsciousness dos not occupy space or exist in time. It is the real you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PureConsciousness",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74238059578798080",
    "text" : "#PureConsciousness dos not occupy space or exist in time. It is the real you.",
    "id" : 74238059578798080,
    "created_at" : "2011-05-27 22:18:27 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 74239355006369793,
  "created_at" : "2011-05-27 22:23:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74239328536109056",
  "text" : "RT @TyrusBooks: There will never be enough. There will never be a finish line.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74238005778460672",
    "text" : "There will never be enough. There will never be a finish line.",
    "id" : 74238005778460672,
    "created_at" : "2011-05-27 22:18:14 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 74239328536109056,
  "created_at" : "2011-05-27 22:23:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74170060259864577",
  "text" : "RT @GeneDoucette: how would one promote a book written under a pseudonym?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74167769100333057",
    "text" : "how would one promote a book written under a pseudonym?",
    "id" : 74167769100333057,
    "created_at" : "2011-05-27 17:39:08 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 74170060259864577,
  "created_at" : "2011-05-27 17:48:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 3, 11 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unschooling",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74158047563497474",
  "text" : "RT @arphaus: Today's a bad-ass day for #unschooling\/independent learning: Skillshare.com, Uncollege.org & Opting out of school http:\/\/j. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "unschooling",
        "indices" : [ 26, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74157652468445184",
    "text" : "Today's a bad-ass day for #unschooling\/independent learning: Skillshare.com, Uncollege.org & Opting out of school http:\/\/j.mp\/mAKYfv FTW!",
    "id" : 74157652468445184,
    "created_at" : "2011-05-27 16:58:56 +0000",
    "user" : {
      "name" : "Arp Laszlo",
      "screen_name" : "thisisarp",
      "protected" : false,
      "id_str" : "7339162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773529857464688640\/ZPr3v43v_normal.jpg",
      "id" : 7339162,
      "verified" : false
    }
  },
  "id" : 74158047563497474,
  "created_at" : "2011-05-27 17:00:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Marston",
      "screen_name" : "ralphmarston",
      "indices" : [ 3, 16 ],
      "id_str" : "21630687",
      "id" : 21630687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74133616623497216",
  "text" : "RT @ralphmarston: Stop looking down at the bumps in the road. Look up and see the vision of where you're working to go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74130319367876608",
    "text" : "Stop looking down at the bumps in the road. Look up and see the vision of where you're working to go.",
    "id" : 74130319367876608,
    "created_at" : "2011-05-27 15:10:20 +0000",
    "user" : {
      "name" : "Ralph Marston",
      "screen_name" : "ralphmarston",
      "protected" : false,
      "id_str" : "21630687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/388467602\/ralph3_normal.jpg",
      "id" : 21630687,
      "verified" : false
    }
  },
  "id" : 74133616623497216,
  "created_at" : "2011-05-27 15:23:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74130892821504001",
  "text" : "@Skandhasattva I hate when ppl shrug at me..lol. my point is maybe the older ppl need there need to see someone younger...",
  "id" : 74130892821504001,
  "created_at" : "2011-05-27 15:12:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    }, {
      "name" : "Ali Spirit",
      "screen_name" : "SpiritAli",
      "indices" : [ 19, 29 ],
      "id_str" : "2936900371",
      "id" : 2936900371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74128659472072704",
  "text" : "RT @dhammagirl: RT @SpiritAli I didn't change. You just never knew me. - Anon\n\nI like that!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ali Spirit",
        "screen_name" : "SpiritAli",
        "indices" : [ 3, 13 ],
        "id_str" : "2936900371",
        "id" : 2936900371
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74128026950057984",
    "text" : "RT @SpiritAli I didn't change. You just never knew me. - Anon\n\nI like that!",
    "id" : 74128026950057984,
    "created_at" : "2011-05-27 15:01:13 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 74128659472072704,
  "created_at" : "2011-05-27 15:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74116510674722816",
  "text" : "@Skandhasattva no. you are there to shine your light.",
  "id" : 74116510674722816,
  "created_at" : "2011-05-27 14:15:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74113490645819392",
  "geo" : { },
  "id_str" : "74116212052865024",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis : ) .. perception.. comes down to perception.. hmm..",
  "id" : 74116212052865024,
  "in_reply_to_status_id" : 74113490645819392,
  "created_at" : "2011-05-27 14:14:16 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74113225746165760",
  "text" : "@tragic_pizza we each responsible for ourselves. dont take on responsibility of those you disagree with & those affected by them. be you.",
  "id" : 74113225746165760,
  "created_at" : "2011-05-27 14:02:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74112577411616768",
  "text" : "you see blue, i see purple. who's right? does it matter? can you convince me my purple is NOT purple when I see purple.",
  "id" : 74112577411616768,
  "created_at" : "2011-05-27 13:59:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74107832345182208",
  "geo" : { },
  "id_str" : "74112205825654785",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles lol",
  "id" : 74112205825654785,
  "in_reply_to_status_id" : 74107832345182208,
  "created_at" : "2011-05-27 13:58:21 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74107628619436032",
  "text" : "wait,wait..having AHA moment. has to do with colors...",
  "id" : 74107628619436032,
  "created_at" : "2011-05-27 13:40:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Sevilla, MD",
      "screen_name" : "drmikesevilla",
      "indices" : [ 3, 17 ],
      "id_str" : "6429252",
      "id" : 6429252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74106766312480768",
  "text" : "RT @drmikesevilla: Random act of kindness. Try it now. Yes, THAT person doesn't deserve it, but needs it. And so do you... #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 104, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74099605884776448",
    "text" : "Random act of kindness. Try it now. Yes, THAT person doesn't deserve it, but needs it. And so do you... #fb",
    "id" : 74099605884776448,
    "created_at" : "2011-05-27 13:08:17 +0000",
    "user" : {
      "name" : "Mike Sevilla, MD",
      "screen_name" : "drmikesevilla",
      "protected" : false,
      "id_str" : "6429252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701037990609608704\/Oan-nJs5_normal.jpg",
      "id" : 6429252,
      "verified" : false
    }
  },
  "id" : 74106766312480768,
  "created_at" : "2011-05-27 13:36:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fantasy",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "booklook",
      "indices" : [ 108, 117 ]
    }, {
      "text" : "goodreads",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74096709311016960",
  "text" : "RT @ShayFabbro: Interview with author Doug Brown. Chance to win a free e-book! http:\/\/su.pr\/5siyic #fantasy #booklook #goodreads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.stumbleupon.com\/\" rel=\"nofollow\"\u003EStumbleUpon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fantasy",
        "indices" : [ 83, 91 ]
      }, {
        "text" : "booklook",
        "indices" : [ 92, 101 ]
      }, {
        "text" : "goodreads",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73860594196955136",
    "text" : "Interview with author Doug Brown. Chance to win a free e-book! http:\/\/su.pr\/5siyic #fantasy #booklook #goodreads",
    "id" : 73860594196955136,
    "created_at" : "2011-05-26 21:18:32 +0000",
    "user" : {
      "name" : "Shay West",
      "screen_name" : "DrShayWest",
      "protected" : false,
      "id_str" : "191647086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743945511644762112\/qszFSfSL_normal.jpg",
      "id" : 191647086,
      "verified" : false
    }
  },
  "id" : 74096709311016960,
  "created_at" : "2011-05-27 12:56:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74095703126851584",
  "text" : "good luck w appt today @Skandhasattva ((hugs))",
  "id" : 74095703126851584,
  "created_at" : "2011-05-27 12:52:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    }, {
      "name" : "Picture Cool",
      "screen_name" : "picturecool",
      "indices" : [ 26, 38 ],
      "id_str" : "46152541",
      "id" : 46152541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73933702811496448",
  "text" : "RT @ThisBlueWorld: Lol RT @picturecool: Ok buddy, that's close enough.. #photo http:\/\/bit.ly\/kKdXRm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Picture Cool",
        "screen_name" : "picturecool",
        "indices" : [ 7, 19 ],
        "id_str" : "46152541",
        "id" : 46152541
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 53, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73931983784386560",
    "text" : "Lol RT @picturecool: Ok buddy, that's close enough.. #photo http:\/\/bit.ly\/kKdXRm",
    "id" : 73931983784386560,
    "created_at" : "2011-05-27 02:02:13 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 73933702811496448,
  "created_at" : "2011-05-27 02:09:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Judy",
      "screen_name" : "LUKIKA",
      "indices" : [ 22, 29 ],
      "id_str" : "40703036",
      "id" : 40703036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73932930854027264",
  "text" : "RT @Dwayne_Reaves: RT @LUKIKA: What you see depends on what you're looking for ~ Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Judy",
        "screen_name" : "LUKIKA",
        "indices" : [ 3, 10 ],
        "id_str" : "40703036",
        "id" : 40703036
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73931161696616449",
    "text" : "RT @LUKIKA: What you see depends on what you're looking for ~ Unknown",
    "id" : 73931161696616449,
    "created_at" : "2011-05-27 01:58:57 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 73932930854027264,
  "created_at" : "2011-05-27 02:05:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan",
      "screen_name" : "FUZZY_TIGERZ",
      "indices" : [ 15, 28 ],
      "id_str" : "2907290939",
      "id" : 2907290939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73930260957233153",
  "text" : "@Skandhasattva @Fuzzy_Tigerz awww, you two look good together! : )",
  "id" : 73930260957233153,
  "created_at" : "2011-05-27 01:55:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73876605373657089",
  "text" : "RT @_NealeDWalsch: Seek not to be the recipient of anything but to be the source. That which you wish to have, cause another to have.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nealedonaldwalsch.com\" rel=\"nofollow\"\u003ENeale Donald Walsch\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73872189534904320",
    "text" : "Seek not to be the recipient of anything but to be the source. That which you wish to have, cause another to have.",
    "id" : 73872189534904320,
    "created_at" : "2011-05-26 22:04:37 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 73876605373657089,
  "created_at" : "2011-05-26 22:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Kunzang Drolma",
      "screen_name" : "helpsavelives",
      "indices" : [ 16, 30 ],
      "id_str" : "80181824",
      "id" : 80181824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73876481754939393",
  "text" : "RT @SangyeH: RT @helpsavelives: Ol dog found faithfully by dead owner. Pls help vet bill http:\/\/tarasbabiesdogs.chipin.com\/jeremiahs-vet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kunzang Drolma",
        "screen_name" : "helpsavelives",
        "indices" : [ 3, 17 ],
        "id_str" : "80181824",
        "id" : 80181824
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73875143054725120",
    "text" : "RT @helpsavelives: Ol dog found faithfully by dead owner. Pls help vet bill http:\/\/tarasbabiesdogs.chipin.com\/jeremiahs-vet-bill",
    "id" : 73875143054725120,
    "created_at" : "2011-05-26 22:16:21 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 73876481754939393,
  "created_at" : "2011-05-26 22:21:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73874104150798336",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: Your thought about God does not create God. It merely creates your experience of God. God is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73870565349392384",
    "text" : "RT @_NealeDWalsch: Your thought about God does not create God. It merely creates your experience of God. God is.",
    "id" : 73870565349392384,
    "created_at" : "2011-05-26 21:58:09 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 73874104150798336,
  "created_at" : "2011-05-26 22:12:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ania Ahlborn",
      "screen_name" : "aniaahlborn",
      "indices" : [ 3, 15 ],
      "id_str" : "272739347",
      "id" : 272739347
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horror",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "kindle",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73844281378476033",
  "text" : "RT @aniaahlborn: Fans of horror, check out SEED, coming June 1st! http:\/\/bit.ly\/lB7td9 Don't miss it! #horror #kindle #ebooks #paranorma ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "horror",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "kindle",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 101, 108 ]
      }, {
        "text" : "paranormal",
        "indices" : [ 109, 120 ]
      }, {
        "text" : "followme",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73843276481966080",
    "text" : "Fans of horror, check out SEED, coming June 1st! http:\/\/bit.ly\/lB7td9 Don't miss it! #horror #kindle #ebooks #paranormal #followme RT2WIN",
    "id" : 73843276481966080,
    "created_at" : "2011-05-26 20:09:43 +0000",
    "user" : {
      "name" : "Ania Ahlborn",
      "screen_name" : "aniaahlborn",
      "protected" : false,
      "id_str" : "272739347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729424733054357504\/gt6TTPx8_normal.jpg",
      "id" : 272739347,
      "verified" : false
    }
  },
  "id" : 73844281378476033,
  "created_at" : "2011-05-26 20:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mackenzie Phillips",
      "screen_name" : "MackPhillips",
      "indices" : [ 3, 16 ],
      "id_str" : "112824083",
      "id" : 112824083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73835303424634880",
  "text" : "RT @MackPhillips: Oh lord. Jeff Conaway to be taken off of life support today. Brutal. God bless you old friend.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73835154346483713",
    "text" : "Oh lord. Jeff Conaway to be taken off of life support today. Brutal. God bless you old friend.",
    "id" : 73835154346483713,
    "created_at" : "2011-05-26 19:37:27 +0000",
    "user" : {
      "name" : "Mackenzie Phillips",
      "screen_name" : "MackPhillips",
      "protected" : false,
      "id_str" : "112824083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2662430044\/dbadcb70117893b43317fd0afcd6be1c_normal.jpeg",
      "id" : 112824083,
      "verified" : true
    }
  },
  "id" : 73835303424634880,
  "created_at" : "2011-05-26 19:38:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "LetItGo",
      "screen_name" : "LetItGo8",
      "indices" : [ 16, 25 ],
      "id_str" : "588438101",
      "id" : 588438101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73820859881631744",
  "text" : "RT @SangyeH: RT @letitgo8: in the end only kindness matters.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LetItGo",
        "screen_name" : "LetItGo8",
        "indices" : [ 3, 12 ],
        "id_str" : "588438101",
        "id" : 588438101
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73820383043780609",
    "text" : "RT @letitgo8: in the end only kindness matters.",
    "id" : 73820383043780609,
    "created_at" : "2011-05-26 18:38:45 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 73820859881631744,
  "created_at" : "2011-05-26 18:40:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73820741983928321",
  "text" : "..and Hell.. what's up w that? that never made sense to me",
  "id" : 73820741983928321,
  "created_at" : "2011-05-26 18:40:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73820183306829824",
  "text" : "RT @UnseeingEyes: The Seat Belt Laws are entirely \"unconstitutional\" & BULLSHIT laws. Should you wear a seat belt? Yes, of course so...t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73819926086942720",
    "text" : "The Seat Belt Laws are entirely \"unconstitutional\" & BULLSHIT laws. Should you wear a seat belt? Yes, of course so...that's not my point.",
    "id" : 73819926086942720,
    "created_at" : "2011-05-26 18:36:56 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 73820183306829824,
  "created_at" : "2011-05-26 18:37:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73820086116421632",
  "text" : "I never got the whole \"saved\" thing.. saved from what? and if God is great, he doesn't make junk.",
  "id" : 73820086116421632,
  "created_at" : "2011-05-26 18:37:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73796594973151232",
  "text" : "RT @ebookfriendly: Are you a Kindle author? Submit a book to Sunday Kindle eBook Give Away! http:\/\/ow.ly\/50TSx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73790585424715776",
    "text" : "Are you a Kindle author? Submit a book to Sunday Kindle eBook Give Away! http:\/\/ow.ly\/50TSx",
    "id" : 73790585424715776,
    "created_at" : "2011-05-26 16:40:21 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 73796594973151232,
  "created_at" : "2011-05-26 17:04:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73780740566949888",
  "text" : "RT @JohnCali: You can change a great many things.  Or you can change. ~ The Universe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73775477587841024",
    "text" : "You can change a great many things.  Or you can change. ~ The Universe",
    "id" : 73775477587841024,
    "created_at" : "2011-05-26 15:40:19 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 73780740566949888,
  "created_at" : "2011-05-26 16:01:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73780489936306177",
  "text" : "RT @Mahala: I just did the retirement income calculator for my 401K and determined that I can't afford to retire until I've been dead fi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 134, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73776621148045312",
    "text" : "I just did the retirement income calculator for my 401K and determined that I can't afford to retire until I've been dead five years. #fb",
    "id" : 73776621148045312,
    "created_at" : "2011-05-26 15:44:51 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 73780489936306177,
  "created_at" : "2011-05-26 16:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karla Dalley",
      "screen_name" : "WaterGardenGodd",
      "indices" : [ 3, 19 ],
      "id_str" : "97964969",
      "id" : 97964969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73770643170148353",
  "text" : "RT @WaterGardenGodd: Gardeners may know cocoa mulch is toxic to dogs but not everyone will.  Let's get the word out to dog owners: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73769240863313920",
    "text" : "Gardeners may know cocoa mulch is toxic to dogs but not everyone will.  Let's get the word out to dog owners: http:\/\/wp.me\/pOm4T-Nx",
    "id" : 73769240863313920,
    "created_at" : "2011-05-26 15:15:32 +0000",
    "user" : {
      "name" : "Karla Dalley",
      "screen_name" : "WaterGardenGodd",
      "protected" : false,
      "id_str" : "97964969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431486733515894784\/SSWGZbNA_normal.jpeg",
      "id" : 97964969,
      "verified" : false
    }
  },
  "id" : 73770643170148353,
  "created_at" : "2011-05-26 15:21:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73768643741224960",
  "text" : "so I cant use the \"email for updates\" function...",
  "id" : 73768643741224960,
  "created_at" : "2011-05-26 15:13:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73768489801875456",
  "text" : "does anyone know how I can show the last links added to my site? I use links more than posts...",
  "id" : 73768489801875456,
  "created_at" : "2011-05-26 15:12:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfpub",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "amwriting",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/h2L300N",
      "expanded_url" : "http:\/\/www.jennascribbles.com\/self-publishing\/off-leash-description-help\/",
      "display_url" : "jennascribbles.com\/self-publishin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "73561531870216193",
  "text" : "RT @JAScribbles: I'm looking for feedback on my WIP's description\/blurb. Care to help?   http:\/\/t.co\/h2L300N #selfpub #amwriting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfpub",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 91 ],
        "url" : "http:\/\/t.co\/h2L300N",
        "expanded_url" : "http:\/\/www.jennascribbles.com\/self-publishing\/off-leash-description-help\/",
        "display_url" : "jennascribbles.com\/self-publishin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "73561135009382400",
    "text" : "I'm looking for feedback on my WIP's description\/blurb. Care to help?   http:\/\/t.co\/h2L300N #selfpub #amwriting",
    "id" : 73561135009382400,
    "created_at" : "2011-05-26 01:28:35 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 73561531870216193,
  "created_at" : "2011-05-26 01:30:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73543458735923200",
  "text" : "RT @_NealeDWalsch: You are here to \"be\" something, not \"do\" something. The soul cares only about what you're being.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nealedonaldwalsch.com\" rel=\"nofollow\"\u003ENeale Donald Walsch\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73539555629858816",
    "text" : "You are here to \"be\" something, not \"do\" something. The soul cares only about what you're being.",
    "id" : 73539555629858816,
    "created_at" : "2011-05-26 00:02:51 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 73543458735923200,
  "created_at" : "2011-05-26 00:18:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73539554283487232",
  "geo" : { },
  "id_str" : "73541543188893696",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist picked up a bug, maybe? hope you ok",
  "id" : 73541543188893696,
  "in_reply_to_status_id" : 73539554283487232,
  "created_at" : "2011-05-26 00:10:44 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73538155235643392",
  "geo" : { },
  "id_str" : "73540092098134016",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 so happy she's off to a good start on her recovery",
  "id" : 73540092098134016,
  "in_reply_to_status_id" : 73538155235643392,
  "created_at" : "2011-05-26 00:04:58 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Morgan",
      "screen_name" : "TalkDoc2",
      "indices" : [ 3, 12 ],
      "id_str" : "18085424",
      "id" : 18085424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73529503875469313",
  "text" : "RT @TalkDoc2: Growth of the soul often comes from pushing against perceived limitations.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73526097098186752",
    "text" : "Growth of the soul often comes from pushing against perceived limitations.",
    "id" : 73526097098186752,
    "created_at" : "2011-05-25 23:09:22 +0000",
    "user" : {
      "name" : "Mike Morgan",
      "screen_name" : "TalkDoc2",
      "protected" : false,
      "id_str" : "18085424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000634769250\/6903887c974d13a598e42246fa4e3f2c_normal.jpeg",
      "id" : 18085424,
      "verified" : false
    }
  },
  "id" : 73529503875469313,
  "created_at" : "2011-05-25 23:22:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73528617103138816",
  "text" : "RT @fearfuldogs: u can't show a fearful dog that they don't need 2 b afraid of something. doesn't work w ppl either.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73524686083985408",
    "text" : "u can't show a fearful dog that they don't need 2 b afraid of something. doesn't work w ppl either.",
    "id" : 73524686083985408,
    "created_at" : "2011-05-25 23:03:45 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 73528617103138816,
  "created_at" : "2011-05-25 23:19:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73519911883915264",
  "text" : "I read you loud & clear! RT @helloinhere: is this thing on or what?",
  "id" : 73519911883915264,
  "created_at" : "2011-05-25 22:44:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73517931031560192",
  "text" : "each of us has a piece of the puzzle. we need to come together w all our pieces to complete the picture.",
  "id" : 73517931031560192,
  "created_at" : "2011-05-25 22:36:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan",
      "screen_name" : "FUZZY_TIGERZ",
      "indices" : [ 30, 43 ],
      "id_str" : "2907290939",
      "id" : 2907290939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73496848605782016",
  "text" : "@Skandhasattva Ouch!! Im sure @fuzzy_tigerz will kiss it later and make it all better : )",
  "id" : 73496848605782016,
  "created_at" : "2011-05-25 21:13:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73461430430605312",
  "text" : "RT @JeffreyGuterman: Could Conjoined Twins Share a Mind? http:\/\/nyti.ms\/jCnmMA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73455732997099520",
    "text" : "Could Conjoined Twins Share a Mind? http:\/\/nyti.ms\/jCnmMA",
    "id" : 73455732997099520,
    "created_at" : "2011-05-25 18:29:46 +0000",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 73461430430605312,
  "created_at" : "2011-05-25 18:52:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73442928772648960",
  "geo" : { },
  "id_str" : "73445363566120960",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem I know the truth.. you're just trying to lose me! haha not that easy, missy! ; )",
  "id" : 73445363566120960,
  "in_reply_to_status_id" : 73442928772648960,
  "created_at" : "2011-05-25 17:48:33 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kylie Riordan \u262E \u2764",
      "screen_name" : "mindfulheal",
      "indices" : [ 3, 15 ],
      "id_str" : "278975121",
      "id" : 278975121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73438238496399360",
  "text" : "RT @mindfulheal: Pay no attention to feelings of fear.    Give full attention to feelings of love & happiness these ADD to the energy of ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72909003562299392",
    "text" : "Pay no attention to feelings of fear.    Give full attention to feelings of love & happiness these ADD to the energy of unconditional love.",
    "id" : 72909003562299392,
    "created_at" : "2011-05-24 06:17:15 +0000",
    "user" : {
      "name" : "Kylie Riordan \u262E \u2764",
      "screen_name" : "mindfulheal",
      "protected" : false,
      "id_str" : "278975121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768228246097793026\/eXnIQar3_normal.jpg",
      "id" : 278975121,
      "verified" : false
    }
  },
  "id" : 73438238496399360,
  "created_at" : "2011-05-25 17:20:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73389683522011137",
  "text" : "RT @TheGodLight: In the grand scale of things your petty arguments mean nothing, life is sacred & in the end that is all that matters.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73388009411723264",
    "text" : "In the grand scale of things your petty arguments mean nothing, life is sacred & in the end that is all that matters.",
    "id" : 73388009411723264,
    "created_at" : "2011-05-25 14:00:39 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 73389683522011137,
  "created_at" : "2011-05-25 14:07:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73377214867058690",
  "geo" : { },
  "id_str" : "73378424017780736",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous Happy Birthday! ((confettifalling))",
  "id" : 73378424017780736,
  "in_reply_to_status_id" : 73377214867058690,
  "created_at" : "2011-05-25 13:22:34 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73377306621644800",
  "geo" : { },
  "id_str" : "73378254739877889",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous wait.. didnt I see it was his bday yesterday?",
  "id" : 73378254739877889,
  "in_reply_to_status_id" : 73377306621644800,
  "created_at" : "2011-05-25 13:21:53 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73377306621644800",
  "geo" : { },
  "id_str" : "73378064817590273",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous and I share mine w Albert Einstein : )",
  "id" : 73378064817590273,
  "in_reply_to_status_id" : 73377306621644800,
  "created_at" : "2011-05-25 13:21:08 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73377233741418498",
  "text" : "RT @scottsigler: This just in: YOUR guy wants to push a radical agenda on America. MY guy is actually the voice of the people. So sayeth ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73372909321728001",
    "text" : "This just in: YOUR guy wants to push a radical agenda on America. MY guy is actually the voice of the people. So sayeth Twitter.",
    "id" : 73372909321728001,
    "created_at" : "2011-05-25 13:00:39 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 73377233741418498,
  "created_at" : "2011-05-25 13:17:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 0, 12 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73366552166154240",
  "geo" : { },
  "id_str" : "73368956844507137",
  "in_reply_to_user_id" : 16691399,
  "text" : "@fearfuldogs awww.. was thinking of mama being scary..lol..",
  "id" : 73368956844507137,
  "in_reply_to_status_id" : 73366552166154240,
  "created_at" : "2011-05-25 12:44:57 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 0, 16 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73357037895041024",
  "geo" : { },
  "id_str" : "73367485671415808",
  "in_reply_to_user_id" : 20245651,
  "text" : "@hauntedcomputer looks good. added to my list!",
  "id" : 73367485671415808,
  "in_reply_to_status_id" : 73357037895041024,
  "created_at" : "2011-05-25 12:39:06 +0000",
  "in_reply_to_screen_name" : "eScottNicholson",
  "in_reply_to_user_id_str" : "20245651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73358212740554752",
  "geo" : { },
  "id_str" : "73366417008898048",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell having my coffee. so far, the sun is out!",
  "id" : 73366417008898048,
  "in_reply_to_status_id" : 73358212740554752,
  "created_at" : "2011-05-25 12:34:51 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 0, 12 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73358947683287040",
  "geo" : { },
  "id_str" : "73365991865856000",
  "in_reply_to_user_id" : 16691399,
  "text" : "@fearfuldogs whoa!! cool but scary but cool!",
  "id" : 73365991865856000,
  "in_reply_to_status_id" : 73358947683287040,
  "created_at" : "2011-05-25 12:33:10 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "T    Batman",
      "screen_name" : "TheToddReport",
      "indices" : [ 28, 42 ],
      "id_str" : "45186617",
      "id" : 45186617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73365725032615937",
  "text" : "RT @CharlesBivona: Word. RT @TheToddReport: Never judge a book by its movie.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "T    Batman",
        "screen_name" : "TheToddReport",
        "indices" : [ 9, 23 ],
        "id_str" : "45186617",
        "id" : 45186617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73359872607010816",
    "text" : "Word. RT @TheToddReport: Never judge a book by its movie.",
    "id" : 73359872607010816,
    "created_at" : "2011-05-25 12:08:51 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 73365725032615937,
  "created_at" : "2011-05-25 12:32:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73176435593986049",
  "geo" : { },
  "id_str" : "73184912030695424",
  "in_reply_to_user_id" : 23539037,
  "text" : "@RMoGib was watching your tweets, glad your safe! ((hugs))",
  "id" : 73184912030695424,
  "in_reply_to_status_id" : 73176435593986049,
  "created_at" : "2011-05-25 00:33:37 +0000",
  "in_reply_to_screen_name" : "OhYouGirl",
  "in_reply_to_user_id_str" : "23539037",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73176064188350464",
  "geo" : { },
  "id_str" : "73183959323918336",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH ((hugs)) Dear Ani-la",
  "id" : 73183959323918336,
  "in_reply_to_status_id" : 73176064188350464,
  "created_at" : "2011-05-25 00:29:50 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73181396969066497",
  "geo" : { },
  "id_str" : "73182821325352960",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 glad you are safely home!",
  "id" : 73182821325352960,
  "in_reply_to_status_id" : 73181396969066497,
  "created_at" : "2011-05-25 00:25:18 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 3, 16 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73166987794186240",
  "text" : "RT @AmazonKindle: In response to customer requests, introducing Kindle 3G with Special Offers for $164\u2014the lowest priced 3G e-reader. ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73165183522054144",
    "text" : "In response to customer requests, introducing Kindle 3G with Special Offers for $164\u2014the lowest priced 3G e-reader. http:\/\/amzn.to\/mr0F0M",
    "id" : 73165183522054144,
    "created_at" : "2011-05-24 23:15:13 +0000",
    "user" : {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "protected" : false,
      "id_str" : "84249568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512411639908298752\/z8wZ_AlQ_normal.jpeg",
      "id" : 84249568,
      "verified" : true
    }
  },
  "id" : 73166987794186240,
  "created_at" : "2011-05-24 23:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kunzang Drolma",
      "screen_name" : "helpsavelives",
      "indices" : [ 3, 17 ],
      "id_str" : "80181824",
      "id" : 80181824
    }, {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 98, 106 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73157060753235968",
  "text" : "RT @helpsavelives: Can pull this boy if find home on E Coast. Owner DUMP..DIES TOMORO pls help me @SangyeH http:\/\/twitgoo.com\/2ap89j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitgoo.com\" rel=\"nofollow\"\u003Etwitgoo\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ani Sangye",
        "screen_name" : "SangyeH",
        "indices" : [ 79, 87 ],
        "id_str" : "54744689",
        "id" : 54744689
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73155838633709568",
    "text" : "Can pull this boy if find home on E Coast. Owner DUMP..DIES TOMORO pls help me @SangyeH http:\/\/twitgoo.com\/2ap89j",
    "id" : 73155838633709568,
    "created_at" : "2011-05-24 22:38:05 +0000",
    "user" : {
      "name" : "Kunzang Drolma",
      "screen_name" : "helpsavelives",
      "protected" : false,
      "id_str" : "80181824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1131250105\/k_and_r_normal.jpg",
      "id" : 80181824,
      "verified" : false
    }
  },
  "id" : 73157060753235968,
  "created_at" : "2011-05-24 22:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73144930020765698",
  "text" : "RT @mssuzcatsilver: We live in an inclusion based Universe, what we give our attention too - grows, whether it be good, bad or infdiffer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loa",
        "indices" : [ 125, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73133461040402433",
    "text" : "We live in an inclusion based Universe, what we give our attention too - grows, whether it be good, bad or infdifference ;-) #loa",
    "id" : 73133461040402433,
    "created_at" : "2011-05-24 21:09:10 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 73144930020765698,
  "created_at" : "2011-05-24 21:54:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beer",
      "screen_name" : "beerandtv",
      "indices" : [ 3, 13 ],
      "id_str" : "536456673",
      "id" : 536456673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "contest",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "amazon",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73126649268416512",
  "text" : "RT @beerandtv: Last day...enter to win a $25 gift card. The Nether Sweepstakes: http:\/\/www.beerandtv.com\/archives\/698 #contest #amazon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "contest",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "amazon",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73122652105089025",
    "text" : "Last day...enter to win a $25 gift card. The Nether Sweepstakes: http:\/\/www.beerandtv.com\/archives\/698 #contest #amazon",
    "id" : 73122652105089025,
    "created_at" : "2011-05-24 20:26:13 +0000",
    "user" : {
      "name" : "Jason Beymer",
      "screen_name" : "tomesandtv",
      "protected" : false,
      "id_str" : "39121638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773641933067390977\/Y5Fp2jNF_normal.jpg",
      "id" : 39121638,
      "verified" : false
    }
  },
  "id" : 73126649268416512,
  "created_at" : "2011-05-24 20:42:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    }, {
      "name" : "Rosalie R Angel",
      "screen_name" : "MissRosalie",
      "indices" : [ 83, 95 ],
      "id_str" : "221970194",
      "id" : 221970194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73115300878495744",
  "text" : "RT @ChrisGroove1: RT some of my pals had requested I put up a chipin for my sisfur @MissRosalie surgery so here it is  w\/story http:\/\/bi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rosalie R Angel",
        "screen_name" : "MissRosalie",
        "indices" : [ 65, 77 ],
        "id_str" : "221970194",
        "id" : 221970194
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73114454530863105",
    "text" : "RT some of my pals had requested I put up a chipin for my sisfur @MissRosalie surgery so here it is  w\/story http:\/\/bit.ly\/jEMVCC",
    "id" : 73114454530863105,
    "created_at" : "2011-05-24 19:53:39 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 73115300878495744,
  "created_at" : "2011-05-24 19:57:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73109067324862464",
  "text" : "RT @DeepakChopra: The cosmos is structured to bring about growth, and growth is always in the direction of greater love and happiness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73108459721203712",
    "text" : "The cosmos is structured to bring about growth, and growth is always in the direction of greater love and happiness.",
    "id" : 73108459721203712,
    "created_at" : "2011-05-24 19:29:49 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 73109067324862464,
  "created_at" : "2011-05-24 19:32:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73093164092768256",
  "geo" : { },
  "id_str" : "73108386547376128",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott oh me, too!! ; )",
  "id" : 73108386547376128,
  "in_reply_to_status_id" : 73093164092768256,
  "created_at" : "2011-05-24 19:29:32 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73105691602202624",
  "geo" : { },
  "id_str" : "73107923680772096",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves they're not on twitter hopefully..lol",
  "id" : 73107923680772096,
  "in_reply_to_status_id" : 73105691602202624,
  "created_at" : "2011-05-24 19:27:41 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73106091403255808",
  "geo" : { },
  "id_str" : "73107589109514240",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX yes, I agree.. with both points..lol",
  "id" : 73107589109514240,
  "in_reply_to_status_id" : 73106091403255808,
  "created_at" : "2011-05-24 19:26:22 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73104216125751297",
  "geo" : { },
  "id_str" : "73104714945933312",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves oh I never want to do such a thing ((rollingeyes)) ..lol",
  "id" : 73104714945933312,
  "in_reply_to_status_id" : 73104216125751297,
  "created_at" : "2011-05-24 19:14:56 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "son rivers",
      "screen_name" : "sonrivers",
      "indices" : [ 3, 13 ],
      "id_str" : "325165820",
      "id" : 325165820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73103895848681472",
  "text" : "RT @sonrivers: you're so vain, you probably think you're you",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72842325788860416",
    "text" : "you're so vain, you probably think you're you",
    "id" : 72842325788860416,
    "created_at" : "2011-05-24 01:52:18 +0000",
    "user" : {
      "name" : "Son",
      "screen_name" : "aumdada",
      "protected" : false,
      "id_str" : "26045238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796356087503028224\/2IwUz7ms_normal.jpg",
      "id" : 26045238,
      "verified" : false
    }
  },
  "id" : 73103895848681472,
  "created_at" : "2011-05-24 19:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "indices" : [ 3, 15 ],
      "id_str" : "32585384",
      "id" : 32585384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73102899181400066",
  "text" : "RT @intuitivedm: Chipmunk energy: Although seemingly scattered there is actually a beautiful purpose to all their running around: prepar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73102403800539136",
    "text" : "Chipmunk energy: Although seemingly scattered there is actually a beautiful purpose to all their running around: preparation!",
    "id" : 73102403800539136,
    "created_at" : "2011-05-24 19:05:45 +0000",
    "user" : {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "protected" : false,
      "id_str" : "32585384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509424532495429633\/3M8ImHNe_normal.jpeg",
      "id" : 32585384,
      "verified" : false
    }
  },
  "id" : 73102899181400066,
  "created_at" : "2011-05-24 19:07:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73080184496062464",
  "text" : "I am not here to teach anybody anything. I am here simply to experience the experience.",
  "id" : 73080184496062464,
  "created_at" : "2011-05-24 17:37:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary-Anne Reed",
      "screen_name" : "HPSelf",
      "indices" : [ 3, 10 ],
      "id_str" : "43237308",
      "id" : 43237308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73075123216846851",
  "text" : "RT @HPSelf: What's best for you is not necessarily what's best for others. Give other people their freedom to find what work's best for  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73074126222401536",
    "text" : "What's best for you is not necessarily what's best for others. Give other people their freedom to find what work's best for them.",
    "id" : 73074126222401536,
    "created_at" : "2011-05-24 17:13:23 +0000",
    "user" : {
      "name" : "Mary-Anne Reed",
      "screen_name" : "HPSelf",
      "protected" : false,
      "id_str" : "43237308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614673460355162113\/HJzNCSN8_normal.jpg",
      "id" : 43237308,
      "verified" : false
    }
  },
  "id" : 73075123216846851,
  "created_at" : "2011-05-24 17:17:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73072902756515840",
  "text" : "RT @CaroleODell: Do your job; worry over stuff you can control and leave the rest to God (you really can't control all that much)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73072482256556034",
    "text" : "Do your job; worry over stuff you can control and leave the rest to God (you really can't control all that much)",
    "id" : 73072482256556034,
    "created_at" : "2011-05-24 17:06:52 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 73072902756515840,
  "created_at" : "2011-05-24 17:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73015652104941568",
  "geo" : { },
  "id_str" : "73071183460966402",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad after reading, just ran screaming thru my house (well, in my mind actually).. sigh.",
  "id" : 73071183460966402,
  "in_reply_to_status_id" : 73015652104941568,
  "created_at" : "2011-05-24 17:01:42 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sena Quaren",
      "screen_name" : "senaquaren",
      "indices" : [ 3, 14 ],
      "id_str" : "179704572",
      "id" : 179704572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amwriting",
      "indices" : [ 110, 120 ]
    }, {
      "text" : "writing",
      "indices" : [ 121, 129 ]
    }, {
      "text" : "scifi",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73069685695987712",
  "text" : "RT @senaquaren: \"Notes from An Alien\" is Published --But, U cn still get a free copy :-) http:\/\/bit.ly\/gCrZb1 #amwriting #writing #scifi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amwriting",
        "indices" : [ 94, 104 ]
      }, {
        "text" : "writing",
        "indices" : [ 105, 113 ]
      }, {
        "text" : "scifi",
        "indices" : [ 114, 120 ]
      }, {
        "text" : "reading",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73045764703662080",
    "text" : "\"Notes from An Alien\" is Published --But, U cn still get a free copy :-) http:\/\/bit.ly\/gCrZb1 #amwriting #writing #scifi #reading",
    "id" : 73045764703662080,
    "created_at" : "2011-05-24 15:20:42 +0000",
    "user" : {
      "name" : "Sena Quaren",
      "screen_name" : "senaquaren",
      "protected" : false,
      "id_str" : "179704572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1105291475\/me_normal.jpg",
      "id" : 179704572,
      "verified" : false
    }
  },
  "id" : 73069685695987712,
  "created_at" : "2011-05-24 16:55:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 0, 10 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73067998105178114",
  "geo" : { },
  "id_str" : "73069564212162560",
  "in_reply_to_user_id" : 24636191,
  "text" : "@LukeRomyn ..and stuff &lt;&lt; LOL I like that : )",
  "id" : 73069564212162560,
  "in_reply_to_status_id" : 73067998105178114,
  "created_at" : "2011-05-24 16:55:16 +0000",
  "in_reply_to_screen_name" : "LukeRomyn",
  "in_reply_to_user_id_str" : "24636191",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73019098384187393",
  "geo" : { },
  "id_str" : "73067764818001920",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX I love gadgets so I want one but it wldnt replace my Kindle. I imagine there is monthly internet fee, also.",
  "id" : 73067764818001920,
  "in_reply_to_status_id" : 73019098384187393,
  "created_at" : "2011-05-24 16:48:07 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 0, 10 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73062661885136896",
  "geo" : { },
  "id_str" : "73067215552917505",
  "in_reply_to_user_id" : 24636191,
  "text" : "@LukeRomyn I know you have strange humor but this is profound, really.",
  "id" : 73067215552917505,
  "in_reply_to_status_id" : 73062661885136896,
  "created_at" : "2011-05-24 16:45:56 +0000",
  "in_reply_to_screen_name" : "LukeRomyn",
  "in_reply_to_user_id_str" : "24636191",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73066981875650560",
  "text" : "RT @LukeRomyn: In a universe so unending, amid a myriad of stars and numberless planets, the fact you look fat in those pants probably d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73062661885136896",
    "text" : "In a universe so unending, amid a myriad of stars and numberless planets, the fact you look fat in those pants probably doesn't matter.",
    "id" : 73062661885136896,
    "created_at" : "2011-05-24 16:27:50 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 73066981875650560,
  "created_at" : "2011-05-24 16:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73066758856126464",
  "text" : "RT @stevetheseeker: If all the energy spent on defending, judging & resisting were used for creating, loving and flowing, we would have  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73065353177075712",
    "text" : "If all the energy spent on defending, judging & resisting were used for creating, loving and flowing, we would have a far different world.",
    "id" : 73065353177075712,
    "created_at" : "2011-05-24 16:38:32 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 73066758856126464,
  "created_at" : "2011-05-24 16:44:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73066566928973824",
  "text" : "but Im going because it makes MIL happy (she likes going w someone) and I can still learn from it.",
  "id" : 73066566928973824,
  "created_at" : "2011-05-24 16:43:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73066298233454593",
  "text" : "went to bible study w my MIL this AM. I prayed for patience! lol (as I dont believe what they believe)",
  "id" : 73066298233454593,
  "created_at" : "2011-05-24 16:42:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "Android and Me",
      "screen_name" : "androidandme",
      "indices" : [ 9, 22 ],
      "id_str" : "20292942",
      "id" : 20292942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73018231006306304",
  "geo" : { },
  "id_str" : "73018780548202496",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX @androidandme noo... I want one but thats too high for me : (",
  "id" : 73018780548202496,
  "in_reply_to_status_id" : 73018231006306304,
  "created_at" : "2011-05-24 13:33:28 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebook",
      "indices" : [ 29, 35 ]
    }, {
      "text" : "Smashwords",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "kindle",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "nook",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73014011477753856",
  "text" : "RT @byoung210: My very first #ebook, Sunrise, is always free on #Smashwords with coupon code: RN65Z http:\/\/j.mp\/hHCnpK #kindle #nook #pu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebook",
        "indices" : [ 14, 20 ]
      }, {
        "text" : "Smashwords",
        "indices" : [ 49, 60 ]
      }, {
        "text" : "kindle",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "nook",
        "indices" : [ 112, 117 ]
      }, {
        "text" : "pubwrite",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73013576889147395",
    "text" : "My very first #ebook, Sunrise, is always free on #Smashwords with coupon code: RN65Z http:\/\/j.mp\/hHCnpK #kindle #nook #pubwrite",
    "id" : 73013576889147395,
    "created_at" : "2011-05-24 13:12:47 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 73014011477753856,
  "created_at" : "2011-05-24 13:14:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    }, {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 21, 32 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73000762044723201",
  "text" : "RT @Joeandrasi93: RT @sparklekaz In the depth of winter, I finally learned that within me there lay an invincible summer. Albert Camus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SPIRITU\u2206L SEEKER",
        "screen_name" : "sparklekaz",
        "indices" : [ 3, 14 ],
        "id_str" : "79711579",
        "id" : 79711579
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72996228933230593",
    "text" : "RT @sparklekaz In the depth of winter, I finally learned that within me there lay an invincible summer. Albert Camus",
    "id" : 72996228933230593,
    "created_at" : "2011-05-24 12:03:51 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 73000762044723201,
  "created_at" : "2011-05-24 12:21:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72843567051177984",
  "geo" : { },
  "id_str" : "72846477151567872",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves ((hugs)) tomorrow will be better!",
  "id" : 72846477151567872,
  "in_reply_to_status_id" : 72843567051177984,
  "created_at" : "2011-05-24 02:08:48 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72839035063767042",
  "text" : "RT @Palidan: \"The tougher the times, the more clarity you gain about the difference between what really matters and what doesn't.\" Po Br ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72838606288453632",
    "text" : "\"The tougher the times, the more clarity you gain about the difference between what really matters and what doesn't.\" Po Bronson",
    "id" : 72838606288453632,
    "created_at" : "2011-05-24 01:37:31 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 72839035063767042,
  "created_at" : "2011-05-24 01:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Kunzang Drolma",
      "screen_name" : "helpsavelives",
      "indices" : [ 9, 23 ],
      "id_str" : "80181824",
      "id" : 80181824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72823144762703872",
  "geo" : { },
  "id_str" : "72828050957533184",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH @helpsavelives I felt same way looking at him! something about him... : )",
  "id" : 72828050957533184,
  "in_reply_to_status_id" : 72823144762703872,
  "created_at" : "2011-05-24 00:55:35 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72826194655059968",
  "geo" : { },
  "id_str" : "72827655875084288",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld smooches to the sweet kitty!",
  "id" : 72827655875084288,
  "in_reply_to_status_id" : 72826194655059968,
  "created_at" : "2011-05-24 00:54:00 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72826620251082752",
  "text" : "RT @_NealeDWalsch: If U saw others as God sees others, U would smile your way through your judgment of others, seeing them as U would be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nealedonaldwalsch.com\" rel=\"nofollow\"\u003ENeale Donald Walsch\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72815984246919168",
    "text" : "If U saw others as God sees others, U would smile your way through your judgment of others, seeing them as U would beg your self 2 be seen.",
    "id" : 72815984246919168,
    "created_at" : "2011-05-24 00:07:38 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 72826620251082752,
  "created_at" : "2011-05-24 00:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches The Poodle",
      "screen_name" : "PeachiePoodle",
      "indices" : [ 3, 17 ],
      "id_str" : "45597851",
      "id" : 45597851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72815514400985088",
  "text" : "RT @PeachiePoodle: \"If there are no dogs in Heaven, then when I die I want to go where they went.\" - Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/renttoownmd.webs.com\/\" rel=\"nofollow\"\u003ETwtMon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72813039279280128",
    "text" : "\"If there are no dogs in Heaven, then when I die I want to go where they went.\" - Unknown",
    "id" : 72813039279280128,
    "created_at" : "2011-05-23 23:55:56 +0000",
    "user" : {
      "name" : "Peaches The Poodle",
      "screen_name" : "PeachiePoodle",
      "protected" : false,
      "id_str" : "45597851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/255129672\/Copy_of_Peachie_normal.jpg",
      "id" : 45597851,
      "verified" : false
    }
  },
  "id" : 72815514400985088,
  "created_at" : "2011-05-24 00:05:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72763729024004096",
  "text" : "I have an ebook blog that uses shortcode to put links on each page. I want to show recent updates to readers.",
  "id" : 72763729024004096,
  "created_at" : "2011-05-23 20:39:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72762618292604928",
  "text" : "there must be a wp plugin that shows blog readers when new links added..but I cant find..",
  "id" : 72762618292604928,
  "created_at" : "2011-05-23 20:35:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi Redford",
      "screen_name" : "jodiredford",
      "indices" : [ 3, 15 ],
      "id_str" : "89815691",
      "id" : 89815691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72761996726116353",
  "text" : "RT @jodiredford: I have eARCs of The Seven Year Witch available for review. @ me or shoot an email to jodiredford (AT) jodiredford (Dot) ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72756344201027584",
    "text" : "I have eARCs of The Seven Year Witch available for review. @ me or shoot an email to jodiredford (AT) jodiredford (Dot) com if interested.",
    "id" : 72756344201027584,
    "created_at" : "2011-05-23 20:10:38 +0000",
    "user" : {
      "name" : "Jodi Redford",
      "screen_name" : "jodiredford",
      "protected" : false,
      "id_str" : "89815691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455486546418728960\/q7R7pmyl_normal.jpeg",
      "id" : 89815691,
      "verified" : false
    }
  },
  "id" : 72761996726116353,
  "created_at" : "2011-05-23 20:33:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "indices" : [ 3, 13 ],
      "id_str" : "23812887",
      "id" : 23812887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAN1",
      "indices" : [ 113, 118 ]
    }, {
      "text" : "supportthelittleguy",
      "indices" : [ 119, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72757249507995649",
  "text" : "RT @LizBorino: The Avid Readers Cafe launches today http:\/\/bit.ly\/m9kUin! Check it out! Win a Kindle! Buy books! #IAN1 #supportthelittleguy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAN1",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "supportthelittleguy",
        "indices" : [ 104, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72755645539028992",
    "text" : "The Avid Readers Cafe launches today http:\/\/bit.ly\/m9kUin! Check it out! Win a Kindle! Buy books! #IAN1 #supportthelittleguy",
    "id" : 72755645539028992,
    "created_at" : "2011-05-23 20:07:52 +0000",
    "user" : {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "protected" : false,
      "id_str" : "23812887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489066924773371905\/AJv5YOCl_normal.jpeg",
      "id" : 23812887,
      "verified" : false
    }
  },
  "id" : 72757249507995649,
  "created_at" : "2011-05-23 20:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I Love Smashwords",
      "screen_name" : "ILoveSmashwords",
      "indices" : [ 3, 19 ],
      "id_str" : "297636628",
      "id" : 297636628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eBooks",
      "indices" : [ 61, 68 ]
    }, {
      "text" : "Smashwords",
      "indices" : [ 83, 94 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72696382829494272",
  "text" : "RT @ILoveSmashwords: Jacob Drake teaches you how to Download #eBooks Directly From #Smashwords to the #Kindle http:\/\/wp.me\/p1yXyo-22 . B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eBooks",
        "indices" : [ 40, 47 ]
      }, {
        "text" : "Smashwords",
        "indices" : [ 62, 73 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72673357329469441",
    "text" : "Jacob Drake teaches you how to Download #eBooks Directly From #Smashwords to the #Kindle http:\/\/wp.me\/p1yXyo-22 . Brilliant, in every sense.",
    "id" : 72673357329469441,
    "created_at" : "2011-05-23 14:40:53 +0000",
    "user" : {
      "name" : "I Love Smashwords",
      "screen_name" : "ILoveSmashwords",
      "protected" : false,
      "id_str" : "297636628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1353058359\/ilslogotrans_normal.jpg",
      "id" : 297636628,
      "verified" : false
    }
  },
  "id" : 72696382829494272,
  "created_at" : "2011-05-23 16:12:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72690268335378432",
  "text" : "RT @DawnFine: Via @pwtphotography Dandelion Removal Service Now Open! http:\/\/bit.ly\/j9olT6 #Nature @DawnFine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dawn",
        "screen_name" : "DawnFine",
        "indices" : [ 85, 94 ],
        "id_str" : "17341213",
        "id" : 17341213
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72681209980915712",
    "text" : "Via @pwtphotography Dandelion Removal Service Now Open! http:\/\/bit.ly\/j9olT6 #Nature @DawnFine",
    "id" : 72681209980915712,
    "created_at" : "2011-05-23 15:12:05 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 72690268335378432,
  "created_at" : "2011-05-23 15:48:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72635570815369216",
  "text" : "RT @screek: Mom's Protection http:\/\/post.ly\/25Pyp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/posterous.com\" rel=\"nofollow\"\u003EPosterous\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72634530447634433",
    "text" : "Mom's Protection http:\/\/post.ly\/25Pyp",
    "id" : 72634530447634433,
    "created_at" : "2011-05-23 12:06:36 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 72635570815369216,
  "created_at" : "2011-05-23 12:10:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Steven B",
      "screen_name" : "_isolar_",
      "indices" : [ 19, 28 ],
      "id_str" : "124166373",
      "id" : 124166373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72459600569446402",
  "text" : "RT @TrishScott: RT @_isolar_: Christ, first misunderstood and crucified, then misunderstood and worshipped. ~ Robert Graves (from 'King  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven B",
        "screen_name" : "_isolar_",
        "indices" : [ 3, 12 ],
        "id_str" : "124166373",
        "id" : 124166373
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72451200456466432",
    "text" : "RT @_isolar_: Christ, first misunderstood and crucified, then misunderstood and worshipped. ~ Robert Graves (from 'King Jesus').",
    "id" : 72451200456466432,
    "created_at" : "2011-05-22 23:58:06 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 72459600569446402,
  "created_at" : "2011-05-23 00:31:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72457512846245888",
  "geo" : { },
  "id_str" : "72458986519150592",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 Hurray! : )",
  "id" : 72458986519150592,
  "in_reply_to_status_id" : 72457512846245888,
  "created_at" : "2011-05-23 00:29:03 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72436170310692864",
  "text" : "RT @bunnybuddhism: I know bunniness is real even if it cannot be perceived by the ordinary senses.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72435154001461250",
    "text" : "I know bunniness is real even if it cannot be perceived by the ordinary senses.",
    "id" : 72435154001461250,
    "created_at" : "2011-05-22 22:54:21 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 72436170310692864,
  "created_at" : "2011-05-22 22:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Jen McNair Wilson",
      "screen_name" : "Jenmalen",
      "indices" : [ 19, 28 ],
      "id_str" : "19820412",
      "id" : 19820412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72435885144158208",
  "text" : "RT @TrishScott: RT @Jenmalen: Relax, nothing is under control.  Jyoti Didi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen McNair Wilson",
        "screen_name" : "Jenmalen",
        "indices" : [ 3, 12 ],
        "id_str" : "19820412",
        "id" : 19820412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72427119157854208",
    "text" : "RT @Jenmalen: Relax, nothing is under control.  Jyoti Didi",
    "id" : 72427119157854208,
    "created_at" : "2011-05-22 22:22:25 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 72435885144158208,
  "created_at" : "2011-05-22 22:57:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liberty Belle",
      "screen_name" : "LibertyBelle4",
      "indices" : [ 3, 17 ],
      "id_str" : "564377528",
      "id" : 564377528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72432950490300416",
  "text" : "RT @LibertyBelle4: I listen to people who say things that are of interest to me, and say what I feel like saying. Those I like may NOT l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72428768630800384",
    "text" : "I listen to people who say things that are of interest to me, and say what I feel like saying. Those I like may NOT like ME. So be it.",
    "id" : 72428768630800384,
    "created_at" : "2011-05-22 22:28:58 +0000",
    "user" : {
      "name" : "J",
      "screen_name" : "LibertyBelleJ",
      "protected" : false,
      "id_str" : "118718294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547650950177910784\/qg9Syf04_normal.png",
      "id" : 118718294,
      "verified" : false
    }
  },
  "id" : 72432950490300416,
  "created_at" : "2011-05-22 22:45:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liberty Belle",
      "screen_name" : "LibertyBelle4",
      "indices" : [ 3, 17 ],
      "id_str" : "564377528",
      "id" : 564377528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72432894970310656",
  "text" : "RT @LibertyBelle4: I'd like to *think* those I follow would enjoy what I have to say. But we're all here for different reasons w\/differe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72430338231648256",
    "text" : "I'd like to *think* those I follow would enjoy what I have to say. But we're all here for different reasons w\/different needs & schedules.",
    "id" : 72430338231648256,
    "created_at" : "2011-05-22 22:35:12 +0000",
    "user" : {
      "name" : "J",
      "screen_name" : "LibertyBelleJ",
      "protected" : false,
      "id_str" : "118718294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547650950177910784\/qg9Syf04_normal.png",
      "id" : 118718294,
      "verified" : false
    }
  },
  "id" : 72432894970310656,
  "created_at" : "2011-05-22 22:45:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72354210859069440",
  "geo" : { },
  "id_str" : "72354980476092416",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts : )",
  "id" : 72354980476092416,
  "in_reply_to_status_id" : 72354210859069440,
  "created_at" : "2011-05-22 17:35:46 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72352421132771328",
  "geo" : { },
  "id_str" : "72353164002725888",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts read the little writing at the bottom of that link..looks fake.",
  "id" : 72353164002725888,
  "in_reply_to_status_id" : 72352421132771328,
  "created_at" : "2011-05-22 17:28:33 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72350502272253952",
  "geo" : { },
  "id_str" : "72351769505705984",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I saw yr tweet and not finding anything else about it. I thought he was filming in NYC. hmm...",
  "id" : 72351769505705984,
  "in_reply_to_status_id" : 72350502272253952,
  "created_at" : "2011-05-22 17:23:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BE",
      "screen_name" : "Lemurian13",
      "indices" : [ 3, 14 ],
      "id_str" : "147699332",
      "id" : 147699332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72346792284524544",
  "text" : "RT @Lemurian13: i'll never ask you to walk on water, i do ask you to look at your mirror image and think about the light you see reflect ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72344871314264064",
    "text" : "i'll never ask you to walk on water, i do ask you to look at your mirror image and think about the light you see reflected . who are you ?",
    "id" : 72344871314264064,
    "created_at" : "2011-05-22 16:55:36 +0000",
    "user" : {
      "name" : "BE",
      "screen_name" : "Lemurian13",
      "protected" : false,
      "id_str" : "147699332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2593204955\/sjd0nmc5afdyk4cf27uv_normal.jpeg",
      "id" : 147699332,
      "verified" : false
    }
  },
  "id" : 72346792284524544,
  "created_at" : "2011-05-22 17:03:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72333060288425984",
  "geo" : { },
  "id_str" : "72335548202754048",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords tuxedo, definitely!",
  "id" : 72335548202754048,
  "in_reply_to_status_id" : 72333060288425984,
  "created_at" : "2011-05-22 16:18:33 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72318552425771008",
  "geo" : { },
  "id_str" : "72319843667423232",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle aww, you are always so sweet to me! : )",
  "id" : 72319843667423232,
  "in_reply_to_status_id" : 72318552425771008,
  "created_at" : "2011-05-22 15:16:09 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72317781483327488",
  "geo" : { },
  "id_str" : "72319581649244160",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts eh.. just tired of the whole rapture thing.. and ppl pointing fingers. move on ppl! lol",
  "id" : 72319581649244160,
  "in_reply_to_status_id" : 72317781483327488,
  "created_at" : "2011-05-22 15:15:06 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72317479313088512",
  "text" : "also, a lot of stuff Im reading online is annoying me.",
  "id" : 72317479313088512,
  "created_at" : "2011-05-22 15:06:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72316914298400768",
  "text" : "im bored...",
  "id" : 72316914298400768,
  "created_at" : "2011-05-22 15:04:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72314111299555329",
  "geo" : { },
  "id_str" : "72316217473503232",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 you are such a good boy!",
  "id" : 72316217473503232,
  "in_reply_to_status_id" : 72314111299555329,
  "created_at" : "2011-05-22 15:01:44 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72275049184370689",
  "text" : "RT @CaroleODell: Good morning people!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72268932240777217",
    "text" : "Good morning people!",
    "id" : 72268932240777217,
    "created_at" : "2011-05-22 11:53:50 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 72275049184370689,
  "created_at" : "2011-05-22 12:18:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72274865415143425",
  "text" : "RT @DoreenVirtue444: I appreciate all my blessings, and I easily express how grateful I am for my life and for being me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72270147955605504",
    "text" : "I appreciate all my blessings, and I easily express how grateful I am for my life and for being me.",
    "id" : 72270147955605504,
    "created_at" : "2011-05-22 11:58:40 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 72274865415143425,
  "created_at" : "2011-05-22 12:17:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Raffel",
      "screen_name" : "writerkeith",
      "indices" : [ 3, 15 ],
      "id_str" : "88726620",
      "id" : 88726620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72133058555428864",
  "text" : "RT @writerkeith: Are any of you out there reviewers who would like an e-ARC of my thriller Drop By Drop? Just let me know. Feel free to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72129153729708034",
    "text" : "Are any of you out there reviewers who would like an e-ARC of my thriller Drop By Drop? Just let me know. Feel free to retweet. Keith Raffel",
    "id" : 72129153729708034,
    "created_at" : "2011-05-22 02:38:25 +0000",
    "user" : {
      "name" : "Keith Raffel",
      "screen_name" : "writerkeith",
      "protected" : false,
      "id_str" : "88726620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518616243\/KR__sunglasses__full_JPG_cropped_normal.jpg",
      "id" : 88726620,
      "verified" : false
    }
  },
  "id" : 72133058555428864,
  "created_at" : "2011-05-22 02:53:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dante",
      "screen_name" : "RainbowDelegate",
      "indices" : [ 3, 19 ],
      "id_str" : "200815093",
      "id" : 200815093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72128524160471041",
  "text" : "RT @RainbowDelegate: No act of kindness, no matter how small, is ever wasted. Let us share our kindness with others. Support them; nurtu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72107253586604032",
    "text" : "No act of kindness, no matter how small, is ever wasted. Let us share our kindness with others. Support them; nurture them and we all grow.",
    "id" : 72107253586604032,
    "created_at" : "2011-05-22 01:11:23 +0000",
    "user" : {
      "name" : "Dante",
      "screen_name" : "RainbowDelegate",
      "protected" : false,
      "id_str" : "200815093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1333100167\/RainbowBumper4x4_normal.jpg",
      "id" : 200815093,
      "verified" : false
    }
  },
  "id" : 72128524160471041,
  "created_at" : "2011-05-22 02:35:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 0, 13 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72089464834498560",
  "geo" : { },
  "id_str" : "72092060970254336",
  "in_reply_to_user_id" : 47618028,
  "text" : "@BeasBookNook heehee.. I'm so happy it's working again! : )",
  "id" : 72092060970254336,
  "in_reply_to_status_id" : 72089464834498560,
  "created_at" : "2011-05-22 00:11:01 +0000",
  "in_reply_to_screen_name" : "BeasBookNook",
  "in_reply_to_user_id_str" : "47618028",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72073757409284096",
  "geo" : { },
  "id_str" : "72086744715100161",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal ((hugs))",
  "id" : 72086744715100161,
  "in_reply_to_status_id" : 72073757409284096,
  "created_at" : "2011-05-21 23:49:53 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stereo Williams",
      "screen_name" : "stereowilliams",
      "indices" : [ 3, 18 ],
      "id_str" : "24245360",
      "id" : 24245360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72085257008062464",
  "text" : "RT @stereowilliams: If this was an M. Night Shyamalan movie, we'd all just now realize that the rapture was 150 yrs ago & we've all been ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72061724269883392",
    "text" : "If this was an M. Night Shyamalan movie, we'd all just now realize that the rapture was 150 yrs ago & we've all been in hell ever since",
    "id" : 72061724269883392,
    "created_at" : "2011-05-21 22:10:28 +0000",
    "user" : {
      "name" : "Stereo Williams",
      "screen_name" : "stereowilliams",
      "protected" : false,
      "id_str" : "24245360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800085339838840832\/EpCahzZH_normal.jpg",
      "id" : 24245360,
      "verified" : false
    }
  },
  "id" : 72085257008062464,
  "created_at" : "2011-05-21 23:43:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72084826043334656",
  "text" : "RT @bcmystery: Squirrel!  http:\/\/instagr.am\/p\/Ei8JM\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72084713933766656",
    "text" : "Squirrel!  http:\/\/instagr.am\/p\/Ei8JM\/",
    "id" : 72084713933766656,
    "created_at" : "2011-05-21 23:41:49 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 72084826043334656,
  "created_at" : "2011-05-21 23:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72061806469853184",
  "geo" : { },
  "id_str" : "72063070914088960",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone maybe.. we all have to go together.. hmm...",
  "id" : 72063070914088960,
  "in_reply_to_status_id" : 72061806469853184,
  "created_at" : "2011-05-21 22:15:49 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71997659581394945",
  "geo" : { },
  "id_str" : "71999376876244992",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous sorry to hear that ((hugs))",
  "id" : 71999376876244992,
  "in_reply_to_status_id" : 71997659581394945,
  "created_at" : "2011-05-21 18:02:43 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71997609933422593",
  "text" : "RT @RMoGib: Yes, that is a thousand-pound horse, wallering in my garden like a dog. Oy. http:\/\/twitpic.com\/50nrrf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71994682820919297",
    "text" : "Yes, that is a thousand-pound horse, wallering in my garden like a dog. Oy. http:\/\/twitpic.com\/50nrrf",
    "id" : 71994682820919297,
    "created_at" : "2011-05-21 17:44:04 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 71997609933422593,
  "created_at" : "2011-05-21 17:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 0, 13 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71985548960595968",
  "geo" : { },
  "id_str" : "71990971725914112",
  "in_reply_to_user_id" : 47618028,
  "text" : "@BeasBookNook http:\/\/askville.amazon.com\/kindle-turn\/AnswerViewer.do?requestId=74624626 &lt;&lt; talks about resetting",
  "id" : 71990971725914112,
  "in_reply_to_status_id" : 71985548960595968,
  "created_at" : "2011-05-21 17:29:19 +0000",
  "in_reply_to_screen_name" : "BeasBookNook",
  "in_reply_to_user_id_str" : "47618028",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 0, 13 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71985548960595968",
  "geo" : { },
  "id_str" : "71990546591268865",
  "in_reply_to_user_id" : 47618028,
  "text" : "@BeasBookNook http:\/\/askville.amazon.com\/Kindle\/Category.do?cat=Kindle &lt;&lt; maybe find help here?",
  "id" : 71990546591268865,
  "in_reply_to_status_id" : 71985548960595968,
  "created_at" : "2011-05-21 17:27:38 +0000",
  "in_reply_to_screen_name" : "BeasBookNook",
  "in_reply_to_user_id_str" : "47618028",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 0, 13 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71981054076006400",
  "geo" : { },
  "id_str" : "71983561934254080",
  "in_reply_to_user_id" : 47618028,
  "text" : "@BeasBookNook oh no.. what's wrong with it?",
  "id" : 71983561934254080,
  "in_reply_to_status_id" : 71981054076006400,
  "created_at" : "2011-05-21 16:59:53 +0000",
  "in_reply_to_screen_name" : "BeasBookNook",
  "in_reply_to_user_id_str" : "47618028",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71979478510878721",
  "geo" : { },
  "id_str" : "71982169408552960",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone thank you for reminding me to see with compassion",
  "id" : 71982169408552960,
  "in_reply_to_status_id" : 71979478510878721,
  "created_at" : "2011-05-21 16:54:21 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71964553033953281",
  "geo" : { },
  "id_str" : "71969277560889344",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 that sounds yummy!",
  "id" : 71969277560889344,
  "in_reply_to_status_id" : 71964553033953281,
  "created_at" : "2011-05-21 16:03:07 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 17, 30 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71969041786478592",
  "text" : "RT @JohnCali: RT @DeepakChopra: Whatever you want will come to you if you let go of it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 3, 16 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71965295698382848",
    "text" : "RT @DeepakChopra: Whatever you want will come to you if you let go of it",
    "id" : 71965295698382848,
    "created_at" : "2011-05-21 15:47:18 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 71969041786478592,
  "created_at" : "2011-05-21 16:02:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Jack King",
      "screen_name" : "DrJackKing",
      "indices" : [ 17, 28 ],
      "id_str" : "53416950",
      "id" : 53416950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71968951877386240",
  "text" : "RT @JohnCali: RT @DrJackKing: The longest journey you will ever make in your life is from your head to your heart. ~Sioux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jack King",
        "screen_name" : "DrJackKing",
        "indices" : [ 3, 14 ],
        "id_str" : "53416950",
        "id" : 53416950
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71965635181150208",
    "text" : "RT @DrJackKing: The longest journey you will ever make in your life is from your head to your heart. ~Sioux",
    "id" : 71965635181150208,
    "created_at" : "2011-05-21 15:48:39 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 71968951877386240,
  "created_at" : "2011-05-21 16:01:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71966815605100544",
  "geo" : { },
  "id_str" : "71968519931174913",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books im good. feeling a tad giddy today..lol. maybe the coffee is stronger than usual..lol",
  "id" : 71968519931174913,
  "in_reply_to_status_id" : 71966815605100544,
  "created_at" : "2011-05-21 16:00:06 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71968127189127168",
  "text" : "apparently The Universe does listen to me..lol. Nice to know someone does! ; )",
  "id" : 71968127189127168,
  "created_at" : "2011-05-21 15:58:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 12, 22 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71961247389712384",
  "geo" : { },
  "id_str" : "71961464684032000",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks @bcmystery yay!!",
  "id" : 71961464684032000,
  "in_reply_to_status_id" : 71961247389712384,
  "created_at" : "2011-05-21 15:32:04 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 12, 22 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71960481606283264",
  "geo" : { },
  "id_str" : "71961115587907584",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks @bcmystery hope it comes out in kindle version as I really enjoyed Day One and this one looks good! : )",
  "id" : 71961115587907584,
  "in_reply_to_status_id" : 71960481606283264,
  "created_at" : "2011-05-21 15:30:41 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71958852848984064",
  "geo" : { },
  "id_str" : "71960049265815552",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 roflmao.. oh, that made me chuckle : )",
  "id" : 71960049265815552,
  "in_reply_to_status_id" : 71958852848984064,
  "created_at" : "2011-05-21 15:26:27 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71959144659292161",
  "text" : "RT @DougDorow: Hey, are you an indie ebook thriller writer? Want to market your book? Let's trade sample chapters in the backs of each o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71955914529316864",
    "text" : "Hey, are you an indie ebook thriller writer? Want to market your book? Let's trade sample chapters in the backs of each others books.",
    "id" : 71955914529316864,
    "created_at" : "2011-05-21 15:10:01 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 71959144659292161,
  "created_at" : "2011-05-21 15:22:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71956757274034176",
  "geo" : { },
  "id_str" : "71958905562988545",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous you can let it go... (easier said than done, I know..)",
  "id" : 71958905562988545,
  "in_reply_to_status_id" : 71956757274034176,
  "created_at" : "2011-05-21 15:21:54 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u042D\u043B\u0435\u0433\u0430\u043D\u0442\u043D\u044B\u0439 \u041F\u0435\u0442\u044C\u041A\u043E",
      "screen_name" : "loagold",
      "indices" : [ 3, 11 ],
      "id_str" : "2821095428",
      "id" : 2821095428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheSecret",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "Quote",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71958120678694912",
  "text" : "RT @LOAGold: We are mass energy. Everything is energy. EVERYTHING. #TheSecret #Quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheSecret",
        "indices" : [ 54, 64 ]
      }, {
        "text" : "Quote",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71956878686552064",
    "text" : "We are mass energy. Everything is energy. EVERYTHING. #TheSecret #Quote",
    "id" : 71956878686552064,
    "created_at" : "2011-05-21 15:13:51 +0000",
    "user" : {
      "name" : "Law Of Attraction",
      "screen_name" : "LOAPower",
      "protected" : false,
      "id_str" : "233250372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1205016796\/149622_159509980757423_100000952670462_289017_3073029_n_normal.jpg",
      "id" : 233250372,
      "verified" : false
    }
  },
  "id" : 71958120678694912,
  "created_at" : "2011-05-21 15:18:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeanie Marshall",
      "screen_name" : "JeanieMarshall",
      "indices" : [ 3, 18 ],
      "id_str" : "16498622",
      "id" : 16498622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71957981801099264",
  "text" : "RT @JeanieMarshall: You become what you think about, whether you're appreciating or criticizing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.empowering-personal-development.com\/\" rel=\"nofollow\"\u003EEmpowering Personal Development\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71957187869671425",
    "text" : "You become what you think about, whether you're appreciating or criticizing.",
    "id" : 71957187869671425,
    "created_at" : "2011-05-21 15:15:05 +0000",
    "user" : {
      "name" : "Jeanie Marshall",
      "screen_name" : "JeanieMarshall",
      "protected" : false,
      "id_str" : "16498622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/60884811\/jeanie_normal.jpg",
      "id" : 16498622,
      "verified" : false
    }
  },
  "id" : 71957981801099264,
  "created_at" : "2011-05-21 15:18:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Marcia Sirota",
      "screen_name" : "rcinstitute",
      "indices" : [ 3, 15 ],
      "id_str" : "62088627",
      "id" : 62088627
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SensitivitySaturday",
      "indices" : [ 17, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71957901257879553",
  "text" : "RT @rcinstitute: #SensitivitySaturday: highly sensitive people are lucky; it's a gift, but like all such gifts one must learn how to use it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SensitivitySaturday",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71957060392189952",
    "text" : "#SensitivitySaturday: highly sensitive people are lucky; it's a gift, but like all such gifts one must learn how to use it.",
    "id" : 71957060392189952,
    "created_at" : "2011-05-21 15:14:34 +0000",
    "user" : {
      "name" : "Dr. Marcia Sirota",
      "screen_name" : "rcinstitute",
      "protected" : false,
      "id_str" : "62088627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3556467555\/1b4568be16bd1942f72ab6e8676a709a_normal.jpeg",
      "id" : 62088627,
      "verified" : false
    }
  },
  "id" : 71957901257879553,
  "created_at" : "2011-05-21 15:17:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71747805378646016",
  "text" : "RT @AnAmericanMonk: 'The Twelve Sacred Principles of Karma' is a book to read on empowering yourself, cause &effect you. #books",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 101, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71747587950129152",
    "text" : "'The Twelve Sacred Principles of Karma' is a book to read on empowering yourself, cause &effect you. #books",
    "id" : 71747587950129152,
    "created_at" : "2011-05-21 01:22:12 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 71747805378646016,
  "created_at" : "2011-05-21 01:23:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71744316783075328",
  "text" : "RT @DeepakChopra: Accept people for who they are. And at all times, be ready to forgive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71743897252003840",
    "text" : "Accept people for who they are. And at all times, be ready to forgive.",
    "id" : 71743897252003840,
    "created_at" : "2011-05-21 01:07:32 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 71744316783075328,
  "created_at" : "2011-05-21 01:09:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71734084073828352",
  "text" : "RT @DeepakChopra: To see the world from others' perspective is to take on their emotional footprint. To comprehend the world through them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71733786257272832",
    "text" : "To see the world from others' perspective is to take on their emotional footprint. To comprehend the world through them.",
    "id" : 71733786257272832,
    "created_at" : "2011-05-21 00:27:22 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 71734084073828352,
  "created_at" : "2011-05-21 00:28:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 17, 30 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71710495412977664",
  "text" : "RT @angelaharms: @DeepakChopra To choose love in this moment. And this one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 0, 13 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "71706576473432064",
    "geo" : { },
    "id_str" : "71708253947572224",
    "in_reply_to_user_id" : 15588657,
    "text" : "@DeepakChopra To choose love in this moment. And this one.",
    "id" : 71708253947572224,
    "in_reply_to_status_id" : 71706576473432064,
    "created_at" : "2011-05-20 22:45:54 +0000",
    "in_reply_to_screen_name" : "DeepakChopra",
    "in_reply_to_user_id_str" : "15588657",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 71710495412977664,
  "created_at" : "2011-05-20 22:54:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71699825325912064",
  "text" : "RT @RMoGib: Donkey. Backyard. Again. http:\/\/twitpic.com\/508oir",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71699191394615296",
    "text" : "Donkey. Backyard. Again. http:\/\/twitpic.com\/508oir",
    "id" : 71699191394615296,
    "created_at" : "2011-05-20 22:09:53 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 71699825325912064,
  "created_at" : "2011-05-20 22:12:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71696654331416576",
  "geo" : { },
  "id_str" : "71697379555946496",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist awww.. thats sweet!",
  "id" : 71697379555946496,
  "in_reply_to_status_id" : 71696654331416576,
  "created_at" : "2011-05-20 22:02:42 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71695349806403585",
  "text" : "RT @Squirrely007: I feel bad for Arnold's secret son. I hope this media mess was not how he found out who his father was.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71685456697360384",
    "text" : "I feel bad for Arnold's secret son. I hope this media mess was not how he found out who his father was.",
    "id" : 71685456697360384,
    "created_at" : "2011-05-20 21:15:19 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 71695349806403585,
  "created_at" : "2011-05-20 21:54:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 15, 24 ]
    }, {
      "text" : "suspense",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71695079810666497",
  "text" : "RT @DougDorow: #thriller #suspense ebook authors. I'm publishing my thriller soon and looking to swap sample chapters in each others boo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "suspense",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "marketing",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71687541149007872",
    "text" : "#thriller #suspense ebook authors. I'm publishing my thriller soon and looking to swap sample chapters in each others books #marketing",
    "id" : 71687541149007872,
    "created_at" : "2011-05-20 21:23:36 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 71695079810666497,
  "created_at" : "2011-05-20 21:53:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Windwalker",
      "screen_name" : "WindwalkerHere",
      "indices" : [ 3, 18 ],
      "id_str" : "15314069",
      "id" : 15314069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71673054102695937",
  "text" : "RT @WindwalkerHere: Would you like Kindle Nation to send you an email alert when the Kindle Tablet is announced and ready for pre-order? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71656622400868352",
    "text" : "Would you like Kindle Nation to send you an email alert when the Kindle Tablet is announced and ready for pre-order? http:\/\/bit.ly\/KTabAlert",
    "id" : 71656622400868352,
    "created_at" : "2011-05-20 19:20:44 +0000",
    "user" : {
      "name" : "Stephen Windwalker",
      "screen_name" : "WindwalkerHere",
      "protected" : false,
      "id_str" : "15314069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/285662504\/Windwalker_1_normal.jpg",
      "id" : 15314069,
      "verified" : false
    }
  },
  "id" : 71673054102695937,
  "created_at" : "2011-05-20 20:26:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71671164564545536",
  "geo" : { },
  "id_str" : "71671347004194816",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 hope she's doing better!",
  "id" : 71671347004194816,
  "in_reply_to_status_id" : 71671164564545536,
  "created_at" : "2011-05-20 20:19:15 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    }, {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 111, 124 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71648063776763904",
  "text" : "RT @JosephRanseth: If you're at all curious about how life really works & what goes on inside your brain, meet @neardeathdoc. A true gen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melvin Morse",
        "screen_name" : "neardeathdoc",
        "indices" : [ 92, 105 ],
        "id_str" : "113458113",
        "id" : 113458113
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowFriday",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71640245946429441",
    "text" : "If you're at all curious about how life really works & what goes on inside your brain, meet @neardeathdoc. A true genius. #FollowFriday",
    "id" : 71640245946429441,
    "created_at" : "2011-05-20 18:15:40 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 71648063776763904,
  "created_at" : "2011-05-20 18:46:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71635897602416641",
  "text" : "oops. I made a mess in the washer...",
  "id" : 71635897602416641,
  "created_at" : "2011-05-20 17:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71635102383345665",
  "geo" : { },
  "id_str" : "71635464049799168",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts ha.. me, too! : )",
  "id" : 71635464049799168,
  "in_reply_to_status_id" : 71635102383345665,
  "created_at" : "2011-05-20 17:56:40 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71613195407736832",
  "geo" : { },
  "id_str" : "71615013579796480",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I may join MILs bible study..it only runs a few more weeks. I got out all my diff bibles..lol",
  "id" : 71615013579796480,
  "in_reply_to_status_id" : 71613195407736832,
  "created_at" : "2011-05-20 16:35:24 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71612474264260608",
  "text" : "so.. im trying to find a good bible for my kindle. I may end up with a Search By Verse version.",
  "id" : 71612474264260608,
  "created_at" : "2011-05-20 16:25:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71553848644345856",
  "text" : "RT @TheChristianLft: When judgement doesn't happen on Saturday, let's follow it up with a Non-Judgement day. http:\/\/fb.me\/VgvRV9Lf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71544842538328066",
    "text" : "When judgement doesn't happen on Saturday, let's follow it up with a Non-Judgement day. http:\/\/fb.me\/VgvRV9Lf",
    "id" : 71544842538328066,
    "created_at" : "2011-05-20 11:56:34 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 71553848644345856,
  "created_at" : "2011-05-20 12:32:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u044F\u0445\u0438\u043Da \u0412\u0435\u0440\u043E\u043D\u0438\u043A\u0430",
      "screen_name" : "ileducprof",
      "indices" : [ 3, 14 ],
      "id_str" : "2833404087",
      "id" : 2833404087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71553240394776576",
  "text" : "RT @ileducprof: If you are old enough to remember placing your pointing finger in a small hole (or a pencil), to rewind a lose tape, ret ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71407144204898304",
    "text" : "If you are old enough to remember placing your pointing finger in a small hole (or a pencil), to rewind a lose tape, retweet.",
    "id" : 71407144204898304,
    "created_at" : "2011-05-20 02:49:24 +0000",
    "user" : {
      "name" : "Venus Evans-Winters",
      "screen_name" : "DrVEvansWinters",
      "protected" : false,
      "id_str" : "64632139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729887695527251968\/XGJxw92e_normal.jpg",
      "id" : 64632139,
      "verified" : false
    }
  },
  "id" : 71553240394776576,
  "created_at" : "2011-05-20 12:29:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71552592374796288",
  "text" : "RT @earthXplorer: Dear coffee, you're the only one that understands me in the morning :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71552271493775360",
    "text" : "Dear coffee, you're the only one that understands me in the morning :-)",
    "id" : 71552271493775360,
    "created_at" : "2011-05-20 12:26:05 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 71552592374796288,
  "created_at" : "2011-05-20 12:27:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71398907707539456",
  "text" : "RT @TheEntertainer: Change your story, change EVERYTHING. It's ALL a story, so choose wisely.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71398658662338563",
    "text" : "Change your story, change EVERYTHING. It's ALL a story, so choose wisely.",
    "id" : 71398658662338563,
    "created_at" : "2011-05-20 02:15:41 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 71398907707539456,
  "created_at" : "2011-05-20 02:16:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "indices" : [ 3, 14 ],
      "id_str" : "14461139",
      "id" : 14461139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71393922525569024",
  "text" : "RT @coachkaren: Its interesting how 2 people can hear the same message and each take away a different meaning from it. Perception is eve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tobri.com\" rel=\"nofollow\"\u003ETobri Social DNA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71384723066327040",
    "text" : "Its interesting how 2 people can hear the same message and each take away a different meaning from it. Perception is everything and its ...",
    "id" : 71384723066327040,
    "created_at" : "2011-05-20 01:20:18 +0000",
    "user" : {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "protected" : false,
      "id_str" : "14461139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1747699492\/KarenWalker_normal.jpg",
      "id" : 14461139,
      "verified" : false
    }
  },
  "id" : 71393922525569024,
  "created_at" : "2011-05-20 01:56:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71257189863530496",
  "text" : "RT @DeepakChopra: Free from the boundaries that limit our perspective and understanding we discover that our awareness is the awareness  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71255823279603712",
    "text" : "Free from the boundaries that limit our perspective and understanding we discover that our awareness is the awareness of the universe.",
    "id" : 71255823279603712,
    "created_at" : "2011-05-19 16:48:06 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 71257189863530496,
  "created_at" : "2011-05-19 16:53:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 8, 23 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71255957170176000",
  "text" : "BOTH RT @richarddoetsch: \u265EAre you a person of faith, science, or both?",
  "id" : 71255957170176000,
  "created_at" : "2011-05-19 16:48:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71242317037715456",
  "text" : "btw.. the expression \"love hurts\" is false. love does NOT hurt. It is LACK OF love that hurts.",
  "id" : 71242317037715456,
  "created_at" : "2011-05-19 15:54:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71239660550107140",
  "text" : "RT @JohnCali: Your first and greatest contribution to world peace is your own. ~ Alan Cohen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71238604789256192",
    "text" : "Your first and greatest contribution to world peace is your own. ~ Alan Cohen",
    "id" : 71238604789256192,
    "created_at" : "2011-05-19 15:39:41 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 71239660550107140,
  "created_at" : "2011-05-19 15:43:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 16, 23 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71235727417024512",
  "text" : "RT @wildobs: RT @screek: Awesome photos by Jim Coda \"Cow Elk Being Groomed by Starlings:\" http:\/\/wp.me\/pUCHh-s7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 3, 10 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71234191563571201",
    "text" : "RT @screek: Awesome photos by Jim Coda \"Cow Elk Being Groomed by Starlings:\" http:\/\/wp.me\/pUCHh-s7",
    "id" : 71234191563571201,
    "created_at" : "2011-05-19 15:22:09 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 71235727417024512,
  "created_at" : "2011-05-19 15:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miles Kahn",
      "screen_name" : "mileskahn",
      "indices" : [ 3, 13 ],
      "id_str" : "17815912",
      "id" : 17815912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71235490912808960",
  "text" : "RT @mileskahn: Gov. Walker on not giving gay couples hospital visitation rights: http:\/\/bit.ly\/lPeDYw. I'm so angry I can't even think o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71230836908888064",
    "text" : "Gov. Walker on not giving gay couples hospital visitation rights: http:\/\/bit.ly\/lPeDYw. I'm so angry I can't even think of a joke.",
    "id" : 71230836908888064,
    "created_at" : "2011-05-19 15:08:49 +0000",
    "user" : {
      "name" : "Miles Kahn",
      "screen_name" : "mileskahn",
      "protected" : false,
      "id_str" : "17815912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3656482790\/d31c78239ec88179a7ed32daa629bd74_normal.jpeg",
      "id" : 17815912,
      "verified" : true
    }
  },
  "id" : 71235490912808960,
  "created_at" : "2011-05-19 15:27:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71233738629070848",
  "text" : "my \"online\" life is just as real and valuable as my offline life. I have learned and grown from my online interactions.",
  "id" : 71233738629070848,
  "created_at" : "2011-05-19 15:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71233396629712896",
  "text" : "for some ppl, internet is only way to get info or interact w others. adds quality of life for them.",
  "id" : 71233396629712896,
  "created_at" : "2011-05-19 15:18:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71233115158347776",
  "text" : "some ppl see internet or computers as evil. say not \"real\" ppl. only predators\/scammers online, etc. FEAR based.",
  "id" : 71233115158347776,
  "created_at" : "2011-05-19 15:17:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71231735685332992",
  "geo" : { },
  "id_str" : "71232565348024320",
  "in_reply_to_user_id" : 31386920,
  "text" : "@MPMcDonald64 yes, I agree.. think ppl see it as either\/or instead of option.",
  "id" : 71232565348024320,
  "in_reply_to_status_id" : 71231735685332992,
  "created_at" : "2011-05-19 15:15:41 +0000",
  "in_reply_to_screen_name" : "MarkTaylorBooks",
  "in_reply_to_user_id_str" : "31386920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 46, 58 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71229974010527744",
  "geo" : { },
  "id_str" : "71231789095600128",
  "in_reply_to_user_id" : 143654638,
  "text" : "Nice page. I added it to my ebook blog Links! @JAScribbles",
  "id" : 71231789095600128,
  "in_reply_to_status_id" : 71229974010527744,
  "created_at" : "2011-05-19 15:12:36 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71230634487578624",
  "text" : "some ppl hate Kindle but without it, I would not get to read much or have access to great indie authors. I \u2665 my Kindle! : )",
  "id" : 71230634487578624,
  "created_at" : "2011-05-19 15:08:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71227389300056064",
  "text" : "my oxygen question is rhetorical. think of all the things we DONT worry about.. everything seems to work out. hmm..",
  "id" : 71227389300056064,
  "created_at" : "2011-05-19 14:55:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 50, 57 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71225952339894273",
  "geo" : { },
  "id_str" : "71226853322530816",
  "in_reply_to_user_id" : 13118692,
  "text" : "hmm.. maybe you should leave a note just in case! @moosep",
  "id" : 71226853322530816,
  "in_reply_to_status_id" : 71225952339894273,
  "created_at" : "2011-05-19 14:52:59 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71220423634845696",
  "text" : "how come we never worry about running out of oxygen?",
  "id" : 71220423634845696,
  "created_at" : "2011-05-19 14:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71021587826085888",
  "text" : "@Skandhasattva good point.",
  "id" : 71021587826085888,
  "created_at" : "2011-05-19 01:17:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Van Zee",
      "screen_name" : "alikat747",
      "indices" : [ 0, 10 ],
      "id_str" : "162283218",
      "id" : 162283218
    }, {
      "name" : "Ziz",
      "screen_name" : "zizzyphus",
      "indices" : [ 11, 21 ],
      "id_str" : "16477823",
      "id" : 16477823
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 22, 36 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70955272692187136",
  "geo" : { },
  "id_str" : "70956025297121280",
  "in_reply_to_user_id" : 162283218,
  "text" : "@alikat747 @zizzyphus @charlesbivona no, becuz those who ppl will find something else to fixate on",
  "id" : 70956025297121280,
  "in_reply_to_status_id" : 70955272692187136,
  "created_at" : "2011-05-18 20:56:49 +0000",
  "in_reply_to_screen_name" : "alikat747",
  "in_reply_to_user_id_str" : "162283218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70952437162311680",
  "geo" : { },
  "id_str" : "70954611103629312",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell if they're too negative",
  "id" : 70954611103629312,
  "in_reply_to_status_id" : 70952437162311680,
  "created_at" : "2011-05-18 20:51:12 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70948471301079040",
  "geo" : { },
  "id_str" : "70950018592407552",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona apparently Harold Camping",
  "id" : 70950018592407552,
  "in_reply_to_status_id" : 70948471301079040,
  "created_at" : "2011-05-18 20:32:57 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 3, 10 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70939940011253760",
  "text" : "RT @moosep: If the Rapture is on Saturday, Why am I still on a diet?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70936414694551552",
    "text" : "If the Rapture is on Saturday, Why am I still on a diet?",
    "id" : 70936414694551552,
    "created_at" : "2011-05-18 19:38:53 +0000",
    "user" : {
      "name" : "moosep",
      "screen_name" : "moosep",
      "protected" : false,
      "id_str" : "13118692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635466686485954560\/I2iA_q6N_normal.jpg",
      "id" : 13118692,
      "verified" : false
    }
  },
  "id" : 70939940011253760,
  "created_at" : "2011-05-18 19:52:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70935346636005376",
  "text" : "RT @ThisBlueWorld: My excuse for not making the bed  http:\/\/yfrog.com\/gzhifmsvj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70925858247946240",
    "text" : "My excuse for not making the bed  http:\/\/yfrog.com\/gzhifmsvj",
    "id" : 70925858247946240,
    "created_at" : "2011-05-18 18:56:57 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 70935346636005376,
  "created_at" : "2011-05-18 19:34:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guido Henkel",
      "screen_name" : "GuidoHenkel",
      "indices" : [ 3, 15 ],
      "id_str" : "118883771",
      "id" : 118883771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freeebook",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70910175451688961",
  "text" : "RT @GuidoHenkel: Hey all you people, hey all you people, hey all you people won't you listen to me? DEMON'S NIGHT is now a #freeebook in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freeebook",
        "indices" : [ 106, 116 ]
      }, {
        "text" : "iBooks",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70899335642087424",
    "text" : "Hey all you people, hey all you people, hey all you people won't you listen to me? DEMON'S NIGHT is now a #freeebook in Apple #iBooks!",
    "id" : 70899335642087424,
    "created_at" : "2011-05-18 17:11:33 +0000",
    "user" : {
      "name" : "Guido Henkel",
      "screen_name" : "GuidoHenkel",
      "protected" : false,
      "id_str" : "118883771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642495480195186689\/EF2H042S_normal.jpg",
      "id" : 118883771,
      "verified" : false
    }
  },
  "id" : 70910175451688961,
  "created_at" : "2011-05-18 17:54:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70894340406378496",
  "text" : "RT @DeepakChopra: Love grows on the basis of giving. God's ability to give is infinite. We limit it by our own unloving perception.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70892902989037568",
    "text" : "Love grows on the basis of giving. God's ability to give is infinite. We limit it by our own unloving perception.",
    "id" : 70892902989037568,
    "created_at" : "2011-05-18 16:45:59 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 70894340406378496,
  "created_at" : "2011-05-18 16:51:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Jane",
      "screen_name" : "jane_bot",
      "indices" : [ 13, 22 ],
      "id_str" : "794650416",
      "id" : 794650416
    }, {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 37, 46 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70878172316569600",
  "geo" : { },
  "id_str" : "70885537107554306",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem @jane_bot LOL.. I think @Tideliar would like this!",
  "id" : 70885537107554306,
  "in_reply_to_status_id" : 70878172316569600,
  "created_at" : "2011-05-18 16:16:43 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makesomewaves",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70876280593195008",
  "text" : "RT @CaroleODell: Oh goody, I sense an opportunity to shake some things up today. #makesomewaves",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "makesomewaves",
        "indices" : [ 64, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70864244442275840",
    "text" : "Oh goody, I sense an opportunity to shake some things up today. #makesomewaves",
    "id" : 70864244442275840,
    "created_at" : "2011-05-18 14:52:07 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 70876280593195008,
  "created_at" : "2011-05-18 15:39:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DrDogs247",
      "screen_name" : "DrDogs247",
      "indices" : [ 16, 26 ],
      "id_str" : "142585230",
      "id" : 142585230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70874507262443523",
  "text" : "RT @iwuvwes: RT @drdogs247: If you can look at a dog and not feel vicarious excitement and affection, you must be a cat.  ~Author Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DrDogs247",
        "screen_name" : "DrDogs247",
        "indices" : [ 3, 13 ],
        "id_str" : "142585230",
        "id" : 142585230
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70872537264947201",
    "text" : "RT @drdogs247: If you can look at a dog and not feel vicarious excitement and affection, you must be a cat.  ~Author Unknown",
    "id" : 70872537264947201,
    "created_at" : "2011-05-18 15:25:04 +0000",
    "user" : {
      "name" : "Wesley",
      "screen_name" : "wuvtags",
      "protected" : false,
      "id_str" : "195433961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1244223989\/beaglepup_normal.gif",
      "id" : 195433961,
      "verified" : false
    }
  },
  "id" : 70874507262443523,
  "created_at" : "2011-05-18 15:32:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70859414160154624",
  "text" : "RT @morsemusings: So many perceptions. So many projections.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70858673538334720",
    "text" : "So many perceptions. So many projections.",
    "id" : 70858673538334720,
    "created_at" : "2011-05-18 14:29:58 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 70859414160154624,
  "created_at" : "2011-05-18 14:32:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 3, 16 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70844782695546881",
  "text" : "RT @SignsOfKevin: I love it when you talk dharma to me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70400072281624576",
    "text" : "I love it when you talk dharma to me.",
    "id" : 70400072281624576,
    "created_at" : "2011-05-17 08:07:39 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "protected" : true,
      "id_str" : "21812702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747936103886270464\/QfwMeqJj_normal.jpg",
      "id" : 21812702,
      "verified" : false
    }
  },
  "id" : 70844782695546881,
  "created_at" : "2011-05-18 13:34:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 0, 12 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70838132748201984",
  "geo" : { },
  "id_str" : "70844457477615616",
  "in_reply_to_user_id" : 16691399,
  "text" : "@fearfuldogs good luck at doc & feel better! ((hugs))",
  "id" : 70844457477615616,
  "in_reply_to_status_id" : 70838132748201984,
  "created_at" : "2011-05-18 13:33:29 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 3, 10 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70843852050796544",
  "text" : "RT @SsmDad: The little boy from this affair is NOT a \"love child.\" He's just a little boy with no control over who his parents are. Leav ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70839738688471042",
    "text" : "The little boy from this affair is NOT a \"love child.\" He's just a little boy with no control over who his parents are. Leave him the F out",
    "id" : 70839738688471042,
    "created_at" : "2011-05-18 13:14:44 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "protected" : false,
      "id_str" : "122393631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649760376880525312\/faJeQ4K3_normal.jpg",
      "id" : 122393631,
      "verified" : false
    }
  },
  "id" : 70843852050796544,
  "created_at" : "2011-05-18 13:31:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chapstick",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70841897110863872",
  "geo" : { },
  "id_str" : "70843456980910080",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles Ive got several chapsticks around the house & always have one w me when I leave! lol #chapstick",
  "id" : 70843456980910080,
  "in_reply_to_status_id" : 70841897110863872,
  "created_at" : "2011-05-18 13:29:31 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 20, 34 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70822131650404352",
  "text" : "RT @DharmaTalks: RT @_NealeDWalsch: The purpose of life is to know yourself, create yourself, experience yourself as Who You Really Are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70816645924388864",
    "text" : "RT @_NealeDWalsch: The purpose of life is to know yourself, create yourself, experience yourself as Who You Really Are.",
    "id" : 70816645924388864,
    "created_at" : "2011-05-18 11:42:58 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 70822131650404352,
  "created_at" : "2011-05-18 12:04:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70821984640053249",
  "text" : "RT @GaribaldiRous: What a cute rodent! I'm glad they still exist. http:\/\/bit.ly\/k0nj6C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70817486286761985",
    "text" : "What a cute rodent! I'm glad they still exist. http:\/\/bit.ly\/k0nj6C",
    "id" : 70817486286761985,
    "created_at" : "2011-05-18 11:46:19 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 70821984640053249,
  "created_at" : "2011-05-18 12:04:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70818610062426112",
  "geo" : { },
  "id_str" : "70821658532917248",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles almost done w cup 1..lol",
  "id" : 70821658532917248,
  "in_reply_to_status_id" : 70818610062426112,
  "created_at" : "2011-05-18 12:02:53 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "indices" : [ 3, 18 ],
      "id_str" : "233966512",
      "id" : 233966512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70818096792866816",
  "text" : "RT @authorkingsley: My thriller SANDMAN is now available in paperback, Kindle and all other eBook formats. Buy options: http:\/\/www.ianki ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70786167095836672",
    "text" : "My thriller SANDMAN is now available in paperback, Kindle and all other eBook formats. Buy options: http:\/\/www.iankingsley.com\/books\/sandman",
    "id" : 70786167095836672,
    "created_at" : "2011-05-18 09:41:52 +0000",
    "user" : {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "protected" : false,
      "id_str" : "233966512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1206687416\/ian-spinaker-90ppi-smallest_normal.JPG",
      "id" : 233966512,
      "verified" : false
    }
  },
  "id" : 70818096792866816,
  "created_at" : "2011-05-18 11:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70817720299565056",
  "text" : "RT @ebookfriendly: Hot New Releases: Area 51: An Uncensored History of America's Top Secret Military Base http:\/\/amzn.to\/iCd4Pe Open in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindleapp",
        "indices" : [ 117, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70789122507276288",
    "text" : "Hot New Releases: Area 51: An Uncensored History of America's Top Secret Military Base http:\/\/amzn.to\/iCd4Pe Open in #kindleapp",
    "id" : 70789122507276288,
    "created_at" : "2011-05-18 09:53:36 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 70817720299565056,
  "created_at" : "2011-05-18 11:47:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70817661508001792",
  "text" : "RT @Moonrust: Researchers 'step closer to reading minds' http:\/\/bbc.in\/jmoC3D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70789167377948672",
    "text" : "Researchers 'step closer to reading minds' http:\/\/bbc.in\/jmoC3D",
    "id" : 70789167377948672,
    "created_at" : "2011-05-18 09:53:47 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 70817661508001792,
  "created_at" : "2011-05-18 11:47:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70552252250730497",
  "geo" : { },
  "id_str" : "70554631499038720",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld interesting.. not my view of what he is saying. yet I can see how you could see that. hmm..",
  "id" : 70554631499038720,
  "in_reply_to_status_id" : 70552252250730497,
  "created_at" : "2011-05-17 18:21:49 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raychelle Burks",
      "screen_name" : "DrRubidium",
      "indices" : [ 3, 14 ],
      "id_str" : "196458749",
      "id" : 196458749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70549774318841856",
  "text" : "RT @DrRubidium: I'm not worried about May 21st.  My hand-basket is picked out & decorated.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70548468489404416",
    "text" : "I'm not worried about May 21st.  My hand-basket is picked out & decorated.",
    "id" : 70548468489404416,
    "created_at" : "2011-05-17 17:57:20 +0000",
    "user" : {
      "name" : "Raychelle Burks",
      "screen_name" : "DrRubidium",
      "protected" : false,
      "id_str" : "196458749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586676275953045504\/VhJ1hVZY_normal.jpg",
      "id" : 196458749,
      "verified" : false
    }
  },
  "id" : 70549774318841856,
  "created_at" : "2011-05-17 18:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "DailyGood",
      "screen_name" : "Daily_Good",
      "indices" : [ 47, 58 ],
      "id_str" : "92345478",
      "id" : 92345478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dailygood",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70539768282349568",
  "text" : "RT @DeepakChopra: Everyone should read this RT @Daily_Good Homeless Man Bails Out Banker http:\/\/ht.ly\/1cDWsG #dailygood",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DailyGood",
        "screen_name" : "Daily_Good",
        "indices" : [ 29, 40 ],
        "id_str" : "92345478",
        "id" : 92345478
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dailygood",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70535362975502337",
    "text" : "Everyone should read this RT @Daily_Good Homeless Man Bails Out Banker http:\/\/ht.ly\/1cDWsG #dailygood",
    "id" : 70535362975502337,
    "created_at" : "2011-05-17 17:05:15 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 70539768282349568,
  "created_at" : "2011-05-17 17:22:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pratt",
      "screen_name" : "timpratt",
      "indices" : [ 3, 12 ],
      "id_str" : "15012705",
      "id" : 15012705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70533724646813697",
  "text" : "RT @timpratt: I'm throwing a contest. Win a copy of Welcome to Bordertown! http:\/\/www.timpratt.org\/?p=628",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70519725288980480",
    "text" : "I'm throwing a contest. Win a copy of Welcome to Bordertown! http:\/\/www.timpratt.org\/?p=628",
    "id" : 70519725288980480,
    "created_at" : "2011-05-17 16:03:07 +0000",
    "user" : {
      "name" : "Tim Pratt",
      "screen_name" : "timpratt",
      "protected" : false,
      "id_str" : "15012705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/55071255\/tim_stalks_normal.jpg",
      "id" : 15012705,
      "verified" : false
    }
  },
  "id" : 70533724646813697,
  "created_at" : "2011-05-17 16:58:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70527587843186688",
  "text" : "perception is EVERYTHING",
  "id" : 70527587843186688,
  "created_at" : "2011-05-17 16:34:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70527400458465281",
  "text" : "interesting how my brain processes the info there. its like a language conversion.",
  "id" : 70527400458465281,
  "created_at" : "2011-05-17 16:33:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70527071612452864",
  "text" : "went to bible study w MIL this am so her friend could pin my uniform to sew. wasnt as bad as I expected..lol",
  "id" : 70527071612452864,
  "created_at" : "2011-05-17 16:32:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Meyer",
      "screen_name" : "JoyceMeyer",
      "indices" : [ 3, 14 ],
      "id_str" : "15809249",
      "id" : 15809249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70465560659509248",
  "text" : "RT @JoyceMeyer: The\nworld is desperate for hope. We need to be light in a dark place. (Matthew\n5:14)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69757768990605312",
    "text" : "The\nworld is desperate for hope. We need to be light in a dark place. (Matthew\n5:14)",
    "id" : 69757768990605312,
    "created_at" : "2011-05-15 13:35:22 +0000",
    "user" : {
      "name" : "Joyce Meyer",
      "screen_name" : "JoyceMeyer",
      "protected" : false,
      "id_str" : "15809249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761690007602012160\/CpTBAjUN_normal.jpg",
      "id" : 15809249,
      "verified" : true
    }
  },
  "id" : 70465560659509248,
  "created_at" : "2011-05-17 12:27:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 0, 12 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70460338268684288",
  "geo" : { },
  "id_str" : "70462277253472256",
  "in_reply_to_user_id" : 16691399,
  "text" : "@fearfuldogs same for children. its about respecting the emotions of another being.",
  "id" : 70462277253472256,
  "in_reply_to_status_id" : 70460338268684288,
  "created_at" : "2011-05-17 12:14:50 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70461135580696577",
  "text" : "RT @fearfuldogs: never punish a dog 4 not having the skills 2 not be afraid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70460338268684288",
    "text" : "never punish a dog 4 not having the skills 2 not be afraid",
    "id" : 70460338268684288,
    "created_at" : "2011-05-17 12:07:08 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 70461135580696577,
  "created_at" : "2011-05-17 12:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    }, {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 17, 32 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70460528207724544",
  "text" : "RT @ShipsofSong: @mssuzcatsilver May the Universe never cease to surprise you with blessings.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "suzcat",
        "screen_name" : "mssuzcatsilver",
        "indices" : [ 0, 15 ],
        "id_str" : "25846336",
        "id" : 25846336
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "70449602624618496",
    "geo" : { },
    "id_str" : "70453761977483264",
    "in_reply_to_user_id" : 25846336,
    "text" : "@mssuzcatsilver May the Universe never cease to surprise you with blessings.",
    "id" : 70453761977483264,
    "in_reply_to_status_id" : 70449602624618496,
    "created_at" : "2011-05-17 11:41:00 +0000",
    "in_reply_to_screen_name" : "mssuzcatsilver",
    "in_reply_to_user_id_str" : "25846336",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 70460528207724544,
  "created_at" : "2011-05-17 12:07:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70454312551190528",
  "geo" : { },
  "id_str" : "70460394258448384",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 oh no. hope she's ok. poor thing. sending well wishes!",
  "id" : 70460394258448384,
  "in_reply_to_status_id" : 70454312551190528,
  "created_at" : "2011-05-17 12:07:21 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70459647500353537",
  "text" : "I did NOT break my board last night. But my kick has improved, my form was great and my spar wasnt too bad!",
  "id" : 70459647500353537,
  "created_at" : "2011-05-17 12:04:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70294585900933120",
  "text" : "perhaps I am gaining more control over my mind. I did a good job at testing tonight.",
  "id" : 70294585900933120,
  "created_at" : "2011-05-17 01:08:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70198455267639296",
  "text" : "RT @worldtreeman: the government seems very selective in which countries it bombs to 'help civilians'..maybe something to do with oil... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70197906296156160",
    "text" : "the government seems very selective in which countries it bombs to 'help civilians'..maybe something to do with oil...oh no..not again!!",
    "id" : 70197906296156160,
    "created_at" : "2011-05-16 18:44:19 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 70198455267639296,
  "created_at" : "2011-05-16 18:46:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70198261503377408",
  "text" : "forgot my pill this am. head is funky.. and I got testing tonight. blah!",
  "id" : 70198261503377408,
  "created_at" : "2011-05-16 18:45:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Redrum Lafferty",
      "screen_name" : "mightymur",
      "indices" : [ 0, 10 ],
      "id_str" : "3025261",
      "id" : 3025261
    }, {
      "name" : "Premium-Hosts.com",
      "screen_name" : "premhosts",
      "indices" : [ 17, 27 ],
      "id_str" : "242830330",
      "id" : 242830330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69938259094016000",
  "geo" : { },
  "id_str" : "69940419072507904",
  "in_reply_to_user_id" : 3025261,
  "text" : "@mightymur I use @premhosts http:\/\/www.premium-hosts.com\/",
  "id" : 69940419072507904,
  "in_reply_to_status_id" : 69938259094016000,
  "created_at" : "2011-05-16 01:41:09 +0000",
  "in_reply_to_screen_name" : "mightymur",
  "in_reply_to_user_id_str" : "3025261",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69921749336203264",
  "text" : "\"not everything has to be sexual to get attention\" my 16yo in response to tv comm. she's going to change the world.",
  "id" : 69921749336203264,
  "created_at" : "2011-05-16 00:26:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69909402399948800",
  "geo" : { },
  "id_str" : "69918627071135745",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH ((hugs)) to you Ani-la. I so wish you could feel better!",
  "id" : 69918627071135745,
  "in_reply_to_status_id" : 69909402399948800,
  "created_at" : "2011-05-16 00:14:34 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 3, 14 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69884116526567424",
  "text" : "RT @quantafire: Being on a mailing list I cannot unsubscribe from is kinda rude...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69880319473487872",
    "text" : "Being on a mailing list I cannot unsubscribe from is kinda rude...",
    "id" : 69880319473487872,
    "created_at" : "2011-05-15 21:42:21 +0000",
    "user" : {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "protected" : false,
      "id_str" : "8449382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2943941501\/b15b399a7823bad25f64b6482704e678_normal.jpeg",
      "id" : 8449382,
      "verified" : false
    }
  },
  "id" : 69884116526567424,
  "created_at" : "2011-05-15 21:57:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 0, 10 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69861431079735296",
  "geo" : { },
  "id_str" : "69865524082905088",
  "in_reply_to_user_id" : 62554155,
  "text" : "@ceebee308 I thought you were married... ((palmtohead)) ohhhhh...",
  "id" : 69865524082905088,
  "in_reply_to_status_id" : 69861431079735296,
  "created_at" : "2011-05-15 20:43:33 +0000",
  "in_reply_to_screen_name" : "ceebee308",
  "in_reply_to_user_id_str" : "62554155",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69853458097901568",
  "geo" : { },
  "id_str" : "69860423419183104",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad I drive w my lights on ALL the time. makes it easier for others to see me. but maybe someone local died?",
  "id" : 69860423419183104,
  "in_reply_to_status_id" : 69853458097901568,
  "created_at" : "2011-05-15 20:23:17 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Jimbo",
      "screen_name" : "NullanVoid",
      "indices" : [ 15, 26 ],
      "id_str" : "140893014",
      "id" : 140893014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69805756324642818",
  "text" : "@BibleAlsoSays @NullanVoid Nothing exists",
  "id" : 69805756324642818,
  "created_at" : "2011-05-15 16:46:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 15, 30 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69797078469062656",
  "text" : "CUTE ALERT! RT @ReformedBuddha: My cousins http:\/\/i.imgur.com\/WVAl2.jpg",
  "id" : 69797078469062656,
  "created_at" : "2011-05-15 16:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69795654779678720",
  "text" : "@ReformedBuddha OMG.. cute alert, cute alert!!",
  "id" : 69795654779678720,
  "created_at" : "2011-05-15 16:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Redrum Lafferty",
      "screen_name" : "mightymur",
      "indices" : [ 0, 10 ],
      "id_str" : "3025261",
      "id" : 3025261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69779950789599232",
  "geo" : { },
  "id_str" : "69795430145343488",
  "in_reply_to_user_id" : 3025261,
  "text" : "@mightymur I will be reading the entire series as they come out : )",
  "id" : 69795430145343488,
  "in_reply_to_status_id" : 69779950789599232,
  "created_at" : "2011-05-15 16:05:01 +0000",
  "in_reply_to_screen_name" : "mightymur",
  "in_reply_to_user_id_str" : "3025261",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69794977458290689",
  "text" : "DDs friend has neat lip balm. Its round, eggshaped. I want one! lol",
  "id" : 69794977458290689,
  "created_at" : "2011-05-15 16:03:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69794217408471040",
  "text" : "pray for me. going on field trip tomorrow w DD.",
  "id" : 69794217408471040,
  "created_at" : "2011-05-15 16:00:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 3, 13 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69793590586507264",
  "text" : "RT @RuffHaven: We have room in our home for another dog. We provide a forever home for Old dogs over 7 and dogs with special needs. Plea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69789873795633152",
    "text" : "We have room in our home for another dog. We provide a forever home for Old dogs over 7 and dogs with special needs. Please Retweet",
    "id" : 69789873795633152,
    "created_at" : "2011-05-15 15:42:57 +0000",
    "user" : {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "protected" : false,
      "id_str" : "126764612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459086546319056896\/W1rXvAEz_normal.jpeg",
      "id" : 126764612,
      "verified" : false
    }
  },
  "id" : 69793590586507264,
  "created_at" : "2011-05-15 15:57:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69788260485963776",
  "text" : "we have a fun household",
  "id" : 69788260485963776,
  "created_at" : "2011-05-15 15:36:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69787767877545984",
  "text" : "hubby chasing flying squirrel in dining room",
  "id" : 69787767877545984,
  "created_at" : "2011-05-15 15:34:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Redrum Lafferty",
      "screen_name" : "mightymur",
      "indices" : [ 24, 34 ],
      "id_str" : "3025261",
      "id" : 3025261
    }, {
      "name" : "BookLending.com",
      "screen_name" : "BookLending",
      "indices" : [ 39, 51 ],
      "id_str" : "233470432",
      "id" : 233470432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69778861306556416",
  "text" : "just lent out Heaven by @mightymur via @BookLending .. cant wait for book 2!",
  "id" : 69778861306556416,
  "created_at" : "2011-05-15 14:59:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69583161998327808",
  "geo" : { },
  "id_str" : "69592869316460545",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms immediately with my kindle",
  "id" : 69592869316460545,
  "in_reply_to_status_id" : 69583161998327808,
  "created_at" : "2011-05-15 02:40:07 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69591024447655936",
  "text" : "RT @tonyrobbins: 5yrs ago Scientists @ Univ of Alberta have found a new molecule that kills cancer cells but not healthy cells.\u2026 (cont)  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69585448514760704",
    "text" : "5yrs ago Scientists @ Univ of Alberta have found a new molecule that kills cancer cells but not healthy cells.\u2026 (cont) http:\/\/deck.ly\/~LN4Tv",
    "id" : 69585448514760704,
    "created_at" : "2011-05-15 02:10:38 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 69591024447655936,
  "created_at" : "2011-05-15 02:32:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69578804431040512",
  "text" : "@ReformedBuddha @Cjanebe yay! : )",
  "id" : 69578804431040512,
  "created_at" : "2011-05-15 01:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69547164971433985",
  "geo" : { },
  "id_str" : "69578705986527232",
  "in_reply_to_user_id" : 21929308,
  "text" : "@Rodd4Real doing a front kick. sr master says I can do it but have mental block.",
  "id" : 69578705986527232,
  "in_reply_to_status_id" : 69547164971433985,
  "created_at" : "2011-05-15 01:43:50 +0000",
  "in_reply_to_screen_name" : "ItsYaBoyRodd",
  "in_reply_to_user_id_str" : "21929308",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69536074246004737",
  "text" : "@ReformedBuddha those men hair color commercials irritate me so. keep it!",
  "id" : 69536074246004737,
  "created_at" : "2011-05-14 22:54:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jack melony",
      "screen_name" : "jackmelony",
      "indices" : [ 3, 14 ],
      "id_str" : "92596592",
      "id" : 92596592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69486187307466752",
  "text" : "RT @jackmelony: Is our Universe a Giant Nervous System? - http:\/\/lux-os.com\/y\/21j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.lux-os.com\" rel=\"nofollow\"\u003EGlobal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69386931510853632",
    "text" : "Is our Universe a Giant Nervous System? - http:\/\/lux-os.com\/y\/21j",
    "id" : 69386931510853632,
    "created_at" : "2011-05-14 13:01:48 +0000",
    "user" : {
      "name" : "jack melony",
      "screen_name" : "jackmelony",
      "protected" : false,
      "id_str" : "92596592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543806200\/jackmelony_normal.jpg",
      "id" : 92596592,
      "verified" : false
    }
  },
  "id" : 69486187307466752,
  "created_at" : "2011-05-14 19:36:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69475224898383872",
  "geo" : { },
  "id_str" : "69485310219792385",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott LOL ; )",
  "id" : 69485310219792385,
  "in_reply_to_status_id" : 69475224898383872,
  "created_at" : "2011-05-14 19:32:43 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/Ukb1hW2",
      "expanded_url" : "http:\/\/www.myaspergerschild.com\/2008\/05\/aspergers-subtypes.html?spref=tw",
      "display_url" : "myaspergerschild.com\/2008\/05\/asperg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "69484205180063744",
  "text" : "My Aspergers Child: Aspergers Subtypes\u2014 http:\/\/t.co\/Ukb1hW2",
  "id" : 69484205180063744,
  "created_at" : "2011-05-14 19:28:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69471547403927552",
  "text" : "yahoo mail beta is annoying.. sigh",
  "id" : 69471547403927552,
  "created_at" : "2011-05-14 18:38:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69471193807327232",
  "text" : "RT @morsemusings: Some get it, some don't. The end.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69471107178180608",
    "text" : "Some get it, some don't. The end.",
    "id" : 69471107178180608,
    "created_at" : "2011-05-14 18:36:17 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 69471193807327232,
  "created_at" : "2011-05-14 18:36:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69466914035998720",
  "text" : "RT @TheGodLight: There is no need to preach the word of God, sing to the hearts of people about God's love & they will hear your message.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69466191235780608",
    "text" : "There is no need to preach the word of God, sing to the hearts of people about God's love & they will hear your message.",
    "id" : 69466191235780608,
    "created_at" : "2011-05-14 18:16:45 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 69466914035998720,
  "created_at" : "2011-05-14 18:19:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69466784796901376",
  "text" : "@alexanderpwalsh lol.. forumspeak.. Dear Daughter",
  "id" : 69466784796901376,
  "created_at" : "2011-05-14 18:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69465768974221312",
  "text" : "I know my red belt form #TKD but will totally fail testing on monday as I have not YET broke my board.. sigh.. doubt it will break for test.",
  "id" : 69465768974221312,
  "created_at" : "2011-05-14 18:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Sweeney",
      "screen_name" : "SMSweeneyAuthor",
      "indices" : [ 3, 19 ],
      "id_str" : "117553357",
      "id" : 117553357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "amcrazy",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "books",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69464725322334208",
  "text" : "RT @SMSweeneyAuthor: I had a nightmare this morning.... the page turner on my #Kindle broke! I awoke in cold sweats. #amcrazy #books",
  "id" : 69464725322334208,
  "created_at" : "2011-05-14 18:10:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69457622436294656",
  "text" : "RT @BeasBookNook: The cat is curled up on my kindle. Again. I think he needs his own. :P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69455033581830144",
    "text" : "The cat is curled up on my kindle. Again. I think he needs his own. :P",
    "id" : 69455033581830144,
    "created_at" : "2011-05-14 17:32:25 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 69457622436294656,
  "created_at" : "2011-05-14 17:42:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69457381154762752",
  "text" : "RT @Wylieknowords: \"Stop animal testing--they don't know the answers.\" slogan for Threadless by Solyo (Nestor Gomez) www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69455649154674688",
    "text" : "\"Stop animal testing--they don't know the answers.\" slogan for Threadless by Solyo (Nestor Gomez) www.knowords.com",
    "id" : 69455649154674688,
    "created_at" : "2011-05-14 17:34:51 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 69457381154762752,
  "created_at" : "2011-05-14 17:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69450648785133568",
  "text" : "@alexanderpwalsh to wander, a journey.. my DDs name.",
  "id" : 69450648785133568,
  "created_at" : "2011-05-14 17:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69435330364833793",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: God calls us all to be messengers. We are anyway, whether we want to be or not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69434635590975489",
    "text" : "RT @_NealeDWalsch: God calls us all to be messengers. We are anyway, whether we want to be or not.",
    "id" : 69434635590975489,
    "created_at" : "2011-05-14 16:11:21 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 69435330364833793,
  "created_at" : "2011-05-14 16:14:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69435211976425473",
  "text" : "@helloinhere but why does the common man believe socialism is evil (ie. many christians?)",
  "id" : 69435211976425473,
  "created_at" : "2011-05-14 16:13:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69434072698601472",
  "text" : "I dont get it. Why is socialism evil?",
  "id" : 69434072698601472,
  "created_at" : "2011-05-14 16:09:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69432174247559168",
  "geo" : { },
  "id_str" : "69432726608019456",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle ((hugs)) dear. take it easy. xoxo",
  "id" : 69432726608019456,
  "in_reply_to_status_id" : 69432174247559168,
  "created_at" : "2011-05-14 16:03:46 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69430841985609729",
  "text" : "I think I understand my wives murder husbands now... ARGGGHHH!!!!!!!!!!",
  "id" : 69430841985609729,
  "created_at" : "2011-05-14 15:56:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69425395002384384",
  "text" : "RT @Jambodhi: Does God have to exist in a place? What if God is inherent in all things?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69420350718492674",
    "text" : "Does God have to exist in a place? What if God is inherent in all things?",
    "id" : 69420350718492674,
    "created_at" : "2011-05-14 15:14:36 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 69425395002384384,
  "created_at" : "2011-05-14 15:34:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69425132472516608",
  "text" : "RT @scottsigler: I'm not a fan of spam, of course, but here's my new favorite subject line of all time: \"Give your wang bulldozer power! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69422715077013505",
    "text" : "I'm not a fan of spam, of course, but here's my new favorite subject line of all time: \"Give your wang bulldozer power!\" That's good writin'",
    "id" : 69422715077013505,
    "created_at" : "2011-05-14 15:23:59 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 69425132472516608,
  "created_at" : "2011-05-14 15:33:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69419345519980544",
  "text" : "Money gone, paralyzed athlete fights to survive http:\/\/yhoo.it\/iDbYKr",
  "id" : 69419345519980544,
  "created_at" : "2011-05-14 15:10:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69413683473817600",
  "text" : "RT @GaribaldiRous: A group of kittens is called a kindle but you can't download any books on them and they don't do well in bright light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69413439080108032",
    "text" : "A group of kittens is called a kindle but you can't download any books on them and they don't do well in bright light.",
    "id" : 69413439080108032,
    "created_at" : "2011-05-14 14:47:08 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 69413683473817600,
  "created_at" : "2011-05-14 14:48:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69406392045408256",
  "text" : "RT @ceebee308: \"Top 10 Reasons why I'm disappointed the world will end on May 21, 2011\", my latest blog post. http:\/\/bit.ly\/hJW8tG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69394661369847808",
    "text" : "\"Top 10 Reasons why I'm disappointed the world will end on May 21, 2011\", my latest blog post. http:\/\/bit.ly\/hJW8tG",
    "id" : 69394661369847808,
    "created_at" : "2011-05-14 13:32:31 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 69406392045408256,
  "created_at" : "2011-05-14 14:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 0, 10 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69395079709724673",
  "geo" : { },
  "id_str" : "69406046292164609",
  "in_reply_to_user_id" : 62554155,
  "text" : "@ceebee308 good tshirt material!",
  "id" : 69406046292164609,
  "in_reply_to_status_id" : 69395079709724673,
  "created_at" : "2011-05-14 14:17:45 +0000",
  "in_reply_to_screen_name" : "ceebee308",
  "in_reply_to_user_id_str" : "62554155",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69405982312247297",
  "text" : "RT @ceebee308: Never use the phrase \u2018over my dead body\u2019 when arguing with a serial killer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69395079709724673",
    "text" : "Never use the phrase \u2018over my dead body\u2019 when arguing with a serial killer.",
    "id" : 69395079709724673,
    "created_at" : "2011-05-14 13:34:10 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 69405982312247297,
  "created_at" : "2011-05-14 14:17:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    }, {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 12, 25 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69405901425094656",
  "text" : "RT @5x5: RT @pourmecoffee: Amateur quits job, spends year traveling 60,000 miles to take 37,440 exposure panorama of night sky. http:\/\/j ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pourmecoffee",
        "screen_name" : "pourmecoffee",
        "indices" : [ 3, 16 ],
        "id_str" : "16906137",
        "id" : 16906137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69395119396241408",
    "text" : "RT @pourmecoffee: Amateur quits job, spends year traveling 60,000 miles to take 37,440 exposure panorama of night sky. http:\/\/j.mp\/lFMBRJ",
    "id" : 69395119396241408,
    "created_at" : "2011-05-14 13:34:20 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 69405901425094656,
  "created_at" : "2011-05-14 14:17:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seeyoumay22",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "rapture",
      "indices" : [ 102, 110 ]
    }, {
      "text" : "hoax",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "may21",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69405785758760961",
  "text" : "RT @Reverend_Sue: Maybe the world ended a long time ago, and all this is merely a dream. #seeyoumay22 #rapture #hoax #may21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "seeyoumay22",
        "indices" : [ 71, 83 ]
      }, {
        "text" : "rapture",
        "indices" : [ 84, 92 ]
      }, {
        "text" : "hoax",
        "indices" : [ 93, 98 ]
      }, {
        "text" : "may21",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69395322568318979",
    "text" : "Maybe the world ended a long time ago, and all this is merely a dream. #seeyoumay22 #rapture #hoax #may21",
    "id" : 69395322568318979,
    "created_at" : "2011-05-14 13:35:08 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 69405785758760961,
  "created_at" : "2011-05-14 14:16:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69395916578226176",
  "geo" : { },
  "id_str" : "69405542954713088",
  "in_reply_to_user_id" : 99910224,
  "text" : "@PaganGmaSayin phones are evil. they must be destroyed!",
  "id" : 69405542954713088,
  "in_reply_to_status_id" : 69395916578226176,
  "created_at" : "2011-05-14 14:15:45 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69404877884882944",
  "text" : "@ReformedBuddha omg... that's adorable!!",
  "id" : 69404877884882944,
  "created_at" : "2011-05-14 14:13:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 58, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69403788502503424",
  "text" : "RT @JimBrownBooks: I am positive that I remain uncertain. #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 39, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69402928221396993",
    "text" : "I am positive that I remain uncertain. #fb",
    "id" : 69402928221396993,
    "created_at" : "2011-05-14 14:05:22 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 69403788502503424,
  "created_at" : "2011-05-14 14:08:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 0, 10 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69403492695019521",
  "geo" : { },
  "id_str" : "69403719141310465",
  "in_reply_to_user_id" : 56280847,
  "text" : "@DougDorow woohoo! ; )",
  "id" : 69403719141310465,
  "in_reply_to_status_id" : 69403492695019521,
  "created_at" : "2011-05-14 14:08:30 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69215648013746176",
  "text" : "@helloinhere because the cat created it...",
  "id" : 69215648013746176,
  "created_at" : "2011-05-14 01:41:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69215076577591296",
  "text" : "RT @Emmanueldagher: One of the greatest ways to move out of judgment is to move into gratitude.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69213303284563969",
    "text" : "One of the greatest ways to move out of judgment is to move into gratitude.",
    "id" : 69213303284563969,
    "created_at" : "2011-05-14 01:31:52 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 69215076577591296,
  "created_at" : "2011-05-14 01:38:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69206507790663681",
  "text" : "RT @ShipsofSong: Do not feed the dragon for you are creating a new reality for you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69204535721197568",
    "text" : "Do not feed the dragon for you are creating a new reality for you.",
    "id" : 69204535721197568,
    "created_at" : "2011-05-14 00:57:01 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 69206507790663681,
  "created_at" : "2011-05-14 01:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69205531163762688",
  "geo" : { },
  "id_str" : "69206115254149120",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves grumble grumble...",
  "id" : 69206115254149120,
  "in_reply_to_status_id" : 69205531163762688,
  "created_at" : "2011-05-14 01:03:18 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69159310244052993",
  "geo" : { },
  "id_str" : "69164807466659840",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell waxing philosophical? I like it! (although I generally like dragons & think they get bad rap..lol) but nice point!",
  "id" : 69164807466659840,
  "in_reply_to_status_id" : 69159310244052993,
  "created_at" : "2011-05-13 22:19:09 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 0, 15 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69131603309367296",
  "text" : "@HeatherWardell omg.. im still too anal to do that..lol",
  "id" : 69131603309367296,
  "created_at" : "2011-05-13 20:07:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "indices" : [ 13, 25 ],
      "id_str" : "21833728",
      "id" : 21833728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69077852091457536",
  "geo" : { },
  "id_str" : "69078266304151552",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem @Brasilmagic wow.. what is it w these ppl?",
  "id" : 69078266304151552,
  "in_reply_to_status_id" : 69077852091457536,
  "created_at" : "2011-05-13 16:35:16 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 20, 31 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69069587890712576",
  "text" : "RT @MartijnLinssen: @moosebegab your best strength is almost always your worst weakness...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "69065352419614720",
    "geo" : { },
    "id_str" : "69068537838313472",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab your best strength is almost always your worst weakness...",
    "id" : 69068537838313472,
    "in_reply_to_status_id" : 69065352419614720,
    "created_at" : "2011-05-13 15:56:37 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 69069587890712576,
  "created_at" : "2011-05-13 16:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69066844031557632",
  "geo" : { },
  "id_str" : "69069431921328128",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell ((hugs)) I like you, too!",
  "id" : 69069431921328128,
  "in_reply_to_status_id" : 69066844031557632,
  "created_at" : "2011-05-13 16:00:10 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69066636266713089",
  "text" : "RT @parkstepp: \"Give up defining yourself - to yourself or to others. You won\u2019t die. You will come to life. And don\u2019t...\" http:\/\/tumblr. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69065720654331904",
    "text" : "\"Give up defining yourself - to yourself or to others. You won\u2019t die. You will come to life. And don\u2019t...\" http:\/\/tumblr.com\/xjw2i5tliv",
    "id" : 69065720654331904,
    "created_at" : "2011-05-13 15:45:25 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 69066636266713089,
  "created_at" : "2011-05-13 15:49:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "John Ziemba",
      "screen_name" : "JohnZiemba",
      "indices" : [ 13, 24 ],
      "id_str" : "21263442",
      "id" : 21263442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69065421353000960",
  "geo" : { },
  "id_str" : "69066406859251712",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell @JohnZiemba Im sure many think same of me..HA! lol",
  "id" : 69066406859251712,
  "in_reply_to_status_id" : 69065421353000960,
  "created_at" : "2011-05-13 15:48:09 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69066268476575744",
  "text" : "RT @JohnCali: If there's ANYTHING you want to change in your experience, IMAGINE it changed. ~ The Universe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69065859682938880",
    "text" : "If there's ANYTHING you want to change in your experience, IMAGINE it changed. ~ The Universe",
    "id" : 69065859682938880,
    "created_at" : "2011-05-13 15:45:58 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 69066268476575744,
  "created_at" : "2011-05-13 15:47:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69066256036282368",
  "text" : "RT @JohnCali: A million people could be pushing against you and it would not negatively affect you unless you push back. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69065808671805440",
    "text" : "A million people could be pushing against you and it would not negatively affect you unless you push back. ~ Abraham",
    "id" : 69065808671805440,
    "created_at" : "2011-05-13 15:45:46 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 69066256036282368,
  "created_at" : "2011-05-13 15:47:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69065352419614720",
  "text" : "the reasons ppl like me are the same reasons ppl dislike me...",
  "id" : 69065352419614720,
  "created_at" : "2011-05-13 15:43:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 32, 45 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69059352882982912",
  "text" : "Im afraid to turn on my wifi\/3G @AmazonKindle I've loaded up on freebies that will auto-download. Plz change in future firmware. Thx!",
  "id" : 69059352882982912,
  "created_at" : "2011-05-13 15:20:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69051769400995841",
  "text" : "RT @Matth3ous: Placebos Are Getting More Effective. Drugmakers Are Desperate to Know Why. - (via Instapaper) http:\/\/tumblr.com\/xsk2i53xu4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69048800358039552",
    "text" : "Placebos Are Getting More Effective. Drugmakers Are Desperate to Know Why. - (via Instapaper) http:\/\/tumblr.com\/xsk2i53xu4",
    "id" : 69048800358039552,
    "created_at" : "2011-05-13 14:38:11 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 69051769400995841,
  "created_at" : "2011-05-13 14:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 34, 45 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69041404759912449",
  "text" : "Happy Birthday to a wonderful gal @mimismutts ((hugs))",
  "id" : 69041404759912449,
  "created_at" : "2011-05-13 14:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridayreads",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69040247647899648",
  "text" : "RT @TyrusBooks: Is there anybody that needs a little something new to read for #fridayreads Maybe a bright and shiny new ebook? I might  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fridayreads",
        "indices" : [ 63, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69039876716232704",
    "text" : "Is there anybody that needs a little something new to read for #fridayreads Maybe a bright and shiny new ebook? I might be able to help.",
    "id" : 69039876716232704,
    "created_at" : "2011-05-13 14:02:43 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 69040247647899648,
  "created_at" : "2011-05-13 14:04:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Beck",
      "screen_name" : "TheKevinBeck",
      "indices" : [ 0, 13 ],
      "id_str" : "299086582",
      "id" : 299086582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69025869917732864",
  "geo" : { },
  "id_str" : "69031745386852352",
  "in_reply_to_user_id" : 21812702,
  "text" : "@TheKevinBeck your today is my yesterday.",
  "id" : 69031745386852352,
  "in_reply_to_status_id" : 69025869917732864,
  "created_at" : "2011-05-13 13:30:25 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69031306046091264",
  "text" : "RT @Reverend_Sue: If you think Friday the 13th is unlucky then it will be. YOU have the power to change your thinking. Ignore the negati ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69027946828021761",
    "text" : "If you think Friday the 13th is unlucky then it will be. YOU have the power to change your thinking. Ignore the negativity. See what happens",
    "id" : 69027946828021761,
    "created_at" : "2011-05-13 13:15:19 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 69031306046091264,
  "created_at" : "2011-05-13 13:28:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 0, 10 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68858394810920960",
  "geo" : { },
  "id_str" : "69030726942724096",
  "in_reply_to_user_id" : 14959952,
  "text" : "@parkstepp I wish I knew the book that is shown.. http:\/\/www.livebeyondtheedge.com",
  "id" : 69030726942724096,
  "in_reply_to_status_id" : 68858394810920960,
  "created_at" : "2011-05-13 13:26:22 +0000",
  "in_reply_to_screen_name" : "parkstepp",
  "in_reply_to_user_id_str" : "14959952",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69028169952399362",
  "text" : "RT @BayBitch: Happy Friday the 13th everyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69024654773329920",
    "text" : "Happy Friday the 13th everyone.",
    "id" : 69024654773329920,
    "created_at" : "2011-05-13 13:02:14 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 69028169952399362,
  "created_at" : "2011-05-13 13:16:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thrillers",
      "indices" : [ 53, 63 ]
    }, {
      "text" : "amreading",
      "indices" : [ 117, 127 ]
    }, {
      "text" : "books",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/KciojYN",
      "expanded_url" : "http:\/\/www.jennascribbles.com\/books\/medical-thrillers\/",
      "display_url" : "jennascribbles.com\/books\/medical-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "69028102977765377",
  "text" : "RT @JAScribbles: Time to read a good, creepy medical #thrillers http:\/\/t.co\/KciojYN Well, maybe not me. Too chicken. #amreading #books",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thrillers",
        "indices" : [ 36, 46 ]
      }, {
        "text" : "amreading",
        "indices" : [ 100, 110 ]
      }, {
        "text" : "books",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 66 ],
        "url" : "http:\/\/t.co\/KciojYN",
        "expanded_url" : "http:\/\/www.jennascribbles.com\/books\/medical-thrillers\/",
        "display_url" : "jennascribbles.com\/books\/medical-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "69024784347959296",
    "text" : "Time to read a good, creepy medical #thrillers http:\/\/t.co\/KciojYN Well, maybe not me. Too chicken. #amreading #books",
    "id" : 69024784347959296,
    "created_at" : "2011-05-13 13:02:45 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 69028102977765377,
  "created_at" : "2011-05-13 13:15:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68852895113691136",
  "text" : "RT @FreeRangeKids: Big controversy: Pastor defends his church forbidding teen boys to help toddlers, or men to change diapers. http:\/\/bi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68849374050000896",
    "text" : "Big controversy: Pastor defends his church forbidding teen boys to help toddlers, or men to change diapers. http:\/\/bit.ly\/kjW9WF",
    "id" : 68849374050000896,
    "created_at" : "2011-05-13 01:25:44 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 68852895113691136,
  "created_at" : "2011-05-13 01:39:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68833877044625408",
  "geo" : { },
  "id_str" : "68852011990388736",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 as a kid, our newfy knocked my mom's knee out of joint.",
  "id" : 68852011990388736,
  "in_reply_to_status_id" : 68833877044625408,
  "created_at" : "2011-05-13 01:36:13 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68780391191945216",
  "text" : "@Skandhasattva you've got a lot of tattoos! cute pup!",
  "id" : 68780391191945216,
  "created_at" : "2011-05-12 20:51:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moses Siregar III",
      "screen_name" : "MosesSiregar",
      "indices" : [ 3, 16 ],
      "id_str" : "74553176",
      "id" : 74553176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "Nook",
      "indices" : [ 40, 45 ]
    }, {
      "text" : "Ebook",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68760536044675072",
  "text" : "RT @MosesSiregar: Win a Free #Kindle 3, #Nook, or $100 Gift Card \/ Free Epic Fantasy #Ebook \/ Charitable Giveaway http:\/\/bit.ly\/jl1dwC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 11, 18 ]
      }, {
        "text" : "Nook",
        "indices" : [ 22, 27 ]
      }, {
        "text" : "Ebook",
        "indices" : [ 67, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68711575996997632",
    "text" : "Win a Free #Kindle 3, #Nook, or $100 Gift Card \/ Free Epic Fantasy #Ebook \/ Charitable Giveaway http:\/\/bit.ly\/jl1dwC",
    "id" : 68711575996997632,
    "created_at" : "2011-05-12 16:18:10 +0000",
    "user" : {
      "name" : "Moses Siregar III",
      "screen_name" : "MosesSiregar",
      "protected" : false,
      "id_str" : "74553176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471438585179017217\/kvrk13Io_normal.png",
      "id" : 74553176,
      "verified" : false
    }
  },
  "id" : 68760536044675072,
  "created_at" : "2011-05-12 19:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68753058447888384",
  "text" : "RT @CharlesBivona: Imagine carrying a bag of worthless shit on your back for 5 years. You thought you had to. Then finally you realized- ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "poem",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68750743208861696",
    "text" : "Imagine carrying a bag of worthless shit on your back for 5 years. You thought you had to. Then finally you realized--and dropped it. #poem",
    "id" : 68750743208861696,
    "created_at" : "2011-05-12 18:53:49 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 68753058447888384,
  "created_at" : "2011-05-12 19:03:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68751287755350016",
  "geo" : { },
  "id_str" : "68752894438023169",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous gentle ((hug))",
  "id" : 68752894438023169,
  "in_reply_to_status_id" : 68751287755350016,
  "created_at" : "2011-05-12 19:02:22 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68737722986143744",
  "text" : "my sister chose a beautiful mahogany box for mommy. it's stunning! mommy would be VERY pleased : )",
  "id" : 68737722986143744,
  "created_at" : "2011-05-12 18:02:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68735350364844032",
  "text" : "RT @MartijnLinssen: They are having sex right outside our door! http:\/\/twitpic.com\/4wprme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68735100032008192",
    "text" : "They are having sex right outside our door! http:\/\/twitpic.com\/4wprme",
    "id" : 68735100032008192,
    "created_at" : "2011-05-12 17:51:39 +0000",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 68735350364844032,
  "created_at" : "2011-05-12 17:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68482948843847680",
  "geo" : { },
  "id_str" : "68484158376255488",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle glad yr home safe ((hugs))",
  "id" : 68484158376255488,
  "in_reply_to_status_id" : 68482948843847680,
  "created_at" : "2011-05-12 01:14:30 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68432473146654720",
  "text" : "RT @ABennettBooks: Authors, advertise your book on my blog! See my blog sidebar for more info.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68417882870124544",
    "text" : "Authors, advertise your book on my blog! See my blog sidebar for more info.",
    "id" : 68417882870124544,
    "created_at" : "2011-05-11 20:51:09 +0000",
    "user" : {
      "name" : "Alex @ ER",
      "screen_name" : "ElectrifyingRvw",
      "protected" : false,
      "id_str" : "126983294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548891848790401024\/qalxb9Y-_normal.png",
      "id" : 126983294,
      "verified" : false
    }
  },
  "id" : 68432473146654720,
  "created_at" : "2011-05-11 21:49:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68414274623647744",
  "geo" : { },
  "id_str" : "68415971970400256",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott hehe.. I will! : )",
  "id" : 68415971970400256,
  "in_reply_to_status_id" : 68414274623647744,
  "created_at" : "2011-05-11 20:43:33 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68382306905231360",
  "text" : "any psychic ppl out there want to check on my mom for me?",
  "id" : 68382306905231360,
  "created_at" : "2011-05-11 18:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68370189397393408",
  "geo" : { },
  "id_str" : "68381258819960832",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad nice to see you happy. would like to see more often! : )",
  "id" : 68381258819960832,
  "in_reply_to_status_id" : 68370189397393408,
  "created_at" : "2011-05-11 18:25:37 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68380260747579392",
  "text" : "RT @abe_quotes: You don't have to go back and deal with childhood issues, because those childhood issues produced a vibration (cont) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68378930129813504",
    "text" : "You don't have to go back and deal with childhood issues, because those childhood issues produced a vibration (cont) http:\/\/tl.gd\/ad8vid",
    "id" : 68378930129813504,
    "created_at" : "2011-05-11 18:16:22 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 68380260747579392,
  "created_at" : "2011-05-11 18:21:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68334900226441217",
  "text" : "RT @Buddhaworld: life is totaly meaningless, exept you give it a meaning, and even that is meaningless to anybody but you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68332172423069696",
    "text" : "life is totaly meaningless, exept you give it a meaning, and even that is meaningless to anybody but you.",
    "id" : 68332172423069696,
    "created_at" : "2011-05-11 15:10:34 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 68334900226441217,
  "created_at" : "2011-05-11 15:21:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yosemite",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68126881358168064",
  "text" : "RT @MyNatureApps: Are U a Blogger ? FREE app code to ne1 that wants to blog about our Yosemite or Sequoia National Park app  #yosemite # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "yosemite",
        "indices" : [ 107, 116 ]
      }, {
        "text" : "Sequoia",
        "indices" : [ 117, 125 ]
      }, {
        "text" : "nationalparks",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68114297686994944",
    "text" : "Are U a Blogger ? FREE app code to ne1 that wants to blog about our Yosemite or Sequoia National Park app  #yosemite #Sequoia #nationalparks",
    "id" : 68114297686994944,
    "created_at" : "2011-05-11 00:44:48 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 68126881358168064,
  "created_at" : "2011-05-11 01:34:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68126754455289859",
  "text" : "RT @sparklekaz: Instead of feeling unhappy & hostile towards your enemy, view them as your most cherished spiritual teacher: Dalai Lama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68115102469070848",
    "text" : "Instead of feeling unhappy & hostile towards your enemy, view them as your most cherished spiritual teacher: Dalai Lama",
    "id" : 68115102469070848,
    "created_at" : "2011-05-11 00:48:00 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 68126754455289859,
  "created_at" : "2011-05-11 01:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 3, 17 ],
      "id_str" : "15855422",
      "id" : 15855422
    }, {
      "name" : "Jo Lynch",
      "screen_name" : "Whimzicals",
      "indices" : [ 26, 37 ],
      "id_str" : "19811896",
      "id" : 19811896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Art",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "Animal",
      "indices" : [ 115, 122 ]
    }, {
      "text" : "Charity",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68125221667872768",
  "text" : "RT @MelodyLeaLamb: Muah!! @Whimzicals Re: You Rock!  Miniature #Art, Helping Old Dogs in Need http:\/\/bit.ly\/irg740 #Animal #Charity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jo Lynch",
        "screen_name" : "Whimzicals",
        "indices" : [ 7, 18 ],
        "id_str" : "19811896",
        "id" : 19811896
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Art",
        "indices" : [ 44, 48 ]
      }, {
        "text" : "Animal",
        "indices" : [ 96, 103 ]
      }, {
        "text" : "Charity",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68121786558066690",
    "text" : "Muah!! @Whimzicals Re: You Rock!  Miniature #Art, Helping Old Dogs in Need http:\/\/bit.ly\/irg740 #Animal #Charity",
    "id" : 68121786558066690,
    "created_at" : "2011-05-11 01:14:34 +0000",
    "user" : {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "protected" : false,
      "id_str" : "15855422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94236021\/NewPic_normal.JPG",
      "id" : 15855422,
      "verified" : false
    }
  },
  "id" : 68125221667872768,
  "created_at" : "2011-05-11 01:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68045318192766976",
  "text" : "mommy got her 1st condolence guestbook note!",
  "id" : 68045318192766976,
  "created_at" : "2011-05-10 20:10:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68042689840553986",
  "text" : "really.. profiting from death.. sigh.",
  "id" : 68042689840553986,
  "created_at" : "2011-05-10 20:00:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68038340007571456",
  "text" : "omg.. I didnt realize they charged for obits!! one paper wanted $325 .. ((faints))",
  "id" : 68038340007571456,
  "created_at" : "2011-05-10 19:42:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosy",
      "screen_name" : "SocialMediaDog",
      "indices" : [ 3, 18 ],
      "id_str" : "91713228",
      "id" : 91713228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68023346671009793",
  "text" : "RT @SocialMediaDog: Stop artist, who fatally shot a dog for a film, from creating sculpture for NY Public Library. Sign petition: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68001046257082368",
    "text" : "Stop artist, who fatally shot a dog for a film, from creating sculpture for NY Public Library. Sign petition: http:\/\/bit.ly\/mkVD03",
    "id" : 68001046257082368,
    "created_at" : "2011-05-10 17:14:47 +0000",
    "user" : {
      "name" : "Rosy",
      "screen_name" : "SocialMediaDog",
      "protected" : false,
      "id_str" : "91713228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2348235413\/ojs0nuaa5ejv30tesssa_normal.jpeg",
      "id" : 91713228,
      "verified" : false
    }
  },
  "id" : 68023346671009793,
  "created_at" : "2011-05-10 18:43:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68015825025638400",
  "text" : "we got DD 3 cards as we couldnt decide plus we got one card from dog & cat..lol.",
  "id" : 68015825025638400,
  "created_at" : "2011-05-10 18:13:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 0, 12 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68012450137640960",
  "geo" : { },
  "id_str" : "68015515087540224",
  "in_reply_to_user_id" : 890831,
  "text" : "@scottsigler aww.. give her a snuggle for me!",
  "id" : 68015515087540224,
  "in_reply_to_status_id" : 68012450137640960,
  "created_at" : "2011-05-10 18:12:17 +0000",
  "in_reply_to_screen_name" : "scottsigler",
  "in_reply_to_user_id_str" : "890831",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68015341221052416",
  "text" : "RT @scottsigler: My dog is getting so old I have to bribe her with treats, just to take her on a walk: http:\/\/www.youtube.com\/watch?v=e4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68012450137640960",
    "text" : "My dog is getting so old I have to bribe her with treats, just to take her on a walk: http:\/\/www.youtube.com\/watch?v=e43XoLuMHTM",
    "id" : 68012450137640960,
    "created_at" : "2011-05-10 18:00:06 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 68015341221052416,
  "created_at" : "2011-05-10 18:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68009058132697088",
  "geo" : { },
  "id_str" : "68009637894557697",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal ((hugs))",
  "id" : 68009637894557697,
  "in_reply_to_status_id" : 68009058132697088,
  "created_at" : "2011-05-10 17:48:55 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68002248021643264",
  "text" : "finished Heaven (The Afterlife Series) by Mur Lafferty and gave it 5 stars http:\/\/amzn.to\/mID8aT #Kindle",
  "id" : 68002248021643264,
  "created_at" : "2011-05-10 17:19:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 32, 43 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 45, 56 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67990910079729664",
  "text" : "exactly..hehe. thx! ((hugs)) RT @TrishScott: @moosebegab Your mom sounds like a fun person who lived life to the full.",
  "id" : 67990910079729664,
  "created_at" : "2011-05-10 16:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67990195571666944",
  "text" : "RT @GraveStomper: I need to say this his every once in awhile to remind folks: zombies don't live happy, fulfilled lives.  They get shov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67983176785600512",
    "text" : "I need to say this his every once in awhile to remind folks: zombies don't live happy, fulfilled lives.  They get shovels thru the head.",
    "id" : 67983176785600512,
    "created_at" : "2011-05-10 16:03:47 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 67990195571666944,
  "created_at" : "2011-05-10 16:31:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67986603737489408",
  "text" : "Valerie Sterople Star Obituary: http:\/\/bit.ly\/jxJKXZ - my mom \u2665",
  "id" : 67986603737489408,
  "created_at" : "2011-05-10 16:17:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67941008041717760",
  "text" : "today is my DD's bday. she is the light of my life!",
  "id" : 67941008041717760,
  "created_at" : "2011-05-10 13:16:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 0, 15 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67940663852924929",
  "text" : "@HeatherWardell yay! another Kindler..lol",
  "id" : 67940663852924929,
  "created_at" : "2011-05-10 13:14:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 0, 13 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67908162887491584",
  "geo" : { },
  "id_str" : "67922018720432129",
  "in_reply_to_user_id" : 45450889,
  "text" : "@Squirrely007 I cant find it online. what's it about?",
  "id" : 67922018720432129,
  "in_reply_to_status_id" : 67908162887491584,
  "created_at" : "2011-05-10 12:00:45 +0000",
  "in_reply_to_screen_name" : "Squirrely007",
  "in_reply_to_user_id_str" : "45450889",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67918991179530241",
  "text" : "RT @screek: Is Alaska's orphaned moose calf program still too weak to stand on its own? http:\/\/bit.ly\/kbKtmv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67910286505553921",
    "text" : "Is Alaska's orphaned moose calf program still too weak to stand on its own? http:\/\/bit.ly\/kbKtmv",
    "id" : 67910286505553921,
    "created_at" : "2011-05-10 11:14:08 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 67918991179530241,
  "created_at" : "2011-05-10 11:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67762934117449729",
  "text" : "RT @TheEntertainer: This is only a test.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67761989258186752",
    "text" : "This is only a test.",
    "id" : 67761989258186752,
    "created_at" : "2011-05-10 01:24:51 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 67762934117449729,
  "created_at" : "2011-05-10 01:28:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67761193753903104",
  "geo" : { },
  "id_str" : "67762728688828416",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes start backing them up using a service like tweetbackup.com or create a site and use a feeder",
  "id" : 67762728688828416,
  "in_reply_to_status_id" : 67761193753903104,
  "created_at" : "2011-05-10 01:27:48 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67760236957679616",
  "text" : "RT @stevetheseeker: Love is only as distant as you think it is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67759976755625984",
    "text" : "Love is only as distant as you think it is.",
    "id" : 67759976755625984,
    "created_at" : "2011-05-10 01:16:52 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 67760236957679616,
  "created_at" : "2011-05-10 01:17:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67757948444749824",
  "text" : "when Im feeling fragile, I imagine large angel wings embracing me, creating a safe cocoon to regenerate.",
  "id" : 67757948444749824,
  "created_at" : "2011-05-10 01:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All About Pisces",
      "screen_name" : "AllAboutPisces",
      "indices" : [ 3, 18 ],
      "id_str" : "215171428",
      "id" : 215171428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PISCES",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "TAURUS",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67747360083685377",
  "text" : "RT @AllAboutPisces: #PISCES & #TAURUS - This is not a bad connection, but the Bull can get upset with your impractical nature & the Bull ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PISCES",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "TAURUS",
        "indices" : [ 10, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67744092561489921",
    "text" : "#PISCES & #TAURUS - This is not a bad connection, but the Bull can get upset with your impractical nature & the Bull is too stubborn.",
    "id" : 67744092561489921,
    "created_at" : "2011-05-10 00:13:44 +0000",
    "user" : {
      "name" : "All About Pisces",
      "screen_name" : "AllAboutPisces",
      "protected" : false,
      "id_str" : "215171428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000666092503\/bedac5fbb2b46e3be346475f71ca61be_normal.jpeg",
      "id" : 215171428,
      "verified" : false
    }
  },
  "id" : 67747360083685377,
  "created_at" : "2011-05-10 00:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67746863977213953",
  "text" : "@Skandhasattva youre an interesting dude..lol.. I like it.",
  "id" : 67746863977213953,
  "created_at" : "2011-05-10 00:24:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67743318569795584",
  "text" : "im getting attacked by the itchies and breaking out in several spots...",
  "id" : 67743318569795584,
  "created_at" : "2011-05-10 00:10:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67724730987331584",
  "geo" : { },
  "id_str" : "67728491617067010",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth delightful!",
  "id" : 67728491617067010,
  "in_reply_to_status_id" : 67724730987331584,
  "created_at" : "2011-05-09 23:11:45 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67690800674390016",
  "text" : "havent seen carmen in a long time. hope shes ok. she kept changing her username and cant remember it. passionate young lady.",
  "id" : 67690800674390016,
  "created_at" : "2011-05-09 20:41:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67689179512963072",
  "text" : "RT @worldtreeman: as soon as we all realise we all love each other then we will be ok:)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67688512891269120",
    "text" : "as soon as we all realise we all love each other then we will be ok:)",
    "id" : 67688512891269120,
    "created_at" : "2011-05-09 20:32:53 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 67689179512963072,
  "created_at" : "2011-05-09 20:35:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67660950752333824",
  "text" : "now I have to add mom to my website. dad's already there.",
  "id" : 67660950752333824,
  "created_at" : "2011-05-09 18:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67660729255337984",
  "text" : "@Skandhasattva awww.. no you dont! lol",
  "id" : 67660729255337984,
  "created_at" : "2011-05-09 18:42:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67660216065462273",
  "text" : "obit written and sent. cant really sum up a soul within an obit but I did my best. hope mom likes it! \u2665",
  "id" : 67660216065462273,
  "created_at" : "2011-05-09 18:40:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67598867889262593",
  "text" : "you may think \"why is she tweeting & not writing?\" its cuz ideas are marinating!",
  "id" : 67598867889262593,
  "created_at" : "2011-05-09 14:36:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 0, 16 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67591654021939200",
  "geo" : { },
  "id_str" : "67598311179288576",
  "in_reply_to_user_id" : 41377983,
  "text" : "@emperorsclothes thanks dear. its all good. shes free now. : )",
  "id" : 67598311179288576,
  "in_reply_to_status_id" : 67591654021939200,
  "created_at" : "2011-05-09 14:34:27 +0000",
  "in_reply_to_screen_name" : "emperorsclothes",
  "in_reply_to_user_id_str" : "41377983",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J Accornero",
      "screen_name" : "TheWaxDr",
      "indices" : [ 15, 24 ],
      "id_str" : "250347124",
      "id" : 250347124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67591538070396928",
  "text" : "@Skandhasattva @TheWaxDr why I dont diet. I really dont want to so Id be fighting the goal..",
  "id" : 67591538070396928,
  "created_at" : "2011-05-09 14:07:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67591273078456320",
  "text" : "im ok. my parents and that stubborn malamute taught me that life is for living!",
  "id" : 67591273078456320,
  "created_at" : "2011-05-09 14:06:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67585809888448512",
  "text" : "writing obit today. damn, its hard work. TOO much to say..lol",
  "id" : 67585809888448512,
  "created_at" : "2011-05-09 13:44:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67404355623596032",
  "text" : "my mommy has left the stage. i \u2665 you mommy.",
  "id" : 67404355623596032,
  "created_at" : "2011-05-09 01:43:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67376026774282240",
  "text" : "RT @Buddhaworld: what we see is what we are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67369343020826624",
    "text" : "what we see is what we are.",
    "id" : 67369343020826624,
    "created_at" : "2011-05-08 23:24:37 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 67376026774282240,
  "created_at" : "2011-05-08 23:51:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heart reflections",
      "screen_name" : "dose_of_love",
      "indices" : [ 3, 16 ],
      "id_str" : "219952715",
      "id" : 219952715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aine",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67375852773572608",
  "text" : "RT @dose_of_love: Don't look at what blocks your path, focus on the way through. ~#Aine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Aine",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67366741365370880",
    "text" : "Don't look at what blocks your path, focus on the way through. ~#Aine",
    "id" : 67366741365370880,
    "created_at" : "2011-05-08 23:14:17 +0000",
    "user" : {
      "name" : "Global Love",
      "screen_name" : "TheGlobalLove",
      "protected" : false,
      "id_str" : "73341141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666530376567955456\/p1v5dT0d_normal.jpg",
      "id" : 73341141,
      "verified" : false
    }
  },
  "id" : 67375852773572608,
  "created_at" : "2011-05-08 23:50:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67351192711344129",
  "text" : "RT @brandonrofl: You're all beautiful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67350819145654274",
    "text" : "You're all beautiful.",
    "id" : 67350819145654274,
    "created_at" : "2011-05-08 22:11:01 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 67351192711344129,
  "created_at" : "2011-05-08 22:12:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Drew University",
      "screen_name" : "DrewUniversity",
      "indices" : [ 63, 78 ],
      "id_str" : "36508339",
      "id" : 36508339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Professor",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "Blogger",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67349778597543936",
  "text" : "RT @CharlesBivona: #Professor #Blogger Collects His Thoughts | @DrewUniversity | http:\/\/bit.ly\/jr1Eex",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Drew University",
        "screen_name" : "DrewUniversity",
        "indices" : [ 44, 59 ],
        "id_str" : "36508339",
        "id" : 36508339
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Professor",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Blogger",
        "indices" : [ 11, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67335609139736576",
    "text" : "#Professor #Blogger Collects His Thoughts | @DrewUniversity | http:\/\/bit.ly\/jr1Eex",
    "id" : 67335609139736576,
    "created_at" : "2011-05-08 21:10:34 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 67349778597543936,
  "created_at" : "2011-05-08 22:06:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67294645989818369",
  "geo" : { },
  "id_str" : "67300445151965186",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms ((hugs)) happy mom day to you",
  "id" : 67300445151965186,
  "in_reply_to_status_id" : 67294645989818369,
  "created_at" : "2011-05-08 18:50:51 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67255461887475712",
  "text" : "I will not apologize for wanting lots of cash. Money = choice",
  "id" : 67255461887475712,
  "created_at" : "2011-05-08 15:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67255062837198848",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: God gave you free choice, to do with life as you will. In this sense, your will for you is God's will f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67252641729748992",
    "text" : "RT @_NealeDWalsch: God gave you free choice, to do with life as you will. In this sense, your will for you is God's will for you.",
    "id" : 67252641729748992,
    "created_at" : "2011-05-08 15:40:53 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 67255062837198848,
  "created_at" : "2011-05-08 15:50:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 17, 33 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67255021313589248",
  "text" : "RT @JohnCali: RT @DoreenVirtue444: Heed the call of you heart\u2026 and trust.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
        "screen_name" : "DoreenVirtue444",
        "indices" : [ 3, 19 ],
        "id_str" : "2813818578",
        "id" : 2813818578
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67252508812255232",
    "text" : "RT @DoreenVirtue444: Heed the call of you heart\u2026 and trust.",
    "id" : 67252508812255232,
    "created_at" : "2011-05-08 15:40:22 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 67255021313589248,
  "created_at" : "2011-05-08 15:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Dannion Brinkley",
      "screen_name" : "dannionbrinkley",
      "indices" : [ 17, 33 ],
      "id_str" : "239096732",
      "id" : 239096732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67254976044466176",
  "text" : "RT @JohnCali: RT @dannionbrinkley: Our lives will be as beautiful and abundant as we choose to imagine them. Secrets of the Light",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dannion Brinkley",
        "screen_name" : "dannionbrinkley",
        "indices" : [ 3, 19 ],
        "id_str" : "239096732",
        "id" : 239096732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67252316725706752",
    "text" : "RT @dannionbrinkley: Our lives will be as beautiful and abundant as we choose to imagine them. Secrets of the Light",
    "id" : 67252316725706752,
    "created_at" : "2011-05-08 15:39:36 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 67254976044466176,
  "created_at" : "2011-05-08 15:50:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67249130581401600",
  "text" : "darn puppetshow.. cant get it to work.. bah!",
  "id" : 67249130581401600,
  "created_at" : "2011-05-08 15:26:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "indices" : [ 3, 13 ],
      "id_str" : "14343511",
      "id" : 14343511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67034477708328960",
  "text" : "RT @lexsisney: Man quits job, travels 60,000 miles to shoot 37,000 images of the night sky, then stitches them together to create http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67031408119525376",
    "text" : "Man quits job, travels 60,000 miles to shoot 37,000 images of the night sky, then stitches them together to create http:\/\/qr.net\/bwiy. Woah.",
    "id" : 67031408119525376,
    "created_at" : "2011-05-08 01:01:47 +0000",
    "user" : {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "protected" : false,
      "id_str" : "14343511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468433962952425472\/VU87Ljmz_normal.jpeg",
      "id" : 14343511,
      "verified" : false
    }
  },
  "id" : 67034477708328960,
  "created_at" : "2011-05-08 01:13:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67028618747981825",
  "geo" : { },
  "id_str" : "67029361689231360",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth that sounds magical! : )",
  "id" : 67029361689231360,
  "in_reply_to_status_id" : 67028618747981825,
  "created_at" : "2011-05-08 00:53:39 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67026971162447872",
  "text" : "you know what I love? seeing ppl connecting in my tweet stream. warms cockles of my heart \u2665",
  "id" : 67026971162447872,
  "created_at" : "2011-05-08 00:44:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AstroJo",
      "screen_name" : "AstroJo",
      "indices" : [ 3, 11 ],
      "id_str" : "1223089292",
      "id" : 1223089292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67013438626480128",
  "text" : "RT @astrojo: Happy mothers day to all the mums- regardless of who or what you are mothering!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67011337351467008",
    "text" : "Happy mothers day to all the mums- regardless of who or what you are mothering!",
    "id" : 67011337351467008,
    "created_at" : "2011-05-07 23:42:02 +0000",
    "user" : {
      "name" : "Jo Tracey",
      "screen_name" : "jotracey_",
      "protected" : false,
      "id_str" : "30100923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678842702893477892\/4eMI4Epi_normal.jpg",
      "id" : 30100923,
      "verified" : false
    }
  },
  "id" : 67013438626480128,
  "created_at" : "2011-05-07 23:50:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Danver Gurupira",
      "screen_name" : "DanverG",
      "indices" : [ 20, 28 ],
      "id_str" : "524395397",
      "id" : 524395397
    }, {
      "name" : "Greg Howard",
      "screen_name" : "GregWHoward",
      "indices" : [ 48, 60 ],
      "id_str" : "1673120882",
      "id" : 1673120882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67008262054227968",
  "text" : "RT @mindymayhem: RT @DanVerg: If you missed it, @GregWHoward calls for the assassination of the President of the United States http:\/\/j. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Danver Gurupira",
        "screen_name" : "DanverG",
        "indices" : [ 3, 11 ],
        "id_str" : "524395397",
        "id" : 524395397
      }, {
        "name" : "Greg Howard",
        "screen_name" : "GregWHoward",
        "indices" : [ 31, 43 ],
        "id_str" : "1673120882",
        "id" : 1673120882
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 129, 134 ]
      }, {
        "text" : "ocra",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67006404904493056",
    "text" : "RT @DanVerg: If you missed it, @GregWHoward calls for the assassination of the President of the United States http:\/\/j.mp\/k3OkgV #tcot #ocra",
    "id" : 67006404904493056,
    "created_at" : "2011-05-07 23:22:26 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 67008262054227968,
  "created_at" : "2011-05-07 23:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AwesomeWolves",
      "screen_name" : "AwesomeWolves",
      "indices" : [ 3, 17 ],
      "id_str" : "162889274",
      "id" : 162889274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66996889601581056",
  "text" : "RT @AwesomeWolves: Wolves are intelligent, highly social and solve problems mostly without the use of force: http:\/\/en.wikipedia.org\/wik ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65063502297047041",
    "text" : "Wolves are intelligent, highly social and solve problems mostly without the use of force: http:\/\/en.wikipedia.org\/wiki\/Gray_wolf",
    "id" : 65063502297047041,
    "created_at" : "2011-05-02 14:42:02 +0000",
    "user" : {
      "name" : "AwesomeWolves",
      "screen_name" : "AwesomeWolves",
      "protected" : false,
      "id_str" : "162889274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1051072049\/wolf_11_normal.jpg",
      "id" : 162889274,
      "verified" : false
    }
  },
  "id" : 66996889601581056,
  "created_at" : "2011-05-07 22:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "HaywoodStubble",
      "indices" : [ 3, 18 ],
      "id_str" : "15887107",
      "id" : 15887107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66992755422924800",
  "text" : "RT @HaywoodStubble: Sigh, why is the U.S. in Libya and not in Syria, Sudan, Ivory Coast, or a dozen other \"worthy\" countries?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66987576178909184",
    "text" : "Sigh, why is the U.S. in Libya and not in Syria, Sudan, Ivory Coast, or a dozen other \"worthy\" countries?",
    "id" : 66987576178909184,
    "created_at" : "2011-05-07 22:07:37 +0000",
    "user" : {
      "name" : "Dave",
      "screen_name" : "HaywoodStubble",
      "protected" : false,
      "id_str" : "15887107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/284939831\/ScreenHunter_195_normal.jpg",
      "id" : 15887107,
      "verified" : false
    }
  },
  "id" : 66992755422924800,
  "created_at" : "2011-05-07 22:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66987752528412672",
  "geo" : { },
  "id_str" : "66992432537018369",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hey, me, too! lol",
  "id" : 66992432537018369,
  "in_reply_to_status_id" : 66987752528412672,
  "created_at" : "2011-05-07 22:26:55 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oncology",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "IntegrativeMedicine",
      "indices" : [ 99, 119 ]
    }, {
      "text" : "CAM",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "Holistic",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66983641103876097",
  "text" : "RT @AlisynGayle: I NEED AN INTEGRATIVE ONCOLOGIST! Anyone know a good one in NY\/NJ area? #Oncology #IntegrativeMedicine #CAM #Holistic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oncology",
        "indices" : [ 72, 81 ]
      }, {
        "text" : "IntegrativeMedicine",
        "indices" : [ 82, 102 ]
      }, {
        "text" : "CAM",
        "indices" : [ 103, 107 ]
      }, {
        "text" : "Holistic",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66972697942429696",
    "text" : "I NEED AN INTEGRATIVE ONCOLOGIST! Anyone know a good one in NY\/NJ area? #Oncology #IntegrativeMedicine #CAM #Holistic",
    "id" : 66972697942429696,
    "created_at" : "2011-05-07 21:08:30 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 66983641103876097,
  "created_at" : "2011-05-07 21:51:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66976615787274240",
  "geo" : { },
  "id_str" : "66983244901527552",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope very content!",
  "id" : 66983244901527552,
  "in_reply_to_status_id" : 66976615787274240,
  "created_at" : "2011-05-07 21:50:24 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66897205004472322",
  "text" : "we're already arguing.. well, F him!!",
  "id" : 66897205004472322,
  "created_at" : "2011-05-07 16:08:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66892848246689792",
  "geo" : { },
  "id_str" : "66896476860719104",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope bless you for trusting. maybe truth, maybe not but your trust adds beauty to the world.",
  "id" : 66896476860719104,
  "in_reply_to_status_id" : 66892848246689792,
  "created_at" : "2011-05-07 16:05:37 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66881814458925056",
  "text" : "it's gonna be a bad day.. hubby's cleaning.",
  "id" : 66881814458925056,
  "created_at" : "2011-05-07 15:07:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66652123227627520",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: All systems which reduce, restrict, or eliminate freedom in any way are systems which work against life ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66651695219867649",
    "text" : "RT @_NealeDWalsch: All systems which reduce, restrict, or eliminate freedom in any way are systems which work against life itself.",
    "id" : 66651695219867649,
    "created_at" : "2011-05-06 23:52:57 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 66652123227627520,
  "created_at" : "2011-05-06 23:54:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66650357870243840",
  "text" : "RT @stream_enterer: Happiness... is finding chocolate in the kitchen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66648345548046336",
    "text" : "Happiness... is finding chocolate in the kitchen.",
    "id" : 66648345548046336,
    "created_at" : "2011-05-06 23:39:38 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 66650357870243840,
  "created_at" : "2011-05-06 23:47:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Keefer",
      "screen_name" : "TheTrustNovel",
      "indices" : [ 3, 17 ],
      "id_str" : "238763865",
      "id" : 238763865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "K9",
      "indices" : [ 65, 68 ]
    }, {
      "text" : "chs",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "rescuedogs",
      "indices" : [ 105, 116 ]
    }, {
      "text" : "amwriting",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66633662376067072",
  "text" : "RT @TheTrustNovel: For every sale of The Trust $$$ are donated 2 #K9 Charities http:\/\/bit.ly\/eFSJtz #chs #rescuedogs #amwriting PLZ RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "K9",
        "indices" : [ 46, 49 ]
      }, {
        "text" : "chs",
        "indices" : [ 81, 85 ]
      }, {
        "text" : "rescuedogs",
        "indices" : [ 86, 97 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66632289165119488",
    "text" : "For every sale of The Trust $$$ are donated 2 #K9 Charities http:\/\/bit.ly\/eFSJtz #chs #rescuedogs #amwriting PLZ RT",
    "id" : 66632289165119488,
    "created_at" : "2011-05-06 22:35:50 +0000",
    "user" : {
      "name" : "Sean Keefer",
      "screen_name" : "TheTrustNovel",
      "protected" : false,
      "id_str" : "238763865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2337785334\/bwom6dtlpo2sb38qqux3_normal.jpeg",
      "id" : 238763865,
      "verified" : false
    }
  },
  "id" : 66633662376067072,
  "created_at" : "2011-05-06 22:41:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Smith",
      "screen_name" : "sowhatfaith",
      "indices" : [ 8, 20 ],
      "id_str" : "74581153",
      "id" : 74581153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66606413845250048",
  "geo" : { },
  "id_str" : "66625783493443585",
  "in_reply_to_user_id" : 74581153,
  "text" : "diverse @sowhatfaith",
  "id" : 66625783493443585,
  "in_reply_to_status_id" : 66606413845250048,
  "created_at" : "2011-05-06 22:09:59 +0000",
  "in_reply_to_screen_name" : "sowhatfaith",
  "in_reply_to_user_id_str" : "74581153",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66614639793930240",
  "text" : "RT @hvspca: We have ten new kitten strays and are desperately in need of kitten formula.  Please help!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66605426518667264",
    "text" : "We have ten new kitten strays and are desperately in need of kitten formula.  Please help!",
    "id" : 66605426518667264,
    "created_at" : "2011-05-06 20:49:05 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 66614639793930240,
  "created_at" : "2011-05-06 21:25:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66614154034819072",
  "text" : "RT @angelaharms: \"As a child who was never controlled, I don't know wht to think when ppl tweet about parents 'failing to control their  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cubey",
        "screen_name" : "CubeMelon",
        "indices" : [ 130, 140 ],
        "id_str" : "4719914581",
        "id" : 4719914581
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66608523894730752",
    "text" : "\"As a child who was never controlled, I don't know wht to think when ppl tweet about parents 'failing to control their children'\" @CubeMelon",
    "id" : 66608523894730752,
    "created_at" : "2011-05-06 21:01:24 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 66614154034819072,
  "created_at" : "2011-05-06 21:23:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66613843278835714",
  "text" : "RT @thesexyatheist: Religion in the news for May 6, 2011. http:\/\/krissthesexyatheist.blogspot.com Go for the six pack, stay for the cont ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66610329068646401",
    "text" : "Religion in the news for May 6, 2011. http:\/\/krissthesexyatheist.blogspot.com Go for the six pack, stay for the content...and the funnies.",
    "id" : 66610329068646401,
    "created_at" : "2011-05-06 21:08:34 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 66613843278835714,
  "created_at" : "2011-05-06 21:22:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66574387549184000",
  "geo" : { },
  "id_str" : "66577407410315264",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench ive seen fax service somewhere that sends fax to email...",
  "id" : 66577407410315264,
  "in_reply_to_status_id" : 66574387549184000,
  "created_at" : "2011-05-06 18:57:45 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 33, 46 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66576707968172033",
  "text" : "@tragic_pizza now you sound like @gravestomper .. LOL .. \u2665U .. keep it up!",
  "id" : 66576707968172033,
  "created_at" : "2011-05-06 18:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66564008102207488",
  "text" : "RT @JAScribbles: There are so many things I should be doing right now, but reading a good book tops them all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66563415904235521",
    "text" : "There are so many things I should be doing right now, but reading a good book tops them all.",
    "id" : 66563415904235521,
    "created_at" : "2011-05-06 18:02:09 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 66564008102207488,
  "created_at" : "2011-05-06 18:04:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ginger Mommy",
      "screen_name" : "Gingermommy",
      "indices" : [ 4, 16 ],
      "id_str" : "126764623",
      "id" : 126764623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSFTSB",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66542226272038912",
  "text" : "Hey @Gingermommy I would like to win My Dogs Life book from Chicken soup for the Soul #CSFTSB  http:\/\/tinyurl.com\/6fct4yn",
  "id" : 66542226272038912,
  "created_at" : "2011-05-06 16:37:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66507329847308288",
  "geo" : { },
  "id_str" : "66524107667279872",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles hehe.. yeah, she likes to talk a lot. It's my gift for Mothers Day..lol (I really do \u2665 her)",
  "id" : 66524107667279872,
  "in_reply_to_status_id" : 66507329847308288,
  "created_at" : "2011-05-06 15:25:57 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66510128194662400",
  "text" : "RT @adampknave: Lust, pure simply LUST: http:\/\/bit.ly\/iRt4jx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66499845912920064",
    "text" : "Lust, pure simply LUST: http:\/\/bit.ly\/iRt4jx",
    "id" : 66499845912920064,
    "created_at" : "2011-05-06 13:49:33 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 66510128194662400,
  "created_at" : "2011-05-06 14:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Balasi",
      "screen_name" : "annabalasi",
      "indices" : [ 3, 14 ],
      "id_str" : "15435656",
      "id" : 15435656
    }, {
      "name" : "Roswell UFOs",
      "screen_name" : "RoswellUFOs",
      "indices" : [ 16, 28 ],
      "id_str" : "21230981",
      "id" : 21230981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66508787154034688",
  "text" : "RT @annabalasi: @Roswellufos Interested in getting a copy of AREA 51 by Annie Jacobsen and reviewing it? http:\/\/ht.ly\/4Nfk4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roswell UFOs",
        "screen_name" : "RoswellUFOs",
        "indices" : [ 0, 12 ],
        "id_str" : "21230981",
        "id" : 21230981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65852044677873665",
    "in_reply_to_user_id" : 21230981,
    "text" : "@Roswellufos Interested in getting a copy of AREA 51 by Annie Jacobsen and reviewing it? http:\/\/ht.ly\/4Nfk4",
    "id" : 65852044677873665,
    "created_at" : "2011-05-04 18:55:25 +0000",
    "in_reply_to_screen_name" : "RoswellUFOs",
    "in_reply_to_user_id_str" : "21230981",
    "user" : {
      "name" : "Anna Balasi",
      "screen_name" : "annabalasi",
      "protected" : false,
      "id_str" : "15435656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461509107099246592\/stQgSzUD_normal.jpeg",
      "id" : 15435656,
      "verified" : false
    }
  },
  "id" : 66508787154034688,
  "created_at" : "2011-05-06 14:25:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Balasi",
      "screen_name" : "annabalasi",
      "indices" : [ 3, 14 ],
      "id_str" : "15435656",
      "id" : 15435656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66508770058055682",
  "text" : "RT @annabalasi: AREA 51. Tweet me if you want to know its secrets http:\/\/twitpic.com\/4tcox9\/full http:\/\/twitpic.com\/4tcp5n\/full",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65841745132388353",
    "text" : "AREA 51. Tweet me if you want to know its secrets http:\/\/twitpic.com\/4tcox9\/full http:\/\/twitpic.com\/4tcp5n\/full",
    "id" : 65841745132388353,
    "created_at" : "2011-05-04 18:14:29 +0000",
    "user" : {
      "name" : "Anna Balasi",
      "screen_name" : "annabalasi",
      "protected" : false,
      "id_str" : "15435656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461509107099246592\/stQgSzUD_normal.jpeg",
      "id" : 15435656,
      "verified" : false
    }
  },
  "id" : 66508770058055682,
  "created_at" : "2011-05-06 14:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Barb_Calabrese",
      "screen_name" : "Barb_Calabrese",
      "indices" : [ 3, 18 ],
      "id_str" : "26137875",
      "id" : 26137875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Love",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66505130543026176",
  "text" : "RT @Barb_Calabrese: Find the AWESOME in everything. #Love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Love",
        "indices" : [ 32, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66498424572354560",
    "text" : "Find the AWESOME in everything. #Love",
    "id" : 66498424572354560,
    "created_at" : "2011-05-06 13:43:54 +0000",
    "user" : {
      "name" : "@Barb_Calabrese",
      "screen_name" : "Barb_Calabrese",
      "protected" : false,
      "id_str" : "26137875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693088994486161408\/wN4tm7Gy_normal.jpg",
      "id" : 26137875,
      "verified" : false
    }
  },
  "id" : 66505130543026176,
  "created_at" : "2011-05-06 14:10:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66505090944602112",
  "text" : "@Tideliar im neurotic w milk. I smell it first and the least bit off, send hubby for new. He complains cuz he thinks its fine..lol",
  "id" : 66505090944602112,
  "created_at" : "2011-05-06 14:10:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66504162061455360",
  "text" : "just spent an hour on phone w MIL. good deed done for today..LOL",
  "id" : 66504162061455360,
  "created_at" : "2011-05-06 14:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66495065505275907",
  "geo" : { },
  "id_str" : "66503818627657728",
  "in_reply_to_user_id" : 18219084,
  "text" : "@byoung210 you're very welcome. I \u2665 my tweeps!",
  "id" : 66503818627657728,
  "in_reply_to_status_id" : 66495065505275907,
  "created_at" : "2011-05-06 14:05:20 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66494538620997634",
  "text" : "good morning beautiful ones",
  "id" : 66494538620997634,
  "created_at" : "2011-05-06 13:28:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 3, 14 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66494146487132160",
  "text" : "RT @quantafire: Unless you have 6 figures, please don't say you can help someone else get 6 figures...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66492561887465473",
    "text" : "Unless you have 6 figures, please don't say you can help someone else get 6 figures...",
    "id" : 66492561887465473,
    "created_at" : "2011-05-06 13:20:36 +0000",
    "user" : {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "protected" : false,
      "id_str" : "8449382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2943941501\/b15b399a7823bad25f64b6482704e678_normal.jpeg",
      "id" : 8449382,
      "verified" : false
    }
  },
  "id" : 66494146487132160,
  "created_at" : "2011-05-06 13:26:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66272049487810560",
  "geo" : { },
  "id_str" : "66273810218876928",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt she sounds awesome..lol",
  "id" : 66273810218876928,
  "in_reply_to_status_id" : 66272049487810560,
  "created_at" : "2011-05-05 22:51:22 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 15, 29 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66273415878815745",
  "text" : "im jealous! RT @ThisBlueWorld: Snuggly with my kitty (you will die of cuteness!!!) http:\/\/yfrog.com\/h8wh5xhj",
  "id" : 66273415878815745,
  "created_at" : "2011-05-05 22:49:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kej",
      "screen_name" : "Ogmin",
      "indices" : [ 13, 19 ],
      "id_str" : "18020718",
      "id" : 18020718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66248725986672640",
  "text" : "@helloinhere @Ogmin Will there be chocolate?",
  "id" : 66248725986672640,
  "created_at" : "2011-05-05 21:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66188832013434880",
  "text" : "@Skandhasattva ohh, Newfies! I've had 2 in my life \u2665",
  "id" : 66188832013434880,
  "created_at" : "2011-05-05 17:13:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66188217300422656",
  "text" : "RT @JohnCali: Violence: Years ago the first spiritual books (that is, non-religious books) I read were from Seth. Seth, I'm su... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66183993170735104",
    "text" : "Violence: Years ago the first spiritual books (that is, non-religious books) I read were from Seth. Seth, I'm su... http:\/\/bit.ly\/kOXiia",
    "id" : 66183993170735104,
    "created_at" : "2011-05-05 16:54:28 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 66188217300422656,
  "created_at" : "2011-05-05 17:11:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 40 ],
      "url" : "http:\/\/t.co\/h4f3nUu",
      "expanded_url" : "http:\/\/www.thinkgeek.com\/tshirts-apparel\/unisex\/popculture\/d3e6\/?cpg=fbl_d3e6",
      "display_url" : "thinkgeek.com\/tshirts-appare\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "66158092877959169",
  "text" : "Define \"Interesting\" http:\/\/t.co\/h4f3nUu #3 is my version..LOL",
  "id" : 66158092877959169,
  "created_at" : "2011-05-05 15:11:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66157757908271104",
  "text" : "RT @Moonrust: Handfeeding a Wasp http:\/\/www.neatorama.com\/2011\/05\/04\/handfeeding-a-wasp\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66155184346234880",
    "text" : "Handfeeding a Wasp http:\/\/www.neatorama.com\/2011\/05\/04\/handfeeding-a-wasp\/",
    "id" : 66155184346234880,
    "created_at" : "2011-05-05 14:59:59 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 66157757908271104,
  "created_at" : "2011-05-05 15:10:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poem",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66147581952135168",
  "text" : "RT @CharlesBivona: ...because this time, the Government's not lying. No, really. #poem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "poem",
        "indices" : [ 62, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66145342588063744",
    "text" : "...because this time, the Government's not lying. No, really. #poem",
    "id" : 66145342588063744,
    "created_at" : "2011-05-05 14:20:53 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 66147581952135168,
  "created_at" : "2011-05-05 14:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Azadeh Gaylord",
      "screen_name" : "AzadehG",
      "indices" : [ 19, 27 ],
      "id_str" : "3323080467",
      "id" : 3323080467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p21",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66143838581960704",
  "text" : "RT @mimismutts: RT @azadehg: THIS is the photo the White House didn't want you to see... http:\/\/bit.ly\/kM7AIR #p21 now that was funny an ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Azadeh Gaylord",
        "screen_name" : "AzadehG",
        "indices" : [ 3, 11 ],
        "id_str" : "3323080467",
        "id" : 3323080467
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p21",
        "indices" : [ 94, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66143578988097536",
    "text" : "RT @azadehg: THIS is the photo the White House didn't want you to see... http:\/\/bit.ly\/kM7AIR #p21 now that was funny and unexpected",
    "id" : 66143578988097536,
    "created_at" : "2011-05-05 14:13:52 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 66143838581960704,
  "created_at" : "2011-05-05 14:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freedom Parenting",
      "screen_name" : "FreedomParentng",
      "indices" : [ 3, 19 ],
      "id_str" : "93416715",
      "id" : 93416715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66139796627652609",
  "text" : "RT @FreedomParentng: The people that are the masters in every single field, in every case, were the rebels that didn\u2019t conform ~Abraham- ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julia Stege",
        "screen_name" : "magicalmarketer",
        "indices" : [ 124, 140 ],
        "id_str" : "14044002",
        "id" : 14044002
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66139626628317184",
    "text" : "The people that are the masters in every single field, in every case, were the rebels that didn\u2019t conform ~Abraham-Hicks RT @magicalmarketer",
    "id" : 66139626628317184,
    "created_at" : "2011-05-05 13:58:10 +0000",
    "user" : {
      "name" : "Freedom Parenting",
      "screen_name" : "FreedomParentng",
      "protected" : false,
      "id_str" : "93416715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606185156756410368\/NcnTbtXC_normal.jpg",
      "id" : 93416715,
      "verified" : false
    }
  },
  "id" : 66139796627652609,
  "created_at" : "2011-05-05 13:58:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66136261127176192",
  "geo" : { },
  "id_str" : "66138085389373440",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL muah!",
  "id" : 66138085389373440,
  "in_reply_to_status_id" : 66136261127176192,
  "created_at" : "2011-05-05 13:52:02 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66133036672098304",
  "text" : "you know whats cool? I got smacked in head 2x at sparring & it didnt bother me. Few yrs back, would have cried. ((highfiveme))",
  "id" : 66133036672098304,
  "created_at" : "2011-05-05 13:31:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominique Jones",
      "screen_name" : "the_lovegoddess",
      "indices" : [ 3, 19 ],
      "id_str" : "749062574168236033",
      "id" : 749062574168236033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66132610967019520",
  "text" : "RT @The_LoveGoddess: An open mind breeds courage. An open heart breeds wisdom.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66129272909205504",
    "text" : "An open mind breeds courage. An open heart breeds wisdom.",
    "id" : 66129272909205504,
    "created_at" : "2011-05-05 13:17:01 +0000",
    "user" : {
      "name" : "Christi",
      "screen_name" : "herlifemessage",
      "protected" : false,
      "id_str" : "171352051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601005527112486912\/k_0sye-9_normal.jpg",
      "id" : 171352051,
      "verified" : false
    }
  },
  "id" : 66132610967019520,
  "created_at" : "2011-05-05 13:30:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66129655232602112",
  "geo" : { },
  "id_str" : "66132510354055168",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver this is why I avoid news and neg ppl. too ez to get drawn into the neg & continue process.",
  "id" : 66132510354055168,
  "in_reply_to_status_id" : 66129655232602112,
  "created_at" : "2011-05-05 13:29:53 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66132158569385984",
  "text" : "RT @mssuzcatsilver: If you Tweet negative news links,pls tweet s'thing positive after as Mass consciousness can really play a big part-  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66129655232602112",
    "text" : "If you Tweet negative news links,pls tweet s'thing positive after as Mass consciousness can really play a big part- Thoughts become things",
    "id" : 66129655232602112,
    "created_at" : "2011-05-05 13:18:33 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 66132158569385984,
  "created_at" : "2011-05-05 13:28:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66132064319180800",
  "text" : "RT @ShipsofSong: There is no punishment in the universe. Consequence is the product of learning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66130095571611650",
    "text" : "There is no punishment in the universe. Consequence is the product of learning.",
    "id" : 66130095571611650,
    "created_at" : "2011-05-05 13:20:18 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 66132064319180800,
  "created_at" : "2011-05-05 13:28:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66128900081725443",
  "text" : "RT @RichardWiseman: Drove passed a sign that I thought said 'Please get ready to pay the troll'. Arrived at bridge and now disappointed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66126135410429953",
    "text" : "Drove passed a sign that I thought said 'Please get ready to pay the troll'. Arrived at bridge and now disappointed.",
    "id" : 66126135410429953,
    "created_at" : "2011-05-05 13:04:33 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 66128900081725443,
  "created_at" : "2011-05-05 13:15:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66122433446424576",
  "text" : "RT @petsalive: Need 100 more votes to win this $2600!  PLEASE VOTE FOR PETS ALIVE!  http:\/\/tinyurl.com\/3vy7dob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66121066862477312",
    "text" : "Need 100 more votes to win this $2600!  PLEASE VOTE FOR PETS ALIVE!  http:\/\/tinyurl.com\/3vy7dob",
    "id" : 66121066862477312,
    "created_at" : "2011-05-05 12:44:25 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 66122433446424576,
  "created_at" : "2011-05-05 12:49:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66118369421688832",
  "geo" : { },
  "id_str" : "66121765725814784",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulzMayBe you did wonderful. ((hugs))",
  "id" : 66121765725814784,
  "in_reply_to_status_id" : 66118369421688832,
  "created_at" : "2011-05-05 12:47:12 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66116622447947776",
  "text" : "RT @JulzMayBe: My Dad:  (looks at me) and says, \"Don't always believe everything anyone tells you.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66113899908440064",
    "text" : "My Dad:  (looks at me) and says, \"Don't always believe everything anyone tells you.\"",
    "id" : 66113899908440064,
    "created_at" : "2011-05-05 12:15:56 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 66116622447947776,
  "created_at" : "2011-05-05 12:26:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66116361943924737",
  "text" : "RT @ShipsofSong: You are only dis-empowered by that which is seen outside yourself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66114935410794496",
    "text" : "You are only dis-empowered by that which is seen outside yourself.",
    "id" : 66114935410794496,
    "created_at" : "2011-05-05 12:20:03 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 66116361943924737,
  "created_at" : "2011-05-05 12:25:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66115322163376129",
  "text" : "RT @screek: A Canada Goose Gosling http:\/\/post.ly\/1zefd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/posterous.com\" rel=\"nofollow\"\u003EPosterous\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66098827702190080",
    "text" : "A Canada Goose Gosling http:\/\/post.ly\/1zefd",
    "id" : 66098827702190080,
    "created_at" : "2011-05-05 11:16:03 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 66115322163376129,
  "created_at" : "2011-05-05 12:21:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66115200637603840",
  "text" : "@Skandhasattva Good morning. How are you?",
  "id" : 66115200637603840,
  "created_at" : "2011-05-05 12:21:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66103701491810304",
  "geo" : { },
  "id_str" : "66114584796332032",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell Good morning. Wish I was there..hehe. Getting mostly mixed days here in NY. bah.",
  "id" : 66114584796332032,
  "in_reply_to_status_id" : 66103701491810304,
  "created_at" : "2011-05-05 12:18:40 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65954853574291456",
  "text" : "Me, too RT @helloinhere: Muteness is my comfort zone.",
  "id" : 65954853574291456,
  "created_at" : "2011-05-05 01:43:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65954766433435649",
  "text" : "RT @paulocoelho: Don't make important decisions in anger:  you can always tell a person to go to hell tomorrow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65953675889221632",
    "text" : "Don't make important decisions in anger:  you can always tell a person to go to hell tomorrow",
    "id" : 65953675889221632,
    "created_at" : "2011-05-05 01:39:16 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 65954766433435649,
  "created_at" : "2011-05-05 01:43:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65950839205920768",
  "text" : "RT @DharmaTalks: Whenever we are meant to do something it should be simple and flow with ease.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65940931857235968",
    "text" : "Whenever we are meant to do something it should be simple and flow with ease.",
    "id" : 65940931857235968,
    "created_at" : "2011-05-05 00:48:37 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 65950839205920768,
  "created_at" : "2011-05-05 01:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65949866379055104",
  "text" : "RT @JosephRanseth: Our level of consciousness is based on 3 things; Our level of: perception, feeling & knowledge.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65947726113816576",
    "text" : "Our level of consciousness is based on 3 things; Our level of: perception, feeling & knowledge.",
    "id" : 65947726113816576,
    "created_at" : "2011-05-05 01:15:37 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 65949866379055104,
  "created_at" : "2011-05-05 01:24:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 7, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65949383870529536",
  "text" : "I \u2665 my #TKD family .. and I got to be Defender tonight. We're working on bullying in Leadership.",
  "id" : 65949383870529536,
  "created_at" : "2011-05-05 01:22:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65899964986966016",
  "geo" : { },
  "id_str" : "65946394002866176",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver I'll have to let these ideas marinate and the clarity will come.",
  "id" : 65946394002866176,
  "in_reply_to_status_id" : 65899964986966016,
  "created_at" : "2011-05-05 01:10:20 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65899964986966016",
  "geo" : { },
  "id_str" : "65946177144750080",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver thank you for your replies : ) my DD also gave me some info.. so combined.. I think Im seeing something..",
  "id" : 65946177144750080,
  "in_reply_to_status_id" : 65899964986966016,
  "created_at" : "2011-05-05 01:09:28 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65887991276638208",
  "text" : "RT @bunnybuddhism: The wise bunny knows we are nothing, and being nothing, we are everything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65887326810800128",
    "text" : "The wise bunny knows we are nothing, and being nothing, we are everything.",
    "id" : 65887326810800128,
    "created_at" : "2011-05-04 21:15:37 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 65887991276638208,
  "created_at" : "2011-05-04 21:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65887714351923200",
  "text" : "RT @tonyrobbins: a coincidence is nothing more than God hiding behind a cloud and smiling",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65881907396755456",
    "text" : "a coincidence is nothing more than God hiding behind a cloud and smiling",
    "id" : 65881907396755456,
    "created_at" : "2011-05-04 20:54:05 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 65887714351923200,
  "created_at" : "2011-05-04 21:17:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65872801000726529",
  "text" : "in everything RT @helloinhere: Reasonable doubt.",
  "id" : 65872801000726529,
  "created_at" : "2011-05-04 20:17:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 75, 90 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Miriam Dunn",
      "screen_name" : "Miridunn",
      "indices" : [ 91, 100 ],
      "id_str" : "33475365",
      "id" : 33475365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65870872833036288",
  "geo" : { },
  "id_str" : "65872590761234434",
  "in_reply_to_user_id" : 25846336,
  "text" : "I do believe in some conspiracies but came to conclusion, it doesnt matter @mssuzcatsilver @Miridunn",
  "id" : 65872590761234434,
  "in_reply_to_status_id" : 65870872833036288,
  "created_at" : "2011-05-04 20:17:04 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65862528122621952",
  "text" : "RT @richarddoetsch: \u265EWhat would you see if who you truly are was reflected in a mirror?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65861930866319360",
    "text" : "\u265EWhat would you see if who you truly are was reflected in a mirror?",
    "id" : 65861930866319360,
    "created_at" : "2011-05-04 19:34:42 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 65862528122621952,
  "created_at" : "2011-05-04 19:37:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65858741370753025",
  "geo" : { },
  "id_str" : "65859328359403520",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes and I like Coke because its less sweet..heehee (well and those great commercials..like to buy the world a coke..)",
  "id" : 65859328359403520,
  "in_reply_to_status_id" : 65858741370753025,
  "created_at" : "2011-05-04 19:24:22 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65856399598555138",
  "geo" : { },
  "id_str" : "65857464947572736",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes might have to unfollow then.. Im a Coke gal (when I do soda) LOL ; )",
  "id" : 65857464947572736,
  "in_reply_to_status_id" : 65856399598555138,
  "created_at" : "2011-05-04 19:16:57 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65856939061555200",
  "text" : "o-O ... Show photo as warning to others seeking America's destruction. http:\/\/bit.ly\/mvw4vs",
  "id" : 65856939061555200,
  "created_at" : "2011-05-04 19:14:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65854906002702336",
  "text" : "next testing is may 16 & I will fail again because I have not yet been able to break my board with a kick.",
  "id" : 65854906002702336,
  "created_at" : "2011-05-04 19:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 0, 15 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65852012193001472",
  "text" : "@HeatherWardell no, doesnt bother me. (I have K3)",
  "id" : 65852012193001472,
  "created_at" : "2011-05-04 18:55:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65851207117316096",
  "text" : "@helloinhere do I detect sarcasm? lol",
  "id" : 65851207117316096,
  "created_at" : "2011-05-04 18:52:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65849989804462081",
  "text" : "RT @mssuzcatsilver: And remember ...\"we see things as WE are, others see things how THEY are! \" ...Saves a damn lot of heartache if u ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "suzcat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65849175811690496",
    "text" : "And remember ...\"we see things as WE are, others see things how THEY are! \" ...Saves a damn lot of heartache if u can remember that #suzcat",
    "id" : 65849175811690496,
    "created_at" : "2011-05-04 18:44:01 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 65849989804462081,
  "created_at" : "2011-05-04 18:47:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65849673780432896",
  "text" : "RT @mssuzcatsilver: Plz try not to worry unnecessarily, as it adds more negativity to a situation (yes I knw it can be hard) focus on po ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "peace",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65848456803131392",
    "text" : "Plz try not to worry unnecessarily, as it adds more negativity to a situation (yes I knw it can be hard) focus on positivity, #love #peace",
    "id" : 65848456803131392,
    "created_at" : "2011-05-04 18:41:10 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 65849673780432896,
  "created_at" : "2011-05-04 18:46:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65847854513664000",
  "text" : "I don't believe anything anyone says.",
  "id" : 65847854513664000,
  "created_at" : "2011-05-04 18:38:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "indices" : [ 3, 10 ],
      "id_str" : "18089695",
      "id" : 18089695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65845503312674816",
  "text" : "RT @rynedp: I try to live my life by two simple rules. 1--don't be a jerk. 2--remember rule 1.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65617498132848640",
    "text" : "I try to live my life by two simple rules. 1--don't be a jerk. 2--remember rule 1.",
    "id" : 65617498132848640,
    "created_at" : "2011-05-04 03:23:25 +0000",
    "user" : {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "protected" : false,
      "id_str" : "18089695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458711316874555392\/8GSsda5g_normal.jpeg",
      "id" : 18089695,
      "verified" : false
    }
  },
  "id" : 65845503312674816,
  "created_at" : "2011-05-04 18:29:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Laube",
      "screen_name" : "TheAncientBooks",
      "indices" : [ 0, 16 ],
      "id_str" : "155754927",
      "id" : 155754927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65843857979486208",
  "geo" : { },
  "id_str" : "65845138429181953",
  "in_reply_to_user_id" : 155754927,
  "text" : "@TheAncientBooks are you feeling better now?",
  "id" : 65845138429181953,
  "in_reply_to_status_id" : 65843857979486208,
  "created_at" : "2011-05-04 18:27:59 +0000",
  "in_reply_to_screen_name" : "TheAncientBooks",
  "in_reply_to_user_id_str" : "155754927",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65832012136714240",
  "text" : "wow.. I'm feeling sassy today..LOL",
  "id" : 65832012136714240,
  "created_at" : "2011-05-04 17:35:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 42, 57 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65831181110882304",
  "text" : "oolala.. too bad Im on east coast! ; ) RT @thesexyatheist: I will be at the Whole Earth Festival this weeken\u2026 (cont) http:\/\/deck.ly\/~f42yI",
  "id" : 65831181110882304,
  "created_at" : "2011-05-04 17:32:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65829170789367808",
  "text" : "RT @byoung210: Whenever a new person likes my Facebook page, I give them a little shoutout on the wall. Give it a try! http:\/\/j.mp\/lwDOlw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65827462109601792",
    "text" : "Whenever a new person likes my Facebook page, I give them a little shoutout on the wall. Give it a try! http:\/\/j.mp\/lwDOlw",
    "id" : 65827462109601792,
    "created_at" : "2011-05-04 17:17:44 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 65829170789367808,
  "created_at" : "2011-05-04 17:24:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "photos",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65827177605763072",
  "text" : "RT @Dwayne_Reaves: Join me on my new facebook page http:\/\/on.fb.me\/mGSXNp #photography #photos",
  "id" : 65827177605763072,
  "created_at" : "2011-05-04 17:16:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65825818819043328",
  "geo" : { },
  "id_str" : "65826404893339648",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves absolutely! : )",
  "id" : 65826404893339648,
  "in_reply_to_status_id" : 65825818819043328,
  "created_at" : "2011-05-04 17:13:32 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65811073130971137",
  "geo" : { },
  "id_str" : "65826114869796864",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver http:\/\/moosebegab.tumblr.com\/post\/5190746208\/my-dream-last-night &lt;&lt;a bit more here.. yeah it was interesting!",
  "id" : 65826114869796864,
  "in_reply_to_status_id" : 65811073130971137,
  "created_at" : "2011-05-04 17:12:23 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65808960053190656",
  "text" : "@Tideliar darn! hmph..",
  "id" : 65808960053190656,
  "created_at" : "2011-05-04 16:04:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "burdr",
      "screen_name" : "burdr",
      "indices" : [ 3, 9 ],
      "id_str" : "18826472",
      "id" : 18826472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "birding",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65808787885408256",
  "text" : "RT @burdr: \"African Buffalo and Friends\" http:\/\/ow.ly\/4N4Ww #birds #birding #wildlife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 49, 55 ]
      }, {
        "text" : "birding",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65808112178835457",
    "text" : "\"African Buffalo and Friends\" http:\/\/ow.ly\/4N4Ww #birds #birding #wildlife",
    "id" : 65808112178835457,
    "created_at" : "2011-05-04 16:00:51 +0000",
    "user" : {
      "name" : "burdr",
      "screen_name" : "burdr",
      "protected" : false,
      "id_str" : "18826472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1349213818\/IMG_0448_normal.jpg",
      "id" : 18826472,
      "verified" : false
    }
  },
  "id" : 65808787885408256,
  "created_at" : "2011-05-04 16:03:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65795613144518656",
  "text" : "@Tideliar hmm.. is it recorded? sounds like a fun listening experience..lol",
  "id" : 65795613144518656,
  "created_at" : "2011-05-04 15:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Van Praagh",
      "screen_name" : "JamesVanPraagh",
      "indices" : [ 3, 18 ],
      "id_str" : "36117734",
      "id" : 36117734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65779982726729728",
  "text" : "RT @JamesVanPraagh: We always have the freedom to choose how we wish to respond to whatever life presents to us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.vanpraagh.com\" rel=\"nofollow\"\u003EJames Van Praagh\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65778087899570176",
    "text" : "We always have the freedom to choose how we wish to respond to whatever life presents to us.",
    "id" : 65778087899570176,
    "created_at" : "2011-05-04 14:01:32 +0000",
    "user" : {
      "name" : "James Van Praagh",
      "screen_name" : "JamesVanPraagh",
      "protected" : false,
      "id_str" : "36117734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531912694501097472\/0GFqd6F6_normal.jpeg",
      "id" : 36117734,
      "verified" : false
    }
  },
  "id" : 65779982726729728,
  "created_at" : "2011-05-04 14:09:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65779907745165312",
  "text" : "RT @DoreenVirtue444: You\u2019re a wise soul, and your heart is guiding you correctly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65779071107350528",
    "text" : "You\u2019re a wise soul, and your heart is guiding you correctly.",
    "id" : 65779071107350528,
    "created_at" : "2011-05-04 14:05:27 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 65779907745165312,
  "created_at" : "2011-05-04 14:08:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 59, 75 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65779071107350528",
  "geo" : { },
  "id_str" : "65779760759963648",
  "in_reply_to_user_id" : 74924273,
  "text" : "I hope so! becuz I worry if I really know what Im doing... @DoreenVirtue444",
  "id" : 65779760759963648,
  "in_reply_to_status_id" : 65779071107350528,
  "created_at" : "2011-05-04 14:08:11 +0000",
  "in_reply_to_screen_name" : "DoreenVirtue",
  "in_reply_to_user_id_str" : "74924273",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65778192140607489",
  "text" : "had a cool dream last night. involved President, school, buses, aliens (I think?).. have to remember to ask DD to look it up..lol",
  "id" : 65778192140607489,
  "created_at" : "2011-05-04 14:01:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65777597216325632",
  "text" : "RT @taraburner: Do what you can, with what you have, where you are - Theodore Roosevelt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65776582068944898",
    "text" : "Do what you can, with what you have, where you are - Theodore Roosevelt",
    "id" : 65776582068944898,
    "created_at" : "2011-05-04 13:55:33 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 65777597216325632,
  "created_at" : "2011-05-04 13:59:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "indices" : [ 3, 15 ],
      "id_str" : "27426615",
      "id" : 27426615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65777533353857024",
  "text" : "RT @DaveUrsillo: ... that positive emotions naturally give you a wider perspective, more creative thinking process and likelihood to sol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65777085834211328",
    "text" : "... that positive emotions naturally give you a wider perspective, more creative thinking process and likelihood to solve problems? Coolness",
    "id" : 65777085834211328,
    "created_at" : "2011-05-04 13:57:33 +0000",
    "user" : {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "protected" : false,
      "id_str" : "27426615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730048048202715137\/3hzFy3qT_normal.jpg",
      "id" : 27426615,
      "verified" : false
    }
  },
  "id" : 65777533353857024,
  "created_at" : "2011-05-04 13:59:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65776942749728768",
  "geo" : { },
  "id_str" : "65777405549215744",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell hehe.. how true : )",
  "id" : 65777405549215744,
  "in_reply_to_status_id" : 65776942749728768,
  "created_at" : "2011-05-04 13:58:50 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65776716278267904",
  "geo" : { },
  "id_str" : "65777112031821825",
  "in_reply_to_user_id" : 18219084,
  "text" : "YES! you got it! thats the concept I was going for..hehe @byoung210",
  "id" : 65777112031821825,
  "in_reply_to_status_id" : 65776716278267904,
  "created_at" : "2011-05-04 13:57:40 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65776211426684929",
  "text" : "I am quite fond of some ppl that I know hold quite diff views from me...",
  "id" : 65776211426684929,
  "created_at" : "2011-05-04 13:54:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65775952470360065",
  "text" : "some ppl I REALLY disagree with.. but I dont want to shut them out JUST becuz of that..lol",
  "id" : 65775952470360065,
  "created_at" : "2011-05-04 13:53:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65775521283309568",
  "text" : "some ppl I disagree with but I try not to unfollow,unfriend unless they are negative posters. Dont need negativity.",
  "id" : 65775521283309568,
  "created_at" : "2011-05-04 13:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65605043625271296",
  "text" : "good night my lovelies. I adore you. xo",
  "id" : 65605043625271296,
  "created_at" : "2011-05-04 02:33:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65603854988886018",
  "text" : "RT @parkstepp: \"If you are discouraged it is a sign of pride because it shows you trust in your own power. Your...\" http:\/\/tumblr.com\/xj ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65603601342533632",
    "text" : "\"If you are discouraged it is a sign of pride because it shows you trust in your own power. Your...\" http:\/\/tumblr.com\/xjw2dnneak",
    "id" : 65603601342533632,
    "created_at" : "2011-05-04 02:28:12 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 65603854988886018,
  "created_at" : "2011-05-04 02:29:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65601081115279360",
  "geo" : { },
  "id_str" : "65602160615899136",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves was a good day. went to food shopping.",
  "id" : 65602160615899136,
  "in_reply_to_status_id" : 65601081115279360,
  "created_at" : "2011-05-04 02:22:28 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65593933824139264",
  "geo" : { },
  "id_str" : "65600572421705728",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves oh no! Im so sorry : (",
  "id" : 65600572421705728,
  "in_reply_to_status_id" : 65593933824139264,
  "created_at" : "2011-05-04 02:16:09 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65540146359054336",
  "geo" : { },
  "id_str" : "65542146706505728",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hubbys can be arses sometimes...",
  "id" : 65542146706505728,
  "in_reply_to_status_id" : 65540146359054336,
  "created_at" : "2011-05-03 22:24:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65541948160753664",
  "text" : "@HEATHENRABBIT aww, thats sweet... : )",
  "id" : 65541948160753664,
  "created_at" : "2011-05-03 22:23:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65533177636196353",
  "geo" : { },
  "id_str" : "65538649021886465",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses well, that's rude of him!",
  "id" : 65538649021886465,
  "in_reply_to_status_id" : 65533177636196353,
  "created_at" : "2011-05-03 22:10:06 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65538486870097920",
  "text" : "@HEATHENRABBIT LOL",
  "id" : 65538486870097920,
  "created_at" : "2011-05-03 22:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 114, 127 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65433156219707392",
  "text" : "YUP! &gt;&gt; Sometimes it's the things we already know that keep us from learning anything. http:\/\/bit.ly\/ifTOEH @RichardMabry",
  "id" : 65433156219707392,
  "created_at" : "2011-05-03 15:10:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65422264866320384",
  "text" : "RT @JosephRanseth: What can you do today to make someone else have a better day?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65417376602136576",
    "text" : "What can you do today to make someone else have a better day?",
    "id" : 65417376602136576,
    "created_at" : "2011-05-03 14:08:12 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 65422264866320384,
  "created_at" : "2011-05-03 14:27:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65421173105758208",
  "text" : "RT @stream_enterer: RT @blakethegeek Wait if Satan is evil, why does he punish bad people?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65406627523727360",
    "text" : "RT @blakethegeek Wait if Satan is evil, why does he punish bad people?",
    "id" : 65406627523727360,
    "created_at" : "2011-05-03 13:25:29 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 65421173105758208,
  "created_at" : "2011-05-03 14:23:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Rogan",
      "screen_name" : "joerogan",
      "indices" : [ 3, 12 ],
      "id_str" : "18208354",
      "id" : 18208354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65420396106760193",
  "text" : "RT @joerogan: If I killed Bigfoot I would dump him in the ocean too. \"No need to keep this smelly old thing around when you've got a bul ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65411777738964992",
    "text" : "If I killed Bigfoot I would dump him in the ocean too. \"No need to keep this smelly old thing around when you've got a bulletproof story\"",
    "id" : 65411777738964992,
    "created_at" : "2011-05-03 13:45:57 +0000",
    "user" : {
      "name" : "Joe Rogan",
      "screen_name" : "joerogan",
      "protected" : false,
      "id_str" : "18208354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552307347851210752\/vrXDcTFC_normal.jpeg",
      "id" : 18208354,
      "verified" : true
    }
  },
  "id" : 65420396106760193,
  "created_at" : "2011-05-03 14:20:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 66, 74 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "ebook",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/FmnPzmW",
      "expanded_url" : "http:\/\/thefrugalereader.com\/2011\/05\/03\/qa-and-giveaway-with-victorine-e-lieske\/",
      "display_url" : "thefrugalereader.com\/2011\/05\/03\/qa-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "65416405192933376",
  "text" : "Q&A and Giveaway with Victorine E. Lieske http:\/\/t.co\/FmnPzmW via @AddThis #kindle #ebook",
  "id" : 65416405192933376,
  "created_at" : "2011-05-03 14:04:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Brink",
      "screen_name" : "jonathanbrink",
      "indices" : [ 3, 17 ],
      "id_str" : "14945944",
      "id" : 14945944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65225424858394624",
  "text" : "RT @jonathanbrink: Overheard: Sometimes I wonder if life is like Groundhog Day.  We just keep living it over until we get that we are loved.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65219925429583872",
    "text" : "Overheard: Sometimes I wonder if life is like Groundhog Day.  We just keep living it over until we get that we are loved.",
    "id" : 65219925429583872,
    "created_at" : "2011-05-03 01:03:36 +0000",
    "user" : {
      "name" : "Jonathan Brink",
      "screen_name" : "jonathanbrink",
      "protected" : false,
      "id_str" : "14945944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1143392875\/jonathan_normal.jpg",
      "id" : 14945944,
      "verified" : false
    }
  },
  "id" : 65225424858394624,
  "created_at" : "2011-05-03 01:25:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65223823615737856",
  "text" : "RT @JeremyCShipp: Could you do me a big favor and help me spread the word about my new Kindle book blog? http:\/\/dailykindlebargains.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65222794878787584",
    "text" : "Could you do me a big favor and help me spread the word about my new Kindle book blog? http:\/\/dailykindlebargains.com\/",
    "id" : 65222794878787584,
    "created_at" : "2011-05-03 01:15:00 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 65223823615737856,
  "created_at" : "2011-05-03 01:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65218163285037056",
  "text" : "@Tideliar I know what skyclad means! lol",
  "id" : 65218163285037056,
  "created_at" : "2011-05-03 00:56:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 0, 13 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65176302205931520",
  "geo" : { },
  "id_str" : "65188555646963712",
  "in_reply_to_user_id" : 42974138,
  "text" : "@GraveStomper wanted to be rich & famous. now? famous, eh.. rich? Hell, yeah! : )",
  "id" : 65188555646963712,
  "in_reply_to_status_id" : 65176302205931520,
  "created_at" : "2011-05-02 22:58:57 +0000",
  "in_reply_to_screen_name" : "GraveStomper",
  "in_reply_to_user_id_str" : "42974138",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 0, 13 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65176302205931520",
  "geo" : { },
  "id_str" : "65188244534460417",
  "in_reply_to_user_id" : 42974138,
  "text" : "@GraveStomper hmm.. animal trainer I think. Do I want to do that now? Dunno. I do like animals, tho.",
  "id" : 65188244534460417,
  "in_reply_to_status_id" : 65176302205931520,
  "created_at" : "2011-05-02 22:57:43 +0000",
  "in_reply_to_screen_name" : "GraveStomper",
  "in_reply_to_user_id_str" : "42974138",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65125817461637120",
  "text" : "@Skandhasattva did you see tattoo I posted? thought of you when I posted..lol : ) ps. not mine, tho but I do like it.",
  "id" : 65125817461637120,
  "created_at" : "2011-05-02 18:49:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 13, 26 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65124175999811585",
  "geo" : { },
  "id_str" : "65125210596188160",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem @GraveStomper no settling here! still learning to reach but def never settle : )",
  "id" : 65125210596188160,
  "in_reply_to_status_id" : 65124175999811585,
  "created_at" : "2011-05-02 18:47:14 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65108981105954818",
  "text" : "RT @GraveStomper: How do you think your life would be different if you refused to settle?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65108145013399554",
    "text" : "How do you think your life would be different if you refused to settle?",
    "id" : 65108145013399554,
    "created_at" : "2011-05-02 17:39:26 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 65108981105954818,
  "created_at" : "2011-05-02 17:42:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NVC",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65106041926459392",
  "text" : "RT @angelaharms: Turns out to be timely \"Why would I want to understand?\" by Miki Kashtan http:\/\/dld.bz\/XZ4c #NVC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NVC",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65104269300346880",
    "text" : "Turns out to be timely \"Why would I want to understand?\" by Miki Kashtan http:\/\/dld.bz\/XZ4c #NVC",
    "id" : 65104269300346880,
    "created_at" : "2011-05-02 17:24:02 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 65106041926459392,
  "created_at" : "2011-05-02 17:31:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65104600130265089",
  "text" : "interesting. been feeling good for awhile. woke up w tum a bit off. kept thinking higher. back to normal now. hmm..",
  "id" : 65104600130265089,
  "created_at" : "2011-05-02 17:25:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chas",
      "screen_name" : "LittlWing",
      "indices" : [ 3, 13 ],
      "id_str" : "23853155",
      "id" : 23853155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haikuchallenge",
      "indices" : [ 72, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65096536719241216",
  "text" : "RT @LittlWing: songless\/ fledgling failed flight-school\/ still as stone #haikuchallenge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haikuchallenge",
        "indices" : [ 57, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64343036045434880",
    "text" : "songless\/ fledgling failed flight-school\/ still as stone #haikuchallenge",
    "id" : 64343036045434880,
    "created_at" : "2011-04-30 14:59:09 +0000",
    "user" : {
      "name" : "Chas",
      "screen_name" : "LittlWing",
      "protected" : false,
      "id_str" : "23853155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1159574495\/image_normal.jpg",
      "id" : 23853155,
      "verified" : false
    }
  },
  "id" : 65096536719241216,
  "created_at" : "2011-05-02 16:53:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ancient Proverbs",
      "screen_name" : "AncientProverbs",
      "indices" : [ 3, 19 ],
      "id_str" : "226922556",
      "id" : 226922556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65096375372750848",
  "text" : "RT @AncientProverbs: It's easy to halve the potato where there's love. -Irish Proverb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64744413196333056",
    "text" : "It's easy to halve the potato where there's love. -Irish Proverb",
    "id" : 64744413196333056,
    "created_at" : "2011-05-01 17:34:05 +0000",
    "user" : {
      "name" : "Sports Motivation",
      "screen_name" : "Sports_HQ",
      "protected" : false,
      "id_str" : "139986343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2679035753\/b0d2eb7d0b01e7381bd8ca944b055f60_normal.jpeg",
      "id" : 139986343,
      "verified" : false
    }
  },
  "id" : 65096375372750848,
  "created_at" : "2011-05-02 16:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65093886703448064",
  "geo" : { },
  "id_str" : "65095564806725632",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves no, no, no!! ((draggingyouawayfromdarkside)) ((hugs))",
  "id" : 65095564806725632,
  "in_reply_to_status_id" : 65093886703448064,
  "created_at" : "2011-05-02 16:49:26 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65085302137552896",
  "geo" : { },
  "id_str" : "65092083979001856",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver I had a Henry but he was a brown tabby..lol. What is this Henry? so beautiful! I want to go thru yr books..hehe.",
  "id" : 65092083979001856,
  "in_reply_to_status_id" : 65085302137552896,
  "created_at" : "2011-05-02 16:35:36 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65091296775249920",
  "text" : "RT @JohnCali: I am the rug beneath your feet that buffers you from all the harshness of life. ~ Dog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65089331345358848",
    "text" : "I am the rug beneath your feet that buffers you from all the harshness of life. ~ Dog",
    "id" : 65089331345358848,
    "created_at" : "2011-05-02 16:24:40 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 65091296775249920,
  "created_at" : "2011-05-02 16:32:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Palmer",
      "screen_name" : "amandapalmer",
      "indices" : [ 3, 16 ],
      "id_str" : "10798802",
      "id" : 10798802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65077881189052416",
  "text" : "RT @amandapalmer: \"Hatred does not cease by hatred, but only by love; this is the eternal rule.\"\n-Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65063665954594817",
    "text" : "\"Hatred does not cease by hatred, but only by love; this is the eternal rule.\"\n-Buddha",
    "id" : 65063665954594817,
    "created_at" : "2011-05-02 14:42:41 +0000",
    "user" : {
      "name" : "Amanda Palmer",
      "screen_name" : "amandapalmer",
      "protected" : false,
      "id_str" : "10798802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510069541200617473\/OiX5QHDB_normal.jpeg",
      "id" : 10798802,
      "verified" : true
    }
  },
  "id" : 65077881189052416,
  "created_at" : "2011-05-02 15:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65076563389059073",
  "text" : "RT @JosephRanseth: We feel our best not from what we have acquired, but from what we have let go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65075955370180609",
    "text" : "We feel our best not from what we have acquired, but from what we have let go.",
    "id" : 65075955370180609,
    "created_at" : "2011-05-02 15:31:31 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 65076563389059073,
  "created_at" : "2011-05-02 15:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tattoo",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65074631563943937",
  "text" : "really neat #tattoo http:\/\/bit.ly\/iE9QEQ (fall leaves on abdomen) not mine..lol",
  "id" : 65074631563943937,
  "created_at" : "2011-05-02 15:26:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65060138867884033",
  "geo" : { },
  "id_str" : "65063464233746433",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous doesnt sound too yummy. sorry it makes you feel yukky.",
  "id" : 65063464233746433,
  "in_reply_to_status_id" : 65060138867884033,
  "created_at" : "2011-05-02 14:41:53 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Vidal",
      "screen_name" : "LauraViAu",
      "indices" : [ 3, 13 ],
      "id_str" : "489727725",
      "id" : 489727725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65062014166376448",
  "text" : "RT @lauraviau: Do I mourn the loss of a terrorist? Not really. Do I celebrate? Not exactly. Can I judge those who do either? No.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65032638301343744",
    "text" : "Do I mourn the loss of a terrorist? Not really. Do I celebrate? Not exactly. Can I judge those who do either? No.",
    "id" : 65032638301343744,
    "created_at" : "2011-05-02 12:39:23 +0000",
    "user" : {
      "name" : "Laura Viau",
      "screen_name" : "elbyviau",
      "protected" : false,
      "id_str" : "16107842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796339860726566912\/lbaEE0pD_normal.jpg",
      "id" : 16107842,
      "verified" : false
    }
  },
  "id" : 65062014166376448,
  "created_at" : "2011-05-02 14:36:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65060533409300480",
  "text" : "@Tideliar someone having a bad hair day? ; )",
  "id" : 65060533409300480,
  "created_at" : "2011-05-02 14:30:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65057026425892864",
  "geo" : { },
  "id_str" : "65059934722719744",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous is it the potassium itself that makes you feel ill? is it a pill?",
  "id" : 65059934722719744,
  "in_reply_to_status_id" : 65057026425892864,
  "created_at" : "2011-05-02 14:27:51 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64808664627818496",
  "text" : "I feel like a hot sexy mama now..hehe. Took 1st ride on motorcycle in 10+ yrs!",
  "id" : 64808664627818496,
  "created_at" : "2011-05-01 21:49:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]