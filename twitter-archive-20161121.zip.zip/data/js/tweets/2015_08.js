Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638547934485872640",
  "text" : "RT @PinarAkal1: No one saves us but ourselves.\nNo one can and no one may.\nWe ourselves must walk the path.\n\n~the Buddha http:\/\/t.co\/7gNsOpw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/638546995209216000\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/7gNsOpwVcj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyTG93XAAAqAcA.jpg",
        "id_str" : "638546995075022848",
        "id" : 638546995075022848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyTG93XAAAqAcA.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/7gNsOpwVcj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638546995209216000",
    "text" : "No one saves us but ourselves.\nNo one can and no one may.\nWe ourselves must walk the path.\n\n~the Buddha http:\/\/t.co\/7gNsOpwVcj",
    "id" : 638546995209216000,
    "created_at" : "2015-09-01 03:00:41 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 638547934485872640,
  "created_at" : "2015-09-01 03:04:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "trutherbotred",
      "screen_name" : "trutherbotred",
      "indices" : [ 3, 17 ],
      "id_str" : "264243333",
      "id" : 264243333
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/trutherbotred\/status\/638543068321312768\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/atUzc9bpNG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyPiZTVAAUi4Wk.jpg",
      "id_str" : "638543068250046469",
      "id" : 638543068250046469,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyPiZTVAAUi4Wk.jpg",
      "sizes" : [ {
        "h" : 590,
        "resize" : "fit",
        "w" : 410
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 410
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 410
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/atUzc9bpNG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638544591961104389",
  "text" : "RT @trutherbotred: http:\/\/t.co\/atUzc9bpNG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/trutherbot.com\/\" rel=\"nofollow\"\u003Etrutherbotred\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/trutherbotred\/status\/638543068321312768\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/atUzc9bpNG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyPiZTVAAUi4Wk.jpg",
        "id_str" : "638543068250046469",
        "id" : 638543068250046469,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyPiZTVAAUi4Wk.jpg",
        "sizes" : [ {
          "h" : 590,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 590,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 590,
          "resize" : "fit",
          "w" : 410
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/atUzc9bpNG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638543068321312768",
    "text" : "http:\/\/t.co\/atUzc9bpNG",
    "id" : 638543068321312768,
    "created_at" : "2015-09-01 02:45:05 +0000",
    "user" : {
      "name" : "trutherbotred",
      "screen_name" : "trutherbotred",
      "protected" : false,
      "id_str" : "264243333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677993472406630400\/1hN87Jsd_normal.png",
      "id" : 264243333,
      "verified" : false
    }
  },
  "id" : 638544591961104389,
  "created_at" : "2015-09-01 02:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/hI1WoJ6GWX",
      "expanded_url" : "https:\/\/instagram.com\/p\/7EgDM1BH8P\/",
      "display_url" : "instagram.com\/p\/7EgDM1BH8P\/"
    } ]
  },
  "geo" : { },
  "id_str" : "638534234047688704",
  "text" : "RT @ducksandclucks: Danny girl had a lot to share with me when I got home. https:\/\/t.co\/hI1WoJ6GWX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/hI1WoJ6GWX",
        "expanded_url" : "https:\/\/instagram.com\/p\/7EgDM1BH8P\/",
        "display_url" : "instagram.com\/p\/7EgDM1BH8P\/"
      } ]
    },
    "geo" : { },
    "id_str" : "638530808450543616",
    "text" : "Danny girl had a lot to share with me when I got home. https:\/\/t.co\/hI1WoJ6GWX",
    "id" : 638530808450543616,
    "created_at" : "2015-09-01 01:56:22 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 638534234047688704,
  "created_at" : "2015-09-01 02:09:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "ABC15 Arizona",
      "screen_name" : "abc15",
      "indices" : [ 53, 59 ],
      "id_str" : "9721292",
      "id" : 9721292
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/638531235061481472\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/LeivbQA9Kb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyExL1UsAAozdz.jpg",
      "id_str" : "638531227704668160",
      "id" : 638531227704668160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyExL1UsAAozdz.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LeivbQA9Kb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/638531235061481472\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/LeivbQA9Kb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyExXKVEAA_Mb_.jpg",
      "id_str" : "638531230745563136",
      "id" : 638531230745563136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyExXKVEAA_Mb_.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LeivbQA9Kb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/638531235061481472\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/LeivbQA9Kb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyExjKUYAAh29O.jpg",
      "id_str" : "638531233966743552",
      "id" : 638531233966743552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyExjKUYAAh29O.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LeivbQA9Kb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638533819176472576",
  "text" : "RT @MimiMadeira1: The sky right this minute in Tempe @abc15 http:\/\/t.co\/LeivbQA9Kb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC15 Arizona",
        "screen_name" : "abc15",
        "indices" : [ 35, 41 ],
        "id_str" : "9721292",
        "id" : 9721292
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/638531235061481472\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LeivbQA9Kb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyExL1UsAAozdz.jpg",
        "id_str" : "638531227704668160",
        "id" : 638531227704668160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyExL1UsAAozdz.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LeivbQA9Kb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/638531235061481472\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LeivbQA9Kb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyExXKVEAA_Mb_.jpg",
        "id_str" : "638531230745563136",
        "id" : 638531230745563136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyExXKVEAA_Mb_.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LeivbQA9Kb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/638531235061481472\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LeivbQA9Kb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyExjKUYAAh29O.jpg",
        "id_str" : "638531233966743552",
        "id" : 638531233966743552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyExjKUYAAh29O.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LeivbQA9Kb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638531235061481472",
    "text" : "The sky right this minute in Tempe @abc15 http:\/\/t.co\/LeivbQA9Kb",
    "id" : 638531235061481472,
    "created_at" : "2015-09-01 01:58:04 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 638533819176472576,
  "created_at" : "2015-09-01 02:08:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Reid",
      "screen_name" : "vurnt22",
      "indices" : [ 3, 11 ],
      "id_str" : "9336402",
      "id" : 9336402
    }, {
      "name" : "Bro Confessions\u2122",
      "screen_name" : "BroConfessional",
      "indices" : [ 14, 30 ],
      "id_str" : "2329424906",
      "id" : 2329424906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/g3TbFhxXRc",
      "expanded_url" : "http:\/\/vine.co\/v\/MYOlBT6T9Xb",
      "display_url" : "vine.co\/v\/MYOlBT6T9Xb"
    } ]
  },
  "geo" : { },
  "id_str" : "638461713449402368",
  "text" : "RT @vurnt22: \u201C@BroConfessional: This deserves endless retweets \uD83D\uDC4F http:\/\/t.co\/g3TbFhxXRc\u201D This Made My Night!\nRoll On Li'l Bro!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bro Confessions\u2122",
        "screen_name" : "BroConfessional",
        "indices" : [ 1, 17 ],
        "id_str" : "2329424906",
        "id" : 2329424906
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/g3TbFhxXRc",
        "expanded_url" : "http:\/\/vine.co\/v\/MYOlBT6T9Xb",
        "display_url" : "vine.co\/v\/MYOlBT6T9Xb"
      } ]
    },
    "in_reply_to_status_id_str" : "621808689830359041",
    "geo" : { },
    "id_str" : "638451073825554432",
    "in_reply_to_user_id" : 2329424906,
    "text" : "\u201C@BroConfessional: This deserves endless retweets \uD83D\uDC4F http:\/\/t.co\/g3TbFhxXRc\u201D This Made My Night!\nRoll On Li'l Bro!",
    "id" : 638451073825554432,
    "in_reply_to_status_id" : 621808689830359041,
    "created_at" : "2015-08-31 20:39:32 +0000",
    "in_reply_to_screen_name" : "BroConfessional",
    "in_reply_to_user_id_str" : "2329424906",
    "user" : {
      "name" : "Vernon Reid",
      "screen_name" : "vurnt22",
      "protected" : false,
      "id_str" : "9336402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529100419000066050\/1I10YRFk_normal.jpeg",
      "id" : 9336402,
      "verified" : false
    }
  },
  "id" : 638461713449402368,
  "created_at" : "2015-08-31 21:21:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/638126287039692801\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/1UHcELEtFM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNsUefRWcAAMW7E.jpg",
      "id_str" : "638126286225960960",
      "id" : 638126286225960960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNsUefRWcAAMW7E.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1UHcELEtFM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638458133963218944",
  "text" : "RT @BobTarte: Mr. Baby Toad, Esquire. http:\/\/t.co\/1UHcELEtFM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/638126287039692801\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/1UHcELEtFM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNsUefRWcAAMW7E.jpg",
        "id_str" : "638126286225960960",
        "id" : 638126286225960960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNsUefRWcAAMW7E.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1UHcELEtFM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638126287039692801",
    "text" : "Mr. Baby Toad, Esquire. http:\/\/t.co\/1UHcELEtFM",
    "id" : 638126287039692801,
    "created_at" : "2015-08-30 23:08:57 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 638458133963218944,
  "created_at" : "2015-08-31 21:07:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638452450819743744",
  "text" : "RT @UnseelieMe: Kayleb needed someone to talk calmly w\/him. What he got was a police officer w\/no understanding of autism. A meltdown is ne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638429607511916545",
    "text" : "Kayleb needed someone to talk calmly w\/him. What he got was a police officer w\/no understanding of autism. A meltdown is neurological.",
    "id" : 638429607511916545,
    "created_at" : "2015-08-31 19:14:14 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 638452450819743744,
  "created_at" : "2015-08-31 20:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638452109013348352",
  "text" : "RT @UnseelieMe: The fear of everyone who has a child w\/autism-an untrained person handling their kid when theyre having difficulty. #Justic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JusticeForKayleb",
        "indices" : [ 116, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638432376213929985",
    "text" : "The fear of everyone who has a child w\/autism-an untrained person handling their kid when theyre having difficulty. #JusticeForKayleb",
    "id" : 638432376213929985,
    "created_at" : "2015-08-31 19:25:14 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 638452109013348352,
  "created_at" : "2015-08-31 20:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/rr7XBjN0Ll",
      "expanded_url" : "https:\/\/twitter.com\/chiltonr\/status\/638368466588860416",
      "display_url" : "twitter.com\/chiltonr\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638451601775136768",
  "text" : "very cute! (but PSA: bread not good for ducks) https:\/\/t.co\/rr7XBjN0Ll",
  "id" : 638451601775136768,
  "created_at" : "2015-08-31 20:41:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "indices" : [ 3, 14 ],
      "id_str" : "220895419",
      "id" : 220895419
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "backtoschool",
      "indices" : [ 55, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Dw9BdKSTVP",
      "expanded_url" : "http:\/\/www.wellplated.com\/banana-oatmeal-muffins\/",
      "display_url" : "wellplated.com\/banana-oatmeal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638450911430504448",
  "text" : "RT @WellPlated: Perfect freezer-friendly breakfast for #backtoschool Blender Banana Oatmeal Muffins http:\/\/t.co\/Dw9BdKSTVP http:\/\/t.co\/Ro8S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WellPlated\/status\/638448194263883776\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Ro8SGYJcQy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNw5P9hVEAEKpg0.jpg",
        "id_str" : "638448193554944001",
        "id" : 638448193554944001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNw5P9hVEAEKpg0.jpg",
        "sizes" : [ {
          "h" : 771,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ro8SGYJcQy"
      } ],
      "hashtags" : [ {
        "text" : "backtoschool",
        "indices" : [ 39, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/Dw9BdKSTVP",
        "expanded_url" : "http:\/\/www.wellplated.com\/banana-oatmeal-muffins\/",
        "display_url" : "wellplated.com\/banana-oatmeal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638448194263883776",
    "text" : "Perfect freezer-friendly breakfast for #backtoschool Blender Banana Oatmeal Muffins http:\/\/t.co\/Dw9BdKSTVP http:\/\/t.co\/Ro8SGYJcQy",
    "id" : 638448194263883776,
    "created_at" : "2015-08-31 20:28:05 +0000",
    "user" : {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "protected" : false,
      "id_str" : "220895419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621711174824914944\/lOVoCMeS_normal.jpg",
      "id" : 220895419,
      "verified" : false
    }
  },
  "id" : 638450911430504448,
  "created_at" : "2015-08-31 20:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "indices" : [ 3, 12 ],
      "id_str" : "12642282",
      "id" : 12642282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dasparky\/status\/638449693492535296\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MnxY3zukI3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNw6nN_UwAA4SjS.jpg",
      "id_str" : "638449692624338944",
      "id" : 638449692624338944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNw6nN_UwAA4SjS.jpg",
      "sizes" : [ {
        "h" : 922,
        "resize" : "fit",
        "w" : 706
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 922,
        "resize" : "fit",
        "w" : 706
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MnxY3zukI3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638449997462249472",
  "text" : "RT @dasparky: Goose with her chew toy (re-used hay bale twine). Gorgeous blue sky beyond the porch shade curtains. http:\/\/t.co\/MnxY3zukI3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dasparky\/status\/638449693492535296\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/MnxY3zukI3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNw6nN_UwAA4SjS.jpg",
        "id_str" : "638449692624338944",
        "id" : 638449692624338944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNw6nN_UwAA4SjS.jpg",
        "sizes" : [ {
          "h" : 922,
          "resize" : "fit",
          "w" : 706
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 922,
          "resize" : "fit",
          "w" : 706
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MnxY3zukI3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638449693492535296",
    "text" : "Goose with her chew toy (re-used hay bale twine). Gorgeous blue sky beyond the porch shade curtains. http:\/\/t.co\/MnxY3zukI3",
    "id" : 638449693492535296,
    "created_at" : "2015-08-31 20:34:03 +0000",
    "user" : {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "protected" : false,
      "id_str" : "12642282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650055629004902400\/VG1lD7ep_normal.png",
      "id" : 12642282,
      "verified" : false
    }
  },
  "id" : 638449997462249472,
  "created_at" : "2015-08-31 20:35:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/638449705446457344\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/4hBn9RS2kP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNw6n5FWIAAnPfQ.jpg",
      "id_str" : "638449704192319488",
      "id" : 638449704192319488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNw6n5FWIAAnPfQ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/4hBn9RS2kP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638449868017680385",
  "text" : "RT @sarahnmoon: Homework help &lt;3 http:\/\/t.co\/4hBn9RS2kP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/638449705446457344\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/4hBn9RS2kP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNw6n5FWIAAnPfQ.jpg",
        "id_str" : "638449704192319488",
        "id" : 638449704192319488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNw6n5FWIAAnPfQ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/4hBn9RS2kP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638449705446457344",
    "text" : "Homework help &lt;3 http:\/\/t.co\/4hBn9RS2kP",
    "id" : 638449705446457344,
    "created_at" : "2015-08-31 20:34:06 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 638449868017680385,
  "created_at" : "2015-08-31 20:34:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638417945799098368",
  "geo" : { },
  "id_str" : "638418975458787328",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe lol.. glad you all survived.",
  "id" : 638418975458787328,
  "in_reply_to_status_id" : 638417945799098368,
  "created_at" : "2015-08-31 18:31:59 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/638405314652585984\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/EgVFIwFjLo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwSP0jW8AAyUly.jpg",
      "id_str" : "638405310194053120",
      "id" : 638405310194053120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwSP0jW8AAyUly.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EgVFIwFjLo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638413219648901120",
  "text" : "RT @ErinEFarley: 21 inches of hats. \uD83D\uDE04 http:\/\/t.co\/EgVFIwFjLo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/638405314652585984\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/EgVFIwFjLo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwSP0jW8AAyUly.jpg",
        "id_str" : "638405310194053120",
        "id" : 638405310194053120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwSP0jW8AAyUly.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EgVFIwFjLo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638405314652585984",
    "text" : "21 inches of hats. \uD83D\uDE04 http:\/\/t.co\/EgVFIwFjLo",
    "id" : 638405314652585984,
    "created_at" : "2015-08-31 17:37:42 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 638413219648901120,
  "created_at" : "2015-08-31 18:09:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Franklin",
      "screen_name" : "missbapple95",
      "indices" : [ 3, 16 ],
      "id_str" : "573825130",
      "id" : 573825130
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missbapple95\/status\/638397463154573312\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/S2sZPSCPW0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwLF2OWEAAZR6r.jpg",
      "id_str" : "638397442262700032",
      "id" : 638397442262700032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwLF2OWEAAZR6r.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/S2sZPSCPW0"
    } ],
    "hashtags" : [ {
      "text" : "farmersdaughter",
      "indices" : [ 85, 101 ]
    }, {
      "text" : "farmfair",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638413089168338945",
  "text" : "RT @missbapple95: Quite proud of my photo taking today! Aren't Donkeys so photogenic #farmersdaughter #farmfair http:\/\/t.co\/S2sZPSCPW0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missbapple95\/status\/638397463154573312\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/S2sZPSCPW0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwLF2OWEAAZR6r.jpg",
        "id_str" : "638397442262700032",
        "id" : 638397442262700032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwLF2OWEAAZR6r.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/S2sZPSCPW0"
      } ],
      "hashtags" : [ {
        "text" : "farmersdaughter",
        "indices" : [ 67, 83 ]
      }, {
        "text" : "farmfair",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638397463154573312",
    "text" : "Quite proud of my photo taking today! Aren't Donkeys so photogenic #farmersdaughter #farmfair http:\/\/t.co\/S2sZPSCPW0",
    "id" : 638397463154573312,
    "created_at" : "2015-08-31 17:06:30 +0000",
    "user" : {
      "name" : "Lauren Franklin",
      "screen_name" : "missbapple95",
      "protected" : false,
      "id_str" : "573825130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696729844344885248\/y1viQtLm_normal.jpg",
      "id" : 573825130,
      "verified" : false
    }
  },
  "id" : 638413089168338945,
  "created_at" : "2015-08-31 18:08:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cove Guardians",
      "screen_name" : "CoveGuardians",
      "indices" : [ 3, 17 ],
      "id_str" : "556297194",
      "id" : 556297194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638362989670871040",
  "text" : "RT @CoveGuardians: Less than 24hrs until the start of the murderous season.  CG's on the ground, ready to expose the brutal crimes #OpHenka\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpHenkaku",
        "indices" : [ 112, 122 ]
      }, {
        "text" : "tweet4taiji",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638219349568851968",
    "text" : "Less than 24hrs until the start of the murderous season.  CG's on the ground, ready to expose the brutal crimes #OpHenkaku #tweet4taiji",
    "id" : 638219349568851968,
    "created_at" : "2015-08-31 05:18:45 +0000",
    "user" : {
      "name" : "Cove Guardians",
      "screen_name" : "CoveGuardians",
      "protected" : false,
      "id_str" : "556297194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2187715195\/image_normal.jpg",
      "id" : 556297194,
      "verified" : false
    }
  },
  "id" : 638362989670871040,
  "created_at" : "2015-08-31 14:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638115068874489856",
  "geo" : { },
  "id_str" : "638116121544101888",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe maybe you should do a beer blog.. lol",
  "id" : 638116121544101888,
  "in_reply_to_status_id" : 638115068874489856,
  "created_at" : "2015-08-30 22:28:33 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638095003303153664",
  "geo" : { },
  "id_str" : "638098648627322880",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe glad you got away today : )",
  "id" : 638098648627322880,
  "in_reply_to_status_id" : 638095003303153664,
  "created_at" : "2015-08-30 21:19:07 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "indices" : [ 3, 16 ],
      "id_str" : "2213370735",
      "id" : 2213370735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638035805177540609",
  "text" : "RT @Spoonie_Life: It's been proven Doctors mostly focus on the first 3 symptoms you list. Decide ahead of time what is most important to te\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spoonie",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530127264629788672",
    "text" : "It's been proven Doctors mostly focus on the first 3 symptoms you list. Decide ahead of time what is most important to tell them #spoonie",
    "id" : 530127264629788672,
    "created_at" : "2014-11-05 22:39:23 +0000",
    "user" : {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "protected" : false,
      "id_str" : "2213370735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779756228817936384\/UfuFd2kB_normal.jpg",
      "id" : 2213370735,
      "verified" : false
    }
  },
  "id" : 638035805177540609,
  "created_at" : "2015-08-30 17:09:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/hFM0J70uN9",
      "expanded_url" : "https:\/\/twitter.com\/Spoonie_Life\/status\/567560801909612544",
      "display_url" : "twitter.com\/Spoonie_Life\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638034125090369540",
  "text" : "cc: @JourneyTheHedgi  https:\/\/t.co\/hFM0J70uN9",
  "id" : 638034125090369540,
  "created_at" : "2015-08-30 17:02:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "indices" : [ 3, 16 ],
      "id_str" : "2213370735",
      "id" : 2213370735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChronicPain",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "spoonielife",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638033754586509312",
  "text" : "RT @Spoonie_Life: Tip: Binder clips (the metal loops) make it easier to squeeze tubes of toothpaste, medicine #ChronicPain #spoonielife htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Spoonie_Life\/status\/618625886435344385\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/P7OOLm2FIw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJXM9ZzWEAAQ5YV.jpg",
        "id_str" : "618625879103639552",
        "id" : 618625879103639552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJXM9ZzWEAAQ5YV.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/P7OOLm2FIw"
      } ],
      "hashtags" : [ {
        "text" : "ChronicPain",
        "indices" : [ 92, 104 ]
      }, {
        "text" : "spoonielife",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618625886435344385",
    "text" : "Tip: Binder clips (the metal loops) make it easier to squeeze tubes of toothpaste, medicine #ChronicPain #spoonielife http:\/\/t.co\/P7OOLm2FIw",
    "id" : 618625886435344385,
    "created_at" : "2015-07-08 03:41:19 +0000",
    "user" : {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "protected" : false,
      "id_str" : "2213370735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779756228817936384\/UfuFd2kB_normal.jpg",
      "id" : 2213370735,
      "verified" : false
    }
  },
  "id" : 638033754586509312,
  "created_at" : "2015-08-30 17:01:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "indices" : [ 3, 16 ],
      "id_str" : "2213370735",
      "id" : 2213370735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XVRJr8UNvY",
      "expanded_url" : "http:\/\/gingerail.com\/2015\/08\/07\/study-shows-poor-sleep-poisons-brain-neurotoxin-buildup-mecfs-lyme-more\/",
      "display_url" : "gingerail.com\/2015\/08\/07\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638033615415328769",
  "text" : "RT @Spoonie_Life: New study shows Poor Sleep Actually Poisons the Brain - why cognitive issues are so severe\u2026 http:\/\/t.co\/XVRJr8UNvY http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Spoonie_Life\/status\/629722348615172096\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/JiVVAzI4kt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL05I3bUEAAT9P9.jpg",
        "id_str" : "629722347381985280",
        "id" : 629722347381985280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL05I3bUEAAT9P9.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JiVVAzI4kt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/XVRJr8UNvY",
        "expanded_url" : "http:\/\/gingerail.com\/2015\/08\/07\/study-shows-poor-sleep-poisons-brain-neurotoxin-buildup-mecfs-lyme-more\/",
        "display_url" : "gingerail.com\/2015\/08\/07\/stu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629722348615172096",
    "text" : "New study shows Poor Sleep Actually Poisons the Brain - why cognitive issues are so severe\u2026 http:\/\/t.co\/XVRJr8UNvY http:\/\/t.co\/JiVVAzI4kt",
    "id" : 629722348615172096,
    "created_at" : "2015-08-07 18:34:42 +0000",
    "user" : {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "protected" : false,
      "id_str" : "2213370735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779756228817936384\/UfuFd2kB_normal.jpg",
      "id" : 2213370735,
      "verified" : false
    }
  },
  "id" : 638033615415328769,
  "created_at" : "2015-08-30 17:00:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save a Spoon",
      "screen_name" : "Spoonie_Life",
      "indices" : [ 101, 114 ],
      "id_str" : "2213370735",
      "id" : 2213370735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/jsdmBo2VzP",
      "expanded_url" : "http:\/\/wp.me\/p4Cg5m-4z",
      "display_url" : "wp.me\/p4Cg5m-4z"
    } ]
  },
  "geo" : { },
  "id_str" : "638024228307136512",
  "text" : "Empty Pill Bottles Desperately Needed (Take your meds &amp; help others!) http:\/\/t.co\/jsdmBo2VzP via @Spoonie_Life",
  "id" : 638024228307136512,
  "created_at" : "2015-08-30 16:23:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ENjSVBiCjX",
      "expanded_url" : "http:\/\/disq.us\/8ogbeg",
      "display_url" : "disq.us\/8ogbeg"
    } ]
  },
  "geo" : { },
  "id_str" : "638010623717150720",
  "text" : "RT @knittingknots: Rafael Cruz, Still Lying for Jesus http:\/\/t.co\/ENjSVBiCjX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/ENjSVBiCjX",
        "expanded_url" : "http:\/\/disq.us\/8ogbeg",
        "display_url" : "disq.us\/8ogbeg"
      } ]
    },
    "geo" : { },
    "id_str" : "638007527439863808",
    "text" : "Rafael Cruz, Still Lying for Jesus http:\/\/t.co\/ENjSVBiCjX",
    "id" : 638007527439863808,
    "created_at" : "2015-08-30 15:17:02 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 638010623717150720,
  "created_at" : "2015-08-30 15:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda",
      "screen_name" : "lindasraven",
      "indices" : [ 3, 15 ],
      "id_str" : "2512480038",
      "id" : 2512480038
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lindasraven\/status\/637988269704237056\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/eG2bG80GNW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNqW8VIUkAEk32w.jpg",
      "id_str" : "637988260434710529",
      "id" : 637988260434710529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNqW8VIUkAEk32w.jpg",
      "sizes" : [ {
        "h" : 757,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 757,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/eG2bG80GNW"
    } ],
    "hashtags" : [ {
      "text" : "squirrel",
      "indices" : [ 51, 60 ]
    }, {
      "text" : "photography",
      "indices" : [ 61, 73 ]
    }, {
      "text" : "nature",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638009922391810049",
  "text" : "RT @lindasraven: Cute squirrel on my walk today \uD83D\uDE0A \n#squirrel #photography #nature #wildlife http:\/\/t.co\/eG2bG80GNW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lindasraven\/status\/637988269704237056\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/eG2bG80GNW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNqW8VIUkAEk32w.jpg",
        "id_str" : "637988260434710529",
        "id" : 637988260434710529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNqW8VIUkAEk32w.jpg",
        "sizes" : [ {
          "h" : 757,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 757,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/eG2bG80GNW"
      } ],
      "hashtags" : [ {
        "text" : "squirrel",
        "indices" : [ 34, 43 ]
      }, {
        "text" : "photography",
        "indices" : [ 44, 56 ]
      }, {
        "text" : "nature",
        "indices" : [ 57, 64 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637988269704237056",
    "text" : "Cute squirrel on my walk today \uD83D\uDE0A \n#squirrel #photography #nature #wildlife http:\/\/t.co\/eG2bG80GNW",
    "id" : 637988269704237056,
    "created_at" : "2015-08-30 14:00:31 +0000",
    "user" : {
      "name" : "Linda",
      "screen_name" : "lindasraven",
      "protected" : false,
      "id_str" : "2512480038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559387084755324929\/jP1NuQNI_normal.jpeg",
      "id" : 2512480038,
      "verified" : false
    }
  },
  "id" : 638009922391810049,
  "created_at" : "2015-08-30 15:26:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638000454841036800",
  "text" : "RT @AnnotatedBible: Are you a Christian who is Pro-Choice, Pro-Gay Rights, Pro-Equality, Pro-Evolution, Pro-Science, Pro-atheist, Pro-Musli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637855825277546497",
    "text" : "Are you a Christian who is Pro-Choice, Pro-Gay Rights, Pro-Equality, Pro-Evolution, Pro-Science, Pro-atheist, Pro-Muslim?\n\nThen follow me.",
    "id" : 637855825277546497,
    "created_at" : "2015-08-30 05:14:14 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 638000454841036800,
  "created_at" : "2015-08-30 14:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637998819871956992",
  "text" : "RT @onealexharms: It's saying this: if you're going to do this, if you're going to dehumanize me or anyone, you'll do it without my help. @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The King Center",
        "screen_name" : "TheKingCenter",
        "indices" : [ 120, 134 ],
        "id_str" : "39547629",
        "id" : 39547629
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "637988733325832192",
    "geo" : { },
    "id_str" : "637989392792035329",
    "in_reply_to_user_id" : 15349954,
    "text" : "It's saying this: if you're going to do this, if you're going to dehumanize me or anyone, you'll do it without my help. @TheKingCenter",
    "id" : 637989392792035329,
    "in_reply_to_status_id" : 637988733325832192,
    "created_at" : "2015-08-30 14:04:59 +0000",
    "in_reply_to_screen_name" : "onealexharms",
    "in_reply_to_user_id_str" : "15349954",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 637998819871956992,
  "created_at" : "2015-08-30 14:42:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637998744781385728",
  "text" : "RT @onealexharms: Nonviolence is never about making oppression comfortable. It's standing strong, unwilling to  complicit. https:\/\/t.co\/yzY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/yzYsyJU16p",
        "expanded_url" : "https:\/\/twitter.com\/TheKingCenter\/status\/637958335728381953",
        "display_url" : "twitter.com\/TheKingCenter\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637988733325832192",
    "text" : "Nonviolence is never about making oppression comfortable. It's standing strong, unwilling to  complicit. https:\/\/t.co\/yzYsyJU16p",
    "id" : 637988733325832192,
    "created_at" : "2015-08-30 14:02:21 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 637998744781385728,
  "created_at" : "2015-08-30 14:42:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philosophy Matters",
      "screen_name" : "PhilosophyMttrs",
      "indices" : [ 3, 19 ],
      "id_str" : "2660613438",
      "id" : 2660613438
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PhilosophyMttrs\/status\/637829606440083456\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/w8rGld86Pj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNoGpZ8WEAAu4RC.jpg",
      "id_str" : "637829605634740224",
      "id" : 637829605634740224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNoGpZ8WEAAu4RC.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w8rGld86Pj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637998478623379456",
  "text" : "RT @PhilosophyMttrs: it's not always easy being Socrates' son ... http:\/\/t.co\/w8rGld86Pj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PhilosophyMttrs\/status\/637829606440083456\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/w8rGld86Pj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNoGpZ8WEAAu4RC.jpg",
        "id_str" : "637829605634740224",
        "id" : 637829605634740224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNoGpZ8WEAAu4RC.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/w8rGld86Pj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637829606440083456",
    "text" : "it's not always easy being Socrates' son ... http:\/\/t.co\/w8rGld86Pj",
    "id" : 637829606440083456,
    "created_at" : "2015-08-30 03:30:03 +0000",
    "user" : {
      "name" : "Philosophy Matters",
      "screen_name" : "PhilosophyMttrs",
      "protected" : false,
      "id_str" : "2660613438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490606298568749056\/FVhiI6kM_normal.jpeg",
      "id" : 2660613438,
      "verified" : false
    }
  },
  "id" : 637998478623379456,
  "created_at" : "2015-08-30 14:41:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637760763806003200",
  "geo" : { },
  "id_str" : "637763958699622400",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe geez.. sometimes I don't think. I remember you telling me that. ugh!",
  "id" : 637763958699622400,
  "in_reply_to_status_id" : 637760763806003200,
  "created_at" : "2015-08-29 23:09:11 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "introvert",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637754836046512128",
  "geo" : { },
  "id_str" : "637759869051908096",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe and I'll go to my death bed still feeling guilty for DD doing K 2x plus full day Pre-K. was hard for her #introvert",
  "id" : 637759869051908096,
  "in_reply_to_status_id" : 637754836046512128,
  "created_at" : "2015-08-29 22:52:56 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637709339009097728",
  "geo" : { },
  "id_str" : "637740531385270272",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms darn. sorry you haven't been well. ((hugs))",
  "id" : 637740531385270272,
  "in_reply_to_status_id" : 637709339009097728,
  "created_at" : "2015-08-29 21:36:05 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 0, 16 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637645304607711232",
  "geo" : { },
  "id_str" : "637660614547120128",
  "in_reply_to_user_id" : 111579405,
  "text" : "@thDigitalReader thx. hmm.. i looked further and saw I can embed or publish to web. i'll play w it to see if i can get it right.",
  "id" : 637660614547120128,
  "in_reply_to_status_id" : 637645304607711232,
  "created_at" : "2015-08-29 16:18:32 +0000",
  "in_reply_to_screen_name" : "thDigitalReader",
  "in_reply_to_user_id_str" : "111579405",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Gibson",
      "screen_name" : "dgpixphoto",
      "indices" : [ 0, 11 ],
      "id_str" : "114216659",
      "id" : 114216659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637644606054731777",
  "geo" : { },
  "id_str" : "637660041198370816",
  "in_reply_to_user_id" : 114216659,
  "text" : "@dgpixphoto thx. installed ducklink so I can get scrolled section. now having trouble edit in paint.. argh. lol.",
  "id" : 637660041198370816,
  "in_reply_to_status_id" : 637644606054731777,
  "created_at" : "2015-08-29 16:16:15 +0000",
  "in_reply_to_screen_name" : "dgpixphoto",
  "in_reply_to_user_id_str" : "114216659",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Petre Sandulescu",
      "screen_name" : "Pit__",
      "indices" : [ 3, 9 ],
      "id_str" : "191536966",
      "id" : 191536966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/cCVnACqHke",
      "expanded_url" : "https:\/\/youtu.be\/m0kw_qx_k4Q",
      "display_url" : "youtu.be\/m0kw_qx_k4Q"
    } ]
  },
  "geo" : { },
  "id_str" : "637644762397454337",
  "text" : "RT @Pit__: BREAKING; Dead Seals Test Positive For Radiation\/Lukemia https:\/\/t.co\/cCVnACqHke \nYet they still don't know what could be killin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/cCVnACqHke",
        "expanded_url" : "https:\/\/youtu.be\/m0kw_qx_k4Q",
        "display_url" : "youtu.be\/m0kw_qx_k4Q"
      } ]
    },
    "geo" : { },
    "id_str" : "637261934161739776",
    "text" : "BREAKING; Dead Seals Test Positive For Radiation\/Lukemia https:\/\/t.co\/cCVnACqHke \nYet they still don't know what could be killing them...",
    "id" : 637261934161739776,
    "created_at" : "2015-08-28 13:54:19 +0000",
    "user" : {
      "name" : "Petre Sandulescu",
      "screen_name" : "Pit__",
      "protected" : false,
      "id_str" : "191536966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553703519153188864\/yOBpfGqA_normal.jpeg",
      "id" : 191536966,
      "verified" : false
    }
  },
  "id" : 637644762397454337,
  "created_at" : "2015-08-29 15:15:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spreadsheets",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637643893266337793",
  "text" : "i cant figure out how to show #spreadsheets on a blog or website. i'd like to post full image spreadsheets.",
  "id" : 637643893266337793,
  "created_at" : "2015-08-29 15:12:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick B",
      "screen_name" : "TenPercent",
      "indices" : [ 3, 14 ],
      "id_str" : "14707122",
      "id" : 14707122
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TenPercent\/status\/637403797082537985\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/eWG39R9t07",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNiDW2RW8AAC88j.jpg",
      "id_str" : "637403775821606912",
      "id" : 637403775821606912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNiDW2RW8AAC88j.jpg",
      "sizes" : [ {
        "h" : 644,
        "resize" : "fit",
        "w" : 557
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 557
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 557
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eWG39R9t07"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637633653057679360",
  "text" : "RT @TenPercent: Respecting wheelchair users who can walk http:\/\/t.co\/eWG39R9t07",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TenPercent\/status\/637403797082537985\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/eWG39R9t07",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNiDW2RW8AAC88j.jpg",
        "id_str" : "637403775821606912",
        "id" : 637403775821606912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNiDW2RW8AAC88j.jpg",
        "sizes" : [ {
          "h" : 644,
          "resize" : "fit",
          "w" : 557
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 557
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 557
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eWG39R9t07"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637403797082537985",
    "text" : "Respecting wheelchair users who can walk http:\/\/t.co\/eWG39R9t07",
    "id" : 637403797082537985,
    "created_at" : "2015-08-28 23:18:02 +0000",
    "user" : {
      "name" : "Rick B",
      "screen_name" : "TenPercent",
      "protected" : false,
      "id_str" : "14707122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581463929932660736\/JhvC6aIg_normal.jpg",
      "id" : 14707122,
      "verified" : false
    }
  },
  "id" : 637633653057679360,
  "created_at" : "2015-08-29 14:31:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637438083881902080",
  "text" : "RT @Pandeism: If you're not following me you're missing all my wisdoms.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637435270237958144",
    "text" : "If you're not following me you're missing all my wisdoms.",
    "id" : 637435270237958144,
    "created_at" : "2015-08-29 01:23:06 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 637438083881902080,
  "created_at" : "2015-08-29 01:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moose",
      "indices" : [ 111, 117 ]
    }, {
      "text" : "Alaska",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "photo",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637430678896963584",
  "text" : "RT @Alaskachic907: Just look at that cute face!  This little one was so fun to watch run and play in the yard. #moose #Alaska #photo http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alaskachic907\/status\/637415580866248704\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/dZDFFz3lRs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNiOF57UwAQPe_7.jpg",
        "id_str" : "637415579373060100",
        "id" : 637415579373060100,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNiOF57UwAQPe_7.jpg",
        "sizes" : [ {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2592,
          "resize" : "fit",
          "w" : 3872
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dZDFFz3lRs"
      } ],
      "hashtags" : [ {
        "text" : "moose",
        "indices" : [ 92, 98 ]
      }, {
        "text" : "Alaska",
        "indices" : [ 99, 106 ]
      }, {
        "text" : "photo",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637415580866248704",
    "text" : "Just look at that cute face!  This little one was so fun to watch run and play in the yard. #moose #Alaska #photo http:\/\/t.co\/dZDFFz3lRs",
    "id" : 637415580866248704,
    "created_at" : "2015-08-29 00:04:51 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 637430678896963584,
  "created_at" : "2015-08-29 01:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LukeRomyn\/status\/637416658915692545\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/IW1fV5fsI7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNiPEvAWEAA_cqy.jpg",
      "id_str" : "637416658773086208",
      "id" : 637416658773086208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNiPEvAWEAA_cqy.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IW1fV5fsI7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637423616230051840",
  "text" : "RT @LukeRomyn: And here's an albino moose for no reason at all. http:\/\/t.co\/IW1fV5fsI7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LukeRomyn\/status\/637416658915692545\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/IW1fV5fsI7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNiPEvAWEAA_cqy.jpg",
        "id_str" : "637416658773086208",
        "id" : 637416658773086208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNiPEvAWEAA_cqy.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IW1fV5fsI7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637416658915692545",
    "text" : "And here's an albino moose for no reason at all. http:\/\/t.co\/IW1fV5fsI7",
    "id" : 637416658915692545,
    "created_at" : "2015-08-29 00:09:08 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 637423616230051840,
  "created_at" : "2015-08-29 00:36:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Longform",
      "screen_name" : "longform",
      "indices" : [ 3, 12 ],
      "id_str" : "125547081",
      "id" : 125547081
    }, {
      "name" : "Mariah Blake",
      "screen_name" : "MariahCBlake",
      "indices" : [ 106, 119 ],
      "id_str" : "454098126",
      "id" : 454098126
    }, {
      "name" : "HuffPost Highline",
      "screen_name" : "highline",
      "indices" : [ 121, 130 ],
      "id_str" : "3031345253",
      "id" : 3031345253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/qftCdxxL3F",
      "expanded_url" : "http:\/\/long.fm\/ZZY2rR3",
      "display_url" : "long.fm\/ZZY2rR3"
    } ]
  },
  "geo" : { },
  "id_str" : "637420727579320320",
  "text" : "RT @longform: How C8, used in the making Teflon, ruined an entire town in W. Va.: http:\/\/t.co\/qftCdxxL3F (@MariahCBlake, @highline) http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/longform.org\/\" rel=\"nofollow\"\u003ELongform.org CMS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mariah Blake",
        "screen_name" : "MariahCBlake",
        "indices" : [ 92, 105 ],
        "id_str" : "454098126",
        "id" : 454098126
      }, {
        "name" : "HuffPost Highline",
        "screen_name" : "highline",
        "indices" : [ 107, 116 ],
        "id_str" : "3031345253",
        "id" : 3031345253
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/longform\/status\/637323849198080000\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/6fZuO7ycVC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNg6qgIXAAA8-OC.jpg",
        "id_str" : "637323849126838272",
        "id" : 637323849126838272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNg6qgIXAAA8-OC.jpg",
        "sizes" : [ {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/6fZuO7ycVC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/qftCdxxL3F",
        "expanded_url" : "http:\/\/long.fm\/ZZY2rR3",
        "display_url" : "long.fm\/ZZY2rR3"
      } ]
    },
    "geo" : { },
    "id_str" : "637323849198080000",
    "text" : "How C8, used in the making Teflon, ruined an entire town in W. Va.: http:\/\/t.co\/qftCdxxL3F (@MariahCBlake, @highline) http:\/\/t.co\/6fZuO7ycVC",
    "id" : 637323849198080000,
    "created_at" : "2015-08-28 18:00:21 +0000",
    "user" : {
      "name" : "Longform",
      "screen_name" : "longform",
      "protected" : false,
      "id_str" : "125547081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512306726633107456\/ekZR-5Zs_normal.png",
      "id" : 125547081,
      "verified" : false
    }
  },
  "id" : 637420727579320320,
  "created_at" : "2015-08-29 00:25:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 3, 9 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qIii7ignFn",
      "expanded_url" : "http:\/\/bit.ly\/1VjlNhM",
      "display_url" : "bit.ly\/1VjlNhM"
    } ]
  },
  "geo" : { },
  "id_str" : "637404405579579392",
  "text" : "RT @sciam: The most rigorous test of quantum theory ever carried out has confirmed 'spooky action at a distance' http:\/\/t.co\/qIii7ignFn #sc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/qIii7ignFn",
        "expanded_url" : "http:\/\/bit.ly\/1VjlNhM",
        "display_url" : "bit.ly\/1VjlNhM"
      } ]
    },
    "geo" : { },
    "id_str" : "637382033606508544",
    "text" : "The most rigorous test of quantum theory ever carried out has confirmed 'spooky action at a distance' http:\/\/t.co\/qIii7ignFn #science",
    "id" : 637382033606508544,
    "created_at" : "2015-08-28 21:51:33 +0000",
    "user" : {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "protected" : false,
      "id_str" : "14647570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676776763431620608\/1eNZzxq0_normal.png",
      "id" : 14647570,
      "verified" : true
    }
  },
  "id" : 637404405579579392,
  "created_at" : "2015-08-28 23:20:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637392742352613377",
  "text" : "endo mentioned misophonia when DD told about sensory overload. just looked it up. its reacting to specific sounds not gen noise.",
  "id" : 637392742352613377,
  "created_at" : "2015-08-28 22:34:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smallholders UK",
      "screen_name" : "SmallholdersUK",
      "indices" : [ 3, 18 ],
      "id_str" : "2755302710",
      "id" : 2755302710
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SmallholdersUK\/status\/637326367428857856\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/jLtvjIp9uJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNg88_SWsAAxY9O.jpg",
      "id_str" : "637326365751160832",
      "id" : 637326365751160832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNg88_SWsAAxY9O.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jLtvjIp9uJ"
    } ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "quiff",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637362743914401797",
  "text" : "RT @SmallholdersUK: Another #buffalo hairstyle #quiff http:\/\/t.co\/jLtvjIp9uJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SmallholdersUK\/status\/637326367428857856\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/jLtvjIp9uJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNg88_SWsAAxY9O.jpg",
        "id_str" : "637326365751160832",
        "id" : 637326365751160832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNg88_SWsAAxY9O.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jLtvjIp9uJ"
      } ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "quiff",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637326367428857856",
    "text" : "Another #buffalo hairstyle #quiff http:\/\/t.co\/jLtvjIp9uJ",
    "id" : 637326367428857856,
    "created_at" : "2015-08-28 18:10:21 +0000",
    "user" : {
      "name" : "Smallholders UK",
      "screen_name" : "SmallholdersUK",
      "protected" : false,
      "id_str" : "2755302710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800640480572833796\/nP9Qr_Kl_normal.jpg",
      "id" : 2755302710,
      "verified" : false
    }
  },
  "id" : 637362743914401797,
  "created_at" : "2015-08-28 20:34:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637356757665337344",
  "text" : "finally got mental health appt for DD. feeling accomplished. although, DD actually made the call..lol. #chronicillness",
  "id" : 637356757665337344,
  "created_at" : "2015-08-28 20:11:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/guK3nPtLH4",
      "expanded_url" : "http:\/\/fb.me\/6J0bdF7md",
      "display_url" : "fb.me\/6J0bdF7md"
    } ]
  },
  "geo" : { },
  "id_str" : "637311441335373824",
  "text" : "RT @WGJewellery: I've named her Lucie and she's now live online! http:\/\/t.co\/guK3nPtLH4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/guK3nPtLH4",
        "expanded_url" : "http:\/\/fb.me\/6J0bdF7md",
        "display_url" : "fb.me\/6J0bdF7md"
      } ]
    },
    "geo" : { },
    "id_str" : "637310153071706112",
    "text" : "I've named her Lucie and she's now live online! http:\/\/t.co\/guK3nPtLH4",
    "id" : 637310153071706112,
    "created_at" : "2015-08-28 17:05:55 +0000",
    "user" : {
      "name" : "Nina Parker",
      "screen_name" : "nina_jewellery",
      "protected" : false,
      "id_str" : "292346507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667416978500489216\/tMozNQyo_normal.jpg",
      "id" : 292346507,
      "verified" : false
    }
  },
  "id" : 637311441335373824,
  "created_at" : "2015-08-28 17:11:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpongeBob",
      "screen_name" : "Stockejock",
      "indices" : [ 3, 14 ],
      "id_str" : "3168146270",
      "id" : 3168146270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637261112824700928",
  "text" : "RT @stockejock: Twitter is the island of Misfit Toys-outcast, weird, odd, strange or dysfunctional? Welcome, we've been expecting you http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stockejock\/status\/637092809317720065\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/bEOWgDtP67",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNdoh6RUcAEhflx.jpg",
        "id_str" : "637092804083085313",
        "id" : 637092804083085313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNdoh6RUcAEhflx.jpg",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 478
        } ],
        "display_url" : "pic.twitter.com\/bEOWgDtP67"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637092809317720065",
    "text" : "Twitter is the island of Misfit Toys-outcast, weird, odd, strange or dysfunctional? Welcome, we've been expecting you http:\/\/t.co\/bEOWgDtP67",
    "id" : 637092809317720065,
    "created_at" : "2015-08-28 02:42:17 +0000",
    "user" : {
      "name" : "The Cultured Ruffian",
      "screen_name" : "CulturedRuffian",
      "protected" : false,
      "id_str" : "18857913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793406779015192576\/iW-WbemL_normal.jpg",
      "id" : 18857913,
      "verified" : false
    }
  },
  "id" : 637261112824700928,
  "created_at" : "2015-08-28 13:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/637073268021682177\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/bMfF0lLAdG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNdWwnsWwAASfwW.jpg",
      "id_str" : "637073265584947200",
      "id" : 637073265584947200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNdWwnsWwAASfwW.jpg",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 311
      } ],
      "display_url" : "pic.twitter.com\/bMfF0lLAdG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637081139073667072",
  "text" : "RT @petsalive: Cumin takes cat napping very seriously http:\/\/t.co\/bMfF0lLAdG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/637073268021682177\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/bMfF0lLAdG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNdWwnsWwAASfwW.jpg",
        "id_str" : "637073265584947200",
        "id" : 637073265584947200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNdWwnsWwAASfwW.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 311
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 311
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 311
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 311
        } ],
        "display_url" : "pic.twitter.com\/bMfF0lLAdG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637073268021682177",
    "text" : "Cumin takes cat napping very seriously http:\/\/t.co\/bMfF0lLAdG",
    "id" : 637073268021682177,
    "created_at" : "2015-08-28 01:24:38 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 637081139073667072,
  "created_at" : "2015-08-28 01:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637051839612088320",
  "text" : "RT @AWorldOutOfMind: I think to cats, their own name is always \"cat\" and every other cat is \"not the real cat.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637050492212920320",
    "text" : "I think to cats, their own name is always \"cat\" and every other cat is \"not the real cat.\"",
    "id" : 637050492212920320,
    "created_at" : "2015-08-27 23:54:07 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 637051839612088320,
  "created_at" : "2015-08-27 23:59:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637047396908662785",
  "geo" : { },
  "id_str" : "637050935890608128",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre no they dont..lol. we like DDs PCP (actually a FNP) but she's at a loss.",
  "id" : 637050935890608128,
  "in_reply_to_status_id" : 637047396908662785,
  "created_at" : "2015-08-27 23:55:53 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elnigma",
      "screen_name" : "galaxiou",
      "indices" : [ 0, 9 ],
      "id_str" : "455972590",
      "id" : 455972590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637048579262181376",
  "geo" : { },
  "id_str" : "637050332086988800",
  "in_reply_to_user_id" : 455972590,
  "text" : "@galaxiou yeah, been hearing about it.. not a drug to fool around with. she was only on small dose (1\/4,1\/2 of 10 mg pill)",
  "id" : 637050332086988800,
  "in_reply_to_status_id" : 637048579262181376,
  "created_at" : "2015-08-27 23:53:29 +0000",
  "in_reply_to_screen_name" : "galaxiou",
  "in_reply_to_user_id_str" : "455972590",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elnigma",
      "screen_name" : "galaxiou",
      "indices" : [ 0, 9 ],
      "id_str" : "455972590",
      "id" : 455972590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637048579262181376",
  "geo" : { },
  "id_str" : "637049951835566080",
  "in_reply_to_user_id" : 455972590,
  "text" : "@galaxiou it was supposed to make her feel better from thyroid inflammation but it wasnt doing anything so endo said might as well stop.",
  "id" : 637049951835566080,
  "in_reply_to_status_id" : 637048579262181376,
  "created_at" : "2015-08-27 23:51:58 +0000",
  "in_reply_to_screen_name" : "galaxiou",
  "in_reply_to_user_id_str" : "455972590",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aric Clark",
      "screen_name" : "aricclark",
      "indices" : [ 3, 13 ],
      "id_str" : "17847731",
      "id" : 17847731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637016325777432580",
  "text" : "RT @aricclark: A lot of pain out there people. Be gentle with each other.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637015074121510914",
    "text" : "A lot of pain out there people. Be gentle with each other.",
    "id" : 637015074121510914,
    "created_at" : "2015-08-27 21:33:23 +0000",
    "user" : {
      "name" : "Aric Clark",
      "screen_name" : "aricclark",
      "protected" : false,
      "id_str" : "17847731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120431797\/CIMG3699_normal.JPG",
      "id" : 17847731,
      "verified" : false
    }
  },
  "id" : 637016325777432580,
  "created_at" : "2015-08-27 21:38:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637009488785108992",
  "text" : "also.. again w the mental health. arg.",
  "id" : 637009488785108992,
  "created_at" : "2015-08-27 21:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637009274762326016",
  "text" : "she rec go to specific GI dr who deals w diabetes pat who have ongoing nausea, add canola oil to shakes, stop prednisone.",
  "id" : 637009274762326016,
  "created_at" : "2015-08-27 21:10:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637008837124468737",
  "text" : "saw new endo. dd weighed at 82.4 there so she was very concerned about that. doesnt think symptoms are #hashimotos related",
  "id" : 637008837124468737,
  "created_at" : "2015-08-27 21:08:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637008054161141760",
  "text" : "feeling.. confused, directionless.. sigh.",
  "id" : 637008054161141760,
  "created_at" : "2015-08-27 21:05:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Playrix",
      "screen_name" : "Playrix",
      "indices" : [ 3, 11 ],
      "id_str" : "18334194",
      "id" : 18334194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/MJGH16JLXv",
      "expanded_url" : "http:\/\/plrx.gs\/1PAyscp",
      "display_url" : "plrx.gs\/1PAyscp"
    } ]
  },
  "geo" : { },
  "id_str" : "636931021515177984",
  "text" : "RT @Playrix: BETA TESTERS WANTED! We are currently looking for beta testers for our new mobile games. Check this out: http:\/\/t.co\/MJGH16JLXv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/MJGH16JLXv",
        "expanded_url" : "http:\/\/plrx.gs\/1PAyscp",
        "display_url" : "plrx.gs\/1PAyscp"
      } ]
    },
    "geo" : { },
    "id_str" : "636930509130612741",
    "text" : "BETA TESTERS WANTED! We are currently looking for beta testers for our new mobile games. Check this out: http:\/\/t.co\/MJGH16JLXv",
    "id" : 636930509130612741,
    "created_at" : "2015-08-27 15:57:21 +0000",
    "user" : {
      "name" : "Playrix",
      "screen_name" : "Playrix",
      "protected" : false,
      "id_str" : "18334194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799260739542323201\/IZTkRQA-_normal.jpg",
      "id" : 18334194,
      "verified" : true
    }
  },
  "id" : 636931021515177984,
  "created_at" : "2015-08-27 15:59:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/E8M2v9xXcW",
      "expanded_url" : "https:\/\/twitter.com\/samwhiteout\/status\/636719022785044480",
      "display_url" : "twitter.com\/samwhiteout\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636930928691027968",
  "text" : "Get out of \"my\" country?? just.. wow. https:\/\/t.co\/E8M2v9xXcW",
  "id" : 636930928691027968,
  "created_at" : "2015-08-27 15:59:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/vuPj2x1lL8",
      "expanded_url" : "https:\/\/twitter.com\/adamrshields\/status\/636870067058253824",
      "display_url" : "twitter.com\/adamrshields\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636921861851467776",
  "text" : "loved it! https:\/\/t.co\/vuPj2x1lL8",
  "id" : 636921861851467776,
  "created_at" : "2015-08-27 15:22:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636921416454131712",
  "text" : "RT @ZachsMind: making actions illegal isn't working in many situations. we need to figure out how to change the behavior. that's way tricki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636886223169019908",
    "text" : "making actions illegal isn't working in many situations. we need to figure out how to change the behavior. that's way trickier.",
    "id" : 636886223169019908,
    "created_at" : "2015-08-27 13:01:23 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 636921416454131712,
  "created_at" : "2015-08-27 15:21:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636921299852492800",
  "text" : "RT @ZachsMind: Why does someone need to steal? Figure that out and stop that. Prevent the motive from happening in the first place.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636886611226030080",
    "text" : "Why does someone need to steal? Figure that out and stop that. Prevent the motive from happening in the first place.",
    "id" : 636886611226030080,
    "created_at" : "2015-08-27 13:02:55 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 636921299852492800,
  "created_at" : "2015-08-27 15:20:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pourmecoffee\/status\/636681272023248896\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/25bbryoNP6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXyLVBUYAAXBx_.jpg",
      "id_str" : "636681198777950208",
      "id" : 636681198777950208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXyLVBUYAAXBx_.jpg",
      "sizes" : [ {
        "h" : 502,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1070,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/25bbryoNP6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/9mZibpdhdp",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/gsfc\/20283986193\/",
      "display_url" : "flickr.com\/photos\/gsfc\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636723170872004608",
  "text" : "RT @pourmecoffee: Sweet Jeebus,look at this thing. New Hubble image of the Twin Jet Nebula https:\/\/t.co\/9mZibpdhdp http:\/\/t.co\/25bbryoNP6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pourmecoffee\/status\/636681272023248896\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/25bbryoNP6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXyLVBUYAAXBx_.jpg",
        "id_str" : "636681198777950208",
        "id" : 636681198777950208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXyLVBUYAAXBx_.jpg",
        "sizes" : [ {
          "h" : 502,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 856,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1070,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/25bbryoNP6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/9mZibpdhdp",
        "expanded_url" : "https:\/\/www.flickr.com\/photos\/gsfc\/20283986193\/",
        "display_url" : "flickr.com\/photos\/gsfc\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636681272023248896",
    "text" : "Sweet Jeebus,look at this thing. New Hubble image of the Twin Jet Nebula https:\/\/t.co\/9mZibpdhdp http:\/\/t.co\/25bbryoNP6",
    "id" : 636681272023248896,
    "created_at" : "2015-08-26 23:26:58 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682738304354140160\/OpbXjxXU_normal.jpg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 636723170872004608,
  "created_at" : "2015-08-27 02:13:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636682976059764736",
  "geo" : { },
  "id_str" : "636686154474065920",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley Thanks! added to wish list.. in red!",
  "id" : 636686154474065920,
  "in_reply_to_status_id" : 636682976059764736,
  "created_at" : "2015-08-26 23:46:22 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Young Turks",
      "screen_name" : "TheYoungTurks",
      "indices" : [ 3, 17 ],
      "id_str" : "14957147",
      "id" : 14957147
    }, {
      "name" : "Ana Kasparian",
      "screen_name" : "AnaKasparian",
      "indices" : [ 121, 134 ],
      "id_str" : "23865382",
      "id" : 23865382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636682466204495872",
  "text" : "RT @TheYoungTurks: \"There\u2019s a lot of talk about freedom of religion in America, but what about freedom from religion?\" - @AnaKasparian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ana Kasparian",
        "screen_name" : "AnaKasparian",
        "indices" : [ 102, 115 ],
        "id_str" : "23865382",
        "id" : 23865382
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636591513011490817",
    "text" : "\"There\u2019s a lot of talk about freedom of religion in America, but what about freedom from religion?\" - @AnaKasparian",
    "id" : 636591513011490817,
    "created_at" : "2015-08-26 17:30:18 +0000",
    "user" : {
      "name" : "The Young Turks",
      "screen_name" : "TheYoungTurks",
      "protected" : false,
      "id_str" : "14957147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712735799444447233\/biy20iny_normal.jpg",
      "id" : 14957147,
      "verified" : true
    }
  },
  "id" : 636682466204495872,
  "created_at" : "2015-08-26 23:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636682269944627200",
  "text" : "RT @ZachsMind: We are trapped on this spinning mudball in space together. We are not making the best of it. We need to do better. We can do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636590151137759232",
    "text" : "We are trapped on this spinning mudball in space together. We are not making the best of it. We need to do better. We can do better.",
    "id" : 636590151137759232,
    "created_at" : "2015-08-26 17:24:53 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 636682269944627200,
  "created_at" : "2015-08-26 23:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 33, 45 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/636636112740593668\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/lDYV1Jpmrw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXJKKNWsAARdhe.jpg",
      "id_str" : "636636098719035392",
      "id" : 636636098719035392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXJKKNWsAARdhe.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lDYV1Jpmrw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636681624843907072",
  "text" : "OMG, adorable!! &lt;3 I want! RT @ErinEFarley: New shoes. Quite comfy. http:\/\/t.co\/lDYV1Jpmrw",
  "id" : 636681624843907072,
  "created_at" : "2015-08-26 23:28:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "myAppFree",
      "screen_name" : "myAppFree",
      "indices" : [ 3, 13 ],
      "id_str" : "926048040",
      "id" : 926048040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636612405930369024",
  "text" : "RT @myAppFree: LOOK OUT! There is still few time to save your sensitive data and $ 9.99 at the same time. Time is running out so... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7IPT01epH3",
        "expanded_url" : "http:\/\/fb.me\/3J3Umn225",
        "display_url" : "fb.me\/3J3Umn225"
      } ]
    },
    "geo" : { },
    "id_str" : "636611263443927041",
    "text" : "LOOK OUT! There is still few time to save your sensitive data and $ 9.99 at the same time. Time is running out so... http:\/\/t.co\/7IPT01epH3",
    "id" : 636611263443927041,
    "created_at" : "2015-08-26 18:48:47 +0000",
    "user" : {
      "name" : "myAppFree",
      "screen_name" : "myAppFree",
      "protected" : false,
      "id_str" : "926048040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660935909123170304\/RJOTv4GD_normal.png",
      "id" : 926048040,
      "verified" : false
    }
  },
  "id" : 636612405930369024,
  "created_at" : "2015-08-26 18:53:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Snyder",
      "screen_name" : "noteon",
      "indices" : [ 3, 10 ],
      "id_str" : "16065917",
      "id" : 16065917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636612025758654465",
  "text" : "RT @noteon: OK, how about this.\n\nA gun is a weapon incorporating a tube from which projectiles are propelled by explosive force.\n\nCan we ag\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636611632806821888",
    "text" : "OK, how about this.\n\nA gun is a weapon incorporating a tube from which projectiles are propelled by explosive force.\n\nCan we agree on THAT.",
    "id" : 636611632806821888,
    "created_at" : "2015-08-26 18:50:15 +0000",
    "user" : {
      "name" : "Keith Snyder",
      "screen_name" : "noteon",
      "protected" : false,
      "id_str" : "16065917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734735503069585408\/AmMDryty_normal.jpg",
      "id" : 16065917,
      "verified" : false
    }
  },
  "id" : 636612025758654465,
  "created_at" : "2015-08-26 18:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "sick",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "unintentionalweightloss",
      "indices" : [ 92, 116 ]
    }, {
      "text" : "canipanicnow",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636607029650563072",
  "text" : "5 foot 1, 83 lbs. officially down 10 lbs since tracking in June. #hashimotos #thyroid #sick #unintentionalweightloss #canipanicnow?",
  "id" : 636607029650563072,
  "created_at" : "2015-08-26 18:31:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 18, 31 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/UfnjhX0k4u",
      "expanded_url" : "http:\/\/flip.it\/GzDvT",
      "display_url" : "flip.it\/GzDvT"
    } ]
  },
  "geo" : { },
  "id_str" : "636539299408801792",
  "text" : "RT @bend_time: RT @mental_floss: There Is a Video Game Where You Just Take Care of Succulents \u2014 http:\/\/t.co\/UfnjhX0k4u http:\/\/t.co\/QBWhpWrU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mental Floss",
        "screen_name" : "mental_floss",
        "indices" : [ 3, 16 ],
        "id_str" : "20065936",
        "id" : 20065936
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/636355636368830464\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/QBWhpWrUt3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNTKFGDUwAEbKPi.png",
        "id_str" : "636355636238794753",
        "id" : 636355636238794753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNTKFGDUwAEbKPi.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QBWhpWrUt3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/UfnjhX0k4u",
        "expanded_url" : "http:\/\/flip.it\/GzDvT",
        "display_url" : "flip.it\/GzDvT"
      } ]
    },
    "geo" : { },
    "id_str" : "636363229447352320",
    "text" : "RT @mental_floss: There Is a Video Game Where You Just Take Care of Succulents \u2014 http:\/\/t.co\/UfnjhX0k4u http:\/\/t.co\/QBWhpWrUt3",
    "id" : 636363229447352320,
    "created_at" : "2015-08-26 02:23:11 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 636539299408801792,
  "created_at" : "2015-08-26 14:02:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "North Woods Ranch",
      "screen_name" : "NorthWoodsRanch",
      "indices" : [ 3, 19 ],
      "id_str" : "431004831",
      "id" : 431004831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/636509405148807168\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Ydv54KEZKa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNVV7kKU8AEltYb.jpg",
      "id_str" : "636509404150427649",
      "id" : 636509404150427649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNVV7kKU8AEltYb.jpg",
      "sizes" : [ {
        "h" : 501,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 885,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1933,
        "resize" : "fit",
        "w" : 1311
      }, {
        "h" : 1510,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ydv54KEZKa"
    } ],
    "hashtags" : [ {
      "text" : "peekacoo",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636535699525771264",
  "text" : "RT @NorthWoodsRanch: #peekacoo http:\/\/t.co\/Ydv54KEZKa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/636509405148807168\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/Ydv54KEZKa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNVV7kKU8AEltYb.jpg",
        "id_str" : "636509404150427649",
        "id" : 636509404150427649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNVV7kKU8AEltYb.jpg",
        "sizes" : [ {
          "h" : 501,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 885,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1933,
          "resize" : "fit",
          "w" : 1311
        }, {
          "h" : 1510,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Ydv54KEZKa"
      } ],
      "hashtags" : [ {
        "text" : "peekacoo",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636509405148807168",
    "text" : "#peekacoo http:\/\/t.co\/Ydv54KEZKa",
    "id" : 636509405148807168,
    "created_at" : "2015-08-26 12:04:02 +0000",
    "user" : {
      "name" : "North Woods Ranch",
      "screen_name" : "NorthWoodsRanch",
      "protected" : false,
      "id_str" : "431004831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1735387668\/DSC05143_normal.JPG",
      "id" : 431004831,
      "verified" : false
    }
  },
  "id" : 636535699525771264,
  "created_at" : "2015-08-26 13:48:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636335272708321280",
  "geo" : { },
  "id_str" : "636338502582562816",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater ohhh I like! : )",
  "id" : 636338502582562816,
  "in_reply_to_status_id" : 636335272708321280,
  "created_at" : "2015-08-26 00:44:56 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 0, 7 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636267085660823556",
  "geo" : { },
  "id_str" : "636329468718632960",
  "in_reply_to_user_id" : 6872302,
  "text" : "@Mahala aww.. bless him for such kindness. made me cry.",
  "id" : 636329468718632960,
  "in_reply_to_status_id" : 636267085660823556,
  "created_at" : "2015-08-26 00:09:02 +0000",
  "in_reply_to_screen_name" : "Mahala",
  "in_reply_to_user_id_str" : "6872302",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/WwwHN35si2",
      "expanded_url" : "http:\/\/bit.ly\/1NOIHJC",
      "display_url" : "bit.ly\/1NOIHJC"
    } ]
  },
  "geo" : { },
  "id_str" : "636329166015741952",
  "text" : "RT @Mahala: Police Officer Soothes Dog Who Bit Him - http:\/\/t.co\/WwwHN35si2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/WwwHN35si2",
        "expanded_url" : "http:\/\/bit.ly\/1NOIHJC",
        "display_url" : "bit.ly\/1NOIHJC"
      } ]
    },
    "geo" : { },
    "id_str" : "636267085660823556",
    "text" : "Police Officer Soothes Dog Who Bit Him - http:\/\/t.co\/WwwHN35si2",
    "id" : 636267085660823556,
    "created_at" : "2015-08-25 20:01:09 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 636329166015741952,
  "created_at" : "2015-08-26 00:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindfulness Wellness",
      "screen_name" : "911well",
      "indices" : [ 3, 11 ],
      "id_str" : "355784391",
      "id" : 355784391
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/911well\/status\/636271417898700800\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/kxG3hu1C2q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNR9e77W8AAT1P2.jpg",
      "id_str" : "636271417802289152",
      "id" : 636271417802289152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNR9e77W8AAT1P2.jpg",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 502
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 502
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 502
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/kxG3hu1C2q"
    } ],
    "hashtags" : [ {
      "text" : "mindfulness",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636328489327685632",
  "text" : "RT @911well: Always help someone .. #mindfulness http:\/\/t.co\/kxG3hu1C2q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/911well\/status\/636271417898700800\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/kxG3hu1C2q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNR9e77W8AAT1P2.jpg",
        "id_str" : "636271417802289152",
        "id" : 636271417802289152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNR9e77W8AAT1P2.jpg",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/kxG3hu1C2q"
      } ],
      "hashtags" : [ {
        "text" : "mindfulness",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636271417898700800",
    "text" : "Always help someone .. #mindfulness http:\/\/t.co\/kxG3hu1C2q",
    "id" : 636271417898700800,
    "created_at" : "2015-08-25 20:18:22 +0000",
    "user" : {
      "name" : "Mindfulness Wellness",
      "screen_name" : "911well",
      "protected" : false,
      "id_str" : "355784391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761420913543745536\/fFpd0pfE_normal.jpg",
      "id" : 355784391,
      "verified" : false
    }
  },
  "id" : 636328489327685632,
  "created_at" : "2015-08-26 00:05:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Roy",
      "screen_name" : "jamesroywriter",
      "indices" : [ 3, 18 ],
      "id_str" : "22137208",
      "id" : 22137208
    }, {
      "name" : "Ray Comfort",
      "screen_name" : "raycomfort",
      "indices" : [ 45, 56 ],
      "id_str" : "22634945",
      "id" : 22634945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636203232340115456",
  "text" : "RT @jamesroywriter: Gay isn't a \"lifestyle\", @raycomfort",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ray Comfort",
        "screen_name" : "raycomfort",
        "indices" : [ 25, 36 ],
        "id_str" : "22634945",
        "id" : 22634945
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "636062567341887488",
    "geo" : { },
    "id_str" : "636118863696891905",
    "in_reply_to_user_id" : 22634945,
    "text" : "Gay isn't a \"lifestyle\", @raycomfort",
    "id" : 636118863696891905,
    "in_reply_to_status_id" : 636062567341887488,
    "created_at" : "2015-08-25 10:12:10 +0000",
    "in_reply_to_screen_name" : "raycomfort",
    "in_reply_to_user_id_str" : "22634945",
    "user" : {
      "name" : "James Roy",
      "screen_name" : "jamesroywriter",
      "protected" : false,
      "id_str" : "22137208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799445288163233792\/LyUK2j0H_normal.jpg",
      "id" : 22137208,
      "verified" : false
    }
  },
  "id" : 636203232340115456,
  "created_at" : "2015-08-25 15:47:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 110, 123 ]
    }, {
      "text" : "NPS99",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636201346887229440",
  "text" : "RT @NatlParkService: These guys might be headed to a birthday party. How are you celebrating 99 years of NPS? #FindYourPark #NPS99 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatlParkService\/status\/636158298325188608\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DhBPHkRrny",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQWmIFVAAANtJV.jpg",
        "id_str" : "636158291626754048",
        "id" : 636158291626754048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQWmIFVAAANtJV.jpg",
        "sizes" : [ {
          "h" : 483,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DhBPHkRrny"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 89, 102 ]
      }, {
        "text" : "NPS99",
        "indices" : [ 103, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636158298325188608",
    "text" : "These guys might be headed to a birthday party. How are you celebrating 99 years of NPS? #FindYourPark #NPS99 http:\/\/t.co\/DhBPHkRrny",
    "id" : 636158298325188608,
    "created_at" : "2015-08-25 12:48:52 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 636201346887229440,
  "created_at" : "2015-08-25 15:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Williams",
      "screen_name" : "Martin1Williams",
      "indices" : [ 3, 19 ],
      "id_str" : "499187808",
      "id" : 499187808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636200624095383552",
  "text" : "RT @Martin1Williams: Children. When grandparents give you a fiver &amp; tell you not to tell the parents..say it will cost more than that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636174858292981760",
    "text" : "Children. When grandparents give you a fiver &amp; tell you not to tell the parents..say it will cost more than that.",
    "id" : 636174858292981760,
    "created_at" : "2015-08-25 13:54:40 +0000",
    "user" : {
      "name" : "Martin Williams",
      "screen_name" : "Martin1Williams",
      "protected" : false,
      "id_str" : "499187808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687268835494367232\/2WvAAe94_normal.jpg",
      "id" : 499187808,
      "verified" : false
    }
  },
  "id" : 636200624095383552,
  "created_at" : "2015-08-25 15:37:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John C. Parkin",
      "screen_name" : "thefuckitlife",
      "indices" : [ 3, 17 ],
      "id_str" : "35800962",
      "id" : 35800962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thefuckitlife\/status\/636178973597151232\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/2xihz9VlNV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQpZ97UEAEJmt6.jpg",
      "id_str" : "636178973462892545",
      "id" : 636178973462892545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQpZ97UEAEJmt6.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 404
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 404
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 404
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2xihz9VlNV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636200152034881536",
  "text" : "RT @thefuckitlife: This too shall pass... http:\/\/t.co\/2xihz9VlNV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thefuckitlife\/status\/636178973597151232\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/2xihz9VlNV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQpZ97UEAEJmt6.jpg",
        "id_str" : "636178973462892545",
        "id" : 636178973462892545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQpZ97UEAEJmt6.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 404
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 404
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 404
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2xihz9VlNV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636178973597151232",
    "text" : "This too shall pass... http:\/\/t.co\/2xihz9VlNV",
    "id" : 636178973597151232,
    "created_at" : "2015-08-25 14:11:01 +0000",
    "user" : {
      "name" : "John C. Parkin",
      "screen_name" : "thefuckitlife",
      "protected" : false,
      "id_str" : "35800962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670129824124522496\/m2DP-ypQ_normal.jpg",
      "id" : 35800962,
      "verified" : false
    }
  },
  "id" : 636200152034881536,
  "created_at" : "2015-08-25 15:35:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/kL3BFO3gH3",
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/636194521399853058",
      "display_url" : "twitter.com\/newlandfarm\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636199544112443392",
  "text" : "soooo smoochable! &lt;3 https:\/\/t.co\/kL3BFO3gH3",
  "id" : 636199544112443392,
  "created_at" : "2015-08-25 15:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636010213091475456",
  "text" : "RT @JacksonPearce: I am thinking about that possum.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636009366571884545",
    "text" : "I am thinking about that possum.",
    "id" : 636009366571884545,
    "created_at" : "2015-08-25 02:57:04 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 636010213091475456,
  "created_at" : "2015-08-25 03:00:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Hope",
      "screen_name" : "RoseHopefully",
      "indices" : [ 3, 17 ],
      "id_str" : "563052577",
      "id" : 563052577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636008387243847680",
  "text" : "RT @RoseHopefully: So many of our friends are conditional. They only love us as long as we fit into the box they made for us. Is that energ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635986499864018944",
    "text" : "So many of our friends are conditional. They only love us as long as we fit into the box they made for us. Is that energy worth it?",
    "id" : 635986499864018944,
    "created_at" : "2015-08-25 01:26:12 +0000",
    "user" : {
      "name" : "Rose Hope",
      "screen_name" : "RoseHopefully",
      "protected" : false,
      "id_str" : "563052577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660324998876385280\/U4UaGKFF_normal.jpg",
      "id" : 563052577,
      "verified" : false
    }
  },
  "id" : 636008387243847680,
  "created_at" : "2015-08-25 02:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Cerrone",
      "screen_name" : "justagoodlife",
      "indices" : [ 3, 17 ],
      "id_str" : "1723493144",
      "id" : 1723493144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "medDetoxesSuck",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636006919849803776",
  "text" : "RT @justagoodlife: Omggggg these freaking 'electric zaps' I keep getting from this med withdrawal is driving me NUTS!!!! #medDetoxesSuck #C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "medDetoxesSuck",
        "indices" : [ 102, 117 ]
      }, {
        "text" : "ChronicLife",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636006725091479552",
    "text" : "Omggggg these freaking 'electric zaps' I keep getting from this med withdrawal is driving me NUTS!!!! #medDetoxesSuck #ChronicLife",
    "id" : 636006725091479552,
    "created_at" : "2015-08-25 02:46:34 +0000",
    "user" : {
      "name" : "Julie Cerrone",
      "screen_name" : "justagoodlife",
      "protected" : false,
      "id_str" : "1723493144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780965077063114752\/NWrkiI2q_normal.jpg",
      "id" : 1723493144,
      "verified" : false
    }
  },
  "id" : 636006919849803776,
  "created_at" : "2015-08-25 02:47:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 3, 12 ],
      "id_str" : "15492359",
      "id" : 15492359
    }, {
      "name" : "Jim Al-Khalili",
      "screen_name" : "jimalkhalili",
      "indices" : [ 99, 112 ],
      "id_str" : "104786280",
      "id" : 104786280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ZgIsmHL0Mu",
      "expanded_url" : "http:\/\/t.ted.com\/jVAQmUG",
      "display_url" : "t.ted.com\/jVAQmUG"
    } ]
  },
  "geo" : { },
  "id_str" : "635983709573922816",
  "text" : "RT @TEDTalks: 3 mind-bending ways quantum biology might explain everything: http:\/\/t.co\/ZgIsmHL0Mu @jimalkhalili",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Al-Khalili",
        "screen_name" : "jimalkhalili",
        "indices" : [ 85, 98 ],
        "id_str" : "104786280",
        "id" : 104786280
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/ZgIsmHL0Mu",
        "expanded_url" : "http:\/\/t.ted.com\/jVAQmUG",
        "display_url" : "t.ted.com\/jVAQmUG"
      } ]
    },
    "geo" : { },
    "id_str" : "635975354067353601",
    "text" : "3 mind-bending ways quantum biology might explain everything: http:\/\/t.co\/ZgIsmHL0Mu @jimalkhalili",
    "id" : 635975354067353601,
    "created_at" : "2015-08-25 00:41:54 +0000",
    "user" : {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "protected" : false,
      "id_str" : "15492359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615531317489303552\/pWXT4Dol_normal.png",
      "id" : 15492359,
      "verified" : true
    }
  },
  "id" : 635983709573922816,
  "created_at" : "2015-08-25 01:15:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "indices" : [ 3, 13 ],
      "id_str" : "65698096",
      "id" : 65698096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/LuAeab5amu",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/8\/24\/9195129\/h-r-block",
      "display_url" : "vox.com\/2015\/8\/24\/9195\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635947970026995712",
  "text" : "RT @splcenter: H&amp;R Block snuck language into a Senate bill to make taxes more confusing for poor people http:\/\/t.co\/LuAeab5amu http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/splcenter\/status\/635938424206180352\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/DxvzbTrQBV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNM_4NcWoAAd3wp.png",
        "id_str" : "635922207303180288",
        "id" : 635922207303180288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNM_4NcWoAAd3wp.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/DxvzbTrQBV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/LuAeab5amu",
        "expanded_url" : "http:\/\/www.vox.com\/2015\/8\/24\/9195129\/h-r-block",
        "display_url" : "vox.com\/2015\/8\/24\/9195\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635938424206180352",
    "text" : "H&amp;R Block snuck language into a Senate bill to make taxes more confusing for poor people http:\/\/t.co\/LuAeab5amu http:\/\/t.co\/DxvzbTrQBV",
    "id" : 635938424206180352,
    "created_at" : "2015-08-24 22:15:10 +0000",
    "user" : {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "protected" : false,
      "id_str" : "65698096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798779235825426433\/n3bvatib_normal.jpg",
      "id" : 65698096,
      "verified" : true
    }
  },
  "id" : 635947970026995712,
  "created_at" : "2015-08-24 22:53:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 0, 14 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635933959256428544",
  "geo" : { },
  "id_str" : "635935428844126208",
  "in_reply_to_user_id" : 16494321,
  "text" : "@BrianRathbone ... and the procrastination support group meeting has been moved back indefinitely. :D",
  "id" : 635935428844126208,
  "in_reply_to_status_id" : 635933959256428544,
  "created_at" : "2015-08-24 22:03:16 +0000",
  "in_reply_to_screen_name" : "BrianRathbone",
  "in_reply_to_user_id_str" : "16494321",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/hfXdSFPgrN",
      "expanded_url" : "http:\/\/mynoise.net\/NoiseMachines\/catPurrNoiseGenerator.php?ref=producthunt",
      "display_url" : "mynoise.net\/NoiseMachines\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635861965051703297",
  "text" : "@Skeptical_Lady came across this today &gt; http:\/\/t.co\/hfXdSFPgrN",
  "id" : 635861965051703297,
  "created_at" : "2015-08-24 17:11:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635851073648001024",
  "text" : "new endo came recommended, another said she's very smart so maybe we'll get more info to help pull the strings apart (like mixed up yarn)",
  "id" : 635851073648001024,
  "created_at" : "2015-08-24 16:28:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635846115980525568",
  "geo" : { },
  "id_str" : "635848552846086146",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time we see new endo thurs but thinking it wont be too fruitful. hope she orders more various labs (so more info)",
  "id" : 635848552846086146,
  "in_reply_to_status_id" : 635846115980525568,
  "created_at" : "2015-08-24 16:18:03 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635845655316049920",
  "text" : "she doesnt look sick (for the most part, except episodes, then yes very) and can walk but I know she's not functioning as previous.",
  "id" : 635845655316049920,
  "created_at" : "2015-08-24 16:06:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635844831785418752",
  "text" : "i dont think \"making\" her get out of room \/ walk outside (while good) is going to make sig diff in her QOL or function.",
  "id" : 635844831785418752,
  "created_at" : "2015-08-24 16:03:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635844108775501824",
  "text" : "she doesnt like to sit in living room w tv cuz noise bothers her. bathing is an issue now becuz it makes her feel faint.",
  "id" : 635844108775501824,
  "created_at" : "2015-08-24 16:00:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mecfs",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635842476490772480",
  "text" : "still not sure about #mecfs connection.. DD shares the fatigue.. big issues are nausea, light-headedness, sensory overload, anxiety.",
  "id" : 635842476490772480,
  "created_at" : "2015-08-24 15:53:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "indices" : [ 3, 12 ],
      "id_str" : "11575102",
      "id" : 11575102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635593053567381504",
  "text" : "RT @tifotter: PLEASE: Stop releasing balloons into the sky. Your \"remembrance\" is killing birds, turtles, fish and more. http:\/\/t.co\/c2ZNNV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/c2ZNNVTELk",
        "expanded_url" : "http:\/\/balloonsblow.org\/impacts-on-wildlife-and-environment\/",
        "display_url" : "balloonsblow.org\/impacts-on-wil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635591433928347648",
    "text" : "PLEASE: Stop releasing balloons into the sky. Your \"remembrance\" is killing birds, turtles, fish and more. http:\/\/t.co\/c2ZNNVTELk",
    "id" : 635591433928347648,
    "created_at" : "2015-08-23 23:16:21 +0000",
    "user" : {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "protected" : false,
      "id_str" : "11575102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579777071850737664\/0bwnd0kt_normal.jpg",
      "id" : 11575102,
      "verified" : false
    }
  },
  "id" : 635593053567381504,
  "created_at" : "2015-08-23 23:22:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/gnfFLhaukz",
      "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/635487933034831872",
      "display_url" : "twitter.com\/Brasilmagic\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635518660535263232",
  "text" : "some perspective for christians feeling persecuted... https:\/\/t.co\/gnfFLhaukz",
  "id" : 635518660535263232,
  "created_at" : "2015-08-23 18:27:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Dave Weigel",
      "screen_name" : "daveweigel",
      "indices" : [ 30, 41 ],
      "id_str" : "13524182",
      "id" : 13524182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635462074743832576",
  "text" : "RT @onealexharms: Holy hell. \u201C@daveweigel: Transcribing this interview with a white Alabama farmer is going well so far http:\/\/t.co\/g1csapV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave Weigel",
        "screen_name" : "daveweigel",
        "indices" : [ 12, 23 ],
        "id_str" : "13524182",
        "id" : 13524182
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/daveweigel\/status\/635082004648734720\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/g1csapVOMT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNBDswGWgAAZ29f.png",
        "id_str" : "635081983564087296",
        "id" : 635081983564087296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNBDswGWgAAZ29f.png",
        "sizes" : [ {
          "h" : 86,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 86,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 86,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 86,
          "resize" : "crop",
          "w" : 86
        }, {
          "h" : 52,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g1csapVOMT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "635082004648734720",
    "geo" : { },
    "id_str" : "635416595259617280",
    "in_reply_to_user_id" : 13524182,
    "text" : "Holy hell. \u201C@daveweigel: Transcribing this interview with a white Alabama farmer is going well so far http:\/\/t.co\/g1csapVOMT\u201D",
    "id" : 635416595259617280,
    "in_reply_to_status_id" : 635082004648734720,
    "created_at" : "2015-08-23 11:41:36 +0000",
    "in_reply_to_screen_name" : "daveweigel",
    "in_reply_to_user_id_str" : "13524182",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 635462074743832576,
  "created_at" : "2015-08-23 14:42:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 3, 17 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635272486268051457",
  "text" : "RT @johnnie_cakes: Sweet Jesus. It's a wonder that anyone ever actually has a wedding. How do people not murder each other trying to plan t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635271853330726912",
    "text" : "Sweet Jesus. It's a wonder that anyone ever actually has a wedding. How do people not murder each other trying to plan this shit?",
    "id" : 635271853330726912,
    "created_at" : "2015-08-23 02:06:27 +0000",
    "user" : {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "protected" : false,
      "id_str" : "16901470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765066200657166336\/h3XngAjO_normal.jpg",
      "id" : 16901470,
      "verified" : false
    }
  },
  "id" : 635272486268051457,
  "created_at" : "2015-08-23 02:08:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qdsmaenHPP",
      "expanded_url" : "http:\/\/qvotr.com\/quote\/3809",
      "display_url" : "qvotr.com\/quote\/3809"
    } ]
  },
  "geo" : { },
  "id_str" : "635261561829986304",
  "text" : "\"Sexual sins committed by men were blamed exclusively on their female partners or...\" http:\/\/t.co\/qdsmaenHPP",
  "id" : 635261561829986304,
  "created_at" : "2015-08-23 01:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635248511018233857",
  "geo" : { },
  "id_str" : "635250992003567620",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms ((hugs))",
  "id" : 635250992003567620,
  "in_reply_to_status_id" : 635248511018233857,
  "created_at" : "2015-08-23 00:43:33 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635223398734499840",
  "geo" : { },
  "id_str" : "635234294017978368",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe i keep trying to learn how to knit...",
  "id" : 635234294017978368,
  "in_reply_to_status_id" : 635223398734499840,
  "created_at" : "2015-08-22 23:37:12 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline",
      "screen_name" : "paulinedaniels",
      "indices" : [ 3, 18 ],
      "id_str" : "270008646",
      "id" : 270008646
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paulinedaniels\/status\/635195281835970561\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/38pSUgvbXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNCqvIwWcAIEo7B.jpg",
      "id_str" : "635195274240094210",
      "id" : 635195274240094210,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNCqvIwWcAIEo7B.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/38pSUgvbXO"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/paulinedaniels\/status\/635195281835970561\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/38pSUgvbXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNCqvUiWoAAnKTr.jpg",
      "id_str" : "635195277402611712",
      "id" : 635195277402611712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNCqvUiWoAAnKTr.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/38pSUgvbXO"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/paulinedaniels\/status\/635195281835970561\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/38pSUgvbXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNCqvWuW8AA-rVZ.jpg",
      "id_str" : "635195277989834752",
      "id" : 635195277989834752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNCqvWuW8AA-rVZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/38pSUgvbXO"
    } ],
    "hashtags" : [ {
      "text" : "highland",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635212213243015168",
  "text" : "RT @paulinedaniels: The babies.. #highland coos..!! http:\/\/t.co\/38pSUgvbXO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paulinedaniels\/status\/635195281835970561\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/38pSUgvbXO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNCqvIwWcAIEo7B.jpg",
        "id_str" : "635195274240094210",
        "id" : 635195274240094210,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNCqvIwWcAIEo7B.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/38pSUgvbXO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/paulinedaniels\/status\/635195281835970561\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/38pSUgvbXO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNCqvUiWoAAnKTr.jpg",
        "id_str" : "635195277402611712",
        "id" : 635195277402611712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNCqvUiWoAAnKTr.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/38pSUgvbXO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/paulinedaniels\/status\/635195281835970561\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/38pSUgvbXO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNCqvWuW8AA-rVZ.jpg",
        "id_str" : "635195277989834752",
        "id" : 635195277989834752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNCqvWuW8AA-rVZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/38pSUgvbXO"
      } ],
      "hashtags" : [ {
        "text" : "highland",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635195281835970561",
    "text" : "The babies.. #highland coos..!! http:\/\/t.co\/38pSUgvbXO",
    "id" : 635195281835970561,
    "created_at" : "2015-08-22 21:02:11 +0000",
    "user" : {
      "name" : "Pauline",
      "screen_name" : "paulinedaniels",
      "protected" : false,
      "id_str" : "270008646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782708879268442112\/DR9uEZCv_normal.jpg",
      "id" : 270008646,
      "verified" : false
    }
  },
  "id" : 635212213243015168,
  "created_at" : "2015-08-22 22:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/h6DRUIwFXQ",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1G4fjurmfaCsMYL_mQF8loSZvNrCmyeoYE7dx5flfkiE\/edit?usp=sharing",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635170347357224960",
  "text" : "still needs tweaking &gt; Copy of 2015-health-medications-sampledata https:\/\/t.co\/h6DRUIwFXQ",
  "id" : 635170347357224960,
  "created_at" : "2015-08-22 19:23:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyme",
      "indices" : [ 113, 118 ]
    }, {
      "text" : "Bartonella",
      "indices" : [ 119, 130 ]
    }, {
      "text" : "psych",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/C3bJzTl5od",
      "expanded_url" : "http:\/\/Sott.net",
      "display_url" : "Sott.net"
    } ]
  },
  "geo" : { },
  "id_str" : "635162278153879552",
  "text" : "RT @AlisynGayle: Antibiotics found effective in schizophrenia -- Health &amp; Wellness -- http:\/\/t.co\/C3bJzTl5od\n#Lyme #Bartonella #psych http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lyme",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "Bartonella",
        "indices" : [ 102, 113 ]
      }, {
        "text" : "psych",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/C3bJzTl5od",
        "expanded_url" : "http:\/\/Sott.net",
        "display_url" : "Sott.net"
      }, {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/tSWpzwMeS4",
        "expanded_url" : "http:\/\/www.sott.net\/article\/300497-Antibiotics-found-effective-in-schizophrenia",
        "display_url" : "sott.net\/article\/300497\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635142030960783360",
    "text" : "Antibiotics found effective in schizophrenia -- Health &amp; Wellness -- http:\/\/t.co\/C3bJzTl5od\n#Lyme #Bartonella #psych http:\/\/t.co\/tSWpzwMeS4",
    "id" : 635142030960783360,
    "created_at" : "2015-08-22 17:30:35 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 635162278153879552,
  "created_at" : "2015-08-22 18:51:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635141365597208576",
  "geo" : { },
  "id_str" : "635161972158386176",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley looking at pics realized that hat would make great round pillow! such a pretty design. &lt;3",
  "id" : 635161972158386176,
  "in_reply_to_status_id" : 635141365597208576,
  "created_at" : "2015-08-22 18:49:49 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/23Qwf8FQWY",
      "expanded_url" : "https:\/\/twitter.com\/HWarlow\/status\/635145386580135936",
      "display_url" : "twitter.com\/HWarlow\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635149919481921536",
  "text" : "pretty https:\/\/t.co\/23Qwf8FQWY",
  "id" : 635149919481921536,
  "created_at" : "2015-08-22 18:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Kosmatka",
      "screen_name" : "TKosmatka",
      "indices" : [ 3, 13 ],
      "id_str" : "521928542",
      "id" : 521928542
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TKosmatka\/status\/634881760044560384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ylBO7UO7ML",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM-Nl90UAAA48VQ.jpg",
      "id_str" : "634881755871182848",
      "id" : 634881755871182848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM-Nl90UAAA48VQ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ylBO7UO7ML"
    } ],
    "hashtags" : [ {
      "text" : "Sasquan",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635116489968910336",
  "text" : "RT @TKosmatka: No special effects on this.  I just snapped a pic of the sun through the smoke in Spokane.   #Sasquan http:\/\/t.co\/ylBO7UO7ML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TKosmatka\/status\/634881760044560384\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ylBO7UO7ML",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM-Nl90UAAA48VQ.jpg",
        "id_str" : "634881755871182848",
        "id" : 634881755871182848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM-Nl90UAAA48VQ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ylBO7UO7ML"
      } ],
      "hashtags" : [ {
        "text" : "Sasquan",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634881760044560384",
    "text" : "No special effects on this.  I just snapped a pic of the sun through the smoke in Spokane.   #Sasquan http:\/\/t.co\/ylBO7UO7ML",
    "id" : 634881760044560384,
    "created_at" : "2015-08-22 00:16:21 +0000",
    "user" : {
      "name" : "Ted Kosmatka",
      "screen_name" : "TKosmatka",
      "protected" : false,
      "id_str" : "521928542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487872277690580993\/BBmxfQTA_normal.jpeg",
      "id" : 521928542,
      "verified" : false
    }
  },
  "id" : 635116489968910336,
  "created_at" : "2015-08-22 15:49:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634986272767938560",
  "geo" : { },
  "id_str" : "635116304194772993",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe yup.",
  "id" : 635116304194772993,
  "in_reply_to_status_id" : 634986272767938560,
  "created_at" : "2015-08-22 15:48:21 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOP_Pussy_Grabber",
      "screen_name" : "CJFinNM",
      "indices" : [ 3, 11 ],
      "id_str" : "28847899",
      "id" : 28847899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Prolife",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/9156yx7xzr",
      "expanded_url" : "http:\/\/m.huffpost.com\/us\/entry\/55d734b9e4b0a40aa3aa8eee",
      "display_url" : "m.huffpost.com\/us\/entry\/55d73\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635114191528062976",
  "text" : "RT @CJFinNM: Anti-abortion stickers on Arizona biology textbooks http:\/\/t.co\/9156yx7xzr #Prolife Group = \"Birth 'em THEN Starve 'em THEN ca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Prolife",
        "indices" : [ 75, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/9156yx7xzr",
        "expanded_url" : "http:\/\/m.huffpost.com\/us\/entry\/55d734b9e4b0a40aa3aa8eee",
        "display_url" : "m.huffpost.com\/us\/entry\/55d73\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635098568093597697",
    "text" : "Anti-abortion stickers on Arizona biology textbooks http:\/\/t.co\/9156yx7xzr #Prolife Group = \"Birth 'em THEN Starve 'em THEN call 'em Takers\"",
    "id" : 635098568093597697,
    "created_at" : "2015-08-22 14:37:52 +0000",
    "user" : {
      "name" : "GOP_Pussy_Grabber",
      "screen_name" : "CJFinNM",
      "protected" : false,
      "id_str" : "28847899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798676374995116033\/7htCq0km_normal.jpg",
      "id" : 28847899,
      "verified" : false
    }
  },
  "id" : 635114191528062976,
  "created_at" : "2015-08-22 15:39:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/4TaIl5dFGe",
      "expanded_url" : "http:\/\/wp.me\/p4x3Dw-2B",
      "display_url" : "wp.me\/p4x3Dw-2B"
    } ]
  },
  "geo" : { },
  "id_str" : "634909915925094400",
  "text" : "A day in the life of an ME sufferer http:\/\/t.co\/4TaIl5dFGe #chronicillness",
  "id" : 634909915925094400,
  "created_at" : "2015-08-22 02:08:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/GIRP9HaxHD",
      "expanded_url" : "http:\/\/paloaltoonline.com\/news\/2015\/07\/10\/chronic-fatigue-syndrome-saps-its-victims-but-new-research-may-find-the-cause#.Vde7d46wFgN.twitter",
      "display_url" : "paloaltoonline.com\/news\/2015\/07\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634877730266460161",
  "text" : "Chronic fatigue syndrome saps its victims, but new research may find the cause | News | Palo Alto Online | http:\/\/t.co\/GIRP9HaxHD",
  "id" : 634877730266460161,
  "created_at" : "2015-08-22 00:00:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634869691207557121",
  "geo" : { },
  "id_str" : "634870825221517312",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre thanks muchly, my sweet. : )",
  "id" : 634870825221517312,
  "in_reply_to_status_id" : 634869691207557121,
  "created_at" : "2015-08-21 23:32:54 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634867966862082054",
  "geo" : { },
  "id_str" : "634869160758124545",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre no.. ((adds to list to check))",
  "id" : 634869160758124545,
  "in_reply_to_status_id" : 634867966862082054,
  "created_at" : "2015-08-21 23:26:17 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634865122259902464",
  "text" : "i might have to make 2 sheets.. one with date of prescription, then other with start\/stop\/change.. hmm...",
  "id" : 634865122259902464,
  "created_at" : "2015-08-21 23:10:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634864567483502592",
  "text" : "see, there's temp meds, ongoing meds, changing amounts.. like taking 1\/4 pill, then 1\/2. im trying to track on 1 sheet by date going forward",
  "id" : 634864567483502592,
  "created_at" : "2015-08-21 23:08:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 3, 18 ],
      "id_str" : "582993732",
      "id" : 582993732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634862857558073344",
  "text" : "RT @DefendTheSheep: Can we now admit that Patriarchy doesn't work. The loudest proponents of it have failed with sex abuse scandals harming\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606646525251297280",
    "text" : "Can we now admit that Patriarchy doesn't work. The loudest proponents of it have failed with sex abuse scandals harming women\/girls.",
    "id" : 606646525251297280,
    "created_at" : "2015-06-05 02:19:37 +0000",
    "user" : {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "protected" : false,
      "id_str" : "582993732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719282831931781120\/BB0VrKyw_normal.jpg",
      "id" : 582993732,
      "verified" : false
    }
  },
  "id" : 634862857558073344,
  "created_at" : "2015-08-21 23:01:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634857733771104256",
  "text" : "playing w meds spreadsheet. have all meds rx'd, taken and not taken, in a date descending format.",
  "id" : 634857733771104256,
  "created_at" : "2015-08-21 22:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Z Photography",
      "screen_name" : "DaveZ_uk",
      "indices" : [ 3, 12 ],
      "id_str" : "482457738",
      "id" : 482457738
    }, {
      "name" : "Deborah Meaden",
      "screen_name" : "DeborahMeaden",
      "indices" : [ 35, 49 ],
      "id_str" : "368240745",
      "id" : 368240745
    }, {
      "name" : "Sarah Willingham",
      "screen_name" : "sarahwillers",
      "indices" : [ 96, 109 ],
      "id_str" : "236346272",
      "id" : 236346272
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DaveZ_uk\/status\/634826440844963840\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/WKw3iYWP3a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9bROUWUAA4YzF.jpg",
      "id_str" : "634826423941877760",
      "id" : 634826423941877760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9bROUWUAA4YzF.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WKw3iYWP3a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634838746140180481",
  "text" : "RT @DaveZ_uk: Here's one you &amp; @DeborahMeaden will like. A pic I took of Mike the horse :) \n@sarahwillers http:\/\/t.co\/WKw3iYWP3a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deborah Meaden",
        "screen_name" : "DeborahMeaden",
        "indices" : [ 21, 35 ],
        "id_str" : "368240745",
        "id" : 368240745
      }, {
        "name" : "Sarah Willingham",
        "screen_name" : "sarahwillers",
        "indices" : [ 82, 95 ],
        "id_str" : "236346272",
        "id" : 236346272
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DaveZ_uk\/status\/634826440844963840\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/WKw3iYWP3a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9bROUWUAA4YzF.jpg",
        "id_str" : "634826423941877760",
        "id" : 634826423941877760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9bROUWUAA4YzF.jpg",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WKw3iYWP3a"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634826440844963840",
    "text" : "Here's one you &amp; @DeborahMeaden will like. A pic I took of Mike the horse :) \n@sarahwillers http:\/\/t.co\/WKw3iYWP3a",
    "id" : 634826440844963840,
    "created_at" : "2015-08-21 20:36:32 +0000",
    "user" : {
      "name" : "Dave Z Photography",
      "screen_name" : "DaveZ_uk",
      "protected" : false,
      "id_str" : "482457738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798226786790375424\/KwoJAgM3_normal.jpg",
      "id" : 482457738,
      "verified" : true
    }
  },
  "id" : 634838746140180481,
  "created_at" : "2015-08-21 21:25:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 0, 16 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634835966994223104",
  "geo" : { },
  "id_str" : "634836291356622848",
  "in_reply_to_user_id" : 24233147,
  "text" : "@fairlyspiritual makes me want to read on.. lol",
  "id" : 634836291356622848,
  "in_reply_to_status_id" : 634835966994223104,
  "created_at" : "2015-08-21 21:15:41 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634836015123943424",
  "text" : "ppl tell her get out of room, sit outside, exercise. but fatigue and sensory overload. trying to avoid trigg another episode.",
  "id" : 634836015123943424,
  "created_at" : "2015-08-21 21:14:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meds",
      "indices" : [ 56, 61 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "sick",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634835186153320448",
  "text" : "ativan, metoclopramide, ranitidine, levothyroxine daily #meds #hashimotos #thyroid #sick - ativan keeps us out of ER",
  "id" : 634835186153320448,
  "created_at" : "2015-08-21 21:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634834306020569088",
  "text" : "u\/s #thyroid \"unremarkable\" but her neck throbs daily. she mostly sleeps. gets up for short time when feeling less icky.",
  "id" : 634834306020569088,
  "created_at" : "2015-08-21 21:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634832828321136640",
  "text" : "yesterday we upped from 1\/4 to 1\/2 pill (of 10 mg pill) prednisone. nothing seems to change symptoms.",
  "id" : 634832828321136640,
  "created_at" : "2015-08-21 21:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/mMBCF2eqaZ",
      "expanded_url" : "https:\/\/projects.propublica.org\/docdollars\/company\/",
      "display_url" : "projects.propublica.org\/docdollars\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634831726032912384",
  "text" : "RT @AlisynGayle: ProPublica Dollars for Docs-Companies Making Payments https:\/\/t.co\/mMBCF2eqaZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/mMBCF2eqaZ",
        "expanded_url" : "https:\/\/projects.propublica.org\/docdollars\/company\/",
        "display_url" : "projects.propublica.org\/docdollars\/com\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634822582601166848",
    "text" : "ProPublica Dollars for Docs-Companies Making Payments https:\/\/t.co\/mMBCF2eqaZ",
    "id" : 634822582601166848,
    "created_at" : "2015-08-21 20:21:12 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 634831726032912384,
  "created_at" : "2015-08-21 20:57:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/634804020054491136\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/rfRWiLY1Xs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9G1ZZWEAAR5KA.jpg",
      "id_str" : "634803955646730240",
      "id" : 634803955646730240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9G1ZZWEAAR5KA.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rfRWiLY1Xs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/634804020054491136\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/rfRWiLY1Xs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9G1ZpWcAAntn_.jpg",
      "id_str" : "634803955713863680",
      "id" : 634803955713863680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9G1ZpWcAAntn_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rfRWiLY1Xs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/634804020054491136\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/rfRWiLY1Xs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9G1aDWIAAo27U.jpg",
      "id_str" : "634803955822895104",
      "id" : 634803955822895104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9G1aDWIAAo27U.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rfRWiLY1Xs"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634831531492683777",
  "text" : "RT @dailyMorag: Morag &amp; Mrs Hooper #dailyMorag http:\/\/t.co\/rfRWiLY1Xs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/634804020054491136\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/rfRWiLY1Xs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9G1ZZWEAAR5KA.jpg",
        "id_str" : "634803955646730240",
        "id" : 634803955646730240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9G1ZZWEAAR5KA.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rfRWiLY1Xs"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/634804020054491136\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/rfRWiLY1Xs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9G1ZpWcAAntn_.jpg",
        "id_str" : "634803955713863680",
        "id" : 634803955713863680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9G1ZpWcAAntn_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rfRWiLY1Xs"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/634804020054491136\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/rfRWiLY1Xs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9G1aDWIAAo27U.jpg",
        "id_str" : "634803955822895104",
        "id" : 634803955822895104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9G1aDWIAAo27U.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rfRWiLY1Xs"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634804020054491136",
    "text" : "Morag &amp; Mrs Hooper #dailyMorag http:\/\/t.co\/rfRWiLY1Xs",
    "id" : 634804020054491136,
    "created_at" : "2015-08-21 19:07:27 +0000",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 634831531492683777,
  "created_at" : "2015-08-21 20:56:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K\u00F3sm\u03C3Zo\u0331an",
      "screen_name" : "Kosmozoan",
      "indices" : [ 3, 13 ],
      "id_str" : "415156476",
      "id" : 415156476
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Atheism",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634819914721853440",
  "text" : "RT @Kosmozoan: #Atheism is not an immoral philosophy, nor is it a moral one; it is merely the absence of belief in supernatural beings, and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Atheism",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634818417459990529",
    "text" : "#Atheism is not an immoral philosophy, nor is it a moral one; it is merely the absence of belief in supernatural beings, and nothing more.",
    "id" : 634818417459990529,
    "created_at" : "2015-08-21 20:04:39 +0000",
    "user" : {
      "name" : "K\u00F3sm\u03C3Zo\u0331an",
      "screen_name" : "Kosmozoan",
      "protected" : false,
      "id_str" : "415156476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684899419473330177\/QonN3JzS_normal.jpg",
      "id" : 415156476,
      "verified" : false
    }
  },
  "id" : 634819914721853440,
  "created_at" : "2015-08-21 20:10:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/z3FHX4MDqH",
      "expanded_url" : "http:\/\/www.rockpapershotgun.com\/2015\/08\/20\/viridi-review\/",
      "display_url" : "rockpapershotgun.com\/2015\/08\/20\/vir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634801645424144384",
  "text" : "funny &gt;&gt; Wot I Think (And Wot I Murdered): Viridi http:\/\/t.co\/z3FHX4MDqH",
  "id" : 634801645424144384,
  "created_at" : "2015-08-21 18:58:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "Willow",
      "screen_name" : "serious_skeptic",
      "indices" : [ 20, 36 ],
      "id_str" : "18151975",
      "id" : 18151975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634792161641373698",
  "text" : "RT @AlisynGayle: RT @serious_skeptic: Hey, viciously pro-GMO people who refuse to think outside your dogma, please see below: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Willow",
        "screen_name" : "serious_skeptic",
        "indices" : [ 3, 19 ],
        "id_str" : "18151975",
        "id" : 18151975
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/3fmYCfJXaR",
        "expanded_url" : "https:\/\/twitter.com\/DrRonaldHoffman\/status\/634174779726106624",
        "display_url" : "twitter.com\/DrRonaldHoffma\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "634779787941277697",
    "geo" : { },
    "id_str" : "634790847092015107",
    "in_reply_to_user_id" : 18151975,
    "text" : "RT @serious_skeptic: Hey, viciously pro-GMO people who refuse to think outside your dogma, please see below: https:\/\/t.co\/3fmYCfJXaR",
    "id" : 634790847092015107,
    "in_reply_to_status_id" : 634779787941277697,
    "created_at" : "2015-08-21 18:15:06 +0000",
    "in_reply_to_screen_name" : "serious_skeptic",
    "in_reply_to_user_id_str" : "18151975",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 634792161641373698,
  "created_at" : "2015-08-21 18:20:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Moberg \uD83D\uDCCE",
      "screen_name" : "Runaway_Writes",
      "indices" : [ 0, 15 ],
      "id_str" : "818384298",
      "id" : 818384298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634788841916776448",
  "geo" : { },
  "id_str" : "634789994863812608",
  "in_reply_to_user_id" : 818384298,
  "text" : "@Runaway_Writes yeah.. your comment exactly. I'm not repub but watched debate, was thrilled his comment on gay.",
  "id" : 634789994863812608,
  "in_reply_to_status_id" : 634788841916776448,
  "created_at" : "2015-08-21 18:11:43 +0000",
  "in_reply_to_screen_name" : "Runaway_Writes",
  "in_reply_to_user_id_str" : "818384298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "It's Tina, Bitches",
      "screen_name" : "sookie_fied",
      "indices" : [ 13, 25 ],
      "id_str" : "22808711",
      "id" : 22808711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634759612022030336",
  "geo" : { },
  "id_str" : "634767646324576257",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle @sookie_fied this! ...trying to sort out what's what.",
  "id" : 634767646324576257,
  "in_reply_to_status_id" : 634759612022030336,
  "created_at" : "2015-08-21 16:42:54 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "windowsphone",
      "indices" : [ 58, 71 ]
    }, {
      "text" : "feedly",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/uwBcPZIGq8",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/windowsphone\/comments\/3hsyg1\/translators_needed_for_audiobooked\/",
      "display_url" : "reddit.com\/r\/windowsphone\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634746703082582017",
  "text" : "Translators needed for Audiobooked http:\/\/t.co\/uwBcPZIGq8 #windowsphone #feedly",
  "id" : 634746703082582017,
  "created_at" : "2015-08-21 15:19:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634714770051100672",
  "text" : "RT @dhammagirl: For a few moments think of something\/someone you really Love, that  makes you Happy.\n\nReally FEEL it\n\nVisit this place thro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634690191568072704",
    "text" : "For a few moments think of something\/someone you really Love, that  makes you Happy.\n\nReally FEEL it\n\nVisit this place throughout the day!",
    "id" : 634690191568072704,
    "created_at" : "2015-08-21 11:35:08 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 634714770051100672,
  "created_at" : "2015-08-21 13:12:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/lLFtX9vTdc",
      "expanded_url" : "https:\/\/instagram.com\/p\/6oNtO9hH_v\/",
      "display_url" : "instagram.com\/p\/6oNtO9hH_v\/"
    } ]
  },
  "geo" : { },
  "id_str" : "634552897573883904",
  "text" : "RT @ducksandclucks: Teddy sleeps with his body outside but his head tucked inside the A-frame. He's a weirdo. https:\/\/t.co\/lLFtX9vTdc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/lLFtX9vTdc",
        "expanded_url" : "https:\/\/instagram.com\/p\/6oNtO9hH_v\/",
        "display_url" : "instagram.com\/p\/6oNtO9hH_v\/"
      } ]
    },
    "geo" : { },
    "id_str" : "634549821374861316",
    "text" : "Teddy sleeps with his body outside but his head tucked inside the A-frame. He's a weirdo. https:\/\/t.co\/lLFtX9vTdc",
    "id" : 634549821374861316,
    "created_at" : "2015-08-21 02:17:21 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 634552897573883904,
  "created_at" : "2015-08-21 02:29:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/AjhVi0IqYa",
      "expanded_url" : "https:\/\/twitter.com\/MECFSisReal\/status\/634373851602944000",
      "display_url" : "twitter.com\/MECFSisReal\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634546337455960065",
  "text" : "cc: @JourneyTheHedgi   https:\/\/t.co\/AjhVi0IqYa",
  "id" : 634546337455960065,
  "created_at" : "2015-08-21 02:03:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/R9Vqi8DwK9",
      "expanded_url" : "https:\/\/twitter.com\/dhammagirl\/status\/634532501122351104",
      "display_url" : "twitter.com\/dhammagirl\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634534597888483329",
  "text" : "yes! https:\/\/t.co\/R9Vqi8DwK9",
  "id" : 634534597888483329,
  "created_at" : "2015-08-21 01:16:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "indices" : [ 3, 12 ],
      "id_str" : "11575102",
      "id" : 11575102
    }, {
      "name" : "SLC Police Dept.",
      "screen_name" : "slcpd",
      "indices" : [ 119, 125 ],
      "id_str" : "18775270",
      "id" : 18775270
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Farmington",
      "indices" : [ 32, 43 ]
    }, {
      "text" : "utpol",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/SKIfKoDjxJ",
      "expanded_url" : "http:\/\/kutv.com\/news\/local\/slc-animal-activists-facing-6-months-in-jail-for-lagoon-zoo-protests",
      "display_url" : "kutv.com\/news\/local\/slc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634534303012122626",
  "text" : "RT @tifotter: This. Is. Idiocy. #Farmington you're an embarrassment. http:\/\/t.co\/SKIfKoDjxJ #utpol I will find out why @slcpd resources wer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SLC Police Dept.",
        "screen_name" : "slcpd",
        "indices" : [ 105, 111 ],
        "id_str" : "18775270",
        "id" : 18775270
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Farmington",
        "indices" : [ 18, 29 ]
      }, {
        "text" : "utpol",
        "indices" : [ 78, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/SKIfKoDjxJ",
        "expanded_url" : "http:\/\/kutv.com\/news\/local\/slc-animal-activists-facing-6-months-in-jail-for-lagoon-zoo-protests",
        "display_url" : "kutv.com\/news\/local\/slc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634532679120257024",
    "text" : "This. Is. Idiocy. #Farmington you're an embarrassment. http:\/\/t.co\/SKIfKoDjxJ #utpol I will find out why @slcpd resources were utilized.",
    "id" : 634532679120257024,
    "created_at" : "2015-08-21 01:09:14 +0000",
    "user" : {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "protected" : false,
      "id_str" : "11575102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579777071850737664\/0bwnd0kt_normal.jpg",
      "id" : 11575102,
      "verified" : false
    }
  },
  "id" : 634534303012122626,
  "created_at" : "2015-08-21 01:15:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wtf renaissance",
      "screen_name" : "WtfRenaissance",
      "indices" : [ 3, 18 ],
      "id_str" : "2710715024",
      "id" : 2710715024
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WtfRenaissance\/status\/634324068515221505\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/oI7MTwAOpk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM2SYNwUEAEy85V.jpg",
      "id_str" : "634324067235926017",
      "id" : 634324067235926017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM2SYNwUEAEy85V.jpg",
      "sizes" : [ {
        "h" : 792,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oI7MTwAOpk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634534125421076481",
  "text" : "RT @WtfRenaissance: Shortly after this incident, Tina would have her zoo membership revoked. http:\/\/t.co\/oI7MTwAOpk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WtfRenaissance\/status\/634324068515221505\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/oI7MTwAOpk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM2SYNwUEAEy85V.jpg",
        "id_str" : "634324067235926017",
        "id" : 634324067235926017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM2SYNwUEAEy85V.jpg",
        "sizes" : [ {
          "h" : 792,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 269,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oI7MTwAOpk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634324068515221505",
    "text" : "Shortly after this incident, Tina would have her zoo membership revoked. http:\/\/t.co\/oI7MTwAOpk",
    "id" : 634324068515221505,
    "created_at" : "2015-08-20 11:20:17 +0000",
    "user" : {
      "name" : "wtf renaissance",
      "screen_name" : "WtfRenaissance",
      "protected" : false,
      "id_str" : "2710715024",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496822533560074240\/FTSKbLb9_normal.jpeg",
      "id" : 2710715024,
      "verified" : false
    }
  },
  "id" : 634534125421076481,
  "created_at" : "2015-08-21 01:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cara Taylor",
      "screen_name" : "CaraLTaylor",
      "indices" : [ 3, 15 ],
      "id_str" : "22633156",
      "id" : 22633156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/w3eXekvNtC",
      "expanded_url" : "http:\/\/m.dailykos.com\/stories\/1413097",
      "display_url" : "m.dailykos.com\/stories\/1413097"
    } ]
  },
  "geo" : { },
  "id_str" : "634519826980040708",
  "text" : "RT @CaraLTaylor: Exhaustive new study finds black jurors struck from juries 300% more than their white peers http:\/\/t.co\/w3eXekvNtC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/w3eXekvNtC",
        "expanded_url" : "http:\/\/m.dailykos.com\/stories\/1413097",
        "display_url" : "m.dailykos.com\/stories\/1413097"
      } ]
    },
    "geo" : { },
    "id_str" : "634464755898580992",
    "text" : "Exhaustive new study finds black jurors struck from juries 300% more than their white peers http:\/\/t.co\/w3eXekvNtC",
    "id" : 634464755898580992,
    "created_at" : "2015-08-20 20:39:20 +0000",
    "user" : {
      "name" : "Cara Taylor",
      "screen_name" : "CaraLTaylor",
      "protected" : false,
      "id_str" : "22633156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3308214018\/5f0ce682922a41708cfbfb50e1ab2263_normal.jpeg",
      "id" : 22633156,
      "verified" : false
    }
  },
  "id" : 634519826980040708,
  "created_at" : "2015-08-21 00:18:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reversesleep",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634507882155888640",
  "geo" : { },
  "id_str" : "634519775662743553",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe DD is more night owl. anything b4 noon is too early. but she also has reg insomnia. #reversesleep",
  "id" : 634519775662743553,
  "in_reply_to_status_id" : 634507882155888640,
  "created_at" : "2015-08-21 00:17:57 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#NativeBreeds",
      "screen_name" : "nativebreedsGB",
      "indices" : [ 3, 18 ],
      "id_str" : "2377830169",
      "id" : 2377830169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "farm24",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634491779417526272",
  "text" : "RT @nativebreedsGB: What's that thing your poking in my face, do I get any royalties if my picture appears on this #farm24 thing http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/adrianjcl123\/status\/634465193247031296\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/x9gZlKEWTj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4SuwCXAAAw0dv.jpg",
        "id_str" : "634465191883898880",
        "id" : 634465191883898880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4SuwCXAAAw0dv.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/x9gZlKEWTj"
      } ],
      "hashtags" : [ {
        "text" : "farm24",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634465616007663618",
    "text" : "What's that thing your poking in my face, do I get any royalties if my picture appears on this #farm24 thing http:\/\/t.co\/x9gZlKEWTj\"",
    "id" : 634465616007663618,
    "created_at" : "2015-08-20 20:42:45 +0000",
    "user" : {
      "name" : "#NativeBreeds",
      "screen_name" : "nativebreedsGB",
      "protected" : false,
      "id_str" : "2377830169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442108576383762432\/tyd5CC9o_normal.jpeg",
      "id" : 2377830169,
      "verified" : false
    }
  },
  "id" : 634491779417526272,
  "created_at" : "2015-08-20 22:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634390032523112448",
  "geo" : { },
  "id_str" : "634475634086019072",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ugh...",
  "id" : 634475634086019072,
  "in_reply_to_status_id" : 634390032523112448,
  "created_at" : "2015-08-20 21:22:33 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/7CKzDPqC1C",
      "expanded_url" : "https:\/\/twitter.com\/suzanne_young\/status\/634134917769654272",
      "display_url" : "twitter.com\/suzanne_young\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634472297936592897",
  "text" : "whaa?? https:\/\/t.co\/7CKzDPqC1C",
  "id" : 634472297936592897,
  "created_at" : "2015-08-20 21:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634422633476452353",
  "geo" : { },
  "id_str" : "634471974379646977",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ohh.. eww. poor birdy.",
  "id" : 634471974379646977,
  "in_reply_to_status_id" : 634422633476452353,
  "created_at" : "2015-08-20 21:08:01 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dolphin Project",
      "screen_name" : "Dolphin_Project",
      "indices" : [ 3, 19 ],
      "id_str" : "378746121",
      "id" : 378746121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DolphinProject",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/GapjXgv2TF",
      "expanded_url" : "https:\/\/goo.gl\/EKciE2",
      "display_url" : "goo.gl\/EKciE2"
    } ]
  },
  "geo" : { },
  "id_str" : "634471281065377793",
  "text" : "RT @Dolphin_Project: Dolphin hunting season begins Sept 1st in Japan\n\nYou can help end it: https:\/\/t.co\/GapjXgv2TF #DolphinProject http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dolphin_Project\/status\/632626088259096576\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/U6MUjcOcMg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeKEzfUEAEVpvz.jpg",
        "id_str" : "632626087814500353",
        "id" : 632626087814500353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeKEzfUEAEVpvz.jpg",
        "sizes" : [ {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 692
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 692
        } ],
        "display_url" : "pic.twitter.com\/U6MUjcOcMg"
      } ],
      "hashtags" : [ {
        "text" : "DolphinProject",
        "indices" : [ 94, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/GapjXgv2TF",
        "expanded_url" : "https:\/\/goo.gl\/EKciE2",
        "display_url" : "goo.gl\/EKciE2"
      } ]
    },
    "geo" : { },
    "id_str" : "632626088259096576",
    "text" : "Dolphin hunting season begins Sept 1st in Japan\n\nYou can help end it: https:\/\/t.co\/GapjXgv2TF #DolphinProject http:\/\/t.co\/U6MUjcOcMg",
    "id" : 632626088259096576,
    "created_at" : "2015-08-15 18:53:07 +0000",
    "user" : {
      "name" : "Dolphin Project",
      "screen_name" : "Dolphin_Project",
      "protected" : false,
      "id_str" : "378746121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695636571366686720\/2EBEENiC_normal.jpg",
      "id" : 378746121,
      "verified" : true
    }
  },
  "id" : 634471281065377793,
  "created_at" : "2015-08-20 21:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/634467112933814273\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/2Kfa3fib5H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4UWXkWUAAOWoZ.jpg",
      "id_str" : "634466972021968896",
      "id" : 634466972021968896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4UWXkWUAAOWoZ.jpg",
      "sizes" : [ {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2Kfa3fib5H"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/634467112933814273\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/2Kfa3fib5H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4UaY1WUAA1K58.jpg",
      "id_str" : "634467041081184256",
      "id" : 634467041081184256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4UaY1WUAA1K58.jpg",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2Kfa3fib5H"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/634467112933814273\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/2Kfa3fib5H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4Ued0WwAAnMol.jpg",
      "id_str" : "634467111138672640",
      "id" : 634467111138672640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4Ued0WwAAnMol.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2Kfa3fib5H"
    } ],
    "hashtags" : [ {
      "text" : "Farm24",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634468211296215040",
  "text" : "RT @SouthYeoEast: Animal antics always bring a smile #Farm24 http:\/\/t.co\/2Kfa3fib5H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/634467112933814273\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/2Kfa3fib5H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4UWXkWUAAOWoZ.jpg",
        "id_str" : "634466972021968896",
        "id" : 634466972021968896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4UWXkWUAAOWoZ.jpg",
        "sizes" : [ {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2Kfa3fib5H"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/634467112933814273\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/2Kfa3fib5H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4UaY1WUAA1K58.jpg",
        "id_str" : "634467041081184256",
        "id" : 634467041081184256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4UaY1WUAA1K58.jpg",
        "sizes" : [ {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2Kfa3fib5H"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/634467112933814273\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/2Kfa3fib5H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4Ued0WwAAnMol.jpg",
        "id_str" : "634467111138672640",
        "id" : 634467111138672640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4Ued0WwAAnMol.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2Kfa3fib5H"
      } ],
      "hashtags" : [ {
        "text" : "Farm24",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634467112933814273",
    "text" : "Animal antics always bring a smile #Farm24 http:\/\/t.co\/2Kfa3fib5H",
    "id" : 634467112933814273,
    "created_at" : "2015-08-20 20:48:42 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 634468211296215040,
  "created_at" : "2015-08-20 20:53:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 26, 38 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Best Self",
      "screen_name" : "bestselfco",
      "indices" : [ 129, 140 ],
      "id_str" : "3305097189",
      "id" : 3305097189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfjournal",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HWEzOJ75FL",
      "expanded_url" : "http:\/\/bit.ly\/1J1WH1l",
      "display_url" : "bit.ly\/1J1WH1l"
    } ]
  },
  "geo" : { },
  "id_str" : "634386367154360320",
  "text" : "Check out #selfjournal on @Kickstarter, makes success inevitable thru planning,execution,measurement: http:\/\/t.co\/HWEzOJ75FL via @bestselfco",
  "id" : 634386367154360320,
  "created_at" : "2015-08-20 15:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 105, 111 ]
    }, {
      "text" : "feedly",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/kj8wvkniHT",
      "expanded_url" : "http:\/\/the-digital-reader.com\/2015\/08\/20\/dropbox-moves-into-competition-with-bookmarking-services-now-lets-you-save-links\/",
      "display_url" : "the-digital-reader.com\/2015\/08\/20\/dro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634373287301267456",
  "text" : "Dropbox Moves Into Competition With Bookmarking Services, Now Lets You Save Links http:\/\/t.co\/kj8wvkniHT #books #feedly",
  "id" : 634373287301267456,
  "created_at" : "2015-08-20 14:35:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Hutton",
      "screen_name" : "GlennHutton1",
      "indices" : [ 3, 16 ],
      "id_str" : "455210253",
      "id" : 455210253
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GlennHutton1\/status\/633984509407571968\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/9Jwoni0yW3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMxdjQYWsAAqMJy.jpg",
      "id_str" : "633984507826319360",
      "id" : 633984507826319360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMxdjQYWsAAqMJy.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2457,
        "resize" : "fit",
        "w" : 3072
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9Jwoni0yW3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634190601521655808",
  "text" : "RT @GlennHutton1: Here they come Mum and the kids http:\/\/t.co\/9Jwoni0yW3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GlennHutton1\/status\/633984509407571968\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/9Jwoni0yW3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMxdjQYWsAAqMJy.jpg",
        "id_str" : "633984507826319360",
        "id" : 633984507826319360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMxdjQYWsAAqMJy.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2457,
          "resize" : "fit",
          "w" : 3072
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9Jwoni0yW3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633984509407571968",
    "text" : "Here they come Mum and the kids http:\/\/t.co\/9Jwoni0yW3",
    "id" : 633984509407571968,
    "created_at" : "2015-08-19 12:51:00 +0000",
    "user" : {
      "name" : "Glenn Hutton",
      "screen_name" : "GlennHutton1",
      "protected" : false,
      "id_str" : "455210253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721296782513332224\/Nrm3hBZM_normal.jpg",
      "id" : 455210253,
      "verified" : false
    }
  },
  "id" : 634190601521655808,
  "created_at" : "2015-08-20 02:29:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Tirado",
      "screen_name" : "KillerMartinis",
      "indices" : [ 3, 18 ],
      "id_str" : "307577710",
      "id" : 307577710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634190322789130240",
  "text" : "RT @KillerMartinis: Dear America: this very second, violent state overreach is happening in St Louis. Police have deployed chemical weapons.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634160197259296769",
    "text" : "Dear America: this very second, violent state overreach is happening in St Louis. Police have deployed chemical weapons.",
    "id" : 634160197259296769,
    "created_at" : "2015-08-20 00:29:07 +0000",
    "user" : {
      "name" : "Linda Tirado",
      "screen_name" : "KillerMartinis",
      "protected" : false,
      "id_str" : "307577710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736069933021298688\/U8SvLf8c_normal.jpg",
      "id" : 307577710,
      "verified" : false
    }
  },
  "id" : 634190322789130240,
  "created_at" : "2015-08-20 02:28:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Adam P. Newman)))",
      "screen_name" : "AdamPNewman89",
      "indices" : [ 3, 17 ],
      "id_str" : "1293178676",
      "id" : 1293178676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634188883090124800",
  "text" : "RT @AdamPNewman89: I have no words to describe what I'm seeing on my TL coming out of St. Louis.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634184211797266433",
    "text" : "I have no words to describe what I'm seeing on my TL coming out of St. Louis.",
    "id" : 634184211797266433,
    "created_at" : "2015-08-20 02:04:33 +0000",
    "user" : {
      "name" : "(((Adam P. Newman)))",
      "screen_name" : "AdamPNewman89",
      "protected" : false,
      "id_str" : "1293178676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738818548919894016\/oVU8sJl5_normal.jpg",
      "id" : 1293178676,
      "verified" : false
    }
  },
  "id" : 634188883090124800,
  "created_at" : "2015-08-20 02:23:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McNeil",
      "screen_name" : "GretchenMcNeil",
      "indices" : [ 3, 18 ],
      "id_str" : "14734870",
      "id" : 14734870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634188203986190336",
  "text" : "RT @GretchenMcNeil: Anna Duggar: if you're being held against your will, blink twice and we'll send help!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634187311136157696",
    "text" : "Anna Duggar: if you're being held against your will, blink twice and we'll send help!",
    "id" : 634187311136157696,
    "created_at" : "2015-08-20 02:16:52 +0000",
    "user" : {
      "name" : "Gretchen McNeil",
      "screen_name" : "GretchenMcNeil",
      "protected" : false,
      "id_str" : "14734870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796829431096410112\/oiFyRrxn_normal.jpg",
      "id" : 14734870,
      "verified" : false
    }
  },
  "id" : 634188203986190336,
  "created_at" : "2015-08-20 02:20:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Tuttle",
      "screen_name" : "niais",
      "indices" : [ 3, 9 ],
      "id_str" : "12267642",
      "id" : 12267642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634187984942825472",
  "text" : "RT @niais: Text from husband \"Have a rodent pinned. Need help.\"\nYou guys, I do not even know what to say to that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634178190114578433",
    "text" : "Text from husband \"Have a rodent pinned. Need help.\"\nYou guys, I do not even know what to say to that.",
    "id" : 634178190114578433,
    "created_at" : "2015-08-20 01:40:37 +0000",
    "user" : {
      "name" : "Sarah Tuttle",
      "screen_name" : "niais",
      "protected" : false,
      "id_str" : "12267642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797110380698812417\/GnUNX5DM_normal.jpg",
      "id" : 12267642,
      "verified" : false
    }
  },
  "id" : 634187984942825472,
  "created_at" : "2015-08-20 02:19:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634157383045005312",
  "text" : "RT @AlisynGayle: WOW! -&gt;\nThere's a single nerve that connects all of your vital organs \u2014 and it might just be the future of medicine http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/JG4xqkkj58",
        "expanded_url" : "http:\/\/read.bi\/1I6wEVX",
        "display_url" : "read.bi\/1I6wEVX"
      } ]
    },
    "geo" : { },
    "id_str" : "634023568003735553",
    "text" : "WOW! -&gt;\nThere's a single nerve that connects all of your vital organs \u2014 and it might just be the future of medicine http:\/\/t.co\/JG4xqkkj58",
    "id" : 634023568003735553,
    "created_at" : "2015-08-19 15:26:12 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 634157383045005312,
  "created_at" : "2015-08-20 00:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634156328114626561",
  "text" : "RT @mindymayhem: If the media is so liberal, then why does my grandma who only watches TV news\/reads newspapers have no fucking clue who Be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634050627530825729",
    "text" : "If the media is so liberal, then why does my grandma who only watches TV news\/reads newspapers have no fucking clue who Bernie Sanders is?",
    "id" : 634050627530825729,
    "created_at" : "2015-08-19 17:13:44 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 634156328114626561,
  "created_at" : "2015-08-20 00:13:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/xZt9xAI8AH",
      "expanded_url" : "https:\/\/twitter.com\/celiahart\/status\/633997249979269120",
      "display_url" : "twitter.com\/celiahart\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634025944450248704",
  "text" : "beautiful https:\/\/t.co\/xZt9xAI8AH",
  "id" : 634025944450248704,
  "created_at" : "2015-08-19 15:35:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JAScribbles\/status\/633823461698351104\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/EsJU6jAGFW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMvLEyyWcAA7NeH.jpg",
      "id_str" : "633823455788560384",
      "id" : 633823455788560384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMvLEyyWcAA7NeH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 826,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 744
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 744
      } ],
      "display_url" : "pic.twitter.com\/EsJU6jAGFW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633824562266918912",
  "text" : "RT @JAScribbles: It sparkles \uD83D\uDE1B http:\/\/t.co\/EsJU6jAGFW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JAScribbles\/status\/633823461698351104\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/EsJU6jAGFW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMvLEyyWcAA7NeH.jpg",
        "id_str" : "633823455788560384",
        "id" : 633823455788560384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMvLEyyWcAA7NeH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 826,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 744
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 744
        } ],
        "display_url" : "pic.twitter.com\/EsJU6jAGFW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633823461698351104",
    "text" : "It sparkles \uD83D\uDE1B http:\/\/t.co\/EsJU6jAGFW",
    "id" : 633823461698351104,
    "created_at" : "2015-08-19 02:11:03 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 633824562266918912,
  "created_at" : "2015-08-19 02:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radley Balko",
      "screen_name" : "radleybalko",
      "indices" : [ 3, 15 ],
      "id_str" : "15816595",
      "id" : 15816595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633821361975238656",
  "text" : "RT @radleybalko: Six cops chase 16yo kid, threaten to take him from his house, arrest and cuff him. Why? Not wearing a bike helmet. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/xGCmzESMDL",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?t=109&v=hT3zToHrmZA",
        "display_url" : "youtube.com\/watch?t=109&v=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633646726235201536",
    "text" : "Six cops chase 16yo kid, threaten to take him from his house, arrest and cuff him. Why? Not wearing a bike helmet. https:\/\/t.co\/xGCmzESMDL",
    "id" : 633646726235201536,
    "created_at" : "2015-08-18 14:28:46 +0000",
    "user" : {
      "name" : "Radley Balko",
      "screen_name" : "radleybalko",
      "protected" : false,
      "id_str" : "15816595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488370517116592128\/d7ImJcYb_normal.jpeg",
      "id" : 15816595,
      "verified" : true
    }
  },
  "id" : 633821361975238656,
  "created_at" : "2015-08-19 02:02:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jim Manganiello",
      "screen_name" : "StressDoc",
      "indices" : [ 3, 13 ],
      "id_str" : "24875779",
      "id" : 24875779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/bZumfN5jSL",
      "expanded_url" : "http:\/\/dld.bz\/MZ4S",
      "display_url" : "dld.bz\/MZ4S"
    } ]
  },
  "geo" : { },
  "id_str" : "633818676886663168",
  "text" : "RT @StressDoc: At Midlife Our Soul Makes A Grab For The Steering Wheel: http:\/\/t.co\/bZumfN5jSL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/bZumfN5jSL",
        "expanded_url" : "http:\/\/dld.bz\/MZ4S",
        "display_url" : "dld.bz\/MZ4S"
      } ]
    },
    "geo" : { },
    "id_str" : "633817369337556992",
    "text" : "At Midlife Our Soul Makes A Grab For The Steering Wheel: http:\/\/t.co\/bZumfN5jSL",
    "id" : 633817369337556992,
    "created_at" : "2015-08-19 01:46:51 +0000",
    "user" : {
      "name" : "Dr. Jim Manganiello",
      "screen_name" : "StressDoc",
      "protected" : false,
      "id_str" : "24875779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148884571\/J_Manganiello_photo_medium_normal.JPG",
      "id" : 24875779,
      "verified" : false
    }
  },
  "id" : 633818676886663168,
  "created_at" : "2015-08-19 01:52:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/pGH4g0IjnD",
      "expanded_url" : "http:\/\/demu.gr\/10141181310",
      "display_url" : "demu.gr\/10141181310"
    } ]
  },
  "geo" : { },
  "id_str" : "633817294293069824",
  "text" : "RT @AWorldOutOfMind: First Near-Fully Formed Brain Grown In Lab, Ohio State Scientists Say - Democratic Underground http:\/\/t.co\/pGH4g0IjnD \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DemUnderground",
        "screen_name" : "demunderground",
        "indices" : [ 122, 137 ],
        "id_str" : "577407017",
        "id" : 577407017
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/pGH4g0IjnD",
        "expanded_url" : "http:\/\/demu.gr\/10141181310",
        "display_url" : "demu.gr\/10141181310"
      } ]
    },
    "geo" : { },
    "id_str" : "633815104866418688",
    "text" : "First Near-Fully Formed Brain Grown In Lab, Ohio State Scientists Say - Democratic Underground http:\/\/t.co\/pGH4g0IjnD via @demunderground",
    "id" : 633815104866418688,
    "created_at" : "2015-08-19 01:37:51 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 633817294293069824,
  "created_at" : "2015-08-19 01:46:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyme",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Gcw5f8jSwA",
      "expanded_url" : "http:\/\/www.idahostatesman.com\/2015\/08\/17\/3942722\/former-boise-state-basketball.html",
      "display_url" : "idahostatesman.com\/2015\/08\/17\/394\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633816674190409729",
  "text" : "RT @AlisynGayle: Former Boise State basketball player Zach Moritz dies at 27 | Boise State Basketball |\n#Lyme (2 yrs) http:\/\/t.co\/Gcw5f8jSwA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lyme",
        "indices" : [ 87, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/Gcw5f8jSwA",
        "expanded_url" : "http:\/\/www.idahostatesman.com\/2015\/08\/17\/3942722\/former-boise-state-basketball.html",
        "display_url" : "idahostatesman.com\/2015\/08\/17\/394\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633814389997596672",
    "text" : "Former Boise State basketball player Zach Moritz dies at 27 | Boise State Basketball |\n#Lyme (2 yrs) http:\/\/t.co\/Gcw5f8jSwA",
    "id" : 633814389997596672,
    "created_at" : "2015-08-19 01:35:00 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 633816674190409729,
  "created_at" : "2015-08-19 01:44:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/e2i34UWe78",
      "expanded_url" : "http:\/\/smashd.co\/in-your-head\/",
      "display_url" : "smashd.co\/in-your-head\/"
    } ]
  },
  "geo" : { },
  "id_str" : "633800986054803460",
  "text" : "RT @wilw: I talked to Smashd about anxiety, depression, and how I live with it. http:\/\/t.co\/e2i34UWe78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/e2i34UWe78",
        "expanded_url" : "http:\/\/smashd.co\/in-your-head\/",
        "display_url" : "smashd.co\/in-your-head\/"
      } ]
    },
    "geo" : { },
    "id_str" : "633798366237855745",
    "text" : "I talked to Smashd about anxiety, depression, and how I live with it. http:\/\/t.co\/e2i34UWe78",
    "id" : 633798366237855745,
    "created_at" : "2015-08-19 00:31:20 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503013851631616\/55p1uw70_normal.jpg",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 633800986054803460,
  "created_at" : "2015-08-19 00:41:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 3, 18 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/nUO5I2cTH6",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/08\/how-not-to-deal-with-a-16-year-old-gay-teenager\/",
      "display_url" : "brucegerencser.net\/2015\/08\/how-no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633777574792065024",
  "text" : "RT @BruceGerencser: How NOT to Deal with a 16 Year Old Gay Daughter http:\/\/t.co\/nUO5I2cTH6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/nUO5I2cTH6",
        "expanded_url" : "http:\/\/brucegerencser.net\/2015\/08\/how-not-to-deal-with-a-16-year-old-gay-teenager\/",
        "display_url" : "brucegerencser.net\/2015\/08\/how-no\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633767129943277568",
    "text" : "How NOT to Deal with a 16 Year Old Gay Daughter http:\/\/t.co\/nUO5I2cTH6",
    "id" : 633767129943277568,
    "created_at" : "2015-08-18 22:27:13 +0000",
    "user" : {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "protected" : false,
      "id_str" : "2954308119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708165822007480320\/bzYNwh2A_normal.jpg",
      "id" : 2954308119,
      "verified" : false
    }
  },
  "id" : 633777574792065024,
  "created_at" : "2015-08-18 23:08:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Wolfson",
      "screen_name" : "EricWolfson",
      "indices" : [ 3, 15 ],
      "id_str" : "62510409",
      "id" : 62510409
    }, {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 121, 135 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "19thAmendment",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633741234670927874",
  "text" : "RT @EricWolfson: 95 years ago today, the #19thAmendment was ratified.\n\nHere were some arguments against it --&gt;\n\n(Pic: @JohnFugelsang) http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Fugelsang",
        "screen_name" : "JohnFugelsang",
        "indices" : [ 104, 118 ],
        "id_str" : "33276161",
        "id" : 33276161
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EricWolfson\/status\/633735902250975232\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/UGkNCehRgZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMt7b_OUcAEo-WB.jpg",
        "id_str" : "633735893333864449",
        "id" : 633735893333864449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMt7b_OUcAEo-WB.jpg",
        "sizes" : [ {
          "h" : 391,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 475
        } ],
        "display_url" : "pic.twitter.com\/UGkNCehRgZ"
      } ],
      "hashtags" : [ {
        "text" : "19thAmendment",
        "indices" : [ 24, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633735902250975232",
    "text" : "95 years ago today, the #19thAmendment was ratified.\n\nHere were some arguments against it --&gt;\n\n(Pic: @JohnFugelsang) http:\/\/t.co\/UGkNCehRgZ",
    "id" : 633735902250975232,
    "created_at" : "2015-08-18 20:23:07 +0000",
    "user" : {
      "name" : "Eric Wolfson",
      "screen_name" : "EricWolfson",
      "protected" : false,
      "id_str" : "62510409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3373517986\/bf35a847483ea8b30679d52c445fb255_normal.jpeg",
      "id" : 62510409,
      "verified" : false
    }
  },
  "id" : 633741234670927874,
  "created_at" : "2015-08-18 20:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasting",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "podcast",
      "indices" : [ 43, 51 ]
    }, {
      "text" : "app",
      "indices" : [ 52, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/DpfTRRZ5RR",
      "expanded_url" : "https:\/\/twitter.com\/JoshTuransky\/status\/630168908297805824",
      "display_url" : "twitter.com\/JoshTuransky\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633720582870331396",
  "text" : "curating episodes.. good idea. #podcasting #podcast #app https:\/\/t.co\/DpfTRRZ5RR",
  "id" : 633720582870331396,
  "created_at" : "2015-08-18 19:22:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "spoonie",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/zNvRZjtoCp",
      "expanded_url" : "http:\/\/www.actionforme.org.uk\/get-informed\/about-me\/Symptoms\/range-of-symptoms\/",
      "display_url" : "actionforme.org.uk\/get-informed\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633703142631317505",
  "text" : "so... me\/cfs on the table re: DD #sick #hashimotos #spoonie http:\/\/t.co\/zNvRZjtoCp",
  "id" : 633703142631317505,
  "created_at" : "2015-08-18 18:12:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633702058231771136",
  "text" : "RT @1CatShepherd: Sometimes I just can't help myself &amp; do that cute feline look thingy but it usually doesn't last long http:\/\/t.co\/bZGSqhl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/633687873066283008\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/bZGSqhlmqa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMtPuDiWgAAa4qI.jpg",
        "id_str" : "633687825217650688",
        "id" : 633687825217650688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMtPuDiWgAAa4qI.jpg",
        "sizes" : [ {
          "h" : 469,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/bZGSqhlmqa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633687873066283008",
    "text" : "Sometimes I just can't help myself &amp; do that cute feline look thingy but it usually doesn't last long http:\/\/t.co\/bZGSqhlmqa",
    "id" : 633687873066283008,
    "created_at" : "2015-08-18 17:12:16 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 633702058231771136,
  "created_at" : "2015-08-18 18:08:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633701777267949569",
  "text" : "RT @neiltyson: Had to wait in line to renew a Passport allowing me to visit members of my own species across artificially conceived borders.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563450492958027777",
    "text" : "Had to wait in line to renew a Passport allowing me to visit members of my own species across artificially conceived borders.",
    "id" : 563450492958027777,
    "created_at" : "2015-02-05 21:34:00 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 633701777267949569,
  "created_at" : "2015-08-18 18:07:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTQ",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "faith",
      "indices" : [ 91, 97 ]
    }, {
      "text" : "love",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/Ef4jXK5Lao",
      "expanded_url" : "http:\/\/wp.me\/p2h2UO-2lK",
      "display_url" : "wp.me\/p2h2UO-2lK"
    } ]
  },
  "geo" : { },
  "id_str" : "633444972675616772",
  "text" : "RT @johnpavlovitz: Yes, Homosexuality Absolutely is A Choice http:\/\/t.co\/Ef4jXK5Lao #LGBTQ #faith #love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTQ",
        "indices" : [ 65, 71 ]
      }, {
        "text" : "faith",
        "indices" : [ 72, 78 ]
      }, {
        "text" : "love",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/Ef4jXK5Lao",
        "expanded_url" : "http:\/\/wp.me\/p2h2UO-2lK",
        "display_url" : "wp.me\/p2h2UO-2lK"
      } ]
    },
    "geo" : { },
    "id_str" : "633439470143041536",
    "text" : "Yes, Homosexuality Absolutely is A Choice http:\/\/t.co\/Ef4jXK5Lao #LGBTQ #faith #love",
    "id" : 633439470143041536,
    "created_at" : "2015-08-18 00:45:13 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 633444972675616772,
  "created_at" : "2015-08-18 01:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Based Medicine",
      "screen_name" : "RxISK",
      "indices" : [ 3, 9 ],
      "id_str" : "267634622",
      "id" : 267634622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4bi3mZJpCf",
      "expanded_url" : "http:\/\/wp.rxisk.org\/antidepressants-and-violence-the-numbers\/",
      "display_url" : "wp.rxisk.org\/antidepressant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633442869815156736",
  "text" : "RT @RxISK: How on earth could an antidepressant drug drive someone to murder?  FDA reports may hold some clues:  http:\/\/t.co\/4bi3mZJpCf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/4bi3mZJpCf",
        "expanded_url" : "http:\/\/wp.rxisk.org\/antidepressants-and-violence-the-numbers\/",
        "display_url" : "wp.rxisk.org\/antidepressant\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633328778563842049",
    "text" : "How on earth could an antidepressant drug drive someone to murder?  FDA reports may hold some clues:  http:\/\/t.co\/4bi3mZJpCf",
    "id" : 633328778563842049,
    "created_at" : "2015-08-17 17:25:22 +0000",
    "user" : {
      "name" : "Data Based Medicine",
      "screen_name" : "RxISK",
      "protected" : false,
      "id_str" : "267634622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472074630518157312\/SIqFkJ3A_normal.png",
      "id" : 267634622,
      "verified" : false
    }
  },
  "id" : 633442869815156736,
  "created_at" : "2015-08-18 00:58:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Healy",
      "screen_name" : "DrDavidHealy",
      "indices" : [ 3, 16 ],
      "id_str" : "455904453",
      "id" : 455904453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633442670090842112",
  "text" : "RT @DrDavidHealy: By end of James Holmes trial we knew a lot about his life &amp; trtmt by Univ. docs.  What does it tell us about Zoloft? http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/vizkHlCAzc",
        "expanded_url" : "http:\/\/wp.me\/p2FaK9-1jY",
        "display_url" : "wp.me\/p2FaK9-1jY"
      } ]
    },
    "geo" : { },
    "id_str" : "631451570975174660",
    "text" : "By end of James Holmes trial we knew a lot about his life &amp; trtmt by Univ. docs.  What does it tell us about Zoloft? http:\/\/t.co\/vizkHlCAzc",
    "id" : 631451570975174660,
    "created_at" : "2015-08-12 13:06:00 +0000",
    "user" : {
      "name" : "David Healy",
      "screen_name" : "DrDavidHealy",
      "protected" : false,
      "id_str" : "455904453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762647514\/DavidHealysmall-150x150_normal.jpg",
      "id" : 455904453,
      "verified" : false
    }
  },
  "id" : 633442670090842112,
  "created_at" : "2015-08-18 00:57:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 99, 113 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sun",
      "indices" : [ 45, 49 ]
    }, {
      "text" : "YearInSpace",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633442345611063296",
  "text" : "RT @StationCDRKelly: Day 143. Looks like the #sun painted a Rothko on its way out. Good night from @space_station! #YearInSpace http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 78, 92 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/633412838694895616\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/DJKK9gbqeZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMpVnusUkAA9BPJ.jpg",
        "id_str" : "633412838636163072",
        "id" : 633412838636163072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMpVnusUkAA9BPJ.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/DJKK9gbqeZ"
      } ],
      "hashtags" : [ {
        "text" : "sun",
        "indices" : [ 24, 28 ]
      }, {
        "text" : "YearInSpace",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633412838694895616",
    "text" : "Day 143. Looks like the #sun painted a Rothko on its way out. Good night from @space_station! #YearInSpace http:\/\/t.co\/DJKK9gbqeZ",
    "id" : 633412838694895616,
    "created_at" : "2015-08-17 22:59:23 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 633442345611063296,
  "created_at" : "2015-08-18 00:56:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633438989672837120",
  "geo" : { },
  "id_str" : "633441760665018369",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous good song! : )",
  "id" : 633441760665018369,
  "in_reply_to_status_id" : 633438989672837120,
  "created_at" : "2015-08-18 00:54:19 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marijuana",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "legal",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633427704017256450",
  "text" : "RT @Pandeism: But to be clear, even if #marijuana had NO medical benefit at all, it still ought to be #legal, as a matter of personal freed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "marijuana",
        "indices" : [ 25, 35 ]
      }, {
        "text" : "legal",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633426600541974529",
    "text" : "But to be clear, even if #marijuana had NO medical benefit at all, it still ought to be #legal, as a matter of personal freedom and choice.",
    "id" : 633426600541974529,
    "created_at" : "2015-08-17 23:54:04 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 633427704017256450,
  "created_at" : "2015-08-17 23:58:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenSanders\/status\/633263788427485184\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nj7HhGlYJ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMnOD2tWIAAWEu2.png",
      "id_str" : "633263788242903040",
      "id" : 633263788242903040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMnOD2tWIAAWEu2.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nj7HhGlYJ6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633403055497682944",
  "text" : "RT @SenSanders: Private insurance companies' goal is to make as much money as possible, not to provide quality care. http:\/\/t.co\/nj7HhGlYJ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSanders\/status\/633263788427485184\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/nj7HhGlYJ6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMnOD2tWIAAWEu2.png",
        "id_str" : "633263788242903040",
        "id" : 633263788242903040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMnOD2tWIAAWEu2.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nj7HhGlYJ6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633263788427485184",
    "text" : "Private insurance companies' goal is to make as much money as possible, not to provide quality care. http:\/\/t.co\/nj7HhGlYJ6",
    "id" : 633263788427485184,
    "created_at" : "2015-08-17 13:07:07 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 633403055497682944,
  "created_at" : "2015-08-17 22:20:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633401781926674432",
  "geo" : { },
  "id_str" : "633402578139807745",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe of course I'm looking.. i'm nosy like that.. plus.. books!!",
  "id" : 633402578139807745,
  "in_reply_to_status_id" : 633401781926674432,
  "created_at" : "2015-08-17 22:18:37 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/7ewA0HqqZx",
      "expanded_url" : "http:\/\/www.quidividibrewery.ca\/award-winning-beers\/iceberg\/",
      "display_url" : "quidividibrewery.ca\/award-winning-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "633399560702951424",
  "geo" : { },
  "id_str" : "633402341132226560",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe dh said this was good, had it on Sat &gt; http:\/\/t.co\/7ewA0HqqZx \"brewed with 25,000 year old iceberg water\"",
  "id" : 633402341132226560,
  "in_reply_to_status_id" : 633399560702951424,
  "created_at" : "2015-08-17 22:17:40 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633348331926867968",
  "text" : "RT @ErinEFarley: I can't decide if this toad is getting enough to eat hiding out in the window well. I left the lid off but he stayed. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/633327986259939328\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/l0rBJ9ZCnI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMoIcduWoAEcWrF.jpg",
        "id_str" : "633327982707384321",
        "id" : 633327982707384321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMoIcduWoAEcWrF.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/l0rBJ9ZCnI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633327986259939328",
    "text" : "I can't decide if this toad is getting enough to eat hiding out in the window well. I left the lid off but he stayed. http:\/\/t.co\/l0rBJ9ZCnI",
    "id" : 633327986259939328,
    "created_at" : "2015-08-17 17:22:13 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 633348331926867968,
  "created_at" : "2015-08-17 18:43:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Qa78sJP7PR",
      "expanded_url" : "https:\/\/twitter.com\/theslowlane_ME\/status\/632512973987254272",
      "display_url" : "twitter.com\/theslowlane_ME\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633326227739295745",
  "text" : "cc: @JourneyTheHedgi #hashimotos #thyroid #chronicillness https:\/\/t.co\/Qa78sJP7PR",
  "id" : 633326227739295745,
  "created_at" : "2015-08-17 17:15:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/svvgT5f97q",
      "expanded_url" : "https:\/\/twitter.com\/FrancineWatson_\/status\/631729153851719680",
      "display_url" : "twitter.com\/FrancineWatson\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633325672577019905",
  "text" : "cc: @JourneyTheHedgi #hashimotos #thyroid #chronicillness https:\/\/t.co\/svvgT5f97q",
  "id" : 633325672577019905,
  "created_at" : "2015-08-17 17:13:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "spoonie",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/5pxDt0gdHN",
      "expanded_url" : "https:\/\/twitter.com\/HypothyroidMom\/status\/633309547160059904",
      "display_url" : "twitter.com\/HypothyroidMom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633310868709748736",
  "text" : "cc: @JourneyTheHedgi #hashimotos #thyroid #spoonie  https:\/\/t.co\/5pxDt0gdHN",
  "id" : 633310868709748736,
  "created_at" : "2015-08-17 16:14:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/dctK8cAGY9",
      "expanded_url" : "http:\/\/buff.ly\/1MsJCAw",
      "display_url" : "buff.ly\/1MsJCAw"
    } ]
  },
  "geo" : { },
  "id_str" : "633076228753354752",
  "text" : "RT @Floridaline: Christians,\nIsrael is using embryonic stem cells in research! \nWhen will you defund them?\n\nhttp:\/\/t.co\/dctK8cAGY9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/dctK8cAGY9",
        "expanded_url" : "http:\/\/buff.ly\/1MsJCAw",
        "display_url" : "buff.ly\/1MsJCAw"
      } ]
    },
    "geo" : { },
    "id_str" : "633075296921624576",
    "text" : "Christians,\nIsrael is using embryonic stem cells in research! \nWhen will you defund them?\n\nhttp:\/\/t.co\/dctK8cAGY9",
    "id" : 633075296921624576,
    "created_at" : "2015-08-17 00:38:07 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 633076228753354752,
  "created_at" : "2015-08-17 00:41:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayne",
      "screen_name" : "Buddha_Insights",
      "indices" : [ 3, 19 ],
      "id_str" : "854772024",
      "id" : 854772024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633075929036816385",
  "text" : "RT @Buddha_Insights: None of us has all the answers. All of us have a part of the answer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633073796451336196",
    "text" : "None of us has all the answers. All of us have a part of the answer.",
    "id" : 633073796451336196,
    "created_at" : "2015-08-17 00:32:09 +0000",
    "user" : {
      "name" : "Rayne",
      "screen_name" : "Buddha_Insights",
      "protected" : false,
      "id_str" : "854772024",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552982680615149568\/njzS8uM-_normal.jpeg",
      "id" : 854772024,
      "verified" : false
    }
  },
  "id" : 633075929036816385,
  "created_at" : "2015-08-17 00:40:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633075211198431232",
  "text" : "intrinsic worth of every human being? where's that value re: war, death penalty, getting basic necessities of life??",
  "id" : 633075211198431232,
  "created_at" : "2015-08-17 00:37:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633070541738381313",
  "geo" : { },
  "id_str" : "633072700320317441",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind hmm.. but that would be a different concept then. atheist means one who does not believe in God.. thats it.",
  "id" : 633072700320317441,
  "in_reply_to_status_id" : 633070541738381313,
  "created_at" : "2015-08-17 00:27:48 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/OKZhvGfyxP",
      "expanded_url" : "https:\/\/twitter.com\/trcfwtt\/status\/633057297359572992",
      "display_url" : "twitter.com\/trcfwtt\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633059790516789248",
  "text" : "lol https:\/\/t.co\/OKZhvGfyxP",
  "id" : 633059790516789248,
  "created_at" : "2015-08-16 23:36:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633055711644282880",
  "text" : "RT @ErinEFarley: Watching this bird stand on tiptoe to get at the grass seeds. Taken through a window covered in cat nose prints. \uD83D\uDE02 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/633049407894646784\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Jh0g08e6hB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMkLEo6UAAAiH9n.jpg",
        "id_str" : "633049396951646208",
        "id" : 633049396951646208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMkLEo6UAAAiH9n.jpg",
        "sizes" : [ {
          "h" : 289,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 870,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 870,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Jh0g08e6hB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/633049407894646784\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Jh0g08e6hB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMkLEo7U8AAWz1d.jpg",
        "id_str" : "633049396955901952",
        "id" : 633049396955901952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMkLEo7U8AAWz1d.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Jh0g08e6hB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/633049407894646784\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Jh0g08e6hB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMkLEo7UAAA6xun.jpg",
        "id_str" : "633049396955840512",
        "id" : 633049396955840512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMkLEo7UAAA6xun.jpg",
        "sizes" : [ {
          "h" : 888,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 888,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Jh0g08e6hB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633049407894646784",
    "text" : "Watching this bird stand on tiptoe to get at the grass seeds. Taken through a window covered in cat nose prints. \uD83D\uDE02 http:\/\/t.co\/Jh0g08e6hB",
    "id" : 633049407894646784,
    "created_at" : "2015-08-16 22:55:14 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 633055711644282880,
  "created_at" : "2015-08-16 23:20:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633046132185169921",
  "geo" : { },
  "id_str" : "633051245561946112",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields eek! hope she's ok?",
  "id" : 633051245561946112,
  "in_reply_to_status_id" : 633046132185169921,
  "created_at" : "2015-08-16 23:02:33 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/rga8nP0PVP",
      "expanded_url" : "https:\/\/twitter.com\/BrianRathbone\/status\/633048662873108480",
      "display_url" : "twitter.com\/BrianRathbone\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633049999581052929",
  "text" : "a million times this... https:\/\/t.co\/rga8nP0PVP",
  "id" : 633049999581052929,
  "created_at" : "2015-08-16 22:57:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "linda",
      "screen_name" : "kermitellis",
      "indices" : [ 3, 15 ],
      "id_str" : "813751194",
      "id" : 813751194
    }, {
      "name" : "VisitScotland",
      "screen_name" : "VisitScotland",
      "indices" : [ 73, 87 ],
      "id_str" : "16557472",
      "id" : 16557472
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kermitellis\/status\/632557404933226497\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/cZw0msGJbT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMdLgS9WEAAMyTO.jpg",
      "id_str" : "632557290885877760",
      "id" : 632557290885877760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMdLgS9WEAAMyTO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 872
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 872
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cZw0msGJbT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/kermitellis\/status\/632557404933226497\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/cZw0msGJbT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMdLgTHWoAANLNP.jpg",
      "id_str" : "632557290927857664",
      "id" : 632557290927857664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMdLgTHWoAANLNP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 807
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 807
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cZw0msGJbT"
    } ],
    "hashtags" : [ {
      "text" : "Robin",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "InverarayCastle",
      "indices" : [ 56, 72 ]
    }, {
      "text" : "Scotland",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633045387104923650",
  "text" : "RT @kermitellis: A young #Robin perched in the trees at #InverarayCastle @VisitScotland #Scotland \uD83C\uDF32\uD83C\uDF32\uD83C\uDF32\uD83D\uDE0D\uD83D\uDC38 http:\/\/t.co\/cZw0msGJbT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VisitScotland",
        "screen_name" : "VisitScotland",
        "indices" : [ 56, 70 ],
        "id_str" : "16557472",
        "id" : 16557472
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kermitellis\/status\/632557404933226497\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/cZw0msGJbT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMdLgS9WEAAMyTO.jpg",
        "id_str" : "632557290885877760",
        "id" : 632557290885877760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMdLgS9WEAAMyTO.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 872
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 872
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 705,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cZw0msGJbT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/kermitellis\/status\/632557404933226497\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/cZw0msGJbT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMdLgTHWoAANLNP.jpg",
        "id_str" : "632557290927857664",
        "id" : 632557290927857664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMdLgTHWoAANLNP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 761,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/cZw0msGJbT"
      } ],
      "hashtags" : [ {
        "text" : "Robin",
        "indices" : [ 8, 14 ]
      }, {
        "text" : "InverarayCastle",
        "indices" : [ 39, 55 ]
      }, {
        "text" : "Scotland",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632557404933226497",
    "text" : "A young #Robin perched in the trees at #InverarayCastle @VisitScotland #Scotland \uD83C\uDF32\uD83C\uDF32\uD83C\uDF32\uD83D\uDE0D\uD83D\uDC38 http:\/\/t.co\/cZw0msGJbT",
    "id" : 632557404933226497,
    "created_at" : "2015-08-15 14:20:12 +0000",
    "user" : {
      "name" : "linda",
      "screen_name" : "kermitellis",
      "protected" : false,
      "id_str" : "813751194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681391060464041984\/S3OmQZEF_normal.jpg",
      "id" : 813751194,
      "verified" : false
    }
  },
  "id" : 633045387104923650,
  "created_at" : "2015-08-16 22:39:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edurne Elizondo",
      "screen_name" : "edurne_elizondo",
      "indices" : [ 3, 19 ],
      "id_str" : "50322387",
      "id" : 50322387
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/edurne_elizondo\/status\/631025765455368192\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/n5YLgzNgp0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMHag22WgAAuoQ6.jpg",
      "id_str" : "631025680822730752",
      "id" : 631025680822730752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMHag22WgAAuoQ6.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3864,
        "resize" : "fit",
        "w" : 5152
      } ],
      "display_url" : "pic.twitter.com\/n5YLgzNgp0"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/edurne_elizondo\/status\/631025765455368192\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/n5YLgzNgp0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMHaj1_WsAAN9W4.jpg",
      "id_str" : "631025732131663872",
      "id" : 631025732131663872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMHaj1_WsAAN9W4.jpg",
      "sizes" : [ {
        "h" : 3864,
        "resize" : "fit",
        "w" : 5152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n5YLgzNgp0"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/edurne_elizondo\/status\/631025765455368192\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/n5YLgzNgp0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMHals4WcAAwqEq.jpg",
      "id_str" : "631025764046106624",
      "id" : 631025764046106624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMHals4WcAAwqEq.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3864,
        "resize" : "fit",
        "w" : 5152
      } ],
      "display_url" : "pic.twitter.com\/n5YLgzNgp0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633035085642661888",
  "text" : "RT @edurne_elizondo: http:\/\/t.co\/n5YLgzNgp0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/edurne_elizondo\/status\/631025765455368192\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/n5YLgzNgp0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMHag22WgAAuoQ6.jpg",
        "id_str" : "631025680822730752",
        "id" : 631025680822730752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMHag22WgAAuoQ6.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3864,
          "resize" : "fit",
          "w" : 5152
        } ],
        "display_url" : "pic.twitter.com\/n5YLgzNgp0"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/edurne_elizondo\/status\/631025765455368192\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/n5YLgzNgp0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMHaj1_WsAAN9W4.jpg",
        "id_str" : "631025732131663872",
        "id" : 631025732131663872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMHaj1_WsAAN9W4.jpg",
        "sizes" : [ {
          "h" : 3864,
          "resize" : "fit",
          "w" : 5152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/n5YLgzNgp0"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/edurne_elizondo\/status\/631025765455368192\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/n5YLgzNgp0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMHals4WcAAwqEq.jpg",
        "id_str" : "631025764046106624",
        "id" : 631025764046106624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMHals4WcAAwqEq.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3864,
          "resize" : "fit",
          "w" : 5152
        } ],
        "display_url" : "pic.twitter.com\/n5YLgzNgp0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631025765455368192",
    "text" : "http:\/\/t.co\/n5YLgzNgp0",
    "id" : 631025765455368192,
    "created_at" : "2015-08-11 08:54:01 +0000",
    "user" : {
      "name" : "Edurne Elizondo",
      "screen_name" : "edurne_elizondo",
      "protected" : false,
      "id_str" : "50322387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795219676942974978\/4PHBnLha_normal.jpg",
      "id" : 50322387,
      "verified" : false
    }
  },
  "id" : 633035085642661888,
  "created_at" : "2015-08-16 21:58:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/Zy0NWTS6Er",
      "expanded_url" : "https:\/\/twitter.com\/dodger1025\/status\/633014825350758400",
      "display_url" : "twitter.com\/dodger1025\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633034985813999616",
  "text" : "precious https:\/\/t.co\/Zy0NWTS6Er",
  "id" : 633034985813999616,
  "created_at" : "2015-08-16 21:57:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "indices" : [ 3, 11 ],
      "id_str" : "250852478",
      "id" : 250852478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Revelation",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633034121485381632",
  "text" : "RT @jeczaja: Christians&gt;#Revelation is full of such fantastic symbolism you can make up any story to fit. Just love each other-that'll keep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Revelation",
        "indices" : [ 14, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633032235508105216",
    "text" : "Christians&gt;#Revelation is full of such fantastic symbolism you can make up any story to fit. Just love each other-that'll keep U busy enuf.",
    "id" : 633032235508105216,
    "created_at" : "2015-08-16 21:47:00 +0000",
    "user" : {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "protected" : false,
      "id_str" : "250852478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545010686699393024\/wxdpPJoe_normal.jpeg",
      "id" : 250852478,
      "verified" : false
    }
  },
  "id" : 633034121485381632,
  "created_at" : "2015-08-16 21:54:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "indices" : [ 0, 8 ],
      "id_str" : "250852478",
      "id" : 250852478
    }, {
      "name" : "Je Czaja",
      "screen_name" : "JoinImagiNation",
      "indices" : [ 9, 25 ],
      "id_str" : "3305549006",
      "id" : 3305549006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633032992479277056",
  "geo" : { },
  "id_str" : "633033445799804928",
  "in_reply_to_user_id" : 250852478,
  "text" : "@jeczaja @JoinImagiNation \"and try to be nice.\" heehee",
  "id" : 633033445799804928,
  "in_reply_to_status_id" : 633032992479277056,
  "created_at" : "2015-08-16 21:51:49 +0000",
  "in_reply_to_screen_name" : "jeczaja",
  "in_reply_to_user_id_str" : "250852478",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PragmaticNationalist",
      "screen_name" : "toirama",
      "indices" : [ 3, 11 ],
      "id_str" : "370254529",
      "id" : 370254529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/sZ6TmulkVL",
      "expanded_url" : "http:\/\/shr.gs\/0KUquWI",
      "display_url" : "shr.gs\/0KUquWI"
    } ]
  },
  "geo" : { },
  "id_str" : "633017115780513792",
  "text" : "RT @toirama: Don't freak out, but scientists think octopuses 'might be aliens' after DNA study http:\/\/t.co\/sZ6TmulkVL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/sZ6TmulkVL",
        "expanded_url" : "http:\/\/shr.gs\/0KUquWI",
        "display_url" : "shr.gs\/0KUquWI"
      } ]
    },
    "geo" : { },
    "id_str" : "632302880947630080",
    "text" : "Don't freak out, but scientists think octopuses 'might be aliens' after DNA study http:\/\/t.co\/sZ6TmulkVL",
    "id" : 632302880947630080,
    "created_at" : "2015-08-14 21:28:49 +0000",
    "user" : {
      "name" : "PragmaticNationalist",
      "screen_name" : "toirama",
      "protected" : false,
      "id_str" : "370254529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709452868567363584\/cNpRIww-_normal.jpg",
      "id" : 370254529,
      "verified" : false
    }
  },
  "id" : 633017115780513792,
  "created_at" : "2015-08-16 20:46:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Torres, MD",
      "screen_name" : "LeahNTorres",
      "indices" : [ 3, 15 ],
      "id_str" : "195409453",
      "id" : 195409453
    }, {
      "name" : "Scott Walker",
      "screen_name" : "ScottWalker",
      "indices" : [ 29, 41 ],
      "id_str" : "33750798",
      "id" : 33750798
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 48, 56 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633016553982816258",
  "text" : "RT @LeahNTorres: If likes of @ScottWalker &amp; @tedcruz have their way--\nA pregnancy ending pre-viability = crime until proven otherwise https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Walker",
        "screen_name" : "ScottWalker",
        "indices" : [ 12, 24 ],
        "id_str" : "33750798",
        "id" : 33750798
      }, {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 31, 39 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/9WKsBbk6jY",
        "expanded_url" : "https:\/\/twitter.com\/mgbazemorejr\/status\/632926806534942720",
        "display_url" : "twitter.com\/mgbazemorejr\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632927380827299840",
    "text" : "If likes of @ScottWalker &amp; @tedcruz have their way--\nA pregnancy ending pre-viability = crime until proven otherwise https:\/\/t.co\/9WKsBbk6jY",
    "id" : 632927380827299840,
    "created_at" : "2015-08-16 14:50:21 +0000",
    "user" : {
      "name" : "Leah Torres, MD",
      "screen_name" : "LeahNTorres",
      "protected" : false,
      "id_str" : "195409453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796512584828493824\/Mgh2Z8HN_normal.jpg",
      "id" : 195409453,
      "verified" : true
    }
  },
  "id" : 633016553982816258,
  "created_at" : "2015-08-16 20:44:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633016221626183680",
  "text" : "RT @aliceinthewater: Chronic pain is a lot like depression. It's invisible. People who hurt constantly don't look sick.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632941176165785600",
    "text" : "Chronic pain is a lot like depression. It's invisible. People who hurt constantly don't look sick.",
    "id" : 632941176165785600,
    "created_at" : "2015-08-16 15:45:10 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 633016221626183680,
  "created_at" : "2015-08-16 20:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633010140682153984",
  "geo" : { },
  "id_str" : "633014107663413248",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater you like flowers, don't you? lol.. ((thumbsup))",
  "id" : 633014107663413248,
  "in_reply_to_status_id" : 633010140682153984,
  "created_at" : "2015-08-16 20:34:58 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Timm",
      "screen_name" : "trevortimm",
      "indices" : [ 3, 14 ],
      "id_str" : "224079521",
      "id" : 224079521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632927176900386816",
  "text" : "RT @trevortimm: So far Jeb Bush's foreign policy is: maybe send more troops to Iraq, rip up the Iran deal and maybe bomb them, and maybe to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "631966430741856256",
    "geo" : { },
    "id_str" : "631966838872768512",
    "in_reply_to_user_id" : 224079521,
    "text" : "So far Jeb Bush's foreign policy is: maybe send more troops to Iraq, rip up the Iran deal and maybe bomb them, and maybe torture more people",
    "id" : 631966838872768512,
    "in_reply_to_status_id" : 631966430741856256,
    "created_at" : "2015-08-13 23:13:30 +0000",
    "in_reply_to_screen_name" : "trevortimm",
    "in_reply_to_user_id_str" : "224079521",
    "user" : {
      "name" : "Trevor Timm",
      "screen_name" : "trevortimm",
      "protected" : false,
      "id_str" : "224079521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777580881938620417\/dl1qo2GM_normal.jpg",
      "id" : 224079521,
      "verified" : true
    }
  },
  "id" : 632927176900386816,
  "created_at" : "2015-08-16 14:49:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Northern Lace",
      "screen_name" : "LizLovick",
      "indices" : [ 3, 13 ],
      "id_str" : "518648128",
      "id" : 518648128
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LizLovick\/status\/632875799750676480\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/1aQIEjbMfD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMhtL48UwAAr5xr.jpg",
      "id_str" : "632875798676946944",
      "id" : 632875798676946944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMhtL48UwAAr5xr.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/1aQIEjbMfD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/nBtxq0LSRT",
      "expanded_url" : "https:\/\/northernlace.wordpress.com\/2015\/08\/16\/flotta-in-summer",
      "display_url" : "northernlace.wordpress.com\/2015\/08\/16\/flo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632910793999314944",
  "text" : "RT @LizLovick: General dog-walking photos of Flotta in the so-called summer. https:\/\/t.co\/nBtxq0LSRT http:\/\/t.co\/1aQIEjbMfD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LizLovick\/status\/632875799750676480\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/1aQIEjbMfD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMhtL48UwAAr5xr.jpg",
        "id_str" : "632875798676946944",
        "id" : 632875798676946944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMhtL48UwAAr5xr.jpg",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/1aQIEjbMfD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/nBtxq0LSRT",
        "expanded_url" : "https:\/\/northernlace.wordpress.com\/2015\/08\/16\/flotta-in-summer",
        "display_url" : "northernlace.wordpress.com\/2015\/08\/16\/flo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632875799750676480",
    "text" : "General dog-walking photos of Flotta in the so-called summer. https:\/\/t.co\/nBtxq0LSRT http:\/\/t.co\/1aQIEjbMfD",
    "id" : 632875799750676480,
    "created_at" : "2015-08-16 11:25:23 +0000",
    "user" : {
      "name" : "Northern Lace",
      "screen_name" : "LizLovick",
      "protected" : false,
      "id_str" : "518648128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1896516912\/Elizabeth_Lovick_normal.jpg",
      "id" : 518648128,
      "verified" : false
    }
  },
  "id" : 632910793999314944,
  "created_at" : "2015-08-16 13:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 3, 18 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "birds",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632909385619107840",
  "text" : "RT @PoetsLoveBirds: The immature Eastern #Bluebird became impatient as Mama was taking too long to share the lunch! #birds #birdwatching ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PoetsLoveBirds\/status\/632762818220150784\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/bv2jFxfLBO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMgGbgIU8AAi7Ae.jpg",
        "id_str" : "632762817196650496",
        "id" : 632762817196650496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMgGbgIU8AAi7Ae.jpg",
        "sizes" : [ {
          "h" : 1847,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 739,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1261,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bv2jFxfLBO"
      } ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "birds",
        "indices" : [ 96, 102 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632762818220150784",
    "text" : "The immature Eastern #Bluebird became impatient as Mama was taking too long to share the lunch! #birds #birdwatching http:\/\/t.co\/bv2jFxfLBO",
    "id" : 632762818220150784,
    "created_at" : "2015-08-16 03:56:26 +0000",
    "user" : {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "protected" : false,
      "id_str" : "818814906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153554844\/2f757111dc3eedb25debd1db4e264f85_normal.jpeg",
      "id" : 818814906,
      "verified" : false
    }
  },
  "id" : 632909385619107840,
  "created_at" : "2015-08-16 13:38:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "indices" : [ 3, 13 ],
      "id_str" : "15104467",
      "id" : 15104467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/3Ta4GnReEv",
      "expanded_url" : "https:\/\/twitter.com\/judd_markowitz\/status\/632742390080634880",
      "display_url" : "twitter.com\/judd_markowitz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632744656539918336",
  "text" : "RT @FogBelter: It's as easy as distinguishing freedom from slavery. Materialism is addiction. https:\/\/t.co\/3Ta4GnReEv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/3Ta4GnReEv",
        "expanded_url" : "https:\/\/twitter.com\/judd_markowitz\/status\/632742390080634880",
        "display_url" : "twitter.com\/judd_markowitz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632744304335675392",
    "text" : "It's as easy as distinguishing freedom from slavery. Materialism is addiction. https:\/\/t.co\/3Ta4GnReEv",
    "id" : 632744304335675392,
    "created_at" : "2015-08-16 02:42:52 +0000",
    "user" : {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "protected" : false,
      "id_str" : "15104467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/263286875\/Joshua_A_Norton_normal.jpg",
      "id" : 15104467,
      "verified" : false
    }
  },
  "id" : 632744656539918336,
  "created_at" : "2015-08-16 02:44:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632744141244469249",
  "text" : "RT @vaxen_var: Amerika: Interesting that you're so worried about Hillarys' emails when you should be worried about DIEBOLD Electronic Votin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632743804211101696",
    "text" : "Amerika: Interesting that you're so worried about Hillarys' emails when you should be worried about DIEBOLD Electronic Voting Machines!",
    "id" : 632743804211101696,
    "created_at" : "2015-08-16 02:40:53 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 632744141244469249,
  "created_at" : "2015-08-16 02:42:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "j.raphael",
      "screen_name" : "jr_behl",
      "indices" : [ 3, 11 ],
      "id_str" : "315052450",
      "id" : 315052450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632742020340142080",
  "text" : "RT @jr_behl: when it comes to social programs and infrastructure its \"where do we get the money\" but when it comes to wars and corporate we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598939263925919744",
    "text" : "when it comes to social programs and infrastructure its \"where do we get the money\" but when it comes to wars and corporate welfare, silence",
    "id" : 598939263925919744,
    "created_at" : "2015-05-14 19:53:42 +0000",
    "user" : {
      "name" : "j.raphael",
      "screen_name" : "jr_behl",
      "protected" : false,
      "id_str" : "315052450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780485526390509569\/8_ZOJZYa_normal.jpg",
      "id" : 315052450,
      "verified" : false
    }
  },
  "id" : 632742020340142080,
  "created_at" : "2015-08-16 02:33:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/BEnSsj4eMv",
      "expanded_url" : "https:\/\/twitter.com\/StressDoc\/status\/632730559786037249",
      "display_url" : "twitter.com\/StressDoc\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632739550192869376",
  "text" : "So much this!  https:\/\/t.co\/BEnSsj4eMv",
  "id" : 632739550192869376,
  "created_at" : "2015-08-16 02:23:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "indices" : [ 3, 11 ],
      "id_str" : "250852478",
      "id" : 250852478
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 83, 99 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/gFQry6WyD0",
      "expanded_url" : "http:\/\/wp.me\/p2X3cL-128",
      "display_url" : "wp.me\/p2X3cL-128"
    } ]
  },
  "geo" : { },
  "id_str" : "632738682479484928",
  "text" : "RT @jeczaja: What if You are Actually a Brain in a Vat? http:\/\/t.co\/gFQry6WyD0 via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 70, 86 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/gFQry6WyD0",
        "expanded_url" : "http:\/\/wp.me\/p2X3cL-128",
        "display_url" : "wp.me\/p2X3cL-128"
      } ]
    },
    "geo" : { },
    "id_str" : "632730823771463680",
    "text" : "What if You are Actually a Brain in a Vat? http:\/\/t.co\/gFQry6WyD0 via @wordpressdotcom",
    "id" : 632730823771463680,
    "created_at" : "2015-08-16 01:49:18 +0000",
    "user" : {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "protected" : false,
      "id_str" : "250852478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545010686699393024\/wxdpPJoe_normal.jpeg",
      "id" : 250852478,
      "verified" : false
    }
  },
  "id" : 632738682479484928,
  "created_at" : "2015-08-16 02:20:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 3, 10 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/feross\/status\/515654523239825409\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/eF1HEHdmWZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byf5Dh8CcAAsHNU.jpg",
      "id_str" : "515654521402322944",
      "id" : 515654521402322944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byf5Dh8CcAAsHNU.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eF1HEHdmWZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632738106983194624",
  "text" : "RT @feross: The Internet of things! [source of pic unknown] http:\/\/t.co\/eF1HEHdmWZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/feross\/status\/515654523239825409\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/eF1HEHdmWZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Byf5Dh8CcAAsHNU.jpg",
        "id_str" : "515654521402322944",
        "id" : 515654521402322944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byf5Dh8CcAAsHNU.jpg",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eF1HEHdmWZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515654523239825409",
    "text" : "The Internet of things! [source of pic unknown] http:\/\/t.co\/eF1HEHdmWZ",
    "id" : 515654523239825409,
    "created_at" : "2014-09-27 00:09:53 +0000",
    "user" : {
      "name" : "Feross",
      "screen_name" : "feross",
      "protected" : false,
      "id_str" : "15692193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458911857466560513\/uKX6-c4z_normal.jpeg",
      "id" : 15692193,
      "verified" : false
    }
  },
  "id" : 632738106983194624,
  "created_at" : "2015-08-16 02:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Fairchild",
      "screen_name" : "morgfair",
      "indices" : [ 3, 12 ],
      "id_str" : "156306739",
      "id" : 156306739
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 127, 133 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/9ZuOC3Tvwn",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/moneybox\/2015\/08\/12\/scott_walker_s_basketball_stadium_finance_bill_the_wisconsin_governor_just.html?wpsrc=sh_all_dt_tw_top",
      "display_url" : "slate.com\/blogs\/moneybox\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632725042258931712",
  "text" : "RT @morgfair: After slashing higher-ed spending, Scott Walker is blowing $250 million on a stadium: http:\/\/t.co\/9ZuOC3Tvwn via @slate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 113, 119 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/9ZuOC3Tvwn",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/moneybox\/2015\/08\/12\/scott_walker_s_basketball_stadium_finance_bill_the_wisconsin_governor_just.html?wpsrc=sh_all_dt_tw_top",
        "display_url" : "slate.com\/blogs\/moneybox\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631674331131572224",
    "text" : "After slashing higher-ed spending, Scott Walker is blowing $250 million on a stadium: http:\/\/t.co\/9ZuOC3Tvwn via @slate",
    "id" : 631674331131572224,
    "created_at" : "2015-08-13 03:51:11 +0000",
    "user" : {
      "name" : "Morgan Fairchild",
      "screen_name" : "morgfair",
      "protected" : false,
      "id_str" : "156306739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1281652659\/mf2_normal.jpg",
      "id" : 156306739,
      "verified" : true
    }
  },
  "id" : 632725042258931712,
  "created_at" : "2015-08-16 01:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqueline Simonds",
      "screen_name" : "GrumpyDem",
      "indices" : [ 3, 13 ],
      "id_str" : "290664328",
      "id" : 290664328
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GrumpyDem\/status\/632641078311546880\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/I0Y3VECVyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeXsDVWgAAYcFe.jpg",
      "id_str" : "632641055733743616",
      "id" : 632641055733743616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeXsDVWgAAYcFe.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I0Y3VECVyc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632673500428378112",
  "text" : "RT @GrumpyDem: Every time someone talks about \"illegals\" living here, send them this. http:\/\/t.co\/I0Y3VECVyc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GrumpyDem\/status\/632641078311546880\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/I0Y3VECVyc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMeXsDVWgAAYcFe.jpg",
        "id_str" : "632641055733743616",
        "id" : 632641055733743616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMeXsDVWgAAYcFe.jpg",
        "sizes" : [ {
          "h" : 597,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 597,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I0Y3VECVyc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632641078311546880",
    "text" : "Every time someone talks about \"illegals\" living here, send them this. http:\/\/t.co\/I0Y3VECVyc",
    "id" : 632641078311546880,
    "created_at" : "2015-08-15 19:52:41 +0000",
    "user" : {
      "name" : "Jacqueline Simonds",
      "screen_name" : "GrumpyDem",
      "protected" : false,
      "id_str" : "290664328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747529945149149184\/t0Ba-Zlw_normal.jpg",
      "id" : 290664328,
      "verified" : false
    }
  },
  "id" : 632673500428378112,
  "created_at" : "2015-08-15 22:01:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632667915561467904",
  "geo" : { },
  "id_str" : "632672817205649409",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits strange story..",
  "id" : 632672817205649409,
  "in_reply_to_status_id" : 632667915561467904,
  "created_at" : "2015-08-15 21:58:48 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.G. Siegler",
      "screen_name" : "mgsiegler",
      "indices" : [ 3, 13 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Q3e2UWXOpL",
      "expanded_url" : "https:\/\/vine.co\/v\/edHiphgVOnd",
      "display_url" : "vine.co\/v\/edHiphgVOnd"
    } ]
  },
  "geo" : { },
  "id_str" : "632669360570691584",
  "text" : "RT @mgsiegler: Ladies and gentlemen, we've found a way to stop the drones.  https:\/\/t.co\/Q3e2UWXOpL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/Q3e2UWXOpL",
        "expanded_url" : "https:\/\/vine.co\/v\/edHiphgVOnd",
        "display_url" : "vine.co\/v\/edHiphgVOnd"
      } ]
    },
    "geo" : { },
    "id_str" : "632589192908959744",
    "text" : "Ladies and gentlemen, we've found a way to stop the drones.  https:\/\/t.co\/Q3e2UWXOpL",
    "id" : 632589192908959744,
    "created_at" : "2015-08-15 16:26:31 +0000",
    "user" : {
      "name" : "M.G. Siegler",
      "screen_name" : "mgsiegler",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770936610506571776\/WLvvp7LP_normal.jpg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 632669360570691584,
  "created_at" : "2015-08-15 21:45:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/07FHaKJdPL",
      "expanded_url" : "https:\/\/twitter.com\/justagoodlife\/status\/632331575707865088",
      "display_url" : "twitter.com\/justagoodlife\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632649946970353665",
  "text" : "good to know! (why it's done,what results mean) https:\/\/t.co\/07FHaKJdPL",
  "id" : 632649946970353665,
  "created_at" : "2015-08-15 20:27:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Cerrone",
      "screen_name" : "justagoodlife",
      "indices" : [ 0, 14 ],
      "id_str" : "1723493144",
      "id" : 1723493144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632645817556463616",
  "geo" : { },
  "id_str" : "632647949747621888",
  "in_reply_to_user_id" : 1723493144,
  "text" : "@justagoodlife and once it starts, takes a few days to get back to feeling normal.. ugh.",
  "id" : 632647949747621888,
  "in_reply_to_status_id" : 632645817556463616,
  "created_at" : "2015-08-15 20:19:59 +0000",
  "in_reply_to_screen_name" : "justagoodlife",
  "in_reply_to_user_id_str" : "1723493144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanessa-Shepherdess",
      "screen_name" : "NesFarm",
      "indices" : [ 3, 11 ],
      "id_str" : "390935410",
      "id" : 390935410
    }, {
      "name" : "Chris VetSchoolDiary",
      "screen_name" : "vetschooldiary",
      "indices" : [ 63, 78 ],
      "id_str" : "511647812",
      "id" : 511647812
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 79, 91 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632634221291532288",
  "text" : "RT @NesFarm: But how did they figure out who'd be in front? ;) @vetschooldiary @ErinEFarley\nCanada goose follows ...truck to water http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris VetSchoolDiary",
        "screen_name" : "vetschooldiary",
        "indices" : [ 50, 65 ],
        "id_str" : "511647812",
        "id" : 511647812
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 66, 78 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/4ttbuLwlhG",
        "expanded_url" : "http:\/\/www.cbc.ca\/1.3191611",
        "display_url" : "cbc.ca\/1.3191611"
      } ]
    },
    "geo" : { },
    "id_str" : "632616811465416704",
    "text" : "But how did they figure out who'd be in front? ;) @vetschooldiary @ErinEFarley\nCanada goose follows ...truck to water http:\/\/t.co\/4ttbuLwlhG",
    "id" : 632616811465416704,
    "created_at" : "2015-08-15 18:16:15 +0000",
    "user" : {
      "name" : "Vanessa-Shepherdess",
      "screen_name" : "NesFarm",
      "protected" : false,
      "id_str" : "390935410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745784297609641984\/y87N0kLd_normal.jpg",
      "id" : 390935410,
      "verified" : false
    }
  },
  "id" : 632634221291532288,
  "created_at" : "2015-08-15 19:25:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kalyn Brooke",
      "screen_name" : "kalynbr00ke",
      "indices" : [ 3, 15 ],
      "id_str" : "171208178",
      "id" : 171208178
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kalynbr00ke\/status\/611598033537626112\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/thCd2GJZLK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHzVK8RXAAEj5Fj.png",
      "id_str" : "611598033369890817",
      "id" : 611598033369890817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHzVK8RXAAEj5Fj.png",
      "sizes" : [ {
        "h" : 521,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/thCd2GJZLK"
    } ],
    "hashtags" : [ {
      "text" : "goodreads",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/LZTTuVIZkW",
      "expanded_url" : "http:\/\/buff.ly\/1enmLK3",
      "display_url" : "buff.ly\/1enmLK3"
    } ]
  },
  "geo" : { },
  "id_str" : "632601782837977088",
  "text" : "RT @kalynbr00ke: Book tracking and author lists made SIMPLE. http:\/\/t.co\/LZTTuVIZkW #goodreads http:\/\/t.co\/thCd2GJZLK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kalynbr00ke\/status\/611598033537626112\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/thCd2GJZLK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHzVK8RXAAEj5Fj.png",
        "id_str" : "611598033369890817",
        "id" : 611598033369890817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHzVK8RXAAEj5Fj.png",
        "sizes" : [ {
          "h" : 521,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/thCd2GJZLK"
      } ],
      "hashtags" : [ {
        "text" : "goodreads",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/LZTTuVIZkW",
        "expanded_url" : "http:\/\/buff.ly\/1enmLK3",
        "display_url" : "buff.ly\/1enmLK3"
      } ]
    },
    "geo" : { },
    "id_str" : "611598033537626112",
    "text" : "Book tracking and author lists made SIMPLE. http:\/\/t.co\/LZTTuVIZkW #goodreads http:\/\/t.co\/thCd2GJZLK",
    "id" : 611598033537626112,
    "created_at" : "2015-06-18 18:15:08 +0000",
    "user" : {
      "name" : "Kalyn Brooke",
      "screen_name" : "kalynbr00ke",
      "protected" : false,
      "id_str" : "171208178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672051741349646336\/U31ljbFY_normal.jpg",
      "id" : 171208178,
      "verified" : false
    }
  },
  "id" : 632601782837977088,
  "created_at" : "2015-08-15 17:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracie",
      "screen_name" : "PennyPinchinMom",
      "indices" : [ 3, 19 ],
      "id_str" : "30039324",
      "id" : 30039324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IKJbBQqAyJ",
      "expanded_url" : "http:\/\/ppmdeals.co\/1GoajEO",
      "display_url" : "ppmdeals.co\/1GoajEO"
    } ]
  },
  "geo" : { },
  "id_str" : "632600628594900992",
  "text" : "RT @PennyPinchinMom: Just in case you missed this! How to Make Money on Your FitBit (Or Other Activity Tracker) http:\/\/t.co\/IKJbBQqAyJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/IKJbBQqAyJ",
        "expanded_url" : "http:\/\/ppmdeals.co\/1GoajEO",
        "display_url" : "ppmdeals.co\/1GoajEO"
      } ]
    },
    "geo" : { },
    "id_str" : "629662967253106688",
    "text" : "Just in case you missed this! How to Make Money on Your FitBit (Or Other Activity Tracker) http:\/\/t.co\/IKJbBQqAyJ",
    "id" : 629662967253106688,
    "created_at" : "2015-08-07 14:38:44 +0000",
    "user" : {
      "name" : "Tracie",
      "screen_name" : "PennyPinchinMom",
      "protected" : false,
      "id_str" : "30039324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674360077130661888\/px01pPLE_normal.jpg",
      "id" : 30039324,
      "verified" : false
    }
  },
  "id" : 632600628594900992,
  "created_at" : "2015-08-15 17:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hari Kondabolu",
      "screen_name" : "harikondabolu",
      "indices" : [ 3, 17 ],
      "id_str" : "30488144",
      "id" : 30488144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632580700718415872",
  "text" : "RT @harikondabolu: If \"All Lives Matter,\" then why don't we have Universal Healthcare? And why are prisons privatized? And why are there st\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632397919048470528",
    "text" : "If \"All Lives Matter,\" then why don't we have Universal Healthcare? And why are prisons privatized? And why are there still homeless people?",
    "id" : 632397919048470528,
    "created_at" : "2015-08-15 03:46:27 +0000",
    "user" : {
      "name" : "Hari Kondabolu",
      "screen_name" : "harikondabolu",
      "protected" : false,
      "id_str" : "30488144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680930468284481536\/jZ6oHy0Y_normal.jpg",
      "id" : 30488144,
      "verified" : true
    }
  },
  "id" : 632580700718415872,
  "created_at" : "2015-08-15 15:52:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina morphis",
      "screen_name" : "TinaMorphis",
      "indices" : [ 3, 15 ],
      "id_str" : "942422990",
      "id" : 942422990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ryws4tjcOZ",
      "expanded_url" : "http:\/\/fb.me\/6DRNRR7p3",
      "display_url" : "fb.me\/6DRNRR7p3"
    } ]
  },
  "geo" : { },
  "id_str" : "632580621823537152",
  "text" : "RT @TinaMorphis: Fertility clinics destroy embryos all the time. Why aren\u2019t conservatives after them? http:\/\/t.co\/ryws4tjcOZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/ryws4tjcOZ",
        "expanded_url" : "http:\/\/fb.me\/6DRNRR7p3",
        "display_url" : "fb.me\/6DRNRR7p3"
      } ]
    },
    "geo" : { },
    "id_str" : "632530589548216321",
    "text" : "Fertility clinics destroy embryos all the time. Why aren\u2019t conservatives after them? http:\/\/t.co\/ryws4tjcOZ",
    "id" : 632530589548216321,
    "created_at" : "2015-08-15 12:33:39 +0000",
    "user" : {
      "name" : "tina morphis",
      "screen_name" : "TinaMorphis",
      "protected" : false,
      "id_str" : "942422990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796432524754952192\/2U85vKv3_normal.jpg",
      "id" : 942422990,
      "verified" : false
    }
  },
  "id" : 632580621823537152,
  "created_at" : "2015-08-15 15:52:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Post",
      "screen_name" : "theBerniePost",
      "indices" : [ 77, 91 ],
      "id_str" : "3312017672",
      "id" : 3312017672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BernieSanders",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/UFYS5jGwgs",
      "expanded_url" : "http:\/\/berniepost.com\/2015\/08\/why-new-yorkers-need-to-register-as-democrats-now\/",
      "display_url" : "berniepost.com\/2015\/08\/why-ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632573538579443712",
  "text" : "Why New Yorkers need to register as Democrats now http:\/\/t.co\/UFYS5jGwgs via @theBerniePost #BernieSanders",
  "id" : 632573538579443712,
  "created_at" : "2015-08-15 15:24:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632369622243745792",
  "geo" : { },
  "id_str" : "632370334558253056",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH wow. makes me cry.",
  "id" : 632370334558253056,
  "in_reply_to_status_id" : 632369622243745792,
  "created_at" : "2015-08-15 01:56:51 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632367519853060096",
  "geo" : { },
  "id_str" : "632368865691992065",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH I'd love to see a pic alongside showing the space they travel in the ocean...",
  "id" : 632368865691992065,
  "in_reply_to_status_id" : 632367519853060096,
  "created_at" : "2015-08-15 01:51:01 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    }, {
      "name" : "SeaWorld",
      "screen_name" : "SeaWorld",
      "indices" : [ 45, 54 ],
      "id_str" : "94618543",
      "id" : 94618543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632367308950929408",
  "text" : "RT @SciencePorn: The red line is the size of @SeaWorld's parking lot. The green line is where Orcas spend their entire lives http:\/\/t.co\/Aj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SeaWorld",
        "screen_name" : "SeaWorld",
        "indices" : [ 28, 37 ],
        "id_str" : "94618543",
        "id" : 94618543
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/632349844309475328\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/AjJP9uzCSv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMaO1T_WUAA0uHP.jpg",
        "id_str" : "632349844242321408",
        "id" : 632349844242321408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMaO1T_WUAA0uHP.jpg",
        "sizes" : [ {
          "h" : 782,
          "resize" : "fit",
          "w" : 561
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 782,
          "resize" : "fit",
          "w" : 561
        }, {
          "h" : 782,
          "resize" : "fit",
          "w" : 561
        } ],
        "display_url" : "pic.twitter.com\/AjJP9uzCSv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632349844309475328",
    "text" : "The red line is the size of @SeaWorld's parking lot. The green line is where Orcas spend their entire lives http:\/\/t.co\/AjJP9uzCSv",
    "id" : 632349844309475328,
    "created_at" : "2015-08-15 00:35:26 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 632367308950929408,
  "created_at" : "2015-08-15 01:44:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hero",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/alAM4VEKUC",
      "expanded_url" : "http:\/\/thedo.do\/1MoN13e",
      "display_url" : "thedo.do\/1MoN13e"
    } ]
  },
  "geo" : { },
  "id_str" : "632346703727886336",
  "text" : "RT @SangyeH: Activist Jumps into Bullfighting Ring to Comfort Dying Bull http:\/\/t.co\/alAM4VEKUC \n\nShe was spit on, cursed &amp; arrested. #Hero\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 134, 144 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hero",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/alAM4VEKUC",
        "expanded_url" : "http:\/\/thedo.do\/1MoN13e",
        "display_url" : "thedo.do\/1MoN13e"
      } ]
    },
    "geo" : { },
    "id_str" : "632331145095589888",
    "text" : "Activist Jumps into Bullfighting Ring to Comfort Dying Bull http:\/\/t.co\/alAM4VEKUC \n\nShe was spit on, cursed &amp; arrested. #Hero \nc @JALPalyul",
    "id" : 632331145095589888,
    "created_at" : "2015-08-14 23:21:07 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 632346703727886336,
  "created_at" : "2015-08-15 00:22:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 9, 19 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632331145095589888",
  "geo" : { },
  "id_str" : "632346678805299201",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH @JALpalyul aww.. bless her. #compassion",
  "id" : 632346678805299201,
  "in_reply_to_status_id" : 632331145095589888,
  "created_at" : "2015-08-15 00:22:51 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toocute",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/2i2zgkzewS",
      "expanded_url" : "https:\/\/twitter.com\/Carreg_Cennen\/status\/632291864733982720",
      "display_url" : "twitter.com\/Carreg_Cennen\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632301031616028672",
  "text" : "awwww.. cuddles! #toocute https:\/\/t.co\/2i2zgkzewS",
  "id" : 632301031616028672,
  "created_at" : "2015-08-14 21:21:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Tilton-Flood",
      "screen_name" : "jtiltonflood",
      "indices" : [ 3, 16 ],
      "id_str" : "21722797",
      "id" : 21722797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maine",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "Summer",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "Cornfield",
      "indices" : [ 78, 88 ]
    }, {
      "text" : "Sunset",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "EasternView",
      "indices" : [ 97, 109 ]
    }, {
      "text" : "farm365",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632299560526815232",
  "text" : "RT @jtiltonflood: In my world even the mud puddles are pretty. #Maine #Summer #Cornfield #Sunset #EasternView #farm365 http:\/\/t.co\/XVCWK0FC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jtiltonflood\/status\/632163931910447105\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/XVCWK0FCZQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMXlu8hUsAA8maH.jpg",
        "id_str" : "632163917398061056",
        "id" : 632163917398061056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMXlu8hUsAA8maH.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XVCWK0FCZQ"
      } ],
      "hashtags" : [ {
        "text" : "Maine",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "Summer",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "Cornfield",
        "indices" : [ 60, 70 ]
      }, {
        "text" : "Sunset",
        "indices" : [ 71, 78 ]
      }, {
        "text" : "EasternView",
        "indices" : [ 79, 91 ]
      }, {
        "text" : "farm365",
        "indices" : [ 92, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632163931910447105",
    "text" : "In my world even the mud puddles are pretty. #Maine #Summer #Cornfield #Sunset #EasternView #farm365 http:\/\/t.co\/XVCWK0FCZQ",
    "id" : 632163931910447105,
    "created_at" : "2015-08-14 12:16:41 +0000",
    "user" : {
      "name" : "Jenni Tilton-Flood",
      "screen_name" : "jtiltonflood",
      "protected" : false,
      "id_str" : "21722797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766868233005719552\/CaspRzVR_normal.jpg",
      "id" : 21722797,
      "verified" : false
    }
  },
  "id" : 632299560526815232,
  "created_at" : "2015-08-14 21:15:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/FDjthqDZqD",
      "expanded_url" : "https:\/\/twitter.com\/RossHamiltonG\/status\/632255384737091584",
      "display_url" : "twitter.com\/RossHamiltonG\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632299431384215552",
  "text" : "so precious, so smoochable! https:\/\/t.co\/FDjthqDZqD",
  "id" : 632299431384215552,
  "created_at" : "2015-08-14 21:15:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632280992351301632",
  "geo" : { },
  "id_str" : "632297644241592320",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ((highfive)) you go, sister! you are awesome! &lt;3",
  "id" : 632297644241592320,
  "in_reply_to_status_id" : 632280992351301632,
  "created_at" : "2015-08-14 21:08:00 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632073008325238785",
  "geo" : { },
  "id_str" : "632211236613189632",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley gorgeous!",
  "id" : 632211236613189632,
  "in_reply_to_status_id" : 632073008325238785,
  "created_at" : "2015-08-14 15:24:39 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632210697917612037",
  "text" : "@HEATHENRABBIT LOLOL",
  "id" : 632210697917612037,
  "created_at" : "2015-08-14 15:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/yAWpVVWAJo",
      "expanded_url" : "https:\/\/timfall.wordpress.com\/2015\/08\/13\/why-is-the-council-on-biblical-manhood-and-womanhood-targeting-my-kids\/",
      "display_url" : "timfall.wordpress.com\/2015\/08\/13\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632006526694227968",
  "text" : "Why is the Council on Biblical Manhood and Womanhood Targeting My Kids?\n\nhttps:\/\/t.co\/yAWpVVWAJo\n\nSent from FeedLab",
  "id" : 632006526694227968,
  "created_at" : "2015-08-14 01:51:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/eCyHDoV6Qh",
      "expanded_url" : "https:\/\/twitter.com\/luligawa\/status\/631842416073445376",
      "display_url" : "twitter.com\/luligawa\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631911300453527552",
  "text" : "wth would they need this in USA??? https:\/\/t.co\/eCyHDoV6Qh",
  "id" : 631911300453527552,
  "created_at" : "2015-08-13 19:32:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/RfmSToFijM",
      "expanded_url" : "https:\/\/twitter.com\/VonniMediaMogul\/status\/631849075630055424",
      "display_url" : "twitter.com\/VonniMediaMogu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631910790250037249",
  "text" : "RT @deray: You mad or nah? https:\/\/t.co\/RfmSToFijM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/RfmSToFijM",
        "expanded_url" : "https:\/\/twitter.com\/VonniMediaMogul\/status\/631849075630055424",
        "display_url" : "twitter.com\/VonniMediaMogu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631856788179017728",
    "text" : "You mad or nah? https:\/\/t.co\/RfmSToFijM",
    "id" : 631856788179017728,
    "created_at" : "2015-08-13 15:56:12 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 631910790250037249,
  "created_at" : "2015-08-13 19:30:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 130, 136 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631910093467054081",
  "text" : "RT @ReaLSixFingers: Dude mentions #Ferguson, KNOCKED OUT a cop, and lived to salute in his mugshot? \"Watch how whiteness works\" - @deray \nh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 110, 116 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/yI631OfFDW",
        "expanded_url" : "http:\/\/boston.cbslocal.com\/2015\/08\/11\/revere-police-officer-assault\/",
        "display_url" : "boston.cbslocal.com\/2015\/08\/11\/rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631896432505585664",
    "text" : "Dude mentions #Ferguson, KNOCKED OUT a cop, and lived to salute in his mugshot? \"Watch how whiteness works\" - @deray \nhttp:\/\/t.co\/yI631OfFDW",
    "id" : 631896432505585664,
    "created_at" : "2015-08-13 18:33:44 +0000",
    "user" : {
      "name" : "Church Holiday, Esq.",
      "screen_name" : "DrSixFingersEsq",
      "protected" : false,
      "id_str" : "328348616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795468603663548416\/txf2Lhz9_normal.jpg",
      "id" : 328348616,
      "verified" : false
    }
  },
  "id" : 631910093467054081,
  "created_at" : "2015-08-13 19:28:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/enRCiwt25L",
      "expanded_url" : "https:\/\/youtu.be\/9T90_RiOXmY",
      "display_url" : "youtu.be\/9T90_RiOXmY"
    } ]
  },
  "geo" : { },
  "id_str" : "631893575664599040",
  "text" : "Cool &gt;&gt; She Looked at Her Father's Ashes With a Microscope and Saw the Universe https:\/\/t.co\/enRCiwt25L",
  "id" : 631893575664599040,
  "created_at" : "2015-08-13 18:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Oaz1mPp7Xh",
      "expanded_url" : "https:\/\/twitter.com\/TheBaxterBean\/status\/631878319038943232",
      "display_url" : "twitter.com\/TheBaxterBean\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631881491350470656",
  "text" : "who can say anything mean about Jimmy Carter? jeez. https:\/\/t.co\/Oaz1mPp7Xh",
  "id" : 631881491350470656,
  "created_at" : "2015-08-13 17:34:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3mirCtUbUr",
      "expanded_url" : "http:\/\/www.rawstory.com\/2015\/08\/ben-carson-conducted-fetal-tissue-research-as-a-doctor-which-he-now-opposes-as-gop-candidate\/#.Vcy0YcKl3FY.twitter",
      "display_url" : "rawstory.com\/2015\/08\/ben-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631857947073728512",
  "text" : "RT @knittingknots: Ben Carson conducted fetal tissue research as a doctor -- which he now opposes as GOP candidate http:\/\/t.co\/3mirCtUbUr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/3mirCtUbUr",
        "expanded_url" : "http:\/\/www.rawstory.com\/2015\/08\/ben-carson-conducted-fetal-tissue-research-as-a-doctor-which-he-now-opposes-as-gop-candidate\/#.Vcy0YcKl3FY.twitter",
        "display_url" : "rawstory.com\/2015\/08\/ben-ca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631846357393772545",
    "text" : "Ben Carson conducted fetal tissue research as a doctor -- which he now opposes as GOP candidate http:\/\/t.co\/3mirCtUbUr",
    "id" : 631846357393772545,
    "created_at" : "2015-08-13 15:14:45 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 631857947073728512,
  "created_at" : "2015-08-13 16:00:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthews&Associates",
      "screen_name" : "Lawfirm_MA",
      "indices" : [ 3, 14 ],
      "id_str" : "493123841",
      "id" : 493123841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631857541811671040",
  "text" : "RT @Lawfirm_MA: Court letter said, \u201CMerck should not be permitted to raise as 1 of its principal defenses that its vaccine has high efficac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631847676288499713",
    "text" : "Court letter said, \u201CMerck should not be permitted to raise as 1 of its principal defenses that its vaccine has high efficacy, which is...",
    "id" : 631847676288499713,
    "created_at" : "2015-08-13 15:19:59 +0000",
    "user" : {
      "name" : "Matthews&Associates",
      "screen_name" : "Lawfirm_MA",
      "protected" : false,
      "id_str" : "493123841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758029557463076864\/RquQIKI3_normal.jpg",
      "id" : 493123841,
      "verified" : false
    }
  },
  "id" : 631857541811671040,
  "created_at" : "2015-08-13 15:59:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631856610135146497",
  "text" : "RT @JohnFugelsang: Ben Carson used aborted fetal tissue.  Tune into FOX to not hear more!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631853112123195392",
    "text" : "Ben Carson used aborted fetal tissue.  Tune into FOX to not hear more!",
    "id" : 631853112123195392,
    "created_at" : "2015-08-13 15:41:35 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 631856610135146497,
  "created_at" : "2015-08-13 15:55:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631853797812342784",
  "text" : "RT @TyrusBooks: Hi, Twitter. Do you or somebody you know need help with school supplies this fall? If so, we're standing by to help. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FDgpsKsMOM",
        "expanded_url" : "http:\/\/benjaminleroy.com\/2015\/08\/13\/free-school-supplies-for-those-in-need\/",
        "display_url" : "benjaminleroy.com\/2015\/08\/13\/fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631839676689616896",
    "text" : "Hi, Twitter. Do you or somebody you know need help with school supplies this fall? If so, we're standing by to help. http:\/\/t.co\/FDgpsKsMOM",
    "id" : 631839676689616896,
    "created_at" : "2015-08-13 14:48:12 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 631853797812342784,
  "created_at" : "2015-08-13 15:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ocd",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631852843356585985",
  "text" : "when I get interested in something, I tend to over do it. ive gone spreadsheet crazy. saved too many templates! #ocd",
  "id" : 631852843356585985,
  "created_at" : "2015-08-13 15:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631847766516453376",
  "text" : "RT @forestberkeley: \u201CThere is only one way to learn. It's through action. Everything you need to know you have learned through your journey\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631846701758828544",
    "text" : "\u201CThere is only one way to learn. It's through action. Everything you need to know you have learned through your journey.\u201D",
    "id" : 631846701758828544,
    "created_at" : "2015-08-13 15:16:07 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 631847766516453376,
  "created_at" : "2015-08-13 15:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631825704938815489",
  "geo" : { },
  "id_str" : "631834639125114881",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ohh.. looks good. ((adds book to TBR list))",
  "id" : 631834639125114881,
  "in_reply_to_status_id" : 631825704938815489,
  "created_at" : "2015-08-13 14:28:11 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/FeniceWindows\/\" rel=\"nofollow\"\u003EFenice for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631638757876330501",
  "text" : "RT @JohnFugelsang: Chelsea Manning is in jail for exposing crimes nobody's ever going to jail for.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631636895777320961",
    "text" : "Chelsea Manning is in jail for exposing crimes nobody's ever going to jail for.",
    "id" : 631636895777320961,
    "created_at" : "2015-08-13 01:22:25 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 631638757876330501,
  "created_at" : "2015-08-13 01:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Carrillo",
      "screen_name" : "ChristineCarril",
      "indices" : [ 3, 19 ],
      "id_str" : "3223600974",
      "id" : 3223600974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitalhealth",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/aXhQwEgxRj",
      "expanded_url" : "http:\/\/buff.ly\/1IDeRqf",
      "display_url" : "buff.ly\/1IDeRqf"
    } ]
  },
  "geo" : { },
  "id_str" : "631632921414234112",
  "text" : "RT @ChristineCarril: Awesome. Wearables help manage neurological disorders, predict symptoms http:\/\/t.co\/aXhQwEgxRj #digitalhealth #healthc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "digitalhealth",
        "indices" : [ 95, 109 ]
      }, {
        "text" : "healthcare",
        "indices" : [ 110, 121 ]
      }, {
        "text" : "IoT",
        "indices" : [ 122, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/aXhQwEgxRj",
        "expanded_url" : "http:\/\/buff.ly\/1IDeRqf",
        "display_url" : "buff.ly\/1IDeRqf"
      } ]
    },
    "geo" : { },
    "id_str" : "631601819567943680",
    "text" : "Awesome. Wearables help manage neurological disorders, predict symptoms http:\/\/t.co\/aXhQwEgxRj #digitalhealth #healthcare #IoT",
    "id" : 631601819567943680,
    "created_at" : "2015-08-12 23:03:03 +0000",
    "user" : {
      "name" : "Christine Carrillo",
      "screen_name" : "ChristineCarril",
      "protected" : false,
      "id_str" : "3223600974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640388688761847808\/VBauHsji_normal.jpg",
      "id" : 3223600974,
      "verified" : false
    }
  },
  "id" : 631632921414234112,
  "created_at" : "2015-08-13 01:06:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Q2ktipo4nb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4MAWsAAsl25.jpg",
      "id_str" : "631568140871315456",
      "id" : 631568140871315456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4MAWsAAsl25.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q2ktipo4nb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Q2ktipo4nb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4N6WsAAWTaO.jpg",
      "id_str" : "631568141383020544",
      "id" : 631568141383020544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4N6WsAAWTaO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Q2ktipo4nb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Q2ktipo4nb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4PYWUAE5HrR.jpg",
      "id_str" : "631568141777260545",
      "id" : 631568141777260545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4PYWUAE5HrR.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q2ktipo4nb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Q2ktipo4nb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4umWsAAYmFe.jpg",
      "id_str" : "631568150157504512",
      "id" : 631568150157504512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4umWsAAYmFe.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q2ktipo4nb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631616762337992705",
  "text" : "RT @newlandfarm: Sunset http:\/\/t.co\/Q2ktipo4nb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/Q2ktipo4nb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4MAWsAAsl25.jpg",
        "id_str" : "631568140871315456",
        "id" : 631568140871315456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4MAWsAAsl25.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Q2ktipo4nb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/Q2ktipo4nb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4N6WsAAWTaO.jpg",
        "id_str" : "631568141383020544",
        "id" : 631568141383020544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4N6WsAAWTaO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 124,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Q2ktipo4nb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/Q2ktipo4nb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4PYWUAE5HrR.jpg",
        "id_str" : "631568141777260545",
        "id" : 631568141777260545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4PYWUAE5HrR.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Q2ktipo4nb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631568219866796032\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/Q2ktipo4nb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPH4umWsAAYmFe.jpg",
        "id_str" : "631568150157504512",
        "id" : 631568150157504512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPH4umWsAAYmFe.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Q2ktipo4nb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631568219866796032",
    "text" : "Sunset http:\/\/t.co\/Q2ktipo4nb",
    "id" : 631568219866796032,
    "created_at" : "2015-08-12 20:49:32 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 631616762337992705,
  "created_at" : "2015-08-13 00:02:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/Armr7mhlof",
      "expanded_url" : "https:\/\/vine.co\/v\/edragwYKY9V",
      "display_url" : "vine.co\/v\/edragwYKY9V"
    } ]
  },
  "geo" : { },
  "id_str" : "631498067385004032",
  "text" : "RT @1CatShepherd: Inspecting the ripening apple crop https:\/\/t.co\/Armr7mhlof",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/Armr7mhlof",
        "expanded_url" : "https:\/\/vine.co\/v\/edragwYKY9V",
        "display_url" : "vine.co\/v\/edragwYKY9V"
      } ]
    },
    "geo" : { },
    "id_str" : "631428982576185344",
    "text" : "Inspecting the ripening apple crop https:\/\/t.co\/Armr7mhlof",
    "id" : 631428982576185344,
    "created_at" : "2015-08-12 11:36:15 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 631498067385004032,
  "created_at" : "2015-08-12 16:10:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 85, 97 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/LSfsrMgyNM",
      "expanded_url" : "https:\/\/vine.co\/v\/edvM521U7rg",
      "display_url" : "vine.co\/v\/edvM521U7rg"
    } ]
  },
  "geo" : { },
  "id_str" : "631497753688870912",
  "text" : "RT @ErinEFarley: Alfie getting all romantic muttering sweet nothings to ewe (Vine by @ZwartblesIE) https:\/\/t.co\/LSfsrMgyNM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zwartbles Ireland",
        "screen_name" : "ZwartblesIE",
        "indices" : [ 68, 80 ],
        "id_str" : "299804123",
        "id" : 299804123
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/LSfsrMgyNM",
        "expanded_url" : "https:\/\/vine.co\/v\/edvM521U7rg",
        "display_url" : "vine.co\/v\/edvM521U7rg"
      } ]
    },
    "geo" : { },
    "id_str" : "631489745420460032",
    "text" : "Alfie getting all romantic muttering sweet nothings to ewe (Vine by @ZwartblesIE) https:\/\/t.co\/LSfsrMgyNM",
    "id" : 631489745420460032,
    "created_at" : "2015-08-12 15:37:42 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 631497753688870912,
  "created_at" : "2015-08-12 16:09:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/gDeC8DsH7C",
      "expanded_url" : "https:\/\/instagram.com\/p\/6SfjG8NqXo\/",
      "display_url" : "instagram.com\/p\/6SfjG8NqXo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "631492820776452096",
  "text" : "Magical spider web https:\/\/t.co\/gDeC8DsH7C",
  "id" : 631492820776452096,
  "created_at" : "2015-08-12 15:49:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/JfTqmIaFsq",
      "expanded_url" : "https:\/\/drive.google.com\/file\/d\/0BwSV98mrpTw-YmVMNGhRU1pWQUNHamFVelRFMExQT21oNnVz\/view?usp=sharing",
      "display_url" : "drive.google.com\/file\/d\/0BwSV98\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631487513408991232",
  "text" : "Magical Spider Web \nhttps:\/\/t.co\/JfTqmIaFsq",
  "id" : 631487513408991232,
  "created_at" : "2015-08-12 15:28:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631481355076026368",
  "text" : "see glittering out of corner of eye.. magical.. like faery sprinkles.. its sun reflecting off spider web.",
  "id" : 631481355076026368,
  "created_at" : "2015-08-12 15:04:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631475674071584768",
  "text" : "RT @UnseelieMe: In related news, 1 month after returning to levothyroxine, my heart issues have stopped &amp; my blood pressure was so low they\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631471768457195521",
    "text" : "In related news, 1 month after returning to levothyroxine, my heart issues have stopped &amp; my blood pressure was so low they took me off meds",
    "id" : 631471768457195521,
    "created_at" : "2015-08-12 14:26:16 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 631475674071584768,
  "created_at" : "2015-08-12 14:41:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631475638554259456",
  "text" : "RT @UnseelieMe: So it turns out I was right &amp; my doctor was wrong. Switching from levothyroxine to synthroid CAN cause high blood pressure \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631471522952036352",
    "text" : "So it turns out I was right &amp; my doctor was wrong. Switching from levothyroxine to synthroid CAN cause high blood pressure &amp; heart issues!!",
    "id" : 631471522952036352,
    "created_at" : "2015-08-12 14:25:17 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 631475638554259456,
  "created_at" : "2015-08-12 14:41:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razorblade Snowflake",
      "screen_name" : "Keffy",
      "indices" : [ 3, 9 ],
      "id_str" : "14788929",
      "id" : 14788929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631474863094546432",
  "text" : "RT @Keffy: Jesus Christ just legalize it already and save the money. Also stop giving tanks to cops you stupid shits. https:\/\/t.co\/Q6CgPJQ8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Q6CgPJQ8VU",
        "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/631291860049203201",
        "display_url" : "twitter.com\/washingtonpost\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631297150329188352",
    "text" : "Jesus Christ just legalize it already and save the money. Also stop giving tanks to cops you stupid shits. https:\/\/t.co\/Q6CgPJQ8VU",
    "id" : 631297150329188352,
    "created_at" : "2015-08-12 02:52:24 +0000",
    "user" : {
      "name" : "Razorblade Snowflake",
      "screen_name" : "Keffy",
      "protected" : false,
      "id_str" : "14788929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685631123435745280\/22Prtigc_normal.jpg",
      "id" : 14788929,
      "verified" : false
    }
  },
  "id" : 631474863094546432,
  "created_at" : "2015-08-12 14:38:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neen\u00E4  \u02C6\u2323\u02C6",
      "screen_name" : "Tum55",
      "indices" : [ 3, 9 ],
      "id_str" : "73623198",
      "id" : 73623198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631473191492419584",
  "text" : "RT @Tum55: Let happiness overtake you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631384678600015872",
    "text" : "Let happiness overtake you.",
    "id" : 631384678600015872,
    "created_at" : "2015-08-12 08:40:12 +0000",
    "user" : {
      "name" : "neen\u00E4  \u02C6\u2323\u02C6",
      "screen_name" : "Tum55",
      "protected" : false,
      "id_str" : "73623198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797380621051924480\/SHP0yA94_normal.jpg",
      "id" : 73623198,
      "verified" : false
    }
  },
  "id" : 631473191492419584,
  "created_at" : "2015-08-12 14:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631471987886551040",
  "text" : "RT @Mahala: I think my inner peace went on vacation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631448523599429632",
    "text" : "I think my inner peace went on vacation.",
    "id" : 631448523599429632,
    "created_at" : "2015-08-12 12:53:54 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 631471987886551040,
  "created_at" : "2015-08-12 14:27:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rare Bird Alert",
      "screen_name" : "RareBirdAlertUK",
      "indices" : [ 3, 19 ],
      "id_str" : "145217542",
      "id" : 145217542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/8b4NjMMHEI",
      "expanded_url" : "http:\/\/bit.ly\/1L5ad58",
      "display_url" : "bit.ly\/1L5ad58"
    } ]
  },
  "geo" : { },
  "id_str" : "631453278858051585",
  "text" : "RT @RareBirdAlertUK: Out Now weekly birding roundup 5-11 Aug\n\nhttp:\/\/t.co\/8b4NjMMHEI\n\nPls RT if you enjoy these free weekly roundups, thks \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RareBirdAlertUK\/status\/631444415484162048\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BQFQabprXv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNXWTrWoAARKAF.jpg",
        "id_str" : "631444413512851456",
        "id" : 631444413512851456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNXWTrWoAARKAF.jpg",
        "sizes" : [ {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/BQFQabprXv"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/RareBirdAlertUK\/status\/631444415484162048\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BQFQabprXv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNXWVeXAAAKdbg.jpg",
        "id_str" : "631444413995220992",
        "id" : 631444413995220992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNXWVeXAAAKdbg.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/BQFQabprXv"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/RareBirdAlertUK\/status\/631444415484162048\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BQFQabprXv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNXWSlWUAACP72.jpg",
        "id_str" : "631444413219229696",
        "id" : 631444413219229696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNXWSlWUAACP72.jpg",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BQFQabprXv"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/RareBirdAlertUK\/status\/631444415484162048\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BQFQabprXv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNXWW5WcAAPyUk.jpg",
        "id_str" : "631444414376865792",
        "id" : 631444414376865792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNXWW5WcAAPyUk.jpg",
        "sizes" : [ {
          "h" : 155,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BQFQabprXv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/8b4NjMMHEI",
        "expanded_url" : "http:\/\/bit.ly\/1L5ad58",
        "display_url" : "bit.ly\/1L5ad58"
      } ]
    },
    "geo" : { },
    "id_str" : "631444415484162048",
    "text" : "Out Now weekly birding roundup 5-11 Aug\n\nhttp:\/\/t.co\/8b4NjMMHEI\n\nPls RT if you enjoy these free weekly roundups, thks http:\/\/t.co\/BQFQabprXv",
    "id" : 631444415484162048,
    "created_at" : "2015-08-12 12:37:34 +0000",
    "user" : {
      "name" : "Rare Bird Alert",
      "screen_name" : "RareBirdAlertUK",
      "protected" : false,
      "id_str" : "145217542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612923926528655361\/AvyBPHZ4_normal.png",
      "id" : 145217542,
      "verified" : false
    }
  },
  "id" : 631453278858051585,
  "created_at" : "2015-08-12 13:12:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Intercept FLM",
      "screen_name" : "the_intercept",
      "indices" : [ 3, 17 ],
      "id_str" : "719972682322853888",
      "id" : 719972682322853888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631272076062687233",
  "text" : "RT @the_intercept: \u201CWhen did they know? Did they lie?\u201D \u2014 the full story behind DuPont\u2019s toxic Teflon coating, and the lives it destroyed ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ioRZvrerK2",
        "expanded_url" : "http:\/\/interc.pt\/1WgrmPw",
        "display_url" : "interc.pt\/1WgrmPw"
      } ]
    },
    "in_reply_to_status_id_str" : "631235170109136898",
    "geo" : { },
    "id_str" : "631262836799483904",
    "in_reply_to_user_id" : 2329066872,
    "text" : "\u201CWhen did they know? Did they lie?\u201D \u2014 the full story behind DuPont\u2019s toxic Teflon coating, and the lives it destroyed http:\/\/t.co\/ioRZvrerK2",
    "id" : 631262836799483904,
    "in_reply_to_status_id" : 631235170109136898,
    "created_at" : "2015-08-12 00:36:03 +0000",
    "in_reply_to_screen_name" : "theintercept",
    "in_reply_to_user_id_str" : "2329066872",
    "user" : {
      "name" : "The Intercept",
      "screen_name" : "theintercept",
      "protected" : false,
      "id_str" : "2329066872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761255184697876480\/8Jssd8S5_normal.jpg",
      "id" : 2329066872,
      "verified" : true
    }
  },
  "id" : 631272076062687233,
  "created_at" : "2015-08-12 01:12:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnetta Elzie",
      "screen_name" : "Nettaaaaaaaa",
      "indices" : [ 3, 16 ],
      "id_str" : "1291770157",
      "id" : 1291770157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "i70Shutdown",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/kgtctcNEi0",
      "expanded_url" : "https:\/\/vine.co\/v\/ed5Ww5PZrQh",
      "display_url" : "vine.co\/v\/ed5Ww5PZrQh"
    } ]
  },
  "geo" : { },
  "id_str" : "631270529861873664",
  "text" : "RT @Nettaaaaaaaa: We have nothing to lose but our chains #i70Shutdown https:\/\/t.co\/kgtctcNEi0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "i70Shutdown",
        "indices" : [ 39, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/kgtctcNEi0",
        "expanded_url" : "https:\/\/vine.co\/v\/ed5Ww5PZrQh",
        "display_url" : "vine.co\/v\/ed5Ww5PZrQh"
      } ]
    },
    "geo" : { },
    "id_str" : "631263256972292097",
    "text" : "We have nothing to lose but our chains #i70Shutdown https:\/\/t.co\/kgtctcNEi0",
    "id" : 631263256972292097,
    "created_at" : "2015-08-12 00:37:43 +0000",
    "user" : {
      "name" : "Johnetta Elzie",
      "screen_name" : "Nettaaaaaaaa",
      "protected" : false,
      "id_str" : "1291770157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787012721770242048\/eqkqR7eZ_normal.jpg",
      "id" : 1291770157,
      "verified" : true
    }
  },
  "id" : 631270529861873664,
  "created_at" : "2015-08-12 01:06:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debra Messing",
      "screen_name" : "DebraMessing",
      "indices" : [ 3, 16 ],
      "id_str" : "499073990",
      "id" : 499073990
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DebraMessing\/status\/631178761094963200\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/eYNqwQrMyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMJlusxWwAEez8b.jpg",
      "id_str" : "631178750751850497",
      "id" : 631178750751850497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMJlusxWwAEez8b.jpg",
      "sizes" : [ {
        "h" : 759,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eYNqwQrMyc"
    } ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631269731979411456",
  "text" : "RT @DebraMessing: Most people don't know their rights. ( I didn't) Here they are--#BlackLivesMatter http:\/\/t.co\/eYNqwQrMyc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DebraMessing\/status\/631178761094963200\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/eYNqwQrMyc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMJlusxWwAEez8b.jpg",
        "id_str" : "631178750751850497",
        "id" : 631178750751850497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMJlusxWwAEez8b.jpg",
        "sizes" : [ {
          "h" : 759,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 759,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/eYNqwQrMyc"
      } ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 64, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631178761094963200",
    "text" : "Most people don't know their rights. ( I didn't) Here they are--#BlackLivesMatter http:\/\/t.co\/eYNqwQrMyc",
    "id" : 631178761094963200,
    "created_at" : "2015-08-11 19:01:58 +0000",
    "user" : {
      "name" : "Debra Messing",
      "screen_name" : "DebraMessing",
      "protected" : false,
      "id_str" : "499073990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1845772090\/Debra-Messing-003WIND_normal.jpg",
      "id" : 499073990,
      "verified" : true
    }
  },
  "id" : 631269731979411456,
  "created_at" : "2015-08-12 01:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "sick",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631267354811346944",
  "text" : "DD says \"It's like having the flu every day.\" #hashimotos #thyroid #sick",
  "id" : 631267354811346944,
  "created_at" : "2015-08-12 00:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secular Humanist",
      "screen_name" : "Reilly4Sanity",
      "indices" : [ 3, 17 ],
      "id_str" : "184998424",
      "id" : 184998424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631238160857501696",
  "text" : "RT @Reilly4Sanity: I just want to make sure I have this right: Unarmed black people exercising their constitutionally... http:\/\/t.co\/z8DEcS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/z8DEcSQn70",
        "expanded_url" : "http:\/\/tmblr.co\/Z6fNKx1rnM9V2",
        "display_url" : "tmblr.co\/Z6fNKx1rnM9V2"
      } ]
    },
    "geo" : { },
    "id_str" : "631224516761518080",
    "text" : "I just want to make sure I have this right: Unarmed black people exercising their constitutionally... http:\/\/t.co\/z8DEcSQn70",
    "id" : 631224516761518080,
    "created_at" : "2015-08-11 22:03:47 +0000",
    "user" : {
      "name" : "Secular Humanist",
      "screen_name" : "Reilly4Sanity",
      "protected" : false,
      "id_str" : "184998424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797619970624651268\/GOoWyuzC_normal.jpg",
      "id" : 184998424,
      "verified" : false
    }
  },
  "id" : 631238160857501696,
  "created_at" : "2015-08-11 22:58:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/631233332685111297\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/msmduTHRvV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKXXs5UwAAqkAk.jpg",
      "id_str" : "631233331229671424",
      "id" : 631233331229671424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKXXs5UwAAqkAk.jpg",
      "sizes" : [ {
        "h" : 1177,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1405,
        "resize" : "fit",
        "w" : 1222
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/msmduTHRvV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631234535061979136",
  "text" : "RT @ChippyCMunk: Chippy likes having the wall to lean on http:\/\/t.co\/msmduTHRvV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/631233332685111297\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/msmduTHRvV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKXXs5UwAAqkAk.jpg",
        "id_str" : "631233331229671424",
        "id" : 631233331229671424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKXXs5UwAAqkAk.jpg",
        "sizes" : [ {
          "h" : 1177,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1405,
          "resize" : "fit",
          "w" : 1222
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/msmduTHRvV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631233332685111297",
    "text" : "Chippy likes having the wall to lean on http:\/\/t.co\/msmduTHRvV",
    "id" : 631233332685111297,
    "created_at" : "2015-08-11 22:38:48 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 631234535061979136,
  "created_at" : "2015-08-11 22:43:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ribfuvwFX9",
      "expanded_url" : "http:\/\/bit.ly\/1P78FsJ",
      "display_url" : "bit.ly\/1P78FsJ"
    } ]
  },
  "geo" : { },
  "id_str" : "631231419822444544",
  "text" : "RT @jonlieffmd: Crows share many characteristics with humans, including advanced memory and tool use. http:\/\/t.co\/ribfuvwFX9 http:\/\/t.co\/qQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/631223569842872320\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/qQHwHsKIlx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKOfgtW8AExGf_.jpg",
        "id_str" : "631223569792561153",
        "id" : 631223569792561153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKOfgtW8AExGf_.jpg",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/qQHwHsKIlx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/ribfuvwFX9",
        "expanded_url" : "http:\/\/bit.ly\/1P78FsJ",
        "display_url" : "bit.ly\/1P78FsJ"
      } ]
    },
    "geo" : { },
    "id_str" : "631223569842872320",
    "text" : "Crows share many characteristics with humans, including advanced memory and tool use. http:\/\/t.co\/ribfuvwFX9 http:\/\/t.co\/qQHwHsKIlx",
    "id" : 631223569842872320,
    "created_at" : "2015-08-11 22:00:01 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 631231419822444544,
  "created_at" : "2015-08-11 22:31:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 3, 14 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/631203664473030656\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/elkwAd2A7Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMJ8YDcWUAA8FzP.jpg",
      "id_str" : "631203650468204544",
      "id" : 631203650468204544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMJ8YDcWUAA8FzP.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/elkwAd2A7Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631230302673735680",
  "text" : "RT @PVickerton: Now then ..... http:\/\/t.co\/elkwAd2A7Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/631203664473030656\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/elkwAd2A7Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMJ8YDcWUAA8FzP.jpg",
        "id_str" : "631203650468204544",
        "id" : 631203650468204544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMJ8YDcWUAA8FzP.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/elkwAd2A7Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631203664473030656",
    "text" : "Now then ..... http:\/\/t.co\/elkwAd2A7Z",
    "id" : 631203664473030656,
    "created_at" : "2015-08-11 20:40:55 +0000",
    "user" : {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "protected" : false,
      "id_str" : "1046103560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773840339463438336\/-PvOKg0h_normal.jpg",
      "id" : 1046103560,
      "verified" : false
    }
  },
  "id" : 631230302673735680,
  "created_at" : "2015-08-11 22:26:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 17, 28 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631208144413327360\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UZWsQsJES1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAbzqXAAAEdbS.jpg",
      "id_str" : "631208112997990400",
      "id" : 631208112997990400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAbzqXAAAEdbS.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UZWsQsJES1"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631208144413327360\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UZWsQsJES1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAb0CWEAARu4R.jpg",
      "id_str" : "631208113098592256",
      "id" : 631208113098592256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAb0CWEAARu4R.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UZWsQsJES1"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631208144413327360\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UZWsQsJES1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAb0gWIAAePvy.jpg",
      "id_str" : "631208113224425472",
      "id" : 631208113224425472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAb0gWIAAePvy.jpg",
      "sizes" : [ {
        "h" : 378,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UZWsQsJES1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631230240505917440",
  "text" : "RT @newlandfarm: @PVickerton Now then ... now then ... now then http:\/\/t.co\/UZWsQsJES1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hawcroft Lleyn",
        "screen_name" : "PVickerton",
        "indices" : [ 0, 11 ],
        "id_str" : "1046103560",
        "id" : 1046103560
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631208144413327360\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/UZWsQsJES1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAbzqXAAAEdbS.jpg",
        "id_str" : "631208112997990400",
        "id" : 631208112997990400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAbzqXAAAEdbS.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UZWsQsJES1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631208144413327360\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/UZWsQsJES1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAb0CWEAARu4R.jpg",
        "id_str" : "631208113098592256",
        "id" : 631208113098592256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAb0CWEAARu4R.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UZWsQsJES1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/631208144413327360\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/UZWsQsJES1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKAb0gWIAAePvy.jpg",
        "id_str" : "631208113224425472",
        "id" : 631208113224425472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKAb0gWIAAePvy.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UZWsQsJES1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "631203664473030656",
    "geo" : { },
    "id_str" : "631208144413327360",
    "in_reply_to_user_id" : 1046103560,
    "text" : "@PVickerton Now then ... now then ... now then http:\/\/t.co\/UZWsQsJES1",
    "id" : 631208144413327360,
    "in_reply_to_status_id" : 631203664473030656,
    "created_at" : "2015-08-11 20:58:43 +0000",
    "in_reply_to_screen_name" : "PVickerton",
    "in_reply_to_user_id_str" : "1046103560",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 631230240505917440,
  "created_at" : "2015-08-11 22:26:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CandaceTX",
      "screen_name" : "CandaceTX",
      "indices" : [ 3, 13 ],
      "id_str" : "21631041",
      "id" : 21631041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandraBland",
      "indices" : [ 96, 108 ]
    }, {
      "text" : "WhichEmergency",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631229911030566912",
  "text" : "RT @CandaceTX: 'Submit or you deserve to die ' is NOT law enforcement; it is an occupying army. #SandraBland #WhichEmergency http:\/\/t.co\/Oo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CandaceTX\/status\/630932519030882304\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Oog6RK7bGX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMGFx2XUYAAHssJ.jpg",
        "id_str" : "630932514261983232",
        "id" : 630932514261983232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMGFx2XUYAAHssJ.jpg",
        "sizes" : [ {
          "h" : 358,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1079,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 1044
        } ],
        "display_url" : "pic.twitter.com\/Oog6RK7bGX"
      } ],
      "hashtags" : [ {
        "text" : "SandraBland",
        "indices" : [ 81, 93 ]
      }, {
        "text" : "WhichEmergency",
        "indices" : [ 94, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631214308458823681",
    "text" : "'Submit or you deserve to die ' is NOT law enforcement; it is an occupying army. #SandraBland #WhichEmergency http:\/\/t.co\/Oog6RK7bGX",
    "id" : 631214308458823681,
    "created_at" : "2015-08-11 21:23:13 +0000",
    "user" : {
      "name" : "CandaceTX",
      "screen_name" : "CandaceTX",
      "protected" : false,
      "id_str" : "21631041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800366184919080964\/7zs-c3U4_normal.jpg",
      "id" : 21631041,
      "verified" : false
    }
  },
  "id" : 631229911030566912,
  "created_at" : "2015-08-11 22:25:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/631226723229671424\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/cmWJp7I6k3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKRLdcWsAguzgi.jpg",
      "id_str" : "631226523853434888",
      "id" : 631226523853434888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKRLdcWsAguzgi.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/cmWJp7I6k3"
    } ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631229622634606592",
  "text" : "RT @CatskillCritter: After this evening's thunderstorm, in the #Catskills . . . http:\/\/t.co\/cmWJp7I6k3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/631226723229671424\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/cmWJp7I6k3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKRLdcWsAguzgi.jpg",
        "id_str" : "631226523853434888",
        "id" : 631226523853434888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKRLdcWsAguzgi.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/cmWJp7I6k3"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631226723229671424",
    "text" : "After this evening's thunderstorm, in the #Catskills . . . http:\/\/t.co\/cmWJp7I6k3",
    "id" : 631226723229671424,
    "created_at" : "2015-08-11 22:12:33 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 631229622634606592,
  "created_at" : "2015-08-11 22:24:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Klingler",
      "screen_name" : "jamieklingler",
      "indices" : [ 3, 17 ],
      "id_str" : "15233347",
      "id" : 15233347
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jamieklingler\/status\/630814347976163329\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/RBkCInwuVE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMEaTBtWgAAmqBb.jpg",
      "id_str" : "630814336987070464",
      "id" : 630814336987070464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMEaTBtWgAAmqBb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/RBkCInwuVE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631228935045541888",
  "text" : "RT @jamieklingler: This is the best thing I've seen on FB in a long time. http:\/\/t.co\/RBkCInwuVE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jamieklingler\/status\/630814347976163329\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/RBkCInwuVE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMEaTBtWgAAmqBb.jpg",
        "id_str" : "630814336987070464",
        "id" : 630814336987070464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMEaTBtWgAAmqBb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/RBkCInwuVE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630814347976163329",
    "text" : "This is the best thing I've seen on FB in a long time. http:\/\/t.co\/RBkCInwuVE",
    "id" : 630814347976163329,
    "created_at" : "2015-08-10 18:53:55 +0000",
    "user" : {
      "name" : "Jamie Klingler",
      "screen_name" : "jamieklingler",
      "protected" : false,
      "id_str" : "15233347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796965000661311488\/t_r_4Cvp_normal.jpg",
      "id" : 15233347,
      "verified" : true
    }
  },
  "id" : 631228935045541888,
  "created_at" : "2015-08-11 22:21:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/vqmdTDPSAI",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/08\/11\/fergusons_terrifying_authoritarian_message_if_you_commit_journalism_we_will_destroy_you\/",
      "display_url" : "salon.com\/2015\/08\/11\/fer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631189679040241664",
  "text" : "Ferguson\u2019s terrifying authoritarian message: If you commit journalism, we will destroy you http:\/\/t.co\/vqmdTDPSAI",
  "id" : 631189679040241664,
  "created_at" : "2015-08-11 19:45:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631184440404901888",
  "text" : "RT @forestberkeley: i want to get lost in the forest",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631182987531583488",
    "text" : "i want to get lost in the forest",
    "id" : 631182987531583488,
    "created_at" : "2015-08-11 19:18:45 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 631184440404901888,
  "created_at" : "2015-08-11 19:24:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "indices" : [ 3, 19 ],
      "id_str" : "179121328",
      "id" : 179121328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631184075244634113",
  "text" : "RT @thesilverspiral: You can't have disappointment without appointments - appointments of expectations to people, things, and situations.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631183599811854336",
    "text" : "You can't have disappointment without appointments - appointments of expectations to people, things, and situations.",
    "id" : 631183599811854336,
    "created_at" : "2015-08-11 19:21:11 +0000",
    "user" : {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "protected" : false,
      "id_str" : "179121328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476331163322052609\/9eQZmrqN_normal.jpeg",
      "id" : 179121328,
      "verified" : false
    }
  },
  "id" : 631184075244634113,
  "created_at" : "2015-08-11 19:23:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631135520958119937",
  "geo" : { },
  "id_str" : "631140019965698048",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous now stop..lol",
  "id" : 631140019965698048,
  "in_reply_to_status_id" : 631135520958119937,
  "created_at" : "2015-08-11 16:28:01 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Dr. Drang",
      "screen_name" : "drdrang",
      "indices" : [ 11, 19 ],
      "id_str" : "10697232",
      "id" : 10697232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631118649017901056",
  "geo" : { },
  "id_str" : "631131023171055617",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous @drdrang um.. yeah? lol",
  "id" : 631131023171055617,
  "in_reply_to_status_id" : 631118649017901056,
  "created_at" : "2015-08-11 15:52:16 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    }, {
      "name" : "Johnetta Elzie",
      "screen_name" : "Nettaaaaaaaa",
      "indices" : [ 18, 31 ],
      "id_str" : "1291770157",
      "id" : 1291770157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631112082600103940",
  "text" : "RT @deray: Today, @Nettaaaaaaaa was arrested as she filmed the police. &amp; once I realized she was being arrested, I questioned it. I was the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Johnetta Elzie",
        "screen_name" : "Nettaaaaaaaa",
        "indices" : [ 7, 20 ],
        "id_str" : "1291770157",
        "id" : 1291770157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630893580614107137",
    "text" : "Today, @Nettaaaaaaaa was arrested as she filmed the police. &amp; once I realized she was being arrested, I questioned it. I was then arrested.",
    "id" : 630893580614107137,
    "created_at" : "2015-08-11 00:08:45 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 631112082600103940,
  "created_at" : "2015-08-11 14:37:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631108617668833280",
  "text" : "RT @Buddhaworld: Peace starts by self acceptance. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631053473598058496",
    "text" : "Peace starts by self acceptance. Volko",
    "id" : 631053473598058496,
    "created_at" : "2015-08-11 10:44:07 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 631108617668833280,
  "created_at" : "2015-08-11 14:23:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 20, 24 ],
      "id_str" : "759251",
      "id" : 759251
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 121, 128 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630896652270891008",
  "text" : "RT @oceanshaman: Ty @CNN....  #Blackfish the movie! Tell friends! Watch it again for the first time! Or buy the dvd from @amazon! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 3, 7 ],
        "id_str" : "759251",
        "id" : 759251
      }, {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 104, 111 ],
        "id_str" : "20793816",
        "id" : 20793816
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/DCo4KeTWOA",
        "expanded_url" : "https:\/\/twitter.com\/TheOrcaProject\/status\/630855215055548416",
        "display_url" : "twitter.com\/TheOrcaProject\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630895866056978432",
    "text" : "Ty @CNN....  #Blackfish the movie! Tell friends! Watch it again for the first time! Or buy the dvd from @amazon! https:\/\/t.co\/DCo4KeTWOA",
    "id" : 630895866056978432,
    "created_at" : "2015-08-11 00:17:50 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 630896652270891008,
  "created_at" : "2015-08-11 00:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Captain Clarion",
      "screen_name" : "citizensrock",
      "indices" : [ 3, 16 ],
      "id_str" : "271030180",
      "id" : 271030180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630895121173753856",
  "text" : "RT @citizensrock: \u201CFreedom is never voluntarily given by the oppressor\u2014it must be demanded by the oppressed.\u201D MLK Jr #BlackLivesMatter http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/citizensrock\/status\/630511267451551745\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/OosWt1t8wb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMAGqANVAAA-GHr.jpg",
        "id_str" : "630511266512044032",
        "id" : 630511266512044032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMAGqANVAAA-GHr.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 1038
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OosWt1t8wb"
      } ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630511267451551745",
    "text" : "\u201CFreedom is never voluntarily given by the oppressor\u2014it must be demanded by the oppressed.\u201D MLK Jr #BlackLivesMatter http:\/\/t.co\/OosWt1t8wb",
    "id" : 630511267451551745,
    "created_at" : "2015-08-09 22:49:35 +0000",
    "user" : {
      "name" : "Captain Clarion",
      "screen_name" : "citizensrock",
      "protected" : false,
      "id_str" : "271030180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500767478197153792\/necyH3Wl_normal.png",
      "id" : 271030180,
      "verified" : false
    }
  },
  "id" : 630895121173753856,
  "created_at" : "2015-08-11 00:14:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/AcnIavDryr",
      "expanded_url" : "https:\/\/twitter.com\/theonlybacchus\/status\/630884969804513280",
      "display_url" : "twitter.com\/theonlybacchus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630891990822035456",
  "text" : "RT @Squirrely007: Wow https:\/\/t.co\/AcnIavDryr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/AcnIavDryr",
        "expanded_url" : "https:\/\/twitter.com\/theonlybacchus\/status\/630884969804513280",
        "display_url" : "twitter.com\/theonlybacchus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630888948454281216",
    "text" : "Wow https:\/\/t.co\/AcnIavDryr",
    "id" : 630888948454281216,
    "created_at" : "2015-08-10 23:50:21 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 630891990822035456,
  "created_at" : "2015-08-11 00:02:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Leopold",
      "screen_name" : "JasonLeopold",
      "indices" : [ 3, 16 ],
      "id_str" : "17094311",
      "id" : 17094311
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 19, 25 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630891025398153216",
  "text" : "RT @JasonLeopold: .@deray, a \"professional protestor known to law enforcement\" whose twitter acct monitored by DHS, says doc I obtained htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 1, 7 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JasonLeopold\/status\/630858204147089408\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BxEIajASyl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMFCMZIUwAEbXB5.png",
        "id_str" : "630858203480244225",
        "id" : 630858203480244225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMFCMZIUwAEbXB5.png",
        "sizes" : [ {
          "h" : 470,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 907
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 907
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BxEIajASyl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630858204147089408",
    "text" : ".@deray, a \"professional protestor known to law enforcement\" whose twitter acct monitored by DHS, says doc I obtained http:\/\/t.co\/BxEIajASyl",
    "id" : 630858204147089408,
    "created_at" : "2015-08-10 21:48:11 +0000",
    "user" : {
      "name" : "Jason Leopold",
      "screen_name" : "JasonLeopold",
      "protected" : false,
      "id_str" : "17094311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684412755512696833\/hC9yuMF2_normal.jpg",
      "id" : 17094311,
      "verified" : true
    }
  },
  "id" : 630891025398153216,
  "created_at" : "2015-08-10 23:58:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brianna Wu",
      "screen_name" : "Spacekatgal",
      "indices" : [ 3, 15 ],
      "id_str" : "17264476",
      "id" : 17264476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630887216609366016",
  "text" : "RT @Spacekatgal: White people MUST understand: Police violence against black people happens because society is built around white privilege\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630827636168724481",
    "text" : "White people MUST understand: Police violence against black people happens because society is built around white privilege #BlackLivesMatter",
    "id" : 630827636168724481,
    "created_at" : "2015-08-10 19:46:43 +0000",
    "user" : {
      "name" : "Brianna Wu",
      "screen_name" : "Spacekatgal",
      "protected" : false,
      "id_str" : "17264476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797689661665767424\/BTzxvg-U_normal.jpg",
      "id" : 17264476,
      "verified" : true
    }
  },
  "id" : 630887216609366016,
  "created_at" : "2015-08-10 23:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxime Duprez",
      "screen_name" : "maximaxoo",
      "indices" : [ 3, 13 ],
      "id_str" : "21641427",
      "id" : 21641427
    }, {
      "name" : "Int. Engineering",
      "screen_name" : "IntEngineering",
      "indices" : [ 117, 132 ],
      "id_str" : "564053183",
      "id" : 564053183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Future",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "Tech",
      "indices" : [ 23, 28 ]
    }, {
      "text" : "ostrich",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "bionic",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/HUupG0aKJu",
      "expanded_url" : "http:\/\/interestingengineering.com\/ostrich-inspired-bionic-boots-let-you-run-at-up-to-25-mph\/",
      "display_url" : "interestingengineering.com\/ostrich-inspir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630881315458543616",
  "text" : "RT @maximaxoo: #Future #Tech: #ostrich inspired #bionic boots let you run at up to 25 mph\n\u25BA http:\/\/t.co\/HUupG0aKJu | @IntEngineering http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Int. Engineering",
        "screen_name" : "IntEngineering",
        "indices" : [ 102, 117 ],
        "id_str" : "564053183",
        "id" : 564053183
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/maximaxoo\/status\/630367685105295360\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/o2peaDb8Ed",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL-EEdjWwAAZtcR.jpg",
        "id_str" : "630367685042421760",
        "id" : 630367685042421760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL-EEdjWwAAZtcR.jpg",
        "sizes" : [ {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/o2peaDb8Ed"
      } ],
      "hashtags" : [ {
        "text" : "Future",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Tech",
        "indices" : [ 8, 13 ]
      }, {
        "text" : "ostrich",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "bionic",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/HUupG0aKJu",
        "expanded_url" : "http:\/\/interestingengineering.com\/ostrich-inspired-bionic-boots-let-you-run-at-up-to-25-mph\/",
        "display_url" : "interestingengineering.com\/ostrich-inspir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630367685105295360",
    "text" : "#Future #Tech: #ostrich inspired #bionic boots let you run at up to 25 mph\n\u25BA http:\/\/t.co\/HUupG0aKJu | @IntEngineering http:\/\/t.co\/o2peaDb8Ed",
    "id" : 630367685105295360,
    "created_at" : "2015-08-09 13:19:02 +0000",
    "user" : {
      "name" : "Maxime Duprez",
      "screen_name" : "maximaxoo",
      "protected" : false,
      "id_str" : "21641427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000461209591\/ea6b2d0f0b67ef502ee8496e0ae8c6c7_normal.jpeg",
      "id" : 21641427,
      "verified" : false
    }
  },
  "id" : 630881315458543616,
  "created_at" : "2015-08-10 23:20:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/630859685046919168\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/boMoWAJ3qH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMFDf7cWgAESLuN.jpg",
      "id_str" : "630859638620192769",
      "id" : 630859638620192769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMFDf7cWgAESLuN.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/boMoWAJ3qH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630880974465859584",
  "text" : "RT @1CatShepherd: Marley found a stash of Zwartbles blankets in the car &amp; decided a snooze was needed http:\/\/t.co\/boMoWAJ3qH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/630859685046919168\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/boMoWAJ3qH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMFDf7cWgAESLuN.jpg",
        "id_str" : "630859638620192769",
        "id" : 630859638620192769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMFDf7cWgAESLuN.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/boMoWAJ3qH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630859685046919168",
    "text" : "Marley found a stash of Zwartbles blankets in the car &amp; decided a snooze was needed http:\/\/t.co\/boMoWAJ3qH",
    "id" : 630859685046919168,
    "created_at" : "2015-08-10 21:54:04 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 630880974465859584,
  "created_at" : "2015-08-10 23:18:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Drang",
      "screen_name" : "drdrang",
      "indices" : [ 0, 8 ],
      "id_str" : "10697232",
      "id" : 10697232
    }, {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 9, 19 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "app",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "notes",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630870191455338496",
  "geo" : { },
  "id_str" : "630880533006938112",
  "in_reply_to_user_id" : 10697232,
  "text" : "@drdrang @Matth3ous bleh. no android, wp version. looks like a good #app. #notes",
  "id" : 630880533006938112,
  "in_reply_to_status_id" : 630870191455338496,
  "created_at" : "2015-08-10 23:16:54 +0000",
  "in_reply_to_screen_name" : "drdrang",
  "in_reply_to_user_id_str" : "10697232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleigh Wright",
      "screen_name" : "DairyFarmHer207",
      "indices" : [ 3, 19 ],
      "id_str" : "2879735713",
      "id" : 2879735713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "farmlove",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "dailymoo",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "milktruth",
      "indices" : [ 105, 115 ]
    }, {
      "text" : "OpenTheBarns",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630879837608148993",
  "text" : "RT @DairyFarmHer207: Vivian's hair makes me smile Every. Single. Day. \n\n\uD83D\uDE04\uD83D\uDE04\uD83D\uDE04 #farm365 #farmlove #dailymoo #milktruth #OpenTheBarns http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DairyFarmHer207\/status\/630869307782746112\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/ckQanKiSrw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMFMSObXAAAOkMl.jpg",
        "id_str" : "630869298802786304",
        "id" : 630869298802786304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMFMSObXAAAOkMl.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ckQanKiSrw"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 55, 63 ]
      }, {
        "text" : "farmlove",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "dailymoo",
        "indices" : [ 74, 83 ]
      }, {
        "text" : "milktruth",
        "indices" : [ 84, 94 ]
      }, {
        "text" : "OpenTheBarns",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630869307782746112",
    "text" : "Vivian's hair makes me smile Every. Single. Day. \n\n\uD83D\uDE04\uD83D\uDE04\uD83D\uDE04 #farm365 #farmlove #dailymoo #milktruth #OpenTheBarns http:\/\/t.co\/ckQanKiSrw",
    "id" : 630869307782746112,
    "created_at" : "2015-08-10 22:32:18 +0000",
    "user" : {
      "name" : "Caleigh Wright",
      "screen_name" : "DairyFarmHer207",
      "protected" : false,
      "id_str" : "2879735713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734793055157489664\/dgvjFtZq_normal.jpg",
      "id" : 2879735713,
      "verified" : false
    }
  },
  "id" : 630879837608148993,
  "created_at" : "2015-08-10 23:14:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elve\u2122",
      "screen_name" : "VineCliques",
      "indices" : [ 3, 15 ],
      "id_str" : "1724928566",
      "id" : 1724928566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/CkuAbGVrHA",
      "expanded_url" : "https:\/\/vine.co\/v\/MQZmmTnB2iw",
      "display_url" : "vine.co\/v\/MQZmmTnB2iw"
    } ]
  },
  "geo" : { },
  "id_str" : "630852080668950528",
  "text" : "RT @VineCliques: Can't stop watching this - absolutely brilliant  https:\/\/t.co\/CkuAbGVrHA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/CkuAbGVrHA",
        "expanded_url" : "https:\/\/vine.co\/v\/MQZmmTnB2iw",
        "display_url" : "vine.co\/v\/MQZmmTnB2iw"
      } ]
    },
    "geo" : { },
    "id_str" : "630607231801688064",
    "text" : "Can't stop watching this - absolutely brilliant  https:\/\/t.co\/CkuAbGVrHA",
    "id" : 630607231801688064,
    "created_at" : "2015-08-10 05:10:54 +0000",
    "user" : {
      "name" : "Elve\u2122",
      "screen_name" : "VineCliques",
      "protected" : false,
      "id_str" : "1724928566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574120335827542016\/yqQm_KbW_normal.jpeg",
      "id" : 1724928566,
      "verified" : false
    }
  },
  "id" : 630852080668950528,
  "created_at" : "2015-08-10 21:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auragasmic",
      "screen_name" : "Auragasmic",
      "indices" : [ 3, 14 ],
      "id_str" : "4386066746",
      "id" : 4386066746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630851770860871681",
  "text" : "RT @Auragasmic: Canadians are the nicest people in the world. Do you know how much of an asshole you have to be to incite us to acts of vio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630850661802872833",
    "text" : "Canadians are the nicest people in the world. Do you know how much of an asshole you have to be to incite us to acts of violence?",
    "id" : 630850661802872833,
    "created_at" : "2015-08-10 21:18:13 +0000",
    "user" : {
      "name" : "\u2728 Kill All Nazis \u2728",
      "screen_name" : "RoyalHoeliness",
      "protected" : false,
      "id_str" : "146712559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796463688920289280\/iwrwut84_normal.jpg",
      "id" : 146712559,
      "verified" : false
    }
  },
  "id" : 630851770860871681,
  "created_at" : "2015-08-10 21:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630843867085045760",
  "geo" : { },
  "id_str" : "630846480534892544",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley you've got an odd sense of humour.. i like that. ; )",
  "id" : 630846480534892544,
  "in_reply_to_status_id" : 630843867085045760,
  "created_at" : "2015-08-10 21:01:36 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/630833047999488001\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/B1gKv9cqal",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMErUHIUwAAbrpa.jpg",
      "id_str" : "630833047319920640",
      "id" : 630833047319920640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMErUHIUwAAbrpa.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/B1gKv9cqal"
    } ],
    "hashtags" : [ {
      "text" : "vabirdlibrary",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630833891826356225",
  "text" : "RT @Library4birds: \"Should I come back?\"\n#vabirdlibrary http:\/\/t.co\/B1gKv9cqal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/630833047999488001\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/B1gKv9cqal",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMErUHIUwAAbrpa.jpg",
        "id_str" : "630833047319920640",
        "id" : 630833047319920640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMErUHIUwAAbrpa.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/B1gKv9cqal"
      } ],
      "hashtags" : [ {
        "text" : "vabirdlibrary",
        "indices" : [ 22, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630833047999488001",
    "text" : "\"Should I come back?\"\n#vabirdlibrary http:\/\/t.co\/B1gKv9cqal",
    "id" : 630833047999488001,
    "created_at" : "2015-08-10 20:08:13 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 630833891826356225,
  "created_at" : "2015-08-10 20:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tor Books",
      "screen_name" : "torbooks",
      "indices" : [ 3, 12 ],
      "id_str" : "9340912",
      "id" : 9340912
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 60, 75 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/torbooks\/status\/630802055616008192\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/cQFOfigzky",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMDquWYWcAAK20Q.jpg",
      "id_str" : "630762029834465280",
      "id" : 630762029834465280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMDquWYWcAAK20Q.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 902,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cQFOfigzky"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/hWvKq0zWMC",
      "expanded_url" : "http:\/\/wapo.st\/1PgHvjc",
      "display_url" : "wapo.st\/1PgHvjc"
    } ]
  },
  "geo" : { },
  "id_str" : "630808062530592768",
  "text" : "RT @torbooks: Why you should be reading Cixin Liu, from the @washingtonpost: http:\/\/t.co\/hWvKq0zWMC http:\/\/t.co\/cQFOfigzky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 46, 61 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/torbooks\/status\/630802055616008192\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/cQFOfigzky",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMDquWYWcAAK20Q.jpg",
        "id_str" : "630762029834465280",
        "id" : 630762029834465280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMDquWYWcAAK20Q.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 665
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 665
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/cQFOfigzky"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/hWvKq0zWMC",
        "expanded_url" : "http:\/\/wapo.st\/1PgHvjc",
        "display_url" : "wapo.st\/1PgHvjc"
      } ]
    },
    "geo" : { },
    "id_str" : "630802055616008192",
    "text" : "Why you should be reading Cixin Liu, from the @washingtonpost: http:\/\/t.co\/hWvKq0zWMC http:\/\/t.co\/cQFOfigzky",
    "id" : 630802055616008192,
    "created_at" : "2015-08-10 18:05:04 +0000",
    "user" : {
      "name" : "Tor Books",
      "screen_name" : "torbooks",
      "protected" : false,
      "id_str" : "9340912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748295925563531264\/bpH57W5x_normal.jpg",
      "id" : 9340912,
      "verified" : true
    }
  },
  "id" : 630808062530592768,
  "created_at" : "2015-08-10 18:28:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/cVn5sgRw9N",
      "expanded_url" : "http:\/\/www.myersbriggs.org\/my-mbti-personality-type\/mbti-basics\/",
      "display_url" : "myersbriggs.org\/my-mbti-person\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "630802590066941952",
  "geo" : { },
  "id_str" : "630804079451746305",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre http:\/\/t.co\/cVn5sgRw9N",
  "id" : 630804079451746305,
  "in_reply_to_status_id" : 630802590066941952,
  "created_at" : "2015-08-10 18:13:06 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630802590066941952",
  "geo" : { },
  "id_str" : "630803784088834048",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre Myers-Briggs personality type - Introverted Intuitive Feeling Perceiving",
  "id" : 630803784088834048,
  "in_reply_to_status_id" : 630802590066941952,
  "created_at" : "2015-08-10 18:11:56 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 44, 49 ]
    }, {
      "text" : "Introvert",
      "indices" : [ 50, 60 ]
    }, {
      "text" : "ilikemylittleworld",
      "indices" : [ 61, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630801577872330752",
  "geo" : { },
  "id_str" : "630802331534295040",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre check, check and check. lol. #INFP #Introvert #ilikemylittleworld",
  "id" : 630802331534295040,
  "in_reply_to_status_id" : 630801577872330752,
  "created_at" : "2015-08-10 18:06:10 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 8, 25 ]
    }, {
      "text" : "AllLivesMatter",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630800205797986305",
  "text" : "its not #BlackLivesMatter vs. #AllLivesMatter .. its ppl unshadowing injustice against their own. they have right to speak out.",
  "id" : 630800205797986305,
  "created_at" : "2015-08-10 17:57:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/630796751121817601\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1BX3fsplvC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMEKTY9WcAAB_nF.jpg",
      "id_str" : "630796751042146304",
      "id" : 630796751042146304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMEKTY9WcAAB_nF.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1BX3fsplvC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630799473480990720",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E A Novel where I'm not the Lead Act must be Boring ... \uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E http:\/\/t.co\/1BX3fsplvC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/630796751121817601\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/1BX3fsplvC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMEKTY9WcAAB_nF.jpg",
        "id_str" : "630796751042146304",
        "id" : 630796751042146304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMEKTY9WcAAB_nF.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1BX3fsplvC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630796751121817601",
    "text" : "\uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E A Novel where I'm not the Lead Act must be Boring ... \uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E http:\/\/t.co\/1BX3fsplvC",
    "id" : 630796751121817601,
    "created_at" : "2015-08-10 17:43:59 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 630799473480990720,
  "created_at" : "2015-08-10 17:54:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630796916809445376",
  "text" : "there are ppl who simply dont believe there is any racial discrimination going on. they think its set up to look like it. #BlackLivesMatter",
  "id" : 630796916809445376,
  "created_at" : "2015-08-10 17:44:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBC News",
      "screen_name" : "CBCNews",
      "indices" : [ 3, 11 ],
      "id_str" : "6433472",
      "id" : 6433472
    }, {
      "name" : "CBC Newfoundland",
      "screen_name" : "CBCNL",
      "indices" : [ 81, 87 ],
      "id_str" : "18999907",
      "id" : 18999907
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CBCNews\/status\/630124234346467328\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/LTqK9XEsgT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL6lDojWoAAuL3y.jpg",
      "id_str" : "630122479722340352",
      "id" : 630122479722340352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL6lDojWoAAuL3y.jpg",
      "sizes" : [ {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/LTqK9XEsgT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630790583108435968",
  "text" : "RT @CBCNews: Facebook user Newfoundland Glassman shared this amoosing photo with @CBCNL. Only in Canada, eh? http:\/\/t.co\/LTqK9XEsgT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBC Newfoundland",
        "screen_name" : "CBCNL",
        "indices" : [ 68, 74 ],
        "id_str" : "18999907",
        "id" : 18999907
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CBCNews\/status\/630124234346467328\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/LTqK9XEsgT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL6lDojWoAAuL3y.jpg",
        "id_str" : "630122479722340352",
        "id" : 630122479722340352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL6lDojWoAAuL3y.jpg",
        "sizes" : [ {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/LTqK9XEsgT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630124234346467328",
    "text" : "Facebook user Newfoundland Glassman shared this amoosing photo with @CBCNL. Only in Canada, eh? http:\/\/t.co\/LTqK9XEsgT",
    "id" : 630124234346467328,
    "created_at" : "2015-08-08 21:11:39 +0000",
    "user" : {
      "name" : "CBC News",
      "screen_name" : "CBCNews",
      "protected" : false,
      "id_str" : "6433472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466664981673410560\/886Az0vu_normal.jpeg",
      "id" : 6433472,
      "verified" : true
    }
  },
  "id" : 630790583108435968,
  "created_at" : "2015-08-10 17:19:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/C12i9bR3Cx",
      "expanded_url" : "https:\/\/twitter.com\/sfreynolds\/status\/630737235592245248",
      "display_url" : "twitter.com\/sfreynolds\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630790173035524096",
  "text" : "which is fine.. unless teen wants to start fire in room which will affect outside the room. https:\/\/t.co\/C12i9bR3Cx",
  "id" : 630790173035524096,
  "created_at" : "2015-08-10 17:17:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CalmYourselfIn4Words",
      "indices" : [ 36, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630788035735592960",
  "text" : "RT @bend_time: this too shall pass. #CalmYourselfIn4Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CalmYourselfIn4Words",
        "indices" : [ 21, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630767852400742400",
    "text" : "this too shall pass. #CalmYourselfIn4Words",
    "id" : 630767852400742400,
    "created_at" : "2015-08-10 15:49:09 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 630788035735592960,
  "created_at" : "2015-08-10 17:09:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630768115438194688",
  "geo" : { },
  "id_str" : "630787567911350272",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley that's still going on?? omg'ness.. just for your simple comment?? oy!! ((hugs)) ps. you held your own quite well : )",
  "id" : 630787567911350272,
  "in_reply_to_status_id" : 630768115438194688,
  "created_at" : "2015-08-10 17:07:30 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oh TWIST!",
      "screen_name" : "H2OhTwist",
      "indices" : [ 3, 13 ],
      "id_str" : "2381465209",
      "id" : 2381465209
    }, {
      "name" : "Christin Miserandino",
      "screen_name" : "bydls",
      "indices" : [ 57, 63 ],
      "id_str" : "9196392",
      "id" : 9196392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EDS",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "HMS",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "POTS",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Em2BwQqJuz",
      "expanded_url" : "http:\/\/buff.ly\/1SFvofD",
      "display_url" : "buff.ly\/1SFvofD"
    } ]
  },
  "geo" : { },
  "id_str" : "630786667461410816",
  "text" : "RT @H2OhTwist: The Spoon Theory of energy management via @bydls for those with chronic illness: http:\/\/t.co\/Em2BwQqJuz #EDS #HMS #POTS #fib\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christin Miserandino",
        "screen_name" : "bydls",
        "indices" : [ 42, 48 ],
        "id_str" : "9196392",
        "id" : 9196392
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EDS",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "HMS",
        "indices" : [ 109, 113 ]
      }, {
        "text" : "POTS",
        "indices" : [ 114, 119 ]
      }, {
        "text" : "fibro",
        "indices" : [ 120, 126 ]
      }, {
        "text" : "spoonies",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Em2BwQqJuz",
        "expanded_url" : "http:\/\/buff.ly\/1SFvofD",
        "display_url" : "buff.ly\/1SFvofD"
      } ]
    },
    "geo" : { },
    "id_str" : "629132542470438912",
    "text" : "The Spoon Theory of energy management via @bydls for those with chronic illness: http:\/\/t.co\/Em2BwQqJuz #EDS #HMS #POTS #fibro #spoonies",
    "id" : 629132542470438912,
    "created_at" : "2015-08-06 03:31:01 +0000",
    "user" : {
      "name" : "Oh TWIST!",
      "screen_name" : "H2OhTwist",
      "protected" : false,
      "id_str" : "2381465209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443276394319974400\/eDIhhc0l_normal.jpeg",
      "id" : 2381465209,
      "verified" : false
    }
  },
  "id" : 630786667461410816,
  "created_at" : "2015-08-10 17:03:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SDkRPglXn0",
      "expanded_url" : "http:\/\/huff.to\/1IZtWUs",
      "display_url" : "huff.to\/1IZtWUs"
    } ]
  },
  "geo" : { },
  "id_str" : "630785591937003520",
  "text" : "economics professor explains.. interesting. Is Bernie Sanders 'Socialist?' Are'\"Socialist' Ideas Unpopular? http:\/\/t.co\/SDkRPglXn0",
  "id" : 630785591937003520,
  "created_at" : "2015-08-10 16:59:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rambling Ratz",
      "screen_name" : "RamblingRatz",
      "indices" : [ 3, 16 ],
      "id_str" : "1665965982",
      "id" : 1665965982
    }, {
      "name" : "RSPB",
      "screen_name" : "Natures_Voice",
      "indices" : [ 34, 48 ],
      "id_str" : "19255050",
      "id" : 19255050
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RamblingRatz\/status\/629775589428330496\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/DPrYAn2u6C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1pZHgW8AAfBFu.jpg",
      "id_str" : "629775403134152704",
      "id" : 629775403134152704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1pZHgW8AAfBFu.jpg",
      "sizes" : [ {
        "h" : 524,
        "resize" : "fit",
        "w" : 699
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 699
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DPrYAn2u6C"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/RamblingRatz\/status\/629775589428330496\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/DPrYAn2u6C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1pcVcXAAAYjVM.jpg",
      "id_str" : "629775458415083520",
      "id" : 629775458415083520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1pcVcXAAAYjVM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 668
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 668
      } ],
      "display_url" : "pic.twitter.com\/DPrYAn2u6C"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/RamblingRatz\/status\/629775589428330496\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/DPrYAn2u6C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1pgfaWEAA_eap.jpg",
      "id_str" : "629775529810464768",
      "id" : 629775529810464768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1pgfaWEAA_eap.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com\/DPrYAn2u6C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630569758635724800",
  "text" : "RT @RamblingRatz: Baby blackbird? @Natures_Voice http:\/\/t.co\/DPrYAn2u6C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RSPB",
        "screen_name" : "Natures_Voice",
        "indices" : [ 16, 30 ],
        "id_str" : "19255050",
        "id" : 19255050
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RamblingRatz\/status\/629775589428330496\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/DPrYAn2u6C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1pZHgW8AAfBFu.jpg",
        "id_str" : "629775403134152704",
        "id" : 629775403134152704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1pZHgW8AAfBFu.jpg",
        "sizes" : [ {
          "h" : 524,
          "resize" : "fit",
          "w" : 699
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 699
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DPrYAn2u6C"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/RamblingRatz\/status\/629775589428330496\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/DPrYAn2u6C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1pcVcXAAAYjVM.jpg",
        "id_str" : "629775458415083520",
        "id" : 629775458415083520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1pcVcXAAAYjVM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 668
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 668
        } ],
        "display_url" : "pic.twitter.com\/DPrYAn2u6C"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/RamblingRatz\/status\/629775589428330496\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/DPrYAn2u6C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1pgfaWEAA_eap.jpg",
        "id_str" : "629775529810464768",
        "id" : 629775529810464768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1pgfaWEAA_eap.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/DPrYAn2u6C"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629775589428330496",
    "text" : "Baby blackbird? @Natures_Voice http:\/\/t.co\/DPrYAn2u6C",
    "id" : 629775589428330496,
    "created_at" : "2015-08-07 22:06:15 +0000",
    "user" : {
      "name" : "Rambling Ratz",
      "screen_name" : "RamblingRatz",
      "protected" : false,
      "id_str" : "1665965982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000402850800\/2d6abb5241ef1e76c24a8844d36ef591_normal.jpeg",
      "id" : 1665965982,
      "verified" : false
    }
  },
  "id" : 630569758635724800,
  "created_at" : "2015-08-10 02:42:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "indices" : [ 3, 12 ],
      "id_str" : "47791514",
      "id" : 47791514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/7azXzRpVaK",
      "expanded_url" : "https:\/\/www.yahoo.com\/parenting\/my-sons-lyme-disease-was-finally-diagnosed-thanks-126015521738.html?soc_src=unv-sh&soc_trk=tw",
      "display_url" : "yahoo.com\/parenting\/my-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630540079648391168",
  "text" : "RT @Lymenews: Child's Lyme Disease finally diagnosed because of mother's gut instinct. https:\/\/t.co\/7azXzRpVaK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/7azXzRpVaK",
        "expanded_url" : "https:\/\/www.yahoo.com\/parenting\/my-sons-lyme-disease-was-finally-diagnosed-thanks-126015521738.html?soc_src=unv-sh&soc_trk=tw",
        "display_url" : "yahoo.com\/parenting\/my-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629645507736965121",
    "text" : "Child's Lyme Disease finally diagnosed because of mother's gut instinct. https:\/\/t.co\/7azXzRpVaK",
    "id" : 629645507736965121,
    "created_at" : "2015-08-07 13:29:21 +0000",
    "user" : {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "protected" : false,
      "id_str" : "47791514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585121378396811264\/cBO4OfUQ_normal.jpg",
      "id" : 47791514,
      "verified" : false
    }
  },
  "id" : 630540079648391168,
  "created_at" : "2015-08-10 00:44:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630478016141991936",
  "text" : "i have diff portals for each hospital and doc but at least I can access DD recs.. view, print, fax.",
  "id" : 630478016141991936,
  "created_at" : "2015-08-09 20:37:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630477500418760704",
  "text" : "very interesting. my area of ny, we have patient portals to access records. by my SIL, portal only for drs. she'd have to pay to get recs.",
  "id" : 630477500418760704,
  "created_at" : "2015-08-09 20:35:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Smith",
      "screen_name" : "TheRealBrianSmi",
      "indices" : [ 3, 19 ],
      "id_str" : "2563769533",
      "id" : 2563769533
    }, {
      "name" : "HolidaysActive",
      "screen_name" : "HolidaysActive1",
      "indices" : [ 119, 135 ],
      "id_str" : "3044585927",
      "id" : 3044585927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630453885174308864",
  "text" : "RT @TheRealBrianSmi: Preening classes. With 6 cygnets it's quite a responsibility. Look good, feel good. Coombe Park.  @HolidaysActive1 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HolidaysActive",
        "screen_name" : "HolidaysActive1",
        "indices" : [ 98, 114 ],
        "id_str" : "3044585927",
        "id" : 3044585927
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheRealBrianSmi\/status\/630440104771854337\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/nOXiW9H4o6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL_F5jbWEAAaV27.jpg",
        "id_str" : "630440065408307200",
        "id" : 630440065408307200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL_F5jbWEAAaV27.jpg",
        "sizes" : [ {
          "h" : 616,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 616,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/nOXiW9H4o6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630440104771854337",
    "text" : "Preening classes. With 6 cygnets it's quite a responsibility. Look good, feel good. Coombe Park.  @HolidaysActive1 http:\/\/t.co\/nOXiW9H4o6",
    "id" : 630440104771854337,
    "created_at" : "2015-08-09 18:06:48 +0000",
    "user" : {
      "name" : "Brian Smith",
      "screen_name" : "TheRealBrianSmi",
      "protected" : false,
      "id_str" : "2563769533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482088522724032512\/j9LYxLrI_normal.jpeg",
      "id" : 2563769533,
      "verified" : false
    }
  },
  "id" : 630453885174308864,
  "created_at" : "2015-08-09 19:01:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/LNoWGf7xuj",
      "expanded_url" : "http:\/\/qvotr.com\/quote\/3711",
      "display_url" : "qvotr.com\/quote\/3711"
    } ]
  },
  "geo" : { },
  "id_str" : "630419899681255424",
  "text" : "\"\u201CRich kids make a lot of bad choices,\u201D Professor Reardon notes. \u201CThey just don\u2019t...\" http:\/\/t.co\/LNoWGf7xuj",
  "id" : 630419899681255424,
  "created_at" : "2015-08-09 16:46:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/jxEy6nOVvF",
      "expanded_url" : "http:\/\/qvotr.com\/quote\/3710",
      "display_url" : "qvotr.com\/quote\/3710"
    } ]
  },
  "geo" : { },
  "id_str" : "630419849785819137",
  "text" : "\"Some think success is all about \u201Cchoices\u201D and \u201Cpersonal responsibility.\u201D Yes, th...\" http:\/\/t.co\/jxEy6nOVvF",
  "id" : 630419849785819137,
  "created_at" : "2015-08-09 16:46:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Niequist",
      "screen_name" : "aaronieq",
      "indices" : [ 3, 12 ],
      "id_str" : "63865025",
      "id" : 63865025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/pgSCA60I6L",
      "expanded_url" : "https:\/\/twitter.com\/NickKristof\/status\/630392290901491713",
      "display_url" : "twitter.com\/NickKristof\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630419014783758340",
  "text" : "RT @aaronieq: Wow. This is really important to wrestle with... https:\/\/t.co\/pgSCA60I6L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/pgSCA60I6L",
        "expanded_url" : "https:\/\/twitter.com\/NickKristof\/status\/630392290901491713",
        "display_url" : "twitter.com\/NickKristof\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630411242558111744",
    "text" : "Wow. This is really important to wrestle with... https:\/\/t.co\/pgSCA60I6L",
    "id" : 630411242558111744,
    "created_at" : "2015-08-09 16:12:07 +0000",
    "user" : {
      "name" : "Aaron Niequist",
      "screen_name" : "aaronieq",
      "protected" : false,
      "id_str" : "63865025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708415417648173056\/xrmR21Ov_normal.jpg",
      "id" : 63865025,
      "verified" : false
    }
  },
  "id" : 630419014783758340,
  "created_at" : "2015-08-09 16:43:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qkCEpnHxuH",
      "expanded_url" : "https:\/\/www.facebook.com\/shaunking\/posts\/903673823004870",
      "display_url" : "facebook.com\/shaunking\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630412195520749570",
  "text" : "and I still dont get that he was left there so long! &gt; \"Mike Brown's...body on the scorching concrete for hours\" https:\/\/t.co\/qkCEpnHxuH",
  "id" : 630412195520749570,
  "created_at" : "2015-08-09 16:15:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Callihan",
      "screen_name" : "Kris10Callihan",
      "indices" : [ 3, 18 ],
      "id_str" : "255305729",
      "id" : 255305729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630407731212615680",
  "text" : "RT @Kris10Callihan: Books can change the world. That's why people burn them, fight over them, fight for them. Never underestimate the power\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630398671960580096",
    "text" : "Books can change the world. That's why people burn them, fight over them, fight for them. Never underestimate the power of a book.",
    "id" : 630398671960580096,
    "created_at" : "2015-08-09 15:22:10 +0000",
    "user" : {
      "name" : "Kristen Callihan",
      "screen_name" : "Kris10Callihan",
      "protected" : false,
      "id_str" : "255305729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784397083067449344\/UReu646e_normal.jpg",
      "id" : 255305729,
      "verified" : false
    }
  },
  "id" : 630407731212615680,
  "created_at" : "2015-08-09 15:58:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yvetteobeirne",
      "screen_name" : "yvetteobeirne",
      "indices" : [ 3, 17 ],
      "id_str" : "456966167",
      "id" : 456966167
    }, {
      "name" : "Birmingham Donkeys",
      "screen_name" : "BhamDonkeys",
      "indices" : [ 53, 65 ],
      "id_str" : "947681610",
      "id" : 947681610
    }, {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 67, 83 ],
      "id_str" : "95607516",
      "id" : 95607516
    }, {
      "name" : "Adopt a Donkey",
      "screen_name" : "AdoptADonkey",
      "indices" : [ 84, 97 ],
      "id_str" : "1527563096",
      "id" : 1527563096
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/yvetteobeirne\/status\/630359652409208833\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Jbb6soPZsB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL98wyoW8AADwpr.jpg",
      "id_str" : "630359650521772032",
      "id" : 630359650521772032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL98wyoW8AADwpr.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 3331,
        "resize" : "fit",
        "w" : 4896
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Jbb6soPZsB"
    } ],
    "hashtags" : [ {
      "text" : "lovedonkeys",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630407297265704961",
  "text" : "RT @yvetteobeirne: The boys sharing a banana.... :-) @BhamDonkeys  @DonkeySanctuary @AdoptADonkey #lovedonkeys http:\/\/t.co\/Jbb6soPZsB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Birmingham Donkeys",
        "screen_name" : "BhamDonkeys",
        "indices" : [ 34, 46 ],
        "id_str" : "947681610",
        "id" : 947681610
      }, {
        "name" : "The Donkey Sanctuary",
        "screen_name" : "DonkeySanctuary",
        "indices" : [ 48, 64 ],
        "id_str" : "95607516",
        "id" : 95607516
      }, {
        "name" : "Adopt a Donkey",
        "screen_name" : "AdoptADonkey",
        "indices" : [ 65, 78 ],
        "id_str" : "1527563096",
        "id" : 1527563096
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/yvetteobeirne\/status\/630359652409208833\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Jbb6soPZsB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL98wyoW8AADwpr.jpg",
        "id_str" : "630359650521772032",
        "id" : 630359650521772032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL98wyoW8AADwpr.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 3331,
          "resize" : "fit",
          "w" : 4896
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 697,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Jbb6soPZsB"
      } ],
      "hashtags" : [ {
        "text" : "lovedonkeys",
        "indices" : [ 79, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630359652409208833",
    "text" : "The boys sharing a banana.... :-) @BhamDonkeys  @DonkeySanctuary @AdoptADonkey #lovedonkeys http:\/\/t.co\/Jbb6soPZsB",
    "id" : 630359652409208833,
    "created_at" : "2015-08-09 12:47:07 +0000",
    "user" : {
      "name" : "yvetteobeirne",
      "screen_name" : "yvetteobeirne",
      "protected" : false,
      "id_str" : "456966167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654020129609641984\/naHuVFSk_normal.jpg",
      "id" : 456966167,
      "verified" : false
    }
  },
  "id" : 630407297265704961,
  "created_at" : "2015-08-09 15:56:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 9, 20 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630401426175430657",
  "text" : "and like @dhammagirl often says.. \"Hurt people hurt people.\" and I add to that.. until they recognize their own hurt.",
  "id" : 630401426175430657,
  "created_at" : "2015-08-09 15:33:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630399238082420736",
  "geo" : { },
  "id_str" : "630400831284748288",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time and im totally opposite.. anything goes. hate rules. EVERYTHING is (shades of) grey.",
  "id" : 630400831284748288,
  "in_reply_to_status_id" : 630399238082420736,
  "created_at" : "2015-08-09 15:30:45 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630398439419871233",
  "geo" : { },
  "id_str" : "630400387149918209",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time my fam was def dysfunctional. now as adult, learning one sibling took brunt of anger &gt;&gt; trauma.",
  "id" : 630400387149918209,
  "in_reply_to_status_id" : 630398439419871233,
  "created_at" : "2015-08-09 15:28:59 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630395580683026432",
  "text" : "when I read about these kids growing up in fundy fams, I imagine they must feel that awful tension but thats all they know.",
  "id" : 630395580683026432,
  "created_at" : "2015-08-09 15:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saadia Muzaffar",
      "screen_name" : "ThisTechGirl",
      "indices" : [ 3, 16 ],
      "id_str" : "31320681",
      "id" : 31320681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630392595844333568",
  "text" : "RT @ThisTechGirl: Critical.\n\nH\/t @CarolineG82 http:\/\/t.co\/uk15N7FDW6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThisTechGirl\/status\/627191347473072128\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/uk15N7FDW6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLQ7M_PWoAAV8Yf.jpg",
        "id_str" : "627191342431641600",
        "id" : 627191342431641600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLQ7M_PWoAAV8Yf.jpg",
        "sizes" : [ {
          "h" : 781,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 781,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uk15N7FDW6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627191347473072128",
    "text" : "Critical.\n\nH\/t @CarolineG82 http:\/\/t.co\/uk15N7FDW6",
    "id" : 627191347473072128,
    "created_at" : "2015-07-31 18:57:24 +0000",
    "user" : {
      "name" : "Saadia Muzaffar",
      "screen_name" : "ThisTechGirl",
      "protected" : false,
      "id_str" : "31320681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799700101832802304\/4lbxcqL9_normal.jpg",
      "id" : 31320681,
      "verified" : false
    }
  },
  "id" : 630392595844333568,
  "created_at" : "2015-08-09 14:58:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fundamentalism",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630391967764094976",
  "text" : "i know ppl who align with ken ham, kirk cameron, focus on family, mike huckabee, etc. I try to understand why. #fundamentalism",
  "id" : 630391967764094976,
  "created_at" : "2015-08-09 14:55:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630391114688790528",
  "text" : "to be clear, i wasnt abused. but I remember the tension.",
  "id" : 630391114688790528,
  "created_at" : "2015-08-09 14:52:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630390586089017344",
  "text" : "why am I obsessed with fundy families? I think partly cuz my Dad could be controlling and I hated that feeling.",
  "id" : 630390586089017344,
  "created_at" : "2015-08-09 14:50:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeschoolers Anon",
      "screen_name" : "HomeschoolAnon",
      "indices" : [ 70, 85 ],
      "id_str" : "943155781",
      "id" : 943155781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abuse",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/1hZmKwFWJB",
      "expanded_url" : "http:\/\/wp.me\/p2SYMn-1LC",
      "display_url" : "wp.me\/p2SYMn-1LC"
    } ]
  },
  "geo" : { },
  "id_str" : "630387361076092928",
  "text" : "Melting Memory Masks: Cynthia Jeub's Story http:\/\/t.co\/1hZmKwFWJB via @HomeschoolAnon #abuse",
  "id" : 630387361076092928,
  "created_at" : "2015-08-09 14:37:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oshum",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630383675142750208",
  "text" : "RT @Oshum: Sometimes\nWhat we believe is our weakness\n                      IS \nOur biggest strength  #oshum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oshum",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630381522038751232",
    "text" : "Sometimes\nWhat we believe is our weakness\n                      IS \nOur biggest strength  #oshum",
    "id" : 630381522038751232,
    "created_at" : "2015-08-09 14:14:01 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 630383675142750208,
  "created_at" : "2015-08-09 14:22:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Scientific",
      "screen_name" : "ASA3org",
      "indices" : [ 3, 11 ],
      "id_str" : "498983018",
      "id" : 498983018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/0W9a1jWIAv",
      "expanded_url" : "http:\/\/fb.me\/1YSGIYPpZ",
      "display_url" : "fb.me\/1YSGIYPpZ"
    } ]
  },
  "geo" : { },
  "id_str" : "630382734578462721",
  "text" : "RT @ASA3org: KEN HAM\u2019S COLOSSAL FAILURE: SAMANTHA FIELD\u2019S STORY http:\/\/t.co\/0W9a1jWIAv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/0W9a1jWIAv",
        "expanded_url" : "http:\/\/fb.me\/1YSGIYPpZ",
        "display_url" : "fb.me\/1YSGIYPpZ"
      } ]
    },
    "geo" : { },
    "id_str" : "629768860569333760",
    "text" : "KEN HAM\u2019S COLOSSAL FAILURE: SAMANTHA FIELD\u2019S STORY http:\/\/t.co\/0W9a1jWIAv",
    "id" : 629768860569333760,
    "created_at" : "2015-08-07 21:39:31 +0000",
    "user" : {
      "name" : "American Scientific",
      "screen_name" : "ASA3org",
      "protected" : false,
      "id_str" : "498983018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734752707815329792\/nGFtqCNV_normal.jpg",
      "id" : 498983018,
      "verified" : false
    }
  },
  "id" : 630382734578462721,
  "created_at" : "2015-08-09 14:18:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630202961084456960",
  "text" : "RT @CharlesBivona: I will NOT go to my Dr. so he can tell me I feel like complere shit because of stress. I will just feel like shit and ho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626958632027090944",
    "text" : "I will NOT go to my Dr. so he can tell me I feel like complere shit because of stress. I will just feel like shit and hope it's not cancer.",
    "id" : 626958632027090944,
    "created_at" : "2015-07-31 03:32:40 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 630202961084456960,
  "created_at" : "2015-08-09 02:24:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "indices" : [ 3, 14 ],
      "id_str" : "2938475619",
      "id" : 2938475619
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/630146671054356480\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/BaU0H8p3Pn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL665ycWwAAT4am.jpg",
      "id_str" : "630146499834462208",
      "id" : 630146499834462208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL665ycWwAAT4am.jpg",
      "sizes" : [ {
        "h" : 378,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 920
      } ],
      "display_url" : "pic.twitter.com\/BaU0H8p3Pn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/630146671054356480\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/BaU0H8p3Pn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL665y2WwAQZPf3.jpg",
      "id_str" : "630146499943514116",
      "id" : 630146499943514116,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL665y2WwAQZPf3.jpg",
      "sizes" : [ {
        "h" : 1023,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BaU0H8p3Pn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/630146671054356480\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/BaU0H8p3Pn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL665zlWcAAFRTT.jpg",
      "id_str" : "630146500140625920",
      "id" : 630146500140625920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL665zlWcAAFRTT.jpg",
      "sizes" : [ {
        "h" : 367,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 948
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 948
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BaU0H8p3Pn"
    } ],
    "hashtags" : [ {
      "text" : "teamStripe",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630186627164450818",
  "text" : "RT @TeamStripe: Marks, Set, Go #teamStripe http:\/\/t.co\/BaU0H8p3Pn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/630146671054356480\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/BaU0H8p3Pn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL665ycWwAAT4am.jpg",
        "id_str" : "630146499834462208",
        "id" : 630146499834462208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL665ycWwAAT4am.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 920
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 920
        } ],
        "display_url" : "pic.twitter.com\/BaU0H8p3Pn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/630146671054356480\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/BaU0H8p3Pn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL665y2WwAQZPf3.jpg",
        "id_str" : "630146499943514116",
        "id" : 630146499943514116,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL665y2WwAQZPf3.jpg",
        "sizes" : [ {
          "h" : 1023,
          "resize" : "fit",
          "w" : 909
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 909
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BaU0H8p3Pn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/630146671054356480\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/BaU0H8p3Pn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL665zlWcAAFRTT.jpg",
        "id_str" : "630146500140625920",
        "id" : 630146500140625920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL665zlWcAAFRTT.jpg",
        "sizes" : [ {
          "h" : 367,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BaU0H8p3Pn"
      } ],
      "hashtags" : [ {
        "text" : "teamStripe",
        "indices" : [ 15, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630146671054356480",
    "text" : "Marks, Set, Go #teamStripe http:\/\/t.co\/BaU0H8p3Pn",
    "id" : 630146671054356480,
    "created_at" : "2015-08-08 22:40:48 +0000",
    "user" : {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "protected" : false,
      "id_str" : "2938475619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620189924915048448\/JFbRz-QX_normal.jpg",
      "id" : 2938475619,
      "verified" : false
    }
  },
  "id" : 630186627164450818,
  "created_at" : "2015-08-09 01:19:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Dotcom",
      "screen_name" : "KimDotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "611986351",
      "id" : 611986351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Insane",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 110, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630180278032564224",
  "text" : "RT @KimDotcom: A black man had a stroke in his car and could not move. Watch what US cops did to him. #Insane #BlackLivesMatter https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Insane",
        "indices" : [ 87, 94 ]
      }, {
        "text" : "BlackLivesMatter",
        "indices" : [ 95, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/hzH4cqi8oQ",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/3fbdc638-6f8d-4f09-aecb-4b82f95aa0a1",
        "display_url" : "amp.twimg.com\/v\/3fbdc638-6f8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630063824142401536",
    "text" : "A black man had a stroke in his car and could not move. Watch what US cops did to him. #Insane #BlackLivesMatter https:\/\/t.co\/hzH4cqi8oQ",
    "id" : 630063824142401536,
    "created_at" : "2015-08-08 17:11:36 +0000",
    "user" : {
      "name" : "Kim Dotcom",
      "screen_name" : "KimDotcom",
      "protected" : false,
      "id_str" : "611986351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2320423543\/9qheijpvtu9g5dteqvvw_normal.jpeg",
      "id" : 611986351,
      "verified" : true
    }
  },
  "id" : 630180278032564224,
  "created_at" : "2015-08-09 00:54:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630166318424195072",
  "text" : "@ThePlushGourmet sending good thoughts your way...",
  "id" : 630166318424195072,
  "created_at" : "2015-08-08 23:58:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/9jwJECjNQZ",
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/630121781131546624",
      "display_url" : "twitter.com\/ErinEFarley\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630149770774999040",
  "text" : "ohh.. so pretty! https:\/\/t.co\/9jwJECjNQZ",
  "id" : 630149770774999040,
  "created_at" : "2015-08-08 22:53:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630136252461903872",
  "geo" : { },
  "id_str" : "630149187993210880",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe oh dear.. sorry you got all that tension going on.",
  "id" : 630149187993210880,
  "in_reply_to_status_id" : 630136252461903872,
  "created_at" : "2015-08-08 22:50:48 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/HmTcAKvPXc",
      "expanded_url" : "http:\/\/religiondispatches.org\/how-a-fringe-theocratic-movement-helped-shape-the-religious-right-as-we-know-it\/",
      "display_url" : "religiondispatches.org\/how-a-fringe-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630098646722342912",
  "text" : "interesting &gt;&gt; How a Fringe Theocratic Movement Helped Shape the Religious Right As We Know It http:\/\/t.co\/HmTcAKvPXc",
  "id" : 630098646722342912,
  "created_at" : "2015-08-08 19:29:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna West",
      "screen_name" : "westhanna661",
      "indices" : [ 3, 16 ],
      "id_str" : "3181476694",
      "id" : 3181476694
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/westhanna661\/status\/630050014061064192\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/0VLOyBPpi3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL5jJgIWEAADMbn.jpg",
      "id_str" : "630050012773355520",
      "id" : 630050012773355520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL5jJgIWEAADMbn.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0VLOyBPpi3"
    } ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630085373864058880",
  "text" : "RT @westhanna661: #SinglePayer http:\/\/t.co\/0VLOyBPpi3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/westhanna661\/status\/630050014061064192\/photo\/1",
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/0VLOyBPpi3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL5jJgIWEAADMbn.jpg",
        "id_str" : "630050012773355520",
        "id" : 630050012773355520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL5jJgIWEAADMbn.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0VLOyBPpi3"
      } ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630050014061064192",
    "text" : "#SinglePayer http:\/\/t.co\/0VLOyBPpi3",
    "id" : 630050014061064192,
    "created_at" : "2015-08-08 16:16:43 +0000",
    "user" : {
      "name" : "Hanna West",
      "screen_name" : "westhanna661",
      "protected" : false,
      "id_str" : "3181476694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797508827729903616\/53rgMvq7_normal.jpg",
      "id" : 3181476694,
      "verified" : false
    }
  },
  "id" : 630085373864058880,
  "created_at" : "2015-08-08 18:37:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/fCXjJFSawI",
      "expanded_url" : "https:\/\/twitter.com\/mydaughtersarmy\/status\/630063198532710400",
      "display_url" : "twitter.com\/mydaughtersarm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630080821714649088",
  "text" : "song pops in head \"follow the yellow brick road\" lol https:\/\/t.co\/fCXjJFSawI",
  "id" : 630080821714649088,
  "created_at" : "2015-08-08 18:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 15, 25 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630065152944177152",
  "geo" : { },
  "id_str" : "630080541048590337",
  "in_reply_to_user_id" : 384316868,
  "text" : "@BrutalAtheist @bend_time I would add abortion as well.",
  "id" : 630080541048590337,
  "in_reply_to_status_id" : 630065152944177152,
  "created_at" : "2015-08-08 18:18:01 +0000",
  "in_reply_to_screen_name" : "ProAntiTheist",
  "in_reply_to_user_id_str" : "384316868",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/EFVJQfRPtq",
      "expanded_url" : "https:\/\/twitter.com\/AnnotatedBible\/status\/630067455293952000",
      "display_url" : "twitter.com\/AnnotatedBible\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630080223485276160",
  "text" : "You did a nice job. You have talent. : ) https:\/\/t.co\/EFVJQfRPtq",
  "id" : 630080223485276160,
  "created_at" : "2015-08-08 18:16:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630055060018475008",
  "text" : "I remember hearing about the microwave noise and the scientists didn't know what it was at that time.",
  "id" : 630055060018475008,
  "created_at" : "2015-08-08 16:36:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630054098814005248",
  "text" : "currently reading \"Our Mathematical Universe: My Quest for the Ultimate Nature of Reality\" by Max Tegmark. Fascinating stuff!",
  "id" : 630054098814005248,
  "created_at" : "2015-08-08 16:32:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NRDC",
      "screen_name" : "NRDC",
      "indices" : [ 3, 8 ],
      "id_str" : "18713552",
      "id" : 18713552
    }, {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 58, 65 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Cuq0M1caZf",
      "expanded_url" : "http:\/\/news.nationalgeographic.com\/2015\/08\/150803-arctic-ice-obama-climate-nation-science\/",
      "display_url" : "news.nationalgeographic.com\/2015\/08\/150803\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630052291924652033",
  "text" : "RT @NRDC: Stunning. The ice caps have melted so much that @NatGeo had to remake its atlas. http:\/\/t.co\/Cuq0M1caZf #ActOnClimate http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Geographic",
        "screen_name" : "NatGeo",
        "indices" : [ 48, 55 ],
        "id_str" : "17471979",
        "id" : 17471979
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NRDC\/status\/629746997076094977\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/yYp9aim8TF",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CL1Php6WIAAL3QW.png",
        "id_str" : "629746962506588160",
        "id" : 629746962506588160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CL1Php6WIAAL3QW.png",
        "sizes" : [ {
          "h" : 605,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yYp9aim8TF"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Cuq0M1caZf",
        "expanded_url" : "http:\/\/news.nationalgeographic.com\/2015\/08\/150803-arctic-ice-obama-climate-nation-science\/",
        "display_url" : "news.nationalgeographic.com\/2015\/08\/150803\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629746997076094977",
    "text" : "Stunning. The ice caps have melted so much that @NatGeo had to remake its atlas. http:\/\/t.co\/Cuq0M1caZf #ActOnClimate http:\/\/t.co\/yYp9aim8TF",
    "id" : 629746997076094977,
    "created_at" : "2015-08-07 20:12:38 +0000",
    "user" : {
      "name" : "NRDC",
      "screen_name" : "NRDC",
      "protected" : false,
      "id_str" : "18713552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794273578644635649\/f3KN7xeK_normal.jpg",
      "id" : 18713552,
      "verified" : true
    }
  },
  "id" : 630052291924652033,
  "created_at" : "2015-08-08 16:25:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/deray\/status\/629993345155244032\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/UNKRq13ITk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL4vmaRVAAAw2HE.jpg",
      "id_str" : "629993334811983872",
      "id" : 629993334811983872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL4vmaRVAAAw2HE.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 807
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 807
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UNKRq13ITk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630046724548087808",
  "text" : "RT @deray: if we get stopped by the police. http:\/\/t.co\/UNKRq13ITk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/deray\/status\/629993345155244032\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/UNKRq13ITk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL4vmaRVAAAw2HE.jpg",
        "id_str" : "629993334811983872",
        "id" : 629993334811983872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL4vmaRVAAAw2HE.jpg",
        "sizes" : [ {
          "h" : 627,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UNKRq13ITk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629993345155244032",
    "text" : "if we get stopped by the police. http:\/\/t.co\/UNKRq13ITk",
    "id" : 629993345155244032,
    "created_at" : "2015-08-08 12:31:32 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 630046724548087808,
  "created_at" : "2015-08-08 16:03:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BernieSanders",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630043819023728640",
  "text" : "thing is.. if oligarchy is that powerful.. #BernieSanders CAN'T win.. unless something MAJOR happens. What that is.. I dunno.",
  "id" : 630043819023728640,
  "created_at" : "2015-08-08 15:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/539869871992217600\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/zE3yPa8y0L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B34Ax70IMAICX71.jpg",
      "id_str" : "539869863200960514",
      "id" : 539869863200960514,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34Ax70IMAICX71.jpg",
      "sizes" : [ {
        "h" : 701,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zE3yPa8y0L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630031502986858496",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/zE3yPa8y0L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/539869871992217600\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/zE3yPa8y0L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B34Ax70IMAICX71.jpg",
        "id_str" : "539869863200960514",
        "id" : 539869863200960514,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34Ax70IMAICX71.jpg",
        "sizes" : [ {
          "h" : 701,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zE3yPa8y0L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630028243043774464",
    "text" : "http:\/\/t.co\/zE3yPa8y0L",
    "id" : 630028243043774464,
    "created_at" : "2015-08-08 14:50:13 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 630031502986858496,
  "created_at" : "2015-08-08 15:03:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Terrazas",
      "screen_name" : "JessTerrazas88",
      "indices" : [ 3, 18 ],
      "id_str" : "458000991",
      "id" : 458000991
    }, {
      "name" : "Jane Crowfoot",
      "screen_name" : "JaneCrowfoot",
      "indices" : [ 61, 74 ],
      "id_str" : "632285096",
      "id" : 632285096
    }, {
      "name" : "Stylecraft Yarns",
      "screen_name" : "StylecraftYarn",
      "indices" : [ 75, 90 ],
      "id_str" : "1655034697",
      "id" : 1655034697
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JessTerrazas88\/status\/629810105907675136\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/CHXIRer8RM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL2I8W9UYAAfUz6.jpg",
      "id_str" : "629810093438033920",
      "id" : 629810093438033920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL2I8W9UYAAfUz6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CHXIRer8RM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630029199760302081",
  "text" : "RT @JessTerrazas88: Lily took home First Place at the fair \uD83D\uDE0A @JaneCrowfoot @StylecraftYarn http:\/\/t.co\/CHXIRer8RM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Crowfoot",
        "screen_name" : "JaneCrowfoot",
        "indices" : [ 41, 54 ],
        "id_str" : "632285096",
        "id" : 632285096
      }, {
        "name" : "Stylecraft Yarns",
        "screen_name" : "StylecraftYarn",
        "indices" : [ 55, 70 ],
        "id_str" : "1655034697",
        "id" : 1655034697
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JessTerrazas88\/status\/629810105907675136\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/CHXIRer8RM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL2I8W9UYAAfUz6.jpg",
        "id_str" : "629810093438033920",
        "id" : 629810093438033920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL2I8W9UYAAfUz6.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CHXIRer8RM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629810105907675136",
    "text" : "Lily took home First Place at the fair \uD83D\uDE0A @JaneCrowfoot @StylecraftYarn http:\/\/t.co\/CHXIRer8RM",
    "id" : 629810105907675136,
    "created_at" : "2015-08-08 00:23:25 +0000",
    "user" : {
      "name" : "Jessica Terrazas",
      "screen_name" : "JessTerrazas88",
      "protected" : false,
      "id_str" : "458000991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687662404537196544\/egzB2NH8_normal.jpg",
      "id" : 458000991,
      "verified" : false
    }
  },
  "id" : 630029199760302081,
  "created_at" : "2015-08-08 14:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630027344913285120",
  "text" : "RT @SouthYeoEast: Found this rather ragged little chap feeding on thistle flowers next to the river. Silver-washed fritillary I think? http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/629765979946545153\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KyKqvwkJVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1gsBeWEAACqzF.jpg",
        "id_str" : "629765832327958528",
        "id" : 629765832327958528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1gsBeWEAACqzF.jpg",
        "sizes" : [ {
          "h" : 866,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 866,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KyKqvwkJVB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/629765979946545153\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KyKqvwkJVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1gwUOWcAAlpMA.jpg",
        "id_str" : "629765906080624640",
        "id" : 629765906080624640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1gwUOWcAAlpMA.jpg",
        "sizes" : [ {
          "h" : 703,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 703,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KyKqvwkJVB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/629765979946545153\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KyKqvwkJVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1g0e7WUAAhP9s.jpg",
        "id_str" : "629765977673191424",
        "id" : 629765977673191424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1g0e7WUAAhP9s.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KyKqvwkJVB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629765979946545153",
    "text" : "Found this rather ragged little chap feeding on thistle flowers next to the river. Silver-washed fritillary I think? http:\/\/t.co\/KyKqvwkJVB",
    "id" : 629765979946545153,
    "created_at" : "2015-08-07 21:28:04 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 630027344913285120,
  "created_at" : "2015-08-08 14:46:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "'Vegan Turkey' Quinn",
      "screen_name" : "quinnnorton",
      "indices" : [ 3, 15 ],
      "id_str" : "38975663",
      "id" : 38975663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630025385384747009",
  "text" : "RT @quinnnorton: For the better part of a year, I have embarked on a terrifying social experiment: Being a kinder person. https:\/\/t.co\/Qkb1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Qkb1jM0fvN",
        "expanded_url" : "https:\/\/medium.com\/message\/ahimsa-online-ef09b9c072",
        "display_url" : "medium.com\/message\/ahimsa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629726647638470656",
    "text" : "For the better part of a year, I have embarked on a terrifying social experiment: Being a kinder person. https:\/\/t.co\/Qkb1jM0fvN",
    "id" : 629726647638470656,
    "created_at" : "2015-08-07 18:51:47 +0000",
    "user" : {
      "name" : "'Vegan Turkey' Quinn",
      "screen_name" : "quinnnorton",
      "protected" : false,
      "id_str" : "38975663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794107440702820352\/-6AIFdvi_normal.jpg",
      "id" : 38975663,
      "verified" : false
    }
  },
  "id" : 630025385384747009,
  "created_at" : "2015-08-08 14:38:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bookworm",
      "screen_name" : "simplecoolguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3108369949",
      "id" : 3108369949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/simplecoolguy\/status\/629845933212213248\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/nM1gf1JzOi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL2piYHUEAA4MVK.jpg",
      "id_str" : "629845930955509760",
      "id" : 629845930955509760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL2piYHUEAA4MVK.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/nM1gf1JzOi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629846304773029892",
  "text" : "RT @simplecoolguy: http:\/\/t.co\/nM1gf1JzOi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/simplecoolguy\/status\/629845933212213248\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/nM1gf1JzOi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL2piYHUEAA4MVK.jpg",
        "id_str" : "629845930955509760",
        "id" : 629845930955509760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL2piYHUEAA4MVK.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/nM1gf1JzOi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629845933212213248",
    "text" : "http:\/\/t.co\/nM1gf1JzOi",
    "id" : 629845933212213248,
    "created_at" : "2015-08-08 02:45:47 +0000",
    "user" : {
      "name" : "The Bookworm",
      "screen_name" : "simplecoolguy",
      "protected" : false,
      "id_str" : "3108369949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581114694812872704\/TNT4pP16_normal.jpg",
      "id" : 3108369949,
      "verified" : false
    }
  },
  "id" : 629846304773029892,
  "created_at" : "2015-08-08 02:47:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "indices" : [ 3, 15 ],
      "id_str" : "896548279",
      "id" : 896548279
    }, {
      "name" : "Neuroscience News",
      "screen_name" : "NeuroscienceNew",
      "indices" : [ 17, 33 ],
      "id_str" : "32302688",
      "id" : 32302688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629846101588357120",
  "text" : "RT @NaamaYehuda: @NeuroscienceNew Does not mean it is not a physiologically supported condition, only that it is not a hormonal imbalance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neuroscience News",
        "screen_name" : "NeuroscienceNew",
        "indices" : [ 0, 16 ],
        "id_str" : "32302688",
        "id" : 32302688
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629792792886181888",
    "geo" : { },
    "id_str" : "629796102972309504",
    "in_reply_to_user_id" : 32302688,
    "text" : "@NeuroscienceNew Does not mean it is not a physiologically supported condition, only that it is not a hormonal imbalance.",
    "id" : 629796102972309504,
    "in_reply_to_status_id" : 629792792886181888,
    "created_at" : "2015-08-07 23:27:46 +0000",
    "in_reply_to_screen_name" : "NeuroscienceNew",
    "in_reply_to_user_id_str" : "32302688",
    "user" : {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "protected" : false,
      "id_str" : "896548279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2748712360\/5665839cb74057117f99ea3245bba181_normal.jpeg",
      "id" : 896548279,
      "verified" : false
    }
  },
  "id" : 629846101588357120,
  "created_at" : "2015-08-08 02:46:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThatGuySpike",
      "screen_name" : "ThatGuySpike",
      "indices" : [ 3, 16 ],
      "id_str" : "218526734",
      "id" : 218526734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/DZLQRbQbYF",
      "expanded_url" : "http:\/\/photo.net",
      "display_url" : "photo.net"
    } ]
  },
  "geo" : { },
  "id_str" : "629808458569789440",
  "text" : "RT @ThatGuySpike: Golden Tufa at Mono Lake by Lester A. Garcia(http:\/\/t.co\/DZLQRbQbYF contributor) Kind of takes your breath away! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThatGuySpike\/status\/629808195687419904\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/7qsrW6GGZ9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL2HN1PUAAAp1sg.jpg",
        "id_str" : "629808194601091072",
        "id" : 629808194601091072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL2HN1PUAAAp1sg.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/7qsrW6GGZ9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/DZLQRbQbYF",
        "expanded_url" : "http:\/\/photo.net",
        "display_url" : "photo.net"
      } ]
    },
    "geo" : { },
    "id_str" : "629808195687419904",
    "text" : "Golden Tufa at Mono Lake by Lester A. Garcia(http:\/\/t.co\/DZLQRbQbYF contributor) Kind of takes your breath away! http:\/\/t.co\/7qsrW6GGZ9",
    "id" : 629808195687419904,
    "created_at" : "2015-08-08 00:15:49 +0000",
    "user" : {
      "name" : "ThatGuySpike",
      "screen_name" : "ThatGuySpike",
      "protected" : false,
      "id_str" : "218526734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342216794\/5688095c1ee110b819c8d6ba902518f4_normal.png",
      "id" : 218526734,
      "verified" : false
    }
  },
  "id" : 629808458569789440,
  "created_at" : "2015-08-08 00:16:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vabirdlibrary",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629798366831058944",
  "text" : "RT @Library4birds: \"We meet again, Miss Dove.\"\n\"Yes, I work here. This is where I usually am.\"\n\"Interesting...\"\n#vabirdlibrary http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/629798120960970752\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/E7HLaruj3N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1-Da3UwAAzS4a.jpg",
        "id_str" : "629798120117813248",
        "id" : 629798120117813248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1-Da3UwAAzS4a.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/E7HLaruj3N"
      } ],
      "hashtags" : [ {
        "text" : "vabirdlibrary",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629798120960970752",
    "text" : "\"We meet again, Miss Dove.\"\n\"Yes, I work here. This is where I usually am.\"\n\"Interesting...\"\n#vabirdlibrary http:\/\/t.co\/E7HLaruj3N",
    "id" : 629798120960970752,
    "created_at" : "2015-08-07 23:35:47 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 629798366831058944,
  "created_at" : "2015-08-07 23:36:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/JKazri4Ls4",
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/629778308239073280",
      "display_url" : "twitter.com\/SciencePorn\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629780201757614080",
  "text" : "cool https:\/\/t.co\/JKazri4Ls4",
  "id" : 629780201757614080,
  "created_at" : "2015-08-07 22:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 68, 78 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/lsmYW0XxB6",
      "expanded_url" : "https:\/\/shar.es\/1t7jsH",
      "display_url" : "shar.es\/1t7jsH"
    } ]
  },
  "geo" : { },
  "id_str" : "629779758822387712",
  "text" : "To a Christian woman who chose abortion https:\/\/t.co\/lsmYW0XxB6 via @sharethis",
  "id" : 629779758822387712,
  "created_at" : "2015-08-07 22:22:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Texas Forever",
      "screen_name" : "andreagrimes",
      "indices" : [ 3, 16 ],
      "id_str" : "4209511",
      "id" : 4209511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629773427038138368",
  "text" : "RT @andreagrimes: I guess I\u2019m not radical enough but I sort of believe in better lives and situations for literally everybody, not just my \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629764660670164992",
    "geo" : { },
    "id_str" : "629764932163252224",
    "in_reply_to_user_id" : 4209511,
    "text" : "I guess I\u2019m not radical enough but I sort of believe in better lives and situations for literally everybody, not just my lefty friends.",
    "id" : 629764932163252224,
    "in_reply_to_status_id" : 629764660670164992,
    "created_at" : "2015-08-07 21:23:54 +0000",
    "in_reply_to_screen_name" : "andreagrimes",
    "in_reply_to_user_id_str" : "4209511",
    "user" : {
      "name" : "Texas Forever",
      "screen_name" : "andreagrimes",
      "protected" : false,
      "id_str" : "4209511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798977878570500101\/ANcchCP__normal.jpg",
      "id" : 4209511,
      "verified" : true
    }
  },
  "id" : 629773427038138368,
  "created_at" : "2015-08-07 21:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "indices" : [ 3, 14 ],
      "id_str" : "2236808551",
      "id" : 2236808551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cows",
      "indices" : [ 22, 27 ]
    }, {
      "text" : "photography",
      "indices" : [ 88, 100 ]
    }, {
      "text" : "animals",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "greybruce",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629763659695292416",
  "text" : "RT @JenLRPhoto: Brown #Cows :) very interested in me lol :) some funny faces on them \u263A\uFE0F #photography #animals #greybruce http:\/\/t.co\/NE1Pge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/626839949313220609\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/NE1PgepWHm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLL7kJiUAAARZO3.jpg",
        "id_str" : "626839896611618816",
        "id" : 626839896611618816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLL7kJiUAAARZO3.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NE1PgepWHm"
      } ],
      "hashtags" : [ {
        "text" : "Cows",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "photography",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "animals",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "greybruce",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626839949313220609",
    "text" : "Brown #Cows :) very interested in me lol :) some funny faces on them \u263A\uFE0F #photography #animals #greybruce http:\/\/t.co\/NE1PgepWHm",
    "id" : 626839949313220609,
    "created_at" : "2015-07-30 19:41:04 +0000",
    "user" : {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "protected" : false,
      "id_str" : "2236808551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916989995909120\/ZPqHp6yp_normal.jpg",
      "id" : 2236808551,
      "verified" : false
    }
  },
  "id" : 629763659695292416,
  "created_at" : "2015-08-07 21:18:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 3, 12 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PZcIljCOb2",
      "expanded_url" : "http:\/\/fernsfronds.blogspot.com\/2015\/08\/taking-wider-view.html?spref=tw",
      "display_url" : "fernsfronds.blogspot.com\/2015\/08\/taking\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629714646161879041",
  "text" : "RT @Fernwise: Fern's Fronds: Taking A Wider View http:\/\/t.co\/PZcIljCOb2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/PZcIljCOb2",
        "expanded_url" : "http:\/\/fernsfronds.blogspot.com\/2015\/08\/taking-wider-view.html?spref=tw",
        "display_url" : "fernsfronds.blogspot.com\/2015\/08\/taking\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629705405069856768",
    "text" : "Fern's Fronds: Taking A Wider View http:\/\/t.co\/PZcIljCOb2",
    "id" : 629705405069856768,
    "created_at" : "2015-08-07 17:27:22 +0000",
    "user" : {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "protected" : false,
      "id_str" : "23538653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/253664055\/FernForTwitter_normal.png",
      "id" : 23538653,
      "verified" : false
    }
  },
  "id" : 629714646161879041,
  "created_at" : "2015-08-07 18:04:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629713636131536896",
  "text" : "this is weird but I was looking at pic of girls wearing long denim skirts.. and it was like looking at them wearing just underwear.",
  "id" : 629713636131536896,
  "created_at" : "2015-08-07 18:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/pF037yNXKV",
      "expanded_url" : "https:\/\/twitter.com\/ddsmidt\/status\/629269054998515712",
      "display_url" : "twitter.com\/ddsmidt\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629694609791275008",
  "text" : "I AM lazy but this IS funny..lol https:\/\/t.co\/pF037yNXKV",
  "id" : 629694609791275008,
  "created_at" : "2015-08-07 16:44:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juliet Harrison",
      "screen_name" : "lecheval",
      "indices" : [ 3, 12 ],
      "id_str" : "17257283",
      "id" : 17257283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629678886780039168",
  "text" : "RT @lecheval: How sad....a young boy maybe 9 or 10 just walked by the open door and I heard him say, \"I want to go in there\"... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/3inq5vAO4h",
        "expanded_url" : "http:\/\/fb.me\/395Hv15VF",
        "display_url" : "fb.me\/395Hv15VF"
      } ]
    },
    "geo" : { },
    "id_str" : "629678323732488192",
    "text" : "How sad....a young boy maybe 9 or 10 just walked by the open door and I heard him say, \"I want to go in there\"... http:\/\/t.co\/3inq5vAO4h",
    "id" : 629678323732488192,
    "created_at" : "2015-08-07 15:39:45 +0000",
    "user" : {
      "name" : "Juliet Harrison",
      "screen_name" : "lecheval",
      "protected" : false,
      "id_str" : "17257283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220023348\/417-23ab_normal.jpg",
      "id" : 17257283,
      "verified" : false
    }
  },
  "id" : 629678886780039168,
  "created_at" : "2015-08-07 15:42:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/bquQmOhPFy",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B00NQFHENM\/ref=cm_sw_r_tw_dp_UmmXvb1JMJHXJ",
      "display_url" : "amazon.com\/dp\/B00NQFHENM\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629663755761266688",
  "text" : "dh bought for me. adorable! &gt;&gt; Owl Peeramid Bookrest http:\/\/t.co\/bquQmOhPFy",
  "id" : 629663755761266688,
  "created_at" : "2015-08-07 14:41:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629662068086566912",
  "text" : "RT @Mahala: I'm still kinda pissed that the live stream for the debate was only available if you have cable or satellite. #poorvotesdontcou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "poorvotesdontcount",
        "indices" : [ 110, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629660349562810368",
    "text" : "I'm still kinda pissed that the live stream for the debate was only available if you have cable or satellite. #poorvotesdontcount",
    "id" : 629660349562810368,
    "created_at" : "2015-08-07 14:28:20 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 629662068086566912,
  "created_at" : "2015-08-07 14:35:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "graphic",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "BernieSanders",
      "indices" : [ 21, 35 ]
    }, {
      "text" : "vision",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629661945495465984",
  "text" : "I want a #graphic of #BernieSanders on the microsoft unicorn with the cat waving a rainbow flag. How cool would that be!? Anybody? #vision",
  "id" : 629661945495465984,
  "created_at" : "2015-08-07 14:34:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalesbrad Holsteins",
      "screen_name" : "Dalesbrad007",
      "indices" : [ 3, 16 ],
      "id_str" : "1618461726",
      "id" : 1618461726
    }, {
      "name" : "Farmers Of The UK",
      "screen_name" : "FarmersOfTheUK",
      "indices" : [ 18, 33 ],
      "id_str" : "2276009684",
      "id" : 2276009684
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Dalesbrad007\/status\/629588982062575616\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/QThI2vsYHA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLy_150UEAAHAZj.jpg",
      "id_str" : "629588980699238400",
      "id" : 629588980699238400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLy_150UEAAHAZj.jpg",
      "sizes" : [ {
        "h" : 866,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 866,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QThI2vsYHA"
    } ],
    "hashtags" : [ {
      "text" : "FarmPhoto",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629654854194069504",
  "text" : "RT @Dalesbrad007: @FarmersOfTheUK one of our dry cows in amongst the foxgloves...\r#FarmPhoto http:\/\/t.co\/QThI2vsYHA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Farmers Of The UK",
        "screen_name" : "FarmersOfTheUK",
        "indices" : [ 0, 15 ],
        "id_str" : "2276009684",
        "id" : 2276009684
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dalesbrad007\/status\/629588982062575616\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/QThI2vsYHA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLy_150UEAAHAZj.jpg",
        "id_str" : "629588980699238400",
        "id" : 629588980699238400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLy_150UEAAHAZj.jpg",
        "sizes" : [ {
          "h" : 866,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 866,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QThI2vsYHA"
      } ],
      "hashtags" : [ {
        "text" : "FarmPhoto",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629585622232117249",
    "geo" : { },
    "id_str" : "629588982062575616",
    "in_reply_to_user_id" : 2276009684,
    "text" : "@FarmersOfTheUK one of our dry cows in amongst the foxgloves...\r#FarmPhoto http:\/\/t.co\/QThI2vsYHA",
    "id" : 629588982062575616,
    "in_reply_to_status_id" : 629585622232117249,
    "created_at" : "2015-08-07 09:44:45 +0000",
    "in_reply_to_screen_name" : "FarmersOfTheUK",
    "in_reply_to_user_id_str" : "2276009684",
    "user" : {
      "name" : "Dalesbrad Holsteins",
      "screen_name" : "Dalesbrad007",
      "protected" : false,
      "id_str" : "1618461726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786433832916512768\/Gp67gNql_normal.jpg",
      "id" : 1618461726,
      "verified" : false
    }
  },
  "id" : 629654854194069504,
  "created_at" : "2015-08-07 14:06:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Woods",
      "screen_name" : "scottwoodssays",
      "indices" : [ 3, 18 ],
      "id_str" : "16190176",
      "id" : 16190176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629486258687975424",
  "text" : "RT @scottwoodssays: This God question is so fucking out of line (sorry Jesus). How is this question even legal in a country with separation\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629485752334843904",
    "text" : "This God question is so fucking out of line (sorry Jesus). How is this question even legal in a country with separation of church and state?",
    "id" : 629485752334843904,
    "created_at" : "2015-08-07 02:54:33 +0000",
    "user" : {
      "name" : "Scott Woods",
      "screen_name" : "scottwoodssays",
      "protected" : false,
      "id_str" : "16190176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1424003225\/scottdesk_normal.jpg",
      "id" : 16190176,
      "verified" : false
    }
  },
  "id" : 629486258687975424,
  "created_at" : "2015-08-07 02:56:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629485582566227968",
  "text" : "RT @rjmedwed: No, seriously, I really, really mean it. Why the fuck are they bringing up God? #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629483883222990848",
    "geo" : { },
    "id_str" : "629484102039814144",
    "in_reply_to_user_id" : 290187508,
    "text" : "No, seriously, I really, really mean it. Why the fuck are they bringing up God? #GOPDebate",
    "id" : 629484102039814144,
    "in_reply_to_status_id" : 629483883222990848,
    "created_at" : "2015-08-07 02:47:59 +0000",
    "in_reply_to_screen_name" : "rjmedwed",
    "in_reply_to_user_id_str" : "290187508",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 629485582566227968,
  "created_at" : "2015-08-07 02:53:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629485517030170624",
  "text" : "RT @rjmedwed: They\u2019re asking about God? Isn\u2019t the no religious litmus test thing\u201D in the Constitution? The US Constitution? #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629483883222990848",
    "text" : "They\u2019re asking about God? Isn\u2019t the no religious litmus test thing\u201D in the Constitution? The US Constitution? #GOPDebate",
    "id" : 629483883222990848,
    "created_at" : "2015-08-07 02:47:07 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 629485517030170624,
  "created_at" : "2015-08-07 02:53:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nish Weiseth",
      "screen_name" : "NishWeiseth",
      "indices" : [ 3, 15 ],
      "id_str" : "16910582",
      "id" : 16910582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629485146719289344",
  "text" : "RT @NishWeiseth: WAIT, GOD IS SHOWING UP? I HAVE SO MANY QUESTIONS. #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629484070011957248",
    "text" : "WAIT, GOD IS SHOWING UP? I HAVE SO MANY QUESTIONS. #GOPDebate",
    "id" : 629484070011957248,
    "created_at" : "2015-08-07 02:47:52 +0000",
    "user" : {
      "name" : "Nish Weiseth",
      "screen_name" : "NishWeiseth",
      "protected" : false,
      "id_str" : "16910582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796829839911026688\/T6C3TYz5_normal.jpg",
      "id" : 16910582,
      "verified" : true
    }
  },
  "id" : 629485146719289344,
  "created_at" : "2015-08-07 02:52:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "indices" : [ 0, 10 ],
      "id_str" : "410135192",
      "id" : 410135192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629483382192390144",
  "geo" : { },
  "id_str" : "629484313709514752",
  "in_reply_to_user_id" : 410135192,
  "text" : "@laprofe63 lol.. just what I was thinking, too..",
  "id" : 629484313709514752,
  "in_reply_to_status_id" : 629483382192390144,
  "created_at" : "2015-08-07 02:48:50 +0000",
  "in_reply_to_screen_name" : "laprofe63",
  "in_reply_to_user_id_str" : "410135192",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629474632878395393",
  "geo" : { },
  "id_str" : "629475387253329920",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH lol.. i said to dh, \"prostitutes are freeloaders?\"",
  "id" : 629475387253329920,
  "in_reply_to_status_id" : 629474632878395393,
  "created_at" : "2015-08-07 02:13:22 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629472140010627072",
  "text" : "RT @nakedpastor: Freedom is scary at first but you do get used to it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629471102163656704",
    "text" : "Freedom is scary at first but you do get used to it.",
    "id" : 629471102163656704,
    "created_at" : "2015-08-07 01:56:20 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 629472140010627072,
  "created_at" : "2015-08-07 02:00:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629471873491955712",
  "text" : "RT @deray: Trump literally said that he donates to politicians and then calls them later to get what he wants. He literally just said that.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629469559670464512",
    "text" : "Trump literally said that he donates to politicians and then calls them later to get what he wants. He literally just said that. #GOPDebate",
    "id" : 629469559670464512,
    "created_at" : "2015-08-07 01:50:12 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 629471873491955712,
  "created_at" : "2015-08-07 01:59:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Diamond",
      "screen_name" : "dintheruff88",
      "indices" : [ 115, 128 ],
      "id_str" : "587803564",
      "id" : 587803564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629464988311289856",
  "text" : "interesting&gt;&gt; Quell - Pain Relief Wearable: FDA-cleared 100% drug-free device that relieves chronic pain via @dintheruff88",
  "id" : 629464988311289856,
  "created_at" : "2015-08-07 01:32:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    }, {
      "name" : "ThanksAmerica",
      "screen_name" : "ThanksAmerica",
      "indices" : [ 119, 133 ],
      "id_str" : "10770952",
      "id" : 10770952
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 134, 138 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629459224620351488",
  "text" : "RT @Mahala: I don't have live access to the debates without a paid cable subscription? Gotta have $$ to stay informed? @thanksAmerica @cnn \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThanksAmerica",
        "screen_name" : "ThanksAmerica",
        "indices" : [ 107, 121 ],
        "id_str" : "10770952",
        "id" : 10770952
      }, {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 122, 126 ],
        "id_str" : "759251",
        "id" : 759251
      }, {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 127, 133 ],
        "id_str" : "2836421",
        "id" : 2836421
      }, {
        "name" : "fantastic ms.",
        "screen_name" : "fox",
        "indices" : [ 134, 138 ],
        "id_str" : "42864649",
        "id" : 42864649
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629458953680879616",
    "text" : "I don't have live access to the debates without a paid cable subscription? Gotta have $$ to stay informed? @thanksAmerica @cnn @msnbc @fox",
    "id" : 629458953680879616,
    "created_at" : "2015-08-07 01:08:03 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 629459224620351488,
  "created_at" : "2015-08-07 01:09:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shelly Banjo",
      "screen_name" : "sbanjo",
      "indices" : [ 3, 10 ],
      "id_str" : "9505502",
      "id" : 9505502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629458504978448384",
  "text" : "RT @sbanjo: Dear Twitter: My Mom's in need of a kidney donor. Can you please share widely? The more who see, the closer we'll get http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sbanjo\/status\/627985993996574720\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wzLXGEGGjH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLcN7wnWsAEdDWd.jpg",
        "id_str" : "627985993354883073",
        "id" : 627985993354883073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLcN7wnWsAEdDWd.jpg",
        "sizes" : [ {
          "h" : 1317,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3128,
          "resize" : "fit",
          "w" : 2433
        } ],
        "display_url" : "pic.twitter.com\/wzLXGEGGjH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627985993996574720",
    "text" : "Dear Twitter: My Mom's in need of a kidney donor. Can you please share widely? The more who see, the closer we'll get http:\/\/t.co\/wzLXGEGGjH",
    "id" : 627985993996574720,
    "created_at" : "2015-08-02 23:35:03 +0000",
    "user" : {
      "name" : "Shelly Banjo",
      "screen_name" : "sbanjo",
      "protected" : false,
      "id_str" : "9505502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785219243721842688\/9S-suBeh_normal.jpg",
      "id" : 9505502,
      "verified" : true
    }
  },
  "id" : 629458504978448384,
  "created_at" : "2015-08-07 01:06:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629439453774381057",
  "text" : "RT @JeremyCShipp: Shouldn't all events like political debates be broadcast for everyone on public television?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629437913382588416",
    "text" : "Shouldn't all events like political debates be broadcast for everyone on public television?",
    "id" : 629437913382588416,
    "created_at" : "2015-08-06 23:44:27 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 629439453774381057,
  "created_at" : "2015-08-06 23:50:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DSCC",
      "screen_name" : "dscc",
      "indices" : [ 3, 8 ],
      "id_str" : "14466538",
      "id" : 14466538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629426465323532288",
  "text" : "RT @dscc: Planning to watch the #GOPDebate tonight? So are we! Join us as we live-tweet the shenanigans starting at 9pm ET!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 22, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629400347199410176",
    "text" : "Planning to watch the #GOPDebate tonight? So are we! Join us as we live-tweet the shenanigans starting at 9pm ET!",
    "id" : 629400347199410176,
    "created_at" : "2015-08-06 21:15:11 +0000",
    "user" : {
      "name" : "DSCC",
      "screen_name" : "dscc",
      "protected" : false,
      "id_str" : "14466538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727517123153633281\/-QQZp5zJ_normal.jpg",
      "id" : 14466538,
      "verified" : true
    }
  },
  "id" : 629426465323532288,
  "created_at" : "2015-08-06 22:58:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Holman",
      "screen_name" : "joannamuses",
      "indices" : [ 3, 15 ],
      "id_str" : "18622950",
      "id" : 18622950
    }, {
      "name" : "davidburkus",
      "screen_name" : "davidburkus",
      "indices" : [ 77, 89 ],
      "id_str" : "18164805",
      "id" : 18164805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/5x3qL2TFYq",
      "expanded_url" : "http:\/\/davidburkus.com\/giveaways\/win-a-year-of-audible-audiobooks\/?lucky=3113",
      "display_url" : "davidburkus.com\/giveaways\/win-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629424432835117056",
  "text" : "RT @joannamuses: Win a Year of Audible Audiobooks http:\/\/t.co\/5x3qL2TFYq via @davidburkus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "davidburkus",
        "screen_name" : "davidburkus",
        "indices" : [ 60, 72 ],
        "id_str" : "18164805",
        "id" : 18164805
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/5x3qL2TFYq",
        "expanded_url" : "http:\/\/davidburkus.com\/giveaways\/win-a-year-of-audible-audiobooks\/?lucky=3113",
        "display_url" : "davidburkus.com\/giveaways\/win-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629401839381839872",
    "text" : "Win a Year of Audible Audiobooks http:\/\/t.co\/5x3qL2TFYq via @davidburkus",
    "id" : 629401839381839872,
    "created_at" : "2015-08-06 21:21:06 +0000",
    "user" : {
      "name" : "Joanna Holman",
      "screen_name" : "joannamuses",
      "protected" : false,
      "id_str" : "18622950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688281262339932160\/svl56s1D_normal.jpg",
      "id" : 18622950,
      "verified" : false
    }
  },
  "id" : 629424432835117056,
  "created_at" : "2015-08-06 22:50:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/4R7ZLH1aLf",
      "expanded_url" : "http:\/\/micahjmurray.com\/this-is-some-bullshit\/",
      "display_url" : "micahjmurray.com\/this-is-some-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629408255530409984",
  "text" : "\"How the fuck is it that everybody is supposed to know God\u2019s will for your life but you?\" http:\/\/t.co\/4R7ZLH1aLf",
  "id" : 629408255530409984,
  "created_at" : "2015-08-06 21:46:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prednisone",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 91, 102 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629354173818122240",
  "text" : "DD is starting #prednisone (1\/4 of 10 mg tab) today. wish us luck it doesnt make her sick! #hashimotos #thyroid",
  "id" : 629354173818122240,
  "created_at" : "2015-08-06 18:11:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Early",
      "screen_name" : "alanearly",
      "indices" : [ 0, 10 ],
      "id_str" : "24219690",
      "id" : 24219690
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 11, 21 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "John D Walsh",
      "screen_name" : "johndwalsh",
      "indices" : [ 22, 33 ],
      "id_str" : "140041470",
      "id" : 140041470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629299370010222592",
  "geo" : { },
  "id_str" : "629334603019485184",
  "in_reply_to_user_id" : 24219690,
  "text" : "@alanearly @bend_time @johndwalsh nde glimpses of different dimensions of conciousness. \"heaven\" is not static nor 1 place. imho.",
  "id" : 629334603019485184,
  "in_reply_to_status_id" : 629299370010222592,
  "created_at" : "2015-08-06 16:53:56 +0000",
  "in_reply_to_screen_name" : "alanearly",
  "in_reply_to_user_id_str" : "24219690",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noel McGivern",
      "screen_name" : "Good_Beard",
      "indices" : [ 3, 14 ],
      "id_str" : "83860499",
      "id" : 83860499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629103630638034944",
  "text" : "RT @Good_Beard: I have met good people in religion, but I have never thought one was made good by it or that they would suddenly become bad\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629009113540902912",
    "text" : "I have met good people in religion, but I have never thought one was made good by it or that they would suddenly become bad if they lost it.",
    "id" : 629009113540902912,
    "created_at" : "2015-08-05 19:20:33 +0000",
    "user" : {
      "name" : "Noel McGivern",
      "screen_name" : "Good_Beard",
      "protected" : false,
      "id_str" : "83860499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744954516181770240\/3u8KTCuI_normal.jpg",
      "id" : 83860499,
      "verified" : false
    }
  },
  "id" : 629103630638034944,
  "created_at" : "2015-08-06 01:36:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giselle",
      "screen_name" : "giselle1900",
      "indices" : [ 3, 15 ],
      "id_str" : "630039574",
      "id" : 630039574
    }, {
      "name" : "Ruth Segura Bourdet",
      "screen_name" : "RuthDSegura",
      "indices" : [ 64, 76 ],
      "id_str" : "405814985",
      "id" : 405814985
    }, {
      "name" : "\uD83C\uDDFA\uD83C\uDDF2\uD83D\uDC3EAthina\uD83D\uDC3E\uD83C\uDDFA\uD83C\uDDF2",
      "screen_name" : "saveallanimals2",
      "indices" : [ 77, 93 ],
      "id_str" : "2300508674",
      "id" : 2300508674
    }, {
      "name" : "SPanimal lover ANON",
      "screen_name" : "shellieRNCEN",
      "indices" : [ 94, 107 ],
      "id_str" : "2861843505",
      "id" : 2861843505
    }, {
      "name" : "Jackie",
      "screen_name" : "Jackie34563177",
      "indices" : [ 108, 123 ],
      "id_str" : "769449354",
      "id" : 769449354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TX",
      "indices" : [ 60, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/PwIJ774z5I",
      "expanded_url" : "https:\/\/www.facebook.com\/permalink.php?story_fbid=10154131311359418&id=100486599417",
      "display_url" : "facebook.com\/permalink.php?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629101443497226242",
  "text" : "RT @giselle1900: SOS!PLZ SAVE BINGO https:\/\/t.co\/PwIJ774z5I #TX @RuthDSegura @saveallanimals2 @shellieRNCEN @Jackie34563177 http:\/\/t.co\/mME\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ruth Segura Bourdet",
        "screen_name" : "RuthDSegura",
        "indices" : [ 47, 59 ],
        "id_str" : "405814985",
        "id" : 405814985
      }, {
        "name" : "\uD83C\uDDFA\uD83C\uDDF2\uD83D\uDC3EAthina\uD83D\uDC3E\uD83C\uDDFA\uD83C\uDDF2",
        "screen_name" : "saveallanimals2",
        "indices" : [ 60, 76 ],
        "id_str" : "2300508674",
        "id" : 2300508674
      }, {
        "name" : "SPanimal lover ANON",
        "screen_name" : "shellieRNCEN",
        "indices" : [ 77, 90 ],
        "id_str" : "2861843505",
        "id" : 2861843505
      }, {
        "name" : "Jackie",
        "screen_name" : "Jackie34563177",
        "indices" : [ 91, 106 ],
        "id_str" : "769449354",
        "id" : 769449354
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/giselle1900\/status\/629003640381026305\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/mMEXwvNlfJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqrdgaWoAAW0pN.jpg",
        "id_str" : "629003621376630784",
        "id" : 629003621376630784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqrdgaWoAAW0pN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 631,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 631,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mMEXwvNlfJ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/giselle1900\/status\/629003640381026305\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/mMEXwvNlfJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqrdnCWEAApzN5.jpg",
        "id_str" : "629003623154978816",
        "id" : 629003623154978816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqrdnCWEAApzN5.jpg",
        "sizes" : [ {
          "h" : 468,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mMEXwvNlfJ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/giselle1900\/status\/629003640381026305\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/mMEXwvNlfJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqrdw4WUAAHG1r.jpg",
        "id_str" : "629003625797406720",
        "id" : 629003625797406720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqrdw4WUAAHG1r.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/mMEXwvNlfJ"
      } ],
      "hashtags" : [ {
        "text" : "TX",
        "indices" : [ 43, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/PwIJ774z5I",
        "expanded_url" : "https:\/\/www.facebook.com\/permalink.php?story_fbid=10154131311359418&id=100486599417",
        "display_url" : "facebook.com\/permalink.php?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629003640381026305",
    "text" : "SOS!PLZ SAVE BINGO https:\/\/t.co\/PwIJ774z5I #TX @RuthDSegura @saveallanimals2 @shellieRNCEN @Jackie34563177 http:\/\/t.co\/mMEXwvNlfJ",
    "id" : 629003640381026305,
    "created_at" : "2015-08-05 18:58:48 +0000",
    "user" : {
      "name" : "Giselle",
      "screen_name" : "giselle1900",
      "protected" : false,
      "id_str" : "630039574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773007967796994050\/bUNDW0ML_normal.jpg",
      "id" : 630039574,
      "verified" : false
    }
  },
  "id" : 629101443497226242,
  "created_at" : "2015-08-06 01:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ickle Misty",
      "screen_name" : "UnlovableT",
      "indices" : [ 3, 14 ],
      "id_str" : "744005468",
      "id" : 744005468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/0ifd1gNgKm",
      "expanded_url" : "http:\/\/www.boredpanda.com\/unusual-bird-nests\/?utm_content=bufferd5647&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "boredpanda.com\/unusual-bird-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629092366599589888",
  "text" : "RT @UnlovableT: Everywhere is a potential nest for our bird families, heres some of the most ingenuitive ones. http:\/\/t.co\/0ifd1gNgKm http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UnlovableT\/status\/612286092029657089\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZSs12YZKnO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH9G801WwAAUDn6.jpg",
        "id_str" : "612286085134204928",
        "id" : 612286085134204928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH9G801WwAAUDn6.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZSs12YZKnO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/UnlovableT\/status\/612286092029657089\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZSs12YZKnO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH9G9BcWEAAQcZh.jpg",
        "id_str" : "612286088518963200",
        "id" : 612286088518963200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH9G9BcWEAAQcZh.jpg",
        "sizes" : [ {
          "h" : 848,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 841,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 848,
          "resize" : "fit",
          "w" : 605
        } ],
        "display_url" : "pic.twitter.com\/ZSs12YZKnO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/UnlovableT\/status\/612286092029657089\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZSs12YZKnO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH9G9IEWIAAizM1.jpg",
        "id_str" : "612286090297352192",
        "id" : 612286090297352192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH9G9IEWIAAizM1.jpg",
        "sizes" : [ {
          "h" : 1127,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 1127,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1118,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZSs12YZKnO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/0ifd1gNgKm",
        "expanded_url" : "http:\/\/www.boredpanda.com\/unusual-bird-nests\/?utm_content=bufferd5647&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
        "display_url" : "boredpanda.com\/unusual-bird-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612286092029657089",
    "text" : "Everywhere is a potential nest for our bird families, heres some of the most ingenuitive ones. http:\/\/t.co\/0ifd1gNgKm http:\/\/t.co\/ZSs12YZKnO",
    "id" : 612286092029657089,
    "created_at" : "2015-06-20 15:49:14 +0000",
    "user" : {
      "name" : "Ickle Misty",
      "screen_name" : "UnlovableT",
      "protected" : false,
      "id_str" : "744005468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799076744519094272\/HJ9kC4Y1_normal.jpg",
      "id" : 744005468,
      "verified" : false
    }
  },
  "id" : 629092366599589888,
  "created_at" : "2015-08-06 00:51:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629035392272994304",
  "geo" : { },
  "id_str" : "629041660777922560",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley love the color, love the stitching! nice!!",
  "id" : 629041660777922560,
  "in_reply_to_status_id" : 629035392272994304,
  "created_at" : "2015-08-05 21:29:53 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628958840059379712",
  "geo" : { },
  "id_str" : "629008136221892609",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe how awful : ( glad your still with us.",
  "id" : 629008136221892609,
  "in_reply_to_status_id" : 628958840059379712,
  "created_at" : "2015-08-05 19:16:40 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeWantDebate",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/vZdEjGRCVk",
      "expanded_url" : "http:\/\/voteforbernie.org\/debate\/",
      "display_url" : "voteforbernie.org\/debate\/"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/cntwLIyGz7",
      "expanded_url" : "http:\/\/thndr.it\/1NwRj7h",
      "display_url" : "thndr.it\/1NwRj7h"
    } ]
  },
  "geo" : { },
  "id_str" : "629004368327651328",
  "text" : "#WeWantDebate because the DNC shouldn't be able to decide our candidate for us! Join us @ http:\/\/t.co\/vZdEjGRCVk http:\/\/t.co\/cntwLIyGz7",
  "id" : 629004368327651328,
  "created_at" : "2015-08-05 19:01:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "creative",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629000989039820800",
  "text" : "im so stinkin pleased w myself over DD medical spreadsheets I created..lol. 1 is for med visits, 1 for labs, 1 for all meds. #creative",
  "id" : 629000989039820800,
  "created_at" : "2015-08-05 18:48:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote For Bernie",
      "screen_name" : "vote_for_bernie",
      "indices" : [ 84, 100 ],
      "id_str" : "3312879640",
      "id" : 3312879640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeWantDebate",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/vZdEjGRCVk",
      "expanded_url" : "http:\/\/voteforbernie.org\/debate\/",
      "display_url" : "voteforbernie.org\/debate\/"
    } ]
  },
  "geo" : { },
  "id_str" : "628987859198976001",
  "text" : "Tell the DNC We Want More Debates in 2016! #WeWantDebate http:\/\/t.co\/vZdEjGRCVk via @vote_for_bernie",
  "id" : 628987859198976001,
  "created_at" : "2015-08-05 17:56:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Democrats",
      "screen_name" : "TheDemocrats",
      "indices" : [ 74, 87 ],
      "id_str" : "14377605",
      "id" : 14377605
    }, {
      "name" : "D Wasserman Schultz",
      "screen_name" : "DWStweets",
      "indices" : [ 88, 98 ],
      "id_str" : "115979444",
      "id" : 115979444
    }, {
      "name" : "Tulsi Gabbard",
      "screen_name" : "TulsiGabbard",
      "indices" : [ 99, 112 ],
      "id_str" : "26637348",
      "id" : 26637348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeWantDebate",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/f8xTGSin1F",
      "expanded_url" : "http:\/\/voteforbernie.org\/debate",
      "display_url" : "voteforbernie.org\/debate"
    } ]
  },
  "geo" : { },
  "id_str" : "628987734091276289",
  "text" : "#WeWantDebate because 6 is not enough! In the 2008 primary there were 26! @TheDemocrats @DWStweets @TulsiGabbard http:\/\/t.co\/f8xTGSin1F",
  "id" : 628987734091276289,
  "created_at" : "2015-08-05 17:55:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronen\u25BC.gif",
      "screen_name" : "RonenV",
      "indices" : [ 3, 10 ],
      "id_str" : "1206581",
      "id" : 1206581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628920616800899072",
  "text" : "RT @RonenV: Best way I've found to explain poverty to those who've never experienced it: Imagine if your phone battery only went up to 6%.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626427685070368768",
    "text" : "Best way I've found to explain poverty to those who've never experienced it: Imagine if your phone battery only went up to 6%.",
    "id" : 626427685070368768,
    "created_at" : "2015-07-29 16:22:53 +0000",
    "user" : {
      "name" : "Ronen\u25BC.gif",
      "screen_name" : "RonenV",
      "protected" : false,
      "id_str" : "1206581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668978046142169088\/7lnFMhMj_normal.jpg",
      "id" : 1206581,
      "verified" : false
    }
  },
  "id" : 628920616800899072,
  "created_at" : "2015-08-05 13:28:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Paul Crockett",
      "screen_name" : "RevCrockett",
      "indices" : [ 3, 15 ],
      "id_str" : "3267596508",
      "id" : 3267596508
    }, {
      "name" : "The Bible",
      "screen_name" : "NIVBible",
      "indices" : [ 17, 26 ],
      "id_str" : "197532709",
      "id" : 197532709
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Greek",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628919057996218368",
  "text" : "RT @RevCrockett: @NIVBible The oldest, most reliable manuscripts use the #Greek word Malakoi which meant \"soft.\" You have translated that t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Bible",
        "screen_name" : "NIVBible",
        "indices" : [ 0, 9 ],
        "id_str" : "197532709",
        "id" : 197532709
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Greek",
        "indices" : [ 56, 62 ]
      }, {
        "text" : "gay",
        "indices" : [ 129, 133 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "627582547115900928",
    "geo" : { },
    "id_str" : "627584248829079552",
    "in_reply_to_user_id" : 197532709,
    "text" : "@NIVBible The oldest, most reliable manuscripts use the #Greek word Malakoi which meant \"soft.\" You have translated that to mean #gay. No.",
    "id" : 627584248829079552,
    "in_reply_to_status_id" : 627582547115900928,
    "created_at" : "2015-08-01 20:58:39 +0000",
    "in_reply_to_screen_name" : "NIVBible",
    "in_reply_to_user_id_str" : "197532709",
    "user" : {
      "name" : "Rev. Paul Crockett",
      "screen_name" : "RevCrockett",
      "protected" : false,
      "id_str" : "3267596508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623015549610655744\/0oaUfcbA_normal.jpg",
      "id" : 3267596508,
      "verified" : false
    }
  },
  "id" : 628919057996218368,
  "created_at" : "2015-08-05 13:22:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Paul Crockett",
      "screen_name" : "RevCrockett",
      "indices" : [ 3, 15 ],
      "id_str" : "3267596508",
      "id" : 3267596508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NIV",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "Bible",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628918965960617985",
  "text" : "RT @RevCrockett: Today I want to explain more about the mistranslations\/revisioning of many verses in the #NIV #Bible READ:https:\/\/t.co\/wnf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NIV",
        "indices" : [ 89, 93 ]
      }, {
        "text" : "Bible",
        "indices" : [ 94, 100 ]
      }, {
        "text" : "Christian",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/wnfEUBCnYS",
        "expanded_url" : "https:\/\/goo.gl\/iTbUHL",
        "display_url" : "goo.gl\/iTbUHL"
      } ]
    },
    "geo" : { },
    "id_str" : "627905040418779137",
    "text" : "Today I want to explain more about the mistranslations\/revisioning of many verses in the #NIV #Bible READ:https:\/\/t.co\/wnfEUBCnYS #Christian",
    "id" : 627905040418779137,
    "created_at" : "2015-08-02 18:13:22 +0000",
    "user" : {
      "name" : "Rev. Paul Crockett",
      "screen_name" : "RevCrockett",
      "protected" : false,
      "id_str" : "3267596508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623015549610655744\/0oaUfcbA_normal.jpg",
      "id" : 3267596508,
      "verified" : false
    }
  },
  "id" : 628918965960617985,
  "created_at" : "2015-08-05 13:22:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Richards",
      "screen_name" : "outpostings",
      "indices" : [ 3, 15 ],
      "id_str" : "39331950",
      "id" : 39331950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ic0LXkME0T",
      "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/628727755794821120",
      "display_url" : "twitter.com\/existentialcom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628918073609842688",
  "text" : "RT @outpostings: Fun. https:\/\/t.co\/ic0LXkME0T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 28 ],
        "url" : "https:\/\/t.co\/ic0LXkME0T",
        "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/628727755794821120",
        "display_url" : "twitter.com\/existentialcom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628903518649253889",
    "text" : "Fun. https:\/\/t.co\/ic0LXkME0T",
    "id" : 628903518649253889,
    "created_at" : "2015-08-05 12:20:57 +0000",
    "user" : {
      "name" : "Greg Richards",
      "screen_name" : "outpostings",
      "protected" : false,
      "id_str" : "39331950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000125631333\/bc0def7af6ef16f27ac10ce1ac7c6f16_normal.jpeg",
      "id" : 39331950,
      "verified" : false
    }
  },
  "id" : 628918073609842688,
  "created_at" : "2015-08-05 13:18:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Autism Care",
      "screen_name" : "autismcareuk",
      "indices" : [ 3, 16 ],
      "id_str" : "454430821",
      "id" : 454430821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628744752750559233",
  "text" : "RT @autismcareuk: \"INCLUDE me, but on my terms. Please don't pressure me to 'participate' when I choose to just observe\"  Sam - a person we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "autism",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628166542518288384",
    "text" : "\"INCLUDE me, but on my terms. Please don't pressure me to 'participate' when I choose to just observe\"  Sam - a person we support.  #autism",
    "id" : 628166542518288384,
    "created_at" : "2015-08-03 11:32:29 +0000",
    "user" : {
      "name" : "Autism Care",
      "screen_name" : "autismcareuk",
      "protected" : false,
      "id_str" : "454430821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793489111164354560\/Frul7qG0_normal.jpg",
      "id" : 454430821,
      "verified" : false
    }
  },
  "id" : 628744752750559233,
  "created_at" : "2015-08-05 01:50:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmett Initiative",
      "screen_name" : "EmmettPlant",
      "indices" : [ 3, 15 ],
      "id_str" : "8477122",
      "id" : 8477122
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EmmettPlant\/status\/628649469714677760\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Z7CgaTRb38",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlpWw2UYAAwahY.jpg",
      "id_str" : "628649462785662976",
      "id" : 628649462785662976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlpWw2UYAAwahY.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z7CgaTRb38"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EmmettPlant\/status\/628649469714677760\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Z7CgaTRb38",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlpWw7UkAABsJo.jpg",
      "id_str" : "628649462806646784",
      "id" : 628649462806646784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlpWw7UkAABsJo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z7CgaTRb38"
    } ],
    "hashtags" : [ {
      "text" : "recovery",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628723808942342144",
  "text" : "RT @EmmettPlant: They say that cats don't give a damn. They're wrong. #recovery http:\/\/t.co\/Z7CgaTRb38",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EmmettPlant\/status\/628649469714677760\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Z7CgaTRb38",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlpWw2UYAAwahY.jpg",
        "id_str" : "628649462785662976",
        "id" : 628649462785662976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlpWw2UYAAwahY.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Z7CgaTRb38"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/EmmettPlant\/status\/628649469714677760\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Z7CgaTRb38",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlpWw7UkAABsJo.jpg",
        "id_str" : "628649462806646784",
        "id" : 628649462806646784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlpWw7UkAABsJo.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Z7CgaTRb38"
      } ],
      "hashtags" : [ {
        "text" : "recovery",
        "indices" : [ 53, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628649469714677760",
    "text" : "They say that cats don't give a damn. They're wrong. #recovery http:\/\/t.co\/Z7CgaTRb38",
    "id" : 628649469714677760,
    "created_at" : "2015-08-04 19:31:27 +0000",
    "user" : {
      "name" : "Emmett Initiative",
      "screen_name" : "EmmettPlant",
      "protected" : false,
      "id_str" : "8477122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773720943386439680\/W_eF18DY_normal.jpg",
      "id" : 8477122,
      "verified" : false
    }
  },
  "id" : 628723808942342144,
  "created_at" : "2015-08-05 00:26:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Anthony James",
      "screen_name" : "JohnJamesOZ",
      "indices" : [ 3, 15 ],
      "id_str" : "766412689",
      "id" : 766412689
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JohnJamesOZ\/status\/628687400613605376\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bwyonbQqQk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmL3A1WwAA95PT.png",
      "id_str" : "628687400227749888",
      "id" : 628687400227749888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmL3A1WwAA95PT.png",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 706
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 870,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 706
      } ],
      "display_url" : "pic.twitter.com\/bwyonbQqQk"
    } ],
    "hashtags" : [ {
      "text" : "eyecandy",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "sharebeautynothate",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/hCxJm4o5qp",
      "expanded_url" : "http:\/\/jajoz.me\/1DrAZVi",
      "display_url" : "jajoz.me\/1DrAZVi"
    } ]
  },
  "geo" : { },
  "id_str" : "628709400908275712",
  "text" : "RT @JohnJamesOZ: Eye-Candy: Found at wonderingaesthetic \u2014 http:\/\/t.co\/hCxJm4o5qp \u2014 #eyecandy \u2014 #sharebeautynothate \u2014 http:\/\/t.co\/bwyonbQqQk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnJamesOZ\/status\/628687400613605376\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/bwyonbQqQk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmL3A1WwAA95PT.png",
        "id_str" : "628687400227749888",
        "id" : 628687400227749888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmL3A1WwAA95PT.png",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 706
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 870,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 706
        } ],
        "display_url" : "pic.twitter.com\/bwyonbQqQk"
      } ],
      "hashtags" : [ {
        "text" : "eyecandy",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "sharebeautynothate",
        "indices" : [ 78, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/hCxJm4o5qp",
        "expanded_url" : "http:\/\/jajoz.me\/1DrAZVi",
        "display_url" : "jajoz.me\/1DrAZVi"
      } ]
    },
    "geo" : { },
    "id_str" : "628687400613605376",
    "text" : "Eye-Candy: Found at wonderingaesthetic \u2014 http:\/\/t.co\/hCxJm4o5qp \u2014 #eyecandy \u2014 #sharebeautynothate \u2014 http:\/\/t.co\/bwyonbQqQk",
    "id" : 628687400613605376,
    "created_at" : "2015-08-04 22:02:11 +0000",
    "user" : {
      "name" : "John Anthony James",
      "screen_name" : "JohnJamesOZ",
      "protected" : false,
      "id_str" : "766412689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747288520482426880\/K2ZUl0Np_normal.jpg",
      "id" : 766412689,
      "verified" : false
    }
  },
  "id" : 628709400908275712,
  "created_at" : "2015-08-04 23:29:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "austin",
      "screen_name" : "kvxll",
      "indices" : [ 3, 9 ],
      "id_str" : "2701453016",
      "id" : 2701453016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628707901444632576",
  "text" : "RT @kvxll: Dear straight people: no one is saying your life can't be hard if you're straight but it's not hard because you're straight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628633990472331264",
    "geo" : { },
    "id_str" : "628634322002690050",
    "in_reply_to_user_id" : 2701453016,
    "text" : "Dear straight people: no one is saying your life can't be hard if you're straight but it's not hard because you're straight",
    "id" : 628634322002690050,
    "in_reply_to_status_id" : 628633990472331264,
    "created_at" : "2015-08-04 18:31:16 +0000",
    "in_reply_to_screen_name" : "kvxll",
    "in_reply_to_user_id_str" : "2701453016",
    "user" : {
      "name" : "austin",
      "screen_name" : "kvxll",
      "protected" : false,
      "id_str" : "2701453016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688038367729160198\/fm4BmSSU_normal.jpg",
      "id" : 2701453016,
      "verified" : false
    }
  },
  "id" : 628707901444632576,
  "created_at" : "2015-08-04 23:23:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628687426291109888",
  "geo" : { },
  "id_str" : "628707558958723072",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe yeah.. pretty much this is what I get from DD.. lol",
  "id" : 628707558958723072,
  "in_reply_to_status_id" : 628687426291109888,
  "created_at" : "2015-08-04 23:22:17 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/lyhqiRHIlm",
      "expanded_url" : "http:\/\/goo.gl\/4fLf4Z",
      "display_url" : "goo.gl\/4fLf4Z"
    } ]
  },
  "geo" : { },
  "id_str" : "628645913901314049",
  "text" : "RT @dailygalaxy: Colossal Ring of Galaxies --\"Largest Object in the Universe Spans 5 Billion Light Years!\" http:\/\/t.co\/lyhqiRHIlm http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/628643101767151616\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/LBdWoAdOnc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLljkdgUkAAtU8Y.jpg",
        "id_str" : "628643101041528832",
        "id" : 628643101041528832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLljkdgUkAAtU8Y.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LBdWoAdOnc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/lyhqiRHIlm",
        "expanded_url" : "http:\/\/goo.gl\/4fLf4Z",
        "display_url" : "goo.gl\/4fLf4Z"
      } ]
    },
    "geo" : { },
    "id_str" : "628643101767151616",
    "text" : "Colossal Ring of Galaxies --\"Largest Object in the Universe Spans 5 Billion Light Years!\" http:\/\/t.co\/lyhqiRHIlm http:\/\/t.co\/LBdWoAdOnc",
    "id" : 628643101767151616,
    "created_at" : "2015-08-04 19:06:09 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 628645913901314049,
  "created_at" : "2015-08-04 19:17:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628615035229765632",
  "text" : "RT @Angelapaints: I try to share info, like when someone tells you eating carcinogens is \"safe\" or injecting them into folks, say Whoa!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628600375583490048",
    "geo" : { },
    "id_str" : "628609774796443648",
    "in_reply_to_user_id" : 592182458,
    "text" : "I try to share info, like when someone tells you eating carcinogens is \"safe\" or injecting them into folks, say Whoa!",
    "id" : 628609774796443648,
    "in_reply_to_status_id" : 628600375583490048,
    "created_at" : "2015-08-04 16:53:43 +0000",
    "in_reply_to_screen_name" : "Angelapaints",
    "in_reply_to_user_id_str" : "592182458",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 628615035229765632,
  "created_at" : "2015-08-04 17:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "glysphosate",
      "indices" : [ 18, 30 ]
    }, {
      "text" : "GMO",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "idontthinkso",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628614574468677632",
  "text" : "RT @Angelapaints: #glysphosate and #GMO w\/built in pesticides are safe to eat? #idontthinkso quit hiding them in my food please.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "glysphosate",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "GMO",
        "indices" : [ 17, 21 ]
      }, {
        "text" : "idontthinkso",
        "indices" : [ 61, 74 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628611167812882432",
    "geo" : { },
    "id_str" : "628612786554171392",
    "in_reply_to_user_id" : 592182458,
    "text" : "#glysphosate and #GMO w\/built in pesticides are safe to eat? #idontthinkso quit hiding them in my food please.",
    "id" : 628612786554171392,
    "in_reply_to_status_id" : 628611167812882432,
    "created_at" : "2015-08-04 17:05:42 +0000",
    "in_reply_to_screen_name" : "Angelapaints",
    "in_reply_to_user_id_str" : "592182458",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 628614574468677632,
  "created_at" : "2015-08-04 17:12:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cute",
      "indices" : [ 0, 5 ]
    }, {
      "text" : "sheep",
      "indices" : [ 6, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/bS3S6Hyrjw",
      "expanded_url" : "http:\/\/sheep.littlethings.com\/?utm_source=LTcom&utm_campaign=animals&utm_medium=Twitter&p=771241",
      "display_url" : "sheep.littlethings.com\/?utm_source=LT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628613782210768898",
  "text" : "#cute #sheep These 2 Dogs Have A Job To Do... http:\/\/t.co\/bS3S6Hyrjw",
  "id" : 628613782210768898,
  "created_at" : "2015-08-04 17:09:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Green",
      "screen_name" : "FixedOpsGenius",
      "indices" : [ 3, 18 ],
      "id_str" : "65577676",
      "id" : 65577676
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FixedOpsGenius\/status\/628582415577919488\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/KsHx6oWRmn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLksYA9UcAAhGX6.jpg",
      "id_str" : "628582414080569344",
      "id" : 628582414080569344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLksYA9UcAAhGX6.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KsHx6oWRmn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/zPY0XFb7dJ",
      "expanded_url" : "https:\/\/plus.google.com\/+KevinGreenFixedOpsGenius\/posts\/J5ePeemJYdn",
      "display_url" : "plus.google.com\/+KevinGreenFix\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628608297516572672",
  "text" : "RT @FixedOpsGenius: How To Be A Cat (23 pics) https:\/\/t.co\/zPY0XFb7dJ http:\/\/t.co\/KsHx6oWRmn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FixedOpsGenius\/status\/628582415577919488\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/KsHx6oWRmn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLksYA9UcAAhGX6.jpg",
        "id_str" : "628582414080569344",
        "id" : 628582414080569344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLksYA9UcAAhGX6.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KsHx6oWRmn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/zPY0XFb7dJ",
        "expanded_url" : "https:\/\/plus.google.com\/+KevinGreenFixedOpsGenius\/posts\/J5ePeemJYdn",
        "display_url" : "plus.google.com\/+KevinGreenFix\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628582415577919488",
    "text" : "How To Be A Cat (23 pics) https:\/\/t.co\/zPY0XFb7dJ http:\/\/t.co\/KsHx6oWRmn",
    "id" : 628582415577919488,
    "created_at" : "2015-08-04 15:05:01 +0000",
    "user" : {
      "name" : "Kevin Green",
      "screen_name" : "FixedOpsGenius",
      "protected" : false,
      "id_str" : "65577676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2525490879\/7o1wshs85s2v4mr7so9l_normal.jpeg",
      "id" : 65577676,
      "verified" : false
    }
  },
  "id" : 628608297516572672,
  "created_at" : "2015-08-04 16:47:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "News from Science",
      "screen_name" : "NewsfromScience",
      "indices" : [ 3, 19 ],
      "id_str" : "17089636",
      "id" : 17089636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NewsfromScience\/status\/626463439683198976\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/wQDyPFBAHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLGlLb8WoAA7NSv.png",
      "id_str" : "626463439079251968",
      "id" : 626463439079251968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLGlLb8WoAA7NSv.png",
      "sizes" : [ {
        "h" : 580,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wQDyPFBAHh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/limhjuGOv1",
      "expanded_url" : "http:\/\/news.sciencemag.org\/space\/2015\/07\/first-northern-lights-seen-outside-solar-system?utm_source=twitter&utm_medium=social&utm_campaign=twitter",
      "display_url" : "news.sciencemag.org\/space\/2015\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628607100218961923",
  "text" : "RT @NewsfromScience: First 'northern lights' seen outside the solar system http:\/\/t.co\/limhjuGOv1 http:\/\/t.co\/wQDyPFBAHh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NewsfromScience\/status\/626463439683198976\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/wQDyPFBAHh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLGlLb8WoAA7NSv.png",
        "id_str" : "626463439079251968",
        "id" : 626463439079251968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLGlLb8WoAA7NSv.png",
        "sizes" : [ {
          "h" : 580,
          "resize" : "fit",
          "w" : 997
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 997
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wQDyPFBAHh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/limhjuGOv1",
        "expanded_url" : "http:\/\/news.sciencemag.org\/space\/2015\/07\/first-northern-lights-seen-outside-solar-system?utm_source=twitter&utm_medium=social&utm_campaign=twitter",
        "display_url" : "news.sciencemag.org\/space\/2015\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626463439683198976",
    "text" : "First 'northern lights' seen outside the solar system http:\/\/t.co\/limhjuGOv1 http:\/\/t.co\/wQDyPFBAHh",
    "id" : 626463439683198976,
    "created_at" : "2015-07-29 18:44:57 +0000",
    "user" : {
      "name" : "News from Science",
      "screen_name" : "NewsfromScience",
      "protected" : false,
      "id_str" : "17089636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476715165165973505\/3X-SFfi5_normal.jpeg",
      "id" : 17089636,
      "verified" : true
    }
  },
  "id" : 628607100218961923,
  "created_at" : "2015-08-04 16:43:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatismorality",
      "indices" : [ 35, 50 ]
    }, {
      "text" : "whatisgood",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "whatisevil",
      "indices" : [ 63, 74 ]
    }, {
      "text" : "shadesofgrey",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628606371680919552",
  "text" : "Morality is absolutely subjective. #whatismorality #whatisgood #whatisevil #shadesofgrey",
  "id" : 628606371680919552,
  "created_at" : "2015-08-04 16:40:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stoner Nation\u2122\uD83D\uDD25\uD83D\uDCA8",
      "screen_name" : "ThaStonerNation",
      "indices" : [ 3, 19 ],
      "id_str" : "627436907",
      "id" : 627436907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628604810846150656",
  "text" : "RT @ThaStonerNation: I just kinda laugh a little every time I hear someone say weed is a gateway drug..\n\nLike wtf do they think alcohol is?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628602871924154368",
    "text" : "I just kinda laugh a little every time I hear someone say weed is a gateway drug..\n\nLike wtf do they think alcohol is?",
    "id" : 628602871924154368,
    "created_at" : "2015-08-04 16:26:18 +0000",
    "user" : {
      "name" : "Stoner Nation\u2122\uD83D\uDD25\uD83D\uDCA8",
      "screen_name" : "ThaStonerNation",
      "protected" : false,
      "id_str" : "627436907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702241212170764288\/DcfH_rE7_normal.jpg",
      "id" : 627436907,
      "verified" : false
    }
  },
  "id" : 628604810846150656,
  "created_at" : "2015-08-04 16:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 3, 17 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628594789345312768",
  "text" : "RT @UnfundieXians: \u201CThe purpose in life is not to win. The purpose in life is to grow and to share. \"When you come to look back on... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/A2NDNyaWGC",
        "expanded_url" : "http:\/\/fb.me\/6MhNGQHYZ",
        "display_url" : "fb.me\/6MhNGQHYZ"
      } ]
    },
    "geo" : { },
    "id_str" : "628017758769287168",
    "text" : "\u201CThe purpose in life is not to win. The purpose in life is to grow and to share. \"When you come to look back on... http:\/\/t.co\/A2NDNyaWGC",
    "id" : 628017758769287168,
    "created_at" : "2015-08-03 01:41:16 +0000",
    "user" : {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "protected" : false,
      "id_str" : "780850862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000612253854\/d369ca7c4cc3d27a5fe05ca11521b685_normal.jpeg",
      "id" : 780850862,
      "verified" : false
    }
  },
  "id" : 628594789345312768,
  "created_at" : "2015-08-04 15:54:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/LMloj2JRMH",
      "expanded_url" : "https:\/\/twitter.com\/UnfundieXians\/status\/628215595708903424",
      "display_url" : "twitter.com\/UnfundieXians\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628594682650603520",
  "text" : "\"So the question is, \u201CWhy can\u2019t I see it?\u201D or even better, \u201CWhat will it take for my eyes to be opened?\u201D\" https:\/\/t.co\/LMloj2JRMH",
  "id" : 628594682650603520,
  "created_at" : "2015-08-04 15:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/o690xdANI9",
      "expanded_url" : "https:\/\/twitter.com\/BruceGerencser\/status\/628324821462568961",
      "display_url" : "twitter.com\/BruceGerencser\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628592155926339584",
  "text" : "\"In any other context we would consider such behavior predatory and harmful.\" https:\/\/t.co\/o690xdANI9",
  "id" : 628592155926339584,
  "created_at" : "2015-08-04 15:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/c2pJkumHUW",
      "expanded_url" : "http:\/\/bookwi.se\/between-the-world-and-me-by-ta-nehisi-coates\/",
      "display_url" : "bookwi.se\/between-the-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628584680833552384",
  "text" : "RT @adamrshields: Book Review: Between the World and Me by Ta-Nehisi Coates - a book that deserves its hype,\u2026 http:\/\/t.co\/c2pJkumHUW http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/adamrshields\/status\/628544073293537280\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/8Zf0j1oVzn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLkJgMnUsAAWlK6.png",
        "id_str" : "628544071741517824",
        "id" : 628544071741517824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLkJgMnUsAAWlK6.png",
        "sizes" : [ {
          "h" : 499,
          "resize" : "fit",
          "w" : 329
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 329
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 329
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 329
        } ],
        "display_url" : "pic.twitter.com\/8Zf0j1oVzn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/c2pJkumHUW",
        "expanded_url" : "http:\/\/bookwi.se\/between-the-world-and-me-by-ta-nehisi-coates\/",
        "display_url" : "bookwi.se\/between-the-wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628544073293537280",
    "text" : "Book Review: Between the World and Me by Ta-Nehisi Coates - a book that deserves its hype,\u2026 http:\/\/t.co\/c2pJkumHUW http:\/\/t.co\/8Zf0j1oVzn",
    "id" : 628544073293537280,
    "created_at" : "2015-08-04 12:32:39 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 628584680833552384,
  "created_at" : "2015-08-04 15:14:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628582795946905601",
  "text" : "RT @UnseelieMe: Theyre not misbehaving. Theyre having a neurological breakdown. Handcuffing them? Locking them down? Yelling at them? Does.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628573177149530113",
    "text" : "Theyre not misbehaving. Theyre having a neurological breakdown. Handcuffing them? Locking them down? Yelling at them? Does. Not. Help.",
    "id" : 628573177149530113,
    "created_at" : "2015-08-04 14:28:18 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 628582795946905601,
  "created_at" : "2015-08-04 15:06:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628582747733401600",
  "text" : "RT @UnseelieMe: When a kid w\/a disability is having a meltdown, the absolute worst thing an adult can do is escalate the situation w\/a thre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628572889277669377",
    "text" : "When a kid w\/a disability is having a meltdown, the absolute worst thing an adult can do is escalate the situation w\/a threatening response.",
    "id" : 628572889277669377,
    "created_at" : "2015-08-04 14:27:09 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 628582747733401600,
  "created_at" : "2015-08-04 15:06:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Stevenson",
      "screen_name" : "tourscotland",
      "indices" : [ 3, 16 ],
      "id_str" : "15842676",
      "id" : 15842676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628388556080324608",
  "text" : "RT @tourscotland: As requested, Tour Scotland photograph of Highland Cows by Duart Castle on ancestry visit to Isle of Mull http:\/\/t.co\/goT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tourscotland\/status\/628345882069569536\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/goT5PZUKwa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhVP9fXAAAcE36.jpg",
        "id_str" : "628345880710676480",
        "id" : 628345880710676480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhVP9fXAAAcE36.jpg",
        "sizes" : [ {
          "h" : 437,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 765
        } ],
        "display_url" : "pic.twitter.com\/goT5PZUKwa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628345882069569536",
    "text" : "As requested, Tour Scotland photograph of Highland Cows by Duart Castle on ancestry visit to Isle of Mull http:\/\/t.co\/goT5PZUKwa",
    "id" : 628345882069569536,
    "created_at" : "2015-08-03 23:25:07 +0000",
    "user" : {
      "name" : "Sandy Stevenson",
      "screen_name" : "tourscotland",
      "protected" : false,
      "id_str" : "15842676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70101487\/Sandy_Stevenson_normal.jpg",
      "id" : 15842676,
      "verified" : false
    }
  },
  "id" : 628388556080324608,
  "created_at" : "2015-08-04 02:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Hughes",
      "screen_name" : "DurhamFarmer",
      "indices" : [ 3, 16 ],
      "id_str" : "2726316501",
      "id" : 2726316501
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DurhamFarmer\/status\/628134369115439104\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/XD2Q1YqGhJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLeU3rtWsAAP5MJ.jpg",
      "id_str" : "628134357388144640",
      "id" : 628134357388144640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLeU3rtWsAAP5MJ.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XD2Q1YqGhJ"
    } ],
    "hashtags" : [ {
      "text" : "lovefarming",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628387044549611520",
  "text" : "RT @DurhamFarmer: Tongues everywhere #lovefarming http:\/\/t.co\/XD2Q1YqGhJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DurhamFarmer\/status\/628134369115439104\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/XD2Q1YqGhJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLeU3rtWsAAP5MJ.jpg",
        "id_str" : "628134357388144640",
        "id" : 628134357388144640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLeU3rtWsAAP5MJ.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XD2Q1YqGhJ"
      } ],
      "hashtags" : [ {
        "text" : "lovefarming",
        "indices" : [ 19, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628134369115439104",
    "text" : "Tongues everywhere #lovefarming http:\/\/t.co\/XD2Q1YqGhJ",
    "id" : 628134369115439104,
    "created_at" : "2015-08-03 09:24:38 +0000",
    "user" : {
      "name" : "Al Hughes",
      "screen_name" : "DurhamFarmer",
      "protected" : false,
      "id_str" : "2726316501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761266853209575424\/Fp2QFAsL_normal.jpg",
      "id" : 2726316501,
      "verified" : false
    }
  },
  "id" : 628387044549611520,
  "created_at" : "2015-08-04 02:08:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628386678072324096",
  "text" : "RT @sarahnmoon: \"18. How would you define marriage?\"\n\nthe state of being married? ??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628382346492911616",
    "text" : "\"18. How would you define marriage?\"\n\nthe state of being married? ??",
    "id" : 628382346492911616,
    "created_at" : "2015-08-04 01:50:00 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 628386678072324096,
  "created_at" : "2015-08-04 02:07:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wakefield Express",
      "screen_name" : "WakeExpress",
      "indices" : [ 3, 15 ],
      "id_str" : "388871127",
      "id" : 388871127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WakeExpress\/status\/627075734843035649\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/QaVWJwHsnr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLPSDsGWoAEOBis.jpg",
      "id_str" : "627075733953880065",
      "id" : 627075733953880065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLPSDsGWoAEOBis.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/QaVWJwHsnr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2vyfsDictR",
      "expanded_url" : "http:\/\/www.wakefieldexpress.co.uk\/news\/local-news\/inspirational-teenager-opens-donkey-sanctuary-1-7387090",
      "display_url" : "wakefieldexpress.co.uk\/news\/local-new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628375320886964224",
  "text" : "RT @WakeExpress: Inspirational teenager opens donkey sanctuary -\nhttp:\/\/t.co\/2vyfsDictR http:\/\/t.co\/QaVWJwHsnr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WakeExpress\/status\/627075734843035649\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/QaVWJwHsnr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLPSDsGWoAEOBis.jpg",
        "id_str" : "627075733953880065",
        "id" : 627075733953880065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLPSDsGWoAEOBis.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/QaVWJwHsnr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/2vyfsDictR",
        "expanded_url" : "http:\/\/www.wakefieldexpress.co.uk\/news\/local-news\/inspirational-teenager-opens-donkey-sanctuary-1-7387090",
        "display_url" : "wakefieldexpress.co.uk\/news\/local-new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627075734843035649",
    "text" : "Inspirational teenager opens donkey sanctuary -\nhttp:\/\/t.co\/2vyfsDictR http:\/\/t.co\/QaVWJwHsnr",
    "id" : 627075734843035649,
    "created_at" : "2015-07-31 11:18:00 +0000",
    "user" : {
      "name" : "Wakefield Express",
      "screen_name" : "WakeExpress",
      "protected" : false,
      "id_str" : "388871127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1583250872\/WBW_normal.jpg",
      "id" : 388871127,
      "verified" : true
    }
  },
  "id" : 628375320886964224,
  "created_at" : "2015-08-04 01:22:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/PBs5jE7zfo",
      "expanded_url" : "https:\/\/twitter.com\/FreeRangeKids\/status\/628363389115473920",
      "display_url" : "twitter.com\/FreeRangeKids\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628366828977410048",
  "text" : "WTF??  https:\/\/t.co\/PBs5jE7zfo",
  "id" : 628366828977410048,
  "created_at" : "2015-08-04 00:48:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Malo",
      "screen_name" : "danmalo",
      "indices" : [ 0, 8 ],
      "id_str" : "98214614",
      "id" : 98214614
    }, {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 19, 31 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lyme",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628291513252978688",
  "geo" : { },
  "id_str" : "628355764852236288",
  "in_reply_to_user_id" : 98214614,
  "text" : "@danmalo check out @AlisynGayle timeline for good #lyme info \/ links.",
  "id" : 628355764852236288,
  "in_reply_to_status_id" : 628291513252978688,
  "created_at" : "2015-08-04 00:04:23 +0000",
  "in_reply_to_screen_name" : "danmalo",
  "in_reply_to_user_id_str" : "98214614",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/628329845387325441\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/nQEslE9eaQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhGqf2W8AAGdoz.jpg",
      "id_str" : "628329843936129024",
      "id" : 628329843936129024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhGqf2W8AAGdoz.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/nQEslE9eaQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628331628717322240",
  "text" : "RT @CUMALi_YILDIZ: Light \nby Ole Henrik Skjelstad http:\/\/t.co\/nQEslE9eaQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/628329845387325441\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/nQEslE9eaQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhGqf2W8AAGdoz.jpg",
        "id_str" : "628329843936129024",
        "id" : 628329843936129024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhGqf2W8AAGdoz.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/nQEslE9eaQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628329845387325441",
    "text" : "Light \nby Ole Henrik Skjelstad http:\/\/t.co\/nQEslE9eaQ",
    "id" : 628329845387325441,
    "created_at" : "2015-08-03 22:21:23 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 628331628717322240,
  "created_at" : "2015-08-03 22:28:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628276604964212737",
  "geo" : { },
  "id_str" : "628324778294775808",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time never mind.. found it! Fox News is hosting it.",
  "id" : 628324778294775808,
  "in_reply_to_status_id" : 628276604964212737,
  "created_at" : "2015-08-03 22:01:15 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/628323116201181184\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/488tfCIbp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhAiB-WwAArh2y.jpg",
      "id_str" : "628323101407887360",
      "id" : 628323101407887360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhAiB-WwAArh2y.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/488tfCIbp5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/628323116201181184\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/488tfCIbp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhAiCJWgAA07uy.jpg",
      "id_str" : "628323101454008320",
      "id" : 628323101454008320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhAiCJWgAA07uy.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/488tfCIbp5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/628323116201181184\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/488tfCIbp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhAiEkXAAEVj-s.jpg",
      "id_str" : "628323102104158209",
      "id" : 628323102104158209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhAiEkXAAEVj-s.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/488tfCIbp5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628323912363937792",
  "text" : "RT @ErinEFarley: Did anyone hear me holler \"COW!\" and demand we turn around? http:\/\/t.co\/488tfCIbp5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/628323116201181184\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/488tfCIbp5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhAiB-WwAArh2y.jpg",
        "id_str" : "628323101407887360",
        "id" : 628323101407887360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhAiB-WwAArh2y.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/488tfCIbp5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/628323116201181184\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/488tfCIbp5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhAiCJWgAA07uy.jpg",
        "id_str" : "628323101454008320",
        "id" : 628323101454008320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhAiCJWgAA07uy.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/488tfCIbp5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/628323116201181184\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/488tfCIbp5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhAiEkXAAEVj-s.jpg",
        "id_str" : "628323102104158209",
        "id" : 628323102104158209,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhAiEkXAAEVj-s.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/488tfCIbp5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628323116201181184",
    "text" : "Did anyone hear me holler \"COW!\" and demand we turn around? http:\/\/t.co\/488tfCIbp5",
    "id" : 628323116201181184,
    "created_at" : "2015-08-03 21:54:39 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 628323912363937792,
  "created_at" : "2015-08-03 21:57:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secular Humanist",
      "screen_name" : "Reilly4Sanity",
      "indices" : [ 3, 17 ],
      "id_str" : "184998424",
      "id" : 184998424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628293981349257216",
  "text" : "RT @Reilly4Sanity: Alabama Attempts To Take Custody Of Fetus Away From Woman To Prevent Abortion - odinsblog: addictinginfo:... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/0RSvZUUmdE",
        "expanded_url" : "http:\/\/tmblr.co\/Z6fNKx1r8itGd",
        "display_url" : "tmblr.co\/Z6fNKx1r8itGd"
      } ]
    },
    "geo" : { },
    "id_str" : "628267251444137984",
    "text" : "Alabama Attempts To Take Custody Of Fetus Away From Woman To Prevent Abortion - odinsblog: addictinginfo:... http:\/\/t.co\/0RSvZUUmdE",
    "id" : 628267251444137984,
    "created_at" : "2015-08-03 18:12:40 +0000",
    "user" : {
      "name" : "Secular Humanist",
      "screen_name" : "Reilly4Sanity",
      "protected" : false,
      "id_str" : "184998424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797619970624651268\/GOoWyuzC_normal.jpg",
      "id" : 184998424,
      "verified" : false
    }
  },
  "id" : 628293981349257216,
  "created_at" : "2015-08-03 19:58:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628276604964212737",
  "geo" : { },
  "id_str" : "628292147645706242",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time debate? ((pencils in thurs night)) do you know channel or station?",
  "id" : 628292147645706242,
  "in_reply_to_status_id" : 628276604964212737,
  "created_at" : "2015-08-03 19:51:35 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "testing",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "lyme",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628186893981745153",
  "geo" : { },
  "id_str" : "628287456526340096",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle interesting &gt;&gt; \"make sure to ask how up-to-date the office\u2019s #testing system is\" #lyme",
  "id" : 628287456526340096,
  "in_reply_to_status_id" : 628186893981745153,
  "created_at" : "2015-08-03 19:32:57 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628266343150809088",
  "text" : "RT @adamrshields: The complete 7 vol Outlander Series by Diana Gabaldon is only $1.99 on Kindle. Probably pricing error. http:\/\/t.co\/Hxk1eP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Hxk1ePpae5",
        "expanded_url" : "http:\/\/amzn.to\/1SCD1ZG",
        "display_url" : "amzn.to\/1SCD1ZG"
      } ]
    },
    "geo" : { },
    "id_str" : "628254686290804737",
    "text" : "The complete 7 vol Outlander Series by Diana Gabaldon is only $1.99 on Kindle. Probably pricing error. http:\/\/t.co\/Hxk1ePpae5",
    "id" : 628254686290804737,
    "created_at" : "2015-08-03 17:22:44 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 628266343150809088,
  "created_at" : "2015-08-03 18:09:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LM8IhIuvKG",
      "expanded_url" : "http:\/\/Amazon.com",
      "display_url" : "Amazon.com"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/G13L2Ptsnk",
      "expanded_url" : "http:\/\/www.libraryextension.com\/",
      "display_url" : "libraryextension.com"
    } ]
  },
  "geo" : { },
  "id_str" : "628250539734609920",
  "text" : "Library Extension for Chrome - See book availability from your local library while you browse http:\/\/t.co\/LM8IhIuvKG http:\/\/t.co\/G13L2Ptsnk",
  "id" : 628250539734609920,
  "created_at" : "2015-08-03 17:06:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt R.",
      "screen_name" : "doesntmattr",
      "indices" : [ 3, 15 ],
      "id_str" : "56762810",
      "id" : 56762810
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/doesntmattr\/status\/627988321533341697\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GPA6sPB8Ds",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLcQDRMWsAAdfvU.jpg",
      "id_str" : "627988321382346752",
      "id" : 627988321382346752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLcQDRMWsAAdfvU.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 841,
        "resize" : "fit",
        "w" : 1121
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GPA6sPB8Ds"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628002883175346177",
  "text" : "RT @doesntmattr: There are currently eleven raccoons outside my parents house. In Queens. This is not the country. http:\/\/t.co\/GPA6sPB8Ds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/doesntmattr\/status\/627988321533341697\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/GPA6sPB8Ds",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLcQDRMWsAAdfvU.jpg",
        "id_str" : "627988321382346752",
        "id" : 627988321382346752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLcQDRMWsAAdfvU.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 841,
          "resize" : "fit",
          "w" : 1121
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GPA6sPB8Ds"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627988321533341697",
    "text" : "There are currently eleven raccoons outside my parents house. In Queens. This is not the country. http:\/\/t.co\/GPA6sPB8Ds",
    "id" : 627988321533341697,
    "created_at" : "2015-08-02 23:44:17 +0000",
    "user" : {
      "name" : "Matt R.",
      "screen_name" : "doesntmattr",
      "protected" : false,
      "id_str" : "56762810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/410793501\/5328_226568265467_554800467_7585530_4537517_n_normal.jpg",
      "id" : 56762810,
      "verified" : false
    }
  },
  "id" : 628002883175346177,
  "created_at" : "2015-08-03 00:42:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523203867417538560\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/uJbpwHHGWh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0LLJSzIAAA1jM0.jpg",
      "id_str" : "523203867253932032",
      "id" : 523203867253932032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0LLJSzIAAA1jM0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/uJbpwHHGWh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627867792730136577",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/uJbpwHHGWh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523203867417538560\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/uJbpwHHGWh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0LLJSzIAAA1jM0.jpg",
        "id_str" : "523203867253932032",
        "id" : 523203867253932032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0LLJSzIAAA1jM0.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/uJbpwHHGWh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627866529263128576",
    "text" : "http:\/\/t.co\/uJbpwHHGWh",
    "id" : 627866529263128576,
    "created_at" : "2015-08-02 15:40:20 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 627867792730136577,
  "created_at" : "2015-08-02 15:45:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627813616146862080",
  "geo" : { },
  "id_str" : "627863383807782912",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre sorry about yr chicken : (",
  "id" : 627863383807782912,
  "in_reply_to_status_id" : 627813616146862080,
  "created_at" : "2015-08-02 15:27:50 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph",
      "screen_name" : "JosephOsaka",
      "indices" : [ 3, 15 ],
      "id_str" : "461725113",
      "id" : 461725113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627686446518915073",
  "text" : "RT @JosephOsaka: It's painfully obvious the entire criminal justice system needs complete revamping.  It's broken and biased. And it makes \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627676290405961728",
    "text" : "It's painfully obvious the entire criminal justice system needs complete revamping.  It's broken and biased. And it makes a few people rich!",
    "id" : 627676290405961728,
    "created_at" : "2015-08-02 03:04:23 +0000",
    "user" : {
      "name" : "Joseph",
      "screen_name" : "JosephOsaka",
      "protected" : false,
      "id_str" : "461725113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1812303687\/image_normal.jpg",
      "id" : 461725113,
      "verified" : false
    }
  },
  "id" : 627686446518915073,
  "created_at" : "2015-08-02 03:44:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wsnK1a9dX3",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2014\/10\/31\/1340649\/-Amazing-NASA-video-makes-earth-look-like-one-big-living-creature",
      "display_url" : "dailykos.com\/story\/2014\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627610706192547840",
  "text" : "RT @SangyeH: NASA video makes earth look like 1 big living creature http:\/\/t.co\/wsnK1a9dX3\n\nFirst time I could perceive this truth. *tears*\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 130, 140 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/wsnK1a9dX3",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2014\/10\/31\/1340649\/-Amazing-NASA-video-makes-earth-look-like-one-big-living-creature",
        "display_url" : "dailykos.com\/story\/2014\/10\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627605524842999808",
    "text" : "NASA video makes earth look like 1 big living creature http:\/\/t.co\/wsnK1a9dX3\n\nFirst time I could perceive this truth. *tears*\n\nc @JALPalyul",
    "id" : 627605524842999808,
    "created_at" : "2015-08-01 22:23:12 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 627610706192547840,
  "created_at" : "2015-08-01 22:43:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanford Pain",
      "screen_name" : "StanfordPain",
      "indices" : [ 3, 16 ],
      "id_str" : "1337365416",
      "id" : 1337365416
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicpain",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/nFkx58PRvT",
      "expanded_url" : "http:\/\/wapo.st\/1KvkzO4",
      "display_url" : "wapo.st\/1KvkzO4"
    } ]
  },
  "geo" : { },
  "id_str" : "627550840199454720",
  "text" : "RT @StanfordPain: The genius inventor who says he\u2019ll eliminate #chronicpain with a simple device: http:\/\/t.co\/nFkx58PRvT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "chronicpain",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/nFkx58PRvT",
        "expanded_url" : "http:\/\/wapo.st\/1KvkzO4",
        "display_url" : "wapo.st\/1KvkzO4"
      } ]
    },
    "geo" : { },
    "id_str" : "626035433512677377",
    "text" : "The genius inventor who says he\u2019ll eliminate #chronicpain with a simple device: http:\/\/t.co\/nFkx58PRvT",
    "id" : 626035433512677377,
    "created_at" : "2015-07-28 14:24:13 +0000",
    "user" : {
      "name" : "Stanford Pain",
      "screen_name" : "StanfordPain",
      "protected" : false,
      "id_str" : "1337365416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675436998799130624\/JxzDN5k3_normal.png",
      "id" : 1337365416,
      "verified" : true
    }
  },
  "id" : 627550840199454720,
  "created_at" : "2015-08-01 18:45:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/lXRD2ccCqc",
      "expanded_url" : "https:\/\/twitter.com\/SecondChronicle\/status\/627515667995074560",
      "display_url" : "twitter.com\/SecondChronicl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627520039818797056",
  "text" : "interesting! https:\/\/t.co\/lXRD2ccCqc",
  "id" : 627520039818797056,
  "created_at" : "2015-08-01 16:43:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627516138390482945",
  "text" : "RT @rachelheldevans: Today's question on FB: What are some key initiatives we should be supporting to reduce abortion rate? http:\/\/t.co\/R5U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/R5U6XkJSYv",
        "expanded_url" : "http:\/\/buff.ly\/1KGSvHC",
        "display_url" : "buff.ly\/1KGSvHC"
      } ]
    },
    "geo" : { },
    "id_str" : "627514402804224000",
    "text" : "Today's question on FB: What are some key initiatives we should be supporting to reduce abortion rate? http:\/\/t.co\/R5U6XkJSYv",
    "id" : 627514402804224000,
    "created_at" : "2015-08-01 16:21:06 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 627516138390482945,
  "created_at" : "2015-08-01 16:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/rBRLa6J4XW",
      "expanded_url" : "https:\/\/twitter.com\/redlianak\/status\/627477934375309314",
      "display_url" : "twitter.com\/redlianak\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627507454755110912",
  "text" : "by their fruit... https:\/\/t.co\/rBRLa6J4XW",
  "id" : 627507454755110912,
  "created_at" : "2015-08-01 15:53:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Quinlan",
      "screen_name" : "neilquinlan",
      "indices" : [ 3, 15 ],
      "id_str" : "258389908",
      "id" : 258389908
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/neilquinlan\/status\/627328787005468672\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/CRWlZExipv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLS4NIPXAAAWizb.jpg",
      "id_str" : "627328783801057280",
      "id" : 627328783801057280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLS4NIPXAAAWizb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/CRWlZExipv"
    } ],
    "hashtags" : [ {
      "text" : "zombiecows",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627333113597816833",
  "text" : "RT @neilquinlan: Funny the effect a blue moon has on a cow......\n#zombiecows http:\/\/t.co\/CRWlZExipv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/neilquinlan\/status\/627328787005468672\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/CRWlZExipv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLS4NIPXAAAWizb.jpg",
        "id_str" : "627328783801057280",
        "id" : 627328783801057280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLS4NIPXAAAWizb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/CRWlZExipv"
      } ],
      "hashtags" : [ {
        "text" : "zombiecows",
        "indices" : [ 48, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627328787005468672",
    "text" : "Funny the effect a blue moon has on a cow......\n#zombiecows http:\/\/t.co\/CRWlZExipv",
    "id" : 627328787005468672,
    "created_at" : "2015-08-01 04:03:32 +0000",
    "user" : {
      "name" : "Neil Quinlan",
      "screen_name" : "neilquinlan",
      "protected" : false,
      "id_str" : "258389908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529262492737097729\/0Fq0ksdb_normal.jpeg",
      "id" : 258389908,
      "verified" : false
    }
  },
  "id" : 627333113597816833,
  "created_at" : "2015-08-01 04:20:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]