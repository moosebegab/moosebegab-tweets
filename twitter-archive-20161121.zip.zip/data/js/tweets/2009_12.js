Grailbird.data.tweets_2009_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7268169782",
  "text" : "You are a live wire today and should be able to raise the ener... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7268169782,
  "created_at" : "2010-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7272170391",
  "text" : "RT @Encouraging: I color my future in shades of love, removing all fear. 2\/3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7270394694",
    "text" : "I color my future in shades of love, removing all fear. 2\/3",
    "id" : 7270394694,
    "created_at" : "2010-01-01 14:41:46 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7272170391,
  "created_at" : "2010-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "indices" : [ 3, 17 ],
      "id_str" : "19160554",
      "id" : 19160554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7216469603",
  "text" : "RT @TatianaTheDog: RT @FreeNewPower @WarrenWhitlock: \"Your time is limited - Don't waste it living someone else's life\" - Steve Jobs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Warren Whitlock",
        "screen_name" : "WarrenWhitlock",
        "indices" : [ 17, 32 ],
        "id_str" : "15081182",
        "id" : 15081182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7206421251",
    "text" : "RT @FreeNewPower @WarrenWhitlock: \"Your time is limited - Don't waste it living someone else's life\" - Steve Jobs",
    "id" : 7206421251,
    "created_at" : "2009-12-30 19:44:09 +0000",
    "user" : {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "protected" : false,
      "id_str" : "19160554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736817395\/c22eadc111e9af2f8a8bea5c17c83a82_normal.png",
      "id" : 19160554,
      "verified" : false
    }
  },
  "id" : 7216469603,
  "created_at" : "2009-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7232310571",
  "text" : "You want to explore new ways of enjoying yourself as today's L... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7232310571,
  "created_at" : "2009-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    }, {
      "name" : "Cesar Millan",
      "screen_name" : "cesarmillan",
      "indices" : [ 18, 30 ],
      "id_str" : "16228699",
      "id" : 16228699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7238304145",
  "text" : "RT @aplacetobark: @cesarmillan TODAY IS THE LAST DAY 2 meet matching grant: http:\/\/bit.ly\/6Yl49s video: http:\/\/bit.ly\/6uhoEn PLS pay it  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cesar Millan",
        "screen_name" : "cesarmillan",
        "indices" : [ 0, 12 ],
        "id_str" : "16228699",
        "id" : 16228699
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "7210542319",
    "geo" : { },
    "id_str" : "7236022836",
    "in_reply_to_user_id" : 16228699,
    "text" : "@cesarmillan TODAY IS THE LAST DAY 2 meet matching grant: http:\/\/bit.ly\/6Yl49s video: http:\/\/bit.ly\/6uhoEn PLS pay it forward & RT:)",
    "id" : 7236022836,
    "in_reply_to_status_id" : 7210542319,
    "created_at" : "2009-12-31 14:58:58 +0000",
    "in_reply_to_screen_name" : "cesarmillan",
    "in_reply_to_user_id_str" : "16228699",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 7238304145,
  "created_at" : "2009-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7238942497",
  "text" : "RT @abandontheherd: 2010 is a block of pure gold and you are the skilled artisan who will sculpt it into a work of art.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7232394213",
    "text" : "2010 is a block of pure gold and you are the skilled artisan who will sculpt it into a work of art.",
    "id" : 7232394213,
    "created_at" : "2009-12-31 12:32:31 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7238942497,
  "created_at" : "2009-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7243435488",
  "text" : "@deucehartley btw, what is FTW? almond butter sounds good!",
  "id" : 7243435488,
  "created_at" : "2009-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7194221299",
  "text" : "It's difficult for you to follow through on what you start tod... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7194221299,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Ann Richardson",
      "screen_name" : "AnnLRichardson",
      "indices" : [ 20, 35 ],
      "id_str" : "58306911",
      "id" : 58306911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7195766287",
  "text" : "RT @Encouraging: RT @AnnLRichardson The smallest deed is better than the grandest intention.",
  "id" : 7195766287,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7195890939",
  "text" : "RT @tonyrobbins: what a wild world we live in: escaped prisoner updates his facebook page while on the run http:\/\/bit.ly\/4rJ2vQ",
  "id" : 7195890939,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7195920380",
  "text" : "RT @abandontheherd: Cultivate compassion towards those who are miserable-Pantanjali's Yoga Sutras",
  "id" : 7195920380,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7195947322",
  "text" : "RT @CaplinROUS: This is how I like to spend a cold winter day.",
  "id" : 7195947322,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    }, {
      "name" : "Marie Ang",
      "screen_name" : "Marie_Ang",
      "indices" : [ 18, 28 ],
      "id_str" : "25247428",
      "id" : 25247428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7196015042",
  "text" : "RT @twitingly: RT @Marie_Ang: Be different.... you were born an original - don't die a copy #quote",
  "id" : 7196015042,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7196222008",
  "text" : "RT @LaughingBaba: The matrix cannot tell you who you are. - Trinity",
  "id" : 7196222008,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7201614549",
  "text" : "RT @aplacetobark: ONLY 1 DAY LEFT 2 meet our matching grant, info here: http:\/\/bit.ly\/6Yl49s  Pls help us finish our shelter:) RT",
  "id" : 7201614549,
  "created_at" : "2009-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7142743486",
  "text" : "me: How did I get that big? hubby: years of practice and hard work",
  "id" : 7142743486,
  "created_at" : "2009-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "indices" : [ 3, 9 ],
      "id_str" : "8943",
      "id" : 8943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7145689339",
  "text" : "RT @jesus: This whole religion thing needs to stop. It's embarrassing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6544924976",
    "text" : "This whole religion thing needs to stop. It's embarrassing.",
    "id" : 6544924976,
    "created_at" : "2009-12-10 21:56:18 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "protected" : false,
      "id_str" : "8943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000436609149\/959a9ed0624216336e8d253aceb89e2b_normal.jpeg",
      "id" : 8943,
      "verified" : false
    }
  },
  "id" : 7145689339,
  "created_at" : "2009-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7157457783",
  "text" : "As the year is drawing to a close, it may seem as if an era is... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7157457783,
  "created_at" : "2009-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moe Farahat",
      "screen_name" : "farahato",
      "indices" : [ 3, 12 ],
      "id_str" : "30189721",
      "id" : 30189721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7104953691",
  "text" : "RT @farahato: \"Life is like a coin. You can spend it any way you wish, but you only spend it once.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7074051992",
    "text" : "\"Life is like a coin. You can spend it any way you wish, but you only spend it once.\"",
    "id" : 7074051992,
    "created_at" : "2009-12-27 00:01:08 +0000",
    "user" : {
      "name" : "Moe Farahat",
      "screen_name" : "farahato",
      "protected" : false,
      "id_str" : "30189721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2697748500\/82cd601ac07b745c503baa71ab9b42c3_normal.jpeg",
      "id" : 30189721,
      "verified" : false
    }
  },
  "id" : 7104953691,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7109021880",
  "text" : "RT @aplacetobark: http:\/\/twitvid.com\/CA224 - If u Twitter or Facebook we need your help to meet r matching grant Dec 31! Pls help us hel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7108474176",
    "text" : "http:\/\/twitvid.com\/CA224 - If u Twitter or Facebook we need your help to meet r matching grant Dec 31! Pls help us help homeless pets!!!",
    "id" : 7108474176,
    "created_at" : "2009-12-28 02:21:49 +0000",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 7109021880,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7109025666",
  "text" : "RT @ChrisCade: I used to have a box. I broke it, so now I can't think inside it nor outside of it.  Now I have to Think Without the Box\u2122",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7108250790",
    "text" : "I used to have a box. I broke it, so now I can't think inside it nor outside of it.  Now I have to Think Without the Box\u2122",
    "id" : 7108250790,
    "created_at" : "2009-12-28 02:13:58 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7109025666,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7109037694",
  "text" : "RT @ChrisCade: Sometimes we must journey to the furthest reaches of the Universe, just to return home and re-discover what was always there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7108117185",
    "text" : "Sometimes we must journey to the furthest reaches of the Universe, just to return home and re-discover what was always there.",
    "id" : 7108117185,
    "created_at" : "2009-12-28 02:09:15 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7109037694,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7121052274",
  "text" : "It's challenging when everything seems so black and white; you... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7121052274,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Keoieid",
      "screen_name" : "tempusfrangit",
      "indices" : [ 19, 33 ],
      "id_str" : "9259432",
      "id" : 9259432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7136938066",
  "text" : "RT @CaplinROUS: RT @tempusfrangit: When you interrupt regular programming for specal reports, the terrorists win.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keoieid",
        "screen_name" : "tempusfrangit",
        "indices" : [ 3, 17 ],
        "id_str" : "9259432",
        "id" : 9259432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7133263030",
    "text" : "RT @tempusfrangit: When you interrupt regular programming for specal reports, the terrorists win.",
    "id" : 7133263030,
    "created_at" : "2009-12-28 20:11:16 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 7136938066,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole",
      "screen_name" : "obnoxiousacorns",
      "indices" : [ 0, 16 ],
      "id_str" : "24719145",
      "id" : 24719145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7132095851",
  "geo" : { },
  "id_str" : "7137064254",
  "in_reply_to_user_id" : 24719145,
  "text" : "@obnoxiousacorns Have you tried drinkact? contact sheri johnson at globalsuccessmentor.com",
  "id" : 7137064254,
  "in_reply_to_status_id" : 7132095851,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "obnoxiousacorns",
  "in_reply_to_user_id_str" : "24719145",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7137161152",
  "text" : "RT @aplacetobark: Pls watch, donate & help us meet our matching grant http:\/\/twitvid.com\/CA224 info here: http:\/\/Bit.ly\/60fSjs RT at ani ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7125639601",
    "text" : "Pls watch, donate & help us meet our matching grant http:\/\/twitvid.com\/CA224 info here: http:\/\/Bit.ly\/60fSjs RT at animal luvn celebs!",
    "id" : 7125639601,
    "created_at" : "2009-12-28 15:38:35 +0000",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 7137161152,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIY Energy",
      "screen_name" : "DIYEnergyNow",
      "indices" : [ 3, 16 ],
      "id_str" : "90270483",
      "id" : 90270483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7137252691",
  "text" : "RT @DIYEnergyNow: The human brain is too high-powered to have many practical uses in this particular universe. *Kurt Vonnegut Jr.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7124157627",
    "text" : "The human brain is too high-powered to have many practical uses in this particular universe. *Kurt Vonnegut Jr.",
    "id" : 7124157627,
    "created_at" : "2009-12-28 14:41:03 +0000",
    "user" : {
      "name" : "DIY Energy",
      "screen_name" : "DIYEnergyNow",
      "protected" : false,
      "id_str" : "90270483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551643238\/DIYEnergy_normal.jpg",
      "id" : 90270483,
      "verified" : false
    }
  },
  "id" : 7137252691,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zappos",
      "screen_name" : "zappos",
      "indices" : [ 3, 10 ],
      "id_str" : "338601496",
      "id" : 338601496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7077147549",
  "text" : "RT @zappos: \"If you obey all the rules, you miss all the fun.\" -Katharine Hepburn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7076526559",
    "text" : "\"If you obey all the rules, you miss all the fun.\" -Katharine Hepburn",
    "id" : 7076526559,
    "created_at" : "2009-12-27 01:46:58 +0000",
    "user" : {
      "name" : "Zappos.com CEO -Tony",
      "screen_name" : "tonyhsieh",
      "protected" : false,
      "id_str" : "7040932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2857765620\/6e217bad764ca0f80b223a890a2f9aa2_normal.png",
      "id" : 7040932,
      "verified" : true
    }
  },
  "id" : 7077147549,
  "created_at" : "2009-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7088693519",
  "text" : "You'll know who your real friends are today because they will ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7088693519,
  "created_at" : "2009-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "linajk",
      "screen_name" : "linajk",
      "indices" : [ 15, 22 ],
      "id_str" : "2568804589",
      "id" : 2568804589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7094228583",
  "text" : "RT @BestAt: RT @linajk: Instructions: The Care and Feeding of Guests... Begin when they arrive. Stop when you want them to leave.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "linajk",
        "screen_name" : "linajk",
        "indices" : [ 3, 10 ],
        "id_str" : "2568804589",
        "id" : 2568804589
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7094184254",
    "text" : "RT @linajk: Instructions: The Care and Feeding of Guests... Begin when they arrive. Stop when you want them to leave.",
    "id" : 7094184254,
    "created_at" : "2009-12-27 16:46:12 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 7094228583,
  "created_at" : "2009-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7094249147",
  "text" : "Daughter loves her snuggie but wears it backwards.. lol. She's a rebel just like her mom!",
  "id" : 7094249147,
  "created_at" : "2009-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7048935839",
  "text" : "Puppy is tired of all this Christmas business.. she wants to go back to work!",
  "id" : 7048935839,
  "created_at" : "2009-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iWise",
      "screen_name" : "iwisenet",
      "indices" : [ 3, 12 ],
      "id_str" : "38865415",
      "id" : 38865415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7049059366",
  "text" : "RT @iwisenet: FREE Sci-Fi Audio+eBook at http:\/\/www.iwasjustdead.com  about Augmented Reality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7038284766",
    "text" : "FREE Sci-Fi Audio+eBook at http:\/\/www.iwasjustdead.com  about Augmented Reality",
    "id" : 7038284766,
    "created_at" : "2009-12-25 18:09:57 +0000",
    "user" : {
      "name" : "iWise",
      "screen_name" : "iwisenet",
      "protected" : false,
      "id_str" : "38865415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/317873988\/oAuthiWiseIcon_normal.png",
      "id" : 38865415,
      "verified" : false
    }
  },
  "id" : 7049059366,
  "created_at" : "2009-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7059562217",
  "text" : "Mercury's retrograde in your 11th House of Long-Term Planning ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7059562217,
  "created_at" : "2009-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Sarah",
      "screen_name" : "yowhatsthehaps",
      "indices" : [ 15, 30 ],
      "id_str" : "14874786",
      "id" : 14874786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7064145426",
  "text" : "RT @BestAt: RT @yowhatsthehaps: They threatened to take the Internet away from me for the night. \"Heeeeyyyy! My friends are in there!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah",
        "screen_name" : "yowhatsthehaps",
        "indices" : [ 3, 18 ],
        "id_str" : "14874786",
        "id" : 14874786
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7056628040",
    "text" : "RT @yowhatsthehaps: They threatened to take the Internet away from me for the night. \"Heeeeyyyy! My friends are in there!\"",
    "id" : 7056628040,
    "created_at" : "2009-12-26 08:28:39 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 7064145426,
  "created_at" : "2009-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7021793362",
  "text" : "RT @aplacetobark: Sometimes.. The true gifts are not the easiest to understand in this life. Looking deeper & finding, self expands our  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7018874953",
    "text" : "Sometimes.. The true gifts are not the easiest to understand in this life. Looking deeper & finding, self expands our souls -B. Berlin",
    "id" : 7018874953,
    "created_at" : "2009-12-25 02:06:55 +0000",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 7021793362,
  "created_at" : "2009-12-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7030757908",
  "text" : "The idea of participating in a group activity is quite natural... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7030757908,
  "created_at" : "2009-12-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "defythemind",
      "indices" : [ 3, 15 ],
      "id_str" : "279751736",
      "id" : 279751736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7041722893",
  "text" : "RT @DefyTheMind: Never be bullied into silence. Never be made a victim. Accept no one\u2019s definition of your life; define yourself. #quote",
  "id" : 7041722893,
  "created_at" : "2009-12-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7005041213",
  "text" : "RT @ChrisCade: \"Whatever your past has been you have a spotless future.\" ~ Melanie Gustafson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7004719174",
    "text" : "\"Whatever your past has been you have a spotless future.\" ~ Melanie Gustafson",
    "id" : 7004719174,
    "created_at" : "2009-12-24 16:53:53 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7005041213,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6997671501",
  "text" : "It's easy for you to get so excited about something now that y... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 6997671501,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metaphorforlife",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7000690093",
  "text" : "RT @ChrisCade: \u201CWhen it snows, you have two choices: shovel or make snow angels.\" ~ Unknown #metaphorforlife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "metaphorforlife",
        "indices" : [ 77, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6969510690",
    "text" : "\u201CWhen it snows, you have two choices: shovel or make snow angels.\" ~ Unknown #metaphorforlife",
    "id" : 6969510690,
    "created_at" : "2009-12-23 16:43:05 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7000690093,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NFTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7000698599",
  "text" : "RT @ChrisCade: \"Each person in your life is there for a reason, and that reason always has something to do with love.\" ~ #NFTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NFTU",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6968743394",
    "text" : "\"Each person in your life is there for a reason, and that reason always has something to do with love.\" ~ #NFTU",
    "id" : 6968743394,
    "created_at" : "2009-12-23 16:16:41 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7000698599,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OSHO International",
      "screen_name" : "OSHOtimes",
      "indices" : [ 3, 13 ],
      "id_str" : "308673983",
      "id" : 308673983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7000730537",
  "text" : "RT @OSHOtimes: Live according to your own light. Find your own light within and live according to it without any fear. Osho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7000334437",
    "text" : "Live according to your own light. Find your own light within and live according to it without any fear. Osho",
    "id" : 7000334437,
    "created_at" : "2009-12-24 14:15:24 +0000",
    "user" : {
      "name" : "OSHO",
      "screen_name" : "OSHO",
      "protected" : false,
      "id_str" : "22303355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/498724104522850304\/7uQ82O5I_normal.png",
      "id" : 22303355,
      "verified" : false
    }
  },
  "id" : 7000730537,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 3, 16 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7000753140",
  "text" : "RT @ralphmacchio: Yes, Buon Natale! Safe and Happy to all in Twitterville!! You guys are awesome! Enjoy those closest to you... And even ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6999698394",
    "text" : "Yes, Buon Natale! Safe and Happy to all in Twitterville!! You guys are awesome! Enjoy those closest to you... And even those that are not :)",
    "id" : 6999698394,
    "created_at" : "2009-12-24 13:48:07 +0000",
    "user" : {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "protected" : false,
      "id_str" : "44163738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535851580667346944\/DCmtbKbq_normal.jpeg",
      "id" : 44163738,
      "verified" : true
    }
  },
  "id" : 7000753140,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "indices" : [ 15, 21 ],
      "id_str" : "9930742",
      "id" : 9930742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7001025922",
  "text" : "RT @BestAt: RT @sween: Someone asked if I felt like sharing my cookies so yeah they're dead now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Sweeney",
        "screen_name" : "sween",
        "indices" : [ 3, 9 ],
        "id_str" : "9930742",
        "id" : 9930742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6999595991",
    "text" : "RT @sween: Someone asked if I felt like sharing my cookies so yeah they're dead now.",
    "id" : 6999595991,
    "created_at" : "2009-12-24 13:43:30 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 7001025922,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7002955458",
  "text" : "Little boy's big legacy teaches others how to live http:\/\/news.yahoo.com\/s\/ap\/20091224\/ap_on_he_me\/us_danny_s_example",
  "id" : 7002955458,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6946483772",
  "text" : "RT @ChrisCade: \"I'm sick of following my dreams. I'm just going to ask them where they're goin' and hook up with them later' ~ Mitch Hedberg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6945946926",
    "text" : "\"I'm sick of following my dreams. I'm just going to ask them where they're goin' and hook up with them later' ~ Mitch Hedberg",
    "id" : 6945946926,
    "created_at" : "2009-12-22 23:43:29 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 6946483772,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6946498893",
  "text" : "RT @ChrisCade: \u201CThere are two mistakes one can make along the road to truth... not going all the way, and not starting.\u201D ~ Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6935608159",
    "text" : "\u201CThere are two mistakes one can make along the road to truth... not going all the way, and not starting.\u201D ~ Buddha",
    "id" : 6935608159,
    "created_at" : "2009-12-22 17:37:25 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 6946498893,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6946653406",
  "text" : "RT @abe_quotes: Abe: Stop worrying about what anybody else is doing becuz it is [that worry] which is causing you to hold urself vibrati ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6944825939",
    "text" : "Abe: Stop worrying about what anybody else is doing becuz it is [that worry] which is causing you to hold urself vibrationally out of whack.",
    "id" : 6944825939,
    "created_at" : "2009-12-22 23:02:05 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 6946653406,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6962906048",
  "text" : "You have something important to say to your friends today and ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 6962906048,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "indices" : [ 3, 16 ],
      "id_str" : "22276232",
      "id" : 22276232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6971379192",
  "text" : "RT @successwalls: \"It takes no more effort 2 expect the best, than 2 fear the worst. Its healthier, more productive, & a lot more fun!\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6954733838",
    "text" : "\"It takes no more effort 2 expect the best, than 2 fear the worst. Its healthier, more productive, & a lot more fun!\" \u2013Philip Humbert #quote",
    "id" : 6954733838,
    "created_at" : "2009-12-23 05:05:34 +0000",
    "user" : {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "protected" : false,
      "id_str" : "22276232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840968112\/twitrSWicon2_normal.jpg",
      "id" : 22276232,
      "verified" : false
    }
  },
  "id" : 6971379192,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Grant Thomson",
      "screen_name" : "GrantThomson",
      "indices" : [ 20, 33 ],
      "id_str" : "79718796",
      "id" : 79718796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6971849662",
  "text" : "RT @Encouraging: RT @GrantThomson The best mind-altering drug is truth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grant Thomson",
        "screen_name" : "GrantThomson",
        "indices" : [ 3, 16 ],
        "id_str" : "79718796",
        "id" : 79718796
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6965840229",
    "text" : "RT @GrantThomson The best mind-altering drug is truth.",
    "id" : 6965840229,
    "created_at" : "2009-12-23 14:37:11 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 6971849662,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    }, {
      "name" : "Ralph Marston",
      "screen_name" : "ralphmarston",
      "indices" : [ 18, 31 ],
      "id_str" : "21630687",
      "id" : 21630687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6972055885",
  "text" : "RT @BeALegacy: RT @ralphmarston If the circumstances of your life r not yet what u desire, it's because u have not yet become the person ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ralph Marston",
        "screen_name" : "ralphmarston",
        "indices" : [ 3, 16 ],
        "id_str" : "21630687",
        "id" : 21630687
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6968623641",
    "text" : "RT @ralphmarston If the circumstances of your life r not yet what u desire, it's because u have not yet become the person u desire 2 become.",
    "id" : 6968623641,
    "created_at" : "2009-12-23 16:12:37 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 6972055885,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Abraham",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "LOA",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6972241148",
  "text" : "RT @abe_quotes: Keep remembering: there is not only one prize. \n\n#Abraham #LOA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abraham",
        "indices" : [ 49, 57 ]
      }, {
        "text" : "LOA",
        "indices" : [ 58, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6972069925",
    "text" : "Keep remembering: there is not only one prize. \n\n#Abraham #LOA",
    "id" : 6972069925,
    "created_at" : "2009-12-23 18:14:47 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 6972241148,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6972271244",
  "text" : "http:\/\/craigmattice.blogspot.com\/2009\/12\/you-have-give-two-of-greatest-gifts-in.html",
  "id" : 6972271244,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 89, 97 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6972783746",
  "text" : "Good News Gazette | Kindness of American Saint Nick remembered: http:\/\/bit.ly\/6NmhnL via @addthis",
  "id" : 6972783746,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6973167457",
  "text" : "FREE gift from Coach Jeannette Maw: Adventures in Manifesting http:\/\/www.adventuresinmanifesting.com -couponcode:GoodLove",
  "id" : 6973167457,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6974714300",
  "text" : "http:\/\/blog.theamericanmonk.com\/power-of-mind\/ ..the effects of human thoughts and words on water..",
  "id" : 6974714300,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6978031076",
  "text" : "DD & I getting our camo belts tonight at belt ceremony.. woohoo!",
  "id" : 6978031076,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6913229405",
  "text" : "RT @aplacetobark: Check this video out -- medium.m4v http:\/\/www.youtube.com\/watch?v=p9TOUUSYPzU Help finish r shelter this Xmas! All don ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6912650329",
    "text" : "Check this video out -- medium.m4v http:\/\/www.youtube.com\/watch?v=p9TOUUSYPzU Help finish r shelter this Xmas! All donations matched to 23k",
    "id" : 6912650329,
    "created_at" : "2009-12-22 01:25:53 +0000",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 6913229405,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    }, {
      "name" : "Lisa Rothe",
      "screen_name" : "CreativeVoix",
      "indices" : [ 99, 112 ],
      "id_str" : "44889732",
      "id" : 44889732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6914177729",
  "text" : "RT @abandontheherd: It doesn't matter how slow you go, as long as you don't stop! - Confucius (via @CreativeVoix)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Rothe",
        "screen_name" : "CreativeVoix",
        "indices" : [ 79, 92 ],
        "id_str" : "44889732",
        "id" : 44889732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6912149112",
    "text" : "It doesn't matter how slow you go, as long as you don't stop! - Confucius (via @CreativeVoix)",
    "id" : 6912149112,
    "created_at" : "2009-12-22 01:09:17 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 6914177729,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Seth",
      "indices" : [ 16, 21 ]
    }, {
      "text" : "LoA",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "Ycyor",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6914377842",
  "text" : "RT @abe_quotes: #Seth: Against all conventional knowledge, reviewing the mistakes of the past does not lead to wisdom.\n\n#LoA #Ycyor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Seth",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "LoA",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "Ycyor",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6910694380",
    "text" : "#Seth: Against all conventional knowledge, reviewing the mistakes of the past does not lead to wisdom.\n\n#LoA #Ycyor",
    "id" : 6910694380,
    "created_at" : "2009-12-22 00:20:36 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 6914377842,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Steve Keating",
      "screen_name" : "LeadToday",
      "indices" : [ 20, 30 ],
      "id_str" : "35767916",
      "id" : 35767916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6914492284",
  "text" : "RT @Encouraging: RT @LeadToday He who laughs, lasts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Keating",
        "screen_name" : "LeadToday",
        "indices" : [ 3, 13 ],
        "id_str" : "35767916",
        "id" : 35767916
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6908813811",
    "text" : "RT @LeadToday He who laughs, lasts.",
    "id" : 6908813811,
    "created_at" : "2009-12-21 23:16:53 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 6914492284,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6927049685",
  "text" : "You may feel as if you are at the whim of your moods that pull... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 6927049685,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 45, 53 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6929833838",
  "text" : "Brought By Thought: http:\/\/bit.ly\/4Hc8M4 via @addthis \"The power of thought is a force above all other forces...\"",
  "id" : 6929833838,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6938515796",
  "text" : "RT @mercola: Have you tried HOMEOPATHY? Here's a great post by Amy L. Lansky, PhD, author of Impossible Cure http:\/\/bit.ly\/6TCH9r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6931934741",
    "text" : "Have you tried HOMEOPATHY? Here's a great post by Amy L. Lansky, PhD, author of Impossible Cure http:\/\/bit.ly\/6TCH9r",
    "id" : 6931934741,
    "created_at" : "2009-12-22 15:32:48 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 6938515796,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Steve Keating",
      "screen_name" : "LeadToday",
      "indices" : [ 20, 30 ],
      "id_str" : "35767916",
      "id" : 35767916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6942578115",
  "text" : "RT @Encouraging: RT @LeadToday Successful people don't find opportunities, they make them.",
  "id" : 6942578115,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Morrow",
      "screen_name" : "jonmorrow",
      "indices" : [ 3, 13 ],
      "id_str" : "2183837993",
      "id" : 2183837993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6944160394",
  "text" : "RT @JonMorrow: My latest at Copyblogger: On Dying, Mothers, and Fighting for Your Ideas http:\/\/bit.ly\/7gZgW3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6933687389",
    "text" : "My latest at Copyblogger: On Dying, Mothers, and Fighting for Your Ideas http:\/\/bit.ly\/7gZgW3",
    "id" : 6933687389,
    "created_at" : "2009-12-22 16:31:49 +0000",
    "user" : {
      "name" : "Smart Blogger",
      "screen_name" : "smartbloggerhq",
      "protected" : false,
      "id_str" : "10621792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755799323129020416\/CHdKrRpD_normal.jpg",
      "id" : 10621792,
      "verified" : false
    }
  },
  "id" : 6944160394,
  "created_at" : "2009-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6878025093",
  "text" : "http:\/\/www.mybusinesspresence.com\/subscribe\/ Will be sharing business tips, online presence news and information, and more!",
  "id" : 6878025093,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Martin Bell",
      "screen_name" : "houstondog",
      "indices" : [ 19, 30 ],
      "id_str" : "305552711",
      "id" : 305552711
    }, {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 35, 47 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogs",
      "indices" : [ 123, 128 ]
    }, {
      "text" : "travel",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6878121801",
  "text" : "RT @CaplinROUS: RT @HoustonDog: RT @fearfuldogs How Amtrak could become solvent (hint: pets involved) http:\/\/bit.ly\/5uljQo #dogs #travel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Bell",
        "screen_name" : "houstondog",
        "indices" : [ 3, 14 ],
        "id_str" : "305552711",
        "id" : 305552711
      }, {
        "name" : "debbie jacobs",
        "screen_name" : "fearfuldogs",
        "indices" : [ 19, 31 ],
        "id_str" : "16691399",
        "id" : 16691399
      }, {
        "name" : "Yrag Kirwan",
        "screen_name" : "WillMyDogHateMe",
        "indices" : [ 122, 138 ],
        "id_str" : "748602537301913600",
        "id" : 748602537301913600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dogs",
        "indices" : [ 107, 112 ]
      }, {
        "text" : "travel",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6876184101",
    "text" : "RT @HoustonDog: RT @fearfuldogs How Amtrak could become solvent (hint: pets involved) http:\/\/bit.ly\/5uljQo #dogs #travel  @WillMyDogHateMe",
    "id" : 6876184101,
    "created_at" : "2009-12-21 00:24:17 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 6878121801,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6896480241",
  "text" : "RT @lisarobbinyoung: Today's brainstorm: Life is a word search. All the answers are right in front of us, we've just got to find them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6894885983",
    "text" : "Today's brainstorm: Life is a word search. All the answers are right in front of us, we've just got to find them.",
    "id" : 6894885983,
    "created_at" : "2009-12-21 14:41:55 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 6896480241,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 101, 109 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6897990120",
  "text" : "Our Changing Sky: Current Transit Details: Become somebody else's oddball.  http:\/\/bit.ly\/2RaByB via @addthis",
  "id" : 6897990120,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slade Roberson",
      "screen_name" : "SladeRoberson",
      "indices" : [ 3, 17 ],
      "id_str" : "40714123",
      "id" : 40714123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6903960058",
  "text" : "RT @sladeroberson: Note to self: do not wear red when shopping at Target.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6903844537",
    "text" : "Note to self: do not wear red when shopping at Target.",
    "id" : 6903844537,
    "created_at" : "2009-12-21 20:07:55 +0000",
    "user" : {
      "name" : "Slade Roberson",
      "screen_name" : "SladeRoberson",
      "protected" : false,
      "id_str" : "40714123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/216164075\/slade-square_normal.png",
      "id" : 40714123,
      "verified" : false
    }
  },
  "id" : 6903960058,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6904013043",
  "text" : "RT @tonyrobbins: \"God said 'Ask and you shall receive', he didn't say 'Bitch and whine and you shall receive. Do your part!.\" tony robbins",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6903318943",
    "text" : "\"God said 'Ask and you shall receive', he didn't say 'Bitch and whine and you shall receive. Do your part!.\" tony robbins",
    "id" : 6903318943,
    "created_at" : "2009-12-21 19:47:26 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 6904013043,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6904071365",
  "text" : "RT @tonyrobbins: A quick a amazing trip through the known universe in back in 4 minutes!  puts your life in perspective watch:  http:\/\/b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6903186488",
    "text" : "A quick a amazing trip through the known universe in back in 4 minutes!  puts your life in perspective watch:  http:\/\/bit.ly\/6uWBIz",
    "id" : 6903186488,
    "created_at" : "2009-12-21 19:42:17 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 6904071365,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6848778432",
  "text" : "watching Dr Who \/ The Water of Mars.. sigh. I'm going to miss this DR..",
  "id" : 6848778432,
  "created_at" : "2009-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6862928806",
  "text" : "Millbrook NY was spared all that snow.. yeah!",
  "id" : 6862928806,
  "created_at" : "2009-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6874213401",
  "text" : "RT @abandontheherd: If you light a lamp for someone , it will also brighten your path. ~Buddhist saying (via @suebatt55)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6862806559",
    "text" : "If you light a lamp for someone , it will also brighten your path. ~Buddhist saying (via @suebatt55)",
    "id" : 6862806559,
    "created_at" : "2009-12-20 15:37:19 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 6874213401,
  "created_at" : "2009-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6875111150",
  "text" : "Use an autoresponder? Visit AR Profits forum: http:\/\/bit.ly\/8Gqet3",
  "id" : 6875111150,
  "created_at" : "2009-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6832679517",
  "text" : "RT @abandontheherd: Trust is the antidote to fear. Love is the antidote to anger.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6829459969",
    "text" : "Trust is the antidote to fear. Love is the antidote to anger.",
    "id" : 6829459969,
    "created_at" : "2009-12-19 14:06:12 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 6832679517,
  "created_at" : "2009-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6837963851",
  "text" : "25 Unlikely Animal Friendships - http:\/\/www.forkparty.com\/25-unlikely-animal-friendships\/",
  "id" : 6837963851,
  "created_at" : "2009-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6838419246",
  "text" : "just had police in driveway due to hubby accidentally dialing 911.. our phone is sticky.. lol.",
  "id" : 6838419246,
  "created_at" : "2009-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6798374193",
  "text" : "RT @abandontheherd: Is there anything sweeter than a puppy resting her head on your foot to sleep? It would be hard to convince me other ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6780176672",
    "text" : "Is there anything sweeter than a puppy resting her head on your foot to sleep? It would be hard to convince me otherwise right now:)))",
    "id" : 6780176672,
    "created_at" : "2009-12-18 00:43:11 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 6798374193,
  "created_at" : "2009-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6798389588",
  "text" : "RT @abandontheherd: Baby moose in sprinkler! http:\/\/www.wimp.com\/babymoose\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6779896466",
    "text" : "Baby moose in sprinkler! http:\/\/www.wimp.com\/babymoose\/",
    "id" : 6779896466,
    "created_at" : "2009-12-18 00:33:07 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 6798389588,
  "created_at" : "2009-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 20, 33 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6798512368",
  "text" : "RT @BigBookofYou: RT@DeepakChopra You alone are the judge of yr worth, & yr goal is to discover infinite worth in yourself, no matter wh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 2, 15 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6778477405",
    "text" : "RT@DeepakChopra You alone are the judge of yr worth, & yr goal is to discover infinite worth in yourself, no matter what anyone else thinks",
    "id" : 6778477405,
    "created_at" : "2009-12-17 23:41:50 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 6798512368,
  "created_at" : "2009-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6801412319",
  "text" : "Hubby's upset.. cheese gift came in but not as pictured.. have to find basket\/box and arrange it.. sigh.",
  "id" : 6801412319,
  "created_at" : "2009-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Carpenter",
      "screen_name" : "MindJuiceMedia",
      "indices" : [ 3, 18 ],
      "id_str" : "55054587",
      "id" : 55054587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6807318744",
  "text" : "RT @MindJuiceMedia: Register at www.12daysofchristmasapps.com to win promo codes for Charmed, Charmed Xmas and other games!  Please retweet!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6804980635",
    "text" : "Register at www.12daysofchristmasapps.com to win promo codes for Charmed, Charmed Xmas and other games!  Please retweet!",
    "id" : 6804980635,
    "created_at" : "2009-12-18 18:57:36 +0000",
    "user" : {
      "name" : "Ken Carpenter",
      "screen_name" : "MindJuiceMedia",
      "protected" : false,
      "id_str" : "55054587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1628436101\/TwitterKenFaceImage_normal.png",
      "id" : 55054587,
      "verified" : false
    }
  },
  "id" : 6807318744,
  "created_at" : "2009-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 27, 40 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6774310379",
  "text" : "http:\/\/twitvid.com\/4E004 - @aplacetobark Thanks for all these updates. Really warms my heart to watch.",
  "id" : 6774310379,
  "created_at" : "2009-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Fiona Mackenzie",
      "screen_name" : "fionajmackenzie",
      "indices" : [ 30, 46 ],
      "id_str" : "2451018541",
      "id" : 2451018541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6752401631",
  "text" : "RT @CaplinROUS: Very cute. RT @FionaJMackenzie:  Seasonal bedtime story http:\/\/bit.ly\/81ogYH (just click on 'Read More) RT if poss please.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fiona Mackenzie",
        "screen_name" : "fionajmackenzie",
        "indices" : [ 14, 30 ],
        "id_str" : "2451018541",
        "id" : 2451018541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6746825092",
    "text" : "Very cute. RT @FionaJMackenzie:  Seasonal bedtime story http:\/\/bit.ly\/81ogYH (just click on 'Read More) RT if poss please.",
    "id" : 6746825092,
    "created_at" : "2009-12-17 00:00:54 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 6752401631,
  "created_at" : "2009-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6773848744",
  "text" : "major triumph for me last night!",
  "id" : 6773848744,
  "created_at" : "2009-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "indices" : [ 3, 17 ],
      "id_str" : "19160554",
      "id" : 19160554
    }, {
      "name" : "Candace Zynda",
      "screen_name" : "ChicagoPetPhoto",
      "indices" : [ 22, 38 ],
      "id_str" : "95317214",
      "id" : 95317214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6730704198",
  "text" : "RT @TatianaTheDog: RT @ChicagoPetPhoto A dog is like an eternal Peter Pan, a child who never grows old & who therefore is always availab ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Candace Zynda",
        "screen_name" : "ChicagoPetPhoto",
        "indices" : [ 3, 19 ],
        "id_str" : "95317214",
        "id" : 95317214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6721495370",
    "text" : "RT @ChicagoPetPhoto A dog is like an eternal Peter Pan, a child who never grows old & who therefore is always available to love & be loved.",
    "id" : 6721495370,
    "created_at" : "2009-12-16 05:28:15 +0000",
    "user" : {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "protected" : false,
      "id_str" : "19160554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736817395\/c22eadc111e9af2f8a8bea5c17c83a82_normal.png",
      "id" : 19160554,
      "verified" : false
    }
  },
  "id" : 6730704198,
  "created_at" : "2009-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6732839856",
  "text" : "http:\/\/twitpic.com\/tr19q - Kari waiting for Christmas.. hehe",
  "id" : 6732839856,
  "created_at" : "2009-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iFans.com",
      "screen_name" : "touchfans",
      "indices" : [ 3, 13 ],
      "id_str" : "18342200",
      "id" : 18342200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6738670454",
  "text" : "RT @touchfans: Nice Tower Defense game. 7 Cities - Free for one day only (celebrating 1 year on the App Store) http:\/\/bit.ly\/4NQztG ^Abc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6734995788",
    "text" : "Nice Tower Defense game. 7 Cities - Free for one day only (celebrating 1 year on the App Store) http:\/\/bit.ly\/4NQztG ^Abc",
    "id" : 6734995788,
    "created_at" : "2009-12-16 16:38:52 +0000",
    "user" : {
      "name" : "iFans.com",
      "screen_name" : "touchfans",
      "protected" : false,
      "id_str" : "18342200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2983864446\/9459b3ea5de259a4b11b82d1b599547c_normal.png",
      "id" : 18342200,
      "verified" : false
    }
  },
  "id" : 6738670454,
  "created_at" : "2009-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddToAny",
      "screen_name" : "AddToAny",
      "indices" : [ 124, 133 ],
      "id_str" : "21849140",
      "id" : 21849140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6739653530",
  "text" : "FDA dupes Interpol to achieve illegal kidnapping and deportation of herbal formulator Greg Caton - http:\/\/bit.ly\/6IT2HV via @AddToAny",
  "id" : 6739653530,
  "created_at" : "2009-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Caligiuri",
      "screen_name" : "RyanCaligiuri",
      "indices" : [ 3, 17 ],
      "id_str" : "26360152",
      "id" : 26360152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6742659493",
  "text" : "RT @RyanCaligiuri: Some people say emotional marketing isn't powerful. Try not to feel anything after this - http:\/\/bit.ly\/4w42S8 - #mar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "marketing",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6742278668",
    "text" : "Some people say emotional marketing isn't powerful. Try not to feel anything after this - http:\/\/bit.ly\/4w42S8 - #marketing",
    "id" : 6742278668,
    "created_at" : "2009-12-16 21:14:33 +0000",
    "user" : {
      "name" : "Ryan Caligiuri",
      "screen_name" : "RyanCaligiuri",
      "protected" : false,
      "id_str" : "26360152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747646059367763968\/c5qVoJeM_normal.jpg",
      "id" : 26360152,
      "verified" : false
    }
  },
  "id" : 6742659493,
  "created_at" : "2009-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 21, 34 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6742768601",
  "text" : "I like this video by @aplacetobark http:\/\/twitvid.com\/5668E",
  "id" : 6742768601,
  "created_at" : "2009-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6695901241",
  "text" : "http:\/\/twitvid.com\/9F6C1 RT A glimpse of the 8 dogs from a hoarding confiscation that we are working on socializing. Much time & LoVe needed",
  "id" : 6695901241,
  "created_at" : "2009-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6697414058",
  "text" : "octopus finds,moves and reassembles http:\/\/news.yahoo.com\/s\/ap\/20091215\/ap_on_sc\/as_australia_coconut_octopus",
  "id" : 6697414058,
  "created_at" : "2009-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6645117628",
  "text" : "Hubby and daughter decorating the tree together while dog and I watch.. hehe.",
  "id" : 6645117628,
  "created_at" : "2009-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SimpleEncouragement",
      "indices" : [ 73, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6669282808",
  "text" : "RT @Encouraging: Set your intentions. Make them clear. Make them loving. #SimpleEncouragement",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SimpleEncouragement",
        "indices" : [ 56, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6665384205",
    "text" : "Set your intentions. Make them clear. Make them loving. #SimpleEncouragement",
    "id" : 6665384205,
    "created_at" : "2009-12-14 16:03:40 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 6669282808,
  "created_at" : "2009-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "indices" : [ 3, 13 ],
      "id_str" : "14343511",
      "id" : 14343511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6669882606",
  "text" : "RT @lexsisney: \"The bad news is you're falling through the air, nothing to hang on to, no parachute. The good news is there's no ground. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6274345373",
    "text" : "\"The bad news is you're falling through the air, nothing to hang on to, no parachute. The good news is there's no ground.\" - Chogyam Trungpa",
    "id" : 6274345373,
    "created_at" : "2009-12-02 16:52:07 +0000",
    "user" : {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "protected" : false,
      "id_str" : "14343511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468433962952425472\/VU87Ljmz_normal.jpeg",
      "id" : 14343511,
      "verified" : false
    }
  },
  "id" : 6669882606,
  "created_at" : "2009-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Telegraph News",
      "screen_name" : "TelegraphNews",
      "indices" : [ 3, 17 ],
      "id_str" : "14138785",
      "id" : 14138785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6670702136",
  "text" : "RT @TelegraphNews Tiger, lion and bear form unusual friendship http:\/\/bit.ly\/4INp42",
  "id" : 6670702136,
  "created_at" : "2009-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Widdershoven",
      "screen_name" : "mucheasier",
      "indices" : [ 3, 14 ],
      "id_str" : "15213540",
      "id" : 15213540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6677442374",
  "text" : "RT @mucheasier checking out this great magazine                        http:\/\/tinyurl.com\/yk28lx4",
  "id" : 6677442374,
  "created_at" : "2009-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6630041999",
  "text" : "enjoying a quiet am before hubby leaves for \"play date\"",
  "id" : 6630041999,
  "created_at" : "2009-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6602500495",
  "text" : "hubby took away my corner to make room for tree.. now I'm all discombobulated.. sigh.",
  "id" : 6602500495,
  "created_at" : "2009-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Aimee D",
      "screen_name" : "Aimee_B_Loved",
      "indices" : [ 15, 29 ],
      "id_str" : "15679149",
      "id" : 15679149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6605403109",
  "text" : "RT @BestAt: RT @Aimee_B_Loved: Whoever decided that chocolate fountains are only for special occasions is no friend of mine.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aimee D",
        "screen_name" : "Aimee_B_Loved",
        "indices" : [ 3, 17 ],
        "id_str" : "15679149",
        "id" : 15679149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6604647425",
    "text" : "RT @Aimee_B_Loved: Whoever decided that chocolate fountains are only for special occasions is no friend of mine.",
    "id" : 6604647425,
    "created_at" : "2009-12-12 17:49:09 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 6605403109,
  "created_at" : "2009-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "HaywoodStubble",
      "indices" : [ 3, 18 ],
      "id_str" : "15887107",
      "id" : 15887107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6605409628",
  "text" : "RT @HaywoodStubble: It's always too early to quit. -Norman Vincent Peale",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6605330513",
    "text" : "It's always too early to quit. -Norman Vincent Peale",
    "id" : 6605330513,
    "created_at" : "2009-12-12 18:17:58 +0000",
    "user" : {
      "name" : "Dave",
      "screen_name" : "HaywoodStubble",
      "protected" : false,
      "id_str" : "15887107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/284939831\/ScreenHunter_195_normal.jpg",
      "id" : 15887107,
      "verified" : false
    }
  },
  "id" : 6605409628,
  "created_at" : "2009-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6606138206",
  "text" : "Understanding Law of Attraction http:\/\/hxy9h.th8.us",
  "id" : 6606138206,
  "created_at" : "2009-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6610669866",
  "text" : "been watching Polar Express with hubby and dog : )",
  "id" : 6610669866,
  "created_at" : "2009-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6570621780",
  "text" : "I did 30 taekwondo situps yesterday... barely.. lol.",
  "id" : 6570621780,
  "created_at" : "2009-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6578997208",
  "text" : "@deucehartley how do you figure that out? tia : )",
  "id" : 6578997208,
  "created_at" : "2009-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6518699212",
  "text" : "I love leadership night at taekwondo! : )",
  "id" : 6518699212,
  "created_at" : "2009-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    }, {
      "name" : "Dr. Karen Becker",
      "screen_name" : "drkarenbecker",
      "indices" : [ 16, 30 ],
      "id_str" : "59017872",
      "id" : 59017872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6518823548",
  "text" : "RT @mercola: RT @drkarenbecker: Oh, this whistling puppy is so adorable :) http:\/\/bit.ly\/88KeoO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Karen Becker",
        "screen_name" : "drkarenbecker",
        "indices" : [ 3, 17 ],
        "id_str" : "59017872",
        "id" : 59017872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6517877660",
    "text" : "RT @drkarenbecker: Oh, this whistling puppy is so adorable :) http:\/\/bit.ly\/88KeoO",
    "id" : 6517877660,
    "created_at" : "2009-12-10 02:28:09 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 6518823548,
  "created_at" : "2009-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Marty Misner",
      "screen_name" : "MartyMisner",
      "indices" : [ 20, 32 ],
      "id_str" : "22883967",
      "id" : 22883967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 96, 102 ]
    }, {
      "text" : "encouragement",
      "indices" : [ 103, 117 ]
    }, {
      "text" : "lt",
      "indices" : [ 118, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6518845915",
  "text" : "RT @Encouraging: RT @martymisner Todays mighty oak is just yesterdays nut that held its ground! #quote #encouragement #lt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marty Misner",
        "screen_name" : "MartyMisner",
        "indices" : [ 3, 15 ],
        "id_str" : "22883967",
        "id" : 22883967
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 79, 85 ]
      }, {
        "text" : "encouragement",
        "indices" : [ 86, 100 ]
      }, {
        "text" : "lt",
        "indices" : [ 101, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6510933998",
    "text" : "RT @martymisner Todays mighty oak is just yesterdays nut that held its ground! #quote #encouragement #lt",
    "id" : 6510933998,
    "created_at" : "2009-12-09 22:32:28 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 6518845915,
  "created_at" : "2009-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6500668626",
  "text" : "dog is helping daddy plow today.. and wow, we got some big wind going on!",
  "id" : 6500668626,
  "created_at" : "2009-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Better",
      "screen_name" : "JasonBetter",
      "indices" : [ 3, 15 ],
      "id_str" : "18510420",
      "id" : 18510420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6501005184",
  "text" : "RT @JasonBetter: A forest made of stone!?! http:\/\/ping.fm\/4HTWT - Awesome pics!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6249844090",
    "text" : "A forest made of stone!?! http:\/\/ping.fm\/4HTWT - Awesome pics!",
    "id" : 6249844090,
    "created_at" : "2009-12-01 22:51:13 +0000",
    "user" : {
      "name" : "Jason Better",
      "screen_name" : "JasonBetter",
      "protected" : false,
      "id_str" : "18510420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69149136\/picture-19502_normal.jpg",
      "id" : 18510420,
      "verified" : false
    }
  },
  "id" : 6501005184,
  "created_at" : "2009-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6502407199",
  "text" : "halfway through reading \"Code Name: God\" by Mani Bhaumik",
  "id" : 6502407199,
  "created_at" : "2009-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6503727692",
  "text" : "Why is Jon Olson switching from Aweber to TrafficWave.net? http:\/\/bit.ly\/7s8yp6 I'd be honored if you join me! http:\/\/budurl.com\/bestsystem",
  "id" : 6503727692,
  "created_at" : "2009-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "salesmoms",
      "screen_name" : "salesmoms",
      "indices" : [ 3, 13 ],
      "id_str" : "18640112",
      "id" : 18640112
    }, {
      "name" : "salesmoms",
      "screen_name" : "salesmoms",
      "indices" : [ 22, 32 ],
      "id_str" : "18640112",
      "id" : 18640112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6503831612",
  "text" : "RT @salesmoms: Follow @salesmoms to stay up-to-date w\/ direct sales news. RT this message to enter to win over $600 in FREE advertising  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "salesmoms",
        "screen_name" : "salesmoms",
        "indices" : [ 7, 17 ],
        "id_str" : "18640112",
        "id" : 18640112
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6503517278",
    "text" : "Follow @salesmoms to stay up-to-date w\/ direct sales news. RT this message to enter to win over $600 in FREE advertising for 2010!",
    "id" : 6503517278,
    "created_at" : "2009-12-09 18:01:34 +0000",
    "user" : {
      "name" : "salesmoms",
      "screen_name" : "salesmoms",
      "protected" : false,
      "id_str" : "18640112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69709888\/salesmoms125x125_normal.gif",
      "id" : 18640112,
      "verified" : false
    }
  },
  "id" : 6503831612,
  "created_at" : "2009-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6446985993",
  "text" : "getting ready to watch \"The Office\" at 7:30. A few weeks ago or so I became addicted!",
  "id" : 6446985993,
  "created_at" : "2009-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6464621051",
  "text" : "fixed my ipod touch volume by doing reset.. google rocks!",
  "id" : 6464621051,
  "created_at" : "2009-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6464814915",
  "text" : "Anissa is showing us how it's done. God bless her! http:\/\/www.hope4peyton.org\/2009\/power-of-prayer\/",
  "id" : 6464814915,
  "created_at" : "2009-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6475538198",
  "text" : "How to Survive a Bad Day &#8211; Article by Christine Kane - http:\/\/www.contemplatethis.com\/archives\/945",
  "id" : 6475538198,
  "created_at" : "2009-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laura sanchez rey",
      "screen_name" : "LauraRey",
      "indices" : [ 3, 12 ],
      "id_str" : "4213879523",
      "id" : 4213879523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6417457597",
  "text" : "RT @laurarey: Children seldom misquote. In fact, they usually repeat word for word what you shouldn't have said. \nAuthor Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6145883039",
    "text" : "Children seldom misquote. In fact, they usually repeat word for word what you shouldn't have said. \nAuthor Unknown",
    "id" : 6145883039,
    "created_at" : "2009-11-28 17:25:38 +0000",
    "user" : {
      "name" : "Chica 4 Change",
      "screen_name" : "HowIZYourSoul",
      "protected" : false,
      "id_str" : "19378287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666252343441166337\/27Xv-Mea_normal.jpg",
      "id" : 19378287,
      "verified" : false
    }
  },
  "id" : 6417457597,
  "created_at" : "2009-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Sky St. John",
      "screen_name" : "skystjohn",
      "indices" : [ 23, 33 ],
      "id_str" : "151246101",
      "id" : 151246101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6436758548",
  "text" : "RT @robin_usanamom: RT @skystjohn: Teach only love, for that is what you are. ACIM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rev. Sky St. John",
        "screen_name" : "skystjohn",
        "indices" : [ 3, 13 ],
        "id_str" : "151246101",
        "id" : 151246101
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6358730682",
    "text" : "RT @skystjohn: Teach only love, for that is what you are. ACIM",
    "id" : 6358730682,
    "created_at" : "2009-12-05 03:18:18 +0000",
    "user" : {
      "name" : "Robin Thomas",
      "screen_name" : "robinthomas1",
      "protected" : false,
      "id_str" : "16232284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656939577505026048\/_rXcT6Hi_normal.jpg",
      "id" : 16232284,
      "verified" : false
    }
  },
  "id" : 6436758548,
  "created_at" : "2009-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bit Rebels",
      "screen_name" : "bitrebels",
      "indices" : [ 23, 33 ],
      "id_str" : "45369648",
      "id" : 45369648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6436802756",
  "text" : "RT @robin_usanamom: RT @bitrebels 8 Tips for Spotting a Spam Twitter Follower | Bit Rebels http:\/\/bit.ly\/6SuCkv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bit Rebels",
        "screen_name" : "bitrebels",
        "indices" : [ 3, 13 ],
        "id_str" : "45369648",
        "id" : 45369648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6419273851",
    "text" : "RT @bitrebels 8 Tips for Spotting a Spam Twitter Follower | Bit Rebels http:\/\/bit.ly\/6SuCkv",
    "id" : 6419273851,
    "created_at" : "2009-12-07 03:07:32 +0000",
    "user" : {
      "name" : "Robin Thomas",
      "screen_name" : "robinthomas1",
      "protected" : false,
      "id_str" : "16232284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656939577505026048\/_rXcT6Hi_normal.jpg",
      "id" : 16232284,
      "verified" : false
    }
  },
  "id" : 6436802756,
  "created_at" : "2009-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SimpleEncouragement",
      "indices" : [ 113, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6446484373",
  "text" : "RT @Encouraging: Whether you know it or not, by bedtime tonight your life will have had a meaning and a purpose. #SimpleEncouragement",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SimpleEncouragement",
        "indices" : [ 96, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6428739232",
    "text" : "Whether you know it or not, by bedtime tonight your life will have had a meaning and a purpose. #SimpleEncouragement",
    "id" : 6428739232,
    "created_at" : "2009-12-07 12:04:45 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 6446484373,
  "created_at" : "2009-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6386051954",
  "text" : "watching iquit icarly and waiting for hubby to finish up at party",
  "id" : 6386051954,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Moose",
      "screen_name" : "PeteMoose",
      "indices" : [ 3, 13 ],
      "id_str" : "63542215",
      "id" : 63542215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6386840247",
  "text" : "RT @PeteMoose: The Great State of Vermont is going to KILL me on Jan. 5 please save me by signing petition!  http:\/\/bit.ly\/4wtfD3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6285214934",
    "text" : "The Great State of Vermont is going to KILL me on Jan. 5 please save me by signing petition!  http:\/\/bit.ly\/4wtfD3",
    "id" : 6285214934,
    "created_at" : "2009-12-02 23:35:09 +0000",
    "user" : {
      "name" : "Pete Moose",
      "screen_name" : "PeteMoose",
      "protected" : false,
      "id_str" : "63542215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643603789\/moose_normal.gif",
      "id" : 63542215,
      "verified" : false
    }
  },
  "id" : 6386840247,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6388499259",
  "text" : "\"The unfortunate need people who will be kind to them; the\nprosperous need people to be kind to.\" -Aristotle",
  "id" : 6388499259,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6400904921",
  "text" : "drinking my coffee and still nursing a sore neck",
  "id" : 6400904921,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "salesmoms",
      "screen_name" : "salesmoms",
      "indices" : [ 3, 13 ],
      "id_str" : "18640112",
      "id" : 18640112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6404418584",
  "text" : "RT @salesmoms: Sales MOMS is Looking for Consultants Who Want to Recruit  http:\/\/bit.ly\/4yuGQU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6349437904",
    "text" : "Sales MOMS is Looking for Consultants Who Want to Recruit  http:\/\/bit.ly\/4yuGQU",
    "id" : 6349437904,
    "created_at" : "2009-12-04 21:14:26 +0000",
    "user" : {
      "name" : "salesmoms",
      "screen_name" : "salesmoms",
      "protected" : false,
      "id_str" : "18640112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69709888\/salesmoms125x125_normal.gif",
      "id" : 18640112,
      "verified" : false
    }
  },
  "id" : 6404418584,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]