Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "judy keller",
      "screen_name" : "spiritvista",
      "indices" : [ 3, 15 ],
      "id_str" : "55017869",
      "id" : 55017869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8976305387208704",
  "text" : "RT @spiritvista: Love is the absence of judgment. ~Dalai Lama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7576688678404096",
    "text" : "Love is the absence of judgment. ~Dalai Lama",
    "id" : 7576688678404096,
    "created_at" : "2010-11-24 23:29:58 +0000",
    "user" : {
      "name" : "judy keller",
      "screen_name" : "spiritvista",
      "protected" : false,
      "id_str" : "55017869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666427624\/Judy_normal.jpg",
      "id" : 55017869,
      "verified" : false
    }
  },
  "id" : 8976305387208704,
  "created_at" : "2010-11-28 20:11:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "dredpiraterob",
      "screen_name" : "dredpiraterob",
      "indices" : [ 55, 69 ],
      "id_str" : "17750056",
      "id" : 17750056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8947512626905088",
  "text" : "RT @ZachsMind: Who decides how \"well being\" is defined @dredpiraterob look at the Tarzan scenario. I'm not saying THAT's real, but who d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dredpiraterob",
        "screen_name" : "dredpiraterob",
        "indices" : [ 40, 54 ],
        "id_str" : "17750056",
        "id" : 17750056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8945237573505024",
    "text" : "Who decides how \"well being\" is defined @dredpiraterob look at the Tarzan scenario. I'm not saying THAT's real, but who decides?",
    "id" : 8945237573505024,
    "created_at" : "2010-11-28 18:08:05 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 8947512626905088,
  "created_at" : "2010-11-28 18:17:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8669097738899456",
  "text" : "Looking foward to this: 12\/5 on Bio - I Survived... Beyond And Back http:\/\/bit.ly\/hhuk8L",
  "id" : 8669097738899456,
  "created_at" : "2010-11-27 23:50:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8589740496388096",
  "geo" : { },
  "id_str" : "8602243783725056",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts only get credit if you tweet it AND comment that you tweeted it on his blog",
  "id" : 8602243783725056,
  "in_reply_to_status_id" : 8589740496388096,
  "created_at" : "2010-11-27 19:25:09 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8599985796943872",
  "text" : "Howlathon \u00BB Life With Dogs http:\/\/bit.ly\/eWJUYe",
  "id" : 8599985796943872,
  "created_at" : "2010-11-27 19:16:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8573176237789184",
  "geo" : { },
  "id_str" : "8588785218494464",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts each tweet you send out on your timeline..but you must comment on author's blog each time also.",
  "id" : 8588785218494464,
  "in_reply_to_status_id" : 8573176237789184,
  "created_at" : "2010-11-27 18:31:40 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8564296627781632",
  "text" : "I entered the BLANK SLATE Kindle Giveaway Contest. To Enter: http:\/\/bit.ly\/b2vbLk Each Tweet is 1 entry! (see blog post 4 info)",
  "id" : 8564296627781632,
  "created_at" : "2010-11-27 16:54:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8363996063211520",
  "text" : "I Know What You\u2019re Thinking \u00AB Spritzophrenia http:\/\/bit.ly\/ecjUqc",
  "id" : 8363996063211520,
  "created_at" : "2010-11-27 03:38:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8358271073132544",
  "text" : "Emergency Veterinary Care Assistance Program | Prince Chunk Foundation, Inc. http:\/\/bit.ly\/eBty8B NJ,NY,PA",
  "id" : 8358271073132544,
  "created_at" : "2010-11-27 03:15:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cyndi Hunter",
      "screen_name" : "Fairlite",
      "indices" : [ 30, 39 ],
      "id_str" : "81249076",
      "id" : 81249076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8355682545836033",
  "text" : "RT @Jeansandpolo: Awwww!!! RT @Fairlite Two raccoons are sleeping on my balcony... cutest deviants ever http:\/\/ht.ly\/3g1PZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cyndi Hunter",
        "screen_name" : "Fairlite",
        "indices" : [ 12, 21 ],
        "id_str" : "81249076",
        "id" : 81249076
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8335543431598080",
    "text" : "Awwww!!! RT @Fairlite Two raccoons are sleeping on my balcony... cutest deviants ever http:\/\/ht.ly\/3g1PZ",
    "id" : 8335543431598080,
    "created_at" : "2010-11-27 01:45:23 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 8355682545836033,
  "created_at" : "2010-11-27 03:05:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8355390496444417",
  "text" : "RT @mimismutts: Grdtr to Grson: That smoked turkey wasn't very good. Grson: I guess turkeys shouldn't smoke either",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8340258542325761",
    "text" : "Grdtr to Grson: That smoked turkey wasn't very good. Grson: I guess turkeys shouldn't smoke either",
    "id" : 8340258542325761,
    "created_at" : "2010-11-27 02:04:07 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 8355390496444417,
  "created_at" : "2010-11-27 03:04:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8331849600344065",
  "text" : "RT @amazonmp3: There's still time to use code GET3MP3S to get $3 towards MP3s at Amazon MP3. Full details: http:\/\/amzn.to\/e47bEs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8327960926879744",
    "text" : "There's still time to use code GET3MP3S to get $3 towards MP3s at Amazon MP3. Full details: http:\/\/amzn.to\/e47bEs",
    "id" : 8327960926879744,
    "created_at" : "2010-11-27 01:15:15 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 8331849600344065,
  "created_at" : "2010-11-27 01:30:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 0, 12 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8305667370647552",
  "geo" : { },
  "id_str" : "8319400415330304",
  "in_reply_to_user_id" : 51846392,
  "text" : "@Jeweldspear ((hugs))",
  "id" : 8319400415330304,
  "in_reply_to_status_id" : 8305667370647552,
  "created_at" : "2010-11-27 00:41:14 +0000",
  "in_reply_to_screen_name" : "Jeweldspear",
  "in_reply_to_user_id_str" : "51846392",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifelesson",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8283046797119489",
  "text" : "What if you could go back in time and warn yourself? Not the miracle cure-all... http:\/\/bit.ly\/eqJucn #lifelesson",
  "id" : 8283046797119489,
  "created_at" : "2010-11-26 22:16:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8279501964316672",
  "text" : "I cannot condemn age and wish for youth. Age is what brought me the wisdom I have and treasure.",
  "id" : 8279501964316672,
  "created_at" : "2010-11-26 22:02:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8210434721062913",
  "geo" : { },
  "id_str" : "8212352780468228",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts made sense to me. wishing you wonderful T-day wkend as well. : )",
  "id" : 8212352780468228,
  "in_reply_to_status_id" : 8210434721062913,
  "created_at" : "2010-11-26 17:35:52 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8210434721062913",
  "geo" : { },
  "id_str" : "8211696535474176",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts muah!! : )",
  "id" : 8211696535474176,
  "in_reply_to_status_id" : 8210434721062913,
  "created_at" : "2010-11-26 17:33:15 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8201674367705088",
  "geo" : { },
  "id_str" : "8203547866828801",
  "in_reply_to_user_id" : 23539037,
  "text" : "@RMoGib don't forget to comment on his blog for your entry : )",
  "id" : 8203547866828801,
  "in_reply_to_status_id" : 8201674367705088,
  "created_at" : "2010-11-26 17:00:52 +0000",
  "in_reply_to_screen_name" : "OhYouGirl",
  "in_reply_to_user_id_str" : "23539037",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 0, 12 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8196583082434560",
  "geo" : { },
  "id_str" : "8197359804620800",
  "in_reply_to_user_id" : 51846392,
  "text" : "@Jeweldspear Happy Birthday! 46 is a good number. : )",
  "id" : 8197359804620800,
  "in_reply_to_status_id" : 8196583082434560,
  "created_at" : "2010-11-26 16:36:17 +0000",
  "in_reply_to_screen_name" : "Jeweldspear",
  "in_reply_to_user_id_str" : "51846392",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake",
      "screen_name" : "FalconPiss911",
      "indices" : [ 3, 17 ],
      "id_str" : "142885184",
      "id" : 142885184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8196883096801280",
  "text" : "RT @FalconPiss911: Why do so many believers want the world to end so badly? Do they wish apocalypse on billions of people? This has neve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8192656098205696",
    "text" : "Why do so many believers want the world to end so badly? Do they wish apocalypse on billions of people? This has never made any sense to me.",
    "id" : 8192656098205696,
    "created_at" : "2010-11-26 16:17:36 +0000",
    "user" : {
      "name" : "Blake",
      "screen_name" : "FalconPiss911",
      "protected" : false,
      "id_str" : "142885184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789064328943132672\/TIaqYLCr_normal.jpg",
      "id" : 142885184,
      "verified" : false
    }
  },
  "id" : 8196883096801280,
  "created_at" : "2010-11-26 16:34:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8196079631728640",
  "text" : "RT @RMoGib: New footrest. http:\/\/yfrog.com\/ghsxp0j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8191158500990976",
    "text" : "New footrest. http:\/\/yfrog.com\/ghsxp0j",
    "id" : 8191158500990976,
    "created_at" : "2010-11-26 16:11:39 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 8196079631728640,
  "created_at" : "2010-11-26 16:31:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8195200543358976",
  "text" : "I entered the BLANK SLATE Kindle Giveaway Contest. To Enter: http:\/\/bit.ly\/b2vbLk Each Tweet is 1 entry!",
  "id" : 8195200543358976,
  "created_at" : "2010-11-26 16:27:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8192396776972289",
  "text" : "my dear BIL fixed my laptop! what a sweetie! \u2665",
  "id" : 8192396776972289,
  "created_at" : "2010-11-26 16:16:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7994125550882818",
  "geo" : { },
  "id_str" : "7998801071579137",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves awww, that's so sweet! : )",
  "id" : 7998801071579137,
  "in_reply_to_status_id" : 7994125550882818,
  "created_at" : "2010-11-26 03:27:17 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Ann Huckaby",
      "screen_name" : "Ginaration",
      "indices" : [ 3, 14 ],
      "id_str" : "106882460",
      "id" : 106882460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankful",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7994143519281153",
  "text" : "RT @Ginaration: I'm #thankful for the love that is shown to me from others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thankful",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7986020263919617",
    "text" : "I'm #thankful for the love that is shown to me from others.",
    "id" : 7986020263919617,
    "created_at" : "2010-11-26 02:36:30 +0000",
    "user" : {
      "name" : "Gina Ann Huckaby",
      "screen_name" : "Ginaration",
      "protected" : false,
      "id_str" : "106882460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2613291732\/image_normal.jpg",
      "id" : 106882460,
      "verified" : false
    }
  },
  "id" : 7994143519281153,
  "created_at" : "2010-11-26 03:08:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7989512797954048",
  "text" : "LOL - Enough Social Interaction Tee http:\/\/amzn.to\/h6MK32",
  "id" : 7989512797954048,
  "created_at" : "2010-11-26 02:50:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 9, 20 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7956073751257088",
  "text" : "ICYMI RT @moosebegab: I\u2019ve created my profile at about.me! Check me out: http:\/\/about.me\/abfabgab and sign up at http:\/\/about.me.",
  "id" : 7956073751257088,
  "created_at" : "2010-11-26 00:37:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7824491535147010",
  "text" : "So very thankful for all my wonderful tweeps. Love you guys \u2665",
  "id" : 7824491535147010,
  "created_at" : "2010-11-25 15:54:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7638744031043584",
  "text" : "RT @bend_time: every time i look up, my dog is watching me. my heart aches. he smiles at me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6561628363427840",
    "text" : "every time i look up, my dog is watching me. my heart aches. he smiles at me.",
    "id" : 6561628363427840,
    "created_at" : "2010-11-22 04:16:28 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 7638744031043584,
  "created_at" : "2010-11-25 03:36:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7637988922105856",
  "text" : "RT @bend_time: 'when i seek only love, i will see nothing else.' ACIM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7160025864732672",
    "text" : "'when i seek only love, i will see nothing else.' ACIM",
    "id" : 7160025864732672,
    "created_at" : "2010-11-23 19:54:17 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 7637988922105856,
  "created_at" : "2010-11-25 03:33:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7637881493397504",
  "text" : "RT @bend_time: ppl r being arrested 4 things they say on twitter- anything tht can be construed as a 'terrorist threat.' which soon will ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7490588274327552",
    "text" : "ppl r being arrested 4 things they say on twitter- anything tht can be construed as a 'terrorist threat.' which soon will be any complaint",
    "id" : 7490588274327552,
    "created_at" : "2010-11-24 17:47:50 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 7637881493397504,
  "created_at" : "2010-11-25 03:33:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7267207708934144",
  "geo" : { },
  "id_str" : "7270249296564225",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves ((hugs))",
  "id" : 7270249296564225,
  "in_reply_to_status_id" : 7267207708934144,
  "created_at" : "2010-11-24 03:12:17 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7235998215835651",
  "text" : "RT @CreativeArtwks: Last night I stayed up late playing poker w\/Tarot cards. I got a full house & 4 people died.- Steven Wright",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7232047164690432",
    "text" : "Last night I stayed up late playing poker w\/Tarot cards. I got a full house & 4 people died.- Steven Wright",
    "id" : 7232047164690432,
    "created_at" : "2010-11-24 00:40:29 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 7235998215835651,
  "created_at" : "2010-11-24 00:56:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7235432668471296",
  "text" : "RT @stevetheseeker: Jesus' statement no one has ever gone up to heaven but he who came down from heaven refers the fact you can't drag y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7235012176912384",
    "text" : "Jesus' statement no one has ever gone up to heaven but he who came down from heaven refers the fact you can't drag your ego into heaven",
    "id" : 7235012176912384,
    "created_at" : "2010-11-24 00:52:15 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 7235432668471296,
  "created_at" : "2010-11-24 00:53:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1690\u1685\u1688\u1680\u1690\u1682\u1682\u1690\u1685",
      "screen_name" : "antallan",
      "indices" : [ 3, 12 ],
      "id_str" : "21348792",
      "id" : 21348792
    }, {
      "name" : "laura serra",
      "screen_name" : "lauraserra",
      "indices" : [ 125, 136 ],
      "id_str" : "24957166",
      "id" : 24957166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7204780837445633",
  "text" : "RT @antallan: Sea otters hold hands when they sleep, so they don't drift away from each other http:\/\/twitpic.com\/39kce6 (via @lauraserra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora HD\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "laura serra",
        "screen_name" : "lauraserra",
        "indices" : [ 111, 122 ],
        "id_str" : "24957166",
        "id" : 24957166
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7203875845046272",
    "text" : "Sea otters hold hands when they sleep, so they don't drift away from each other http:\/\/twitpic.com\/39kce6 (via @lauraserra) ~ So sweet! ;-)",
    "id" : 7203875845046272,
    "created_at" : "2010-11-23 22:48:32 +0000",
    "user" : {
      "name" : "\u1690\u1685\u1688\u1680\u1690\u1682\u1682\u1690\u1685",
      "screen_name" : "antallan",
      "protected" : false,
      "id_str" : "21348792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746282540651188225\/_EQXj6pK_normal.jpg",
      "id" : 21348792,
      "verified" : false
    }
  },
  "id" : 7204780837445633,
  "created_at" : "2010-11-23 22:52:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7187860444680194",
  "text" : "I\u2019ve created my profile at about.me! Check me out: http:\/\/about.me\/abfabgab and sign up at http:\/\/about.me.",
  "id" : 7187860444680194,
  "created_at" : "2010-11-23 21:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "batman",
      "screen_name" : "nonidentity",
      "indices" : [ 3, 15 ],
      "id_str" : "99486198",
      "id" : 99486198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7159795912024064",
  "text" : "RT @NonIdentity: I have just remembered I have a whole fudge cake to comfort eat with. *dances with glee*",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7153090310443009",
    "text" : "I have just remembered I have a whole fudge cake to comfort eat with. *dances with glee*",
    "id" : 7153090310443009,
    "created_at" : "2010-11-23 19:26:44 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 7159795912024064,
  "created_at" : "2010-11-23 19:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7139818253320195",
  "text" : "think my laptop infected me.. tummy not so good today :(",
  "id" : 7139818253320195,
  "created_at" : "2010-11-23 18:33:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7139605082021888",
  "text" : "RT @Buddhaworld: just read that as farther a watch is away from earth as slower it moves, gravity is the reason.time is relative-love bu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7138328784670720",
    "text" : "just read that as farther a watch is away from earth as slower it moves, gravity is the reason.time is relative-love buddha volko.",
    "id" : 7138328784670720,
    "created_at" : "2010-11-23 18:28:04 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 7139605082021888,
  "created_at" : "2010-11-23 18:33:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7129141912535040",
  "text" : "The 25 Cutest Pictures Of Pua The Pet Anteater http:\/\/bzfd.it\/eyyrMY",
  "id" : 7129141912535040,
  "created_at" : "2010-11-23 17:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary-Anne Reed",
      "screen_name" : "HPSelf",
      "indices" : [ 3, 10 ],
      "id_str" : "43237308",
      "id" : 43237308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6909348575969280",
  "text" : "RT @HPSelf: Choose to love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6905444329066496",
    "text" : "Choose to love.",
    "id" : 6905444329066496,
    "created_at" : "2010-11-23 03:02:40 +0000",
    "user" : {
      "name" : "Mary-Anne Reed",
      "screen_name" : "HPSelf",
      "protected" : false,
      "id_str" : "43237308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614673460355162113\/HJzNCSN8_normal.jpg",
      "id" : 43237308,
      "verified" : false
    }
  },
  "id" : 6909348575969280,
  "created_at" : "2010-11-23 03:18:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penn Jillette",
      "screen_name" : "pennjillette",
      "indices" : [ 3, 16 ],
      "id_str" : "14749383",
      "id" : 14749383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6902333078245376",
  "text" : "RT @pennjillette: Some freedom-fighters flying w\/ kilts (nothing under them of course) to \"Opt Out\" on 11\/ 24.  If government wants cock ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6899926185279488",
    "text" : "Some freedom-fighters flying w\/ kilts (nothing under them of course) to \"Opt Out\" on 11\/ 24.  If government wants cock, let them have it.",
    "id" : 6899926185279488,
    "created_at" : "2010-11-23 02:40:45 +0000",
    "user" : {
      "name" : "Penn Jillette",
      "screen_name" : "pennjillette",
      "protected" : false,
      "id_str" : "14749383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585988687210553346\/CTxPyEI6_normal.jpg",
      "id" : 14749383,
      "verified" : true
    }
  },
  "id" : 6902333078245376,
  "created_at" : "2010-11-23 02:50:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "twinkle hehe",
      "screen_name" : "selenaisrad",
      "indices" : [ 99, 111 ],
      "id_str" : "781976761",
      "id" : 781976761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6902258457387008",
  "text" : "RT @brandonrofl: Yeah, most people follow me while they're wasted. There's no other explanation RT @selenaisrad I don't remember followi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "twinkle hehe",
        "screen_name" : "selenaisrad",
        "indices" : [ 82, 94 ],
        "id_str" : "781976761",
        "id" : 781976761
      }, {
        "name" : "Vanilla Ice",
        "screen_name" : "brandonrofl",
        "indices" : [ 122, 134 ],
        "id_str" : "1934461332",
        "id" : 1934461332
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6901820446212096",
    "text" : "Yeah, most people follow me while they're wasted. There's no other explanation RT @selenaisrad I don't remember following @brandonrofl..",
    "id" : 6901820446212096,
    "created_at" : "2010-11-23 02:48:16 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 6902258457387008,
  "created_at" : "2010-11-23 02:50:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "Odd Mama",
      "screen_name" : "StudioOdd",
      "indices" : [ 60, 70 ],
      "id_str" : "14213140",
      "id" : 14213140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6901978688921600",
  "text" : "RT @CoyoteSings: You should call it The Smashed Pumpkin. RT @StudioOdd: Eggnog, pumpkin pie spice and tequila... That is all",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Odd Mama",
        "screen_name" : "StudioOdd",
        "indices" : [ 43, 53 ],
        "id_str" : "14213140",
        "id" : 14213140
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6896678233702400",
    "text" : "You should call it The Smashed Pumpkin. RT @StudioOdd: Eggnog, pumpkin pie spice and tequila... That is all",
    "id" : 6896678233702400,
    "created_at" : "2010-11-23 02:27:50 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 6901978688921600,
  "created_at" : "2010-11-23 02:48:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Regina Schrambling",
      "screen_name" : "gastropoda",
      "indices" : [ 3, 14 ],
      "id_str" : "15853490",
      "id" : 15853490
    }, {
      "name" : "Susan Jordan",
      "screen_name" : "Moonbootica",
      "indices" : [ 23, 35 ],
      "id_str" : "16984207",
      "id" : 16984207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6901319059116032",
  "text" : "RT @gastropoda: Nod to @Moonbootica Friday cat blogging: mine, all mine http:\/\/yfrog.com\/6156kaj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Jordan",
        "screen_name" : "Moonbootica",
        "indices" : [ 7, 19 ],
        "id_str" : "16984207",
        "id" : 16984207
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5690155172106240",
    "text" : "Nod to @Moonbootica Friday cat blogging: mine, all mine http:\/\/yfrog.com\/6156kaj",
    "id" : 5690155172106240,
    "created_at" : "2010-11-19 18:33:33 +0000",
    "user" : {
      "name" : "Regina Schrambling",
      "screen_name" : "gastropoda",
      "protected" : false,
      "id_str" : "15853490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/138401913\/reginaTwitter_normal.jpg",
      "id" : 15853490,
      "verified" : false
    }
  },
  "id" : 6901319059116032,
  "created_at" : "2010-11-23 02:46:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6891895674376192",
  "text" : "@tragic_pizza Ouch 2K?? sorry your car is sick. I happen to love it when you say something offensive ((hugs))",
  "id" : 6891895674376192,
  "created_at" : "2010-11-23 02:08:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6773605429944320",
  "geo" : { },
  "id_str" : "6887562819936258",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott I never realized what it really looked like (since I RT a lot and never really see my tweets)..hmm..",
  "id" : 6887562819936258,
  "in_reply_to_status_id" : 6773605429944320,
  "created_at" : "2010-11-23 01:51:37 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6735370175647744",
  "text" : "New! FREE Amazon $3 Credit for MP3s (US only) exp 11\/29 - MobileRead Forums http:\/\/bit.ly\/aq6097 [Like it? http:\/\/bit.ly\/cluQMT ]",
  "id" : 6735370175647744,
  "created_at" : "2010-11-22 15:46:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6734491070500864",
  "text" : "Boy's best friend ~ Dog mourns loss of owner, 15 http:\/\/bit.ly\/dhWMeK [Like it? http:\/\/bit.ly\/9jTy7s ]",
  "id" : 6734491070500864,
  "created_at" : "2010-11-22 15:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6514282028072960",
  "text" : "RT @tonyrobbins: LOVE  is the ladder from Hell to Heavan. ....Climb it today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6500544709402624",
    "text" : "LOVE  is the ladder from Hell to Heavan. ....Climb it today",
    "id" : 6500544709402624,
    "created_at" : "2010-11-22 00:13:45 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 6514282028072960,
  "created_at" : "2010-11-22 01:08:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6445288252248064",
  "text" : "RT @bcmouser: @tragic_pizza wow! Right on!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6441123178348544",
    "text" : "@tragic_pizza wow! Right on!",
    "id" : 6441123178348544,
    "created_at" : "2010-11-21 20:17:38 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 6445288252248064,
  "created_at" : "2010-11-21 20:34:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6389763959431168",
  "text" : "RT @SangyeH: If u keep the public scared, u can do anything to them with their consent.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6358015359848448",
    "text" : "If u keep the public scared, u can do anything to them with their consent.",
    "id" : 6358015359848448,
    "created_at" : "2010-11-21 14:47:23 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 6389763959431168,
  "created_at" : "2010-11-21 16:53:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6389284256878592",
  "text" : "RT @SangyeH: We're afraid of toothpicks, forks and shoes while terrorists are still finding ways to get bombs on board planes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6360164982587393",
    "text" : "We're afraid of toothpicks, forks and shoes while terrorists are still finding ways to get bombs on board planes.",
    "id" : 6360164982587393,
    "created_at" : "2010-11-21 14:55:56 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 6389284256878592,
  "created_at" : "2010-11-21 16:51:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Present",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "Mindfulness",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6387067013566464",
  "text" : "RT @DharmaTalks: There are No Accidents in the Universe, We create our own reality.  #Present #Mindfulness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Present",
        "indices" : [ 68, 76 ]
      }, {
        "text" : "Mindfulness",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6375115495313408",
    "text" : "There are No Accidents in the Universe, We create our own reality.  #Present #Mindfulness",
    "id" : 6375115495313408,
    "created_at" : "2010-11-21 15:55:20 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 6387067013566464,
  "created_at" : "2010-11-21 16:42:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6386831994126336",
  "text" : "RT @CoyoteSings: \"Wherever you go, go with all your heart.\" -Confucius",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6377434198843392",
    "text" : "\"Wherever you go, go with all your heart.\" -Confucius",
    "id" : 6377434198843392,
    "created_at" : "2010-11-21 16:04:33 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 6386831994126336,
  "created_at" : "2010-11-21 16:41:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forumotion.com",
      "screen_name" : "Forumotion",
      "indices" : [ 3, 14 ],
      "id_str" : "42395459",
      "id" : 42395459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6163437814026240",
  "text" : "RT @Forumotion: We offer free .COM .NET .ORG .BIZ domain names to our active communities on http:\/\/www.forumotion.com :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.gremlinsocial.com\" rel=\"nofollow\"\u003EGremlin Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6162857372688385",
    "text" : "We offer free .COM .NET .ORG .BIZ domain names to our active communities on http:\/\/www.forumotion.com :)",
    "id" : 6162857372688385,
    "created_at" : "2010-11-21 01:51:54 +0000",
    "user" : {
      "name" : "Forumotion.com",
      "screen_name" : "Forumotion",
      "protected" : false,
      "id_str" : "42395459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575300013045108736\/DosHidwi_normal.png",
      "id" : 42395459,
      "verified" : false
    }
  },
  "id" : 6163437814026240,
  "created_at" : "2010-11-21 01:54:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6163203054637056",
  "text" : "I'm trying to send AntiVirus 2010 to Hell.. where it belongs.. One thing I don't mind killing. [Like it? http:\/\/bit.ly\/b4FPZ0 ]",
  "id" : 6163203054637056,
  "created_at" : "2010-11-21 01:53:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ryan",
      "screen_name" : "ChrisDelorey",
      "indices" : [ 3, 16 ],
      "id_str" : "190100756",
      "id" : 190100756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6136287530586112",
  "text" : "RT @chrisdelorey: A Japanese man invents machine that turns plastic back to oil! http:\/\/tinyurl.com\/3amcwtq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6134344867385344",
    "text" : "A Japanese man invents machine that turns plastic back to oil! http:\/\/tinyurl.com\/3amcwtq",
    "id" : 6134344867385344,
    "created_at" : "2010-11-20 23:58:36 +0000",
    "user" : {
      "name" : "Christine DeLorey",
      "screen_name" : "the9numbers",
      "protected" : false,
      "id_str" : "24301880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1288489336\/ChristineDeLorey_normal.jpg",
      "id" : 24301880,
      "verified" : false
    }
  },
  "id" : 6136287530586112,
  "created_at" : "2010-11-21 00:06:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6136034081374209",
  "text" : "RT @Wylieknowords: \"Illegal aliens have always been a problem in the United States. Ask any Indian.\" Robert Orben  www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6133192859852800",
    "text" : "\"Illegal aliens have always been a problem in the United States. Ask any Indian.\" Robert Orben  www.knowords.com",
    "id" : 6133192859852800,
    "created_at" : "2010-11-20 23:54:01 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 6136034081374209,
  "created_at" : "2010-11-21 00:05:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6135528890048512",
  "text" : "RT @Buddhaworld: love can be expressed even in a single tweet, and what a great effect it has.-love buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6130920981536768",
    "text" : "love can be expressed even in a single tweet, and what a great effect it has.-love buddha volko.",
    "id" : 6130920981536768,
    "created_at" : "2010-11-20 23:45:00 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 6135528890048512,
  "created_at" : "2010-11-21 00:03:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6135414704308224",
  "text" : "RT @SangyeH: \u201CIf this country is going 2sacrifice treatg ppl like human beings in the name of safety, then we've alrdy lost the war\u201D htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6130623915757568",
    "text" : "\u201CIf this country is going 2sacrifice treatg ppl like human beings in the name of safety, then we've alrdy lost the war\u201D http:\/\/bit.ly\/cFNlPm",
    "id" : 6130623915757568,
    "created_at" : "2010-11-20 23:43:49 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 6135414704308224,
  "created_at" : "2010-11-21 00:02:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6034027530162176",
  "text" : "LOL The 3 Phases of Owning a Computer - http:\/\/bit.ly\/dxjJmP",
  "id" : 6034027530162176,
  "created_at" : "2010-11-20 17:19:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ninethousandone",
      "screen_name" : "icpchad",
      "indices" : [ 3, 11 ],
      "id_str" : "16603994",
      "id" : 16603994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twitter",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5828618538192896",
  "text" : "RT @icpchad: A paper trail of thought, without the paper. #Twitter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Twitter",
        "indices" : [ 45, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5820279066468353",
    "text" : "A paper trail of thought, without the paper. #Twitter",
    "id" : 5820279066468353,
    "created_at" : "2010-11-20 03:10:37 +0000",
    "user" : {
      "name" : "ninethousandone",
      "screen_name" : "icpchad",
      "protected" : false,
      "id_str" : "16603994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681887434\/modernman533_normal.jpg",
      "id" : 16603994,
      "verified" : false
    }
  },
  "id" : 5828618538192896,
  "created_at" : "2010-11-20 03:43:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Collins",
      "screen_name" : "trib",
      "indices" : [ 3, 8 ],
      "id_str" : "24113",
      "id" : 24113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5818437230141441",
  "text" : "RT @trib: If you own a dog, this is perhaps the most hilarious thing you will ever read\/look at http:\/\/acdl.bz\/a7nShy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nambu.com\/\" rel=\"nofollow\"\u003ENambu\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5796893204418560",
    "text" : "If you own a dog, this is perhaps the most hilarious thing you will ever read\/look at http:\/\/acdl.bz\/a7nShy",
    "id" : 5796893204418560,
    "created_at" : "2010-11-20 01:37:41 +0000",
    "user" : {
      "name" : "Stephen Collins",
      "screen_name" : "trib",
      "protected" : false,
      "id_str" : "24113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749819889062326272\/qaCldOdx_normal.jpg",
      "id" : 24113,
      "verified" : false
    }
  },
  "id" : 5818437230141441,
  "created_at" : "2010-11-20 03:03:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Raine OK",
      "screen_name" : "raine_ok",
      "indices" : [ 24, 33 ],
      "id_str" : "71659765",
      "id" : 71659765
    }, {
      "name" : "Joni Hall",
      "screen_name" : "JoniH007",
      "indices" : [ 34, 43 ],
      "id_str" : "105012421",
      "id" : 105012421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5815996736606208",
  "text" : "RT @ZachsMind: My point @raine_ok @JoniH007 is that no woman is more or less deserving than any other. You're being silly w\/your beauty  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raine OK",
        "screen_name" : "raine_ok",
        "indices" : [ 9, 18 ],
        "id_str" : "71659765",
        "id" : 71659765
      }, {
        "name" : "Joni Hall",
        "screen_name" : "JoniH007",
        "indices" : [ 19, 28 ],
        "id_str" : "105012421",
        "id" : 105012421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5812603506917376",
    "text" : "My point @raine_ok @JoniH007 is that no woman is more or less deserving than any other. You're being silly w\/your beauty pageant.",
    "id" : 5812603506917376,
    "created_at" : "2010-11-20 02:40:07 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 5815996736606208,
  "created_at" : "2010-11-20 02:53:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Coyle",
      "screen_name" : "dan_coyle",
      "indices" : [ 3, 13 ],
      "id_str" : "42264700",
      "id" : 42264700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5815262234288128",
  "text" : "RT @dan_coyle: You are the miracle that\n you keep waiting for.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5807252896227328",
    "text" : "You are the miracle that\n you keep waiting for.",
    "id" : 5807252896227328,
    "created_at" : "2010-11-20 02:18:51 +0000",
    "user" : {
      "name" : "Dan Coyle",
      "screen_name" : "dan_coyle",
      "protected" : false,
      "id_str" : "42264700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494534909197680641\/frLVs6wP_normal.jpeg",
      "id" : 42264700,
      "verified" : false
    }
  },
  "id" : 5815262234288128,
  "created_at" : "2010-11-20 02:50:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5778863300812801",
  "text" : "Contrarians Pour On the Concrete - highly modern home http:\/\/yhoo.it\/djp9HQ",
  "id" : 5778863300812801,
  "created_at" : "2010-11-20 00:26:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5754517962366978",
  "text" : "RT @CoyoteSings: Officially gradutate from the Phlebotomy program today. Am now one of the world's biggest mosquitos looking for a job.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5751105254326272",
    "text" : "Officially gradutate from the Phlebotomy program today. Am now one of the world's biggest mosquitos looking for a job.",
    "id" : 5751105254326272,
    "created_at" : "2010-11-19 22:35:45 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 5754517962366978,
  "created_at" : "2010-11-19 22:49:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5754359744827392",
  "text" : "RT @thesexyatheist: So glad I live in the States. http:\/\/bit.ly\/bvXGjK  Chinese woman sent to labor camp for tweet.  We would all be in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5751851202904064",
    "text" : "So glad I live in the States. http:\/\/bit.ly\/bvXGjK  Chinese woman sent to labor camp for tweet.  We would all be in jail if we lived there.",
    "id" : 5751851202904064,
    "created_at" : "2010-11-19 22:38:42 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 5754359744827392,
  "created_at" : "2010-11-19 22:48:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "Fumbles Morales",
      "screen_name" : "SeerGenius",
      "indices" : [ 21, 32 ],
      "id_str" : "28414306",
      "id" : 28414306
    }, {
      "name" : "Michael Pata",
      "screen_name" : "MichaelPata",
      "indices" : [ 33, 45 ],
      "id_str" : "55468579",
      "id" : 55468579
    }, {
      "name" : "Diamond Dd",
      "screen_name" : "ntnslykrazy",
      "indices" : [ 46, 58 ],
      "id_str" : "30335077",
      "id" : 30335077
    }, {
      "name" : "Maureen VanDerStad",
      "screen_name" : "MyFlyingCloud",
      "indices" : [ 59, 73 ],
      "id_str" : "94215997",
      "id" : 94215997
    }, {
      "name" : "Connie Handscomb",
      "screen_name" : "Peepsqueak",
      "indices" : [ 74, 85 ],
      "id_str" : "133923294",
      "id" : 133923294
    }, {
      "name" : "ilham",
      "screen_name" : "i_Enigma",
      "indices" : [ 86, 95 ],
      "id_str" : "2832607604",
      "id" : 2832607604
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 97, 108 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "TSAagent",
      "screen_name" : "TSAagent",
      "indices" : [ 120, 129 ],
      "id_str" : "214413815",
      "id" : 214413815
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 17, 20 ]
    }, {
      "text" : "FF",
      "indices" : [ 116, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5754038092042240",
  "text" : "RT @AlisynGayle: #FF @SeerGenius @MichaelPata @ntnslykrazy @MyFlyingCloud @Peepsqueak @I_enigma  @Moosebegab  Don't #FF @TSAAgent unless ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fumbles Morales",
        "screen_name" : "SeerGenius",
        "indices" : [ 4, 15 ],
        "id_str" : "28414306",
        "id" : 28414306
      }, {
        "name" : "Michael Pata",
        "screen_name" : "MichaelPata",
        "indices" : [ 16, 28 ],
        "id_str" : "55468579",
        "id" : 55468579
      }, {
        "name" : "Diamond Dd",
        "screen_name" : "ntnslykrazy",
        "indices" : [ 29, 41 ],
        "id_str" : "30335077",
        "id" : 30335077
      }, {
        "name" : "Maureen VanDerStad",
        "screen_name" : "MyFlyingCloud",
        "indices" : [ 42, 56 ],
        "id_str" : "94215997",
        "id" : 94215997
      }, {
        "name" : "Connie Handscomb",
        "screen_name" : "Peepsqueak",
        "indices" : [ 57, 68 ],
        "id_str" : "133923294",
        "id" : 133923294
      }, {
        "name" : "ilham",
        "screen_name" : "i_Enigma",
        "indices" : [ 69, 78 ],
        "id_str" : "2832607604",
        "id" : 2832607604
      }, {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 80, 91 ],
        "id_str" : "93747129",
        "id" : 93747129
      }, {
        "name" : "TSAagent",
        "screen_name" : "TSAagent",
        "indices" : [ 103, 112 ],
        "id_str" : "214413815",
        "id" : 214413815
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      }, {
        "text" : "FF",
        "indices" : [ 99, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5740490867609600",
    "text" : "#FF @SeerGenius @MichaelPata @ntnslykrazy @MyFlyingCloud @Peepsqueak @I_enigma  @Moosebegab  Don't #FF @TSAAgent unless u want 2 b groped ;)",
    "id" : 5740490867609600,
    "created_at" : "2010-11-19 21:53:34 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 5754038092042240,
  "created_at" : "2010-11-19 22:47:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H.N.C.",
      "screen_name" : "Heidikins79",
      "indices" : [ 3, 15 ],
      "id_str" : "26421415",
      "id" : 26421415
    }, {
      "name" : "Katrina M.",
      "screen_name" : "BooksOnBoard",
      "indices" : [ 20, 33 ],
      "id_str" : "30936075",
      "id" : 30936075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5747512757452800",
  "text" : "RT @Heidikins79: RT @BooksOnBoard: Rachel Vincent's new Soul Screamers novella \"Reaper\" FREE in PDF format - http:\/\/bit.ly\/bvJud4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Katrina M.",
        "screen_name" : "BooksOnBoard",
        "indices" : [ 3, 16 ],
        "id_str" : "30936075",
        "id" : 30936075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5722632565563392",
    "text" : "RT @BooksOnBoard: Rachel Vincent's new Soul Screamers novella \"Reaper\" FREE in PDF format - http:\/\/bit.ly\/bvJud4",
    "id" : 5722632565563392,
    "created_at" : "2010-11-19 20:42:36 +0000",
    "user" : {
      "name" : "H.N.C.",
      "screen_name" : "Heidikins79",
      "protected" : false,
      "id_str" : "26421415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460538224688238592\/G9-MnNmo_normal.jpeg",
      "id" : 26421415,
      "verified" : false
    }
  },
  "id" : 5747512757452800,
  "created_at" : "2010-11-19 22:21:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5747212608868353",
  "text" : "RT @BooksOnTheKnob: Using the Kindle Book Gift Feature http:\/\/bit.ly\/ayV3aX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5681998488145920",
    "text" : "Using the Kindle Book Gift Feature http:\/\/bit.ly\/ayV3aX",
    "id" : 5681998488145920,
    "created_at" : "2010-11-19 18:01:08 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 5747212608868353,
  "created_at" : "2010-11-19 22:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5747154907832320",
  "text" : "RT @WestofMars: Trevor's Song at the Sony store. Remember, 50% of my reported royalties headed to charity! http:\/\/bit.ly\/c3t2Hm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5687325820452865",
    "text" : "Trevor's Song at the Sony store. Remember, 50% of my reported royalties headed to charity! http:\/\/bit.ly\/c3t2Hm",
    "id" : 5687325820452865,
    "created_at" : "2010-11-19 18:22:18 +0000",
    "user" : {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "protected" : false,
      "id_str" : "34258680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454321783588413442\/gndVsGba_normal.png",
      "id" : 34258680,
      "verified" : false
    }
  },
  "id" : 5747154907832320,
  "created_at" : "2010-11-19 22:20:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5398739392925697",
  "text" : "Can you spare \u00A32 for the donkeys? | The Donkey Sanctuary http:\/\/bit.ly\/anzChh [Like it? http:\/\/bit.ly\/9Zu0D0 ]",
  "id" : 5398739392925697,
  "created_at" : "2010-11-18 23:15:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5387676446359552",
  "text" : "RT @hauntedcomputer: Scholastic book fairs at school are always cool--kids STILL get awesomely excited, no matter what the crusties say  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5386512308899841",
    "text" : "Scholastic book fairs at school are always cool--kids STILL get awesomely excited, no matter what the crusties say #books",
    "id" : 5386512308899841,
    "created_at" : "2010-11-18 22:26:59 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 5387676446359552,
  "created_at" : "2010-11-18 22:31:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 3, 15 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5386759114334208",
  "text" : "RT @Jeweldspear: Embracing nature, true animal speak. http:\/\/twitpic.com\/3808sq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5382853336502272",
    "text" : "Embracing nature, true animal speak. http:\/\/twitpic.com\/3808sq",
    "id" : 5382853336502272,
    "created_at" : "2010-11-18 22:12:26 +0000",
    "user" : {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "protected" : false,
      "id_str" : "51846392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655444947940823041\/ORiamX3x_normal.jpg",
      "id" : 51846392,
      "verified" : false
    }
  },
  "id" : 5386759114334208,
  "created_at" : "2010-11-18 22:27:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5374024095899648",
  "text" : "I love you friends. #justsayin [Like it? http:\/\/bit.ly\/9t7iUv ]",
  "id" : 5374024095899648,
  "created_at" : "2010-11-18 21:37:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "donni saphire",
      "screen_name" : "donni",
      "indices" : [ 15, 21 ],
      "id_str" : "4230121",
      "id" : 4230121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5373827840217090",
  "text" : "RT @BestAt: RT @donni: Why am I in the working class? I specifically requested the sleeping class.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "donni saphire",
        "screen_name" : "donni",
        "indices" : [ 3, 9 ],
        "id_str" : "4230121",
        "id" : 4230121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5373597891698688",
    "text" : "RT @donni: Why am I in the working class? I specifically requested the sleeping class.",
    "id" : 5373597891698688,
    "created_at" : "2010-11-18 21:35:40 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 5373827840217090,
  "created_at" : "2010-11-18 21:36:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5372474975846400",
  "geo" : { },
  "id_str" : "5373619987288064",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time He is beautiful. ((hugs))",
  "id" : 5373619987288064,
  "in_reply_to_status_id" : 5372474975846400,
  "created_at" : "2010-11-18 21:35:45 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bubby",
      "screen_name" : "bubbysharma",
      "indices" : [ 3, 15 ],
      "id_str" : "59225619",
      "id" : 59225619
    }, {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 17, 32 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5373068507615232",
  "text" : "RT @bubbysharma: @SpiritualNurse \n\n\u007B\u25E0\u203F\u25E0\u007D\uE415 \u007B\u25E0\u203F\u25E0\u007D\uE415\nA smile is the best lighting               system of Life!!\n  \uE415Smiley Thursday\uE415\n     \u007B\u25E0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpiritualNurse Sandy",
        "screen_name" : "SpiritualNurse",
        "indices" : [ 0, 15 ],
        "id_str" : "32435460",
        "id" : 32435460
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5331500337725440",
    "in_reply_to_user_id" : 32435460,
    "text" : "@SpiritualNurse \n\n\u007B\u25E0\u203F\u25E0\u007D\uE415 \u007B\u25E0\u203F\u25E0\u007D\uE415\nA smile is the best lighting               system of Life!!\n  \uE415Smiley Thursday\uE415\n     \u007B\u25E0\u203F\u25E0\u007D\uE415 \u007B\u25E0\u203F\u25E0\u007D\u201D",
    "id" : 5331500337725440,
    "created_at" : "2010-11-18 18:48:23 +0000",
    "in_reply_to_screen_name" : "SpiritualNurse",
    "in_reply_to_user_id_str" : "32435460",
    "user" : {
      "name" : "Bubby",
      "screen_name" : "bubbysharma",
      "protected" : false,
      "id_str" : "59225619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776463207288274944\/9Xb-Z0jz_normal.jpg",
      "id" : 59225619,
      "verified" : false
    }
  },
  "id" : 5373068507615232,
  "created_at" : "2010-11-18 21:33:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5372692148527104",
  "text" : "RT @Buddhaworld: the moment you realise you dont really know anything, you are entering the gates of wisdom.-love buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5369503676366848",
    "text" : "the moment you realise you dont really know anything, you are entering the gates of wisdom.-love buddha volko.",
    "id" : 5369503676366848,
    "created_at" : "2010-11-18 21:19:24 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 5372692148527104,
  "created_at" : "2010-11-18 21:32:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5372529015267329",
  "text" : "RT @mindymayhem: My mom is fucking nuts to email me about seasonal Toys R Us jobs. Do you even understand the resulting casualties that  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5369033335513088",
    "text" : "My mom is fucking nuts to email me about seasonal Toys R Us jobs. Do you even understand the resulting casualties that could come of this?!",
    "id" : 5369033335513088,
    "created_at" : "2010-11-18 21:17:31 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 5372529015267329,
  "created_at" : "2010-11-18 21:31:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5371978437365760",
  "text" : "RT @ChrisGroove1: &gt;^,,^&lt;",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5366402647064576",
    "text" : "&gt;^,,^&lt;",
    "id" : 5366402647064576,
    "created_at" : "2010-11-18 21:07:04 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 5371978437365760,
  "created_at" : "2010-11-18 21:29:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5351248010158080",
  "text" : "Siberian Husky Plagued by Dangerous Dog Label 8 Years After Duck Chasing Incident \u00BB Life With Dogs http:\/\/bit.ly\/bAIVNA",
  "id" : 5351248010158080,
  "created_at" : "2010-11-18 20:06:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noworries",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5302167976017921",
  "text" : "RT @earthXplorer: I appreciate the friends that stay around & I don't worry about the ones that move on..... #noworries",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noworries",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5299753168408576",
    "text" : "I appreciate the friends that stay around & I don't worry about the ones that move on..... #noworries",
    "id" : 5299753168408576,
    "created_at" : "2010-11-18 16:42:14 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 5302167976017921,
  "created_at" : "2010-11-18 16:51:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5058260201639936",
  "geo" : { },
  "id_str" : "5254846131208193",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time getting another dog kept us sane.. We think of & talk about Quinn all the time. Always with joy. Kari reminds us &lt;3",
  "id" : 5254846131208193,
  "in_reply_to_status_id" : 5058260201639936,
  "created_at" : "2010-11-18 13:43:47 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "batman",
      "screen_name" : "nonidentity",
      "indices" : [ 0, 12 ],
      "id_str" : "99486198",
      "id" : 99486198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5098181318676480",
  "geo" : { },
  "id_str" : "5253977729929217",
  "in_reply_to_user_id" : 159213309,
  "text" : "@NonIdentity all the way! Lol. I am INFP (Myers-Briggs type indicator)",
  "id" : 5253977729929217,
  "in_reply_to_status_id" : 5098181318676480,
  "created_at" : "2010-11-18 13:40:20 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "batman",
      "screen_name" : "nonidentity",
      "indices" : [ 3, 15 ],
      "id_str" : "99486198",
      "id" : 99486198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5092455074496512",
  "text" : "RT @NonIdentity: www.sengifted.org\/articles_counseling\/Webb_ExistentialDepressionInGiftedIndividuals.shtml &lt;&lt; This describes my pr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5091745213718528",
    "text" : "www.sengifted.org\/articles_counseling\/Webb_ExistentialDepressionInGiftedIndividuals.shtml &lt;&lt; This describes my problem PERFECTLY!",
    "id" : 5091745213718528,
    "created_at" : "2010-11-18 02:55:41 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 5092455074496512,
  "created_at" : "2010-11-18 02:58:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "batman",
      "screen_name" : "nonidentity",
      "indices" : [ 28, 40 ],
      "id_str" : "99486198",
      "id" : 99486198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5091231965126656",
  "text" : "I'm sorry about that : ( RT @NonIdentity: Introverted personalities frustrate me and leave me feeling drained and depressed.",
  "id" : 5091231965126656,
  "created_at" : "2010-11-18 02:53:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5090441863102465",
  "text" : "RT @Wylieknowords: \"I am not Spartacus. I am a freelance writer in need of blurbs from famous creative people for my creativity book.\" N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5087206771269632",
    "text" : "\"I am not Spartacus. I am a freelance writer in need of blurbs from famous creative people for my creativity book.\" N.W.J.www.knowords.com",
    "id" : 5087206771269632,
    "created_at" : "2010-11-18 02:37:39 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 5090441863102465,
  "created_at" : "2010-11-18 02:50:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5087473503838208",
  "text" : "Plate Poets: The Poetry of Vanity License Plates http:\/\/bit.ly\/99lXbN",
  "id" : 5087473503838208,
  "created_at" : "2010-11-18 02:38:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Pyle",
      "screen_name" : "djpyle",
      "indices" : [ 0, 7 ],
      "id_str" : "23011183",
      "id" : 23011183
    }, {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 8, 16 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "LaurenHidden",
      "screen_name" : "LaurenHidden",
      "indices" : [ 17, 30 ],
      "id_str" : "14977281",
      "id" : 14977281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5017992286965760",
  "geo" : { },
  "id_str" : "5019832307163137",
  "in_reply_to_user_id" : 14653298,
  "text" : "@djpyle @candytx @laurenhidden I read \"Down the Drain\" .. Excellent & scary!",
  "id" : 5019832307163137,
  "in_reply_to_status_id" : 5017992286965760,
  "created_at" : "2010-11-17 22:09:55 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 24, 38 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5018900475420672",
  "text" : "Totally loving Boom by  @JimBrownBooks !",
  "id" : 5018900475420672,
  "created_at" : "2010-11-17 22:06:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5006315348828160",
  "text" : "Beautiful Cleo! Part Alsatian - Wordless Wednesday http:\/\/bit.ly\/dAjBDQ [Like it? http:\/\/bit.ly\/aVYLH2 ]",
  "id" : 5006315348828160,
  "created_at" : "2010-11-17 21:16:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5006311406182400",
  "text" : "Beautiful Cleo! Part Alsatian - Wordless Wednesday http:\/\/bit.ly\/dAjBDQ [Like it? http:\/\/bit.ly\/bqvYiZ ]",
  "id" : 5006311406182400,
  "created_at" : "2010-11-17 21:16:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5006312970657792",
  "text" : "Beautiful Cleo! Part Alsatian - Wordless Wednesday http:\/\/bit.ly\/dAjBDQ [Like it? http:\/\/bit.ly\/cvkbtm ]",
  "id" : 5006312970657792,
  "created_at" : "2010-11-17 21:16:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5004691154935808",
  "text" : "RT @CoyoteSings: I got my four graded draws as follows: 95, 100, 100, and 100. Unless I stick someone in the heart by accident, I got an ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5000078070652929",
    "text" : "I got my four graded draws as follows: 95, 100, 100, and 100. Unless I stick someone in the heart by accident, I got an A :)) Yay!",
    "id" : 5000078070652929,
    "created_at" : "2010-11-17 20:51:26 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 5004691154935808,
  "created_at" : "2010-11-17 21:09:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Sarah",
      "screen_name" : "MarySarahMusic",
      "indices" : [ 3, 18 ],
      "id_str" : "27503151",
      "id" : 27503151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5004311566225408",
  "text" : "RT @MarySarahMusic: For all my followers ~  I loved you once, I love you still, I always have, I always will! ~ Unknown \u2740*\u02DA\u00B0\u2022.\u2764.\u2022\u00B0\u02DA*\u2740 RT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Fry",
        "screen_name" : "lovepeaceunity",
        "indices" : [ 117, 132 ],
        "id_str" : "23939797",
        "id" : 23939797
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5000541914529792",
    "text" : "For all my followers ~  I loved you once, I love you still, I always have, I always will! ~ Unknown \u2740*\u02DA\u00B0\u2022.\u2764.\u2022\u00B0\u02DA*\u2740 RT @lovepeaceunity",
    "id" : 5000541914529792,
    "created_at" : "2010-11-17 20:53:16 +0000",
    "user" : {
      "name" : "Mary Sarah",
      "screen_name" : "MarySarahMusic",
      "protected" : false,
      "id_str" : "27503151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790606248609800193\/D8Gr04eF_normal.jpg",
      "id" : 27503151,
      "verified" : true
    }
  },
  "id" : 5004311566225408,
  "created_at" : "2010-11-17 21:08:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intent.com",
      "screen_name" : "Intentdotcom",
      "indices" : [ 3, 16 ],
      "id_str" : "15238769",
      "id" : 15238769
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 27, 40 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4998027035025408",
  "text" : "RT @Intentdotcom: Q&A with @DeepakChopra: If our soul indeed resides in some part of our brain, what happens when we are under anesthesi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 9, 22 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4987179952504832",
    "text" : "Q&A with @DeepakChopra: If our soul indeed resides in some part of our brain, what happens when we are under anesthesia? http:\/\/ow.ly\/3bmiL",
    "id" : 4987179952504832,
    "created_at" : "2010-11-17 20:00:11 +0000",
    "user" : {
      "name" : "Intent.com",
      "screen_name" : "Intentdotcom",
      "protected" : false,
      "id_str" : "15238769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3442918435\/168dc33af062248e560625cc543a7403_normal.jpeg",
      "id" : 15238769,
      "verified" : false
    }
  },
  "id" : 4998027035025408,
  "created_at" : "2010-11-17 20:43:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    }, {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 60, 69 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4995979564552192",
  "text" : "RT @bcmouser: \"I regularly exercise my right to not vote\" - @bcmouser you can read more here http:\/\/ht.ly\/3bsiq \/via @jasonbhuffman #Out ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brandon Mouser",
        "screen_name" : "bcmouser",
        "indices" : [ 46, 55 ],
        "id_str" : "16649649",
        "id" : 16649649
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OutlawPreachers",
        "indices" : [ 118, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4990912623026177",
    "text" : "\"I regularly exercise my right to not vote\" - @bcmouser you can read more here http:\/\/ht.ly\/3bsiq \/via @jasonbhuffman #OutlawPreachers",
    "id" : 4990912623026177,
    "created_at" : "2010-11-17 20:15:00 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 4995979564552192,
  "created_at" : "2010-11-17 20:35:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "soulseedz",
      "indices" : [ 3, 13 ],
      "id_str" : "17783366",
      "id" : 17783366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4990067697258496",
  "text" : "RT @soulseedz: You have no idea how, when and where the seeds of your best efforts will harvest in amazing ways.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4930113741266944",
    "text" : "You have no idea how, when and where the seeds of your best efforts will harvest in amazing ways.",
    "id" : 4930113741266944,
    "created_at" : "2010-11-17 16:13:25 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "soulseedz",
      "protected" : false,
      "id_str" : "17783366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1052413314\/header_bigger_normal.jpg",
      "id" : 17783366,
      "verified" : false
    }
  },
  "id" : 4990067697258496,
  "created_at" : "2010-11-17 20:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4982840638836736",
  "geo" : { },
  "id_str" : "4988601678962688",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time love never dies.. That is what got me thru our prev dog leaving.. and a lot of tears in car (alone) for year.",
  "id" : 4988601678962688,
  "in_reply_to_status_id" : 4982840638836736,
  "created_at" : "2010-11-17 20:05:49 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4988015680159744",
  "text" : "RT @JacksonPearce: I have eaten lunch. And by lunch I mean cookies. And now back to editing. And by editing I mean procrastinating.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4982344192626688",
    "text" : "I have eaten lunch. And by lunch I mean cookies. And now back to editing. And by editing I mean procrastinating.",
    "id" : 4982344192626688,
    "created_at" : "2010-11-17 19:40:58 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 4988015680159744,
  "created_at" : "2010-11-17 20:03:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4982336353472512",
  "geo" : { },
  "id_str" : "4987924693131265",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time been thru it & likely again soon.. ((hugs))",
  "id" : 4987924693131265,
  "in_reply_to_status_id" : 4982336353472512,
  "created_at" : "2010-11-17 20:03:08 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 16, 31 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4972581811658752",
  "text" : "OMG Awesome! RT @ReformedBuddha: Night sky from Japan http:\/\/apod.nasa.gov\/apod\/image\/1011\/leaforion_miyasaka_big.jpg",
  "id" : 4972581811658752,
  "created_at" : "2010-11-17 19:02:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 16, 31 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4972437456289792",
  "text" : "Naughty..lol RT @ReformedBuddha: I have not done this *grin* http:\/\/i.imgur.com\/Fomvi.jpg [Like it? http:\/\/bit.ly\/aL4kwJ ]",
  "id" : 4972437456289792,
  "created_at" : "2010-11-17 19:01:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 16, 31 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4972439238877185",
  "text" : "Naughty..lol RT @ReformedBuddha: I have not done this *grin* http:\/\/i.imgur.com\/Fomvi.jpg [Like it? http:\/\/bit.ly\/9L6W4f ]",
  "id" : 4972439238877185,
  "created_at" : "2010-11-17 19:01:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 16, 31 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4972436374163457",
  "text" : "Naughty..lol RT @ReformedBuddha: I have not done this *grin* http:\/\/i.imgur.com\/Fomvi.jpg [Like it? http:\/\/bit.ly\/atsCV8 ]",
  "id" : 4972436374163457,
  "created_at" : "2010-11-17 19:01:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mastin Kipp",
      "screen_name" : "TheDailyLove",
      "indices" : [ 3, 16 ],
      "id_str" : "16870682",
      "id" : 16870682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TDL",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4925886973353984",
  "text" : "RT @TheDailyLove: I repeat: Don't let ppl who are living their nightmare tell you that you can't live your dream! #TDL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TDL",
        "indices" : [ 96, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4921282822934528",
    "text" : "I repeat: Don't let ppl who are living their nightmare tell you that you can't live your dream! #TDL",
    "id" : 4921282822934528,
    "created_at" : "2010-11-17 15:38:19 +0000",
    "user" : {
      "name" : "Mastin Kipp",
      "screen_name" : "TheDailyLove",
      "protected" : false,
      "id_str" : "16870682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708016260542365696\/Oucm5M91_normal.jpg",
      "id" : 16870682,
      "verified" : true
    }
  },
  "id" : 4925886973353984,
  "created_at" : "2010-11-17 15:56:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    }, {
      "name" : "Stephanie Pellegrin",
      "screen_name" : "StephPellegrin",
      "indices" : [ 20, 35 ],
      "id_str" : "27367009",
      "id" : 27367009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4925313192562688",
  "text" : "RT @JacksonPearce: \"@StephPellegrin:  And then the zombie alien giraffes came and stomped everyone to death. The end.\" But how to work i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephanie Pellegrin",
        "screen_name" : "StephPellegrin",
        "indices" : [ 1, 16 ],
        "id_str" : "27367009",
        "id" : 27367009
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4920300625989632",
    "text" : "\"@StephPellegrin:  And then the zombie alien giraffes came and stomped everyone to death. The end.\" But how to work in the Choir Turtles?",
    "id" : 4920300625989632,
    "created_at" : "2010-11-17 15:34:25 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 4925313192562688,
  "created_at" : "2010-11-17 15:54:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 3, 19 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4924225248825344",
  "text" : "RT @SparklingReview: The Kindle #giveaway ends tomorrow night at 11:59pm EST... You can now enter UNLIMITED times until the end of the g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaway",
        "indices" : [ 11, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4918177708376064",
    "text" : "The Kindle #giveaway ends tomorrow night at 11:59pm EST... You can now enter UNLIMITED times until the end of the giveaway... enjoy!",
    "id" : 4918177708376064,
    "created_at" : "2010-11-17 15:25:59 +0000",
    "user" : {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "protected" : false,
      "id_str" : "26547903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535442186964176897\/q9jfS0U4_normal.png",
      "id" : 26547903,
      "verified" : false
    }
  },
  "id" : 4924225248825344,
  "created_at" : "2010-11-17 15:50:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "paranormal",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "romance",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "books",
      "indices" : [ 117, 123 ]
    }, {
      "text" : "writing",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4924017161011200",
  "text" : "RT @hauntedcomputer: Meet CURSED! and enter for #kindle giveaways at http:\/\/wickedlilpixie.com\/ #paranormal #romance #books #writing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 27, 34 ]
      }, {
        "text" : "paranormal",
        "indices" : [ 75, 86 ]
      }, {
        "text" : "romance",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "books",
        "indices" : [ 96, 102 ]
      }, {
        "text" : "writing",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4918907278200832",
    "text" : "Meet CURSED! and enter for #kindle giveaways at http:\/\/wickedlilpixie.com\/ #paranormal #romance #books #writing",
    "id" : 4918907278200832,
    "created_at" : "2010-11-17 15:28:53 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 4924017161011200,
  "created_at" : "2010-11-17 15:49:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4923473948319745",
  "text" : "Writings Of A Wicked Book Addict \u2013 Kindle Giveaway: Scott Nicholson Guest Blogs http:\/\/bit.ly\/bt0ZUn [Like it? http:\/\/bit.ly\/c8cKRO ]",
  "id" : 4923473948319745,
  "created_at" : "2010-11-17 15:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4909844242890752",
  "text" : "West of Mars Book giveaway Exp Nov 29 http:\/\/bit.ly\/c66C3S [Like it? http:\/\/bit.ly\/dsR5bL ]",
  "id" : 4909844242890752,
  "created_at" : "2010-11-17 14:52:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 7, 17 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4727602963030016",
  "text" : "Me2 RT @wow_trees: I'm such a voyeur. [Like it? http:\/\/bit.ly\/ctceyR ]",
  "id" : 4727602963030016,
  "created_at" : "2010-11-17 02:48:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4722305624182785",
  "text" : "Liking the weet app so far",
  "id" : 4722305624182785,
  "created_at" : "2010-11-17 02:27:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4721624410492929",
  "text" : "RT @derekrootboy: if people only collect followers in the expectation of followbacks... this is a pyramid that will collapse, taking eve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4721456483143680",
    "text" : "if people only collect followers in the expectation of followbacks... this is a pyramid that will collapse, taking everyone with it.",
    "id" : 4721456483143680,
    "created_at" : "2010-11-17 02:24:17 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 4721624410492929,
  "created_at" : "2010-11-17 02:24:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 9, 18 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Bunny One",
      "screen_name" : "rotordroid",
      "indices" : [ 81, 92 ],
      "id_str" : "192770268",
      "id" : 192770268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4719846751215617",
  "text" : "Awww! RT @gemswinc: http:\/\/yfrog.com\/5tz4vkj My Owl in a tree in my backyard via @rotordroid [Like it? http:\/\/bit.ly\/bxVmp4 ]",
  "id" : 4719846751215617,
  "created_at" : "2010-11-17 02:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lin Corto",
      "screen_name" : "blogomomma",
      "indices" : [ 11, 22 ],
      "id_str" : "17567609",
      "id" : 17567609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4718932841730048",
  "text" : "Dislike RT @blogomomma: How do YOU feel about the body scanner?",
  "id" : 4718932841730048,
  "created_at" : "2010-11-17 02:14:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4699825777934336",
  "text" : "RT @Joeandrasi93: NGC 4826 The Black Eye Galaxy (also known as the Evil Eye Galaxy)http:\/\/www.spacepictures.org\/displayimage-12-3.html",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4698766825234433",
    "text" : "NGC 4826 The Black Eye Galaxy (also known as the Evil Eye Galaxy)http:\/\/www.spacepictures.org\/displayimage-12-3.html",
    "id" : 4698766825234433,
    "created_at" : "2010-11-17 00:54:07 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 4699825777934336,
  "created_at" : "2010-11-17 00:58:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4699455760637954",
  "text" : "The bison got away Billings, Montana http:\/\/bit.ly\/acpTLm [Like it? http:\/\/bit.ly\/aLjuHX ]",
  "id" : 4699455760637954,
  "created_at" : "2010-11-17 00:56:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4620922405261312",
  "text" : "Wonders what having synesthesia is like? [Like it? http:\/\/bit.ly\/a9SjKT ]",
  "id" : 4620922405261312,
  "created_at" : "2010-11-16 19:44:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "batman",
      "screen_name" : "nonidentity",
      "indices" : [ 3, 15 ],
      "id_str" : "99486198",
      "id" : 99486198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4620268693618689",
  "text" : "RT @NonIdentity: You lot follow me but barely @ me. What the fuck is the point?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4615962305236992",
    "text" : "You lot follow me but barely @ me. What the fuck is the point?",
    "id" : 4615962305236992,
    "created_at" : "2010-11-16 19:25:05 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 4620268693618689,
  "created_at" : "2010-11-16 19:42:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 0, 9 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4617765834985473",
  "geo" : { },
  "id_str" : "4619485726113793",
  "in_reply_to_user_id" : 13112692,
  "text" : "@gemswinc smartypants ; )",
  "id" : 4619485726113793,
  "in_reply_to_status_id" : 4617765834985473,
  "created_at" : "2010-11-16 19:39:05 +0000",
  "in_reply_to_screen_name" : "gemswinc",
  "in_reply_to_user_id_str" : "13112692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4617248421453825",
  "text" : "The Five Most Ridiculous Moments from the Sarah Palin's Alaska Premiere http:\/\/bit.ly\/bssPvX [Like it? http:\/\/bit.ly\/dd4Fnp ]",
  "id" : 4617248421453825,
  "created_at" : "2010-11-16 19:30:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smashwords",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "read",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4331076650536960",
  "text" : "RT @DarciaHelle: 'The First Kill' free download at #smashwords!  http:\/\/smashwords.com\/b\/28647 #read",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smashwords",
        "indices" : [ 34, 45 ]
      }, {
        "text" : "read",
        "indices" : [ 78, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4330564177895424",
    "text" : "'The First Kill' free download at #smashwords!  http:\/\/smashwords.com\/b\/28647 #read",
    "id" : 4330564177895424,
    "created_at" : "2010-11-16 00:31:01 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 4331076650536960,
  "created_at" : "2010-11-16 00:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4329771638984704",
  "text" : "RT @derekrootboy: lalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalala ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NAMETHATTUNE",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4328507261853696",
    "text" : "lalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalalala #NAMETHATTUNE!!!",
    "id" : 4328507261853696,
    "created_at" : "2010-11-16 00:22:51 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 4329771638984704,
  "created_at" : "2010-11-16 00:27:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4329127448416256",
  "text" : "Failure is impossible for high school students! (No, really) on Shine http:\/\/yhoo.it\/bI0k0s [Like it? http:\/\/bit.ly\/9Mg4yW ]",
  "id" : 4329127448416256,
  "created_at" : "2010-11-16 00:25:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4321376705970176",
  "text" : "RT @Dwayne_Reaves: In three words I can sum up everything I've learned about life: it goes on. ~Robert Frost  #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 91, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4320736537743360",
    "text" : "In three words I can sum up everything I've learned about life: it goes on. ~Robert Frost  #quote",
    "id" : 4320736537743360,
    "created_at" : "2010-11-15 23:51:58 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 4321376705970176,
  "created_at" : "2010-11-15 23:54:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4320961650229249",
  "text" : "RT @bunnybuddhism: No bunny saves us but ourselves.  We ourselves must hop the path.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4308708792205314",
    "text" : "No bunny saves us but ourselves.  We ourselves must hop the path.",
    "id" : 4308708792205314,
    "created_at" : "2010-11-15 23:04:10 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 4320961650229249,
  "created_at" : "2010-11-15 23:52:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4320672192929792",
  "text" : "I thought of you last week.. at petsmart saw the cutest sweetest pup like yours but diff colors.. she was a doll! \u2665",
  "id" : 4320672192929792,
  "created_at" : "2010-11-15 23:51:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4157016943624193",
  "text" : "nightsky on your pc - Stellarium http:\/\/bit.ly\/cn5Eve [Like it? http:\/\/bit.ly\/cu1p6J ]",
  "id" : 4157016943624193,
  "created_at" : "2010-11-15 13:01:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moose",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4146543493914624",
  "text" : "November Calendars~ | A Focus In the Wild http:\/\/bit.ly\/9tumhW #moose [Like it? http:\/\/bit.ly\/bTrjHJ ]",
  "id" : 4146543493914624,
  "created_at" : "2010-11-15 12:19:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3931842856091648",
  "text" : "Free WordPress e-Commerce Theme: Crafty Cart http:\/\/bit.ly\/ch4FDz",
  "id" : 3931842856091648,
  "created_at" : "2010-11-14 22:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3872291461013504",
  "text" : "Crow takes a bath http:\/\/yhoo.it\/dvhuDh [Like it? http:\/\/bit.ly\/cs3xwe ]",
  "id" : 3872291461013504,
  "created_at" : "2010-11-14 18:10:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3819585274904576",
  "text" : "Oscar the Donkey who cries like a baby http:\/\/bit.ly\/c7Fd9H [Like it? http:\/\/bit.ly\/bRbSl8 ]",
  "id" : 3819585274904576,
  "created_at" : "2010-11-14 14:40:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3552347636633600",
  "text" : "To Hold Nothing: Where Human Ethics Begin http:\/\/bit.ly\/970BWX [Like it? http:\/\/bit.ly\/azedeY ]",
  "id" : 3552347636633600,
  "created_at" : "2010-11-13 20:58:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3488994822197248",
  "text" : "Tipsy\u2019s First Kill \u00BB Life With Dogs http:\/\/bit.ly\/9UNUYD [Like it? http:\/\/bit.ly\/9gMLyP ]",
  "id" : 3488994822197248,
  "created_at" : "2010-11-13 16:46:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2025784197779456",
  "geo" : { },
  "id_str" : "2802806931070976",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts havent been on twitter... gotta get back in the groove. miss my peeps! : )",
  "id" : 2802806931070976,
  "in_reply_to_status_id" : 2025784197779456,
  "created_at" : "2010-11-11 19:20:15 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2559017494773760",
  "text" : "good short video! Get Service - http:\/\/bit.ly\/aSvma3 [Like it? http:\/\/bit.ly\/b2USHD ]",
  "id" : 2559017494773760,
  "created_at" : "2010-11-11 03:11:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2006294550544384",
  "text" : "Longest valid domain name: Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch http:\/\/bit.ly\/9Bb2EX [Like it? http:\/\/bit.ly\/bxk3h8 ]",
  "id" : 2006294550544384,
  "created_at" : "2010-11-09 14:35:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1460098132090880",
  "text" : "RT @Davescotperth: Heard that counting sheep helps you sleep... It's bloody freezing in this field! AND I'M STILL WIDE AWAKE!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1457258647003136",
    "text" : "Heard that counting sheep helps you sleep... It's bloody freezing in this field! AND I'M STILL WIDE AWAKE!!",
    "id" : 1457258647003136,
    "created_at" : "2010-11-08 02:13:32 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 1460098132090880,
  "created_at" : "2010-11-08 02:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1459933094612992",
  "text" : "RT @Davescotperth: One spelling mistake can destroy your life.\nA Husband sent this to his wife \"I'm having a wonderful time wish you wer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1457706472837120",
    "text" : "One spelling mistake can destroy your life.\nA Husband sent this to his wife \"I'm having a wonderful time wish you were her\"",
    "id" : 1457706472837120,
    "created_at" : "2010-11-08 02:15:18 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 1459933094612992,
  "created_at" : "2010-11-08 02:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1459829948284928",
  "text" : "RT @Davescotperth: Quick hide.. Monday is coming!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1457951273385984",
    "text" : "Quick hide.. Monday is coming!!",
    "id" : 1457951273385984,
    "created_at" : "2010-11-08 02:16:17 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 1459829948284928,
  "created_at" : "2010-11-08 02:23:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert L Fleck",
      "screen_name" : "robertlfleck",
      "indices" : [ 3, 16 ],
      "id_str" : "16305770",
      "id" : 16305770
    }, {
      "name" : "David_N_Wilson",
      "screen_name" : "David_N_Wilson",
      "indices" : [ 43, 58 ],
      "id_str" : "14527038",
      "id" : 14527038
    }, {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 62, 78 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 127, 135 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1410384200204288",
  "text" : "RT @robertlfleck: Book giveaway! Check out @David_N_Wilson on @hauntedcomputer's blog http:\/\/hauntedcomputer.blogspot.com\/ via @addthis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David_N_Wilson",
        "screen_name" : "David_N_Wilson",
        "indices" : [ 25, 40 ],
        "id_str" : "14527038",
        "id" : 14527038
      }, {
        "name" : "Counting Bankroll",
        "screen_name" : "hauntedcomputer",
        "indices" : [ 44, 60 ],
        "id_str" : "2553401966",
        "id" : 2553401966
      }, {
        "name" : "AddThis",
        "screen_name" : "addthis",
        "indices" : [ 109, 117 ],
        "id_str" : "15907720",
        "id" : 15907720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1386087566016512",
    "text" : "Book giveaway! Check out @David_N_Wilson on @hauntedcomputer's blog http:\/\/hauntedcomputer.blogspot.com\/ via @addthis",
    "id" : 1386087566016512,
    "created_at" : "2010-11-07 21:30:43 +0000",
    "user" : {
      "name" : "Robert L Fleck",
      "screen_name" : "robertlfleck",
      "protected" : false,
      "id_str" : "16305770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660606194227146752\/YQd5n12L_normal.jpg",
      "id" : 16305770,
      "verified" : false
    }
  },
  "id" : 1410384200204288,
  "created_at" : "2010-11-07 23:07:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1410072378875904",
  "text" : "RT @hauntedcomputer: Day 2: Worst novel ever, 117 rejections, why not help make it a 99-cent bestseller? http:\/\/amzn.to\/9VIkOS #kindle # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "books",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1292503332421633",
    "text" : "Day 2: Worst novel ever, 117 rejections, why not help make it a 99-cent bestseller? http:\/\/amzn.to\/9VIkOS #kindle #books PlzRT",
    "id" : 1292503332421633,
    "created_at" : "2010-11-07 15:18:51 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 1410072378875904,
  "created_at" : "2010-11-07 23:06:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1046942213734400",
  "text" : "Words You Dont Know http:\/\/bit.ly\/c8jvnt [Like it? http:\/\/bit.ly\/98asG3 ]",
  "id" : 1046942213734400,
  "created_at" : "2010-11-06 23:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928107561226240",
  "text" : "Carole's Thoughtful Spot: Does the Coffee Fairy Come to Your House? http:\/\/bit.ly\/beZXHo [Like it? http:\/\/bit.ly\/cCExSf ]",
  "id" : 928107561226240,
  "created_at" : "2010-11-06 15:10:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615248407044096",
  "text" : "@SamsaricWarrior looks like u can add up to 10 pgs under Posting",
  "id" : 615248407044096,
  "created_at" : "2010-11-05 18:27:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 3, 15 ],
      "id_str" : "130344581",
      "id" : 130344581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335291097284610",
  "text" : "RT @_karmadorje: Inside the box http:\/\/twitpic.com\/33xo7a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329445583880192",
    "text" : "Inside the box http:\/\/twitpic.com\/33xo7a",
    "id" : 329445583880192,
    "created_at" : "2010-11-04 23:32:00 +0000",
    "user" : {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "protected" : false,
      "id_str" : "130344581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803398523\/double-dorje_normal.jpg",
      "id" : 130344581,
      "verified" : false
    }
  },
  "id" : 335291097284610,
  "created_at" : "2010-11-04 23:55:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 13, 25 ],
      "id_str" : "130344581",
      "id" : 130344581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335193839763456",
  "text" : "Gorgeous! RT @_karmadorje: My husband made this as a gift for friend's 25th wedding anniversary.  http:\/\/twitpic.com\/33xnv2",
  "id" : 335193839763456,
  "created_at" : "2010-11-04 23:54:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334766238863360",
  "text" : "@SamsaricWarrior I was using blogspot, now using self-hosted wordpress (org not com). But using it as site not just blog.",
  "id" : 334766238863360,
  "created_at" : "2010-11-04 23:53:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "W. Bruce McConnel",
      "screen_name" : "wbrucemcconnel",
      "indices" : [ 13, 28 ],
      "id_str" : "56443331",
      "id" : 56443331
    }, {
      "name" : "Forbes Tech News",
      "screen_name" : "ForbesTech",
      "indices" : [ 110, 121 ],
      "id_str" : "14885549",
      "id" : 14885549
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 122, 133 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333002022326272",
  "text" : "Cool! : ) RT @wbrucemcconnel: The W. Bruce McConnel Daily is out! http:\/\/bit.ly\/cGZhAW \u25B8 Top stories today by @ForbesTech @moosebegab",
  "id" : 333002022326272,
  "created_at" : "2010-11-04 23:46:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29628629695",
  "text" : "Opt Out of a Body Scan? Then Brace Yourself http:\/\/yhoo.it\/dBlKky [Like it? http:\/\/bit.ly\/dcLFt9 ]",
  "id" : 29628629695,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheism",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "religion",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "science",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29628823938",
  "text" : "RT @Reverend_Sue: The bashing of #atheism, #religion and #science MUST END. Bashing only segregates and alienates Moving forward is neve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheism",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "religion",
        "indices" : [ 25, 34 ]
      }, {
        "text" : "science",
        "indices" : [ 39, 47 ]
      }, {
        "text" : "peace",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29628317107",
    "text" : "The bashing of #atheism, #religion and #science MUST END. Bashing only segregates and alienates Moving forward is never accomplished. #peace",
    "id" : 29628317107,
    "created_at" : "2010-11-04 01:41:38 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 29628823938,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29628269669",
  "geo" : { },
  "id_str" : "29629023967",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis love his last point about how we treat others! : )",
  "id" : 29629023967,
  "in_reply_to_status_id" : 29628269669,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29629674876",
  "text" : "RT @neardeathdoc: Another child told me, after being dead for 20 minutes: no I wasn't dead at all. I was alive, some part of me was alive\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29629564892",
    "text" : "Another child told me, after being dead for 20 minutes: no I wasn't dead at all. I was alive, some part of me was alive\"",
    "id" : 29629564892,
    "created_at" : "2010-11-04 01:57:03 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 29629674876,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29629741703",
  "text" : "Reading thru my tweet stream makes me smile.. got some fine tweeps on here! : ) [Like it? http:\/\/bit.ly\/aJpH8T ]",
  "id" : 29629741703,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29629775295",
  "text" : "RT @neardeathdoc: When we die, we do not lose consciousness. We are aware body is dead. As one child said: death is just a body problem.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29629704142",
    "text" : "When we die, we do not lose consciousness. We are aware body is dead. As one child said: death is just a body problem.",
    "id" : 29629704142,
    "created_at" : "2010-11-04 01:58:51 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 29629775295,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29689738544",
  "text" : "My Aspergers Child: Helping Teachers To Understand Your Aspergers Child http:\/\/bit.ly\/b7yvaM [Like it? http:\/\/bit.ly\/cqWc7s ]",
  "id" : 29689738544,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29689774457",
  "text" : "My Aspergers Child: Helping Teachers To Understand Your Aspergers Child http:\/\/bit.ly\/b7yvaM [Like it? http:\/\/bit.ly\/a5KThP ]",
  "id" : 29689774457,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29689778919",
  "text" : "My Aspergers Child: Helping Teachers To Understand Your Aspergers Child http:\/\/bit.ly\/b7yvaM [Like it? http:\/\/bit.ly\/9e4Cu4 ]",
  "id" : 29689778919,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "DZA",
      "screen_name" : "DZA13",
      "indices" : [ 17, 23 ],
      "id_str" : "90468592",
      "id" : 90468592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29528954447",
  "text" : "RT @gemswinc: RT @DZA13 I am unimpressed by Republicans, Tea Party, Democrats, Progressives. Any political system not firmly grounded in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DZA",
        "screen_name" : "DZA13",
        "indices" : [ 3, 9 ],
        "id_str" : "90468592",
        "id" : 90468592
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29528814314",
    "text" : "RT @DZA13 I am unimpressed by Republicans, Tea Party, Democrats, Progressives. Any political system not firmly grounded in Nature will fail.",
    "id" : 29528814314,
    "created_at" : "2010-11-03 01:48:26 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 29528954447,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29529915518",
  "text" : "RT @squintinginfog: RT @PolycarpTCOJC: I wonder how many people realize that nearly 4 billion dollars were spent in this election. &lt;~ :(",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29527134586",
    "text" : "RT @PolycarpTCOJC: I wonder how many people realize that nearly 4 billion dollars were spent in this election. &lt;~ :(",
    "id" : 29527134586,
    "created_at" : "2010-11-03 01:28:43 +0000",
    "user" : {
      "name" : "Christi Bowman",
      "screen_name" : "fastingfoody",
      "protected" : false,
      "id_str" : "199743576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499337090\/fastingfoody_normal.jpg",
      "id" : 199743576,
      "verified" : false
    }
  },
  "id" : 29529915518,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pj johnson Yukon",
      "screen_name" : "pjjohnsonYukon",
      "indices" : [ 3, 18 ],
      "id_str" : "113514329",
      "id" : 113514329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 103, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29530048753",
  "text" : "RT @pjjohnsonYukon: Just because someone disagrees with you doesn\u2019t mean they are wrong. ~ pj johnson  #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 83, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29526522146",
    "text" : "Just because someone disagrees with you doesn\u2019t mean they are wrong. ~ pj johnson  #quote",
    "id" : 29526522146,
    "created_at" : "2010-11-03 01:21:45 +0000",
    "user" : {
      "name" : "pj johnson Yukon",
      "screen_name" : "pjjohnsonYukon",
      "protected" : false,
      "id_str" : "113514329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762329024680951808\/xaVPixN8_normal.jpg",
      "id" : 113514329,
      "verified" : false
    }
  },
  "id" : 29530048753,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pitbull",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29530455016",
  "text" : "RT @mindymayhem: #pitbull in the park (funny face cos I distracted him with a strange sound!) http:\/\/twitpic.com\/33dyk0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pitbull",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29526169608",
    "text" : "#pitbull in the park (funny face cos I distracted him with a strange sound!) http:\/\/twitpic.com\/33dyk0",
    "id" : 29526169608,
    "created_at" : "2010-11-03 01:17:55 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 29530455016,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tzu",
      "screen_name" : "duhism",
      "indices" : [ 3, 10 ],
      "id_str" : "27700636",
      "id" : 27700636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29530964688",
  "text" : "RT @duhism: I'm pretty sure that I'm on the path of enlightenment so, no, I do NOT need to stop and ask for directions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29529459698",
    "text" : "I'm pretty sure that I'm on the path of enlightenment so, no, I do NOT need to stop and ask for directions.",
    "id" : 29529459698,
    "created_at" : "2010-11-03 01:55:47 +0000",
    "user" : {
      "name" : "Bob Tzu",
      "screen_name" : "duhism",
      "protected" : false,
      "id_str" : "27700636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/136471861\/pictest1_normal.jpg",
      "id" : 27700636,
      "verified" : false
    }
  },
  "id" : 29530964688,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Hunter",
      "screen_name" : "amyandwillow",
      "indices" : [ 3, 16 ],
      "id_str" : "188067857",
      "id" : 188067857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29531111348",
  "text" : "RT @amyandwillow: What you think about comes about. So think about what you think about...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29531067792",
    "text" : "What you think about comes about. So think about what you think about...",
    "id" : 29531067792,
    "created_at" : "2010-11-03 02:15:25 +0000",
    "user" : {
      "name" : "Amy Hunter",
      "screen_name" : "amyandwillow",
      "protected" : false,
      "id_str" : "188067857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120602620\/lab11_normal.jpg",
      "id" : 188067857,
      "verified" : false
    }
  },
  "id" : 29531111348,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 3, 17 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29601333897",
  "text" : "RT @Unique_Misfit: People don't appreciate how heartbreaking it is when a pet dies. It's just as bad as a human bereavement.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29600652779",
    "text" : "People don't appreciate how heartbreaking it is when a pet dies. It's just as bad as a human bereavement.",
    "id" : 29600652779,
    "created_at" : "2010-11-03 19:52:09 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 29601333897,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29601401910",
  "text" : "RT @petsalive: Don;t forget that Pets Alive also runs the Pet Chow Pantry! Please donate or direct people to us for help! http:\/\/www.pet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29600033879",
    "text" : "Don;t forget that Pets Alive also runs the Pet Chow Pantry! Please donate or direct people to us for help! http:\/\/www.petchowpantry.org\/",
    "id" : 29600033879,
    "created_at" : "2010-11-03 19:42:55 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 29601401910,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 3, 17 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29601640563",
  "text" : "RT @Unique_Misfit: Ah books make life worthwhile.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29591399918",
    "text" : "Ah books make life worthwhile.",
    "id" : 29591399918,
    "created_at" : "2010-11-03 17:35:12 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 29601640563,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29507673109",
  "text" : ": (   Iranian authorities give go-ahead to execute woman http:\/\/bit.ly\/9JytXs [Like it? http:\/\/bit.ly\/9GKMbE ]",
  "id" : 29507673109,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]