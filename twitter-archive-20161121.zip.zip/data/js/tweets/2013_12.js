Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/rpzoQEZQXc",
      "expanded_url" : "http:\/\/wp.me\/p1pu8r-7X1",
      "display_url" : "wp.me\/p1pu8r-7X1"
    } ]
  },
  "geo" : { },
  "id_str" : "418154857242296321",
  "text" : "RT @adamrshields: Amazon Prime Trial Membership http:\/\/t.co\/rpzoQEZQXc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/rpzoQEZQXc",
        "expanded_url" : "http:\/\/wp.me\/p1pu8r-7X1",
        "display_url" : "wp.me\/p1pu8r-7X1"
      } ]
    },
    "geo" : { },
    "id_str" : "418151908293873664",
    "text" : "Amazon Prime Trial Membership http:\/\/t.co\/rpzoQEZQXc",
    "id" : 418151908293873664,
    "created_at" : "2013-12-31 22:49:18 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 418154857242296321,
  "created_at" : "2013-12-31 23:01:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/417724835842646017\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/S6j5b4YSGD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcwOhmbCYAAEn5x.jpg",
      "id_str" : "417724835851034624",
      "id" : 417724835851034624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcwOhmbCYAAEn5x.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/S6j5b4YSGD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417725935245623296",
  "text" : "RT @jacqueduncalf: \"The ruddy cheek it just rammed it's way through\"Listen ere woman my needs are greater than yours\" http:\/\/t.co\/S6j5b4YSGD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/417724835842646017\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/S6j5b4YSGD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcwOhmbCYAAEn5x.jpg",
        "id_str" : "417724835851034624",
        "id" : 417724835851034624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcwOhmbCYAAEn5x.jpg",
        "sizes" : [ {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/S6j5b4YSGD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417724835842646017",
    "text" : "\"The ruddy cheek it just rammed it's way through\"Listen ere woman my needs are greater than yours\" http:\/\/t.co\/S6j5b4YSGD",
    "id" : 417724835842646017,
    "created_at" : "2013-12-30 18:32:16 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 417725935245623296,
  "created_at" : "2013-12-30 18:36:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    }, {
      "name" : "\u041D\u0430\u0441\u0442\u0435\u043D\u0430 \u041D\u043E\u0432\u0438\u043A\u043E\u0432\u0430",
      "screen_name" : "jeffwired",
      "indices" : [ 20, 30 ],
      "id_str" : "2375648636",
      "id" : 2375648636
    }, {
      "name" : "dora wiilliams",
      "screen_name" : "rodeodance",
      "indices" : [ 35, 46 ],
      "id_str" : "60684098",
      "id" : 60684098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417700779387265024",
  "text" : "RT @TheOracle13: RT @jeffwired: RT @rodeodance Watch: Koch Brothers Caught Red-Handed Buying Economics Professors and Studies  http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweko.com\" rel=\"nofollow\"\u003ETweko\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u041D\u0430\u0441\u0442\u0435\u043D\u0430 \u041D\u043E\u0432\u0438\u043A\u043E\u0432\u0430",
        "screen_name" : "jeffwired",
        "indices" : [ 3, 13 ],
        "id_str" : "2375648636",
        "id" : 2375648636
      }, {
        "name" : "dora wiilliams",
        "screen_name" : "rodeodance",
        "indices" : [ 18, 29 ],
        "id_str" : "60684098",
        "id" : 60684098
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/bTjXfgzroi",
        "expanded_url" : "http:\/\/www.occupydemocrats.com\/watch-koch-brothers-caught-red-handed-buying-economics-professors-and-studies\/",
        "display_url" : "occupydemocrats.com\/watch-koch-bro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417699218183426049",
    "text" : "RT @jeffwired: RT @rodeodance Watch: Koch Brothers Caught Red-Handed Buying Economics Professors and Studies  http:\/\/t.co\/bTjXfgzroi",
    "id" : 417699218183426049,
    "created_at" : "2013-12-30 16:50:28 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 417700779387265024,
  "created_at" : "2013-12-30 16:56:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UMpMcM9MWg",
      "expanded_url" : "http:\/\/www.theblaze.com\/stories\/2012\/01\/27\/wis-teacher-refuses-award-from-paul-ryan-during-mlk-ceremony-lackey-for-the-1\/?utm_source=twitter&utm_medium=story&utm_campaign=ShareButtons",
      "display_url" : "theblaze.com\/stories\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417646462856474624",
  "text" : "Wis. Teacher Refuses Award From Paul Ryan During MLK Ceremony: \u2018Lackey for the 1%\u2019 http:\/\/t.co\/UMpMcM9MWg",
  "id" : 417646462856474624,
  "created_at" : "2013-12-30 13:20:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 3, 9 ],
      "id_str" : "2836421",
      "id" : 2836421
    }, {
      "name" : "Melissa @ MSNBC",
      "screen_name" : "MHPshow",
      "indices" : [ 122, 130 ],
      "id_str" : "475286355",
      "id" : 475286355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdland",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417317078102974464",
  "text" : "RT @msnbc: Between 1980 and 2012, the U.S. went from spending $540 million in prisons to spending $6.4 billion. #nerdland @MHPShow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa @ MSNBC",
        "screen_name" : "MHPshow",
        "indices" : [ 111, 119 ],
        "id_str" : "475286355",
        "id" : 475286355
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nerdland",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416956377207427073",
    "text" : "Between 1980 and 2012, the U.S. went from spending $540 million in prisons to spending $6.4 billion. #nerdland @MHPShow",
    "id" : 416956377207427073,
    "created_at" : "2013-12-28 15:38:41 +0000",
    "user" : {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "protected" : false,
      "id_str" : "2836421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753308587498364928\/b53eqF6C_normal.jpg",
      "id" : 2836421,
      "verified" : true
    }
  },
  "id" : 417317078102974464,
  "created_at" : "2013-12-29 15:31:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/0JHlbeNgf6",
      "expanded_url" : "http:\/\/amzn.to\/TsCBQW",
      "display_url" : "amzn.to\/TsCBQW"
    } ]
  },
  "geo" : { },
  "id_str" : "417131720920821760",
  "text" : "finished The Park Service: Book One of The Park Service Trilogy by Ryan Winfield http:\/\/t.co\/0JHlbeNgf6",
  "id" : 417131720920821760,
  "created_at" : "2013-12-29 03:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 3, 15 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/3rl4iFuxUF",
      "expanded_url" : "http:\/\/theatln.tc\/1cVZc2k",
      "display_url" : "theatln.tc\/1cVZc2k"
    } ]
  },
  "geo" : { },
  "id_str" : "417103537609654272",
  "text" : "RT @TheAtlantic: Can Vermont's single-payer system fix American healthcare? http:\/\/t.co\/3rl4iFuxUF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/3rl4iFuxUF",
        "expanded_url" : "http:\/\/theatln.tc\/1cVZc2k",
        "display_url" : "theatln.tc\/1cVZc2k"
      } ]
    },
    "geo" : { },
    "id_str" : "417068192612110336",
    "text" : "Can Vermont's single-payer system fix American healthcare? http:\/\/t.co\/3rl4iFuxUF",
    "id" : 417068192612110336,
    "created_at" : "2013-12-28 23:03:00 +0000",
    "user" : {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "protected" : false,
      "id_str" : "35773039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268207868\/twitter-icon-main_normal.png",
      "id" : 35773039,
      "verified" : true
    }
  },
  "id" : 417103537609654272,
  "created_at" : "2013-12-29 01:23:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sevenbowie",
      "screen_name" : "sevenbowie",
      "indices" : [ 3, 14 ],
      "id_str" : "85460092",
      "id" : 85460092
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sevenbowie\/status\/417067277461114880\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/k0psEj90CL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcm4epWCIAAZlld.jpg",
      "id_str" : "417067277142335488",
      "id" : 417067277142335488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcm4epWCIAAZlld.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/k0psEj90CL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417079299305664512",
  "text" : "RT @sevenbowie: Next time someone tells you welfare is bad for the economy ... http:\/\/t.co\/k0psEj90CL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sevenbowie\/status\/417067277461114880\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/k0psEj90CL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcm4epWCIAAZlld.jpg",
        "id_str" : "417067277142335488",
        "id" : 417067277142335488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcm4epWCIAAZlld.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/k0psEj90CL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417067277461114880",
    "text" : "Next time someone tells you welfare is bad for the economy ... http:\/\/t.co\/k0psEj90CL",
    "id" : 417067277461114880,
    "created_at" : "2013-12-28 22:59:22 +0000",
    "user" : {
      "name" : "sevenbowie",
      "screen_name" : "sevenbowie",
      "protected" : false,
      "id_str" : "85460092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796574870679199744\/OVdr85bS_normal.jpg",
      "id" : 85460092,
      "verified" : false
    }
  },
  "id" : 417079299305664512,
  "created_at" : "2013-12-28 23:47:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417070324086497280",
  "text" : "RT @CrystalLewis: \"So Matthew's 'kingdom of heaven,' isn\u2019t about an otherworldly heaven \u2013 it isn\u2019t a concept of the afterlife at all.\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FRP7CeDAJr",
        "expanded_url" : "http:\/\/livingthequestionsonline.com\/2013\/12\/28\/jesus-didnt-give-a-rip-about-heaven\/",
        "display_url" : "livingthequestionsonline.com\/2013\/12\/28\/jes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417069953670324224",
    "text" : "\"So Matthew's 'kingdom of heaven,' isn\u2019t about an otherworldly heaven \u2013 it isn\u2019t a concept of the afterlife at all.\" http:\/\/t.co\/FRP7CeDAJr",
    "id" : 417069953670324224,
    "created_at" : "2013-12-28 23:10:00 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 417070324086497280,
  "created_at" : "2013-12-28 23:11:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417069953670324224",
  "geo" : { },
  "id_str" : "417070302812585985",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis Yes!",
  "id" : 417070302812585985,
  "in_reply_to_status_id" : 417069953670324224,
  "created_at" : "2013-12-28 23:11:23 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416969005648191488",
  "text" : "when watching peanuts special.. it really bothered me that Linus' grandma took away his blanket.",
  "id" : 416969005648191488,
  "created_at" : "2013-12-28 16:28:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416958343572230145",
  "text" : "@Skeptical_Lady LOLOL",
  "id" : 416958343572230145,
  "created_at" : "2013-12-28 15:46:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lim\u00F3n fresco",
      "screen_name" : "enemycollision",
      "indices" : [ 0, 15 ],
      "id_str" : "18255552",
      "id" : 18255552
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 79, 94 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416757177219444737",
  "geo" : { },
  "id_str" : "416937344432750593",
  "in_reply_to_user_id" : 18255552,
  "text" : "@enemycollision i was joking.. i think :P (as one who is not good at anything) @1stCitizenKane",
  "id" : 416937344432750593,
  "in_reply_to_status_id" : 416757177219444737,
  "created_at" : "2013-12-28 14:23:03 +0000",
  "in_reply_to_screen_name" : "enemycollision",
  "in_reply_to_user_id_str" : "18255552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Adam R. B. Jack",
      "screen_name" : "adam_jack",
      "indices" : [ 65, 75 ],
      "id_str" : "11798892",
      "id" : 11798892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "Grand_Teton_National_Park_WY",
      "indices" : [ 92, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ZOWF7neJiP",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/9561",
      "display_url" : "wildobs.com\/wo\/9561"
    } ]
  },
  "geo" : { },
  "id_str" : "416771010315452416",
  "text" : "RT @wildobs: For the late crowd: Moose http:\/\/t.co\/ZOWF7neJiP by @adam_jack #EOTD #wildlife #Grand_Teton_National_Park_WY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam R. B. Jack",
        "screen_name" : "adam_jack",
        "indices" : [ 52, 62 ],
        "id_str" : "11798892",
        "id" : 11798892
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 69, 78 ]
      }, {
        "text" : "Grand_Teton_National_Park_WY",
        "indices" : [ 79, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/ZOWF7neJiP",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/9561",
        "display_url" : "wildobs.com\/wo\/9561"
      } ]
    },
    "geo" : { },
    "id_str" : "416766748008779776",
    "text" : "For the late crowd: Moose http:\/\/t.co\/ZOWF7neJiP by @adam_jack #EOTD #wildlife #Grand_Teton_National_Park_WY",
    "id" : 416766748008779776,
    "created_at" : "2013-12-28 03:05:10 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 416771010315452416,
  "created_at" : "2013-12-28 03:22:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416756537940774912",
  "geo" : { },
  "id_str" : "416757509601230848",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 good to know, thanks. : )",
  "id" : 416757509601230848,
  "in_reply_to_status_id" : 416756537940774912,
  "created_at" : "2013-12-28 02:28:27 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416755812636561408",
  "text" : "RT @ChrisCapparell: Follow your heart and the positive signs will follow you. Ignore the negative signs. This is what I have learned.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416748264948760576",
    "text" : "Follow your heart and the positive signs will follow you. Ignore the negative signs. This is what I have learned.",
    "id" : 416748264948760576,
    "created_at" : "2013-12-28 01:51:43 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 416755812636561408,
  "created_at" : "2013-12-28 02:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416748264948760576",
  "geo" : { },
  "id_str" : "416755792474157056",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell Yes!!",
  "id" : 416755792474157056,
  "in_reply_to_status_id" : 416748264948760576,
  "created_at" : "2013-12-28 02:21:38 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lim\u00F3n fresco",
      "screen_name" : "enemycollision",
      "indices" : [ 0, 15 ],
      "id_str" : "18255552",
      "id" : 18255552
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 45, 60 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416749323833987073",
  "geo" : { },
  "id_str" : "416755582633140225",
  "in_reply_to_user_id" : 18255552,
  "text" : "@enemycollision agreed.. isn't it sickening? @1stCitizenKane",
  "id" : 416755582633140225,
  "in_reply_to_status_id" : 416749323833987073,
  "created_at" : "2013-12-28 02:20:48 +0000",
  "in_reply_to_screen_name" : "enemycollision",
  "in_reply_to_user_id_str" : "18255552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I am what I am!",
      "screen_name" : "nevermore_007",
      "indices" : [ 3, 17 ],
      "id_str" : "236093569",
      "id" : 236093569
    }, {
      "name" : "Leo Yak",
      "screen_name" : "Leonor188",
      "indices" : [ 30, 40 ],
      "id_str" : "1909606682",
      "id" : 1909606682
    }, {
      "name" : "\u043D\u0435 \u044F \u043D\u0435",
      "screen_name" : "tsygan48",
      "indices" : [ 56, 65 ],
      "id_str" : "496067564",
      "id" : 496067564
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SRabelt\/status\/410122435535450112\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/IHjMSIAreM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbEMLqTCMAARM6h.jpg",
      "id_str" : "410122435539644416",
      "id" : 410122435539644416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbEMLqTCMAARM6h.jpg",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 1004
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 1004
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IHjMSIAreM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416754800710385664",
  "text" : "RT @nevermore_007: My turf!  \"@Leonor188: ***Bellos*** \"@tsygan48: \u0424\u0423\u0423\u0423 \u041D\u0410\u0424\u0418\u0413, \u0401\u041C\u0410\u0401...\nhttp:\/\/t.co\/IHjMSIAreM\"\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leo Yak",
        "screen_name" : "Leonor188",
        "indices" : [ 11, 21 ],
        "id_str" : "1909606682",
        "id" : 1909606682
      }, {
        "name" : "\u043D\u0435 \u044F \u043D\u0435",
        "screen_name" : "tsygan48",
        "indices" : [ 37, 46 ],
        "id_str" : "496067564",
        "id" : 496067564
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SRabelt\/status\/410122435535450112\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/IHjMSIAreM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbEMLqTCMAARM6h.jpg",
        "id_str" : "410122435539644416",
        "id" : 410122435539644416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbEMLqTCMAARM6h.jpg",
        "sizes" : [ {
          "h" : 801,
          "resize" : "fit",
          "w" : 1004
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 801,
          "resize" : "fit",
          "w" : 1004
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IHjMSIAreM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416752652731826176",
    "text" : "My turf!  \"@Leonor188: ***Bellos*** \"@tsygan48: \u0424\u0423\u0423\u0423 \u041D\u0410\u0424\u0418\u0413, \u0401\u041C\u0410\u0401...\nhttp:\/\/t.co\/IHjMSIAreM\"\"",
    "id" : 416752652731826176,
    "created_at" : "2013-12-28 02:09:09 +0000",
    "user" : {
      "name" : "I am what I am!",
      "screen_name" : "nevermore_007",
      "protected" : false,
      "id_str" : "236093569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549231353859149824\/RYqzze3P_normal.jpeg",
      "id" : 236093569,
      "verified" : false
    }
  },
  "id" : 416754800710385664,
  "created_at" : "2013-12-28 02:17:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I am what I am!",
      "screen_name" : "nevermore_007",
      "indices" : [ 0, 14 ],
      "id_str" : "236093569",
      "id" : 236093569
    }, {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 19, 28 ],
      "id_str" : "490591746",
      "id" : 490591746
    }, {
      "name" : "Leo Yak",
      "screen_name" : "Leonor188",
      "indices" : [ 29, 39 ],
      "id_str" : "1909606682",
      "id" : 1909606682
    }, {
      "name" : "\u043D\u0435 \u044F \u043D\u0435",
      "screen_name" : "tsygan48",
      "indices" : [ 40, 49 ],
      "id_str" : "496067564",
      "id" : 496067564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416752652731826176",
  "geo" : { },
  "id_str" : "416754783433670656",
  "in_reply_to_user_id" : 236093569,
  "text" : "@nevermore_007 LOL @BobTarte @Leonor188 @tsygan48",
  "id" : 416754783433670656,
  "in_reply_to_status_id" : 416752652731826176,
  "created_at" : "2013-12-28 02:17:37 +0000",
  "in_reply_to_screen_name" : "nevermore_007",
  "in_reply_to_user_id_str" : "236093569",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "acidreflux",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416754403769454592",
  "text" : "honey.. it's good for what ails you! #acidreflux",
  "id" : 416754403769454592,
  "created_at" : "2013-12-28 02:16:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416743152972611584",
  "text" : "it's a big responsibility just to exist...",
  "id" : 416743152972611584,
  "created_at" : "2013-12-28 01:31:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "179732982",
      "id" : 179732982
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 26, 35 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416598229783158784",
  "text" : "RT @TheDailyEdge: Note to @Buzzfeed: Paul Ryan is 'a champion of the poor' the same way Rick Santorum is 'a lover of the gays.'\nhttp:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 8, 17 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/I4vsLlNz0V",
        "expanded_url" : "http:\/\/thinkprogress.org\/economy\/2013\/12\/20\/3094291\/buzzfeed-paul-ryan-god\/",
        "display_url" : "thinkprogress.org\/economy\/2013\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416590571797377024",
    "text" : "Note to @Buzzfeed: Paul Ryan is 'a champion of the poor' the same way Rick Santorum is 'a lover of the gays.'\nhttp:\/\/t.co\/I4vsLlNz0V",
    "id" : 416590571797377024,
    "created_at" : "2013-12-27 15:25:06 +0000",
    "user" : {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "protected" : false,
      "id_str" : "179732982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655073745510510592\/FX6VgfRw_normal.png",
      "id" : 179732982,
      "verified" : false
    }
  },
  "id" : 416598229783158784,
  "created_at" : "2013-12-27 15:55:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416374280473935872",
  "text" : "more ACV tonight..  ugh.",
  "id" : 416374280473935872,
  "created_at" : "2013-12-27 01:05:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416225701398724608",
  "text" : "love my chickadees. so sweet.. they dont go far when i put food out and they talk to me..lol",
  "id" : 416225701398724608,
  "created_at" : "2013-12-26 15:15:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Musingo",
      "screen_name" : "MusingoApp",
      "indices" : [ 3, 14 ],
      "id_str" : "2157277273",
      "id" : 2157277273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ocean",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416225052611592192",
  "text" : "RT @MusingoApp: The blue whale (the largest animal on our planet) still lives in the #ocean; it's heart's the size of a Volkswagen! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MusingoApp\/status\/416217444949041152\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/aTRrgK7ucn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcazj5KCIAAKKNR.jpg",
        "id_str" : "416217444798046208",
        "id" : 416217444798046208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcazj5KCIAAKKNR.jpg",
        "sizes" : [ {
          "h" : 200,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 113,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/aTRrgK7ucn"
      } ],
      "hashtags" : [ {
        "text" : "ocean",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416217444949041152",
    "text" : "The blue whale (the largest animal on our planet) still lives in the #ocean; it's heart's the size of a Volkswagen! http:\/\/t.co\/aTRrgK7ucn",
    "id" : 416217444949041152,
    "created_at" : "2013-12-26 14:42:26 +0000",
    "user" : {
      "name" : "Musingo",
      "screen_name" : "MusingoApp",
      "protected" : false,
      "id_str" : "2157277273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000651149703\/c4dd2ca3ef9bf756bd9d43b2f23b749a_normal.png",
      "id" : 2157277273,
      "verified" : false
    }
  },
  "id" : 416225052611592192,
  "created_at" : "2013-12-26 15:12:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "DianeN56",
      "screen_name" : "DianeN56",
      "indices" : [ 20, 29 ],
      "id_str" : "30971909",
      "id" : 30971909
    }, {
      "name" : "Jim Braswell",
      "screen_name" : "ShowMeNature",
      "indices" : [ 116, 129 ],
      "id_str" : "68475519",
      "id" : 68475519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bird",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "bluebird",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "nature",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "photography",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/sKagKakoBJ",
      "expanded_url" : "http:\/\/bit.ly\/1c8H7Nz",
      "display_url" : "bit.ly\/1c8H7Nz"
    } ]
  },
  "geo" : { },
  "id_str" : "416224653414506496",
  "text" : "RT @oceanshaman: Mt @DianeN56: \"Beauty in the Snow\" http:\/\/t.co\/sKagKakoBJ  #bird #bluebird #nature #photography RT @ShowMeNature http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DianeN56",
        "screen_name" : "DianeN56",
        "indices" : [ 3, 12 ],
        "id_str" : "30971909",
        "id" : 30971909
      }, {
        "name" : "Jim Braswell",
        "screen_name" : "ShowMeNature",
        "indices" : [ 99, 112 ],
        "id_str" : "68475519",
        "id" : 68475519
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DianeN56\/status\/416220219351130112\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/hHOBakSMEl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bca2FZNCYAALrxW.jpg",
        "id_str" : "416220219359518720",
        "id" : 416220219359518720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bca2FZNCYAALrxW.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hHOBakSMEl"
      } ],
      "hashtags" : [ {
        "text" : "bird",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "bluebird",
        "indices" : [ 65, 74 ]
      }, {
        "text" : "nature",
        "indices" : [ 75, 82 ]
      }, {
        "text" : "photography",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/sKagKakoBJ",
        "expanded_url" : "http:\/\/bit.ly\/1c8H7Nz",
        "display_url" : "bit.ly\/1c8H7Nz"
      } ]
    },
    "geo" : { },
    "id_str" : "416222696146735105",
    "text" : "Mt @DianeN56: \"Beauty in the Snow\" http:\/\/t.co\/sKagKakoBJ  #bird #bluebird #nature #photography RT @ShowMeNature http:\/\/t.co\/hHOBakSMEl\"",
    "id" : 416222696146735105,
    "created_at" : "2013-12-26 15:03:18 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 416224653414506496,
  "created_at" : "2013-12-26 15:11:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 0, 12 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "DianeN56",
      "screen_name" : "DianeN56",
      "indices" : [ 13, 22 ],
      "id_str" : "30971909",
      "id" : 30971909
    }, {
      "name" : "Jim Braswell",
      "screen_name" : "ShowMeNature",
      "indices" : [ 23, 36 ],
      "id_str" : "68475519",
      "id" : 68475519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416222696146735105",
  "geo" : { },
  "id_str" : "416224606744084481",
  "in_reply_to_user_id" : 45674330,
  "text" : "@oceanshaman @DianeN56 @ShowMeNature aww.. hello, precious! &lt;3",
  "id" : 416224606744084481,
  "in_reply_to_status_id" : 416222696146735105,
  "created_at" : "2013-12-26 15:10:53 +0000",
  "in_reply_to_screen_name" : "oceanshaman",
  "in_reply_to_user_id_str" : "45674330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416031845122584576",
  "text" : "RT @bunnybuddhism: A bunny will not have enough until he learns to be grateful for what he already has.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "415998478914158592",
    "text" : "A bunny will not have enough until he learns to be grateful for what he already has.",
    "id" : 415998478914158592,
    "created_at" : "2013-12-26 00:12:20 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 416031845122584576,
  "created_at" : "2013-12-26 02:24:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ztN0knAiif",
      "expanded_url" : "http:\/\/bookwi.se\/getting-started\/",
      "display_url" : "bookwi.se\/getting-starte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416022855017451520",
  "text" : "So Now I Have a Kindle, What Do I Do With It? How to Get Started http:\/\/t.co\/ztN0knAiif",
  "id" : 416022855017451520,
  "created_at" : "2013-12-26 01:49:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/415984120888852480\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/SKgz06upzI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcXfWpEIYAAdX-L.jpg",
      "id_str" : "415984120674934784",
      "id" : 415984120674934784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcXfWpEIYAAdX-L.jpg",
      "sizes" : [ {
        "h" : 652,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/SKgz06upzI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415996908558381056",
  "text" : "RT @ebookfriendly: Come back to us frequently for more pics with reading spaces http:\/\/t.co\/SKgz06upzI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/415984120888852480\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/SKgz06upzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcXfWpEIYAAdX-L.jpg",
        "id_str" : "415984120674934784",
        "id" : 415984120674934784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcXfWpEIYAAdX-L.jpg",
        "sizes" : [ {
          "h" : 652,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 652,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 652,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/SKgz06upzI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "415984120888852480",
    "text" : "Come back to us frequently for more pics with reading spaces http:\/\/t.co\/SKgz06upzI",
    "id" : 415984120888852480,
    "created_at" : "2013-12-25 23:15:17 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 415996908558381056,
  "created_at" : "2013-12-26 00:06:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/18MfCtJ0vi",
      "expanded_url" : "http:\/\/www.jqpublic-blog.com\/?p=600",
      "display_url" : "jqpublic-blog.com\/?p=600"
    } ]
  },
  "geo" : { },
  "id_str" : "415517464265363456",
  "text" : "The Right Thing: An Open Letter to Paul Ryan: http:\/\/t.co\/18MfCtJ0vi",
  "id" : 415517464265363456,
  "created_at" : "2013-12-24 16:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "indices" : [ 0, 14 ],
      "id_str" : "20640860",
      "id" : 20640860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415300738814726144",
  "geo" : { },
  "id_str" : "415481396128280576",
  "in_reply_to_user_id" : 20640860,
  "text" : "@homesteadwool it was beautiful. i could imagine sitting there w you listening to their peaceful sleep.",
  "id" : 415481396128280576,
  "in_reply_to_status_id" : 415300738814726144,
  "created_at" : "2013-12-24 13:57:38 +0000",
  "in_reply_to_screen_name" : "homesteadwool",
  "in_reply_to_user_id_str" : "20640860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/X5TFU5m4r7",
      "expanded_url" : "http:\/\/tinyurl.com\/9h3k42u",
      "display_url" : "tinyurl.com\/9h3k42u"
    } ]
  },
  "geo" : { },
  "id_str" : "415311040612925441",
  "text" : "RT @Soulseedzforall: Every obnoxious act is a cry for help. Its rarely a personal attack. http:\/\/t.co\/X5TFU5m4r7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/X5TFU5m4r7",
        "expanded_url" : "http:\/\/tinyurl.com\/9h3k42u",
        "display_url" : "tinyurl.com\/9h3k42u"
      } ]
    },
    "geo" : { },
    "id_str" : "415310335029956609",
    "text" : "Every obnoxious act is a cry for help. Its rarely a personal attack. http:\/\/t.co\/X5TFU5m4r7",
    "id" : 415310335029956609,
    "created_at" : "2013-12-24 02:37:54 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 415311040612925441,
  "created_at" : "2013-12-24 02:40:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camille LaGuire",
      "screen_name" : "camillelaguire",
      "indices" : [ 3, 18 ],
      "id_str" : "137536109",
      "id" : 137536109
    }, {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "indices" : [ 20, 32 ],
      "id_str" : "26029878",
      "id" : 26029878
    }, {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 33, 45 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415299813849452544",
  "text" : "RT @camillelaguire: @ChuckWendig @tommysalami Yep, when you hit a kid, all you actually teach them is that you approve of hitting others to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chuck Wendig",
        "screen_name" : "ChuckWendig",
        "indices" : [ 0, 12 ],
        "id_str" : "26029878",
        "id" : 26029878
      }, {
        "name" : "Thomas Pluck",
        "screen_name" : "tommysalami",
        "indices" : [ 13, 25 ],
        "id_str" : "261888721",
        "id" : 261888721
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "415296310385070081",
    "geo" : { },
    "id_str" : "415297638724956161",
    "in_reply_to_user_id" : 26029878,
    "text" : "@ChuckWendig @tommysalami Yep, when you hit a kid, all you actually teach them is that you approve of hitting others to get your way.",
    "id" : 415297638724956161,
    "in_reply_to_status_id" : 415296310385070081,
    "created_at" : "2013-12-24 01:47:27 +0000",
    "in_reply_to_screen_name" : "ChuckWendig",
    "in_reply_to_user_id_str" : "26029878",
    "user" : {
      "name" : "Camille LaGuire",
      "screen_name" : "camillelaguire",
      "protected" : false,
      "id_str" : "137536109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747092909988679681\/-sUwEaD7_normal.jpg",
      "id" : 137536109,
      "verified" : false
    }
  },
  "id" : 415299813849452544,
  "created_at" : "2013-12-24 01:56:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "indices" : [ 3, 15 ],
      "id_str" : "26029878",
      "id" : 26029878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "terribleminds",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/F2t7mc9yG4",
      "expanded_url" : "http:\/\/terribleminds.com\/ramble\/2013\/12\/23\/spanking-your-children-is-hitting-your-children\/",
      "display_url" : "terribleminds.com\/ramble\/2013\/12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415299321081626624",
  "text" : "RT @ChuckWendig: In which I get ranty-spittin'-frothy-mad about that spanking meme on Facebook: http:\/\/t.co\/F2t7mc9yG4 #terribleminds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "terribleminds",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/F2t7mc9yG4",
        "expanded_url" : "http:\/\/terribleminds.com\/ramble\/2013\/12\/23\/spanking-your-children-is-hitting-your-children\/",
        "display_url" : "terribleminds.com\/ramble\/2013\/12\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "415296310385070081",
    "text" : "In which I get ranty-spittin'-frothy-mad about that spanking meme on Facebook: http:\/\/t.co\/F2t7mc9yG4 #terribleminds",
    "id" : 415296310385070081,
    "created_at" : "2013-12-24 01:42:10 +0000",
    "user" : {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "protected" : false,
      "id_str" : "26029878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642026672636731392\/_krOPqwm_normal.jpg",
      "id" : 26029878,
      "verified" : true
    }
  },
  "id" : 415299321081626624,
  "created_at" : "2013-12-24 01:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "indices" : [ 0, 12 ],
      "id_str" : "26029878",
      "id" : 26029878
    }, {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 20, 32 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415296310385070081",
  "geo" : { },
  "id_str" : "415299298658504704",
  "in_reply_to_user_id" : 26029878,
  "text" : "@ChuckWendig Amen!! @tommysalami",
  "id" : 415299298658504704,
  "in_reply_to_status_id" : 415296310385070081,
  "created_at" : "2013-12-24 01:54:03 +0000",
  "in_reply_to_screen_name" : "ChuckWendig",
  "in_reply_to_user_id_str" : "26029878",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali R. Rodriguez",
      "screen_name" : "Ali4Coach",
      "indices" : [ 3, 13 ],
      "id_str" : "14089271",
      "id" : 14089271
    }, {
      "name" : "Cam and Lauren",
      "screen_name" : "WrittenWoman",
      "indices" : [ 75, 88 ],
      "id_str" : "272930509",
      "id" : 272930509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/pPGclwA9r3",
      "expanded_url" : "http:\/\/thewellwrittenwoman.com\/an-open-letter-to-phil-robertson\/#.Urjkm9QQXLc.twitter",
      "display_url" : "thewellwrittenwoman.com\/an-open-letter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415298262414135296",
  "text" : "RT @Ali4Coach: An Open Letter to Phil Robertson http:\/\/t.co\/pPGclwA9r3 via @WrittenWoman - Interesting article!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cam and Lauren",
        "screen_name" : "WrittenWoman",
        "indices" : [ 60, 73 ],
        "id_str" : "272930509",
        "id" : 272930509
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/pPGclwA9r3",
        "expanded_url" : "http:\/\/thewellwrittenwoman.com\/an-open-letter-to-phil-robertson\/#.Urjkm9QQXLc.twitter",
        "display_url" : "thewellwrittenwoman.com\/an-open-letter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "415294433815298048",
    "text" : "An Open Letter to Phil Robertson http:\/\/t.co\/pPGclwA9r3 via @WrittenWoman - Interesting article!",
    "id" : 415294433815298048,
    "created_at" : "2013-12-24 01:34:43 +0000",
    "user" : {
      "name" : "Ali R. Rodriguez",
      "screen_name" : "Ali4Coach",
      "protected" : false,
      "id_str" : "14089271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586527922791452674\/pslV7ee8_normal.png",
      "id" : 14089271,
      "verified" : false
    }
  },
  "id" : 415298262414135296,
  "created_at" : "2013-12-24 01:49:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "indices" : [ 3, 17 ],
      "id_str" : "20640860",
      "id" : 20640860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/j6335nnWIY",
      "expanded_url" : "http:\/\/us2.campaign-archive1.com\/?u=61c12080c2822012d70de74ee&id=7fec7ec070",
      "display_url" : "us2.campaign-archive1.com\/?u=61c12080c28\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415296422075195392",
  "text" : "RT @homesteadwool: Happy Holidays from the sheep!: A silent night with the sheep. http:\/\/t.co\/j6335nnWIY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/j6335nnWIY",
        "expanded_url" : "http:\/\/us2.campaign-archive1.com\/?u=61c12080c2822012d70de74ee&id=7fec7ec070",
        "display_url" : "us2.campaign-archive1.com\/?u=61c12080c28\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "415292581098975232",
    "text" : "Happy Holidays from the sheep!: A silent night with the sheep. http:\/\/t.co\/j6335nnWIY",
    "id" : 415292581098975232,
    "created_at" : "2013-12-24 01:27:21 +0000",
    "user" : {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "protected" : false,
      "id_str" : "20640860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462783906903629824\/PO5lx_HY_normal.jpeg",
      "id" : 20640860,
      "verified" : false
    }
  },
  "id" : 415296422075195392,
  "created_at" : "2013-12-24 01:42:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 0, 16 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415266657712746496",
  "geo" : { },
  "id_str" : "415292076218015744",
  "in_reply_to_user_id" : 175204121,
  "text" : "@WildlifeGadgets watching him dream away.. adorbs!!",
  "id" : 415292076218015744,
  "in_reply_to_status_id" : 415266657712746496,
  "created_at" : "2013-12-24 01:25:21 +0000",
  "in_reply_to_screen_name" : "WildlifeGadgets",
  "in_reply_to_user_id_str" : "175204121",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415101098144198657",
  "geo" : { },
  "id_str" : "415109470876745728",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous LOLOL :D",
  "id" : 415109470876745728,
  "in_reply_to_status_id" : 415101098144198657,
  "created_at" : "2013-12-23 13:19:44 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 3, 19 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/XAtbiXooZO",
      "expanded_url" : "http:\/\/twitpic.com\/dpox86",
      "display_url" : "twitpic.com\/dpox86"
    } ]
  },
  "geo" : { },
  "id_str" : "415108353506152448",
  "text" : "RT @HighlandFarmsME: ICY BACKSCRATCH. Young Beatrice finds a cool way to get some itch relief.  http:\/\/t.co\/XAtbiXooZO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/XAtbiXooZO",
        "expanded_url" : "http:\/\/twitpic.com\/dpox86",
        "display_url" : "twitpic.com\/dpox86"
      } ]
    },
    "geo" : { },
    "id_str" : "415106391833989121",
    "text" : "ICY BACKSCRATCH. Young Beatrice finds a cool way to get some itch relief.  http:\/\/t.co\/XAtbiXooZO",
    "id" : 415106391833989121,
    "created_at" : "2013-12-23 13:07:30 +0000",
    "user" : {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "protected" : false,
      "id_str" : "1050419874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046136643\/52b682fed61ae8e3cd6692fcb7e54ab8_normal.jpeg",
      "id" : 1050419874,
      "verified" : false
    }
  },
  "id" : 415108353506152448,
  "created_at" : "2013-12-23 13:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Organic Live Foods",
      "screen_name" : "OrganicLiveFood",
      "indices" : [ 3, 19 ],
      "id_str" : "444378105",
      "id" : 444378105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GMO",
      "indices" : [ 74, 78 ]
    }, {
      "text" : "neonicotinoid",
      "indices" : [ 103, 117 ]
    }, {
      "text" : "pesticides",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414950961313234945",
  "text" : "RT @OrganicLiveFood: 37 millions bees found dead in Canada after planting #GMO corn field treated with #neonicotinoid class of #pesticides \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GMO",
        "indices" : [ 53, 57 ]
      }, {
        "text" : "neonicotinoid",
        "indices" : [ 82, 96 ]
      }, {
        "text" : "pesticides",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/PNkqgKl1si",
        "expanded_url" : "http:\/\/bit.ly\/1aGnkdC",
        "display_url" : "bit.ly\/1aGnkdC"
      } ]
    },
    "geo" : { },
    "id_str" : "414915923490123776",
    "text" : "37 millions bees found dead in Canada after planting #GMO corn field treated with #neonicotinoid class of #pesticides http:\/\/t.co\/PNkqgKl1si",
    "id" : 414915923490123776,
    "created_at" : "2013-12-23 00:30:39 +0000",
    "user" : {
      "name" : "Organic Live Foods",
      "screen_name" : "OrganicLiveFood",
      "protected" : false,
      "id_str" : "444378105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000790297501\/95a559eb81b3cf714f529ef3f4c6bb36_normal.png",
      "id" : 444378105,
      "verified" : false
    }
  },
  "id" : 414950961313234945,
  "created_at" : "2013-12-23 02:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414913544774488064",
  "text" : "RT @nakedpastor: I've deconstructed the original Christmas good news message so it will make more sense with how we treat it today: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/4MtCBFecul",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nakedpastor\/2013\/12\/a-deconstruction-of-the-christmas-message\/",
        "display_url" : "patheos.com\/blogs\/nakedpas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414910880510271488",
    "text" : "I've deconstructed the original Christmas good news message so it will make more sense with how we treat it today: http:\/\/t.co\/4MtCBFecul",
    "id" : 414910880510271488,
    "created_at" : "2013-12-23 00:10:37 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 414913544774488064,
  "created_at" : "2013-12-23 00:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/414894945858641920\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/u0TzSHht3i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcIAwUJCEAAaVZ_.jpg",
      "id_str" : "414894945711820800",
      "id" : 414894945711820800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcIAwUJCEAAaVZ_.jpg",
      "sizes" : [ {
        "h" : 641,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 641,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 641,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/u0TzSHht3i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414897051496116224",
  "text" : "RT @Chickypoo333: The List http:\/\/t.co\/u0TzSHht3i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/414894945858641920\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/u0TzSHht3i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcIAwUJCEAAaVZ_.jpg",
        "id_str" : "414894945711820800",
        "id" : 414894945711820800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcIAwUJCEAAaVZ_.jpg",
        "sizes" : [ {
          "h" : 641,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 641,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 641,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/u0TzSHht3i"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414894945858641920",
    "text" : "The List http:\/\/t.co\/u0TzSHht3i",
    "id" : 414894945858641920,
    "created_at" : "2013-12-22 23:07:18 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 414897051496116224,
  "created_at" : "2013-12-22 23:15:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 0, 9 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414893359606415360",
  "geo" : { },
  "id_str" : "414894770641571840",
  "in_reply_to_user_id" : 12088232,
  "text" : "@KerriFar precious!!",
  "id" : 414894770641571840,
  "in_reply_to_status_id" : 414893359606415360,
  "created_at" : "2013-12-22 23:06:36 +0000",
  "in_reply_to_screen_name" : "KerriFar",
  "in_reply_to_user_id_str" : "12088232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 0, 9 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414885756302135296",
  "geo" : { },
  "id_str" : "414893527303073792",
  "in_reply_to_user_id" : 490591746,
  "text" : "@BobTarte well, those lights around the birdhouse were cool.. pretty.",
  "id" : 414893527303073792,
  "in_reply_to_status_id" : 414885756302135296,
  "created_at" : "2013-12-22 23:01:39 +0000",
  "in_reply_to_screen_name" : "BobTarte",
  "in_reply_to_user_id_str" : "490591746",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414875821774368768",
  "geo" : { },
  "id_str" : "414893346532753408",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind your xx before xy post",
  "id" : 414893346532753408,
  "in_reply_to_status_id" : 414875821774368768,
  "created_at" : "2013-12-22 23:00:56 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414874683025014784",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind you really should make a link to that post and put it on your blog's sidebar.. make it easier to find..lol : D",
  "id" : 414874683025014784,
  "created_at" : "2013-12-22 21:46:47 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Thiessen",
      "screen_name" : "SamThiessen",
      "indices" : [ 0, 12 ],
      "id_str" : "228448495",
      "id" : 228448495
    }, {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 50, 60 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "The Watcher Grimatu",
      "screen_name" : "GRIMACHU",
      "indices" : [ 61, 70 ],
      "id_str" : "22166232",
      "id" : 22166232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/kW7evDEUrv",
      "expanded_url" : "http:\/\/zachsmind.wordpress.com\/2012\/09\/22\/let-x-equal-x-atheism-skeptic-religion-christian-omgwtf-feminism-bible-etc\/",
      "display_url" : "zachsmind.wordpress.com\/2012\/09\/22\/let\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "414868039402668032",
  "geo" : { },
  "id_str" : "414874062666473472",
  "in_reply_to_user_id" : 228448495,
  "text" : "@SamThiessen here &gt;&gt; http:\/\/t.co\/kW7evDEUrv @ZachsMind @GRIMACHU",
  "id" : 414874062666473472,
  "in_reply_to_status_id" : 414868039402668032,
  "created_at" : "2013-12-22 21:44:19 +0000",
  "in_reply_to_screen_name" : "SamThiessen",
  "in_reply_to_user_id_str" : "228448495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/414856666673188864\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1QS4K99Woi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcHd8LpCEAAcoU-.jpg",
      "id_str" : "414856666681577472",
      "id" : 414856666681577472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcHd8LpCEAAcoU-.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/1QS4K99Woi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414865390427451392",
  "text" : "RT @BobTarte: Santa must be near. There were lights in the air around the bird house early this morning. http:\/\/t.co\/1QS4K99Woi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/414856666673188864\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/1QS4K99Woi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcHd8LpCEAAcoU-.jpg",
        "id_str" : "414856666681577472",
        "id" : 414856666681577472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcHd8LpCEAAcoU-.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/1QS4K99Woi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414856666673188864",
    "text" : "Santa must be near. There were lights in the air around the bird house early this morning. http:\/\/t.co\/1QS4K99Woi",
    "id" : 414856666673188864,
    "created_at" : "2013-12-22 20:35:11 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 414865390427451392,
  "created_at" : "2013-12-22 21:09:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marchella",
      "screen_name" : "1Marchella",
      "indices" : [ 0, 11 ],
      "id_str" : "55113967",
      "id" : 55113967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414854546104401920",
  "geo" : { },
  "id_str" : "414863762965803008",
  "in_reply_to_user_id" : 55113967,
  "text" : "@1Marchella wow.. creepy.. makes one wonder..",
  "id" : 414863762965803008,
  "in_reply_to_status_id" : 414854546104401920,
  "created_at" : "2013-12-22 21:03:23 +0000",
  "in_reply_to_screen_name" : "1Marchella",
  "in_reply_to_user_id_str" : "55113967",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Dorrough",
      "screen_name" : "kamelou9",
      "indices" : [ 0, 9 ],
      "id_str" : "702103989429604353",
      "id" : 702103989429604353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414861652773728256",
  "text" : "@kamelou9 this would make a great wallpaper : ) beautiful! @missysongbird",
  "id" : 414861652773728256,
  "created_at" : "2013-12-22 20:55:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emad Adly Mikhael",
      "screen_name" : "adlyissa",
      "indices" : [ 3, 12 ],
      "id_str" : "757036260",
      "id" : 757036260
    }, {
      "name" : "Kleopatra Aggelidi",
      "screen_name" : "klaggelidi",
      "indices" : [ 15, 26 ],
      "id_str" : "1313001439",
      "id" : 1313001439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/6pUBiJ62bZ",
      "expanded_url" : "https:\/\/twitter.com\/ProprioCosi\/status\/414767534668128256\/photo\/1",
      "display_url" : "pic.twitter.com\/6pUBiJ62bZ"
    } ]
  },
  "geo" : { },
  "id_str" : "414834357720068098",
  "text" : "RT @adlyissa: \u201C@klaggelidi: http:\/\/t.co\/6pUBiJ62bZ\u201D\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kleopatra Aggelidi",
        "screen_name" : "klaggelidi",
        "indices" : [ 1, 12 ],
        "id_str" : "1313001439",
        "id" : 1313001439
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/6pUBiJ62bZ",
        "expanded_url" : "https:\/\/twitter.com\/ProprioCosi\/status\/414767534668128256\/photo\/1",
        "display_url" : "pic.twitter.com\/6pUBiJ62bZ"
      } ]
    },
    "in_reply_to_status_id_str" : "414772407648649216",
    "geo" : { },
    "id_str" : "414829888835952640",
    "in_reply_to_user_id" : 1313001439,
    "text" : "\u201C@klaggelidi: http:\/\/t.co\/6pUBiJ62bZ\u201D\u201D",
    "id" : 414829888835952640,
    "in_reply_to_status_id" : 414772407648649216,
    "created_at" : "2013-12-22 18:48:47 +0000",
    "in_reply_to_screen_name" : "klaggelidi",
    "in_reply_to_user_id_str" : "1313001439",
    "user" : {
      "name" : "Emad Adly Mikhael",
      "screen_name" : "adlyissa",
      "protected" : false,
      "id_str" : "757036260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762986131969437696\/hccmrigx_normal.jpg",
      "id" : 757036260,
      "verified" : false
    }
  },
  "id" : 414834357720068098,
  "created_at" : "2013-12-22 19:06:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414797301203214336",
  "geo" : { },
  "id_str" : "414805698732490752",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses oh god.. ((facepalm))",
  "id" : 414805698732490752,
  "in_reply_to_status_id" : 414797301203214336,
  "created_at" : "2013-12-22 17:12:39 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414790783427178496",
  "text" : "RT @RavenG999: I wish you love, peace, abundance and a true connection with the light and beauty of your own heart and soul.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414774848519299072",
    "text" : "I wish you love, peace, abundance and a true connection with the light and beauty of your own heart and soul.",
    "id" : 414774848519299072,
    "created_at" : "2013-12-22 15:10:04 +0000",
    "user" : {
      "name" : "Raven",
      "screen_name" : "RavenG93",
      "protected" : false,
      "id_str" : "265609488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714562472288641026\/cCB4HghF_normal.jpg",
      "id" : 265609488,
      "verified" : false
    }
  },
  "id" : 414790783427178496,
  "created_at" : "2013-12-22 16:13:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/414778869657665537\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/gflB7weiJ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcGXLysIAAE_AmS.jpg",
      "id_str" : "414778869535997953",
      "id" : 414778869535997953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcGXLysIAAE_AmS.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gflB7weiJ4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414790084458971137",
  "text" : "RT @ravenmaster1: I'm fed up of mouse, I want some crisps! http:\/\/t.co\/gflB7weiJ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/414778869657665537\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/gflB7weiJ4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcGXLysIAAE_AmS.jpg",
        "id_str" : "414778869535997953",
        "id" : 414778869535997953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcGXLysIAAE_AmS.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gflB7weiJ4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414778869657665537",
    "text" : "I'm fed up of mouse, I want some crisps! http:\/\/t.co\/gflB7weiJ4",
    "id" : 414778869657665537,
    "created_at" : "2013-12-22 15:26:03 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 414790084458971137,
  "created_at" : "2013-12-22 16:10:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414784743964946432",
  "geo" : { },
  "id_str" : "414788979456634880",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses aww.. pretty face! looks like shepherd mix.",
  "id" : 414788979456634880,
  "in_reply_to_status_id" : 414784743964946432,
  "created_at" : "2013-12-22 16:06:13 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414788446536736769",
  "text" : "ACV FTW!",
  "id" : 414788446536736769,
  "created_at" : "2013-12-22 16:04:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414564841672556544",
  "geo" : { },
  "id_str" : "414570024116826112",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos lol.. im not allowed to talk anime in my house.. DD cant stand that i dont know the pronunciations.. :D",
  "id" : 414570024116826112,
  "in_reply_to_status_id" : 414564841672556544,
  "created_at" : "2013-12-22 01:36:10 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poppy",
      "screen_name" : "C_inthegarden",
      "indices" : [ 3, 17 ],
      "id_str" : "2193160665",
      "id" : 2193160665
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "OCEAN",
      "indices" : [ 62, 68 ]
    }, {
      "text" : "Blackfish",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414563402976333824",
  "text" : "RT @C_inthegarden: #Blackfish Mammal that size needs a bloody #OCEAN to swim in, why the hell in little tanks #Blackfish prob feels Suicida\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "OCEAN",
        "indices" : [ 43, 49 ]
      }, {
        "text" : "Blackfish",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414560475129864192",
    "text" : "#Blackfish Mammal that size needs a bloody #OCEAN to swim in, why the hell in little tanks #Blackfish prob feels Suicidal. So set him FREE!",
    "id" : 414560475129864192,
    "created_at" : "2013-12-22 00:58:14 +0000",
    "user" : {
      "name" : "Poppy",
      "screen_name" : "C_inthegarden",
      "protected" : false,
      "id_str" : "2193160665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732143057588588544\/SqFXUuLs_normal.jpg",
      "id" : 2193160665,
      "verified" : false
    }
  },
  "id" : 414563402976333824,
  "created_at" : "2013-12-22 01:09:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414559494597664768",
  "text" : "drinking ACV to get my ex galbladder under control...",
  "id" : 414559494597664768,
  "created_at" : "2013-12-22 00:54:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/l7WIydd7oP",
      "expanded_url" : "http:\/\/bit.ly\/1cbVmWv",
      "display_url" : "bit.ly\/1cbVmWv"
    } ]
  },
  "geo" : { },
  "id_str" : "414535967916445696",
  "text" : "RT @Msunbeams: What You Believe About Homosexuality Doesn\u2019t Matter | In The Parlor http:\/\/t.co\/l7WIydd7oP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/l7WIydd7oP",
        "expanded_url" : "http:\/\/bit.ly\/1cbVmWv",
        "display_url" : "bit.ly\/1cbVmWv"
      } ]
    },
    "geo" : { },
    "id_str" : "414532677312970752",
    "text" : "What You Believe About Homosexuality Doesn\u2019t Matter | In The Parlor http:\/\/t.co\/l7WIydd7oP",
    "id" : 414532677312970752,
    "created_at" : "2013-12-21 23:07:46 +0000",
    "user" : {
      "name" : "Bekka Leigh",
      "screen_name" : "_bekkaleigh",
      "protected" : false,
      "id_str" : "341002490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792140692738838528\/6SjPIATQ_normal.jpg",
      "id" : 341002490,
      "verified" : false
    }
  },
  "id" : 414535967916445696,
  "created_at" : "2013-12-21 23:20:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aca",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/CAnqP3iPsg",
      "expanded_url" : "http:\/\/www.addictinginfo.org\/2013\/12\/20\/sanders-obamacare-single-payer\/",
      "display_url" : "addictinginfo.org\/2013\/12\/20\/san\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414535710612664320",
  "text" : "RT @Adenovir: Hey GOP, Here's Your Chance To Repeal Obamacare - Now Put Up Or Shut Up: http:\/\/t.co\/CAnqP3iPsg #aca",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aca",
        "indices" : [ 96, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/CAnqP3iPsg",
        "expanded_url" : "http:\/\/www.addictinginfo.org\/2013\/12\/20\/sanders-obamacare-single-payer\/",
        "display_url" : "addictinginfo.org\/2013\/12\/20\/san\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414529626275209216",
    "text" : "Hey GOP, Here's Your Chance To Repeal Obamacare - Now Put Up Or Shut Up: http:\/\/t.co\/CAnqP3iPsg #aca",
    "id" : 414529626275209216,
    "created_at" : "2013-12-21 22:55:39 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 414535710612664320,
  "created_at" : "2013-12-21 23:19:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414453368258830336",
  "text" : "RT @Buddhaworld: All depends on your thinking. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414443662773583872",
    "text" : "All depends on your thinking. Buddha volko",
    "id" : 414443662773583872,
    "created_at" : "2013-12-21 17:14:03 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 414453368258830336,
  "created_at" : "2013-12-21 17:52:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greytdog",
      "screen_name" : "Greytdog",
      "indices" : [ 3, 12 ],
      "id_str" : "17141349",
      "id" : 17141349
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Greytdog\/status\/414358626929614848\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/94bTGbyBld",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcAY-dACIAEeqaf.jpg",
      "id_str" : "414358626933809153",
      "id" : 414358626933809153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcAY-dACIAEeqaf.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/94bTGbyBld"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Ho4kvUdodD",
      "expanded_url" : "http:\/\/www.angelsrescue.org\/donate\/",
      "display_url" : "angelsrescue.org\/donate\/"
    } ]
  },
  "geo" : { },
  "id_str" : "414390061392998400",
  "text" : "RT @Greytdog: in Atlanta: needs adoption, needs vetting donations. on kill list. please help http:\/\/t.co\/Ho4kvUdodD http:\/\/t.co\/94bTGbyBld",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Greytdog\/status\/414358626929614848\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/94bTGbyBld",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcAY-dACIAEeqaf.jpg",
        "id_str" : "414358626933809153",
        "id" : 414358626933809153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcAY-dACIAEeqaf.jpg",
        "sizes" : [ {
          "h" : 679,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/94bTGbyBld"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Ho4kvUdodD",
        "expanded_url" : "http:\/\/www.angelsrescue.org\/donate\/",
        "display_url" : "angelsrescue.org\/donate\/"
      } ]
    },
    "geo" : { },
    "id_str" : "414358626929614848",
    "text" : "in Atlanta: needs adoption, needs vetting donations. on kill list. please help http:\/\/t.co\/Ho4kvUdodD http:\/\/t.co\/94bTGbyBld",
    "id" : 414358626929614848,
    "created_at" : "2013-12-21 11:36:09 +0000",
    "user" : {
      "name" : "Greytdog",
      "screen_name" : "Greytdog",
      "protected" : false,
      "id_str" : "17141349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800712966274478082\/4hurAvEV_normal.jpg",
      "id" : 17141349,
      "verified" : false
    }
  },
  "id" : 414390061392998400,
  "created_at" : "2013-12-21 13:41:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sha",
      "screen_name" : "maezymare",
      "indices" : [ 3, 13 ],
      "id_str" : "297384220",
      "id" : 297384220
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/maezymare\/status\/414362593797865473\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/1TzYKk4u2r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcAclWSIUAA-AD2.jpg",
      "id_str" : "414362593680445440",
      "id" : 414362593680445440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcAclWSIUAA-AD2.jpg",
      "sizes" : [ {
        "h" : 608,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 710
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 710
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1TzYKk4u2r"
    } ],
    "hashtags" : [ {
      "text" : "stopthecull",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414389513084215296",
  "text" : "RT @maezymare: Beautiful by Wendy Andrew from her Painting Dreams. #stopthecull ... http:\/\/t.co\/1TzYKk4u2r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/maezymare\/status\/414362593797865473\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/1TzYKk4u2r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcAclWSIUAA-AD2.jpg",
        "id_str" : "414362593680445440",
        "id" : 414362593680445440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcAclWSIUAA-AD2.jpg",
        "sizes" : [ {
          "h" : 608,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 710
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 710
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1TzYKk4u2r"
      } ],
      "hashtags" : [ {
        "text" : "stopthecull",
        "indices" : [ 52, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414362593797865473",
    "text" : "Beautiful by Wendy Andrew from her Painting Dreams. #stopthecull ... http:\/\/t.co\/1TzYKk4u2r",
    "id" : 414362593797865473,
    "created_at" : "2013-12-21 11:51:55 +0000",
    "user" : {
      "name" : "Sha",
      "screen_name" : "maezymare",
      "protected" : false,
      "id_str" : "297384220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766707355400757248\/6t8h2j6e_normal.jpg",
      "id" : 297384220,
      "verified" : false
    }
  },
  "id" : 414389513084215296,
  "created_at" : "2013-12-21 13:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414171711500595201",
  "geo" : { },
  "id_str" : "414189677101318144",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist tablet?? ohh, which one, if I may ask? : )",
  "id" : 414189677101318144,
  "in_reply_to_status_id" : 414171711500595201,
  "created_at" : "2013-12-21 00:24:48 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414072967899799553",
  "text" : "the only reason im excited for xmas is that we'll be that much closer to Spring.",
  "id" : 414072967899799553,
  "created_at" : "2013-12-20 16:41:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "Ntchwaidumela",
      "screen_name" : "Pride_Lord",
      "indices" : [ 18, 29 ],
      "id_str" : "1578063061",
      "id" : 1578063061
    }, {
      "name" : "Ms.OpRoar",
      "screen_name" : "OpRoar",
      "indices" : [ 75, 82 ],
      "id_str" : "1597438568",
      "id" : 1597438568
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OpRoar\/status\/411231163957522432\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/GXzHU2yX5R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbT8kJCCQAA9sj5.jpg",
      "id_str" : "411231163827503104",
      "id" : 411231163827503104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbT8kJCCQAA9sj5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 489
      } ],
      "display_url" : "pic.twitter.com\/GXzHU2yX5R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414072428663672833",
  "text" : "RT @oceanshaman: \"@Pride_Lord: Kindness matters http:\/\/t.co\/GXzHU2yX5R via @OpRoar\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ntchwaidumela",
        "screen_name" : "Pride_Lord",
        "indices" : [ 1, 12 ],
        "id_str" : "1578063061",
        "id" : 1578063061
      }, {
        "name" : "Ms.OpRoar",
        "screen_name" : "OpRoar",
        "indices" : [ 58, 65 ],
        "id_str" : "1597438568",
        "id" : 1597438568
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OpRoar\/status\/411231163957522432\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/GXzHU2yX5R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbT8kJCCQAA9sj5.jpg",
        "id_str" : "411231163827503104",
        "id" : 411231163827503104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbT8kJCCQAA9sj5.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 489
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 489
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 489
        } ],
        "display_url" : "pic.twitter.com\/GXzHU2yX5R"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414070810677379072",
    "text" : "\"@Pride_Lord: Kindness matters http:\/\/t.co\/GXzHU2yX5R via @OpRoar\"",
    "id" : 414070810677379072,
    "created_at" : "2013-12-20 16:32:28 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 414072428663672833,
  "created_at" : "2013-12-20 16:38:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dark Faerie Tales",
      "screen_name" : "DarkFaerieTales",
      "indices" : [ 3, 19 ],
      "id_str" : "23559325",
      "id" : 23559325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/dQsavYq8QR",
      "expanded_url" : "http:\/\/bit.ly\/1cItOb6",
      "display_url" : "bit.ly\/1cItOb6"
    } ]
  },
  "geo" : { },
  "id_str" : "414070013159800832",
  "text" : "RT @DarkFaerieTales: Help Wanted: Are you interested in reviewing for Dark Faerie Tales? Click here to apply: http:\/\/t.co\/dQsavYq8QR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/dQsavYq8QR",
        "expanded_url" : "http:\/\/bit.ly\/1cItOb6",
        "display_url" : "bit.ly\/1cItOb6"
      } ]
    },
    "geo" : { },
    "id_str" : "414066695410835456",
    "text" : "Help Wanted: Are you interested in reviewing for Dark Faerie Tales? Click here to apply: http:\/\/t.co\/dQsavYq8QR",
    "id" : 414066695410835456,
    "created_at" : "2013-12-20 16:16:07 +0000",
    "user" : {
      "name" : "Dark Faerie Tales",
      "screen_name" : "DarkFaerieTales",
      "protected" : false,
      "id_str" : "23559325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1493551121\/DFT_Button_normal.jpeg",
      "id" : 23559325,
      "verified" : false
    }
  },
  "id" : 414070013159800832,
  "created_at" : "2013-12-20 16:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Williams",
      "screen_name" : "LCWxDave",
      "indices" : [ 3, 12 ],
      "id_str" : "83410317",
      "id" : 83410317
    }, {
      "name" : "Austin Bond",
      "screen_name" : "austinebond",
      "indices" : [ 55, 67 ],
      "id_str" : "46899751",
      "id" : 46899751
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LCWxDave\/status\/414067502290051072\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/8ZTW3xce2L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb8QMwtIMAASoq8.jpg",
      "id_str" : "414067502160031744",
      "id" : 414067502160031744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb8QMwtIMAASoq8.jpg",
      "sizes" : [ {
        "h" : 592,
        "resize" : "fit",
        "w" : 908
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 908
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8ZTW3xce2L"
    } ],
    "hashtags" : [ {
      "text" : "scwx",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/gkBG1CrOQ7",
      "expanded_url" : "http:\/\/www.wcivmail.com\/OWA\/attachment.ashx?attach=1&id=RgAAAAC10%2ft8s8JjR5CANS1NucBaBwCrNpTn0xosSbFqF%2beLPbPTAAABQr26AABNcQPy33bJTqqqY5PCwFZUAF2%2fgys7AAAJ&attid0=EAC31ufGPlcRTYzQVrxuBAAZ&attcnt=1",
      "display_url" : "wcivmail.com\/OWA\/attachment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414069695881703424",
  "text" : "RT @LCWxDave: Now that's how you do a sunrise!  Thanks @austinebond! #scwx http:\/\/t.co\/gkBG1CrOQ7 http:\/\/t.co\/8ZTW3xce2L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Austin Bond",
        "screen_name" : "austinebond",
        "indices" : [ 41, 53 ],
        "id_str" : "46899751",
        "id" : 46899751
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LCWxDave\/status\/414067502290051072\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/8ZTW3xce2L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb8QMwtIMAASoq8.jpg",
        "id_str" : "414067502160031744",
        "id" : 414067502160031744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb8QMwtIMAASoq8.jpg",
        "sizes" : [ {
          "h" : 592,
          "resize" : "fit",
          "w" : 908
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 908
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8ZTW3xce2L"
      } ],
      "hashtags" : [ {
        "text" : "scwx",
        "indices" : [ 55, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/gkBG1CrOQ7",
        "expanded_url" : "http:\/\/www.wcivmail.com\/OWA\/attachment.ashx?attach=1&id=RgAAAAC10%2ft8s8JjR5CANS1NucBaBwCrNpTn0xosSbFqF%2beLPbPTAAABQr26AABNcQPy33bJTqqqY5PCwFZUAF2%2fgys7AAAJ&attid0=EAC31ufGPlcRTYzQVrxuBAAZ&attcnt=1",
        "display_url" : "wcivmail.com\/OWA\/attachment\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414067502290051072",
    "text" : "Now that's how you do a sunrise!  Thanks @austinebond! #scwx http:\/\/t.co\/gkBG1CrOQ7 http:\/\/t.co\/8ZTW3xce2L",
    "id" : 414067502290051072,
    "created_at" : "2013-12-20 16:19:20 +0000",
    "user" : {
      "name" : "Dave Williams",
      "screen_name" : "LCWxDave",
      "protected" : false,
      "id_str" : "83410317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759098842470047744\/CeSvGSQl_normal.jpg",
      "id" : 83410317,
      "verified" : true
    }
  },
  "id" : 414069695881703424,
  "created_at" : "2013-12-20 16:28:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 3, 16 ],
      "id_str" : "43298413",
      "id" : 43298413
    }, {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "indices" : [ 32, 43 ],
      "id_str" : "16042794",
      "id" : 16042794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/sEzhewFjF1",
      "expanded_url" : "http:\/\/trib.al\/wvTA3xv",
      "display_url" : "trib.al\/wvTA3xv"
    } ]
  },
  "geo" : { },
  "id_str" : "414065993628262400",
  "text" : "RT @NathanDunbar: Holy crap! MT @GuardianUS It's going to cost China $176 billion to clean up its air pollution. http:\/\/t.co\/sEzhewFjF1 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guardian US",
        "screen_name" : "GuardianUS",
        "indices" : [ 14, 25 ],
        "id_str" : "16042794",
        "id" : 16042794
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuardianUS\/status\/414061805250809856\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/JWOPiea2jr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb8LBJsIgAAGp83.jpg",
        "id_str" : "414061805150175232",
        "id" : 414061805150175232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb8LBJsIgAAGp83.jpg",
        "sizes" : [ {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/JWOPiea2jr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/sEzhewFjF1",
        "expanded_url" : "http:\/\/trib.al\/wvTA3xv",
        "display_url" : "trib.al\/wvTA3xv"
      } ]
    },
    "in_reply_to_status_id_str" : "414061805250809856",
    "geo" : { },
    "id_str" : "414062501756547073",
    "in_reply_to_user_id" : 16042794,
    "text" : "Holy crap! MT @GuardianUS It's going to cost China $176 billion to clean up its air pollution. http:\/\/t.co\/sEzhewFjF1 http:\/\/t.co\/JWOPiea2jr",
    "id" : 414062501756547073,
    "in_reply_to_status_id" : 414061805250809856,
    "created_at" : "2013-12-20 15:59:27 +0000",
    "in_reply_to_screen_name" : "GuardianUS",
    "in_reply_to_user_id_str" : "16042794",
    "user" : {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "protected" : false,
      "id_str" : "43298413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683069342842503169\/t-eR15ya_normal.jpg",
      "id" : 43298413,
      "verified" : false
    }
  },
  "id" : 414065993628262400,
  "created_at" : "2013-12-20 16:13:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414065789206294528",
  "text" : "RT @neiltyson: Need to cry, but don't want others to know? Look up to the stars. Your tears won't fall, and the cosmos will make you smile.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414063256873873408",
    "text" : "Need to cry, but don't want others to know? Look up to the stars. Your tears won't fall, and the cosmos will make you smile.",
    "id" : 414063256873873408,
    "created_at" : "2013-12-20 16:02:28 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 414065789206294528,
  "created_at" : "2013-12-20 16:12:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414057624317861888",
  "geo" : { },
  "id_str" : "414065116573732864",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses what i like about you is your honesty. i was very shy growing up.. still learning to speak my mind.",
  "id" : 414065116573732864,
  "in_reply_to_status_id" : 414057624317861888,
  "created_at" : "2013-12-20 16:09:51 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414063862443286528",
  "text" : "dreamed about tornados last night..",
  "id" : 414063862443286528,
  "created_at" : "2013-12-20 16:04:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414062356855930880",
  "text" : "our keurig was dying so hubby got a new coffee machine. went back to pot style. has ready hot water for DD's hot cocoa.",
  "id" : 414062356855930880,
  "created_at" : "2013-12-20 15:58:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/p5MaDLmMzB",
      "expanded_url" : "http:\/\/www.thestranger.com\/seattle\/good-grief-and-great-tits\/Content?oid=18503580",
      "display_url" : "thestranger.com\/seattle\/good-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414059177162469376",
  "text" : "LOL &gt;&gt; Sitting Down to Read Sarah Palin's Christmas Book While I Bake Christmas Cookies for My Family http:\/\/t.co\/p5MaDLmMzB",
  "id" : 414059177162469376,
  "created_at" : "2013-12-20 15:46:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/EapQht6ik6",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=e2X3cecTU3w&feature=share&list=SP6FDA762F19FD9F3B",
      "display_url" : "youtube.com\/watch?v=e2X3ce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414041974513995776",
  "text" : "Dogs Ruin Christmas:  Cute Dog Maymo &amp; Puppy Penny (+playlist): http:\/\/t.co\/EapQht6ik6 via @youtube",
  "id" : 414041974513995776,
  "created_at" : "2013-12-20 14:37:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love My Fire",
      "screen_name" : "Love_My_Fire",
      "indices" : [ 3, 16 ],
      "id_str" : "1291699070",
      "id" : 1291699070
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Love_My_Fire\/status\/413819240190205952\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/t6EcHLhJxp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb4uaA1CYAAlriF.jpg",
      "id_str" : "413819240198594560",
      "id" : 413819240198594560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb4uaA1CYAAlriF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 420
      } ],
      "display_url" : "pic.twitter.com\/t6EcHLhJxp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/42x2UauP5X",
      "expanded_url" : "http:\/\/www.lovemyfire.com\/kindle-fire-tablet.html",
      "display_url" : "lovemyfire.com\/kindle-fire-ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413841089561645056",
  "text" : "RT @Love_My_Fire: Do you know which Kindle Fire you own? See my updated infographic!\nhttp:\/\/t.co\/42x2UauP5X http:\/\/t.co\/t6EcHLhJxp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Love_My_Fire\/status\/413819240190205952\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/t6EcHLhJxp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb4uaA1CYAAlriF.jpg",
        "id_str" : "413819240198594560",
        "id" : 413819240198594560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb4uaA1CYAAlriF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 420
        } ],
        "display_url" : "pic.twitter.com\/t6EcHLhJxp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/42x2UauP5X",
        "expanded_url" : "http:\/\/www.lovemyfire.com\/kindle-fire-tablet.html",
        "display_url" : "lovemyfire.com\/kindle-fire-ta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413819240190205952",
    "text" : "Do you know which Kindle Fire you own? See my updated infographic!\nhttp:\/\/t.co\/42x2UauP5X http:\/\/t.co\/t6EcHLhJxp",
    "id" : 413819240190205952,
    "created_at" : "2013-12-19 23:52:50 +0000",
    "user" : {
      "name" : "Love My Fire",
      "screen_name" : "Love_My_Fire",
      "protected" : false,
      "id_str" : "1291699070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3418941977\/dce2206e65166a03456cc3538abb5f94_normal.jpeg",
      "id" : 1291699070,
      "verified" : false
    }
  },
  "id" : 413841089561645056,
  "created_at" : "2013-12-20 01:19:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413709111260610560",
  "geo" : { },
  "id_str" : "413712147344924672",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny well then, i can see why you said that..lol",
  "id" : 413712147344924672,
  "in_reply_to_status_id" : 413709111260610560,
  "created_at" : "2013-12-19 16:47:17 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413673221364674560",
  "geo" : { },
  "id_str" : "413708753981030400",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny the convo? no.. it just tickled me. im weird..lol",
  "id" : 413708753981030400,
  "in_reply_to_status_id" : 413673221364674560,
  "created_at" : "2013-12-19 16:33:47 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413670952019689472",
  "geo" : { },
  "id_str" : "413672951091695616",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny for some reason this comment made me LOL...",
  "id" : 413672951091695616,
  "in_reply_to_status_id" : 413670952019689472,
  "created_at" : "2013-12-19 14:11:31 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413657845691719680",
  "text" : "i see it differently...",
  "id" : 413657845691719680,
  "created_at" : "2013-12-19 13:11:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/uGUl9ed0cv",
      "expanded_url" : "http:\/\/amzn.to\/tmAkAc",
      "display_url" : "amzn.to\/tmAkAc"
    } ]
  },
  "geo" : { },
  "id_str" : "413519217682829312",
  "text" : "finished The Handmaid's Tale by Margaret Atwood and gave it 4 stars http:\/\/t.co\/uGUl9ed0cv",
  "id" : 413519217682829312,
  "created_at" : "2013-12-19 04:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413488717463314432",
  "text" : "RT @nakedpastor: Happiness doesn't need to be achieved, it just needs to be realized.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413477846841962496",
    "text" : "Happiness doesn't need to be achieved, it just needs to be realized.",
    "id" : 413477846841962496,
    "created_at" : "2013-12-19 01:16:15 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 413488717463314432,
  "created_at" : "2013-12-19 01:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "indices" : [ 3, 17 ],
      "id_str" : "255780065",
      "id" : 255780065
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Crowtographer\/status\/412447063977099265\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/185QuKjOfs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BblOa1uCQAAX7bw.jpg",
      "id_str" : "412447063884840960",
      "id" : 412447063884840960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BblOa1uCQAAX7bw.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/185QuKjOfs"
    } ],
    "hashtags" : [ {
      "text" : "crowtograph",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413396491517317121",
  "text" : "RT @Crowtographer: A crow and his toes\n#crowtograph http:\/\/t.co\/185QuKjOfs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Crowtographer\/status\/412447063977099265\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/185QuKjOfs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BblOa1uCQAAX7bw.jpg",
        "id_str" : "412447063884840960",
        "id" : 412447063884840960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BblOa1uCQAAX7bw.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/185QuKjOfs"
      } ],
      "hashtags" : [ {
        "text" : "crowtograph",
        "indices" : [ 20, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412447063977099265",
    "text" : "A crow and his toes\n#crowtograph http:\/\/t.co\/185QuKjOfs",
    "id" : 412447063977099265,
    "created_at" : "2013-12-16 05:00:17 +0000",
    "user" : {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "protected" : false,
      "id_str" : "255780065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737547028062863361\/1tOrY86w_normal.jpg",
      "id" : 255780065,
      "verified" : false
    }
  },
  "id" : 413396491517317121,
  "created_at" : "2013-12-18 19:52:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413361881781248000",
  "text" : "ideally, i'd like to replace my ipodtouch4G (camera, music) and kindlefire (apps, web, social) w android tablet.",
  "id" : 413361881781248000,
  "created_at" : "2013-12-18 17:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nexus7",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413360718805614592",
  "text" : "but i have to get a case because.. well, it protects in bag.. plus i love auto wake\/sleep function. #nexus7.2",
  "id" : 413360718805614592,
  "created_at" : "2013-12-18 17:30:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/eqreeE6xPs",
      "expanded_url" : "https:\/\/www.decalgirl.com\/wishlist\/7ac46bd0-6f17-43e6-a2ea-92fc099f70a8",
      "display_url" : "decalgirl.com\/wishlist\/7ac46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413360248078864384",
  "text" : "here are skins i like to put on nexus 7: https:\/\/t.co\/eqreeE6xPs",
  "id" : 413360248078864384,
  "created_at" : "2013-12-18 17:28:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 28, 38 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/kW7evDEUrv",
      "expanded_url" : "http:\/\/zachsmind.wordpress.com\/2012\/09\/22\/let-x-equal-x-atheism-skeptic-religion-christian-omgwtf-feminism-bible-etc\/",
      "display_url" : "zachsmind.wordpress.com\/2012\/09\/22\/let\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "413351538619199488",
  "geo" : { },
  "id_str" : "413355669194952705",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible did you see @ZachsMind post? is that why yr asking? &gt;&gt; http:\/\/t.co\/kW7evDEUrv",
  "id" : 413355669194952705,
  "in_reply_to_status_id" : 413351538619199488,
  "created_at" : "2013-12-18 17:10:45 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 0, 13 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413341018075848704",
  "geo" : { },
  "id_str" : "413344449008111616",
  "in_reply_to_user_id" : 17068546,
  "text" : "@TorontoLydia click Settings \/ go down list to blog name, click. \/ see \"Ask\", check box.",
  "id" : 413344449008111616,
  "in_reply_to_status_id" : 413341018075848704,
  "created_at" : "2013-12-18 16:26:10 +0000",
  "in_reply_to_screen_name" : "TorontoLydia",
  "in_reply_to_user_id_str" : "17068546",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Malow",
      "screen_name" : "sciencecomedian",
      "indices" : [ 3, 19 ],
      "id_str" : "18569484",
      "id" : 18569484
    }, {
      "name" : "Judy Stone",
      "screen_name" : "DrJudyStone",
      "indices" : [ 24, 36 ],
      "id_str" : "20739133",
      "id" : 20739133
    }, {
      "name" : "Earth Pics",
      "screen_name" : "EarthPix",
      "indices" : [ 51, 60 ],
      "id_str" : "1152279248",
      "id" : 1152279248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413338813734604800",
  "text" : "RT @sciencecomedian: RT @DrJudyStone: Aww, love RT @EarthPix: Male lizard holding up his girlfriend so she can take a nap http:\/\/t.co\/QKjOl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Judy Stone",
        "screen_name" : "DrJudyStone",
        "indices" : [ 3, 15 ],
        "id_str" : "20739133",
        "id" : 20739133
      }, {
        "name" : "Earth Pics",
        "screen_name" : "EarthPix",
        "indices" : [ 30, 39 ],
        "id_str" : "1152279248",
        "id" : 1152279248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/QKjOlpRbnd",
        "expanded_url" : "https:\/\/twitter.com\/EarthPix\/status\/412708993040412672\/photo\/1",
        "display_url" : "pic.twitter.com\/QKjOlpRbnd"
      } ]
    },
    "in_reply_to_status_id_str" : "413133161565274112",
    "geo" : { },
    "id_str" : "413137939603140609",
    "in_reply_to_user_id" : 20739133,
    "text" : "RT @DrJudyStone: Aww, love RT @EarthPix: Male lizard holding up his girlfriend so she can take a nap http:\/\/t.co\/QKjOlpRbnd",
    "id" : 413137939603140609,
    "in_reply_to_status_id" : 413133161565274112,
    "created_at" : "2013-12-18 02:45:35 +0000",
    "in_reply_to_screen_name" : "DrJudyStone",
    "in_reply_to_user_id_str" : "20739133",
    "user" : {
      "name" : "Brian Malow",
      "screen_name" : "sciencecomedian",
      "protected" : false,
      "id_str" : "18569484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747417761597558786\/QudNt3f__normal.jpg",
      "id" : 18569484,
      "verified" : false
    }
  },
  "id" : 413338813734604800,
  "created_at" : "2013-12-18 16:03:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413338363156910080",
  "text" : "@1stCitizenKane which means nothing is real? hmm...",
  "id" : 413338363156910080,
  "created_at" : "2013-12-18 16:01:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 66, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413333358823763968",
  "text" : "think our keurig machine dying. have to use 2x to get 1 full cup. #firstworldproblems",
  "id" : 413333358823763968,
  "created_at" : "2013-12-18 15:42:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 3, 16 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413332803217276928",
  "text" : "RT @JoshuaDamnIt: I cordially invite the masses drooling over war porn to step into the dreams and memories of a veteran for a night.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413332519782600706",
    "text" : "I cordially invite the masses drooling over war porn to step into the dreams and memories of a veteran for a night.",
    "id" : 413332519782600706,
    "created_at" : "2013-12-18 15:38:46 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 413332803217276928,
  "created_at" : "2013-12-18 15:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413328909950648321",
  "text" : "i see another existential crisis looming ahead...",
  "id" : 413328909950648321,
  "created_at" : "2013-12-18 15:24:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 51, 59 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413328072436637697",
  "text" : "RT @micahjmurray: \u201CTwitter is about being human.\u201D -@garyvee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gary Vaynerchuk",
        "screen_name" : "garyvee",
        "indices" : [ 33, 41 ],
        "id_str" : "5768872",
        "id" : 5768872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413326960069464064",
    "text" : "\u201CTwitter is about being human.\u201D -@garyvee",
    "id" : 413326960069464064,
    "created_at" : "2013-12-18 15:16:41 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 413328072436637697,
  "created_at" : "2013-12-18 15:21:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413324412629168128",
  "text" : "im always afraid i'll discover im really a psychopath under this sweet demeanor.",
  "id" : 413324412629168128,
  "created_at" : "2013-12-18 15:06:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 3, 15 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/hnItBCwzYI",
      "expanded_url" : "http:\/\/bit.ly\/1b2D2KM",
      "display_url" : "bit.ly\/1b2D2KM"
    } ]
  },
  "geo" : { },
  "id_str" : "413323558425985025",
  "text" : "RT @MotherJones: This is what the $361 billion the Pentagon handed out to military contractors in 2012 bought http:\/\/t.co\/hnItBCwzYI http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MotherJones\/status\/411846540026576897\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/EWc8uWTXg4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbcsPvRCAAA4zaB.jpg",
        "id_str" : "411846539825250304",
        "id" : 411846539825250304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbcsPvRCAAA4zaB.jpg",
        "sizes" : [ {
          "h" : 392,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1106,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 1106,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 691,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/EWc8uWTXg4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/hnItBCwzYI",
        "expanded_url" : "http:\/\/bit.ly\/1b2D2KM",
        "display_url" : "bit.ly\/1b2D2KM"
      } ]
    },
    "geo" : { },
    "id_str" : "411846540026576897",
    "text" : "This is what the $361 billion the Pentagon handed out to military contractors in 2012 bought http:\/\/t.co\/hnItBCwzYI http:\/\/t.co\/EWc8uWTXg4",
    "id" : 411846540026576897,
    "created_at" : "2013-12-14 13:14:01 +0000",
    "user" : {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "protected" : false,
      "id_str" : "18510860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731988002206027776\/c0HB7fbs_normal.jpg",
      "id" : 18510860,
      "verified" : true
    }
  },
  "id" : 413323558425985025,
  "created_at" : "2013-12-18 15:03:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413116032375455744",
  "text" : "watching myself from 8-9 yrs ago.. i can see just how weird i really am!",
  "id" : 413116032375455744,
  "created_at" : "2013-12-18 01:18:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Stevens",
      "screen_name" : "Blndetallnlean",
      "indices" : [ 0, 15 ],
      "id_str" : "605981688",
      "id" : 605981688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408575812967751680",
  "geo" : { },
  "id_str" : "413114759223865345",
  "in_reply_to_user_id" : 605981688,
  "text" : "@Blndetallnlean awwww!",
  "id" : 413114759223865345,
  "in_reply_to_status_id" : 408575812967751680,
  "created_at" : "2013-12-18 01:13:28 +0000",
  "in_reply_to_screen_name" : "Blndetallnlean",
  "in_reply_to_user_id_str" : "605981688",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Stevens",
      "screen_name" : "Blndetallnlean",
      "indices" : [ 0, 15 ],
      "id_str" : "605981688",
      "id" : 605981688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408575563821879297",
  "geo" : { },
  "id_str" : "413112190149722112",
  "in_reply_to_user_id" : 605981688,
  "text" : "@Blndetallnlean looks like they will tumble out any minute at that angle..lol. but adorable : )",
  "id" : 413112190149722112,
  "in_reply_to_status_id" : 408575563821879297,
  "created_at" : "2013-12-18 01:03:16 +0000",
  "in_reply_to_screen_name" : "Blndetallnlean",
  "in_reply_to_user_id_str" : "605981688",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413111705829273600",
  "text" : "damn.. my bro sent me a gift thru mail. a dvd. an hour of christmas past.",
  "id" : 413111705829273600,
  "created_at" : "2013-12-18 01:01:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/412984004434874368\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/wzMqOBboiG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbs2w4nCIAALNuH.jpg",
      "id_str" : "412984004292255744",
      "id" : 412984004292255744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbs2w4nCIAALNuH.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/wzMqOBboiG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412984240775905280",
  "text" : "RT @Chickypoo333: Goodmorning http:\/\/t.co\/wzMqOBboiG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/412984004434874368\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/wzMqOBboiG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbs2w4nCIAALNuH.jpg",
        "id_str" : "412984004292255744",
        "id" : 412984004292255744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbs2w4nCIAALNuH.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/wzMqOBboiG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412984004434874368",
    "text" : "Goodmorning http:\/\/t.co\/wzMqOBboiG",
    "id" : 412984004434874368,
    "created_at" : "2013-12-17 16:33:54 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 412984240775905280,
  "created_at" : "2013-12-17 16:34:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0639\u0645\u0631 \u0627\u0644\u062C\u0639\u0628\u0631\u064A",
      "screen_name" : "OmarJaabari",
      "indices" : [ 3, 15 ],
      "id_str" : "77096563",
      "id" : 77096563
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OmarJaabari\/status\/412689920785133568\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/CSBJWvT6J6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BborS90IYAARYTJ.jpg",
      "id_str" : "412689920688676864",
      "id" : 412689920688676864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BborS90IYAARYTJ.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/CSBJWvT6J6"
    } ],
    "hashtags" : [ {
      "text" : "GazaDisaster",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412980964143681536",
  "text" : "RT @OmarJaabari: Palestinian activists in Gaza save a cat during the unprecedented heavy rain #GazaDisaster http:\/\/t.co\/CSBJWvT6J6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OmarJaabari\/status\/412689920785133568\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/CSBJWvT6J6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BborS90IYAARYTJ.jpg",
        "id_str" : "412689920688676864",
        "id" : 412689920688676864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BborS90IYAARYTJ.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/CSBJWvT6J6"
      } ],
      "hashtags" : [ {
        "text" : "GazaDisaster",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412689920785133568",
    "text" : "Palestinian activists in Gaza save a cat during the unprecedented heavy rain #GazaDisaster http:\/\/t.co\/CSBJWvT6J6",
    "id" : 412689920785133568,
    "created_at" : "2013-12-16 21:05:19 +0000",
    "user" : {
      "name" : "\u0639\u0645\u0631 \u0627\u0644\u062C\u0639\u0628\u0631\u064A",
      "screen_name" : "OmarJaabari",
      "protected" : false,
      "id_str" : "77096563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790302702613979136\/840WxDku_normal.jpg",
      "id" : 77096563,
      "verified" : false
    }
  },
  "id" : 412980964143681536,
  "created_at" : "2013-12-17 16:21:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412975234614968320",
  "geo" : { },
  "id_str" : "412980485325742080",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos LOLOL",
  "id" : 412980485325742080,
  "in_reply_to_status_id" : 412975234614968320,
  "created_at" : "2013-12-17 16:19:55 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 72, 76 ],
      "id_str" : "759251",
      "id" : 759251
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 82, 91 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BmzMVObxKZ",
      "expanded_url" : "http:\/\/www.upworthy.com\/one-time-a-guy-gave-a-homeless-man-a-computer-and-the-recipient-did-exactly-what-the-giver-expected?g=2&c=ufb1",
      "display_url" : "upworthy.com\/one-time-a-guy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412980011155472384",
  "text" : "A man who is homeless reminds us all why we shouldn't make assumptions. @CNN (via @Upworthy) http:\/\/t.co\/BmzMVObxKZ",
  "id" : 412980011155472384,
  "created_at" : "2013-12-17 16:18:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412971041745412097",
  "geo" : { },
  "id_str" : "412977013092143104",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare #SinglePayer that much closer!",
  "id" : 412977013092143104,
  "in_reply_to_status_id" : 412971041745412097,
  "created_at" : "2013-12-17 16:06:07 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/RnSC1LO798",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/12\/17\/1263350\/-Cruelty-Insurers-Block-Hospital-and-Charity-Efforts-to-Pay-Premiums-in-Bid-to-Protect-Profits",
      "display_url" : "dailykos.com\/story\/2013\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412976814647418881",
  "text" : "RT @AllOnMedicare: Cruelty: Insurers Block Hospital and Charity Efforts to Pay Premiums in Bid to Protect Profits http:\/\/t.co\/RnSC1LO798 vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Kos",
        "screen_name" : "dailykos",
        "indices" : [ 122, 131 ],
        "id_str" : "20818801",
        "id" : 20818801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/RnSC1LO798",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/12\/17\/1263350\/-Cruelty-Insurers-Block-Hospital-and-Charity-Efforts-to-Pay-Premiums-in-Bid-to-Protect-Profits",
        "display_url" : "dailykos.com\/story\/2013\/12\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412971041745412097",
    "text" : "Cruelty: Insurers Block Hospital and Charity Efforts to Pay Premiums in Bid to Protect Profits http:\/\/t.co\/RnSC1LO798 via @dailykos",
    "id" : 412971041745412097,
    "created_at" : "2013-12-17 15:42:23 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 412976814647418881,
  "created_at" : "2013-12-17 16:05:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/EwNWtXCxbe",
      "expanded_url" : "http:\/\/bit.ly\/1hgliBd",
      "display_url" : "bit.ly\/1hgliBd"
    } ]
  },
  "geo" : { },
  "id_str" : "412974722511814656",
  "text" : "RT @Floridaline: Separation of church and state made easy for Sarah Palin  http:\/\/t.co\/EwNWtXCxbe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/EwNWtXCxbe",
        "expanded_url" : "http:\/\/bit.ly\/1hgliBd",
        "display_url" : "bit.ly\/1hgliBd"
      } ]
    },
    "geo" : { },
    "id_str" : "412904023864647681",
    "text" : "Separation of church and state made easy for Sarah Palin  http:\/\/t.co\/EwNWtXCxbe",
    "id" : 412904023864647681,
    "created_at" : "2013-12-17 11:16:05 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 412974722511814656,
  "created_at" : "2013-12-17 15:57:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412969071253016577",
  "geo" : { },
  "id_str" : "412974678655766528",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos DD, 18, loves Shadow... so.. yeah..lol",
  "id" : 412974678655766528,
  "in_reply_to_status_id" : 412969071253016577,
  "created_at" : "2013-12-17 15:56:50 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412964754098253824",
  "geo" : { },
  "id_str" : "412972629411110912",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields ahhh.. thanks for correcting me! : )",
  "id" : 412972629411110912,
  "in_reply_to_status_id" : 412964754098253824,
  "created_at" : "2013-12-17 15:48:42 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412971563491655680",
  "text" : "@weakSquare well, you are pretty scary w those mirrored sunglasses..",
  "id" : 412971563491655680,
  "created_at" : "2013-12-17 15:44:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412958760777547776",
  "text" : "RT @DarciaHelle: Are there college courses on how to properly re-fold maps?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412956698312073217",
    "text" : "Are there college courses on how to properly re-fold maps?",
    "id" : 412956698312073217,
    "created_at" : "2013-12-17 14:45:23 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 412958760777547776,
  "created_at" : "2013-12-17 14:53:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412957941143060481",
  "text" : "hmm.. kindle (touch.. they dont even call it that anymore) is on sale \"while supplies last\" .. a new #kindle model coming?",
  "id" : 412957941143060481,
  "created_at" : "2013-12-17 14:50:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412710021722411008",
  "geo" : { },
  "id_str" : "412723441683283968",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos lady: \"key is break the will not the spirit\" wth? ((facepalm))",
  "id" : 412723441683283968,
  "in_reply_to_status_id" : 412710021722411008,
  "created_at" : "2013-12-16 23:18:31 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Miner",
      "screen_name" : "MattMinerXVX",
      "indices" : [ 0, 13 ],
      "id_str" : "3439061",
      "id" : 3439061
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 25, 41 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412711166352576512",
  "geo" : { },
  "id_str" : "412723038828785664",
  "in_reply_to_user_id" : 3439061,
  "text" : "@MattMinerXVX agreed : ) @shoeofallcosmos",
  "id" : 412723038828785664,
  "in_reply_to_status_id" : 412711166352576512,
  "created_at" : "2013-12-16 23:16:55 +0000",
  "in_reply_to_screen_name" : "MattMinerXVX",
  "in_reply_to_user_id_str" : "3439061",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 3, 19 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412713780582555648",
  "text" : "RT @shoeofallcosmos: I'm actually a part of a documentary on spanking. You can find out more about the organization at http:\/\/t.co\/8kpga5rc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/8kpga5rckp",
        "expanded_url" : "http:\/\/stopspanking.org",
        "display_url" : "stopspanking.org"
      } ]
    },
    "geo" : { },
    "id_str" : "412710021722411008",
    "text" : "I'm actually a part of a documentary on spanking. You can find out more about the organization at http:\/\/t.co\/8kpga5rckp, I think.",
    "id" : 412710021722411008,
    "created_at" : "2013-12-16 22:25:11 +0000",
    "user" : {
      "name" : "\uD83D\uDC51Hillary\uD83D\uDC51",
      "screen_name" : "trustsuperjail",
      "protected" : false,
      "id_str" : "14364749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755988613427437568\/6rMS9eol_normal.jpg",
      "id" : 14364749,
      "verified" : false
    }
  },
  "id" : 412713780582555648,
  "created_at" : "2013-12-16 22:40:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412705165049733120",
  "text" : "google nexus 7 (2013) or samsung galaxy tab 3 (8 in.) ?",
  "id" : 412705165049733120,
  "created_at" : "2013-12-16 22:05:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 0, 13 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412657327968227328",
  "geo" : { },
  "id_str" : "412676149215383552",
  "in_reply_to_user_id" : 17068546,
  "text" : "@TorontoLydia im introvert and neurotic. all the hoopla around the holiday gets my nerves on edge. blah.",
  "id" : 412676149215383552,
  "in_reply_to_status_id" : 412657327968227328,
  "created_at" : "2013-12-16 20:10:35 +0000",
  "in_reply_to_screen_name" : "TorontoLydia",
  "in_reply_to_user_id_str" : "17068546",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412644462636957696",
  "text" : "in case you didn't know, i hate christmas.",
  "id" : 412644462636957696,
  "created_at" : "2013-12-16 18:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412596956553154560",
  "text" : "love seeing the happy birds in my backyard. crow is enjoying the pancake pieces.",
  "id" : 412596956553154560,
  "created_at" : "2013-12-16 14:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/77VKffSTtu",
      "expanded_url" : "http:\/\/amzn.to\/hY6ldt",
      "display_url" : "amzn.to\/hY6ldt"
    } ]
  },
  "geo" : { },
  "id_str" : "412413376925814784",
  "text" : "finished Peace Warrior (Peace Warrior Trilogy, Book 1) by Steven L. Hawk http:\/\/t.co\/77VKffSTtu",
  "id" : 412413376925814784,
  "created_at" : "2013-12-16 02:46:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "indices" : [ 3, 12 ],
      "id_str" : "800652126",
      "id" : 800652126
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/412340190514933761\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/6ZI216ElEH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbjtN_aCcAEv9OC.jpg",
      "id_str" : "412340190519128065",
      "id" : 412340190519128065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbjtN_aCcAEv9OC.jpg",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/6ZI216ElEH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412345609308631040",
  "text" : "RT @MrRat395: The whole herd.  The dark one is the boss:-) http:\/\/t.co\/6ZI216ElEH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/412340190514933761\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/6ZI216ElEH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbjtN_aCcAEv9OC.jpg",
        "id_str" : "412340190519128065",
        "id" : 412340190519128065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbjtN_aCcAEv9OC.jpg",
        "sizes" : [ {
          "h" : 452,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/6ZI216ElEH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412340190514933761",
    "text" : "The whole herd.  The dark one is the boss:-) http:\/\/t.co\/6ZI216ElEH",
    "id" : 412340190514933761,
    "created_at" : "2013-12-15 21:55:37 +0000",
    "user" : {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "protected" : false,
      "id_str" : "800652126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779503692802240512\/iVwM-mwl_normal.jpg",
      "id" : 800652126,
      "verified" : false
    }
  },
  "id" : 412345609308631040,
  "created_at" : "2013-12-15 22:17:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/412289923324981249\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/mQTWzocNgc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbi_gDjCMAAIVB8.jpg",
      "id_str" : "412289923333369856",
      "id" : 412289923333369856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbi_gDjCMAAIVB8.jpg",
      "sizes" : [ {
        "h" : 489,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 542
      } ],
      "display_url" : "pic.twitter.com\/mQTWzocNgc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412298148326146049",
  "text" : "RT @CUMALi_YILDIZ: http:\/\/t.co\/mQTWzocNgc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/412289923324981249\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/mQTWzocNgc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbi_gDjCMAAIVB8.jpg",
        "id_str" : "412289923333369856",
        "id" : 412289923333369856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbi_gDjCMAAIVB8.jpg",
        "sizes" : [ {
          "h" : 489,
          "resize" : "fit",
          "w" : 542
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 542
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 542
        } ],
        "display_url" : "pic.twitter.com\/mQTWzocNgc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412289923324981249",
    "text" : "http:\/\/t.co\/mQTWzocNgc",
    "id" : 412289923324981249,
    "created_at" : "2013-12-15 18:35:52 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 412298148326146049,
  "created_at" : "2013-12-15 19:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/412294831168184320\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/RIsKnE0yAm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbjD9usCYAA36Sl.jpg",
      "id_str" : "412294831176572928",
      "id" : 412294831176572928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbjD9usCYAA36Sl.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/RIsKnE0yAm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412296772586057728",
  "text" : "RT @CUMALi_YILDIZ: doga_national_geopraphic EN \u0130Y\u0130 DO\u011EA FATO\u011ERAFLARI .... http:\/\/t.co\/RIsKnE0yAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/412294831168184320\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/RIsKnE0yAm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbjD9usCYAA36Sl.jpg",
        "id_str" : "412294831176572928",
        "id" : 412294831176572928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbjD9usCYAA36Sl.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/RIsKnE0yAm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412294831168184320",
    "text" : "doga_national_geopraphic EN \u0130Y\u0130 DO\u011EA FATO\u011ERAFLARI .... http:\/\/t.co\/RIsKnE0yAm",
    "id" : 412294831168184320,
    "created_at" : "2013-12-15 18:55:22 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 412296772586057728,
  "created_at" : "2013-12-15 19:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/qbgR64Awja",
      "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=98",
      "display_url" : "wildlifegadgetman.com\/?page_id=98"
    } ]
  },
  "geo" : { },
  "id_str" : "412268884826554368",
  "text" : "RT @WildlifeGadgets: Great Tit tucked up in the nest box 4 the evening. Looks just like a little fluffy lollipop! http:\/\/t.co\/qbgR64Awja ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/412265261241102336\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/J4pbGzCgRh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbipEiHCcAEBb20.jpg",
        "id_str" : "412265261245296641",
        "id" : 412265261245296641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbipEiHCcAEBb20.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/J4pbGzCgRh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/qbgR64Awja",
        "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=98",
        "display_url" : "wildlifegadgetman.com\/?page_id=98"
      } ]
    },
    "geo" : { },
    "id_str" : "412265261241102336",
    "text" : "Great Tit tucked up in the nest box 4 the evening. Looks just like a little fluffy lollipop! http:\/\/t.co\/qbgR64Awja http:\/\/t.co\/J4pbGzCgRh",
    "id" : 412265261241102336,
    "created_at" : "2013-12-15 16:57:52 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 412268884826554368,
  "created_at" : "2013-12-15 17:12:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412260867204317184",
  "text" : "thinking of replacing kindlefire and ipodtouch4G w android tablet (for apps, camera, web browse, social media, music. what say you?",
  "id" : 412260867204317184,
  "created_at" : "2013-12-15 16:40:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 0, 13 ],
      "id_str" : "43298413",
      "id" : 43298413
    }, {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 14, 28 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412254014080708609",
  "geo" : { },
  "id_str" : "412259846142976000",
  "in_reply_to_user_id" : 43298413,
  "text" : "@NathanDunbar @johnnie_cakes both! brings back teen years : )",
  "id" : 412259846142976000,
  "in_reply_to_status_id" : 412254014080708609,
  "created_at" : "2013-12-15 16:36:21 +0000",
  "in_reply_to_screen_name" : "NathanDunbar",
  "in_reply_to_user_id_str" : "43298413",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Algernon  Fross",
      "screen_name" : "fxp123",
      "indices" : [ 3, 10 ],
      "id_str" : "16383523",
      "id" : 16383523
    }, {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 20, 30 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/LbxdibAJsS",
      "expanded_url" : "https:\/\/twitter.com\/joyceetta\/status\/400335989219921921\/photo\/1",
      "display_url" : "pic.twitter.com\/LbxdibAJsS"
    } ]
  },
  "geo" : { },
  "id_str" : "412259236320927744",
  "text" : "RT @fxp123: Cute RT @joyceetta: Life let it flow http:\/\/t.co\/LbxdibAJsS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "joyce bugg",
        "screen_name" : "joyceetta",
        "indices" : [ 8, 18 ],
        "id_str" : "89621202",
        "id" : 89621202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/LbxdibAJsS",
        "expanded_url" : "https:\/\/twitter.com\/joyceetta\/status\/400335989219921921\/photo\/1",
        "display_url" : "pic.twitter.com\/LbxdibAJsS"
      } ]
    },
    "in_reply_to_status_id_str" : "400335989219921921",
    "geo" : { },
    "id_str" : "412255896698253312",
    "in_reply_to_user_id" : 89621202,
    "text" : "Cute RT @joyceetta: Life let it flow http:\/\/t.co\/LbxdibAJsS",
    "id" : 412255896698253312,
    "in_reply_to_status_id" : 400335989219921921,
    "created_at" : "2013-12-15 16:20:39 +0000",
    "in_reply_to_screen_name" : "joyceetta",
    "in_reply_to_user_id_str" : "89621202",
    "user" : {
      "name" : "Algernon  Fross",
      "screen_name" : "fxp123",
      "protected" : false,
      "id_str" : "16383523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796617636595585024\/4olWhtK0_normal.jpg",
      "id" : 16383523,
      "verified" : false
    }
  },
  "id" : 412259236320927744,
  "created_at" : "2013-12-15 16:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann",
      "screen_name" : "writerPT",
      "indices" : [ 3, 12 ],
      "id_str" : "711010554",
      "id" : 711010554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412251588091465728",
  "text" : "RT @writerPT: And then one day she realized she held the key to her shackles the entire time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412040273804288001",
    "text" : "And then one day she realized she held the key to her shackles the entire time.",
    "id" : 412040273804288001,
    "created_at" : "2013-12-15 02:03:51 +0000",
    "user" : {
      "name" : "Ann",
      "screen_name" : "writerPT",
      "protected" : false,
      "id_str" : "711010554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2528998795\/hki30x2kn4wm7sctv57b_normal.jpeg",
      "id" : 711010554,
      "verified" : false
    }
  },
  "id" : 412251588091465728,
  "created_at" : "2013-12-15 16:03:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "indices" : [ 3, 13 ],
      "id_str" : "23539037",
      "id" : 23539037
    }, {
      "name" : "\u0938\u0941\u092E\u0928 (\u0938\u093E\u0928\u092D\u093E\u0908)",
      "screen_name" : "coreylambrecht",
      "indices" : [ 16, 31 ],
      "id_str" : "3838342521",
      "id" : 3838342521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xRo8aM2BYk",
      "expanded_url" : "https:\/\/twitter.com\/CoreyLambrecht\/status\/412217938565795840\/photo\/1",
      "display_url" : "pic.twitter.com\/xRo8aM2BYk"
    } ]
  },
  "geo" : { },
  "id_str" : "412250041924214784",
  "text" : "RT @OhYouGirl: \u201C@CoreyLambrecht: Chilly morning at OU's Duck Pond http:\/\/t.co\/xRo8aM2BYk\u201D Gorgeous.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0938\u0941\u092E\u0928 (\u0938\u093E\u0928\u092D\u093E\u0908)",
        "screen_name" : "coreylambrecht",
        "indices" : [ 1, 16 ],
        "id_str" : "3838342521",
        "id" : 3838342521
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/xRo8aM2BYk",
        "expanded_url" : "https:\/\/twitter.com\/CoreyLambrecht\/status\/412217938565795840\/photo\/1",
        "display_url" : "pic.twitter.com\/xRo8aM2BYk"
      } ]
    },
    "geo" : { },
    "id_str" : "412229071372681216",
    "text" : "\u201C@CoreyLambrecht: Chilly morning at OU's Duck Pond http:\/\/t.co\/xRo8aM2BYk\u201D Gorgeous.",
    "id" : 412229071372681216,
    "created_at" : "2013-12-15 14:34:04 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 412250041924214784,
  "created_at" : "2013-12-15 15:57:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412249568298819584",
  "text" : "@Skeptical_Lady ((hugs)) i cant imagine.",
  "id" : 412249568298819584,
  "created_at" : "2013-12-15 15:55:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Reynolds \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "Sarah__Reynolds",
      "indices" : [ 3, 19 ],
      "id_str" : "179719307",
      "id" : 179719307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 37, 41 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412246147546488832",
  "text" : "RT @Sarah__Reynolds: The REAL reason #ACA is so feared: provision allowing individual states to set up a #singlepayer system: http:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 16, 20 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 84, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/o9T69WZGAp",
        "expanded_url" : "http:\/\/m.dailykos.com\/story\/2013\/11\/24\/1258135\/-Obama-just-launched-single-payer-in-America?detail=email",
        "display_url" : "m.dailykos.com\/story\/2013\/11\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412102466822344704",
    "text" : "The REAL reason #ACA is so feared: provision allowing individual states to set up a #singlepayer system: http:\/\/t.co\/o9T69WZGAp Vermont has.",
    "id" : 412102466822344704,
    "created_at" : "2013-12-15 06:10:59 +0000",
    "user" : {
      "name" : "Sarah Reynolds \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "Sarah__Reynolds",
      "protected" : false,
      "id_str" : "179719307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788893429250027520\/MTZgY8KA_normal.jpg",
      "id" : 179719307,
      "verified" : false
    }
  },
  "id" : 412246147546488832,
  "created_at" : "2013-12-15 15:41:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Shawd",
      "screen_name" : "bjs5555",
      "indices" : [ 3, 11 ],
      "id_str" : "821372790",
      "id" : 821372790
    }, {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 55, 66 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPFail",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412245489384693760",
  "text" : "RT @bjs5555: Follow &amp; Re-Elect SENATOR CORY BOOKER @CoryBooker in 2014! (D-NJ) Keep Democratic Senate Majority! #GOPFail http:\/\/t.co\/47DghM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Booker",
        "screen_name" : "CoryBooker",
        "indices" : [ 42, 53 ],
        "id_str" : "15808765",
        "id" : 15808765
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bjs5555\/status\/412051092877238272\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/47DghM219U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbfmSSyCYAE9YMo.jpg",
        "id_str" : "412051092881432577",
        "id" : 412051092881432577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbfmSSyCYAE9YMo.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 875
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 146,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 875
        } ],
        "display_url" : "pic.twitter.com\/47DghM219U"
      } ],
      "hashtags" : [ {
        "text" : "GOPFail",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412051092877238272",
    "text" : "Follow &amp; Re-Elect SENATOR CORY BOOKER @CoryBooker in 2014! (D-NJ) Keep Democratic Senate Majority! #GOPFail http:\/\/t.co\/47DghM219U",
    "id" : 412051092877238272,
    "created_at" : "2013-12-15 02:46:50 +0000",
    "user" : {
      "name" : "BJ Shawd",
      "screen_name" : "bjs5555",
      "protected" : false,
      "id_str" : "821372790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746853250423480320\/R7GTEgux_normal.jpg",
      "id" : 821372790,
      "verified" : false
    }
  },
  "id" : 412245489384693760,
  "created_at" : "2013-12-15 15:39:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412039263761739776",
  "geo" : { },
  "id_str" : "412041456593825794",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields LOL...",
  "id" : 412041456593825794,
  "in_reply_to_status_id" : 412039263761739776,
  "created_at" : "2013-12-15 02:08:33 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rich the farmer",
      "screen_name" : "richthefarmer",
      "indices" : [ 3, 17 ],
      "id_str" : "463286921",
      "id" : 463286921
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/richthefarmer\/status\/412025618310504448\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/djFtOuyTNa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbfPHeNCYAAyPKu.jpg",
      "id_str" : "412025618201468928",
      "id" : 412025618201468928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbfPHeNCYAAyPKu.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/djFtOuyTNa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412038984832143360",
  "text" : "RT @richthefarmer: http:\/\/t.co\/djFtOuyTNa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/richthefarmer\/status\/412025618310504448\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/djFtOuyTNa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbfPHeNCYAAyPKu.jpg",
        "id_str" : "412025618201468928",
        "id" : 412025618201468928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbfPHeNCYAAyPKu.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/djFtOuyTNa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412025618310504448",
    "text" : "http:\/\/t.co\/djFtOuyTNa",
    "id" : 412025618310504448,
    "created_at" : "2013-12-15 01:05:37 +0000",
    "user" : {
      "name" : "rich the farmer",
      "screen_name" : "richthefarmer",
      "protected" : false,
      "id_str" : "463286921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750678301836845056\/DEBTJruL_normal.jpg",
      "id" : 463286921,
      "verified" : false
    }
  },
  "id" : 412038984832143360,
  "created_at" : "2013-12-15 01:58:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jani Treagust",
      "screen_name" : "Jan1_T",
      "indices" : [ 3, 10 ],
      "id_str" : "393265261",
      "id" : 393265261
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Jan1_T\/status\/411957589006893056\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PTDjSSHAaQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbeRPpTIQAAsIfS.jpg",
      "id_str" : "411957588897841152",
      "id" : 411957588897841152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbeRPpTIQAAsIfS.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PTDjSSHAaQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412037708627066880",
  "text" : "RT @Jan1_T: Please share for this poor lost bear http:\/\/t.co\/PTDjSSHAaQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jan1_T\/status\/411957589006893056\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/PTDjSSHAaQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbeRPpTIQAAsIfS.jpg",
        "id_str" : "411957588897841152",
        "id" : 411957588897841152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbeRPpTIQAAsIfS.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PTDjSSHAaQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411957589006893056",
    "text" : "Please share for this poor lost bear http:\/\/t.co\/PTDjSSHAaQ",
    "id" : 411957589006893056,
    "created_at" : "2013-12-14 20:35:17 +0000",
    "user" : {
      "name" : "Jani Treagust",
      "screen_name" : "Jan1_T",
      "protected" : false,
      "id_str" : "393265261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601311662214410240\/Y0FWkEaA_normal.jpg",
      "id" : 393265261,
      "verified" : false
    }
  },
  "id" : 412037708627066880,
  "created_at" : "2013-12-15 01:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/411923830504824832\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/ujv5WU72bH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbdyiphCIAAB7Vt.jpg",
      "id_str" : "411923830513213440",
      "id" : 411923830513213440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbdyiphCIAAB7Vt.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ujv5WU72bH"
    } ],
    "hashtags" : [ {
      "text" : "geese",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "rimcountry",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411926119076888576",
  "text" : "RT @AWrobley: \"It's fun walking on water!!\" (frozen water) #geese #rimcountry :o)) http:\/\/t.co\/ujv5WU72bH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/411923830504824832\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/ujv5WU72bH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbdyiphCIAAB7Vt.jpg",
        "id_str" : "411923830513213440",
        "id" : 411923830513213440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbdyiphCIAAB7Vt.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ujv5WU72bH"
      } ],
      "hashtags" : [ {
        "text" : "geese",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "rimcountry",
        "indices" : [ 52, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411923830504824832",
    "text" : "\"It's fun walking on water!!\" (frozen water) #geese #rimcountry :o)) http:\/\/t.co\/ujv5WU72bH",
    "id" : 411923830504824832,
    "created_at" : "2013-12-14 18:21:09 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 411926119076888576,
  "created_at" : "2013-12-14 18:30:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Berwyn",
      "screen_name" : "bberwyn",
      "indices" : [ 3, 11 ],
      "id_str" : "32140995",
      "id" : 32140995
    }, {
      "name" : "Daniel McVey",
      "screen_name" : "DanielMcVey",
      "indices" : [ 20, 32 ],
      "id_str" : "293223670",
      "id" : 293223670
    }, {
      "name" : "Bob Berwyn",
      "screen_name" : "SummitVoice",
      "indices" : [ 77, 89 ],
      "id_str" : "93915396",
      "id" : 93915396
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/lVjTQDgylQ",
      "expanded_url" : "http:\/\/bit.ly\/JjmTtX",
      "display_url" : "bit.ly\/JjmTtX"
    } ]
  },
  "geo" : { },
  "id_str" : "411890043461304320",
  "text" : "RT @bberwyn: Thanks @DanielMcVey for sharing these amazing night sky pics on @SummitVoice - http:\/\/t.co\/lVjTQDgylQ #photography http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel McVey",
        "screen_name" : "DanielMcVey",
        "indices" : [ 7, 19 ],
        "id_str" : "293223670",
        "id" : 293223670
      }, {
        "name" : "Bob Berwyn",
        "screen_name" : "SummitVoice",
        "indices" : [ 64, 76 ],
        "id_str" : "93915396",
        "id" : 93915396
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bberwyn\/status\/411862160990408704\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ecIDITOypK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbc6dArCEAEe2qf.jpg",
        "id_str" : "411862160998797313",
        "id" : 411862160998797313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbc6dArCEAEe2qf.jpg",
        "sizes" : [ {
          "h" : 702,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ecIDITOypK"
      } ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/lVjTQDgylQ",
        "expanded_url" : "http:\/\/bit.ly\/JjmTtX",
        "display_url" : "bit.ly\/JjmTtX"
      } ]
    },
    "geo" : { },
    "id_str" : "411862160990408704",
    "text" : "Thanks @DanielMcVey for sharing these amazing night sky pics on @SummitVoice - http:\/\/t.co\/lVjTQDgylQ #photography http:\/\/t.co\/ecIDITOypK",
    "id" : 411862160990408704,
    "created_at" : "2013-12-14 14:16:06 +0000",
    "user" : {
      "name" : "Bob Berwyn",
      "screen_name" : "bberwyn",
      "protected" : false,
      "id_str" : "32140995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731976305542082560\/kREi9iz5_normal.jpg",
      "id" : 32140995,
      "verified" : false
    }
  },
  "id" : 411890043461304320,
  "created_at" : "2013-12-14 16:06:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "RageMichelle",
      "indices" : [ 3, 16 ],
      "id_str" : "203054475",
      "id" : 203054475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411889277551669249",
  "text" : "RT @RageMichelle: Let's just get the tinsel sticks out of our asses, okay? If someone wishes you a merry or a happy anything..be gracious a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411888477740228608",
    "text" : "Let's just get the tinsel sticks out of our asses, okay? If someone wishes you a merry or a happy anything..be gracious and say thank you",
    "id" : 411888477740228608,
    "created_at" : "2013-12-14 16:00:40 +0000",
    "user" : {
      "name" : "Michelle",
      "screen_name" : "RageMichelle",
      "protected" : false,
      "id_str" : "203054475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522322844600922112\/4V6zWNU4_normal.jpeg",
      "id" : 203054475,
      "verified" : false
    }
  },
  "id" : 411889277551669249,
  "created_at" : "2013-12-14 16:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411889144659324928",
  "text" : "thank goodness, no roof climbing, chimney work today! : )",
  "id" : 411889144659324928,
  "created_at" : "2013-12-14 16:03:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 20, 27 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411870189022900224",
  "text" : "RT @Lesism: What if @Amazon's drones suddenly become self-aware? Maybe they'll give everyone exactly what they really need, and not charge \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 8, 15 ],
        "id_str" : "20793816",
        "id" : 20793816
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411869031105179649",
    "text" : "What if @Amazon's drones suddenly become self-aware? Maybe they'll give everyone exactly what they really need, and not charge them?",
    "id" : 411869031105179649,
    "created_at" : "2013-12-14 14:43:23 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 411870189022900224,
  "created_at" : "2013-12-14 14:47:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411867099582042112",
  "text" : "hubby working on a frozen chimney today (not ours) .. hope he doesnt fall.",
  "id" : 411867099582042112,
  "created_at" : "2013-12-14 14:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope For Paws",
      "screen_name" : "HopeForPaws",
      "indices" : [ 3, 15 ],
      "id_str" : "75321229",
      "id" : 75321229
    }, {
      "name" : "HPGoodNews",
      "screen_name" : "HPGoodNews",
      "indices" : [ 117, 128 ],
      "id_str" : "2243011218",
      "id" : 2243011218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/11b5eQf1Jb",
      "expanded_url" : "http:\/\/huff.to\/1frs2LT",
      "display_url" : "huff.to\/1frs2LT"
    } ]
  },
  "geo" : { },
  "id_str" : "411677626227376128",
  "text" : "RT @HopeForPaws: Left To Die In A Trash Heap, Abandoned Dog Gets Remarkable Second Chance http:\/\/t.co\/11b5eQf1Jb via @HPGoodNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HPGoodNews",
        "screen_name" : "HPGoodNews",
        "indices" : [ 100, 111 ],
        "id_str" : "2243011218",
        "id" : 2243011218
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/11b5eQf1Jb",
        "expanded_url" : "http:\/\/huff.to\/1frs2LT",
        "display_url" : "huff.to\/1frs2LT"
      } ]
    },
    "geo" : { },
    "id_str" : "411651854720720897",
    "text" : "Left To Die In A Trash Heap, Abandoned Dog Gets Remarkable Second Chance http:\/\/t.co\/11b5eQf1Jb via @HPGoodNews",
    "id" : 411651854720720897,
    "created_at" : "2013-12-14 00:20:24 +0000",
    "user" : {
      "name" : "Hope For Paws",
      "screen_name" : "HopeForPaws",
      "protected" : false,
      "id_str" : "75321229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416271144908382210\/ezeYcRIi_normal.jpeg",
      "id" : 75321229,
      "verified" : false
    }
  },
  "id" : 411677626227376128,
  "created_at" : "2013-12-14 02:02:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 80, 92 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/a3M5vHfaPC",
      "expanded_url" : "http:\/\/huff.to\/19HE8ia",
      "display_url" : "huff.to\/19HE8ia"
    } ]
  },
  "geo" : { },
  "id_str" : "411639914812297218",
  "text" : "Why I Will Never, Ever, Go Back to the United States http:\/\/t.co\/a3M5vHfaPC via @HuffPostPol",
  "id" : 411639914812297218,
  "created_at" : "2013-12-13 23:32:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/wy7lDgURiH",
      "expanded_url" : "http:\/\/wp.me\/p3FuZ-sD",
      "display_url" : "wp.me\/p3FuZ-sD"
    } ]
  },
  "geo" : { },
  "id_str" : "411571444556898304",
  "text" : "beautiful &gt;&gt; Regarding my 1,000-year-old dog. http:\/\/t.co\/wy7lDgURiH via @kellybarnhill",
  "id" : 411571444556898304,
  "created_at" : "2013-12-13 19:00:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzanne Lepage",
      "screen_name" : "SuzanneLepage1",
      "indices" : [ 3, 18 ],
      "id_str" : "350593129",
      "id" : 350593129
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SuzanneLepage1\/status\/410204850798874624\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/K28rHkr6vp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFXI3FCUAESXXT.jpg",
      "id_str" : "410204850803068929",
      "id" : 410204850803068929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFXI3FCUAESXXT.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 471,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/K28rHkr6vp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411526669514833920",
  "text" : "RT @SuzanneLepage1: Marvelous! http:\/\/t.co\/K28rHkr6vp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SuzanneLepage1\/status\/410204850798874624\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/K28rHkr6vp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFXI3FCUAESXXT.jpg",
        "id_str" : "410204850803068929",
        "id" : 410204850803068929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFXI3FCUAESXXT.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 611
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 611
        }, {
          "h" : 471,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/K28rHkr6vp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410204850798874624",
    "text" : "Marvelous! http:\/\/t.co\/K28rHkr6vp",
    "id" : 410204850798874624,
    "created_at" : "2013-12-10 00:30:32 +0000",
    "user" : {
      "name" : "Suzanne Lepage",
      "screen_name" : "SuzanneLepage1",
      "protected" : false,
      "id_str" : "350593129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3389613210\/3295605d62aeef93702878263814cbee_normal.jpeg",
      "id" : 350593129,
      "verified" : false
    }
  },
  "id" : 411526669514833920,
  "created_at" : "2013-12-13 16:02:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rich the farmer",
      "screen_name" : "richthefarmer",
      "indices" : [ 3, 17 ],
      "id_str" : "463286921",
      "id" : 463286921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/r3zw6TPKLT",
      "expanded_url" : "http:\/\/youtu.be\/sARNiAAIQ8w",
      "display_url" : "youtu.be\/sARNiAAIQ8w"
    } ]
  },
  "geo" : { },
  "id_str" : "411525412096069633",
  "text" : "RT @richthefarmer: Deer in our back yard last night\n\nhttp:\/\/t.co\/r3zw6TPKLT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/r3zw6TPKLT",
        "expanded_url" : "http:\/\/youtu.be\/sARNiAAIQ8w",
        "display_url" : "youtu.be\/sARNiAAIQ8w"
      } ]
    },
    "geo" : { },
    "id_str" : "411282259287617536",
    "text" : "Deer in our back yard last night\n\nhttp:\/\/t.co\/r3zw6TPKLT",
    "id" : 411282259287617536,
    "created_at" : "2013-12-12 23:51:46 +0000",
    "user" : {
      "name" : "rich the farmer",
      "screen_name" : "richthefarmer",
      "protected" : false,
      "id_str" : "463286921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750678301836845056\/DEBTJruL_normal.jpg",
      "id" : 463286921,
      "verified" : false
    }
  },
  "id" : 411525412096069633,
  "created_at" : "2013-12-13 15:57:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/411492439631732736\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/tEH67xuHTH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbXqMYtCMAALw67.jpg",
      "id_str" : "411492439484936192",
      "id" : 411492439484936192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbXqMYtCMAALw67.jpg",
      "sizes" : [ {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tEH67xuHTH"
    } ],
    "hashtags" : [ {
      "text" : "deerkiss",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "myyard",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411524519841779712",
  "text" : "RT @rm123077: This is what goes on in my backyard late at night. #deerkiss #wildlife #myyard http:\/\/t.co\/tEH67xuHTH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/411492439631732736\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/tEH67xuHTH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbXqMYtCMAALw67.jpg",
        "id_str" : "411492439484936192",
        "id" : 411492439484936192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbXqMYtCMAALw67.jpg",
        "sizes" : [ {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tEH67xuHTH"
      } ],
      "hashtags" : [ {
        "text" : "deerkiss",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 61, 70 ]
      }, {
        "text" : "myyard",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411492439631732736",
    "text" : "This is what goes on in my backyard late at night. #deerkiss #wildlife #myyard http:\/\/t.co\/tEH67xuHTH",
    "id" : 411492439631732736,
    "created_at" : "2013-12-13 13:46:57 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 411524519841779712,
  "created_at" : "2013-12-13 15:54:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411507276776607744",
  "geo" : { },
  "id_str" : "411511338016309248",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses heehee",
  "id" : 411511338016309248,
  "in_reply_to_status_id" : 411507276776607744,
  "created_at" : "2013-12-13 15:02:03 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411322976026370048",
  "geo" : { },
  "id_str" : "411506901990404096",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 i keep forgetting to post that he (she? lol) seems back to normal. swims all over the tank. so i think he's ok. ((fishykisses))",
  "id" : 411506901990404096,
  "in_reply_to_status_id" : 411322976026370048,
  "created_at" : "2013-12-13 14:44:25 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "indices" : [ 3, 14 ],
      "id_str" : "1132090693",
      "id" : 1132090693
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/411308518101487616\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/a7iJGMcNrg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbVC6v5IgAA0bwS.jpg",
      "id_str" : "411308518030213120",
      "id" : 411308518030213120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbVC6v5IgAA0bwS.jpg",
      "sizes" : [ {
        "h" : 713,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 950
      } ],
      "display_url" : "pic.twitter.com\/a7iJGMcNrg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411309732289581056",
  "text" : "RT @Globe_Pics: Lightning over the Grand Canyon http:\/\/t.co\/a7iJGMcNrg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/411308518101487616\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/a7iJGMcNrg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbVC6v5IgAA0bwS.jpg",
        "id_str" : "411308518030213120",
        "id" : 411308518030213120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbVC6v5IgAA0bwS.jpg",
        "sizes" : [ {
          "h" : 713,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 950
        } ],
        "display_url" : "pic.twitter.com\/a7iJGMcNrg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411308518101487616",
    "text" : "Lightning over the Grand Canyon http:\/\/t.co\/a7iJGMcNrg",
    "id" : 411308518101487616,
    "created_at" : "2013-12-13 01:36:07 +0000",
    "user" : {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "protected" : false,
      "id_str" : "1132090693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538457900281126912\/tMIRoIp7_normal.jpeg",
      "id" : 1132090693,
      "verified" : false
    }
  },
  "id" : 411309732289581056,
  "created_at" : "2013-12-13 01:40:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/65q6jc2fko",
      "expanded_url" : "http:\/\/huff.to\/1cx3T5Z",
      "display_url" : "huff.to\/1cx3T5Z"
    } ]
  },
  "geo" : { },
  "id_str" : "411213641849917440",
  "text" : "((sobbing)) &gt;&gt; WestJet Finds Out What Passengers Want For Christmas, Leaves Presents At Baggage Claim (VIDEO) http:\/\/t.co\/65q6jc2fko",
  "id" : 411213641849917440,
  "created_at" : "2013-12-12 19:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Bell",
      "screen_name" : "realrobbell",
      "indices" : [ 3, 15 ],
      "id_str" : "65167734",
      "id" : 65167734
    }, {
      "name" : "HarperOne",
      "screen_name" : "HarperOne",
      "indices" : [ 26, 36 ],
      "id_str" : "22593357",
      "id" : 22593357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/2BRBzcWOyZ",
      "expanded_url" : "http:\/\/ow.ly\/rEcYD",
      "display_url" : "ow.ly\/rEcYD"
    } ]
  },
  "geo" : { },
  "id_str" : "410877430212354048",
  "text" : "RT @realrobbell: Friends, @HarperOne is offering the Love Wins eBook at $2.99 through Dec. 30. Learn more here: http:\/\/t.co\/2BRBzcWOyZ #Lov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HarperOne",
        "screen_name" : "HarperOne",
        "indices" : [ 9, 19 ],
        "id_str" : "22593357",
        "id" : 22593357
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/2BRBzcWOyZ",
        "expanded_url" : "http:\/\/ow.ly\/rEcYD",
        "display_url" : "ow.ly\/rEcYD"
      } ]
    },
    "geo" : { },
    "id_str" : "410870741307912192",
    "text" : "Friends, @HarperOne is offering the Love Wins eBook at $2.99 through Dec. 30. Learn more here: http:\/\/t.co\/2BRBzcWOyZ #LoveWins",
    "id" : 410870741307912192,
    "created_at" : "2013-12-11 20:36:32 +0000",
    "user" : {
      "name" : "Rob Bell",
      "screen_name" : "realrobbell",
      "protected" : false,
      "id_str" : "65167734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520013272154509312\/Od9N-cYV_normal.jpeg",
      "id" : 65167734,
      "verified" : true
    }
  },
  "id" : 410877430212354048,
  "created_at" : "2013-12-11 21:03:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410870517009108992",
  "text" : "our 7yo dog's bloodwork came back. vet says she has bloodwork of 2yo.",
  "id" : 410870517009108992,
  "created_at" : "2013-12-11 20:35:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/WBK97B9kjq",
      "expanded_url" : "http:\/\/huff.to\/1fkIDRE",
      "display_url" : "huff.to\/1fkIDRE"
    } ]
  },
  "geo" : { },
  "id_str" : "410867979778531329",
  "text" : "RT @HuffPostWeird: These footprints are 10,500 years old! http:\/\/t.co\/WBK97B9kjq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/WBK97B9kjq",
        "expanded_url" : "http:\/\/huff.to\/1fkIDRE",
        "display_url" : "huff.to\/1fkIDRE"
      } ]
    },
    "geo" : { },
    "id_str" : "410866343039467521",
    "text" : "These footprints are 10,500 years old! http:\/\/t.co\/WBK97B9kjq",
    "id" : 410866343039467521,
    "created_at" : "2013-12-11 20:19:04 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 410867979778531329,
  "created_at" : "2013-12-11 20:25:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410812831702188032",
  "text" : "RT @SheilaWalsh: Sitting between 2 people who are talking really loudly on their phones. I am about to burst into a commanding performance \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410804362965815296",
    "text" : "Sitting between 2 people who are talking really loudly on their phones. I am about to burst into a commanding performance of Jingle Bells",
    "id" : 410804362965815296,
    "created_at" : "2013-12-11 16:12:47 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 410812831702188032,
  "created_at" : "2013-12-11 16:46:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "WOWBAGGER",
      "screen_name" : "Eschertology",
      "indices" : [ 91, 104 ],
      "id_str" : "335293686",
      "id" : 335293686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410598983858671616",
  "geo" : { },
  "id_str" : "410601151860461569",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny omg, wth did i watch that? now i have a headache and need another pill... o-O @Eschertology",
  "id" : 410601151860461569,
  "in_reply_to_status_id" : 410598983858671616,
  "created_at" : "2013-12-11 02:45:17 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/NKmWramseL",
      "expanded_url" : "http:\/\/shar.es\/O0RUF",
      "display_url" : "shar.es\/O0RUF"
    } ]
  },
  "geo" : { },
  "id_str" : "410586859425636352",
  "text" : "blanket training? WTH?? &gt;&gt; Carefully scripted lives: My concerns about the Duggars http:\/\/t.co\/NKmWramseL",
  "id" : 410586859425636352,
  "created_at" : "2013-12-11 01:48:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410582510528376832",
  "text" : "RT @micahjmurray: The cult promoted a lot of teachings, but ultimately as means to an end: CONFORM. Maybe that\u2019s why I value freedom more t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410529824596172800",
    "text" : "The cult promoted a lot of teachings, but ultimately as means to an end: CONFORM. Maybe that\u2019s why I value freedom more than absolute truth.",
    "id" : 410529824596172800,
    "created_at" : "2013-12-10 22:01:52 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 410582510528376832,
  "created_at" : "2013-12-11 01:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/R9rS1cjJJw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0KPYurNMGlo&feature=share&list=SPVrg5xLmCvhFAH6gE0uLT5RXz-OIIiUhb&index=6",
      "display_url" : "youtube.com\/watch?v=0KPYur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410550156224757760",
  "text" : "the ppl laughing w him.. ugh &gt;&gt; Republican: Pre-Existing Conditions Are Your Own Fault: http:\/\/t.co\/R9rS1cjJJw",
  "id" : 410550156224757760,
  "created_at" : "2013-12-10 23:22:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410473305523494912",
  "geo" : { },
  "id_str" : "410474931529338880",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott lol.. yeah, im pretty much exclusively ebooks now. just easier.",
  "id" : 410474931529338880,
  "in_reply_to_status_id" : 410473305523494912,
  "created_at" : "2013-12-10 18:23:44 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nintendo of America",
      "screen_name" : "NintendoAmerica",
      "indices" : [ 3, 19 ],
      "id_str" : "5162861",
      "id" : 5162861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3DS",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "BecauseItsNintendo",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410472773375770624",
  "text" : "RT @NintendoAmerica: Luigi wants to share his holiday stocking. RT for a chance to win today\u2019s stocking. #3DS #BecauseItsNintendo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NintendoAmerica\/status\/410468982924537856\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/Csykbvyp0Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbJHXW6IAAAAhEi.jpg",
        "id_str" : "410468982656073728",
        "id" : 410468982656073728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbJHXW6IAAAAhEi.jpg",
        "sizes" : [ {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 854
        } ],
        "display_url" : "pic.twitter.com\/Csykbvyp0Z"
      } ],
      "hashtags" : [ {
        "text" : "3DS",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "BecauseItsNintendo",
        "indices" : [ 89, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410468982924537856",
    "text" : "Luigi wants to share his holiday stocking. RT for a chance to win today\u2019s stocking. #3DS #BecauseItsNintendo http:\/\/t.co\/Csykbvyp0Z",
    "id" : 410468982924537856,
    "created_at" : "2013-12-10 18:00:06 +0000",
    "user" : {
      "name" : "Nintendo of America",
      "screen_name" : "NintendoAmerica",
      "protected" : false,
      "id_str" : "5162861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798215824024670209\/nlzO2oHn_normal.jpg",
      "id" : 5162861,
      "verified" : true
    }
  },
  "id" : 410472773375770624,
  "created_at" : "2013-12-10 18:15:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410467397880258560",
  "text" : "RT @SenSanders: Today Sen. Sanders introduced legislation to provide health care for every American through a single-payer system: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/z2F31O7vT2",
        "expanded_url" : "http:\/\/www.sanders.senate.gov\/newsroom\/recent-business\/cover-more-americans-for-less-cost",
        "display_url" : "sanders.senate.gov\/newsroom\/recen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410465312123781120",
    "text" : "Today Sen. Sanders introduced legislation to provide health care for every American through a single-payer system: http:\/\/t.co\/z2F31O7vT2",
    "id" : 410465312123781120,
    "created_at" : "2013-12-10 17:45:31 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 410467397880258560,
  "created_at" : "2013-12-10 17:53:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitay Tweeto",
      "screen_name" : "amitayt",
      "indices" : [ 67, 75 ],
      "id_str" : "14582715",
      "id" : 14582715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thequietplace",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ZjII8RdtyK",
      "expanded_url" : "http:\/\/thequietplaceproject.com\/thequietplace",
      "display_url" : "thequietplaceproject.com\/thequietplace"
    } ]
  },
  "geo" : { },
  "id_str" : "410446228887846913",
  "text" : "visit the quiet place :) #thequietplace http:\/\/t.co\/ZjII8RdtyK via @amitayt",
  "id" : 410446228887846913,
  "created_at" : "2013-12-10 16:29:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patheos",
      "screen_name" : "Patheos",
      "indices" : [ 124, 132 ],
      "id_str" : "31743105",
      "id" : 31743105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410438278568230912",
  "text" : "RT @TomRapsasTweets: On his deathbed, Roger Ebert called life \"an elaborate hoax\"...and glimpsed heaven? See the true story @Patheos: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patheos",
        "screen_name" : "Patheos",
        "indices" : [ 103, 111 ],
        "id_str" : "31743105",
        "id" : 31743105
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PZe9H0qgSi",
        "expanded_url" : "http:\/\/shar.es\/OaPK3",
        "display_url" : "shar.es\/OaPK3"
      } ]
    },
    "geo" : { },
    "id_str" : "410436075463507969",
    "text" : "On his deathbed, Roger Ebert called life \"an elaborate hoax\"...and glimpsed heaven? See the true story @Patheos: http:\/\/t.co\/PZe9H0qgSi",
    "id" : 410436075463507969,
    "created_at" : "2013-12-10 15:49:20 +0000",
    "user" : {
      "name" : "Tom Rapsas",
      "screen_name" : "TomRapsas",
      "protected" : false,
      "id_str" : "84377368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459003600174206977\/OcjkrDsf_normal.jpeg",
      "id" : 84377368,
      "verified" : false
    }
  },
  "id" : 410438278568230912,
  "created_at" : "2013-12-10 15:58:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "indices" : [ 3, 12 ],
      "id_str" : "265346131",
      "id" : 265346131
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/410156633319563265\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/vB5r8MEXfW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbErSN4IgAAZrCh.jpg",
      "id_str" : "410156633030164480",
      "id" : 410156633030164480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbErSN4IgAAZrCh.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1002,
        "resize" : "fit",
        "w" : 1430
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vB5r8MEXfW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410432829181673472",
  "text" : "RT @iauaauoo: Black-necked Swan http:\/\/t.co\/vB5r8MEXfW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/410156633319563265\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/vB5r8MEXfW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbErSN4IgAAZrCh.jpg",
        "id_str" : "410156633030164480",
        "id" : 410156633030164480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbErSN4IgAAZrCh.jpg",
        "sizes" : [ {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1002,
          "resize" : "fit",
          "w" : 1430
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vB5r8MEXfW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 35.3622532, 139.5760655 ]
    },
    "id_str" : "410156633319563265",
    "text" : "Black-necked Swan http:\/\/t.co\/vB5r8MEXfW",
    "id" : 410156633319563265,
    "created_at" : "2013-12-09 21:18:56 +0000",
    "user" : {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "protected" : false,
      "id_str" : "265346131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768291432213774336\/m7AAnnuF_normal.jpg",
      "id" : 265346131,
      "verified" : false
    }
  },
  "id" : 410432829181673472,
  "created_at" : "2013-12-10 15:36:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ujDXY4LqrW",
      "expanded_url" : "http:\/\/www.benjaminleroy.com\/holiday-giveaway\/",
      "display_url" : "benjaminleroy.com\/holiday-giveaw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410432103579660288",
  "text" : "RT @TyrusBooks: As a reminder - the holiday giveaway is still going strong. If you or someone you know needs help... http:\/\/t.co\/ujDXY4LqrW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/ujDXY4LqrW",
        "expanded_url" : "http:\/\/www.benjaminleroy.com\/holiday-giveaway\/",
        "display_url" : "benjaminleroy.com\/holiday-giveaw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410426129434955776",
    "text" : "As a reminder - the holiday giveaway is still going strong. If you or someone you know needs help... http:\/\/t.co\/ujDXY4LqrW",
    "id" : 410426129434955776,
    "created_at" : "2013-12-10 15:09:49 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 410432103579660288,
  "created_at" : "2013-12-10 15:33:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410431223493058560",
  "text" : "RT @ScarlettBaby97: ELVIRA is the First Present Under the Christmas Tree.  She Wishes All A PURRfectly Merry Christmas.  MEOW. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettBaby97\/status\/401781947128881152\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/3UooX6CNg5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZNqjUwIcAArFbf.jpg",
        "id_str" : "401781946864660480",
        "id" : 401781946864660480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZNqjUwIcAArFbf.jpg",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3UooX6CNg5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401781947128881152",
    "text" : "ELVIRA is the First Present Under the Christmas Tree.  She Wishes All A PURRfectly Merry Christmas.  MEOW. http:\/\/t.co\/3UooX6CNg5",
    "id" : 401781947128881152,
    "created_at" : "2013-11-16 18:40:55 +0000",
    "user" : {
      "name" : "Scarlett Baby NYC",
      "screen_name" : "ScarlettBabyNYC",
      "protected" : false,
      "id_str" : "118055895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423808353953804288\/z6d19WJJ_normal.jpeg",
      "id" : 118055895,
      "verified" : false
    }
  },
  "id" : 410431223493058560,
  "created_at" : "2013-12-10 15:30:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. P. Kitten Rescue",
      "screen_name" : "_tinypaws",
      "indices" : [ 3, 13 ],
      "id_str" : "1898813899",
      "id" : 1898813899
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/_tinypaws\/status\/410414028834340864\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/QASHrcZa8Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbIVYnaCEAEnGUH.jpg",
      "id_str" : "410414028683350017",
      "id" : 410414028683350017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbIVYnaCEAEnGUH.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/QASHrcZa8Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410420642937593857",
  "text" : "RT @_tinypaws: Don't forget to feed the birds! Benefits the birds &amp; the kitties! http:\/\/t.co\/QASHrcZa8Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_tinypaws\/status\/410414028834340864\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/QASHrcZa8Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbIVYnaCEAEnGUH.jpg",
        "id_str" : "410414028683350017",
        "id" : 410414028683350017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbIVYnaCEAEnGUH.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/QASHrcZa8Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410414028834340864",
    "text" : "Don't forget to feed the birds! Benefits the birds &amp; the kitties! http:\/\/t.co\/QASHrcZa8Y",
    "id" : 410414028834340864,
    "created_at" : "2013-12-10 14:21:44 +0000",
    "user" : {
      "name" : "T. P. Kitten Rescue",
      "screen_name" : "_tinypaws",
      "protected" : false,
      "id_str" : "1898813899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602704198728310785\/jFGUtrBZ_normal.jpg",
      "id" : 1898813899,
      "verified" : false
    }
  },
  "id" : 410420642937593857,
  "created_at" : "2013-12-10 14:48:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410420493531881472",
  "text" : "Today Sen. Bernie Sanders introduced the American Health Security Act, which would require each state to set up a #SinglePayer health!!",
  "id" : 410420493531881472,
  "created_at" : "2013-12-10 14:47:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/EZZXuSXFYR",
      "expanded_url" : "http:\/\/www.sanders.senate.gov\/newsroom\/newswatch\/121013",
      "display_url" : "sanders.senate.gov\/newsroom\/newsw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410419515076272128",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare Sanders Introduces Single-Payer Bill in Senate (req all states have #SinglePayer ) http:\/\/t.co\/EZZXuSXFYR",
  "id" : 410419515076272128,
  "created_at" : "2013-12-10 14:43:32 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 0, 13 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410226606410461184",
  "geo" : { },
  "id_str" : "410396594513522688",
  "in_reply_to_user_id" : 17068546,
  "text" : "@TorontoLydia : ) they had yummy treats at vet.. she was so happy..lol. she might have surgery after xmas for perm fix of ear.",
  "id" : 410396594513522688,
  "in_reply_to_status_id" : 410226606410461184,
  "created_at" : "2013-12-10 13:12:27 +0000",
  "in_reply_to_screen_name" : "TorontoLydia",
  "in_reply_to_user_id_str" : "17068546",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/DIhvHrCFna",
      "expanded_url" : "http:\/\/www.ipersonic.com\/type\/DI.html#.UqcSDMH54To.twitter",
      "display_url" : "ipersonic.com\/type\/DI.html#.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410395363594362880",
  "text" : "My Personality Type: The Dreamy Idealist http:\/\/t.co\/DIhvHrCFna",
  "id" : 410395363594362880,
  "created_at" : "2013-12-10 13:07:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/9Lx44DrVqC",
      "expanded_url" : "http:\/\/amzn.to\/10S9GwQ",
      "display_url" : "amzn.to\/10S9GwQ"
    } ]
  },
  "geo" : { },
  "id_str" : "410251794712133632",
  "text" : "finished The Nightwatchman by Scott Griffin http:\/\/t.co\/9Lx44DrVqC",
  "id" : 410251794712133632,
  "created_at" : "2013-12-10 03:37:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dudette",
      "screen_name" : "Dudette9t9",
      "indices" : [ 3, 14 ],
      "id_str" : "800748296",
      "id" : 800748296
    }, {
      "name" : "Zbigniew",
      "screen_name" : "zbrad111",
      "indices" : [ 48, 57 ],
      "id_str" : "879917970",
      "id" : 879917970
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zbrad111\/status\/409765011221803009\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/l76rwk69jY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba_HG0mCAAANi_t.jpg",
      "id_str" : "409765011125305344",
      "id" : 409765011125305344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba_HG0mCAAANi_t.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/l76rwk69jY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410218115512160257",
  "text" : "RT @Dudette9t9: Gorgeous pair of Bullfinches RT @zbrad111 http:\/\/t.co\/l76rwk69jY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zbigniew",
        "screen_name" : "zbrad111",
        "indices" : [ 32, 41 ],
        "id_str" : "879917970",
        "id" : 879917970
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zbrad111\/status\/409765011221803009\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/l76rwk69jY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba_HG0mCAAANi_t.jpg",
        "id_str" : "409765011125305344",
        "id" : 409765011125305344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba_HG0mCAAANi_t.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/l76rwk69jY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409995388632846336",
    "text" : "Gorgeous pair of Bullfinches RT @zbrad111 http:\/\/t.co\/l76rwk69jY",
    "id" : 409995388632846336,
    "created_at" : "2013-12-09 10:38:12 +0000",
    "user" : {
      "name" : "Dudette",
      "screen_name" : "Dudette9t9",
      "protected" : false,
      "id_str" : "800748296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591469938075832321\/d6iXGpnN_normal.jpg",
      "id" : 800748296,
      "verified" : false
    }
  },
  "id" : 410218115512160257,
  "created_at" : "2013-12-10 01:23:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egg White",
      "screen_name" : "JediMasterJason",
      "indices" : [ 3, 19 ],
      "id_str" : "419534932",
      "id" : 419534932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410215006824042497",
  "text" : "RT @JediMasterJason: I am proud to be a part of the universe expressing itself as human.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410208981056258048",
    "text" : "I am proud to be a part of the universe expressing itself as human.",
    "id" : 410208981056258048,
    "created_at" : "2013-12-10 00:46:57 +0000",
    "user" : {
      "name" : "Egg White",
      "screen_name" : "JediMasterJason",
      "protected" : false,
      "id_str" : "419534932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621123248198189057\/gk4TaIKd_normal.jpg",
      "id" : 419534932,
      "verified" : false
    }
  },
  "id" : 410215006824042497,
  "created_at" : "2013-12-10 01:10:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KANUNSUZ_5858\/status\/410206148441022464\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Of5zoYTMR3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFYUZLCIAA-aAO.jpg",
      "id_str" : "410206148445216768",
      "id" : 410206148445216768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFYUZLCIAA-aAO.jpg",
      "sizes" : [ {
        "h" : 552,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Of5zoYTMR3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410206728673042433",
  "text" : "RT @KANUNSUZ_5858: E\u011Fer b\u00FCy\u00FCd\u00FC\u011F\u00FCnde \u00F6ld\u00FCreceksen , hi\u00E7 sevme beni ! http:\/\/t.co\/Of5zoYTMR3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KANUNSUZ_5858\/status\/410206148441022464\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/Of5zoYTMR3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFYUZLCIAA-aAO.jpg",
        "id_str" : "410206148445216768",
        "id" : 410206148445216768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFYUZLCIAA-aAO.jpg",
        "sizes" : [ {
          "h" : 552,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 552,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 552,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Of5zoYTMR3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410206148441022464",
    "text" : "E\u011Fer b\u00FCy\u00FCd\u00FC\u011F\u00FCnde \u00F6ld\u00FCreceksen , hi\u00E7 sevme beni ! http:\/\/t.co\/Of5zoYTMR3",
    "id" : 410206148441022464,
    "created_at" : "2013-12-10 00:35:41 +0000",
    "user" : {
      "name" : "SPARTACUS",
      "screen_name" : "KANUNSUZ_1923",
      "protected" : false,
      "id_str" : "602215053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752819346813190144\/C3vpL9gL_normal.jpg",
      "id" : 602215053,
      "verified" : false
    }
  },
  "id" : 410206728673042433,
  "created_at" : "2013-12-10 00:38:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 0, 13 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410184327327395841",
  "geo" : { },
  "id_str" : "410205918257627136",
  "in_reply_to_user_id" : 197910360,
  "text" : "@JoshuaDamnIt jeepers.. really?? wth",
  "id" : 410205918257627136,
  "in_reply_to_status_id" : 410184327327395841,
  "created_at" : "2013-12-10 00:34:46 +0000",
  "in_reply_to_screen_name" : "ALifeRelentless",
  "in_reply_to_user_id_str" : "197910360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 0, 13 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410204821505859584",
  "in_reply_to_user_id" : 197910360,
  "text" : "@JoshuaDamnIt ((facepalm)) lol",
  "id" : 410204821505859584,
  "created_at" : "2013-12-10 00:30:25 +0000",
  "in_reply_to_screen_name" : "ALifeRelentless",
  "in_reply_to_user_id_str" : "197910360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410178454361894913",
  "text" : "dog was sooo good at vet today. has aural hematoma. got that drained and was poked for bloodwork. she gave them wiggles afterward.",
  "id" : 410178454361894913,
  "created_at" : "2013-12-09 22:45:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410176680192274432",
  "text" : "possum on porch.. i talked sweetly thru door to him. little ears twitched and turned. then he ran off.",
  "id" : 410176680192274432,
  "created_at" : "2013-12-09 22:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409834760933240832",
  "geo" : { },
  "id_str" : "409840754505158656",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 they consider that morality. from what i see, they are all for social equality, being decent people, etc.",
  "id" : 409840754505158656,
  "in_reply_to_status_id" : 409834760933240832,
  "created_at" : "2013-12-09 00:23:45 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409833462711869440",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia nice to see you in my timeline. : ) its been awhile.",
  "id" : 409833462711869440,
  "created_at" : "2013-12-08 23:54:46 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WFMU",
      "screen_name" : "WFMU",
      "indices" : [ 3, 8 ],
      "id_str" : "17369528",
      "id" : 17369528
    }, {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 118, 133 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/David_baker_\/status\/409482515284389888\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/dsKSyzZjIE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba7GLZVCEAANOwx.jpg",
      "id_str" : "409482515217256448",
      "id" : 409482515217256448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba7GLZVCEAANOwx.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 694
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 694
      } ],
      "display_url" : "pic.twitter.com\/dsKSyzZjIE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409833150433755137",
  "text" : "RT @WFMU: The Creation of Adam by Michelangelo as Rendered by Poking Pinholes in a Banana:  http:\/\/t.co\/dsKSyzZjIE ht @stevesilberman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Silberman",
        "screen_name" : "stevesilberman",
        "indices" : [ 108, 123 ],
        "id_str" : "18655567",
        "id" : 18655567
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/David_baker_\/status\/409482515284389888\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/dsKSyzZjIE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba7GLZVCEAANOwx.jpg",
        "id_str" : "409482515217256448",
        "id" : 409482515217256448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba7GLZVCEAANOwx.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 694
        } ],
        "display_url" : "pic.twitter.com\/dsKSyzZjIE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409778282679128064",
    "text" : "The Creation of Adam by Michelangelo as Rendered by Poking Pinholes in a Banana:  http:\/\/t.co\/dsKSyzZjIE ht @stevesilberman",
    "id" : 409778282679128064,
    "created_at" : "2013-12-08 20:15:30 +0000",
    "user" : {
      "name" : "WFMU",
      "screen_name" : "WFMU",
      "protected" : false,
      "id_str" : "17369528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000409162284\/331240d15978f9d60a274d6427bfeb23_normal.png",
      "id" : 17369528,
      "verified" : false
    }
  },
  "id" : 409833150433755137,
  "created_at" : "2013-12-08 23:53:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409830367320084481",
  "geo" : { },
  "id_str" : "409833032409833472",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 well.. generally that's the rule, I think? I follow quite a few. As far as I can tell, no god, no soul, no spirits, etc.",
  "id" : 409833032409833472,
  "in_reply_to_status_id" : 409830367320084481,
  "created_at" : "2013-12-08 23:53:03 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    }, {
      "name" : "Bookfoolery",
      "screen_name" : "Bookfoolery",
      "indices" : [ 13, 25 ],
      "id_str" : "18091880",
      "id" : 18091880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409827315787792384",
  "geo" : { },
  "id_str" : "409829924929667073",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles @Bookfoolery LOL",
  "id" : 409829924929667073,
  "in_reply_to_status_id" : 409827315787792384,
  "created_at" : "2013-12-08 23:40:43 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sauk River Review",
      "screen_name" : "OldSaukRiver",
      "indices" : [ 3, 16 ],
      "id_str" : "374901847",
      "id" : 374901847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409817081400815616",
  "text" : "RT @OldSaukRiver: An Australian psychiatrist describes the single payer health care his family enjoys @ Sauk River Review: Mens Sana http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ROk4ROtnRM",
        "expanded_url" : "http:\/\/oldsaukriver.blogspot.com\/2013\/11\/mens-sana.html?spref=tw",
        "display_url" : "oldsaukriver.blogspot.com\/2013\/11\/mens-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409800970348949504",
    "text" : "An Australian psychiatrist describes the single payer health care his family enjoys @ Sauk River Review: Mens Sana http:\/\/t.co\/ROk4ROtnRM",
    "id" : 409800970348949504,
    "created_at" : "2013-12-08 21:45:39 +0000",
    "user" : {
      "name" : "Sauk River Review",
      "screen_name" : "OldSaukRiver",
      "protected" : false,
      "id_str" : "374901847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1546492517\/old_sauk_river_trail_normal.jpg",
      "id" : 374901847,
      "verified" : false
    }
  },
  "id" : 409817081400815616,
  "created_at" : "2013-12-08 22:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409785974693318656",
  "geo" : { },
  "id_str" : "409786678711042048",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis LOL",
  "id" : 409786678711042048,
  "in_reply_to_status_id" : 409785974693318656,
  "created_at" : "2013-12-08 20:48:52 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409786258672857088",
  "text" : "RT @ChrisCapparell: I watched myself commit a sin this morning. And while I watched, accepting myself, I realized it was because I didn't y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409785418406588416",
    "text" : "I watched myself commit a sin this morning. And while I watched, accepting myself, I realized it was because I didn't yet know how not to.",
    "id" : 409785418406588416,
    "created_at" : "2013-12-08 20:43:51 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 409786258672857088,
  "created_at" : "2013-12-08 20:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 0, 13 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409782688720367616",
  "geo" : { },
  "id_str" : "409784484859375616",
  "in_reply_to_user_id" : 197910360,
  "text" : "@JoshuaDamnIt also, looking back, i can see kindness extended to me. some not even knowing it! so grateful.",
  "id" : 409784484859375616,
  "in_reply_to_status_id" : 409782688720367616,
  "created_at" : "2013-12-08 20:40:09 +0000",
  "in_reply_to_screen_name" : "ALifeRelentless",
  "in_reply_to_user_id_str" : "197910360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 0, 13 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409782688720367616",
  "geo" : { },
  "id_str" : "409783932054282240",
  "in_reply_to_user_id" : 197910360,
  "text" : "@JoshuaDamnIt yeah.. at 20, used to think i was so nice, etc. but looking back, can see the errors. im still learning.",
  "id" : 409783932054282240,
  "in_reply_to_status_id" : 409782688720367616,
  "created_at" : "2013-12-08 20:37:57 +0000",
  "in_reply_to_screen_name" : "ALifeRelentless",
  "in_reply_to_user_id_str" : "197910360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/409776842485149696\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/l5iUqRwKF0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba_R3f3CMAEBOqS.png",
      "id_str" : "409776842489344001",
      "id" : 409776842489344001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba_R3f3CMAEBOqS.png",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/l5iUqRwKF0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409783205483786240",
  "text" : "RT @CUMALi_YILDIZ: http:\/\/t.co\/l5iUqRwKF0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/409776842485149696\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/l5iUqRwKF0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba_R3f3CMAEBOqS.png",
        "id_str" : "409776842489344001",
        "id" : 409776842489344001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba_R3f3CMAEBOqS.png",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 683
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 683
        } ],
        "display_url" : "pic.twitter.com\/l5iUqRwKF0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409776842485149696",
    "text" : "http:\/\/t.co\/l5iUqRwKF0",
    "id" : 409776842485149696,
    "created_at" : "2013-12-08 20:09:47 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 409783205483786240,
  "created_at" : "2013-12-08 20:35:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 0, 14 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409776842485149696",
  "geo" : { },
  "id_str" : "409783178832801793",
  "in_reply_to_user_id" : 109003770,
  "text" : "@CUMALi_YILDIZ precious!",
  "id" : 409783178832801793,
  "in_reply_to_status_id" : 409776842485149696,
  "created_at" : "2013-12-08 20:34:57 +0000",
  "in_reply_to_screen_name" : "CUMALi_YILDIZ",
  "in_reply_to_user_id_str" : "109003770",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "Ivanroberson",
      "indices" : [ 3, 16 ],
      "id_str" : "40874240",
      "id" : 40874240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UniteBlue",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Mk9RqrWKwN",
      "expanded_url" : "http:\/\/www.politicususa.com\/2013\/12\/08\/sen-rand-paul-unemployment-benefits.html",
      "display_url" : "politicususa.com\/2013\/12\/08\/sen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409780538828804096",
  "text" : "RT @Ivanroberson: Rand Paul Tells Millions He\u2019s Doing Them a Favor By Cutting Off Unemployment Benefits http:\/\/t.co\/Mk9RqrWKwN #UniteBlue #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UniteBlue",
        "indices" : [ 109, 119 ]
      }, {
        "text" : "LibCrib",
        "indices" : [ 120, 128 ]
      }, {
        "text" : "P2",
        "indices" : [ 129, 132 ]
      }, {
        "text" : "CTL",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Mk9RqrWKwN",
        "expanded_url" : "http:\/\/www.politicususa.com\/2013\/12\/08\/sen-rand-paul-unemployment-benefits.html",
        "display_url" : "politicususa.com\/2013\/12\/08\/sen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409770356983881729",
    "text" : "Rand Paul Tells Millions He\u2019s Doing Them a Favor By Cutting Off Unemployment Benefits http:\/\/t.co\/Mk9RqrWKwN #UniteBlue #LibCrib #P2 #CTL",
    "id" : 409770356983881729,
    "created_at" : "2013-12-08 19:44:00 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "Ivanroberson",
      "protected" : false,
      "id_str" : "40874240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797235761640783873\/brKY5iyX_normal.jpg",
      "id" : 40874240,
      "verified" : false
    }
  },
  "id" : 409780538828804096,
  "created_at" : "2013-12-08 20:24:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/409775161143881728\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/PaMo4ljX8p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba_QVoYCcAAA3F4.jpg",
      "id_str" : "409775161148076032",
      "id" : 409775161148076032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba_QVoYCcAAA3F4.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PaMo4ljX8p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409779816175763456",
  "text" : "RT @CUMALi_YILDIZ: http:\/\/t.co\/PaMo4ljX8p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/409775161143881728\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/PaMo4ljX8p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba_QVoYCcAAA3F4.jpg",
        "id_str" : "409775161148076032",
        "id" : 409775161148076032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba_QVoYCcAAA3F4.jpg",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PaMo4ljX8p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409775161143881728",
    "text" : "http:\/\/t.co\/PaMo4ljX8p",
    "id" : 409775161143881728,
    "created_at" : "2013-12-08 20:03:06 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 409779816175763456,
  "created_at" : "2013-12-08 20:21:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 0, 14 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409775161143881728",
  "geo" : { },
  "id_str" : "409779774630797313",
  "in_reply_to_user_id" : 109003770,
  "text" : "@CUMALi_YILDIZ lovely!",
  "id" : 409779774630797313,
  "in_reply_to_status_id" : 409775161143881728,
  "created_at" : "2013-12-08 20:21:26 +0000",
  "in_reply_to_screen_name" : "CUMALi_YILDIZ",
  "in_reply_to_user_id_str" : "109003770",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 0, 13 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409775191599120384",
  "geo" : { },
  "id_str" : "409779446896287744",
  "in_reply_to_user_id" : 197910360,
  "text" : "@JoshuaDamnIt is yr inner circle mostly atheist? (they feel comfortable offering help) often, god bless is a way to express a deep feeling.",
  "id" : 409779446896287744,
  "in_reply_to_status_id" : 409775191599120384,
  "created_at" : "2013-12-08 20:20:08 +0000",
  "in_reply_to_screen_name" : "ALifeRelentless",
  "in_reply_to_user_id_str" : "197910360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    }, {
      "name" : "Mind Blowing",
      "screen_name" : "TheMindBlowing",
      "indices" : [ 43, 58 ],
      "id_str" : "488751763",
      "id" : 488751763
    }, {
      "name" : "Elen A.Arruda Queiro",
      "screen_name" : "DraElen",
      "indices" : [ 59, 67 ],
      "id_str" : "724692420009558021",
      "id" : 724692420009558021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409725219134128129",
  "geo" : { },
  "id_str" : "409729420451414016",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni ahh.. so that's how it works!  @TheMindBlowing @Draelen",
  "id" : 409729420451414016,
  "in_reply_to_status_id" : 409725219134128129,
  "created_at" : "2013-12-08 17:01:20 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409711316346355712",
  "text" : "RT @adamrshields: Just added RSS advertising spot on Bookwi.se  Far more people read Bookwi.se via RSS than on site (4x).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409707189637353473",
    "text" : "Just added RSS advertising spot on Bookwi.se  Far more people read Bookwi.se via RSS than on site (4x).",
    "id" : 409707189637353473,
    "created_at" : "2013-12-08 15:33:00 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 409711316346355712,
  "created_at" : "2013-12-08 15:49:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 0, 9 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409709080807079936",
  "geo" : { },
  "id_str" : "409710814115790848",
  "in_reply_to_user_id" : 552094863,
  "text" : "@AWrobley love this pic so much!",
  "id" : 409710814115790848,
  "in_reply_to_status_id" : 409709080807079936,
  "created_at" : "2013-12-08 15:47:24 +0000",
  "in_reply_to_screen_name" : "AWrobley",
  "in_reply_to_user_id_str" : "552094863",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/409709080807079936\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/WDhfnj8Cwz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba-UPP8CAAAuSbA.jpg",
      "id_str" : "409709080811274240",
      "id" : 409709080811274240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba-UPP8CAAAuSbA.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/WDhfnj8Cwz"
    } ],
    "hashtags" : [ {
      "text" : "rimcountry",
      "indices" : [ 82, 93 ]
    }, {
      "text" : "chickadee",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409710292755816448",
  "text" : "RT @AWrobley: This morning; first snow, first light, first bird, first seed ;o))  #rimcountry #chickadee http:\/\/t.co\/WDhfnj8Cwz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/409709080807079936\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/WDhfnj8Cwz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba-UPP8CAAAuSbA.jpg",
        "id_str" : "409709080811274240",
        "id" : 409709080811274240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba-UPP8CAAAuSbA.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/WDhfnj8Cwz"
      } ],
      "hashtags" : [ {
        "text" : "rimcountry",
        "indices" : [ 68, 79 ]
      }, {
        "text" : "chickadee",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409709080807079936",
    "text" : "This morning; first snow, first light, first bird, first seed ;o))  #rimcountry #chickadee http:\/\/t.co\/WDhfnj8Cwz",
    "id" : 409709080807079936,
    "created_at" : "2013-12-08 15:40:31 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 409710292755816448,
  "created_at" : "2013-12-08 15:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PetSmart Charities\u00AE",
      "screen_name" : "PetSmartChariTs",
      "indices" : [ 3, 19 ],
      "id_str" : "42368820",
      "id" : 42368820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankfulpets",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409706223601451008",
  "text" : "RT @PetSmartChariTs: Tucker is thankful his mom was patient while he adjusted to his new home. Tweet us your #thankfulpets pic. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PetSmartChariTs\/status\/403688534726307840\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/yHc8ipiu08",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZowlVXCUAASUg9.jpg",
        "id_str" : "403688534550138880",
        "id" : 403688534550138880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZowlVXCUAASUg9.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yHc8ipiu08"
      } ],
      "hashtags" : [ {
        "text" : "thankfulpets",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403688534726307840",
    "text" : "Tucker is thankful his mom was patient while he adjusted to his new home. Tweet us your #thankfulpets pic. http:\/\/t.co\/yHc8ipiu08",
    "id" : 403688534726307840,
    "created_at" : "2013-11-22 00:57:01 +0000",
    "user" : {
      "name" : "PetSmart Charities\u00AE",
      "screen_name" : "PetSmartChariTs",
      "protected" : false,
      "id_str" : "42368820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740147389837316\/CVKRNqhw_normal.jpg",
      "id" : 42368820,
      "verified" : true
    }
  },
  "id" : 409706223601451008,
  "created_at" : "2013-12-08 15:29:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409437107489234944",
  "geo" : { },
  "id_str" : "409437920685092864",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis ahhh.. got it.",
  "id" : 409437920685092864,
  "in_reply_to_status_id" : 409437107489234944,
  "created_at" : "2013-12-07 21:43:01 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409429742656299008",
  "geo" : { },
  "id_str" : "409436684032286720",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis do they know yr atheist?",
  "id" : 409436684032286720,
  "in_reply_to_status_id" : 409429742656299008,
  "created_at" : "2013-12-07 21:38:07 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 131, 137 ]
    }, {
      "text" : "livecams",
      "indices" : [ 138, 147 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/t06RwKVwBU",
      "expanded_url" : "http:\/\/camodave.co.uk",
      "display_url" : "camodave.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "409411981225906177",
  "text" : "RT @CamoDave_: LIVE cam showing roosting Great Tit wakes up now &amp; again to preen &amp; stretch watch at http:\/\/t.co\/t06RwKVwBU #birds #livecams\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 116, 122 ]
      }, {
        "text" : "livecams",
        "indices" : [ 123, 132 ]
      }, {
        "text" : "Greattit",
        "indices" : [ 133, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/t06RwKVwBU",
        "expanded_url" : "http:\/\/camodave.co.uk",
        "display_url" : "camodave.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "409410924152250368",
    "text" : "LIVE cam showing roosting Great Tit wakes up now &amp; again to preen &amp; stretch watch at http:\/\/t.co\/t06RwKVwBU #birds #livecams #Greattit",
    "id" : 409410924152250368,
    "created_at" : "2013-12-07 19:55:45 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 409411981225906177,
  "created_at" : "2013-12-07 19:59:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 11, 23 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/cndrCwXH9s",
      "expanded_url" : "http:\/\/rationalwiki.org\/wiki\/List_of_scientists_who_became_creationists_after_studying_the_evidence",
      "display_url" : "rationalwiki.org\/wiki\/List_of_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409410230556975104",
  "text" : "seen this? @VirgoJohnny http:\/\/t.co\/cndrCwXH9s",
  "id" : 409410230556975104,
  "created_at" : "2013-12-07 19:53:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Starkiller",
      "screen_name" : "MarcStarkiller",
      "indices" : [ 3, 18 ],
      "id_str" : "25488447",
      "id" : 25488447
    }, {
      "name" : "Dr. Kate Riordan.",
      "screen_name" : "cathorio",
      "indices" : [ 39, 48 ],
      "id_str" : "105202268",
      "id" : 105202268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409404013705449472",
  "text" : "RT @MarcStarkiller: So heartbreaking! \"@cathorio: #Blackfish: Say No 2 Captivity.....This is so very wrong. Cruel beyond words. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Kate Riordan.",
        "screen_name" : "cathorio",
        "indices" : [ 19, 28 ],
        "id_str" : "105202268",
        "id" : 105202268
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cathorio\/status\/403654885414936576\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/rIFY9qxrAB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZoR-r1CAAAr24o.jpg",
        "id_str" : "403654885217796096",
        "id" : 403654885217796096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZoR-r1CAAAr24o.jpg",
        "sizes" : [ {
          "h" : 474,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rIFY9qxrAB"
      } ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403910259162775552",
    "text" : "So heartbreaking! \"@cathorio: #Blackfish: Say No 2 Captivity.....This is so very wrong. Cruel beyond words. http:\/\/t.co\/rIFY9qxrAB\"",
    "id" : 403910259162775552,
    "created_at" : "2013-11-22 15:38:04 +0000",
    "user" : {
      "name" : "Marc Starkiller",
      "screen_name" : "MarcStarkiller",
      "protected" : false,
      "id_str" : "25488447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573247164211699712\/sjHIEBR4_normal.jpeg",
      "id" : 25488447,
      "verified" : false
    }
  },
  "id" : 409404013705449472,
  "created_at" : "2013-12-07 19:28:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bison",
      "indices" : [ 49, 55 ]
    }, {
      "text" : "Montana",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409381843453353984",
  "text" : "RT @Interior: Winter has arrived at the National #Bison Range in #Montana &amp; the residents appear to be taking it in stride. http:\/\/t.co\/3P0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/409084329554640896\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/3P0vMpb7Lg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1cB7gIAAAzbH_.jpg",
        "id_str" : "409084329382641664",
        "id" : 409084329382641664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1cB7gIAAAzbH_.jpg",
        "sizes" : [ {
          "h" : 926,
          "resize" : "fit",
          "w" : 926
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 926,
          "resize" : "fit",
          "w" : 926
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3P0vMpb7Lg"
      } ],
      "hashtags" : [ {
        "text" : "Bison",
        "indices" : [ 35, 41 ]
      }, {
        "text" : "Montana",
        "indices" : [ 51, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409084329554640896",
    "text" : "Winter has arrived at the National #Bison Range in #Montana &amp; the residents appear to be taking it in stride. http:\/\/t.co\/3P0vMpb7Lg",
    "id" : 409084329554640896,
    "created_at" : "2013-12-06 22:17:59 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 409381843453353984,
  "created_at" : "2013-12-07 18:00:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 24, 40 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409368380194709504",
  "geo" : { },
  "id_str" : "409380491549106178",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny hehe.. hey @shoeofallcosmos , you'll like this! :D",
  "id" : 409380491549106178,
  "in_reply_to_status_id" : 409368380194709504,
  "created_at" : "2013-12-07 17:54:49 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiderwort52",
      "screen_name" : "Spiderwort52",
      "indices" : [ 3, 16 ],
      "id_str" : "269871152",
      "id" : 269871152
    }, {
      "name" : "Outback Pics",
      "screen_name" : "OutbackPics",
      "indices" : [ 22, 34 ],
      "id_str" : "170602260",
      "id" : 170602260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409379949314068480",
  "text" : "RT @Spiderwort52: MT @@OutbackPics: More budgie leaves - the budgies were out in the Mitchell Grass after the rain - north of Longreach htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Outback Pics",
        "screen_name" : "OutbackPics",
        "indices" : [ 4, 16 ],
        "id_str" : "170602260",
        "id" : 170602260
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OutbackPics\/status\/406018459147857920\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zstN9pk9Be",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaJ3oy4CcAEOTAE.jpg",
        "id_str" : "406018459152052225",
        "id" : 406018459152052225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaJ3oy4CcAEOTAE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zstN9pk9Be"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "406018459147857920",
    "geo" : { },
    "id_str" : "406619914443583488",
    "in_reply_to_user_id" : 170602260,
    "text" : "MT @@OutbackPics: More budgie leaves - the budgies were out in the Mitchell Grass after the rain - north of Longreach http:\/\/t.co\/zstN9pk9Be",
    "id" : 406619914443583488,
    "in_reply_to_status_id" : 406018459147857920,
    "created_at" : "2013-11-30 03:05:16 +0000",
    "in_reply_to_screen_name" : "OutbackPics",
    "in_reply_to_user_id_str" : "170602260",
    "user" : {
      "name" : "Spiderwort52",
      "screen_name" : "Spiderwort52",
      "protected" : false,
      "id_str" : "269871152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783896078622031872\/GDs0g-3s_normal.jpg",
      "id" : 269871152,
      "verified" : false
    }
  },
  "id" : 409379949314068480,
  "created_at" : "2013-12-07 17:52:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    }, {
      "name" : "A.B. Shepherd",
      "screen_name" : "ABHPShepherd",
      "indices" : [ 126, 139 ],
      "id_str" : "459821326",
      "id" : 459821326
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amangry",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "stupidpeople",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Ocj1sYbbUN",
      "expanded_url" : "http:\/\/goo.gl\/mBof4a",
      "display_url" : "goo.gl\/mBof4a"
    } ]
  },
  "geo" : { },
  "id_str" : "409378866059546624",
  "text" : "RT @DarciaHelle: Hopping on my soapbox - Mandela vs. Walker Death Shaming.  #amangry #stupidpeople http:\/\/t.co\/Ocj1sYbbUN via @ABHPShepherd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A.B. Shepherd",
        "screen_name" : "ABHPShepherd",
        "indices" : [ 109, 122 ],
        "id_str" : "459821326",
        "id" : 459821326
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amangry",
        "indices" : [ 59, 67 ]
      }, {
        "text" : "stupidpeople",
        "indices" : [ 68, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Ocj1sYbbUN",
        "expanded_url" : "http:\/\/goo.gl\/mBof4a",
        "display_url" : "goo.gl\/mBof4a"
      } ]
    },
    "geo" : { },
    "id_str" : "409375006645170176",
    "text" : "Hopping on my soapbox - Mandela vs. Walker Death Shaming.  #amangry #stupidpeople http:\/\/t.co\/Ocj1sYbbUN via @ABHPShepherd",
    "id" : 409375006645170176,
    "created_at" : "2013-12-07 17:33:02 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 409378866059546624,
  "created_at" : "2013-12-07 17:48:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409362881847631872",
  "text" : "as much as i dislike him.. he is obv a man w issues who needs compassion. sigh...",
  "id" : 409362881847631872,
  "created_at" : "2013-12-07 16:44:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/7IPLSg8tjz",
      "expanded_url" : "https:\/\/www.facebook.com\/pastormark\/posts\/10152019752931912",
      "display_url" : "facebook.com\/pastormark\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409362213510475777",
  "text" : "another interesting..lol &gt; https:\/\/t.co\/7IPLSg8tjz",
  "id" : 409362213510475777,
  "created_at" : "2013-12-07 16:42:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/mKl9xUiSjS",
      "expanded_url" : "https:\/\/www.facebook.com\/pastormark\/posts\/10152022423916912",
      "display_url" : "facebook.com\/pastormark\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409361306345418754",
  "text" : "hmm.. very interesting &gt;&gt; https:\/\/t.co\/mKl9xUiSjS",
  "id" : 409361306345418754,
  "created_at" : "2013-12-07 16:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/409068545830424576\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/zxwBYKBFYv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1NrNOCEAA9cMN.jpg",
      "id_str" : "409068545838813184",
      "id" : 409068545838813184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1NrNOCEAA9cMN.jpg",
      "sizes" : [ {
        "h" : 323,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zxwBYKBFYv"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "Robins",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409345423271534592",
  "text" : "RT @CamoDave_: This cheeky chap was following me around the garden while working, #birds #Robins http:\/\/t.co\/zxwBYKBFYv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/409068545830424576\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/zxwBYKBFYv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1NrNOCEAA9cMN.jpg",
        "id_str" : "409068545838813184",
        "id" : 409068545838813184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1NrNOCEAA9cMN.jpg",
        "sizes" : [ {
          "h" : 323,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zxwBYKBFYv"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "Robins",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409284221903966208",
    "text" : "This cheeky chap was following me around the garden while working, #birds #Robins http:\/\/t.co\/zxwBYKBFYv",
    "id" : 409284221903966208,
    "created_at" : "2013-12-07 11:32:17 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 409345423271534592,
  "created_at" : "2013-12-07 15:35:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    }, {
      "name" : "~*~ Saffron ~*~",
      "screen_name" : "Saffron606",
      "indices" : [ 28, 39 ],
      "id_str" : "498903705",
      "id" : 498903705
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Saffron606\/status\/409191896041279488\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/TvBDWPtlm0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba293IjCUAA6TAy.jpg",
      "id_str" : "409191896045473792",
      "id" : 409191896045473792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba293IjCUAA6TAy.jpg",
      "sizes" : [ {
        "h" : 327,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/TvBDWPtlm0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409345241339396096",
  "text" : "RT @MartinBelan: Beauty! RT @Saffron606: http:\/\/t.co\/TvBDWPtlm0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "~*~ Saffron ~*~",
        "screen_name" : "Saffron606",
        "indices" : [ 11, 22 ],
        "id_str" : "498903705",
        "id" : 498903705
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Saffron606\/status\/409191896041279488\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/TvBDWPtlm0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba293IjCUAA6TAy.jpg",
        "id_str" : "409191896045473792",
        "id" : 409191896045473792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba293IjCUAA6TAy.jpg",
        "sizes" : [ {
          "h" : 327,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/TvBDWPtlm0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409345063727030272",
    "text" : "Beauty! RT @Saffron606: http:\/\/t.co\/TvBDWPtlm0",
    "id" : 409345063727030272,
    "created_at" : "2013-12-07 15:34:03 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 409345241339396096,
  "created_at" : "2013-12-07 15:34:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409339012105515008",
  "text" : "yeah, i guess previous tweet does not make sense..lol. my thoughts are not always coherent.",
  "id" : 409339012105515008,
  "created_at" : "2013-12-07 15:10:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409338040708898819",
  "text" : "not all of us are bungee jumpers, some of us are rocks soaking up the sun.",
  "id" : 409338040708898819,
  "created_at" : "2013-12-07 15:06:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "indices" : [ 3, 19 ],
      "id_str" : "829603410",
      "id" : 829603410
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Fifthcolumnblue\/status\/409318447646924801\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/D1ZudTneKP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba4w9aCCYAE33Um.jpg",
      "id_str" : "409318447655313409",
      "id" : 409318447655313409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba4w9aCCYAE33Um.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/D1ZudTneKP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409337520401682432",
  "text" : "RT @Fifthcolumnblue: Where American tax dollars actually go: http:\/\/t.co\/D1ZudTneKP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fifthcolumnblue\/status\/409318447646924801\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/D1ZudTneKP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba4w9aCCYAE33Um.jpg",
        "id_str" : "409318447655313409",
        "id" : 409318447655313409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba4w9aCCYAE33Um.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/D1ZudTneKP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409318447646924801",
    "text" : "Where American tax dollars actually go: http:\/\/t.co\/D1ZudTneKP",
    "id" : 409318447646924801,
    "created_at" : "2013-12-07 13:48:17 +0000",
    "user" : {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "protected" : false,
      "id_str" : "829603410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796277104707047424\/MgURyKNE_normal.jpg",
      "id" : 829603410,
      "verified" : false
    }
  },
  "id" : 409337520401682432,
  "created_at" : "2013-12-07 15:04:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ificouldtellu\/status\/409320160701321216\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/10LRnjrvcW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba4yhHECUAAW4pf.jpg",
      "id_str" : "409320160550342656",
      "id" : 409320160550342656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba4yhHECUAAW4pf.jpg",
      "sizes" : [ {
        "h" : 477,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/10LRnjrvcW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409337248484950016",
  "text" : "RT @ificouldtellu: http:\/\/t.co\/10LRnjrvcW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ificouldtellu\/status\/409320160701321216\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/10LRnjrvcW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba4yhHECUAAW4pf.jpg",
        "id_str" : "409320160550342656",
        "id" : 409320160550342656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba4yhHECUAAW4pf.jpg",
        "sizes" : [ {
          "h" : 477,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/10LRnjrvcW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409320160701321216",
    "text" : "http:\/\/t.co\/10LRnjrvcW",
    "id" : 409320160701321216,
    "created_at" : "2013-12-07 13:55:05 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 409337248484950016,
  "created_at" : "2013-12-07 15:02:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doris Koren",
      "screen_name" : "csareb",
      "indices" : [ 3, 10 ],
      "id_str" : "53754783",
      "id" : 53754783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/0gvqvbdhiA",
      "expanded_url" : "http:\/\/huff.to\/1coHyHN",
      "display_url" : "huff.to\/1coHyHN"
    } ]
  },
  "geo" : { },
  "id_str" : "409337169179070464",
  "text" : "RT @csareb: Love this: Goose's Gentle Touch Turns Aggressive German Shepherd Into Playful Dog (PHOTOS) http:\/\/t.co\/0gvqvbdhiA via @HPGoodNe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HPGoodNews",
        "screen_name" : "HPGoodNews",
        "indices" : [ 118, 129 ],
        "id_str" : "2243011218",
        "id" : 2243011218
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/0gvqvbdhiA",
        "expanded_url" : "http:\/\/huff.to\/1coHyHN",
        "display_url" : "huff.to\/1coHyHN"
      } ]
    },
    "geo" : { },
    "id_str" : "409320557314732032",
    "text" : "Love this: Goose's Gentle Touch Turns Aggressive German Shepherd Into Playful Dog (PHOTOS) http:\/\/t.co\/0gvqvbdhiA via @HPGoodNews",
    "id" : 409320557314732032,
    "created_at" : "2013-12-07 13:56:40 +0000",
    "user" : {
      "name" : "Doris Koren",
      "screen_name" : "csareb",
      "protected" : false,
      "id_str" : "53754783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000589977131\/34d3a7c4c94e678f3580fa6fe54f9573_normal.jpeg",
      "id" : 53754783,
      "verified" : false
    }
  },
  "id" : 409337169179070464,
  "created_at" : "2013-12-07 15:02:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409182021270110209",
  "geo" : { },
  "id_str" : "409335988528242688",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses pretty design",
  "id" : 409335988528242688,
  "in_reply_to_status_id" : 409182021270110209,
  "created_at" : "2013-12-07 14:57:59 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 3, 16 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409335245226639360",
  "text" : "RT @JoshuaDamnIt: Should &lt;- I hate that word.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409326098405535744",
    "text" : "Should &lt;- I hate that word.",
    "id" : 409326098405535744,
    "created_at" : "2013-12-07 14:18:41 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 409335245226639360,
  "created_at" : "2013-12-07 14:55:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409134806497124352",
  "geo" : { },
  "id_str" : "409139358126465025",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH i appreciate you sharing : )",
  "id" : 409139358126465025,
  "in_reply_to_status_id" : 409134806497124352,
  "created_at" : "2013-12-07 01:56:39 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409135431226105857",
  "geo" : { },
  "id_str" : "409138957985665024",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses im sorry yr having bad day ((hugs))",
  "id" : 409138957985665024,
  "in_reply_to_status_id" : 409135431226105857,
  "created_at" : "2013-12-07 01:55:03 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409135173536849920",
  "text" : "RT @SangyeH: It troubles me to see liberals &amp; conservatives demonizing each other. When we make the \"other\" less human, we kill our *own* h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409128907334352896",
    "text" : "It troubles me to see liberals &amp; conservatives demonizing each other. When we make the \"other\" less human, we kill our *own* humanity.",
    "id" : 409128907334352896,
    "created_at" : "2013-12-07 01:15:07 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 409135173536849920,
  "created_at" : "2013-12-07 01:40:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammy",
      "screen_name" : "TammyReasbeck",
      "indices" : [ 3, 17 ],
      "id_str" : "1654077776",
      "id" : 1654077776
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TammyReasbeck\/status\/409027468335394818\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nBSAJ0Eeq3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0oULRCAAArt4o.jpg",
      "id_str" : "409027468247302144",
      "id" : 409027468247302144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0oULRCAAArt4o.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nBSAJ0Eeq3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409124998990016512",
  "text" : "RT @TammyReasbeck: These animals are still bring tortured and killed for someone's coffee! Please be their voice too. http:\/\/t.co\/nBSAJ0Eeq3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TammyReasbeck\/status\/409027468335394818\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/nBSAJ0Eeq3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0oULRCAAArt4o.jpg",
        "id_str" : "409027468247302144",
        "id" : 409027468247302144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0oULRCAAArt4o.jpg",
        "sizes" : [ {
          "h" : 326,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/nBSAJ0Eeq3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409027468335394818",
    "text" : "These animals are still bring tortured and killed for someone's coffee! Please be their voice too. http:\/\/t.co\/nBSAJ0Eeq3",
    "id" : 409027468335394818,
    "created_at" : "2013-12-06 18:32:02 +0000",
    "user" : {
      "name" : "Tammy",
      "screen_name" : "TammyReasbeck",
      "protected" : false,
      "id_str" : "1654077776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795354803740221441\/xXIKa8ER_normal.jpg",
      "id" : 1654077776,
      "verified" : false
    }
  },
  "id" : 409124998990016512,
  "created_at" : "2013-12-07 00:59:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409122319584739328",
  "text" : "RT @ChrisCapparell: You're only lost if you don't want to be found.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409113852589400064",
    "text" : "You're only lost if you don't want to be found.",
    "id" : 409113852589400064,
    "created_at" : "2013-12-07 00:15:18 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 409122319584739328,
  "created_at" : "2013-12-07 00:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry malin",
      "screen_name" : "b4zzam",
      "indices" : [ 3, 10 ],
      "id_str" : "221517559",
      "id" : 221517559
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/b4zzam\/status\/409033692762210304\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/Fmp5DbMgbj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0t-faCAAAe5O0.jpg",
      "id_str" : "409033692766404608",
      "id" : 409033692766404608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0t-faCAAAe5O0.jpg",
      "sizes" : [ {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Fmp5DbMgbj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409122068371111936",
  "text" : "RT @b4zzam: Time to sleep: http:\/\/t.co\/Fmp5DbMgbj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/b4zzam\/status\/409033692762210304\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/Fmp5DbMgbj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0t-faCAAAe5O0.jpg",
        "id_str" : "409033692766404608",
        "id" : 409033692766404608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0t-faCAAAe5O0.jpg",
        "sizes" : [ {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Fmp5DbMgbj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409033692762210304",
    "text" : "Time to sleep: http:\/\/t.co\/Fmp5DbMgbj",
    "id" : 409033692762210304,
    "created_at" : "2013-12-06 18:56:46 +0000",
    "user" : {
      "name" : "barry malin",
      "screen_name" : "b4zzam",
      "protected" : false,
      "id_str" : "221517559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438008125455491072\/XkP_jbdD_normal.jpeg",
      "id" : 221517559,
      "verified" : false
    }
  },
  "id" : 409122068371111936,
  "created_at" : "2013-12-07 00:47:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/zPVTb4Lgme",
      "expanded_url" : "http:\/\/www.bizjournals.com\/seattle\/blog\/health-care-inc\/2013\/12\/colin-powell-calls-for-universal.html?ana=e_ptl_hc",
      "display_url" : "bizjournals.com\/seattle\/blog\/h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409121792687898624",
  "text" : "RT @AllOnMedicare: Colin Powell calls for Canadian, European-style health care in the USA: http:\/\/t.co\/zPVTb4Lgme #SinglePayer #MedicareFor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 95, 107 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 108, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/zPVTb4Lgme",
        "expanded_url" : "http:\/\/www.bizjournals.com\/seattle\/blog\/health-care-inc\/2013\/12\/colin-powell-calls-for-universal.html?ana=e_ptl_hc",
        "display_url" : "bizjournals.com\/seattle\/blog\/h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409116439660867586",
    "text" : "Colin Powell calls for Canadian, European-style health care in the USA: http:\/\/t.co\/zPVTb4Lgme #SinglePayer #MedicareForAll",
    "id" : 409116439660867586,
    "created_at" : "2013-12-07 00:25:34 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 409121792687898624,
  "created_at" : "2013-12-07 00:46:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This American Life",
      "screen_name" : "ThisAmerLife",
      "indices" : [ 10, 23 ],
      "id_str" : "149180925",
      "id" : 149180925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/o16KC6cKru",
      "expanded_url" : "http:\/\/tal.fm\/304",
      "display_url" : "tal.fm\/304"
    } ]
  },
  "geo" : { },
  "id_str" : "409080726403813376",
  "text" : "Check out @ThisAmerLife episode 304: 'Heretics.' http:\/\/t.co\/o16KC6cKru Story of Rev Carlton Pearson who cast aside idea of Hell.",
  "id" : 409080726403813376,
  "created_at" : "2013-12-06 22:03:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thepoliticalcat",
      "screen_name" : "thepoliticalcat",
      "indices" : [ 0, 16 ],
      "id_str" : "17686959",
      "id" : 17686959
    }, {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 17, 26 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408765914864054272",
  "geo" : { },
  "id_str" : "408767412788420608",
  "in_reply_to_user_id" : 17686959,
  "text" : "@thepoliticalcat @Adenovir double BAM!",
  "id" : 408767412788420608,
  "in_reply_to_status_id" : 408765914864054272,
  "created_at" : "2013-12-06 01:18:40 +0000",
  "in_reply_to_screen_name" : "thepoliticalcat",
  "in_reply_to_user_id_str" : "17686959",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408765752729018369",
  "geo" : { },
  "id_str" : "408766618362060800",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell is that red velvet cake?",
  "id" : 408766618362060800,
  "in_reply_to_status_id" : 408765752729018369,
  "created_at" : "2013-12-06 01:15:30 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408689863026692096",
  "geo" : { },
  "id_str" : "408691115018055680",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields hmm.. guess i'll have to re-join GR. dont care about the sharing, tho, its organization i want..lol",
  "id" : 408691115018055680,
  "in_reply_to_status_id" : 408689863026692096,
  "created_at" : "2013-12-05 20:15:29 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408684895305596929",
  "geo" : { },
  "id_str" : "408689789664108544",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH thats where im working.. deleting 1 at a time and it always returns to 1st page of books after each delete.. oy!",
  "id" : 408689789664108544,
  "in_reply_to_status_id" : 408684895305596929,
  "created_at" : "2013-12-05 20:10:13 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408685371182964737",
  "geo" : { },
  "id_str" : "408689429784436736",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields yes! i wonder if they have any plans to ever improve it.. sigh.",
  "id" : 408689429784436736,
  "in_reply_to_status_id" : 408685371182964737,
  "created_at" : "2013-12-05 20:08:47 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408685412849180672",
  "geo" : { },
  "id_str" : "408688992305950720",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time insanely hard to work with the archive. cant list all books in a row, bulk delete, cant delete archived books from kindle..",
  "id" : 408688992305950720,
  "in_reply_to_status_id" : 408685412849180672,
  "created_at" : "2013-12-05 20:07:03 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408685412849180672",
  "geo" : { },
  "id_str" : "408688565606834176",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time all your kindle books archive automatically. go to amazon, manage your kindle. lists books by pages (15\/page)",
  "id" : 408688565606834176,
  "in_reply_to_status_id" : 408685412849180672,
  "created_at" : "2013-12-05 20:05:21 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408684693731540992",
  "text" : "oh Amazon why can't I bulk delete my Kindle books? sigh. I really hate the library set up. I love my Kindle but not the archive.",
  "id" : 408684693731540992,
  "created_at" : "2013-12-05 19:49:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    }, {
      "name" : "Bushnell Nature",
      "screen_name" : "BushnellNature",
      "indices" : [ 86, 101 ],
      "id_str" : "1111698842",
      "id" : 1111698842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7EqglOFgb6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Kn6D6EgjOU4",
      "display_url" : "youtube.com\/watch?v=Kn6D6E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408672405612400640",
  "text" : "RT @WildlifeGadgets: Check out this marauding group of scary scavengers captured on a @BushnellNature trail cam https:\/\/t.co\/7EqglOFgb6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bushnell Nature",
        "screen_name" : "BushnellNature",
        "indices" : [ 65, 80 ],
        "id_str" : "1111698842",
        "id" : 1111698842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/7EqglOFgb6",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Kn6D6EgjOU4",
        "display_url" : "youtube.com\/watch?v=Kn6D6E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408670612777730048",
    "text" : "Check out this marauding group of scary scavengers captured on a @BushnellNature trail cam https:\/\/t.co\/7EqglOFgb6",
    "id" : 408670612777730048,
    "created_at" : "2013-12-05 18:54:01 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 408672405612400640,
  "created_at" : "2013-12-05 19:01:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408615728346980352",
  "geo" : { },
  "id_str" : "408616860918099968",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits yay! : )",
  "id" : 408616860918099968,
  "in_reply_to_status_id" : 408615728346980352,
  "created_at" : "2013-12-05 15:20:26 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Summer Anne Burton",
      "screen_name" : "summeranne",
      "indices" : [ 90, 101 ],
      "id_str" : "12618872",
      "id" : 12618872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/BCmwoJhuRq",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/summeranne\/real-life-fox-and-the-hound-best-friends-will-melt-your-hear",
      "display_url" : "buzzfeed.com\/summeranne\/rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408616042697465856",
  "text" : "Real Life Fox And The Hound Best Friends Will Melt Your Heart http:\/\/t.co\/BCmwoJhuRq  via @summeranne",
  "id" : 408616042697465856,
  "created_at" : "2013-12-05 15:17:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408323734777638912",
  "geo" : { },
  "id_str" : "408325600399462400",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hopefully he was unconscious and didnt know.. awful..",
  "id" : 408325600399462400,
  "in_reply_to_status_id" : 408323734777638912,
  "created_at" : "2013-12-04 20:03:04 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 3, 17 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/hyTRRLXMe7",
      "expanded_url" : "http:\/\/zite.to\/1cYnPNc",
      "display_url" : "zite.to\/1cYnPNc"
    } ]
  },
  "geo" : { },
  "id_str" : "408324346701430785",
  "text" : "RT @allthewayleft: Cops: 'Are You Aware Your Daughter Is With Two Black Men?' http:\/\/t.co\/hyTRRLXMe7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/hyTRRLXMe7",
        "expanded_url" : "http:\/\/zite.to\/1cYnPNc",
        "display_url" : "zite.to\/1cYnPNc"
      } ]
    },
    "geo" : { },
    "id_str" : "408321207025803264",
    "text" : "Cops: 'Are You Aware Your Daughter Is With Two Black Men?' http:\/\/t.co\/hyTRRLXMe7",
    "id" : 408321207025803264,
    "created_at" : "2013-12-04 19:45:36 +0000",
    "user" : {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "protected" : false,
      "id_str" : "345207173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000852111499\/8d917b25d9062fc1d0af08d0f98ccd71_normal.jpeg",
      "id" : 345207173,
      "verified" : false
    }
  },
  "id" : 408324346701430785,
  "created_at" : "2013-12-04 19:58:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia Borisova",
      "screen_name" : "Tashka73143500",
      "indices" : [ 3, 18 ],
      "id_str" : "889320270",
      "id" : 889320270
    }, {
      "name" : "speakASAP",
      "screen_name" : "speakASAP",
      "indices" : [ 20, 30 ],
      "id_str" : "464216910",
      "id" : 464216910
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Tashka73143500\/status\/406814105190662146\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/X9qpa2cuBh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVLRfXCAAAmedv.jpg",
      "id_str" : "406814105194856448",
      "id" : 406814105194856448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVLRfXCAAAmedv.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/X9qpa2cuBh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408322341643767808",
  "text" : "RT @Tashka73143500: @speakASAP \u0421\u043F\u0430\u0441\u0438\u0431\u043E!) \u0418 \u0412\u0430\u043C \u0443\u044E\u0442\u043D\u043E\u0433\u043E \u0432\u0435\u0447\u0435\u0440\u0430!)) http:\/\/t.co\/X9qpa2cuBh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "speakASAP",
        "screen_name" : "speakASAP",
        "indices" : [ 0, 10 ],
        "id_str" : "464216910",
        "id" : 464216910
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Tashka73143500\/status\/406814105190662146\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/X9qpa2cuBh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVLRfXCAAAmedv.jpg",
        "id_str" : "406814105194856448",
        "id" : 406814105194856448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVLRfXCAAAmedv.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1366
        } ],
        "display_url" : "pic.twitter.com\/X9qpa2cuBh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "406810745582534656",
    "geo" : { },
    "id_str" : "406814105190662146",
    "in_reply_to_user_id" : 464216910,
    "text" : "@speakASAP \u0421\u043F\u0430\u0441\u0438\u0431\u043E!) \u0418 \u0412\u0430\u043C \u0443\u044E\u0442\u043D\u043E\u0433\u043E \u0432\u0435\u0447\u0435\u0440\u0430!)) http:\/\/t.co\/X9qpa2cuBh",
    "id" : 406814105190662146,
    "in_reply_to_status_id" : 406810745582534656,
    "created_at" : "2013-11-30 15:56:55 +0000",
    "in_reply_to_screen_name" : "speakASAP",
    "in_reply_to_user_id_str" : "464216910",
    "user" : {
      "name" : "Natalia Borisova",
      "screen_name" : "Tashka73143500",
      "protected" : false,
      "id_str" : "889320270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780343090922065920\/psAHGZBb_normal.jpg",
      "id" : 889320270,
      "verified" : false
    }
  },
  "id" : 408322341643767808,
  "created_at" : "2013-12-04 19:50:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408302552262782976",
  "geo" : { },
  "id_str" : "408303125326340096",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft agreed",
  "id" : 408303125326340096,
  "in_reply_to_status_id" : 408302552262782976,
  "created_at" : "2013-12-04 18:33:45 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u043E\u0437\u0434\u043D\u0435\u0432a \u041E\u043B\u044C\u0433\u0430",
      "screen_name" : "WarCosts",
      "indices" : [ 3, 12 ],
      "id_str" : "2814081530",
      "id" : 2814081530
    }, {
      "name" : "The Young Turks",
      "screen_name" : "TheYoungTurks",
      "indices" : [ 112, 126 ],
      "id_str" : "14957147",
      "id" : 14957147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WarCosts",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408298364707823616",
  "text" : "RT @WarCosts: The Pentagon spends $11 billion per week. Meanwhile, 1 in 6 Americans go hungry... #WarCosts (via @TheYoungTurks) http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Young Turks",
        "screen_name" : "TheYoungTurks",
        "indices" : [ 98, 112 ],
        "id_str" : "14957147",
        "id" : 14957147
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WarCosts",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/8HFw3UFPtu",
        "expanded_url" : "http:\/\/bit.ly\/189RkOH",
        "display_url" : "bit.ly\/189RkOH"
      } ]
    },
    "geo" : { },
    "id_str" : "408285881754476544",
    "text" : "The Pentagon spends $11 billion per week. Meanwhile, 1 in 6 Americans go hungry... #WarCosts (via @TheYoungTurks) http:\/\/t.co\/8HFw3UFPtu",
    "id" : 408285881754476544,
    "created_at" : "2013-12-04 17:25:14 +0000",
    "user" : {
      "name" : "BNF Security",
      "screen_name" : "BNFWarCosts",
      "protected" : false,
      "id_str" : "22809627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509814411104489472\/UXSwXYwO_normal.jpeg",
      "id" : 22809627,
      "verified" : false
    }
  },
  "id" : 408298364707823616,
  "created_at" : "2013-12-04 18:14:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408279240526688256",
  "geo" : { },
  "id_str" : "408281434260905984",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos better to let it out than let it fester. ((hugs)) keep moving forward.",
  "id" : 408281434260905984,
  "in_reply_to_status_id" : 408279240526688256,
  "created_at" : "2013-12-04 17:07:34 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408280902868156417",
  "text" : "RT @WHLive: President Obama: \"The idea that so many children are born into poverty in the wealthiest nation on Earth is heartbreaking.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408276039182192641",
    "text" : "President Obama: \"The idea that so many children are born into poverty in the wealthiest nation on Earth is heartbreaking.\"",
    "id" : 408276039182192641,
    "created_at" : "2013-12-04 16:46:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408280902868156417,
  "created_at" : "2013-12-04 17:05:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408280507441774592",
  "text" : "RT @Wolf_Mommy: \"Get a room\" implies a sexual act is being commuted in public. Breastfeeding is the act of feeding a baby. It's food, NOT s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Toad Taint",
        "screen_name" : "WildCard306",
        "indices" : [ 127, 139 ],
        "id_str" : "446634472",
        "id" : 446634472
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "408273594053959681",
    "geo" : { },
    "id_str" : "408280349828186112",
    "in_reply_to_user_id" : 446634472,
    "text" : "\"Get a room\" implies a sexual act is being commuted in public. Breastfeeding is the act of feeding a baby. It's food, NOT sex. @WildCard306",
    "id" : 408280349828186112,
    "in_reply_to_status_id" : 408273594053959681,
    "created_at" : "2013-12-04 17:03:15 +0000",
    "in_reply_to_screen_name" : "WildCard306",
    "in_reply_to_user_id_str" : "446634472",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 408280507441774592,
  "created_at" : "2013-12-04 17:03:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408275925017448448",
  "geo" : { },
  "id_str" : "408278818881667073",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater omg.. i love it! lol",
  "id" : 408278818881667073,
  "in_reply_to_status_id" : 408275925017448448,
  "created_at" : "2013-12-04 16:57:10 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    }, {
      "name" : "Rachel Maddow MSNBC",
      "screen_name" : "maddow",
      "indices" : [ 122, 129 ],
      "id_str" : "16129920",
      "id" : 16129920
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0JDzMjH5KT",
      "expanded_url" : "http:\/\/on.msnbc.com\/IDYsqD",
      "display_url" : "on.msnbc.com\/IDYsqD"
    } ]
  },
  "geo" : { },
  "id_str" : "408266546373754881",
  "text" : "RT @Adenovir: Calif. GOP creates fake #ACA website to confuse people. Isn't this sh*t illegal? http:\/\/t.co\/0JDzMjH5KT via @maddow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachel Maddow MSNBC",
        "screen_name" : "maddow",
        "indices" : [ 108, 115 ],
        "id_str" : "16129920",
        "id" : 16129920
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 24, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/0JDzMjH5KT",
        "expanded_url" : "http:\/\/on.msnbc.com\/IDYsqD",
        "display_url" : "on.msnbc.com\/IDYsqD"
      } ]
    },
    "geo" : { },
    "id_str" : "408260413789200384",
    "text" : "Calif. GOP creates fake #ACA website to confuse people. Isn't this sh*t illegal? http:\/\/t.co\/0JDzMjH5KT via @maddow",
    "id" : 408260413789200384,
    "created_at" : "2013-12-04 15:44:02 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 408266546373754881,
  "created_at" : "2013-12-04 16:08:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Flagg",
      "screen_name" : "JessieFlagg1",
      "indices" : [ 3, 16 ],
      "id_str" : "560326682",
      "id" : 560326682
    }, {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 18, 32 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408266475162845184",
  "text" : "RT @JessieFlagg1: @AllOnMedicare That is THE most truthful statement 1 could possibly make re Insurers. Insurance is a financial service in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 0, 14 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "408250848028803072",
    "geo" : { },
    "id_str" : "408252632793231360",
    "in_reply_to_user_id" : 1067293117,
    "text" : "@AllOnMedicare That is THE most truthful statement 1 could possibly make re Insurers. Insurance is a financial service industry NOT HC!",
    "id" : 408252632793231360,
    "in_reply_to_status_id" : 408250848028803072,
    "created_at" : "2013-12-04 15:13:07 +0000",
    "in_reply_to_screen_name" : "AllOnMedicare",
    "in_reply_to_user_id_str" : "1067293117",
    "user" : {
      "name" : "Jessie Flagg",
      "screen_name" : "JessieFlagg1",
      "protected" : false,
      "id_str" : "560326682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454237352466993153\/PeyFzhfM_normal.jpeg",
      "id" : 560326682,
      "verified" : false
    }
  },
  "id" : 408266475162845184,
  "created_at" : "2013-12-04 16:08:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "indices" : [ 3, 16 ],
      "id_str" : "21611239",
      "id" : 21611239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/hW6HYKBAS2",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/cocktail-party-physics\/2013\/12\/04\/bakers-dozen-best-2013-books-for-the-physics-fan\/",
      "display_url" : "blogs.scientificamerican.com\/cocktail-party\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408266365951545344",
  "text" : "RT @seanmcarroll: Xmas shoppers: plenty of good physics books came out this year. Just saying. http:\/\/t.co\/hW6HYKBAS2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/hW6HYKBAS2",
        "expanded_url" : "http:\/\/blogs.scientificamerican.com\/cocktail-party-physics\/2013\/12\/04\/bakers-dozen-best-2013-books-for-the-physics-fan\/",
        "display_url" : "blogs.scientificamerican.com\/cocktail-party\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408260881626050560",
    "text" : "Xmas shoppers: plenty of good physics books came out this year. Just saying. http:\/\/t.co\/hW6HYKBAS2",
    "id" : 408260881626050560,
    "created_at" : "2013-12-04 15:45:53 +0000",
    "user" : {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "protected" : false,
      "id_str" : "21611239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554901773467406337\/emLyWwmt_normal.jpeg",
      "id" : 21611239,
      "verified" : true
    }
  },
  "id" : 408266365951545344,
  "created_at" : "2013-12-04 16:07:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Packard Sonic",
      "screen_name" : "Packard_Sonic",
      "indices" : [ 3, 17 ],
      "id_str" : "14374797",
      "id" : 14374797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/8tD3QAUVuq",
      "expanded_url" : "http:\/\/youtu.be\/ZllaNieVetw",
      "display_url" : "youtu.be\/ZllaNieVetw"
    } ]
  },
  "geo" : { },
  "id_str" : "408265963931717632",
  "text" : "RT @Packard_Sonic: God, Bible Prove Climate Change A Hoax (Say GOP Reps): http:\/\/t.co\/8tD3QAUVuq &lt; So Gawd is why we can't have nice things\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BibleAlsoSays",
        "screen_name" : "BibleAlsoSays",
        "indices" : [ 125, 139 ],
        "id_str" : "2511428924",
        "id" : 2511428924
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/8tD3QAUVuq",
        "expanded_url" : "http:\/\/youtu.be\/ZllaNieVetw",
        "display_url" : "youtu.be\/ZllaNieVetw"
      } ]
    },
    "geo" : { },
    "id_str" : "408247194689343491",
    "text" : "God, Bible Prove Climate Change A Hoax (Say GOP Reps): http:\/\/t.co\/8tD3QAUVuq &lt; So Gawd is why we can't have nice things? @BibleAlsoSays",
    "id" : 408247194689343491,
    "created_at" : "2013-12-04 14:51:30 +0000",
    "user" : {
      "name" : "Packard Sonic",
      "screen_name" : "Packard_Sonic",
      "protected" : false,
      "id_str" : "14374797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411651489\/2a3318900483bc0bb590ac17c7d0f063_normal.jpeg",
      "id" : 14374797,
      "verified" : false
    }
  },
  "id" : 408265963931717632,
  "created_at" : "2013-12-04 16:06:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408261929359396865",
  "text" : "RT @dhammagirl: You're unable to change people, you can only do your best to influence. Minimize suffering by changing the way you react\/re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408257537654685696",
    "text" : "You're unable to change people, you can only do your best to influence. Minimize suffering by changing the way you react\/respond to them.",
    "id" : 408257537654685696,
    "created_at" : "2013-12-04 15:32:36 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 408261929359396865,
  "created_at" : "2013-12-04 15:50:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2BirdBrainz",
      "screen_name" : "2BirdBrainz",
      "indices" : [ 3, 15 ],
      "id_str" : "1416237422",
      "id" : 1416237422
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/2BirdBrainz\/status\/406847276967936000\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/YCAmtnirkT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVpcVeCcAAn1EZ.jpg",
      "id_str" : "406847276867284992",
      "id" : 406847276867284992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVpcVeCcAAn1EZ.jpg",
      "sizes" : [ {
        "h" : 969,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 969,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YCAmtnirkT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408261533157048320",
  "text" : "RT @2BirdBrainz: may you find the light \n   in your day...\n (redpoll)- http:\/\/t.co\/YCAmtnirkT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/2BirdBrainz\/status\/406847276967936000\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/YCAmtnirkT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVpcVeCcAAn1EZ.jpg",
        "id_str" : "406847276867284992",
        "id" : 406847276867284992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVpcVeCcAAn1EZ.jpg",
        "sizes" : [ {
          "h" : 969,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 969,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YCAmtnirkT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406847276967936000",
    "text" : "may you find the light \n   in your day...\n (redpoll)- http:\/\/t.co\/YCAmtnirkT",
    "id" : 406847276967936000,
    "created_at" : "2013-11-30 18:08:44 +0000",
    "user" : {
      "name" : "2BirdBrainz",
      "screen_name" : "2BirdBrainz",
      "protected" : false,
      "id_str" : "1416237422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731000663824420869\/8i9ZwLgb_normal.jpg",
      "id" : 1416237422,
      "verified" : false
    }
  },
  "id" : 408261533157048320,
  "created_at" : "2013-12-04 15:48:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408259014217449472",
  "geo" : { },
  "id_str" : "408261447592857601",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH aww.. lol",
  "id" : 408261447592857601,
  "in_reply_to_status_id" : 408259014217449472,
  "created_at" : "2013-12-04 15:48:08 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408260260051169280",
  "geo" : { },
  "id_str" : "408260939335483392",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem walker wasnt driving and car was going about 45 mph. car was giving trouble right before drive.",
  "id" : 408260939335483392,
  "in_reply_to_status_id" : 408260260051169280,
  "created_at" : "2013-12-04 15:46:07 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "How2Guide",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408256556242059264",
  "text" : "RT @WildlifeGadgets: Just finished my hanging fat snack feeder for garden birds using an old piece of guttering. #How2Guide on the way. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/408248332188794880\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kLay7yoYXs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BapjsfTCQAAboXA.jpg",
        "id_str" : "408248332197183488",
        "id" : 408248332197183488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BapjsfTCQAAboXA.jpg",
        "sizes" : [ {
          "h" : 1081,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kLay7yoYXs"
      } ],
      "hashtags" : [ {
        "text" : "How2Guide",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408248332188794880",
    "text" : "Just finished my hanging fat snack feeder for garden birds using an old piece of guttering. #How2Guide on the way. http:\/\/t.co\/kLay7yoYXs",
    "id" : 408248332188794880,
    "created_at" : "2013-12-04 14:56:02 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 408256556242059264,
  "created_at" : "2013-12-04 15:28:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amreading",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/1nlrjiqFK9",
      "expanded_url" : "http:\/\/AdvanceReadingCopy.Wordpress.com",
      "display_url" : "AdvanceReadingCopy.Wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "408254259655106560",
  "text" : "RT @JAScribbles: Authors- plug your book here. Free. http:\/\/t.co\/1nlrjiqFK9 #amreading",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amreading",
        "indices" : [ 59, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/1nlrjiqFK9",
        "expanded_url" : "http:\/\/AdvanceReadingCopy.Wordpress.com",
        "display_url" : "AdvanceReadingCopy.Wordpress.com"
      } ]
    },
    "in_reply_to_status_id_str" : "407602683043119105",
    "geo" : { },
    "id_str" : "408250643984678912",
    "in_reply_to_user_id" : 143654638,
    "text" : "Authors- plug your book here. Free. http:\/\/t.co\/1nlrjiqFK9 #amreading",
    "id" : 408250643984678912,
    "in_reply_to_status_id" : 407602683043119105,
    "created_at" : "2013-12-04 15:05:13 +0000",
    "in_reply_to_screen_name" : "JAScribbles",
    "in_reply_to_user_id_str" : "143654638",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 408254259655106560,
  "created_at" : "2013-12-04 15:19:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    }, {
      "name" : "All Things CrimeBlog",
      "screen_name" : "PatrickHMoore1",
      "indices" : [ 123, 138 ],
      "id_str" : "1275662162",
      "id" : 1275662162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/h9gZpJ4URE",
      "expanded_url" : "http:\/\/www.allthingscrimeblog.com\/2013\/12\/03\/prisoner-in-agony-escapes-from-jail-to-see-dentist-then-turns-himself-back-in\/",
      "display_url" : "allthingscrimeblog.com\/2013\/12\/03\/pri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408254062707343361",
  "text" : "RT @DarciaHelle: Prisoner in Agony Escapes from Jail to See Dentist, Then Turns Himself Back In http:\/\/t.co\/h9gZpJ4URE via @PatrickHMoore1 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All Things CrimeBlog",
        "screen_name" : "PatrickHMoore1",
        "indices" : [ 106, 121 ],
        "id_str" : "1275662162",
        "id" : 1275662162
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Crime",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/h9gZpJ4URE",
        "expanded_url" : "http:\/\/www.allthingscrimeblog.com\/2013\/12\/03\/prisoner-in-agony-escapes-from-jail-to-see-dentist-then-turns-himself-back-in\/",
        "display_url" : "allthingscrimeblog.com\/2013\/12\/03\/pri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408250931734519808",
    "text" : "Prisoner in Agony Escapes from Jail to See Dentist, Then Turns Himself Back In http:\/\/t.co\/h9gZpJ4URE via @PatrickHMoore1  #Crime",
    "id" : 408250931734519808,
    "created_at" : "2013-12-04 15:06:21 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 408254062707343361,
  "created_at" : "2013-12-04 15:18:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 0, 16 ],
      "id_str" : "116009507",
      "id" : 116009507
    }, {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "indices" : [ 91, 105 ],
      "id_str" : "313091751",
      "id" : 313091751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408063192540012545",
  "geo" : { },
  "id_str" : "408252698467655680",
  "in_reply_to_user_id" : 116009507,
  "text" : "@ChristnNitemare hope you dont mind.. doing a happy dance. not too often im right..lol : ) @fakedansavage",
  "id" : 408252698467655680,
  "in_reply_to_status_id" : 408063192540012545,
  "created_at" : "2013-12-04 15:13:22 +0000",
  "in_reply_to_screen_name" : "ChristnNitemare",
  "in_reply_to_user_id_str" : "116009507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Gilbert",
      "screen_name" : "rachlgil",
      "indices" : [ 3, 12 ],
      "id_str" : "1491459638",
      "id" : 1491459638
    }, {
      "name" : "Kirk Wellum",
      "screen_name" : "kwellum",
      "indices" : [ 15, 23 ],
      "id_str" : "26013091",
      "id" : 26013091
    }, {
      "name" : "barry malin",
      "screen_name" : "b4zzam",
      "indices" : [ 69, 76 ],
      "id_str" : "221517559",
      "id" : 221517559
    }, {
      "name" : "CB",
      "screen_name" : "CBonehannon",
      "indices" : [ 119, 131 ],
      "id_str" : "1697605788",
      "id" : 1697605788
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/b4zzam\/status\/406494475507073024\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/I7XBotMyWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaQokmACAAEr57Q.jpg",
      "id_str" : "406494475511267329",
      "id" : 406494475511267329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaQokmACAAEr57Q.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I7XBotMyWF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408037391493255168",
  "text" : "RT @rachlgil: \"@kwellum: A stillness you can feel in your soul... RT @b4zzam: Moon reflection: http:\/\/t.co\/I7XBotMyWF\" @CBonehannon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirk Wellum",
        "screen_name" : "kwellum",
        "indices" : [ 1, 9 ],
        "id_str" : "26013091",
        "id" : 26013091
      }, {
        "name" : "barry malin",
        "screen_name" : "b4zzam",
        "indices" : [ 55, 62 ],
        "id_str" : "221517559",
        "id" : 221517559
      }, {
        "name" : "CB",
        "screen_name" : "CBonehannon",
        "indices" : [ 105, 117 ],
        "id_str" : "1697605788",
        "id" : 1697605788
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/b4zzam\/status\/406494475507073024\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/I7XBotMyWF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaQokmACAAEr57Q.jpg",
        "id_str" : "406494475511267329",
        "id" : 406494475511267329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaQokmACAAEr57Q.jpg",
        "sizes" : [ {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I7XBotMyWF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407230523942375424",
    "text" : "\"@kwellum: A stillness you can feel in your soul... RT @b4zzam: Moon reflection: http:\/\/t.co\/I7XBotMyWF\" @CBonehannon",
    "id" : 407230523942375424,
    "created_at" : "2013-12-01 19:31:37 +0000",
    "user" : {
      "name" : "Rachel Gilbert",
      "screen_name" : "rachlgil",
      "protected" : false,
      "id_str" : "1491459638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800832785393053696\/1qdeLh6Q_normal.jpg",
      "id" : 1491459638,
      "verified" : false
    }
  },
  "id" : 408037391493255168,
  "created_at" : "2013-12-04 00:57:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 0, 16 ],
      "id_str" : "116009507",
      "id" : 116009507
    }, {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "indices" : [ 92, 106 ],
      "id_str" : "313091751",
      "id" : 313091751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408013024750870528",
  "geo" : { },
  "id_str" : "408017148104028160",
  "in_reply_to_user_id" : 116009507,
  "text" : "@ChristnNitemare im confused.. went to their website. they're progressive from what i see.. @fakedansavage",
  "id" : 408017148104028160,
  "in_reply_to_status_id" : 408013024750870528,
  "created_at" : "2013-12-03 23:37:23 +0000",
  "in_reply_to_screen_name" : "ChristnNitemare",
  "in_reply_to_user_id_str" : "116009507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 127, 136 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/MLgF7eTSrB",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/12\/02\/1259641\/-California-GOP-creates-fake-healthcare-website-to-discourage-constituents-from-obtaining-insurance",
      "display_url" : "dailykos.com\/story\/2013\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408005906563989504",
  "text" : "California GOP creates fake health care website to discourage constituents from obtaining insurance http:\/\/t.co\/MLgF7eTSrB via @dailykos",
  "id" : 408005906563989504,
  "created_at" : "2013-12-03 22:52:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iyanla Vanzant",
      "screen_name" : "IyanlaVanzant",
      "indices" : [ 3, 17 ],
      "id_str" : "27368199",
      "id" : 27368199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407975538142490624",
  "text" : "RT @IyanlaVanzant: If you are in a relationship that causes you anguish, get out. We come together in relationships to grow, not to live in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407887002823299072",
    "text" : "If you are in a relationship that causes you anguish, get out. We come together in relationships to grow, not to live in misery.",
    "id" : 407887002823299072,
    "created_at" : "2013-12-03 15:00:14 +0000",
    "user" : {
      "name" : "Iyanla Vanzant",
      "screen_name" : "IyanlaVanzant",
      "protected" : false,
      "id_str" : "27368199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646789722056974336\/wMGXxCgl_normal.png",
      "id" : 27368199,
      "verified" : true
    }
  },
  "id" : 407975538142490624,
  "created_at" : "2013-12-03 20:52:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407971883179454464",
  "geo" : { },
  "id_str" : "407975439898910720",
  "in_reply_to_user_id" : 18694547,
  "text" : "@fetusb0y damn.. that's awesome : ) I'm over 40 and STILL don't know what I want to do.. o-O",
  "id" : 407975439898910720,
  "in_reply_to_status_id" : 407971883179454464,
  "created_at" : "2013-12-03 20:51:39 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407690979035340800",
  "geo" : { },
  "id_str" : "407972562119823360",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 he is more active today.. not quite normal yet. thanks for thoughts. amazing how quickly i get attached to the fish. : )",
  "id" : 407972562119823360,
  "in_reply_to_status_id" : 407690979035340800,
  "created_at" : "2013-12-03 20:40:13 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407957292358045697",
  "geo" : { },
  "id_str" : "407972120929398784",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles just saying, i love it when i have something for him.. like leftover steak or chicken and he digs in. then cleans himself..lol.",
  "id" : 407972120929398784,
  "in_reply_to_status_id" : 407957292358045697,
  "created_at" : "2013-12-03 20:38:28 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407956597516685312",
  "text" : "i especially love when i see my stray cat waiting and i have something really good just for him. i love that cat.",
  "id" : 407956597516685312,
  "created_at" : "2013-12-03 19:36:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407956134595555328",
  "text" : "i love watching our birds at the feeder or on the ground.. their sweet chirps.. watching the squirrels romp.",
  "id" : 407956134595555328,
  "created_at" : "2013-12-03 19:34:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407955898208768000",
  "text" : "feeding our local wildlife is my addiction. i feel bad when we run out of cat food or have no left overs.",
  "id" : 407955898208768000,
  "created_at" : "2013-12-03 19:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/i1BcDWJ1lM",
      "expanded_url" : "http:\/\/bookwi.se\/refurbished-kindle-paperwhite-for-99\/",
      "display_url" : "bookwi.se\/refurbished-ki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407955418066223104",
  "text" : "RT @adamrshields: Refurbished Kindle Paperwhite for $90 (or $104 from Amazon) http:\/\/t.co\/i1BcDWJ1lM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/i1BcDWJ1lM",
        "expanded_url" : "http:\/\/bookwi.se\/refurbished-kindle-paperwhite-for-99\/",
        "display_url" : "bookwi.se\/refurbished-ki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407954934248640512",
    "text" : "Refurbished Kindle Paperwhite for $90 (or $104 from Amazon) http:\/\/t.co\/i1BcDWJ1lM",
    "id" : 407954934248640512,
    "created_at" : "2013-12-03 19:30:10 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 407955418066223104,
  "created_at" : "2013-12-03 19:32:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yyHG6TuMbg",
      "expanded_url" : "http:\/\/www.mlive.com\/news\/jackson\/index.ssf\/2013\/12\/jackson_police_officials_say_t.html",
      "display_url" : "mlive.com\/news\/jackson\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407953551936081920",
  "text" : "Jackson police officials say they'll allow possession of marijuana on private property after public vote http:\/\/t.co\/yyHG6TuMbg",
  "id" : 407953551936081920,
  "created_at" : "2013-12-03 19:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Life",
      "screen_name" : "AnimaILife",
      "indices" : [ 3, 14 ],
      "id_str" : "989429790",
      "id" : 989429790
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AnimaILife\/status\/405954727302930432\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/zPgzSzQeqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaI9rG1IIAEK006.jpg",
      "id_str" : "405954727193878529",
      "id" : 405954727193878529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaI9rG1IIAEK006.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/zPgzSzQeqE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407949486322098176",
  "text" : "RT @AnimaILife: Horses \"hoof bumping\" in a field http:\/\/t.co\/zPgzSzQeqE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnimaILife\/status\/405954727302930432\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/zPgzSzQeqE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaI9rG1IIAEK006.jpg",
        "id_str" : "405954727193878529",
        "id" : 405954727193878529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaI9rG1IIAEK006.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/zPgzSzQeqE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405954727302930432",
    "text" : "Horses \"hoof bumping\" in a field http:\/\/t.co\/zPgzSzQeqE",
    "id" : 405954727302930432,
    "created_at" : "2013-11-28 07:02:03 +0000",
    "user" : {
      "name" : "Animal Life",
      "screen_name" : "AnimaILife",
      "protected" : false,
      "id_str" : "989429790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726456356643983360\/zL91NlRf_normal.jpg",
      "id" : 989429790,
      "verified" : false
    }
  },
  "id" : 407949486322098176,
  "created_at" : "2013-12-03 19:08:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407948516166606848",
  "text" : "@Lluminous_ i think i need another cup of coffee to ponder that just yet..lol",
  "id" : 407948516166606848,
  "created_at" : "2013-12-03 19:04:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407934624761782272",
  "geo" : { },
  "id_str" : "407947960136114176",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible you ask a lot of great questions. : )",
  "id" : 407947960136114176,
  "in_reply_to_status_id" : 407934624761782272,
  "created_at" : "2013-12-03 19:02:27 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407939711328452608",
  "geo" : { },
  "id_str" : "407941063198789632",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 just got in and read yr tweets.. im so glad he was good to the kids. it will help them later on as adults.",
  "id" : 407941063198789632,
  "in_reply_to_status_id" : 407939711328452608,
  "created_at" : "2013-12-03 18:35:03 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407660403661873152",
  "text" : "somethings not right w our biggest goldfish. sluggish. just spending time in one spot. ugh. i hope hes not dying.",
  "id" : 407660403661873152,
  "created_at" : "2013-12-02 23:59:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "indices" : [ 3, 17 ],
      "id_str" : "195173057",
      "id" : 195173057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotElan",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407568189740945408",
  "text" : "RT @lindapoitevin: Take a moment. Read this. Then pass it on. #NotElan (or The Importance of Compassion) | refashionista http:\/\/t.co\/kQfhYj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NotElan",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/kQfhYjTBIP",
        "expanded_url" : "http:\/\/buff.ly\/IB9FIx",
        "display_url" : "buff.ly\/IB9FIx"
      } ]
    },
    "geo" : { },
    "id_str" : "407563076243046401",
    "text" : "Take a moment. Read this. Then pass it on. #NotElan (or The Importance of Compassion) | refashionista http:\/\/t.co\/kQfhYjTBIP",
    "id" : 407563076243046401,
    "created_at" : "2013-12-02 17:33:04 +0000",
    "user" : {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "protected" : false,
      "id_str" : "195173057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653593067958571008\/PyqlHnTV_normal.jpg",
      "id" : 195173057,
      "verified" : false
    }
  },
  "id" : 407568189740945408,
  "created_at" : "2013-12-02 17:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fhromhehre",
      "screen_name" : "Zou_Ji",
      "indices" : [ 3, 10 ],
      "id_str" : "2184668095",
      "id" : 2184668095
    }, {
      "name" : "Maggie",
      "screen_name" : "Couragetob",
      "indices" : [ 15, 26 ],
      "id_str" : "332344331",
      "id" : 332344331
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Couragetob\/status\/398114925471465473\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/CiHkOi4eP8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZjalHCQAAxtg5.jpg",
      "id_str" : "398114925358235648",
      "id" : 398114925358235648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZjalHCQAAxtg5.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CiHkOi4eP8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407545533528813568",
  "text" : "RT @Zou_Ji: RT @Couragetob Wishing you all a Blessed Wednesday. http:\/\/t.co\/CiHkOi4eP8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maggie",
        "screen_name" : "Couragetob",
        "indices" : [ 3, 14 ],
        "id_str" : "332344331",
        "id" : 332344331
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Couragetob\/status\/398114925471465473\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/CiHkOi4eP8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZjalHCQAAxtg5.jpg",
        "id_str" : "398114925358235648",
        "id" : 398114925358235648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZjalHCQAAxtg5.jpg",
        "sizes" : [ {
          "h" : 424,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CiHkOi4eP8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407315345561485312",
    "text" : "RT @Couragetob Wishing you all a Blessed Wednesday. http:\/\/t.co\/CiHkOi4eP8",
    "id" : 407315345561485312,
    "created_at" : "2013-12-02 01:08:40 +0000",
    "user" : {
      "name" : "Fhromhehre",
      "screen_name" : "Zou_Ji",
      "protected" : false,
      "id_str" : "2184668095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000716798634\/12bdbe43890bb0b272a0b5a1cd3116c1_normal.jpeg",
      "id" : 2184668095,
      "verified" : false
    }
  },
  "id" : 407545533528813568,
  "created_at" : "2013-12-02 16:23:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 3, 16 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7XFzv4RLbd",
      "expanded_url" : "http:\/\/www.wrongingrights.com\/2013\/01\/what-if-we-responded-to-sexual-assault-by-limiting-mens-freedom-like-we-limit-womens.html",
      "display_url" : "wrongingrights.com\/2013\/01\/what-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407544976936304641",
  "text" : "RT @TorontoLydia: What If We Responded to Sexual Assault by Limiting Men\u2019s Freedom Like We Limit Women\u2019s? - http:\/\/t.co\/7XFzv4RLbd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/7XFzv4RLbd",
        "expanded_url" : "http:\/\/www.wrongingrights.com\/2013\/01\/what-if-we-responded-to-sexual-assault-by-limiting-mens-freedom-like-we-limit-womens.html",
        "display_url" : "wrongingrights.com\/2013\/01\/what-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407543429204148224",
    "text" : "What If We Responded to Sexual Assault by Limiting Men\u2019s Freedom Like We Limit Women\u2019s? - http:\/\/t.co\/7XFzv4RLbd",
    "id" : 407543429204148224,
    "created_at" : "2013-12-02 16:14:59 +0000",
    "user" : {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "protected" : false,
      "id_str" : "17068546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2110881642\/LydiaTea_normal",
      "id" : 17068546,
      "verified" : false
    }
  },
  "id" : 407544976936304641,
  "created_at" : "2013-12-02 16:21:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407544321139691520",
  "text" : "its 2013.. why do we still have trains on tracks? they should be running above tracks and automated by now.",
  "id" : 407544321139691520,
  "created_at" : "2013-12-02 16:18:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 0, 13 ],
      "id_str" : "926185416",
      "id" : 926185416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407513204319723520",
  "geo" : { },
  "id_str" : "407514309611102208",
  "in_reply_to_user_id" : 926185416,
  "text" : "@hoosierworld LOL",
  "id" : 407514309611102208,
  "in_reply_to_status_id" : 407513204319723520,
  "created_at" : "2013-12-02 14:19:17 +0000",
  "in_reply_to_screen_name" : "hoosierworld",
  "in_reply_to_user_id_str" : "926185416",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Maytag",
      "screen_name" : "cpm5280",
      "indices" : [ 0, 8 ],
      "id_str" : "17947700",
      "id" : 17947700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407512721840537601",
  "geo" : { },
  "id_str" : "407514068753215489",
  "in_reply_to_user_id" : 17947700,
  "text" : "@cpm5280 he's serious about working hard to throw less fortunate ppl under the bus. that man has no compassion.",
  "id" : 407514068753215489,
  "in_reply_to_status_id" : 407512721840537601,
  "created_at" : "2013-12-02 14:18:19 +0000",
  "in_reply_to_screen_name" : "cpm5280",
  "in_reply_to_user_id_str" : "17947700",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "GOP",
      "screen_name" : "GOP",
      "indices" : [ 77, 81 ],
      "id_str" : "11134252",
      "id" : 11134252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 47, 59 ]
    }, {
      "text" : "Medicare",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407513414094053377",
  "text" : "RT @AllOnMedicare: America already has a great #SinglePayer system that even @GOP loves, it's called #Medicare. #MedicareForAll would save \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GOP",
        "screen_name" : "GOP",
        "indices" : [ 58, 62 ],
        "id_str" : "11134252",
        "id" : 11134252
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 28, 40 ]
      }, {
        "text" : "Medicare",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 93, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407512627166711808",
    "text" : "America already has a great #SinglePayer system that even @GOP loves, it's called #Medicare. #MedicareForAll would save $1.8 Trillion\/10yrs!",
    "id" : 407512627166711808,
    "created_at" : "2013-12-02 14:12:36 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 407513414094053377,
  "created_at" : "2013-12-02 14:15:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/407278233504067584\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/tY3VmZcDlC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BabxZUGCMAAaRsu.jpg",
      "id_str" : "407278233516650496",
      "id" : 407278233516650496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BabxZUGCMAAaRsu.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/tY3VmZcDlC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407279770180005888",
  "text" : "RT @AWrobley: I didn't realize a crow in a puddle could be so cute! ;o)) http:\/\/t.co\/tY3VmZcDlC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/407278233504067584\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/tY3VmZcDlC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BabxZUGCMAAaRsu.jpg",
        "id_str" : "407278233516650496",
        "id" : 407278233516650496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BabxZUGCMAAaRsu.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/tY3VmZcDlC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407278233504067584",
    "text" : "I didn't realize a crow in a puddle could be so cute! ;o)) http:\/\/t.co\/tY3VmZcDlC",
    "id" : 407278233504067584,
    "created_at" : "2013-12-01 22:41:12 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 407279770180005888,
  "created_at" : "2013-12-01 22:47:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Yamamoto",
      "screen_name" : "MadameRamotswe",
      "indices" : [ 3, 18 ],
      "id_str" : "34234990",
      "id" : 34234990
    }, {
      "name" : "Si\u00E2n Is Me",
      "screen_name" : "Lynsm7",
      "indices" : [ 23, 30 ],
      "id_str" : "256925813",
      "id" : 256925813
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lynsm7\/status\/407206681681330176\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/SGFdthun8j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaawUcLIEAAefLz.jpg",
      "id_str" : "407206681530339328",
      "id" : 407206681530339328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaawUcLIEAAefLz.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/SGFdthun8j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407247685734113280",
  "text" : "RT @MadameRamotswe: RT @Lynsm7: And the giant cat said.... \"Behold... I have made myself at home\" http:\/\/t.co\/SGFdthun8j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Si\u00E2n Is Me",
        "screen_name" : "Lynsm7",
        "indices" : [ 3, 10 ],
        "id_str" : "256925813",
        "id" : 256925813
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lynsm7\/status\/407206681681330176\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/SGFdthun8j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaawUcLIEAAefLz.jpg",
        "id_str" : "407206681530339328",
        "id" : 407206681530339328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaawUcLIEAAefLz.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/SGFdthun8j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407233710514130944",
    "text" : "RT @Lynsm7: And the giant cat said.... \"Behold... I have made myself at home\" http:\/\/t.co\/SGFdthun8j",
    "id" : 407233710514130944,
    "created_at" : "2013-12-01 19:44:17 +0000",
    "user" : {
      "name" : "Michelle Yamamoto",
      "screen_name" : "MadameRamotswe",
      "protected" : false,
      "id_str" : "34234990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538239050574856193\/JjHlcFss_normal.jpeg",
      "id" : 34234990,
      "verified" : false
    }
  },
  "id" : 407247685734113280,
  "created_at" : "2013-12-01 20:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407202851622907905",
  "geo" : { },
  "id_str" : "407203600234848256",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid crows are awesome : )",
  "id" : 407203600234848256,
  "in_reply_to_status_id" : 407202851622907905,
  "created_at" : "2013-12-01 17:44:38 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciro Galli",
      "screen_name" : "CiroGalli",
      "indices" : [ 0, 10 ],
      "id_str" : "114721230",
      "id" : 114721230
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 19, 34 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407199170647166977",
  "geo" : { },
  "id_str" : "407199969783709696",
  "in_reply_to_user_id" : 114721230,
  "text" : "@CiroGalli hmmm... @AnnotatedBible",
  "id" : 407199969783709696,
  "in_reply_to_status_id" : 407199170647166977,
  "created_at" : "2013-12-01 17:30:12 +0000",
  "in_reply_to_screen_name" : "CiroGalli",
  "in_reply_to_user_id_str" : "114721230",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407198581926293504",
  "geo" : { },
  "id_str" : "407199788703051776",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible whether there is God or No God, still end up with conundrum of original cause.",
  "id" : 407199788703051776,
  "in_reply_to_status_id" : 407198581926293504,
  "created_at" : "2013-12-01 17:29:29 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curve dust",
      "screen_name" : "seekerwisdom8",
      "indices" : [ 3, 17 ],
      "id_str" : "67054018",
      "id" : 67054018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407198503853883393",
  "text" : "RT @seekerwisdom8: \"Tolerance is giving to every other human being every right that you claim for yourself.\"  ~  Robert Green Ingersoll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407197708550553601",
    "text" : "\"Tolerance is giving to every other human being every right that you claim for yourself.\"  ~  Robert Green Ingersoll",
    "id" : 407197708550553601,
    "created_at" : "2013-12-01 17:21:13 +0000",
    "user" : {
      "name" : "carophi",
      "screen_name" : "caro_phill",
      "protected" : false,
      "id_str" : "564947096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799926134817308672\/aYSukjGd_normal.jpg",
      "id" : 564947096,
      "verified" : false
    }
  },
  "id" : 407198503853883393,
  "created_at" : "2013-12-01 17:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407174748821417984",
  "geo" : { },
  "id_str" : "407194583919898624",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible clearly the universe is not \"everything\"",
  "id" : 407194583919898624,
  "in_reply_to_status_id" : 407174748821417984,
  "created_at" : "2013-12-01 17:08:48 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]