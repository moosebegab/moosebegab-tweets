Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan Hollingsworth",
      "screen_name" : "SoulHarmonyInc",
      "indices" : [ 3, 18 ],
      "id_str" : "557446380",
      "id" : 557446380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759911093821018112",
  "text" : "RT @SoulHarmonyInc: Your own truth lies in the realms of your own experience, through your own eyes, within your own soul understanding.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757764191147089921",
    "text" : "Your own truth lies in the realms of your own experience, through your own eyes, within your own soul understanding.",
    "id" : 757764191147089921,
    "created_at" : "2016-07-26 02:27:16 +0000",
    "user" : {
      "name" : "Dylan Hollingsworth",
      "screen_name" : "SoulHarmonyInc",
      "protected" : false,
      "id_str" : "557446380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790299143725916160\/9cPZgrFc_normal.jpg",
      "id" : 557446380,
      "verified" : false
    }
  },
  "id" : 759911093821018112,
  "created_at" : "2016-08-01 00:38:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759811631232589825",
  "geo" : { },
  "id_str" : "759859893629313024",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater my condolences. ((hugs))",
  "id" : 759859893629313024,
  "in_reply_to_status_id" : 759811631232589825,
  "created_at" : "2016-07-31 21:14:50 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759823947881852929",
  "geo" : { },
  "id_str" : "759859485645139968",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind not a stein fan and not anti-vax. but i do think too many vax and wary of pharma.",
  "id" : 759859485645139968,
  "in_reply_to_status_id" : 759823947881852929,
  "created_at" : "2016-07-31 21:13:13 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toto Habschned",
      "screen_name" : "totohabschned",
      "indices" : [ 0, 14 ],
      "id_str" : "46611987",
      "id" : 46611987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759832298405715969",
  "geo" : { },
  "id_str" : "759858881275256832",
  "in_reply_to_user_id" : 46611987,
  "text" : "@totohabschned interesting picture..lol",
  "id" : 759858881275256832,
  "in_reply_to_status_id" : 759832298405715969,
  "created_at" : "2016-07-31 21:10:49 +0000",
  "in_reply_to_screen_name" : "totohabschned",
  "in_reply_to_user_id_str" : "46611987",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/wJ5Rmt1Los",
      "expanded_url" : "https:\/\/zachsmind.wordpress.com\/2016\/07\/31\/like-pegasus-comes-sweeping",
      "display_url" : "zachsmind.wordpress.com\/2016\/07\/31\/lik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759795613907226624",
  "text" : "RT @ZachsMind: Like Pegasus Comes\u00A0Sweeping https:\/\/t.co\/wJ5Rmt1Los",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/wJ5Rmt1Los",
        "expanded_url" : "https:\/\/zachsmind.wordpress.com\/2016\/07\/31\/like-pegasus-comes-sweeping",
        "display_url" : "zachsmind.wordpress.com\/2016\/07\/31\/lik\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759774396357545985",
    "text" : "Like Pegasus Comes\u00A0Sweeping https:\/\/t.co\/wJ5Rmt1Los",
    "id" : 759774396357545985,
    "created_at" : "2016-07-31 15:35:06 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 759795613907226624,
  "created_at" : "2016-07-31 16:59:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weather",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "ncwx",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759760717507661824",
  "text" : "RT @dwaynereaves: Tonight's sunset here in Person County. #weather #ncwx @LizHortonABC11 https:\/\/t.co\/T0iXdvQi4v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/759573129496817664\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/T0iXdvQi4v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoqLuwgWAAEHkJE.jpg",
        "id_str" : "759573122576154625",
        "id" : 759573122576154625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoqLuwgWAAEHkJE.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/T0iXdvQi4v"
      } ],
      "hashtags" : [ {
        "text" : "weather",
        "indices" : [ 40, 48 ]
      }, {
        "text" : "ncwx",
        "indices" : [ 49, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759573129496817664",
    "text" : "Tonight's sunset here in Person County. #weather #ncwx @LizHortonABC11 https:\/\/t.co\/T0iXdvQi4v",
    "id" : 759573129496817664,
    "created_at" : "2016-07-31 02:15:20 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 759760717507661824,
  "created_at" : "2016-07-31 14:40:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galaxy Diagnostics",
      "screen_name" : "Bartonella",
      "indices" : [ 3, 14 ],
      "id_str" : "146188728",
      "id" : 146188728
    }, {
      "name" : "Mackay Rippey",
      "screen_name" : "LymeNinjaRadio",
      "indices" : [ 111, 126 ],
      "id_str" : "2579533556",
      "id" : 2579533556
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LymeDisease",
      "indices" : [ 62, 74 ]
    }, {
      "text" : "Bartonella",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759760418105679872",
  "text" : "RT @Bartonella: Dr. Ahern explains how stealth pathogens like #LymeDisease &amp; #Bartonella hide in the body. @LymeNinjaRadio podcast: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mackay Rippey",
        "screen_name" : "LymeNinjaRadio",
        "indices" : [ 95, 110 ],
        "id_str" : "2579533556",
        "id" : 2579533556
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LymeDisease",
        "indices" : [ 46, 58 ]
      }, {
        "text" : "Bartonella",
        "indices" : [ 65, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/iCGe3fsUWw",
        "expanded_url" : "http:\/\/ow.ly\/lA5W302yW0Y",
        "display_url" : "ow.ly\/lA5W302yW0Y"
      } ]
    },
    "geo" : { },
    "id_str" : "759417079766319104",
    "text" : "Dr. Ahern explains how stealth pathogens like #LymeDisease &amp; #Bartonella hide in the body. @LymeNinjaRadio podcast: https:\/\/t.co\/iCGe3fsUWw",
    "id" : 759417079766319104,
    "created_at" : "2016-07-30 15:55:15 +0000",
    "user" : {
      "name" : "Galaxy Diagnostics",
      "screen_name" : "Bartonella",
      "protected" : false,
      "id_str" : "146188728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2709308221\/e7b27fbcba3d88aa2a011edb5a959316_normal.jpeg",
      "id" : 146188728,
      "verified" : false
    }
  },
  "id" : 759760418105679872,
  "created_at" : "2016-07-31 14:39:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Spectator",
      "screen_name" : "spectator",
      "indices" : [ 3, 13 ],
      "id_str" : "16683666",
      "id" : 16683666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/spectator\/status\/759680798169632768\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/z7DSVvfPJc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cortm9uWgAAoOer.jpg",
      "id_str" : "759680740825137152",
      "id" : 759680740825137152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cortm9uWgAAoOer.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 702
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 702
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 702
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/z7DSVvfPJc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/oUyl1tQpND",
      "expanded_url" : "http:\/\/specc.ie\/2avxi65",
      "display_url" : "specc.ie\/2avxi65"
    } ]
  },
  "geo" : { },
  "id_str" : "759760267576213504",
  "text" : "RT @spectator: Why do lefties hate my pedigree dog? https:\/\/t.co\/oUyl1tQpND https:\/\/t.co\/z7DSVvfPJc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/spectator\/status\/759680798169632768\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/z7DSVvfPJc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cortm9uWgAAoOer.jpg",
        "id_str" : "759680740825137152",
        "id" : 759680740825137152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cortm9uWgAAoOer.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 702
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 702
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 702
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/z7DSVvfPJc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/oUyl1tQpND",
        "expanded_url" : "http:\/\/specc.ie\/2avxi65",
        "display_url" : "specc.ie\/2avxi65"
      } ]
    },
    "geo" : { },
    "id_str" : "759680798169632768",
    "text" : "Why do lefties hate my pedigree dog? https:\/\/t.co\/oUyl1tQpND https:\/\/t.co\/z7DSVvfPJc",
    "id" : 759680798169632768,
    "created_at" : "2016-07-31 09:23:11 +0000",
    "user" : {
      "name" : "The Spectator",
      "screen_name" : "spectator",
      "protected" : false,
      "id_str" : "16683666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550605349649006592\/5uweyQ7d_normal.png",
      "id" : 16683666,
      "verified" : true
    }
  },
  "id" : 759760267576213504,
  "created_at" : "2016-07-31 14:38:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/xfIb0t3rnk",
      "expanded_url" : "https:\/\/twitter.com\/antmousie\/status\/759550590833745920",
      "display_url" : "twitter.com\/antmousie\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759561263039016961",
  "text" : "interesting https:\/\/t.co\/xfIb0t3rnk",
  "id" : 759561263039016961,
  "created_at" : "2016-07-31 01:28:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert E. Hayes",
      "screen_name" : "RobertEHayes",
      "indices" : [ 3, 16 ],
      "id_str" : "357299551",
      "id" : 357299551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759558896340074496",
  "text" : "RT @RobertEHayes: A white Wash. state teen killed 3, fled &amp; was taken alive. Last night a black teen in Chicago stole a car, no gun, fled &amp;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759550128793485312",
    "text" : "A white Wash. state teen killed 3, fled &amp; was taken alive. Last night a black teen in Chicago stole a car, no gun, fled &amp; cops killed him.",
    "id" : 759550128793485312,
    "created_at" : "2016-07-31 00:43:57 +0000",
    "user" : {
      "name" : "Robert E. Hayes",
      "screen_name" : "RobertEHayes",
      "protected" : false,
      "id_str" : "357299551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000088043337\/56bc128a58f68b8702ea919441044600_normal.jpeg",
      "id" : 357299551,
      "verified" : false
    }
  },
  "id" : 759558896340074496,
  "created_at" : "2016-07-31 01:18:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perky-Pet\u00AE",
      "screen_name" : "PerkyPetFeeders",
      "indices" : [ 3, 19 ],
      "id_str" : "96792570",
      "id" : 96792570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/sr15tDj1tG",
      "expanded_url" : "http:\/\/ow.ly\/Q1NQ301IMap",
      "display_url" : "ow.ly\/Q1NQ301IMap"
    } ]
  },
  "geo" : { },
  "id_str" : "759541368268136448",
  "text" : "RT @PerkyPetFeeders: Did you know? To attract a mate, male Red-Bellied Woodpeckers rap on metal objects? https:\/\/t.co\/sr15tDj1tG https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PerkyPetFeeders\/status\/759539341924368384\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/AMuuQ8WNYI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoptAShXYAUb_-K.jpg",
        "id_str" : "759539338904559621",
        "id" : 759539338904559621,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoptAShXYAUb_-K.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/AMuuQ8WNYI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/sr15tDj1tG",
        "expanded_url" : "http:\/\/ow.ly\/Q1NQ301IMap",
        "display_url" : "ow.ly\/Q1NQ301IMap"
      } ]
    },
    "geo" : { },
    "id_str" : "759539341924368384",
    "text" : "Did you know? To attract a mate, male Red-Bellied Woodpeckers rap on metal objects? https:\/\/t.co\/sr15tDj1tG https:\/\/t.co\/AMuuQ8WNYI",
    "id" : 759539341924368384,
    "created_at" : "2016-07-31 00:01:05 +0000",
    "user" : {
      "name" : "Perky-Pet\u00AE",
      "screen_name" : "PerkyPetFeeders",
      "protected" : false,
      "id_str" : "96792570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794209254601347073\/cZsF5R_H_normal.jpg",
      "id" : 96792570,
      "verified" : false
    }
  },
  "id" : 759541368268136448,
  "created_at" : "2016-07-31 00:09:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "indices" : [ 3, 16 ],
      "id_str" : "530935629",
      "id" : 530935629
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/759509227513614336\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/e0COioVuCe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CopRayQUMAArxh9.jpg",
      "id_str" : "759509007774003200",
      "id" : 759509007774003200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CopRayQUMAArxh9.jpg",
      "sizes" : [ {
        "h" : 1131,
        "resize" : "fit",
        "w" : 1158
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1131,
        "resize" : "fit",
        "w" : 1158
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1131,
        "resize" : "fit",
        "w" : 1158
      } ],
      "display_url" : "pic.twitter.com\/e0COioVuCe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/759509227513614336\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/e0COioVuCe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CopReOQUIAA5jVM.jpg",
      "id_str" : "759509066829799424",
      "id" : 759509066829799424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CopReOQUIAA5jVM.jpg",
      "sizes" : [ {
        "h" : 1064,
        "resize" : "fit",
        "w" : 998
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 998
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 998
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/e0COioVuCe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/759509227513614336\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/e0COioVuCe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CopRf-EVIAAFGRi.jpg",
      "id_str" : "759509096844304384",
      "id" : 759509096844304384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CopRf-EVIAAFGRi.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 453
      } ],
      "display_url" : "pic.twitter.com\/e0COioVuCe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759539772842991618",
  "text" : "RT @melinawstaal: the tithonia was popular with the swallowtails this morning https:\/\/t.co\/e0COioVuCe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/759509227513614336\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/e0COioVuCe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CopRayQUMAArxh9.jpg",
        "id_str" : "759509007774003200",
        "id" : 759509007774003200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CopRayQUMAArxh9.jpg",
        "sizes" : [ {
          "h" : 1131,
          "resize" : "fit",
          "w" : 1158
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1131,
          "resize" : "fit",
          "w" : 1158
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1131,
          "resize" : "fit",
          "w" : 1158
        } ],
        "display_url" : "pic.twitter.com\/e0COioVuCe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/759509227513614336\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/e0COioVuCe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CopReOQUIAA5jVM.jpg",
        "id_str" : "759509066829799424",
        "id" : 759509066829799424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CopReOQUIAA5jVM.jpg",
        "sizes" : [ {
          "h" : 1064,
          "resize" : "fit",
          "w" : 998
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 998
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 998
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/e0COioVuCe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/759509227513614336\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/e0COioVuCe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CopRf-EVIAAFGRi.jpg",
        "id_str" : "759509096844304384",
        "id" : 759509096844304384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CopRf-EVIAAFGRi.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 453
        } ],
        "display_url" : "pic.twitter.com\/e0COioVuCe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759509227513614336",
    "text" : "the tithonia was popular with the swallowtails this morning https:\/\/t.co\/e0COioVuCe",
    "id" : 759509227513614336,
    "created_at" : "2016-07-30 22:01:25 +0000",
    "user" : {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "protected" : false,
      "id_str" : "530935629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638498065096151042\/DwWC834G_normal.jpg",
      "id" : 530935629,
      "verified" : false
    }
  },
  "id" : 759539772842991618,
  "created_at" : "2016-07-31 00:02:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Mark N Reynolds",
      "screen_name" : "JMNR",
      "indices" : [ 3, 8 ],
      "id_str" : "16380561",
      "id" : 16380561
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 90, 100 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/0JUsmlFCZW",
      "expanded_url" : "https:\/\/shar.es\/1ZuKWt",
      "display_url" : "shar.es\/1ZuKWt"
    } ]
  },
  "geo" : { },
  "id_str" : "759521477272170496",
  "text" : "RT @JMNR: A Good Man Justifies a Wicked Deed: Grudem on Trump https:\/\/t.co\/0JUsmlFCZW via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 80, 90 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/0JUsmlFCZW",
        "expanded_url" : "https:\/\/shar.es\/1ZuKWt",
        "display_url" : "shar.es\/1ZuKWt"
      } ]
    },
    "geo" : { },
    "id_str" : "759299775887921152",
    "text" : "A Good Man Justifies a Wicked Deed: Grudem on Trump https:\/\/t.co\/0JUsmlFCZW via @sharethis",
    "id" : 759299775887921152,
    "created_at" : "2016-07-30 08:09:08 +0000",
    "user" : {
      "name" : "John Mark N Reynolds",
      "screen_name" : "JMNR",
      "protected" : false,
      "id_str" : "16380561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783307864047628288\/JgOwvumX_normal.jpg",
      "id" : 16380561,
      "verified" : false
    }
  },
  "id" : 759521477272170496,
  "created_at" : "2016-07-30 22:50:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "indices" : [ 3, 16 ],
      "id_str" : "2423532173",
      "id" : 2423532173
    }, {
      "name" : "lorna",
      "screen_name" : "lorna_prentice",
      "indices" : [ 100, 115 ],
      "id_str" : "1445806682",
      "id" : 1445806682
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/759291061546127360\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/COlE1jZ91S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ComLKmwXYAA36ga.jpg",
      "id_str" : "759291026506997760",
      "id" : 759291026506997760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ComLKmwXYAA36ga.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/COlE1jZ91S"
    } ],
    "hashtags" : [ {
      "text" : "isleofiona",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "highlandcattle",
      "indices" : [ 76, 91 ]
    }, {
      "text" : "collie",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759521088376274944",
  "text" : "RT @Maolfarmiona: One woman and her dog, oh yeh and her bull!!! #isleofiona #highlandcattle #collie @lorna_prentice https:\/\/t.co\/COlE1jZ91S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "lorna",
        "screen_name" : "lorna_prentice",
        "indices" : [ 82, 97 ],
        "id_str" : "1445806682",
        "id" : 1445806682
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/759291061546127360\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/COlE1jZ91S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ComLKmwXYAA36ga.jpg",
        "id_str" : "759291026506997760",
        "id" : 759291026506997760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ComLKmwXYAA36ga.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/COlE1jZ91S"
      } ],
      "hashtags" : [ {
        "text" : "isleofiona",
        "indices" : [ 46, 57 ]
      }, {
        "text" : "highlandcattle",
        "indices" : [ 58, 73 ]
      }, {
        "text" : "collie",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759291061546127360",
    "text" : "One woman and her dog, oh yeh and her bull!!! #isleofiona #highlandcattle #collie @lorna_prentice https:\/\/t.co\/COlE1jZ91S",
    "id" : 759291061546127360,
    "created_at" : "2016-07-30 07:34:30 +0000",
    "user" : {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "protected" : false,
      "id_str" : "2423532173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798860009874472961\/v5GADWSz_normal.jpg",
      "id" : 2423532173,
      "verified" : false
    }
  },
  "id" : 759521088376274944,
  "created_at" : "2016-07-30 22:48:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Ricketts",
      "screen_name" : "gbricketts",
      "indices" : [ 3, 14 ],
      "id_str" : "3310136011",
      "id" : 3310136011
    }, {
      "name" : "Good News Network",
      "screen_name" : "goodnewsnetwork",
      "indices" : [ 106, 122 ],
      "id_str" : "22025046",
      "id" : 22025046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/8rUxcZ89bY",
      "expanded_url" : "http:\/\/www.goodnewsnetwork.org\/monarch-butterfly-population-more-than-triples-over-last-year\/#.V50G53chTRQ.twitter",
      "display_url" : "goodnewsnetwork.org\/monarch-butter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759503800105308160",
  "text" : "RT @gbricketts: Monarch Butterfly Population More Than Triples Over Last Year https:\/\/t.co\/8rUxcZ89bY via @GoodNewsNetwork",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Good News Network",
        "screen_name" : "goodnewsnetwork",
        "indices" : [ 90, 106 ],
        "id_str" : "22025046",
        "id" : 22025046
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/8rUxcZ89bY",
        "expanded_url" : "http:\/\/www.goodnewsnetwork.org\/monarch-butterfly-population-more-than-triples-over-last-year\/#.V50G53chTRQ.twitter",
        "display_url" : "goodnewsnetwork.org\/monarch-butter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759478314356441090",
    "text" : "Monarch Butterfly Population More Than Triples Over Last Year https:\/\/t.co\/8rUxcZ89bY via @GoodNewsNetwork",
    "id" : 759478314356441090,
    "created_at" : "2016-07-30 19:58:35 +0000",
    "user" : {
      "name" : "Greg Ricketts",
      "screen_name" : "gbricketts",
      "protected" : false,
      "id_str" : "3310136011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654926850716659712\/AA3UI6X9_normal.jpg",
      "id" : 3310136011,
      "verified" : false
    }
  },
  "id" : 759503800105308160,
  "created_at" : "2016-07-30 21:39:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759499606505955328",
  "geo" : { },
  "id_str" : "759503569548705792",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep yeah.. we experienced that, too. luckily found shorter line and it moved rel. fast",
  "id" : 759503569548705792,
  "in_reply_to_status_id" : 759499606505955328,
  "created_at" : "2016-07-30 21:38:56 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "indices" : [ 3, 18 ],
      "id_str" : "46822887",
      "id" : 46822887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759476026065952768",
  "text" : "RT @AngryBlackLady: I relate so much. I didn't become the person I am now until I was 38. Just wandering around the world lost af. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AngryBlackLady\/status\/755433651639169024\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/4rJJD7YBjm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvW49VUIAEBUSO.jpg",
        "id_str" : "755433636539670529",
        "id" : 755433636539670529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvW49VUIAEBUSO.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 584
        }, {
          "h" : 874,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 874,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 874,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/4rJJD7YBjm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755433651639169024",
    "text" : "I relate so much. I didn't become the person I am now until I was 38. Just wandering around the world lost af. https:\/\/t.co\/4rJJD7YBjm",
    "id" : 755433651639169024,
    "created_at" : "2016-07-19 16:06:32 +0000",
    "user" : {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "protected" : false,
      "id_str" : "46822887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790644001330171904\/E3uUevS__normal.jpg",
      "id" : 46822887,
      "verified" : true
    }
  },
  "id" : 759476026065952768,
  "created_at" : "2016-07-30 19:49:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert McNees",
      "screen_name" : "mcnees",
      "indices" : [ 3, 10 ],
      "id_str" : "15127834",
      "id" : 15127834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/JKzBkXuGuB",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonk\/wp\/2016\/07\/29\/the-smoking-gun-proving-north-carolina-republicans-tried-to-disenfranchise-black-voters\/",
      "display_url" : "washingtonpost.com\/news\/wonk\/wp\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759388233717481473",
  "text" : "RT @mcnees: Not a smoking gun so much as a signed and detailed confession, given with no fear of consequences.\nhttps:\/\/t.co\/JKzBkXuGuB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/JKzBkXuGuB",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonk\/wp\/2016\/07\/29\/the-smoking-gun-proving-north-carolina-republicans-tried-to-disenfranchise-black-voters\/",
        "display_url" : "washingtonpost.com\/news\/wonk\/wp\/2\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "759068989792419840",
    "geo" : { },
    "id_str" : "759383811612352512",
    "in_reply_to_user_id" : 15127834,
    "text" : "Not a smoking gun so much as a signed and detailed confession, given with no fear of consequences.\nhttps:\/\/t.co\/JKzBkXuGuB",
    "id" : 759383811612352512,
    "in_reply_to_status_id" : 759068989792419840,
    "created_at" : "2016-07-30 13:43:04 +0000",
    "in_reply_to_screen_name" : "mcnees",
    "in_reply_to_user_id_str" : "15127834",
    "user" : {
      "name" : "Robert McNees",
      "screen_name" : "mcnees",
      "protected" : false,
      "id_str" : "15127834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783668865884622849\/8NXcRAuk_normal.jpg",
      "id" : 15127834,
      "verified" : false
    }
  },
  "id" : 759388233717481473,
  "created_at" : "2016-07-30 14:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/SqDHbKm5A7",
      "expanded_url" : "http:\/\/nydn.us\/RedneckDNC",
      "display_url" : "nydn.us\/RedneckDNC"
    } ]
  },
  "geo" : { },
  "id_str" : "759383995851374592",
  "text" : "Trae Crowder, the Liberal Redneck, says the DNC email controversy \u2018is the Deflategate of election scandals.\u2019 https:\/\/t.co\/SqDHbKm5A7",
  "id" : 759383995851374592,
  "created_at" : "2016-07-30 13:43:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/Lc8epwMnle",
      "expanded_url" : "https:\/\/twitter.com\/emma_gras\/status\/759151974713556993",
      "display_url" : "twitter.com\/emma_gras\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759197393141297152",
  "text" : "RT @onealexharms: How lovely! \uD83D\uDE0D https:\/\/t.co\/Lc8epwMnle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/Lc8epwMnle",
        "expanded_url" : "https:\/\/twitter.com\/emma_gras\/status\/759151974713556993",
        "display_url" : "twitter.com\/emma_gras\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759187620912046080",
    "text" : "How lovely! \uD83D\uDE0D https:\/\/t.co\/Lc8epwMnle",
    "id" : 759187620912046080,
    "created_at" : "2016-07-30 00:43:28 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 759197393141297152,
  "created_at" : "2016-07-30 01:22:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina",
      "screen_name" : "ItsMeTinaD",
      "indices" : [ 3, 14 ],
      "id_str" : "911319649",
      "id" : 911319649
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/754726351605755904\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/1xgReDf2wf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlTXaGXEAANi_a.jpg",
      "id_str" : "754726074169364480",
      "id" : 754726074169364480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlTXaGXEAANi_a.jpg",
      "sizes" : [ {
        "h" : 2789,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 817,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1395,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/1xgReDf2wf"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/754726351605755904\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/1xgReDf2wf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlTdzhXgAA-gDS.jpg",
      "id_str" : "754726184072740864",
      "id" : 754726184072740864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlTdzhXgAA-gDS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1071,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2141,
        "resize" : "fit",
        "w" : 4096
      } ],
      "display_url" : "pic.twitter.com\/1xgReDf2wf"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/754726351605755904\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/1xgReDf2wf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlTkrzWEAAGGm6.jpg",
      "id_str" : "754726302259744768",
      "id" : 754726302259744768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlTkrzWEAAGGm6.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2373,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 1187,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1xgReDf2wf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759147927667412992",
  "text" : "RT @ItsMeTinaD: Greylag Geese enjoying the meadow grasses https:\/\/t.co\/1xgReDf2wf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/754726351605755904\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/1xgReDf2wf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlTXaGXEAANi_a.jpg",
        "id_str" : "754726074169364480",
        "id" : 754726074169364480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlTXaGXEAANi_a.jpg",
        "sizes" : [ {
          "h" : 2789,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 817,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1395,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/1xgReDf2wf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/754726351605755904\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/1xgReDf2wf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlTdzhXgAA-gDS.jpg",
        "id_str" : "754726184072740864",
        "id" : 754726184072740864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlTdzhXgAA-gDS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1071,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2141,
          "resize" : "fit",
          "w" : 4096
        } ],
        "display_url" : "pic.twitter.com\/1xgReDf2wf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/754726351605755904\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/1xgReDf2wf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlTkrzWEAAGGm6.jpg",
        "id_str" : "754726302259744768",
        "id" : 754726302259744768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlTkrzWEAAGGm6.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2373,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 1187,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/1xgReDf2wf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754726351605755904",
    "text" : "Greylag Geese enjoying the meadow grasses https:\/\/t.co\/1xgReDf2wf",
    "id" : 754726351605755904,
    "created_at" : "2016-07-17 17:15:59 +0000",
    "user" : {
      "name" : "Tina",
      "screen_name" : "ItsMeTinaD",
      "protected" : false,
      "id_str" : "911319649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3332409356\/c4e564761da1342ec30ebc3dc055c3a1_normal.jpeg",
      "id" : 911319649,
      "verified" : false
    }
  },
  "id" : 759147927667412992,
  "created_at" : "2016-07-29 22:05:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev",
      "screen_name" : "Fruit_and_Nut",
      "indices" : [ 3, 17 ],
      "id_str" : "4910691041",
      "id" : 4910691041
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Fruit_and_Nut\/status\/757269156039385090\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/J29FqC7R0w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoJcKdfWIAAQYJB.jpg",
      "id_str" : "757269022136213504",
      "id" : 757269022136213504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoJcKdfWIAAQYJB.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3072,
        "resize" : "fit",
        "w" : 4096
      } ],
      "display_url" : "pic.twitter.com\/J29FqC7R0w"
    } ],
    "hashtags" : [ {
      "text" : "macrophoto",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759147770586533888",
  "text" : "RT @Fruit_and_Nut: Common Blue #macrophoto https:\/\/t.co\/J29FqC7R0w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fruit_and_Nut\/status\/757269156039385090\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/J29FqC7R0w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoJcKdfWIAAQYJB.jpg",
        "id_str" : "757269022136213504",
        "id" : 757269022136213504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoJcKdfWIAAQYJB.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3072,
          "resize" : "fit",
          "w" : 4096
        } ],
        "display_url" : "pic.twitter.com\/J29FqC7R0w"
      } ],
      "hashtags" : [ {
        "text" : "macrophoto",
        "indices" : [ 12, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757269156039385090",
    "text" : "Common Blue #macrophoto https:\/\/t.co\/J29FqC7R0w",
    "id" : 757269156039385090,
    "created_at" : "2016-07-24 17:40:10 +0000",
    "user" : {
      "name" : "Kev",
      "screen_name" : "Fruit_and_Nut",
      "protected" : false,
      "id_str" : "4910691041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775091594995335169\/ClE5fIaQ_normal.jpg",
      "id" : 4910691041,
      "verified" : false
    }
  },
  "id" : 759147770586533888,
  "created_at" : "2016-07-29 22:05:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina",
      "screen_name" : "ItsMeTinaD",
      "indices" : [ 3, 14 ],
      "id_str" : "911319649",
      "id" : 911319649
    }, {
      "name" : "BBC Springwatch",
      "screen_name" : "BBCSpringwatch",
      "indices" : [ 16, 31 ],
      "id_str" : "71229689",
      "id" : 71229689
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/756468096190164992\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/s9EPtuT0OK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn-DsEtW8AAox5f.jpg",
      "id_str" : "756468055623004160",
      "id" : 756468055623004160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn-DsEtW8AAox5f.jpg",
      "sizes" : [ {
        "h" : 1157,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2067,
        "resize" : "fit",
        "w" : 3658
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/s9EPtuT0OK"
    } ],
    "hashtags" : [ {
      "text" : "Summerwatch",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759147686008356864",
  "text" : "RT @ItsMeTinaD: @BBCSpringwatch #Summerwatch https:\/\/t.co\/s9EPtuT0OK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Springwatch",
        "screen_name" : "BBCSpringwatch",
        "indices" : [ 0, 15 ],
        "id_str" : "71229689",
        "id" : 71229689
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsMeTinaD\/status\/756468096190164992\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/s9EPtuT0OK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn-DsEtW8AAox5f.jpg",
        "id_str" : "756468055623004160",
        "id" : 756468055623004160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn-DsEtW8AAox5f.jpg",
        "sizes" : [ {
          "h" : 1157,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2067,
          "resize" : "fit",
          "w" : 3658
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/s9EPtuT0OK"
      } ],
      "hashtags" : [ {
        "text" : "Summerwatch",
        "indices" : [ 16, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756468096190164992",
    "in_reply_to_user_id" : 71229689,
    "text" : "@BBCSpringwatch #Summerwatch https:\/\/t.co\/s9EPtuT0OK",
    "id" : 756468096190164992,
    "created_at" : "2016-07-22 12:37:03 +0000",
    "in_reply_to_screen_name" : "BBCSpringwatch",
    "in_reply_to_user_id_str" : "71229689",
    "user" : {
      "name" : "Tina",
      "screen_name" : "ItsMeTinaD",
      "protected" : false,
      "id_str" : "911319649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3332409356\/c4e564761da1342ec30ebc3dc055c3a1_normal.jpeg",
      "id" : 911319649,
      "verified" : false
    }
  },
  "id" : 759147686008356864,
  "created_at" : "2016-07-29 22:04:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheriffFruitfly",
      "screen_name" : "sherifffruitfly",
      "indices" : [ 3, 19 ],
      "id_str" : "19052381",
      "id" : 19052381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/artLfQDnMp",
      "expanded_url" : "https:\/\/twitter.com\/austin_walker\/status\/758508202497638400",
      "display_url" : "twitter.com\/austin_walker\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759146164855930880",
  "text" : "RT @sherifffruitfly: (sobs) https:\/\/t.co\/artLfQDnMp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/artLfQDnMp",
        "expanded_url" : "https:\/\/twitter.com\/austin_walker\/status\/758508202497638400",
        "display_url" : "twitter.com\/austin_walker\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758763808361807872",
    "text" : "(sobs) https:\/\/t.co\/artLfQDnMp",
    "id" : 758763808361807872,
    "created_at" : "2016-07-28 20:39:23 +0000",
    "user" : {
      "name" : "SheriffFruitfly",
      "screen_name" : "sherifffruitfly",
      "protected" : false,
      "id_str" : "19052381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739119427564642306\/kfwtzRtA_normal.jpg",
      "id" : 19052381,
      "verified" : false
    }
  },
  "id" : 759146164855930880,
  "created_at" : "2016-07-29 21:58:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "austin walker",
      "screen_name" : "austin_walker",
      "indices" : [ 3, 17 ],
      "id_str" : "18758101",
      "id" : 18758101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/austin_walker\/status\/758508202497638400\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/eCN04cE0q3",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CobDI8TWgAAYlBl.jpg",
      "id_str" : "758508145652170752",
      "id" : 758508145652170752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CobDI8TWgAAYlBl.jpg",
      "sizes" : [ {
        "h" : 274,
        "resize" : "fit",
        "w" : 488
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 488
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 488
      } ],
      "display_url" : "pic.twitter.com\/eCN04cE0q3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759146063731326976",
  "text" : "RT @austin_walker: well now i'm just thinking about this moment again. https:\/\/t.co\/eCN04cE0q3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/austin_walker\/status\/758508202497638400\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/eCN04cE0q3",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CobDI8TWgAAYlBl.jpg",
        "id_str" : "758508145652170752",
        "id" : 758508145652170752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CobDI8TWgAAYlBl.jpg",
        "sizes" : [ {
          "h" : 274,
          "resize" : "fit",
          "w" : 488
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 488
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 488
        } ],
        "display_url" : "pic.twitter.com\/eCN04cE0q3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758508202497638400",
    "text" : "well now i'm just thinking about this moment again. https:\/\/t.co\/eCN04cE0q3",
    "id" : 758508202497638400,
    "created_at" : "2016-07-28 03:43:42 +0000",
    "user" : {
      "name" : "austin walker",
      "screen_name" : "austin_walker",
      "protected" : false,
      "id_str" : "18758101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793461030030630912\/f2_KJm2P_normal.jpg",
      "id" : 18758101,
      "verified" : true
    }
  },
  "id" : 759146063731326976,
  "created_at" : "2016-07-29 21:58:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Fine Art America",
      "screen_name" : "FineArtAmerica",
      "indices" : [ 90, 105 ],
      "id_str" : "16828262",
      "id" : 16828262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/759089615634436096\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/WJb6Gapfm1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CojT-xKUMAADhn0.jpg",
      "id_str" : "759089612513882112",
      "id" : 759089612513882112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CojT-xKUMAADhn0.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WJb6Gapfm1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/R48DJUIXXK",
      "expanded_url" : "http:\/\/fineartamerica.com\/featured\/sunset-at-hyco-lake-dwayne-reaves.html",
      "display_url" : "fineartamerica.com\/featured\/sunse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759116242141806592",
  "text" : "RT @dwaynereaves: New artwork for sale! - \"Sunset at Hyco Lake\" - https:\/\/t.co\/R48DJUIXXK @fineartamerica https:\/\/t.co\/WJb6Gapfm1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/fineartamerica.com\" rel=\"nofollow\"\u003EFine Art America\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fine Art America",
        "screen_name" : "FineArtAmerica",
        "indices" : [ 72, 87 ],
        "id_str" : "16828262",
        "id" : 16828262
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/759089615634436096\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/WJb6Gapfm1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CojT-xKUMAADhn0.jpg",
        "id_str" : "759089612513882112",
        "id" : 759089612513882112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CojT-xKUMAADhn0.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WJb6Gapfm1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/R48DJUIXXK",
        "expanded_url" : "http:\/\/fineartamerica.com\/featured\/sunset-at-hyco-lake-dwayne-reaves.html",
        "display_url" : "fineartamerica.com\/featured\/sunse\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759089615634436096",
    "text" : "New artwork for sale! - \"Sunset at Hyco Lake\" - https:\/\/t.co\/R48DJUIXXK @fineartamerica https:\/\/t.co\/WJb6Gapfm1",
    "id" : 759089615634436096,
    "created_at" : "2016-07-29 18:14:02 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 759116242141806592,
  "created_at" : "2016-07-29 19:59:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Fine Art America",
      "screen_name" : "FineArtAmerica",
      "indices" : [ 90, 105 ],
      "id_str" : "16828262",
      "id" : 16828262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/759084937936904192\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/GSyaF8sghX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CojPujPUIAAFX2h.jpg",
      "id_str" : "759084935852335104",
      "id" : 759084935852335104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CojPujPUIAAFX2h.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GSyaF8sghX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/V2QMUReZkU",
      "expanded_url" : "http:\/\/fineartamerica.com\/featured\/sunset-at-mayo-lake-dwayne-reaves.html",
      "display_url" : "fineartamerica.com\/featured\/sunse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759087444209889280",
  "text" : "RT @dwaynereaves: New artwork for sale! - \"Sunset at Mayo Lake\" - https:\/\/t.co\/V2QMUReZkU @fineartamerica https:\/\/t.co\/GSyaF8sghX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/fineartamerica.com\" rel=\"nofollow\"\u003EFine Art America\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fine Art America",
        "screen_name" : "FineArtAmerica",
        "indices" : [ 72, 87 ],
        "id_str" : "16828262",
        "id" : 16828262
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/759084937936904192\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/GSyaF8sghX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CojPujPUIAAFX2h.jpg",
        "id_str" : "759084935852335104",
        "id" : 759084935852335104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CojPujPUIAAFX2h.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GSyaF8sghX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/V2QMUReZkU",
        "expanded_url" : "http:\/\/fineartamerica.com\/featured\/sunset-at-mayo-lake-dwayne-reaves.html",
        "display_url" : "fineartamerica.com\/featured\/sunse\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759084937936904192",
    "text" : "New artwork for sale! - \"Sunset at Mayo Lake\" - https:\/\/t.co\/V2QMUReZkU @fineartamerica https:\/\/t.co\/GSyaF8sghX",
    "id" : 759084937936904192,
    "created_at" : "2016-07-29 17:55:26 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 759087444209889280,
  "created_at" : "2016-07-29 18:05:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758725182156595200",
  "geo" : { },
  "id_str" : "758763808764682240",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe so exciting. congrats! i know you'd been wanting to move for awhile. : )",
  "id" : 758763808764682240,
  "in_reply_to_status_id" : 758725182156595200,
  "created_at" : "2016-07-28 20:39:23 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chessie The Shark",
      "screen_name" : "ChessieShark",
      "indices" : [ 3, 16 ],
      "id_str" : "3246347998",
      "id" : 3246347998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758675928994250753",
  "text" : "RT @ChessieShark: They should make untangling headphones an olympic sport.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758660071177981952",
    "text" : "They should make untangling headphones an olympic sport.",
    "id" : 758660071177981952,
    "created_at" : "2016-07-28 13:47:10 +0000",
    "user" : {
      "name" : "Chessie The Shark",
      "screen_name" : "ChessieShark",
      "protected" : false,
      "id_str" : "3246347998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753014966937018368\/FubPGJmL_normal.jpg",
      "id" : 3246347998,
      "verified" : false
    }
  },
  "id" : 758675928994250753,
  "created_at" : "2016-07-28 14:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird and Moon",
      "screen_name" : "RosemaryMosco",
      "indices" : [ 3, 17 ],
      "id_str" : "1020952663",
      "id" : 1020952663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/v5K2TF98iY",
      "expanded_url" : "http:\/\/www.birdandmoon.com\/comic\/study-species\/",
      "display_url" : "birdandmoon.com\/comic\/study-sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758675764711723008",
  "text" : "RT @RosemaryMosco: Need help deciding which species to observe or study? I've got you covered! https:\/\/t.co\/v5K2TF98iY https:\/\/t.co\/bbxuSNX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RosemaryMosco\/status\/758421144622039040\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/bbxuSNXqrA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZzmPxXgAAP0qe.jpg",
        "id_str" : "758420688164323328",
        "id" : 758420688164323328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZzmPxXgAAP0qe.jpg",
        "sizes" : [ {
          "h" : 1040,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1040,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 1040,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 451
        } ],
        "display_url" : "pic.twitter.com\/bbxuSNXqrA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/v5K2TF98iY",
        "expanded_url" : "http:\/\/www.birdandmoon.com\/comic\/study-species\/",
        "display_url" : "birdandmoon.com\/comic\/study-sp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758421144622039040",
    "text" : "Need help deciding which species to observe or study? I've got you covered! https:\/\/t.co\/v5K2TF98iY https:\/\/t.co\/bbxuSNXqrA",
    "id" : 758421144622039040,
    "created_at" : "2016-07-27 21:57:46 +0000",
    "user" : {
      "name" : "Bird and Moon",
      "screen_name" : "RosemaryMosco",
      "protected" : false,
      "id_str" : "1020952663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800519480401154050\/AkUITeM-_normal.jpg",
      "id" : 1020952663,
      "verified" : false
    }
  },
  "id" : 758675764711723008,
  "created_at" : "2016-07-28 14:49:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Godwin",
      "screen_name" : "richardjgodwin",
      "indices" : [ 3, 18 ],
      "id_str" : "75060487",
      "id" : 75060487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/cKlO8QEc0p",
      "expanded_url" : "http:\/\/www.standard.co.uk\/comment\/comment\/richard-godwin-universal-basic-income-is-not-just-some-pipedream-a3305791.html",
      "display_url" : "standard.co.uk\/comment\/commen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758675284287684608",
  "text" : "RT @richardjgodwin: Basic income woo-hoo! This week's column (trying to spread a little optimism...) https:\/\/t.co\/cKlO8QEc0p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/cKlO8QEc0p",
        "expanded_url" : "http:\/\/www.standard.co.uk\/comment\/comment\/richard-godwin-universal-basic-income-is-not-just-some-pipedream-a3305791.html",
        "display_url" : "standard.co.uk\/comment\/commen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758295344866287620",
    "text" : "Basic income woo-hoo! This week's column (trying to spread a little optimism...) https:\/\/t.co\/cKlO8QEc0p",
    "id" : 758295344866287620,
    "created_at" : "2016-07-27 13:37:53 +0000",
    "user" : {
      "name" : "Richard Godwin",
      "screen_name" : "richardjgodwin",
      "protected" : false,
      "id_str" : "75060487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2399788067\/58yqleh093tpil90vxl3_normal.jpeg",
      "id" : 75060487,
      "verified" : false
    }
  },
  "id" : 758675284287684608,
  "created_at" : "2016-07-28 14:47:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basic Income UK",
      "screen_name" : "basicincome_uk",
      "indices" : [ 3, 18 ],
      "id_str" : "1175288654",
      "id" : 1175288654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758675200280039424",
  "text" : "RT @basicincome_uk: \"One possible solution is to give everyone a basic income: a guaranteed min income for everyone, as a right.\" https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/IZOK4ObtU0",
        "expanded_url" : "http:\/\/theconversation.com\/the-way-we-work-is-changing-but-the-welfare-state-hasnt-kept-pace-with-the-times-60589",
        "display_url" : "theconversation.com\/the-way-we-wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757650600603426816",
    "text" : "\"One possible solution is to give everyone a basic income: a guaranteed min income for everyone, as a right.\" https:\/\/t.co\/IZOK4ObtU0",
    "id" : 757650600603426816,
    "created_at" : "2016-07-25 18:55:54 +0000",
    "user" : {
      "name" : "Basic Income UK",
      "screen_name" : "basicincome_uk",
      "protected" : false,
      "id_str" : "1175288654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640997528717033473\/jw2rpekD_normal.png",
      "id" : 1175288654,
      "verified" : false
    }
  },
  "id" : 758675200280039424,
  "created_at" : "2016-07-28 14:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    }, {
      "name" : "The Gospel Coalition",
      "screen_name" : "TGC",
      "indices" : [ 125, 129 ],
      "id_str" : "31014746",
      "id" : 31014746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758672751578185729",
  "text" : "RT @rachelheldevans: This is more common than people realize. Especially from orgs that embrace teachings of Douglas Wilson (@TGC) https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Gospel Coalition",
        "screen_name" : "TGC",
        "indices" : [ 104, 108 ],
        "id_str" : "31014746",
        "id" : 31014746
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/fEq6KlDaDj",
        "expanded_url" : "https:\/\/twitter.com\/kscharold\/status\/758664016172572672",
        "display_url" : "twitter.com\/kscharold\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758670056096161792",
    "text" : "This is more common than people realize. Especially from orgs that embrace teachings of Douglas Wilson (@TGC) https:\/\/t.co\/fEq6KlDaDj",
    "id" : 758670056096161792,
    "created_at" : "2016-07-28 14:26:51 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 758672751578185729,
  "created_at" : "2016-07-28 14:37:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/hzEv8jDFuX",
      "expanded_url" : "http:\/\/abcn.ws\/2av9kaR",
      "display_url" : "abcn.ws\/2av9kaR"
    } ]
  },
  "geo" : { },
  "id_str" : "758476696161030144",
  "text" : "RT @ABC: 75-pound pet tortoise reunited with family in CA after he was discovered fleeing wildfires. https:\/\/t.co\/hzEv8jDFuX https:\/\/t.co\/f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/758276006008545281\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fXFyRRMLVE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXwACbWEAEU_Cb.jpg",
        "id_str" : "758275995724025857",
        "id" : 758275995724025857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXwACbWEAEU_Cb.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 992
        } ],
        "display_url" : "pic.twitter.com\/fXFyRRMLVE"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/758276006008545281\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fXFyRRMLVE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXwAYSWYAAg9zq.jpg",
        "id_str" : "758276001591877632",
        "id" : 758276001591877632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXwAYSWYAAg9zq.jpg",
        "sizes" : [ {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fXFyRRMLVE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/hzEv8jDFuX",
        "expanded_url" : "http:\/\/abcn.ws\/2av9kaR",
        "display_url" : "abcn.ws\/2av9kaR"
      } ]
    },
    "geo" : { },
    "id_str" : "758276006008545281",
    "text" : "75-pound pet tortoise reunited with family in CA after he was discovered fleeing wildfires. https:\/\/t.co\/hzEv8jDFuX https:\/\/t.co\/fXFyRRMLVE",
    "id" : 758276006008545281,
    "created_at" : "2016-07-27 12:21:02 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658688193651277824\/Kv_cNNub_normal.png",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 758476696161030144,
  "created_at" : "2016-07-28 01:38:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWG",
      "screen_name" : "WWG",
      "indices" : [ 3, 7 ],
      "id_str" : "52216611",
      "id" : 52216611
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WWG\/status\/758446785702555648\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/PkvzBcYEeR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaLRbWUAAAB8l7.jpg",
      "id_str" : "758446718773886976",
      "id" : 758446718773886976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaLRbWUAAAB8l7.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 655
      } ],
      "display_url" : "pic.twitter.com\/PkvzBcYEeR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/RR2dE48LnF",
      "expanded_url" : "http:\/\/bit.ly\/2ai27vI",
      "display_url" : "bit.ly\/2ai27vI"
    } ]
  },
  "geo" : { },
  "id_str" : "758452497090502656",
  "text" : "RT @WWG: Someone Is Using A Real Chicken To Hatch POKEMON GO Eggs -https:\/\/t.co\/RR2dE48LnF https:\/\/t.co\/PkvzBcYEeR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WWG\/status\/758446785702555648\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/PkvzBcYEeR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaLRbWUAAAB8l7.jpg",
        "id_str" : "758446718773886976",
        "id" : 758446718773886976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaLRbWUAAAB8l7.jpg",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 655
        } ],
        "display_url" : "pic.twitter.com\/PkvzBcYEeR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/RR2dE48LnF",
        "expanded_url" : "http:\/\/bit.ly\/2ai27vI",
        "display_url" : "bit.ly\/2ai27vI"
      } ]
    },
    "geo" : { },
    "id_str" : "758446785702555648",
    "text" : "Someone Is Using A Real Chicken To Hatch POKEMON GO Eggs -https:\/\/t.co\/RR2dE48LnF https:\/\/t.co\/PkvzBcYEeR",
    "id" : 758446785702555648,
    "created_at" : "2016-07-27 23:39:39 +0000",
    "user" : {
      "name" : "WWG",
      "screen_name" : "WWG",
      "protected" : false,
      "id_str" : "52216611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753298592496955393\/qusxJxmj_normal.jpg",
      "id" : 52216611,
      "verified" : true
    }
  },
  "id" : 758452497090502656,
  "created_at" : "2016-07-28 00:02:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jermaine Spradley",
      "screen_name" : "MrSpradley",
      "indices" : [ 3, 14 ],
      "id_str" : "33410854",
      "id" : 33410854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758408305123454980",
  "text" : "RT @MrSpradley: Freddie Gray high energy injured himself to death and slaves were well fed and had decent lodging. Tuesday's off to a great\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758307189362683904",
    "text" : "Freddie Gray high energy injured himself to death and slaves were well fed and had decent lodging. Tuesday's off to a great start.",
    "id" : 758307189362683904,
    "created_at" : "2016-07-27 14:24:57 +0000",
    "user" : {
      "name" : "Jermaine Spradley",
      "screen_name" : "MrSpradley",
      "protected" : false,
      "id_str" : "33410854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774198114974572544\/E5lL78Pp_normal.jpg",
      "id" : 33410854,
      "verified" : true
    }
  },
  "id" : 758408305123454980,
  "created_at" : "2016-07-27 21:06:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758408081525080064",
  "text" : "RT @ZachsMind: The Two Different Americas ppl claim exist are beginning to crash into each other while standing still that's what.  https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Nby8HC2myu",
        "expanded_url" : "https:\/\/twitter.com\/chrislhayes\/status\/758401126815322113",
        "display_url" : "twitter.com\/chrislhayes\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758402137655156737",
    "text" : "The Two Different Americas ppl claim exist are beginning to crash into each other while standing still that's what.  https:\/\/t.co\/Nby8HC2myu",
    "id" : 758402137655156737,
    "created_at" : "2016-07-27 20:42:14 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 758408081525080064,
  "created_at" : "2016-07-27 21:05:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758354241656356864",
  "geo" : { },
  "id_str" : "758355065048592384",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides now I want a smoothie darnit..lol",
  "id" : 758355065048592384,
  "in_reply_to_status_id" : 758354241656356864,
  "created_at" : "2016-07-27 17:35:11 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Android Authority",
      "screen_name" : "AndroidAuth",
      "indices" : [ 3, 15 ],
      "id_str" : "95438524",
      "id" : 95438524
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AndroidAuth\/status\/758350678804791296\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/jAEI52RhuP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYz69AWcAAirxm.jpg",
      "id_str" : "758350675159969792",
      "id" : 758350675159969792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYz69AWcAAirxm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 840
      } ],
      "display_url" : "pic.twitter.com\/jAEI52RhuP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/NqqtqmYjTL",
      "expanded_url" : "http:\/\/goo.gl\/x3feOI",
      "display_url" : "goo.gl\/x3feOI"
    } ]
  },
  "geo" : { },
  "id_str" : "758354395146948608",
  "text" : "RT @AndroidAuth: Pok\u00E9mon Go Plus delayed till September https:\/\/t.co\/NqqtqmYjTL https:\/\/t.co\/jAEI52RhuP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.androidauthority.com\" rel=\"nofollow\"\u003EAndroidAuth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AndroidAuth\/status\/758350678804791296\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/jAEI52RhuP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYz69AWcAAirxm.jpg",
        "id_str" : "758350675159969792",
        "id" : 758350675159969792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYz69AWcAAirxm.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 840
        } ],
        "display_url" : "pic.twitter.com\/jAEI52RhuP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/NqqtqmYjTL",
        "expanded_url" : "http:\/\/goo.gl\/x3feOI",
        "display_url" : "goo.gl\/x3feOI"
      } ]
    },
    "geo" : { },
    "id_str" : "758350678804791296",
    "text" : "Pok\u00E9mon Go Plus delayed till September https:\/\/t.co\/NqqtqmYjTL https:\/\/t.co\/jAEI52RhuP",
    "id" : 758350678804791296,
    "created_at" : "2016-07-27 17:17:45 +0000",
    "user" : {
      "name" : "Android Authority",
      "screen_name" : "AndroidAuth",
      "protected" : false,
      "id_str" : "95438524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651260268236812289\/vbpawQ35_normal.png",
      "id" : 95438524,
      "verified" : true
    }
  },
  "id" : 758354395146948608,
  "created_at" : "2016-07-27 17:32:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758333601767391232",
  "geo" : { },
  "id_str" : "758353924944498688",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides alright, i suppose. heat's making all of us cranky, tho. gah.",
  "id" : 758353924944498688,
  "in_reply_to_status_id" : 758333601767391232,
  "created_at" : "2016-07-27 17:30:39 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/758252064199864321\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/bX0oPZ4rX6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXaN9TWcAAmqKx.jpg",
      "id_str" : "758252045610676224",
      "id" : 758252045610676224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXaN9TWcAAmqKx.jpg",
      "sizes" : [ {
        "h" : 838,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1430,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1430,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/bX0oPZ4rX6"
    } ],
    "hashtags" : [ {
      "text" : "WildlifeWednesday",
      "indices" : [ 44, 62 ]
    }, {
      "text" : "insects",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "damselfly",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "photography",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758327842329468928",
  "text" : "RT @missmuckyduck: Reflection on the water.\n#WildlifeWednesday #insects #damselfly #photography https:\/\/t.co\/bX0oPZ4rX6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/758252064199864321\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/bX0oPZ4rX6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXaN9TWcAAmqKx.jpg",
        "id_str" : "758252045610676224",
        "id" : 758252045610676224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXaN9TWcAAmqKx.jpg",
        "sizes" : [ {
          "h" : 838,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1430,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1430,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/bX0oPZ4rX6"
      } ],
      "hashtags" : [ {
        "text" : "WildlifeWednesday",
        "indices" : [ 25, 43 ]
      }, {
        "text" : "insects",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "damselfly",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "photography",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758252064199864321",
    "text" : "Reflection on the water.\n#WildlifeWednesday #insects #damselfly #photography https:\/\/t.co\/bX0oPZ4rX6",
    "id" : 758252064199864321,
    "created_at" : "2016-07-27 10:45:54 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 758327842329468928,
  "created_at" : "2016-07-27 15:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter",
      "screen_name" : "woodcarver_t",
      "indices" : [ 3, 16 ],
      "id_str" : "831927198",
      "id" : 831927198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/758069020671275009\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/bKS0CyOibm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUzv5QXgAAAxJt.jpg",
      "id_str" : "758069010198134784",
      "id" : 758069010198134784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUzv5QXgAAAxJt.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 871,
        "resize" : "fit",
        "w" : 1534
      }, {
        "h" : 871,
        "resize" : "fit",
        "w" : 1534
      } ],
      "display_url" : "pic.twitter.com\/bKS0CyOibm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/758069020671275009\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/bKS0CyOibm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUzv5PXYAAuqJm.jpg",
      "id_str" : "758069010193932288",
      "id" : 758069010193932288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUzv5PXYAAuqJm.jpg",
      "sizes" : [ {
        "h" : 462,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 967,
        "resize" : "fit",
        "w" : 1422
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 967,
        "resize" : "fit",
        "w" : 1422
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bKS0CyOibm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/758069020671275009\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/bKS0CyOibm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUzv5RXgAEZLx7.jpg",
      "id_str" : "758069010202329089",
      "id" : 758069010202329089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUzv5RXgAEZLx7.jpg",
      "sizes" : [ {
        "h" : 942,
        "resize" : "fit",
        "w" : 1510
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 942,
        "resize" : "fit",
        "w" : 1510
      } ],
      "display_url" : "pic.twitter.com\/bKS0CyOibm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758305151996362754",
  "text" : "RT @woodcarver_t: The bobbin mouse &amp; cheese mice before they moved on &amp; at they'r new home.\uD83D\uDE0E\uD83D\uDC2D https:\/\/t.co\/bKS0CyOibm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/758069020671275009\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/bKS0CyOibm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUzv5QXgAAAxJt.jpg",
        "id_str" : "758069010198134784",
        "id" : 758069010198134784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUzv5QXgAAAxJt.jpg",
        "sizes" : [ {
          "h" : 386,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 871,
          "resize" : "fit",
          "w" : 1534
        }, {
          "h" : 871,
          "resize" : "fit",
          "w" : 1534
        } ],
        "display_url" : "pic.twitter.com\/bKS0CyOibm"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/758069020671275009\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/bKS0CyOibm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUzv5PXYAAuqJm.jpg",
        "id_str" : "758069010193932288",
        "id" : 758069010193932288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUzv5PXYAAuqJm.jpg",
        "sizes" : [ {
          "h" : 462,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 967,
          "resize" : "fit",
          "w" : 1422
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 967,
          "resize" : "fit",
          "w" : 1422
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/bKS0CyOibm"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/758069020671275009\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/bKS0CyOibm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUzv5RXgAEZLx7.jpg",
        "id_str" : "758069010202329089",
        "id" : 758069010202329089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUzv5RXgAEZLx7.jpg",
        "sizes" : [ {
          "h" : 942,
          "resize" : "fit",
          "w" : 1510
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 942,
          "resize" : "fit",
          "w" : 1510
        } ],
        "display_url" : "pic.twitter.com\/bKS0CyOibm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758069020671275009",
    "text" : "The bobbin mouse &amp; cheese mice before they moved on &amp; at they'r new home.\uD83D\uDE0E\uD83D\uDC2D https:\/\/t.co\/bKS0CyOibm",
    "id" : 758069020671275009,
    "created_at" : "2016-07-26 22:38:33 +0000",
    "user" : {
      "name" : "Peter",
      "screen_name" : "woodcarver_t",
      "protected" : false,
      "id_str" : "831927198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796487744113508352\/1ui6JNzH_normal.jpg",
      "id" : 831927198,
      "verified" : false
    }
  },
  "id" : 758305151996362754,
  "created_at" : "2016-07-27 14:16:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758304692325773312",
  "text" : "RT @CatskillCritter: Beloved horse chestnut tree, home to many nesting birds, emerging from morning mists in the summer #Catskills. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/758270143432691712\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/3JPmpj38Yj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXqqxpW8AEns9Z.jpg",
        "id_str" : "758270132884008961",
        "id" : 758270132884008961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXqqxpW8AEns9Z.jpg",
        "sizes" : [ {
          "h" : 708,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 531
        } ],
        "display_url" : "pic.twitter.com\/3JPmpj38Yj"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758270143432691712",
    "text" : "Beloved horse chestnut tree, home to many nesting birds, emerging from morning mists in the summer #Catskills. https:\/\/t.co\/3JPmpj38Yj",
    "id" : 758270143432691712,
    "created_at" : "2016-07-27 11:57:44 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 758304692325773312,
  "created_at" : "2016-07-27 14:15:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758285313005457408",
  "geo" : { },
  "id_str" : "758294141528862720",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves ((hugs))",
  "id" : 758294141528862720,
  "in_reply_to_status_id" : 758285313005457408,
  "created_at" : "2016-07-27 13:33:06 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrankyPappy\uD83C\uDDE8\uD83C\uDDE6\uD83C\uDCCF\uD83D\uDCDA",
      "screen_name" : "CrankyPappy",
      "indices" : [ 3, 15 ],
      "id_str" : "241273903",
      "id" : 241273903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758079790582824960",
  "text" : "RT @CrankyPappy: When we were kids, we all thought we would grow up &amp; figure it out. Then we all grew up &amp; didn't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758072688548188162",
    "text" : "When we were kids, we all thought we would grow up &amp; figure it out. Then we all grew up &amp; didn't.",
    "id" : 758072688548188162,
    "created_at" : "2016-07-26 22:53:07 +0000",
    "user" : {
      "name" : "CrankyPappy\uD83C\uDDE8\uD83C\uDDE6\uD83C\uDCCF\uD83D\uDCDA",
      "screen_name" : "CrankyPappy",
      "protected" : false,
      "id_str" : "241273903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801059567580889088\/hyCKZGfb_normal.jpg",
      "id" : 241273903,
      "verified" : false
    }
  },
  "id" : 758079790582824960,
  "created_at" : "2016-07-26 23:21:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 22, 33 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758079663528968192",
  "text" : "RT @aliceinthewater: .@SenSanders has been full of grace and kindness. I'm so proud he's a Senator.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Sanders",
        "screen_name" : "SenSanders",
        "indices" : [ 1, 12 ],
        "id_str" : "29442313",
        "id" : 29442313
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758075541563990017",
    "text" : ".@SenSanders has been full of grace and kindness. I'm so proud he's a Senator.",
    "id" : 758075541563990017,
    "created_at" : "2016-07-26 23:04:28 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 758079663528968192,
  "created_at" : "2016-07-26 23:20:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "indices" : [ 3, 15 ],
      "id_str" : "14873767",
      "id" : 14873767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/mCyyx4Qt5R",
      "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/758071952498159616",
      "display_url" : "twitter.com\/realDonaldTrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758074915518046208",
  "text" : "RT @DanteAtkins: Dude the question is, how much has Russia invested in you https:\/\/t.co\/mCyyx4Qt5R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/mCyyx4Qt5R",
        "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/758071952498159616",
        "display_url" : "twitter.com\/realDonaldTrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758073708070117376",
    "text" : "Dude the question is, how much has Russia invested in you https:\/\/t.co\/mCyyx4Qt5R",
    "id" : 758073708070117376,
    "created_at" : "2016-07-26 22:57:10 +0000",
    "user" : {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "protected" : false,
      "id_str" : "14873767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466040900196372480\/uSZa77kS_normal.jpeg",
      "id" : 14873767,
      "verified" : true
    }
  },
  "id" : 758074915518046208,
  "created_at" : "2016-07-26 23:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Koi Fresco",
      "screen_name" : "koifresco",
      "indices" : [ 3, 13 ],
      "id_str" : "1857947658",
      "id" : 1857947658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758074360691384320",
  "text" : "RT @koifresco: the best thing that can happen to us is having our views challenged. it wakes us from our illusion. makes us think again. it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "757632215186485248",
    "geo" : { },
    "id_str" : "757632977484394496",
    "in_reply_to_user_id" : 1857947658,
    "text" : "the best thing that can happen to us is having our views challenged. it wakes us from our illusion. makes us think again. it helps us grow.",
    "id" : 757632977484394496,
    "in_reply_to_status_id" : 757632215186485248,
    "created_at" : "2016-07-25 17:45:52 +0000",
    "in_reply_to_screen_name" : "koifresco",
    "in_reply_to_user_id_str" : "1857947658",
    "user" : {
      "name" : "Koi Fresco",
      "screen_name" : "koifresco",
      "protected" : false,
      "id_str" : "1857947658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800859325132480512\/7nsejbdH_normal.jpg",
      "id" : 1857947658,
      "verified" : false
    }
  },
  "id" : 758074360691384320,
  "created_at" : "2016-07-26 22:59:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sparklekaz\/status\/758073377290608640\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/3eITTOB7l7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoU3sezWEAQOnyF.jpg",
      "id_str" : "758073349603987460",
      "id" : 758073349603987460,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoU3sezWEAQOnyF.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 942,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 942,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 942,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/3eITTOB7l7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758073682916941825",
  "text" : "RT @sparklekaz: Be a reflection of what you'd like to receive. If you want love, give love.... https:\/\/t.co\/3eITTOB7l7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sparklekaz\/status\/758073377290608640\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/3eITTOB7l7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoU3sezWEAQOnyF.jpg",
        "id_str" : "758073349603987460",
        "id" : 758073349603987460,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoU3sezWEAQOnyF.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 942,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 942,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 942,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/3eITTOB7l7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758073377290608640",
    "text" : "Be a reflection of what you'd like to receive. If you want love, give love.... https:\/\/t.co\/3eITTOB7l7",
    "id" : 758073377290608640,
    "created_at" : "2016-07-26 22:55:52 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 758073682916941825,
  "created_at" : "2016-07-26 22:57:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Pastures",
      "screen_name" : "HopePastures",
      "indices" : [ 3, 16 ],
      "id_str" : "617917883",
      "id" : 617917883
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tongueouttuesday",
      "indices" : [ 45, 62 ]
    }, {
      "text" : "Leeds",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/DX1jSN70Ux",
      "expanded_url" : "http:\/\/www.hopepastures.org",
      "display_url" : "hopepastures.org"
    } ]
  },
  "geo" : { },
  "id_str" : "758055557630746624",
  "text" : "RT @HopePastures: Everyone loves a salt lick #tongueouttuesday we are open everyday free admission\nhttps:\/\/t.co\/DX1jSN70Ux #Leeds https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/757840182548701184\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/jmoJPHRCEP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoRjh8QVUAAg43Q.jpg",
        "id_str" : "757840072066551808",
        "id" : 757840072066551808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoRjh8QVUAAg43Q.jpg",
        "sizes" : [ {
          "h" : 585,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 388
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/jmoJPHRCEP"
      } ],
      "hashtags" : [ {
        "text" : "tongueouttuesday",
        "indices" : [ 27, 44 ]
      }, {
        "text" : "Leeds",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/DX1jSN70Ux",
        "expanded_url" : "http:\/\/www.hopepastures.org",
        "display_url" : "hopepastures.org"
      } ]
    },
    "geo" : { },
    "id_str" : "757840182548701184",
    "text" : "Everyone loves a salt lick #tongueouttuesday we are open everyday free admission\nhttps:\/\/t.co\/DX1jSN70Ux #Leeds https:\/\/t.co\/jmoJPHRCEP",
    "id" : 757840182548701184,
    "created_at" : "2016-07-26 07:29:14 +0000",
    "user" : {
      "name" : "Hope Pastures",
      "screen_name" : "HopePastures",
      "protected" : false,
      "id_str" : "617917883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2340198212\/4xpqgnrt1uxlwp6mpcui_normal.jpeg",
      "id" : 617917883,
      "verified" : false
    }
  },
  "id" : 758055557630746624,
  "created_at" : "2016-07-26 21:45:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758045574855856128",
  "text" : "umm.. whats going on at DNC? they're talking about nominating Bernie?",
  "id" : 758045574855856128,
  "created_at" : "2016-07-26 21:05:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "indices" : [ 3, 14 ],
      "id_str" : "2441608651",
      "id" : 2441608651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/757953402437373952\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/KRUzTDNLbI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTKIVLUMAAKeMm.jpg",
      "id_str" : "757952881777455104",
      "id" : 757952881777455104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTKIVLUMAAKeMm.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1973,
        "resize" : "fit",
        "w" : 2890
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1398,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/KRUzTDNLbI"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 31, 37 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758029736186634240",
  "text" : "RT @mido3bitte: feel sleepy... #birds #wildlife https:\/\/t.co\/KRUzTDNLbI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/757953402437373952\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/KRUzTDNLbI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTKIVLUMAAKeMm.jpg",
        "id_str" : "757952881777455104",
        "id" : 757952881777455104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTKIVLUMAAKeMm.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1973,
          "resize" : "fit",
          "w" : 2890
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1398,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/KRUzTDNLbI"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 15, 21 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 22, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757953402437373952",
    "text" : "feel sleepy... #birds #wildlife https:\/\/t.co\/KRUzTDNLbI",
    "id" : 757953402437373952,
    "created_at" : "2016-07-26 14:59:07 +0000",
    "user" : {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "protected" : false,
      "id_str" : "2441608651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746727881498206208\/tfRux6Hm_normal.jpg",
      "id" : 2441608651,
      "verified" : false
    }
  },
  "id" : 758029736186634240,
  "created_at" : "2016-07-26 20:02:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/757974202788024320\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1ARZpe3kD1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTdhImWgAAqdkK.jpg",
      "id_str" : "757974198618849280",
      "id" : 757974198618849280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTdhImWgAAqdkK.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/1ARZpe3kD1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/1pBZtKuSbN",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nolongerquivering\/2016\/07\/quoting-quiverfull-homeschool-your-children-even-if-you-arent-educated\/?_ts=1469550100#comment-2803364574",
      "display_url" : "patheos.com\/blogs\/nolonger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757974202788024320",
  "text" : "Quoting Quiverfull: Homeschool Your Children Even if You Aren't Educated? https:\/\/t.co\/1pBZtKuSbN https:\/\/t.co\/1ARZpe3kD1",
  "id" : 757974202788024320,
  "created_at" : "2016-07-26 16:21:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 62, 76 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/nVE3DGlnQg",
      "expanded_url" : "https:\/\/shar.es\/1Zp0XH",
      "display_url" : "shar.es\/1Zp0XH"
    } ]
  },
  "geo" : { },
  "id_str" : "757972056143200256",
  "text" : "A Close Encounter of the Ark Kind https:\/\/t.co\/nVE3DGlnQg via @UnfundieXians",
  "id" : 757972056143200256,
  "created_at" : "2016-07-26 16:13:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farm on the Heath",
      "screen_name" : "NatashaBaker28",
      "indices" : [ 3, 18 ],
      "id_str" : "745165629905215488",
      "id" : 745165629905215488
    }, {
      "name" : "TongueOutCoosday",
      "screen_name" : "tongueoutcoos",
      "indices" : [ 22, 36 ],
      "id_str" : "4783458341",
      "id" : 4783458341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NatashaBaker28\/status\/757875556268539904\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/O7XLw9Ezln",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoSDuCnXYAAygB7.jpg",
      "id_str" : "757875464304287744",
      "id" : 757875464304287744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoSDuCnXYAAygB7.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/O7XLw9Ezln"
    } ],
    "hashtags" : [ {
      "text" : "tongueoutcoos",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757954803515453440",
  "text" : "RT @NatashaBaker28: \uD83D\uDC45 @tongueoutcoos #tongueoutcoos https:\/\/t.co\/O7XLw9Ezln",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TongueOutCoosday",
        "screen_name" : "tongueoutcoos",
        "indices" : [ 2, 16 ],
        "id_str" : "4783458341",
        "id" : 4783458341
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatashaBaker28\/status\/757875556268539904\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/O7XLw9Ezln",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoSDuCnXYAAygB7.jpg",
        "id_str" : "757875464304287744",
        "id" : 757875464304287744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoSDuCnXYAAygB7.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/O7XLw9Ezln"
      } ],
      "hashtags" : [ {
        "text" : "tongueoutcoos",
        "indices" : [ 17, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757875556268539904",
    "text" : "\uD83D\uDC45 @tongueoutcoos #tongueoutcoos https:\/\/t.co\/O7XLw9Ezln",
    "id" : 757875556268539904,
    "created_at" : "2016-07-26 09:49:47 +0000",
    "user" : {
      "name" : "Farm on the Heath",
      "screen_name" : "NatashaBaker28",
      "protected" : false,
      "id_str" : "745165629905215488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774900474495561728\/q1SR7GVg_normal.jpg",
      "id" : 745165629905215488,
      "verified" : false
    }
  },
  "id" : 757954803515453440,
  "created_at" : "2016-07-26 15:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/757756148011438080\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/zQhKeHKnLx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoQXMEGWYAI4Dv6.jpg",
      "id_str" : "757756133331329026",
      "id" : 757756133331329026,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoQXMEGWYAI4Dv6.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zQhKeHKnLx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757759527156580352",
  "text" : "RT @dwaynereaves: Anyone care to take a walk down the railroad tracks? Don't worry, not a very active track. https:\/\/t.co\/zQhKeHKnLx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/757756148011438080\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/zQhKeHKnLx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoQXMEGWYAI4Dv6.jpg",
        "id_str" : "757756133331329026",
        "id" : 757756133331329026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoQXMEGWYAI4Dv6.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/zQhKeHKnLx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757756148011438080",
    "text" : "Anyone care to take a walk down the railroad tracks? Don't worry, not a very active track. https:\/\/t.co\/zQhKeHKnLx",
    "id" : 757756148011438080,
    "created_at" : "2016-07-26 01:55:18 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 757759527156580352,
  "created_at" : "2016-07-26 02:08:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JuanPa",
      "screen_name" : "jpbrammer",
      "indices" : [ 3, 13 ],
      "id_str" : "74087670",
      "id" : 74087670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757756050116345856",
  "text" : "RT @jpbrammer: I am left of Hillary. But I understand that under Hillary I will be able to fight for what I believe in. Trump WILL silence\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "757741493696143360",
    "geo" : { },
    "id_str" : "757741628660428800",
    "in_reply_to_user_id" : 74087670,
    "text" : "I am left of Hillary. But I understand that under Hillary I will be able to fight for what I believe in. Trump WILL silence me and others.",
    "id" : 757741628660428800,
    "in_reply_to_status_id" : 757741493696143360,
    "created_at" : "2016-07-26 00:57:37 +0000",
    "in_reply_to_screen_name" : "jpbrammer",
    "in_reply_to_user_id_str" : "74087670",
    "user" : {
      "name" : "JuanPa",
      "screen_name" : "jpbrammer",
      "protected" : false,
      "id_str" : "74087670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771090928899612676\/nwGpl8kw_normal.jpg",
      "id" : 74087670,
      "verified" : true
    }
  },
  "id" : 757756050116345856,
  "created_at" : "2016-07-26 01:54:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dose Animals",
      "screen_name" : "DoseofAnimals",
      "indices" : [ 3, 17 ],
      "id_str" : "184651802",
      "id" : 184651802
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DoseofAnimals\/status\/757743445943455744\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/6YL4mFsVDs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoQLpVtWIAAPChA.jpg",
      "id_str" : "757743442134966272",
      "id" : 757743442134966272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoQLpVtWIAAPChA.jpg",
      "sizes" : [ {
        "h" : 477,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/6YL4mFsVDs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757755850278789120",
  "text" : "RT @DoseofAnimals: Commence snuggles! https:\/\/t.co\/6YL4mFsVDs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DoseofAnimals\/status\/757743445943455744\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/6YL4mFsVDs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoQLpVtWIAAPChA.jpg",
        "id_str" : "757743442134966272",
        "id" : 757743442134966272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoQLpVtWIAAPChA.jpg",
        "sizes" : [ {
          "h" : 477,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/6YL4mFsVDs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757743445943455744",
    "text" : "Commence snuggles! https:\/\/t.co\/6YL4mFsVDs",
    "id" : 757743445943455744,
    "created_at" : "2016-07-26 01:04:50 +0000",
    "user" : {
      "name" : "Dose Animals",
      "screen_name" : "DoseofAnimals",
      "protected" : false,
      "id_str" : "184651802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705416109495709696\/0rNJfZMZ_normal.jpg",
      "id" : 184651802,
      "verified" : false
    }
  },
  "id" : 757755850278789120,
  "created_at" : "2016-07-26 01:54:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757714809496346625",
  "geo" : { },
  "id_str" : "757715772114362368",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time mmmm.. ((drools))",
  "id" : 757715772114362368,
  "in_reply_to_status_id" : 757714809496346625,
  "created_at" : "2016-07-25 23:14:52 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Beavan",
      "screen_name" : "KateBeavan",
      "indices" : [ 3, 14 ],
      "id_str" : "456109958",
      "id" : 456109958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KateBeavan\/status\/757705142598852609\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Mv3tN91Mpn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoPoyGZWYAAI-MT.jpg",
      "id_str" : "757705109736415232",
      "id" : 757705109736415232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoPoyGZWYAAI-MT.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Mv3tN91Mpn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757712918758748160",
  "text" : "RT @KateBeavan: Skirrid (Holy) Mountain. https:\/\/t.co\/Mv3tN91Mpn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KateBeavan\/status\/757705142598852609\/photo\/1",
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/Mv3tN91Mpn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoPoyGZWYAAI-MT.jpg",
        "id_str" : "757705109736415232",
        "id" : 757705109736415232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoPoyGZWYAAI-MT.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/Mv3tN91Mpn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757705142598852609",
    "text" : "Skirrid (Holy) Mountain. https:\/\/t.co\/Mv3tN91Mpn",
    "id" : 757705142598852609,
    "created_at" : "2016-07-25 22:32:38 +0000",
    "user" : {
      "name" : "Kate Beavan",
      "screen_name" : "KateBeavan",
      "protected" : false,
      "id_str" : "456109958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554389378672242688\/Nus1YdSY_normal.jpeg",
      "id" : 456109958,
      "verified" : false
    }
  },
  "id" : 757712918758748160,
  "created_at" : "2016-07-25 23:03:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757640408679735301",
  "text" : "if you pray, plz pray 4 my brother. we're not close but he's having a really tough time. thx.",
  "id" : 757640408679735301,
  "created_at" : "2016-07-25 18:15:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/PJLyVwD2UU",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/757576607515209728",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757598385352372226",
  "text" : "kindness can and does change the world. https:\/\/t.co\/PJLyVwD2UU",
  "id" : 757598385352372226,
  "created_at" : "2016-07-25 15:28:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757587449564377088",
  "geo" : { },
  "id_str" : "757597434948255744",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 me, too!",
  "id" : 757597434948255744,
  "in_reply_to_status_id" : 757587449564377088,
  "created_at" : "2016-07-25 15:24:38 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farms Of The World",
      "screen_name" : "FarmsOfTheWorld",
      "indices" : [ 3, 19 ],
      "id_str" : "4474023375",
      "id" : 4474023375
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FarmsOfTheWorld\/status\/757529307866603520\/video\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/3nmqvatM1A",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/757528860674166784\/pu\/img\/g873zzwuVcOLimxm.jpg",
      "id_str" : "757528860674166784",
      "id" : 757528860674166784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/757528860674166784\/pu\/img\/g873zzwuVcOLimxm.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3nmqvatM1A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757597333890760706",
  "text" : "RT @FarmsOfTheWorld: Full Ladybug in alfalfa https:\/\/t.co\/3nmqvatM1A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmsOfTheWorld\/status\/757529307866603520\/video\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/3nmqvatM1A",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/757528860674166784\/pu\/img\/g873zzwuVcOLimxm.jpg",
        "id_str" : "757528860674166784",
        "id" : 757528860674166784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/757528860674166784\/pu\/img\/g873zzwuVcOLimxm.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3nmqvatM1A"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "757499363795042304",
    "geo" : { },
    "id_str" : "757529307866603520",
    "in_reply_to_user_id" : 4474023375,
    "text" : "Full Ladybug in alfalfa https:\/\/t.co\/3nmqvatM1A",
    "id" : 757529307866603520,
    "in_reply_to_status_id" : 757499363795042304,
    "created_at" : "2016-07-25 10:53:55 +0000",
    "in_reply_to_screen_name" : "FarmsOfTheWorld",
    "in_reply_to_user_id_str" : "4474023375",
    "user" : {
      "name" : "Farms Of The World",
      "screen_name" : "FarmsOfTheWorld",
      "protected" : false,
      "id_str" : "4474023375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798075678981816320\/QZeENBzh_normal.jpg",
      "id" : 4474023375,
      "verified" : false
    }
  },
  "id" : 757597333890760706,
  "created_at" : "2016-07-25 15:24:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Pickering \u27B0",
      "screen_name" : "philip_pbm339",
      "indices" : [ 3, 17 ],
      "id_str" : "752868295",
      "id" : 752868295
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/philip_pbm339\/status\/757199324929519617\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/CWqtTi2bUE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoIcxRhXEAE0jay.jpg",
      "id_str" : "757199320194158593",
      "id" : 757199320194158593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoIcxRhXEAE0jay.jpg",
      "sizes" : [ {
        "h" : 539,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CWqtTi2bUE"
    } ],
    "hashtags" : [ {
      "text" : "harvest16",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757327031835164672",
  "text" : "RT @philip_pbm339: Harvesting rainbows\uD83C\uDF08 #harvest16 https:\/\/t.co\/CWqtTi2bUE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/philip_pbm339\/status\/757199324929519617\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/CWqtTi2bUE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoIcxRhXEAE0jay.jpg",
        "id_str" : "757199320194158593",
        "id" : 757199320194158593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoIcxRhXEAE0jay.jpg",
        "sizes" : [ {
          "h" : 539,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CWqtTi2bUE"
      } ],
      "hashtags" : [ {
        "text" : "harvest16",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757199324929519617",
    "text" : "Harvesting rainbows\uD83C\uDF08 #harvest16 https:\/\/t.co\/CWqtTi2bUE",
    "id" : 757199324929519617,
    "created_at" : "2016-07-24 13:02:41 +0000",
    "user" : {
      "name" : "Philip Pickering \u27B0",
      "screen_name" : "philip_pbm339",
      "protected" : false,
      "id_str" : "752868295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741991850505056256\/RUjck7Wx_normal.jpg",
      "id" : 752868295,
      "verified" : false
    }
  },
  "id" : 757327031835164672,
  "created_at" : "2016-07-24 21:30:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian E. Niskala",
      "screen_name" : "Rhinehoth",
      "indices" : [ 53, 63 ],
      "id_str" : "100575612",
      "id" : 100575612
    }, {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 64, 77 ],
      "id_str" : "457997266",
      "id" : 457997266
    }, {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 78, 89 ],
      "id_str" : "87207875",
      "id" : 87207875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horror",
      "indices" : [ 8, 15 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7X4A3MNFd0",
      "expanded_url" : "https:\/\/audiobookreviewer.com\/reviews\/rhinehoth-brian-e-niskala\/",
      "display_url" : "audiobookreviewer.com\/reviews\/rhineh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757287001846611968",
  "text" : "Win the #horror #audiobook #giveaway of Rhinehoth by @Rhinehoth @audiobookrev @SimonAudio https:\/\/t.co\/7X4A3MNFd0",
  "id" : 757287001846611968,
  "created_at" : "2016-07-24 18:51:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "indices" : [ 3, 17 ],
      "id_str" : "255780065",
      "id" : 255780065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757285554883006465",
  "text" : "RT @Crowtographer: These lovelies are as curious of me as I am of them. There was lots of soft crow chatter and great eye contact. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Crowtographer\/status\/757232890186829825\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/22jV2c49OS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoI7TC4VUAInWN3.jpg",
        "id_str" : "757232885728366594",
        "id" : 757232885728366594,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoI7TC4VUAInWN3.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/22jV2c49OS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757232890186829825",
    "text" : "These lovelies are as curious of me as I am of them. There was lots of soft crow chatter and great eye contact. https:\/\/t.co\/22jV2c49OS",
    "id" : 757232890186829825,
    "created_at" : "2016-07-24 15:16:04 +0000",
    "user" : {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "protected" : false,
      "id_str" : "255780065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737547028062863361\/1tOrY86w_normal.jpg",
      "id" : 255780065,
      "verified" : false
    }
  },
  "id" : 757285554883006465,
  "created_at" : "2016-07-24 18:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 9, 25 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/xUdMdGKNgY",
      "expanded_url" : "https:\/\/twitter.com\/Honda\/status\/756624890720030721",
      "display_url" : "twitter.com\/Honda\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756673003837132801",
  "text" : "hey look @JourneyTheHedgi https:\/\/t.co\/xUdMdGKNgY",
  "id" : 756673003837132801,
  "created_at" : "2016-07-23 02:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Farms Of The World",
      "screen_name" : "FarmsOfTheWorld",
      "indices" : [ 17, 33 ],
      "id_str" : "4474023375",
      "id" : 4474023375
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HCYBQuNl4C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QSnXEAAM1rH.jpg",
      "id_str" : "756669888459116544",
      "id" : 756669888459116544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QSnXEAAM1rH.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HCYBQuNl4C"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HCYBQuNl4C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QS6XEAANOXN.jpg",
      "id_str" : "756669888538808320",
      "id" : 756669888538808320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QS6XEAANOXN.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HCYBQuNl4C"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HCYBQuNl4C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QTUXEAAl902.jpg",
      "id_str" : "756669888647860224",
      "id" : 756669888647860224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QTUXEAAl902.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/HCYBQuNl4C"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HCYBQuNl4C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QiEWAAAGOWX.jpg",
      "id_str" : "756669892607213568",
      "id" : 756669892607213568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QiEWAAAGOWX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/HCYBQuNl4C"
    } ],
    "hashtags" : [ {
      "text" : "FFF",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "Exmoor",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756672479628824577",
  "text" : "RT @newlandfarm: @FarmsOfTheWorld #FFF #Exmoor https:\/\/t.co\/HCYBQuNl4C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Farms Of The World",
        "screen_name" : "FarmsOfTheWorld",
        "indices" : [ 0, 16 ],
        "id_str" : "4474023375",
        "id" : 4474023375
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/HCYBQuNl4C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QSnXEAAM1rH.jpg",
        "id_str" : "756669888459116544",
        "id" : 756669888459116544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QSnXEAAM1rH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HCYBQuNl4C"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/HCYBQuNl4C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QS6XEAANOXN.jpg",
        "id_str" : "756669888538808320",
        "id" : 756669888538808320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QS6XEAANOXN.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HCYBQuNl4C"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/HCYBQuNl4C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QTUXEAAl902.jpg",
        "id_str" : "756669888647860224",
        "id" : 756669888647860224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QTUXEAAl902.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/HCYBQuNl4C"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/756669985087483905\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/HCYBQuNl4C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoA7QiEWAAAGOWX.jpg",
        "id_str" : "756669892607213568",
        "id" : 756669892607213568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoA7QiEWAAAGOWX.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/HCYBQuNl4C"
      } ],
      "hashtags" : [ {
        "text" : "FFF",
        "indices" : [ 17, 21 ]
      }, {
        "text" : "Exmoor",
        "indices" : [ 22, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756669985087483905",
    "in_reply_to_user_id" : 4474023375,
    "text" : "@FarmsOfTheWorld #FFF #Exmoor https:\/\/t.co\/HCYBQuNl4C",
    "id" : 756669985087483905,
    "created_at" : "2016-07-23 01:59:17 +0000",
    "in_reply_to_screen_name" : "FarmsOfTheWorld",
    "in_reply_to_user_id_str" : "4474023375",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 756672479628824577,
  "created_at" : "2016-07-23 02:09:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 3, 18 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756662273331126272",
  "text" : "RT @HillaryClinton: \"We need more love and kindness in this country...The last thing we need are leaders who try to divide us even more tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756611324596092928",
    "text" : "\"We need more love and kindness in this country...The last thing we need are leaders who try to divide us even more than we are.\" \u2014Hillary",
    "id" : 756611324596092928,
    "created_at" : "2016-07-22 22:06:11 +0000",
    "user" : {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "protected" : false,
      "id_str" : "1339835893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796243884636512260\/zHVoWqKV_normal.jpg",
      "id" : 1339835893,
      "verified" : true
    }
  },
  "id" : 756662273331126272,
  "created_at" : "2016-07-23 01:28:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Paul",
      "screen_name" : "Jeff_Journalist",
      "indices" : [ 3, 19 ],
      "id_str" : "17070745",
      "id" : 17070745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756662135749566465",
  "text" : "RT @Jeff_Journalist: 1 guy, 1 sign and 1 message. How these three words, \"Everybody Love Everybody,\" are capturing world interest, @ 10 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jeff_Journalist\/status\/756657770372427777\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ZCWEuOdIzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoAwNx0XEAAra_x.jpg",
        "id_str" : "756657750667628544",
        "id" : 756657750667628544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoAwNx0XEAAra_x.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ZCWEuOdIzI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756657770372427777",
    "text" : "1 guy, 1 sign and 1 message. How these three words, \"Everybody Love Everybody,\" are capturing world interest, @ 10 https:\/\/t.co\/ZCWEuOdIzI",
    "id" : 756657770372427777,
    "created_at" : "2016-07-23 01:10:45 +0000",
    "user" : {
      "name" : "Jeff Paul",
      "screen_name" : "Jeff_Journalist",
      "protected" : false,
      "id_str" : "17070745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560185674989461504\/_zWAikkD_normal.jpeg",
      "id" : 17070745,
      "verified" : true
    }
  },
  "id" : 756662135749566465,
  "created_at" : "2016-07-23 01:28:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    }, {
      "name" : "Shareaholic",
      "screen_name" : "Shareaholic",
      "indices" : [ 60, 72 ],
      "id_str" : "791635",
      "id" : 791635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/l1LjFuH0cP",
      "expanded_url" : "http:\/\/go.shr.lc\/2ai64mc",
      "display_url" : "go.shr.lc\/2ai64mc"
    } ]
  },
  "geo" : { },
  "id_str" : "756650820708536320",
  "text" : "RT @Mahala: Redefining Normal - https:\/\/t.co\/l1LjFuH0cP via @Shareaholic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shareaholic",
        "screen_name" : "Shareaholic",
        "indices" : [ 48, 60 ],
        "id_str" : "791635",
        "id" : 791635
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/l1LjFuH0cP",
        "expanded_url" : "http:\/\/go.shr.lc\/2ai64mc",
        "display_url" : "go.shr.lc\/2ai64mc"
      } ]
    },
    "geo" : { },
    "id_str" : "756644141916942336",
    "text" : "Redefining Normal - https:\/\/t.co\/l1LjFuH0cP via @Shareaholic",
    "id" : 756644141916942336,
    "created_at" : "2016-07-23 00:16:35 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 756650820708536320,
  "created_at" : "2016-07-23 00:43:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "West Wing Reports",
      "screen_name" : "WestWingReport",
      "indices" : [ 3, 18 ],
      "id_str" : "20182089",
      "id" : 20182089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756650240338456577",
  "text" : "RT @WestWingReport: The one thing about Kaine: people may disagree w\/his views - but he's almost universally seen as a nice man; genuinely\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756644059460964352",
    "text" : "The one thing about Kaine: people may disagree w\/his views - but he's almost universally seen as a nice man; genuinely a decent guy",
    "id" : 756644059460964352,
    "created_at" : "2016-07-23 00:16:16 +0000",
    "user" : {
      "name" : "West Wing Reports",
      "screen_name" : "WestWingReport",
      "protected" : false,
      "id_str" : "20182089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692726797197119488\/UEg5exR4_normal.png",
      "id" : 20182089,
      "verified" : true
    }
  },
  "id" : 756650240338456577,
  "created_at" : "2016-07-23 00:40:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne A.",
      "screen_name" : "LynneElmira",
      "indices" : [ 3, 15 ],
      "id_str" : "23255171",
      "id" : 23255171
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LynneElmira\/status\/756637807464939522\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/D3p1QqNWvE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoAeANJWYAEpcJJ.jpg",
      "id_str" : "756637726275952641",
      "id" : 756637726275952641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoAeANJWYAEpcJJ.jpg",
      "sizes" : [ {
        "h" : 596,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/D3p1QqNWvE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756641950900641793",
  "text" : "RT @LynneElmira: Molly Dean  photo https:\/\/t.co\/D3p1QqNWvE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LynneElmira\/status\/756637807464939522\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/D3p1QqNWvE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoAeANJWYAEpcJJ.jpg",
        "id_str" : "756637726275952641",
        "id" : 756637726275952641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoAeANJWYAEpcJJ.jpg",
        "sizes" : [ {
          "h" : 596,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/D3p1QqNWvE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756637807464939522",
    "text" : "Molly Dean  photo https:\/\/t.co\/D3p1QqNWvE",
    "id" : 756637807464939522,
    "created_at" : "2016-07-22 23:51:25 +0000",
    "user" : {
      "name" : "Lynne A.",
      "screen_name" : "LynneElmira",
      "protected" : false,
      "id_str" : "23255171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125797710\/YELLOW_ROSE_normal.jpg",
      "id" : 23255171,
      "verified" : false
    }
  },
  "id" : 756641950900641793,
  "created_at" : "2016-07-23 00:07:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "indices" : [ 3, 15 ],
      "id_str" : "519836839",
      "id" : 519836839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "quotes",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "kelpiewisdom",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756637078037917696",
  "text" : "RT @decisiveman: \"The smallest act of kindness is worth more than the grandest intention\" - Unknown. #farm365 #quotes #kelpiewisdom https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/756614903746658304\/video\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/TG6iYE3T5J",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/756614612418691073\/pu\/img\/hFIBEhzxY-gCXRQh.jpg",
        "id_str" : "756614612418691073",
        "id" : 756614612418691073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/756614612418691073\/pu\/img\/hFIBEhzxY-gCXRQh.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TG6iYE3T5J"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 84, 92 ]
      }, {
        "text" : "quotes",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "kelpiewisdom",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756614903746658304",
    "text" : "\"The smallest act of kindness is worth more than the grandest intention\" - Unknown. #farm365 #quotes #kelpiewisdom https:\/\/t.co\/TG6iYE3T5J",
    "id" : 756614903746658304,
    "created_at" : "2016-07-22 22:20:24 +0000",
    "user" : {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "protected" : false,
      "id_str" : "519836839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706805650844585984\/Wyw3swZ9_normal.jpg",
      "id" : 519836839,
      "verified" : false
    }
  },
  "id" : 756637078037917696,
  "created_at" : "2016-07-22 23:48:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBT Shrink",
      "screen_name" : "DrRonHolt",
      "indices" : [ 3, 13 ],
      "id_str" : "513883865",
      "id" : 513883865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrRonHolt\/status\/756601742117056512\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/5DFSaqRG00",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_9RZLUAAA1OUY.jpg",
      "id_str" : "756601737679470592",
      "id" : 756601737679470592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_9RZLUAAA1OUY.jpg",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 324
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 324
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 324
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 324
      } ],
      "display_url" : "pic.twitter.com\/5DFSaqRG00"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756606009293082624",
  "text" : "RT @DrRonHolt: Embracing and loving yourself will allow everything else to fall into place. \u2764\uFE0F https:\/\/t.co\/5DFSaqRG00",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrRonHolt\/status\/756601742117056512\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/5DFSaqRG00",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_9RZLUAAA1OUY.jpg",
        "id_str" : "756601737679470592",
        "id" : 756601737679470592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_9RZLUAAA1OUY.jpg",
        "sizes" : [ {
          "h" : 324,
          "resize" : "fit",
          "w" : 324
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 324
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 324
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 324
        } ],
        "display_url" : "pic.twitter.com\/5DFSaqRG00"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756601742117056512",
    "text" : "Embracing and loving yourself will allow everything else to fall into place. \u2764\uFE0F https:\/\/t.co\/5DFSaqRG00",
    "id" : 756601742117056512,
    "created_at" : "2016-07-22 21:28:06 +0000",
    "user" : {
      "name" : "LGBT Shrink",
      "screen_name" : "DrRonHolt",
      "protected" : false,
      "id_str" : "513883865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2266928515\/v0pqhj389sdslvgqaqyi_normal.jpeg",
      "id" : 513883865,
      "verified" : false
    }
  },
  "id" : 756606009293082624,
  "created_at" : "2016-07-22 21:45:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheAcronymMaker",
      "screen_name" : "TheAcronymMaker",
      "indices" : [ 3, 19 ],
      "id_str" : "117998721",
      "id" : 117998721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756605876967006209",
  "text" : "RT @TheAcronymMaker: The creation of \"Hell\" is the most powerful psychological weapon used to keep believers in fear of breaking the mental\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756570089676169216",
    "text" : "The creation of \"Hell\" is the most powerful psychological weapon used to keep believers in fear of breaking the mental chains of religion.",
    "id" : 756570089676169216,
    "created_at" : "2016-07-22 19:22:20 +0000",
    "user" : {
      "name" : "TheAcronymMaker",
      "screen_name" : "TheAcronymMaker",
      "protected" : false,
      "id_str" : "117998721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2794049995\/6ab1df1e44b1017176a4d13f396d16c7_normal.jpeg",
      "id" : 117998721,
      "verified" : false
    }
  },
  "id" : 756605876967006209,
  "created_at" : "2016-07-22 21:44:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skatronixxx",
      "screen_name" : "Skatronixxx",
      "indices" : [ 3, 15 ],
      "id_str" : "1887543085",
      "id" : 1887543085
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Skatronixxx\/status\/756580991129509888\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Wp1aOdhqJD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_qY_dWYAAxF1B.jpg",
      "id_str" : "756580977493827584",
      "id" : 756580977493827584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_qY_dWYAAxF1B.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/Wp1aOdhqJD"
    } ],
    "hashtags" : [ {
      "text" : "LionKing",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756605600310657024",
  "text" : "RT @Skatronixxx: The new #LionKing has had some budget cuts https:\/\/t.co\/Wp1aOdhqJD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Skatronixxx\/status\/756580991129509888\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/Wp1aOdhqJD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_qY_dWYAAxF1B.jpg",
        "id_str" : "756580977493827584",
        "id" : 756580977493827584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_qY_dWYAAxF1B.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/Wp1aOdhqJD"
      } ],
      "hashtags" : [ {
        "text" : "LionKing",
        "indices" : [ 8, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756580991129509888",
    "text" : "The new #LionKing has had some budget cuts https:\/\/t.co\/Wp1aOdhqJD",
    "id" : 756580991129509888,
    "created_at" : "2016-07-22 20:05:39 +0000",
    "user" : {
      "name" : "Skatronixxx",
      "screen_name" : "Skatronixxx",
      "protected" : false,
      "id_str" : "1887543085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759325413420240896\/O6jJXnSp_normal.jpg",
      "id" : 1887543085,
      "verified" : false
    }
  },
  "id" : 756605600310657024,
  "created_at" : "2016-07-22 21:43:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jerri",
      "screen_name" : "mamajer",
      "indices" : [ 3, 11 ],
      "id_str" : "444061175",
      "id" : 444061175
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mamajer\/status\/756588425310896128\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/J8vEWUeVlN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_xKFyUEAI-b3S.jpg",
      "id_str" : "756588418075725826",
      "id" : 756588418075725826,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_xKFyUEAI-b3S.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/J8vEWUeVlN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756601356107018240",
  "text" : "RT @mamajer: https:\/\/t.co\/J8vEWUeVlN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mamajer\/status\/756588425310896128\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/J8vEWUeVlN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_xKFyUEAI-b3S.jpg",
        "id_str" : "756588418075725826",
        "id" : 756588418075725826,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_xKFyUEAI-b3S.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/J8vEWUeVlN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756588425310896128",
    "text" : "https:\/\/t.co\/J8vEWUeVlN",
    "id" : 756588425310896128,
    "created_at" : "2016-07-22 20:35:11 +0000",
    "user" : {
      "name" : "jerri",
      "screen_name" : "mamajer",
      "protected" : false,
      "id_str" : "444061175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699353237753712640\/eUhyqjJb_normal.jpg",
      "id" : 444061175,
      "verified" : false
    }
  },
  "id" : 756601356107018240,
  "created_at" : "2016-07-22 21:26:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756576017398063104",
  "text" : "RT @ZachsMind: There may be an objective reality, but from your limited vantage point, you only see a subjective artificial point of view.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756574680807464960",
    "text" : "There may be an objective reality, but from your limited vantage point, you only see a subjective artificial point of view. You can't not.",
    "id" : 756574680807464960,
    "created_at" : "2016-07-22 19:40:35 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 756576017398063104,
  "created_at" : "2016-07-22 19:45:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "feedly",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/niF0Kxblji",
      "expanded_url" : "http:\/\/www.minddrippings.link\/limits-only-exist-when-believed-2\/",
      "display_url" : "minddrippings.link\/limits-only-ex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756520357461385216",
  "text" : "Mind Drippings Podcast - Become Limitless \u2014 Limits are only set by those who believe they exist. https:\/\/t.co\/niF0Kxblji #tech #feedly",
  "id" : 756520357461385216,
  "created_at" : "2016-07-22 16:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Favreau",
      "screen_name" : "jonfavs",
      "indices" : [ 3, 11 ],
      "id_str" : "130496027",
      "id" : 130496027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756509148729212928",
  "text" : "RT @jonfavs: I just turned the television off. I already feel like America's safer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756349465909276673",
    "text" : "I just turned the television off. I already feel like America's safer.",
    "id" : 756349465909276673,
    "created_at" : "2016-07-22 04:45:39 +0000",
    "user" : {
      "name" : "Jon Favreau",
      "screen_name" : "jonfavs",
      "protected" : false,
      "id_str" : "130496027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733786686526619649\/H2hfL9Dj_normal.jpg",
      "id" : 130496027,
      "verified" : true
    }
  },
  "id" : 756509148729212928,
  "created_at" : "2016-07-22 15:20:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/KkeXtnSt2R",
      "expanded_url" : "https:\/\/twitter.com\/intlspectator\/status\/756489585941618689",
      "display_url" : "twitter.com\/intlspectator\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756508943766126592",
  "text" : "who the heck is tim kaine? https:\/\/t.co\/KkeXtnSt2R",
  "id" : 756508943766126592,
  "created_at" : "2016-07-22 15:19:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 71, 78 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/x8YcjAJXjS",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/audible\/comments\/4u1g0j\/audibles_notsosubtle_antitrump_message\/?ref=share&ref_source=twitter",
      "display_url" : "reddit.com\/r\/audible\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756491325730586624",
  "text" : "Audible's not-so-subtle anti-Trump message https:\/\/t.co\/x8YcjAJXjS via @reddit",
  "id" : 756491325730586624,
  "created_at" : "2016-07-22 14:09:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "314",
      "screen_name" : "314apps",
      "indices" : [ 3, 11 ],
      "id_str" : "114424676",
      "id" : 114424676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chucknorris",
      "indices" : [ 13, 25 ]
    }, {
      "text" : "BADA55",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "css",
      "indices" : [ 73, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/M7wQmiLF1a",
      "expanded_url" : "http:\/\/digitalsynopsis.com\/design\/34-css-puns-web-design-funny-jokes\/",
      "display_url" : "digitalsynopsis.com\/design\/34-css-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756487081157877760",
  "text" : "RT @314apps: #chucknorris \u007B\n  color: #BADA55;\n\u007D\n\nhttps:\/\/t.co\/M7wQmiLF1a #css",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "chucknorris",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "BADA55",
        "indices" : [ 24, 31 ]
      }, {
        "text" : "css",
        "indices" : [ 60, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/M7wQmiLF1a",
        "expanded_url" : "http:\/\/digitalsynopsis.com\/design\/34-css-puns-web-design-funny-jokes\/",
        "display_url" : "digitalsynopsis.com\/design\/34-css-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732137133486571520",
    "text" : "#chucknorris \u007B\n  color: #BADA55;\n\u007D\n\nhttps:\/\/t.co\/M7wQmiLF1a #css",
    "id" : 732137133486571520,
    "created_at" : "2016-05-16 09:14:29 +0000",
    "user" : {
      "name" : "314",
      "screen_name" : "314apps",
      "protected" : false,
      "id_str" : "114424676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693063163911245824\/JdZCcHgj_normal.png",
      "id" : 114424676,
      "verified" : false
    }
  },
  "id" : 756487081157877760,
  "created_at" : "2016-07-22 13:52:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/dTQMOPmVGU",
      "expanded_url" : "http:\/\/huff.to\/29HTpYg",
      "display_url" : "huff.to\/29HTpYg"
    } ]
  },
  "geo" : { },
  "id_str" : "756485527721959424",
  "text" : "RT @SenSanders: The pharmaceutical industry has become a major health hazard to the American people. https:\/\/t.co\/dTQMOPmVGU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/dTQMOPmVGU",
        "expanded_url" : "http:\/\/huff.to\/29HTpYg",
        "display_url" : "huff.to\/29HTpYg"
      } ]
    },
    "geo" : { },
    "id_str" : "753290169290256384",
    "text" : "The pharmaceutical industry has become a major health hazard to the American people. https:\/\/t.co\/dTQMOPmVGU",
    "id" : 753290169290256384,
    "created_at" : "2016-07-13 18:09:06 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 756485527721959424,
  "created_at" : "2016-07-22 13:46:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756485430304964608",
  "text" : "RT @SenSanders: We could fully fund tuition-free public colleges if corporations paid in taxes today what they paid under \"radical socialis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753283152047734784",
    "text" : "We could fully fund tuition-free public colleges if corporations paid in taxes today what they paid under \"radical socialist\" Ronald Reagan.",
    "id" : 753283152047734784,
    "created_at" : "2016-07-13 17:41:13 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 756485430304964608,
  "created_at" : "2016-07-22 13:45:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756485259965915136",
  "text" : "RT @SenSanders: The Stabenow-Roberts GMO \"labeling\" bill was bought and paid for by Monsanto and the Grocery Manufacturers Association.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "751151256354238464",
    "geo" : { },
    "id_str" : "751151621254553600",
    "in_reply_to_user_id" : 29442313,
    "text" : "The Stabenow-Roberts GMO \"labeling\" bill was bought and paid for by Monsanto and the Grocery Manufacturers Association.",
    "id" : 751151621254553600,
    "in_reply_to_status_id" : 751151256354238464,
    "created_at" : "2016-07-07 20:31:16 +0000",
    "in_reply_to_screen_name" : "SenSanders",
    "in_reply_to_user_id_str" : "29442313",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 756485259965915136,
  "created_at" : "2016-07-22 13:45:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756485165338198016",
  "text" : "RT @SenSanders: 62 people own as much wealth as the bottom half of the world\u2019s population \u2014 around 3.6 billion people. 62 people!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752571139583578112",
    "text" : "62 people own as much wealth as the bottom half of the world\u2019s population \u2014 around 3.6 billion people. 62 people!",
    "id" : 752571139583578112,
    "created_at" : "2016-07-11 18:31:56 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 756485165338198016,
  "created_at" : "2016-07-22 13:44:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/756157809247522816\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/hTEq9kcBQZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn5pg-vWYAA8Sya.jpg",
      "id_str" : "756157802763149312",
      "id" : 756157802763149312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn5pg-vWYAA8Sya.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/hTEq9kcBQZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756168833031933952",
  "text" : "RT @dwaynereaves: https:\/\/t.co\/hTEq9kcBQZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/756157809247522816\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/hTEq9kcBQZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn5pg-vWYAA8Sya.jpg",
        "id_str" : "756157802763149312",
        "id" : 756157802763149312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn5pg-vWYAA8Sya.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/hTEq9kcBQZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756157809247522816",
    "text" : "https:\/\/t.co\/hTEq9kcBQZ",
    "id" : 756157809247522816,
    "created_at" : "2016-07-21 16:04:05 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 756168833031933952,
  "created_at" : "2016-07-21 16:47:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoApp",
      "screen_name" : "myNoApp",
      "indices" : [ 3, 11 ],
      "id_str" : "741319395671085056",
      "id" : 741319395671085056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756153200990887936",
  "text" : "RT @myNoApp: NoApp for Reminders is out in active beta now. People scheduling text reminders.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746072540112523264",
    "text" : "NoApp for Reminders is out in active beta now. People scheduling text reminders.",
    "id" : 746072540112523264,
    "created_at" : "2016-06-23 20:08:49 +0000",
    "user" : {
      "name" : "NoApp",
      "screen_name" : "myNoApp",
      "protected" : false,
      "id_str" : "741319395671085056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744767495123271685\/obZULFs0_normal.jpg",
      "id" : 741319395671085056,
      "verified" : false
    }
  },
  "id" : 756153200990887936,
  "created_at" : "2016-07-21 15:45:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoApp",
      "screen_name" : "myNoApp",
      "indices" : [ 3, 11 ],
      "id_str" : "741319395671085056",
      "id" : 741319395671085056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/XERgfKXwN8",
      "expanded_url" : "https:\/\/medium.com\/p\/you-asked-we-delivered-4e6d16b104bd",
      "display_url" : "medium.com\/p\/you-asked-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756153166048165888",
  "text" : "RT @myNoApp: I just published \u201CYou asked, We delivered\u201D https:\/\/t.co\/XERgfKXwN8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/XERgfKXwN8",
        "expanded_url" : "https:\/\/medium.com\/p\/you-asked-we-delivered-4e6d16b104bd",
        "display_url" : "medium.com\/p\/you-asked-we\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754868062671794176",
    "text" : "I just published \u201CYou asked, We delivered\u201D https:\/\/t.co\/XERgfKXwN8",
    "id" : 754868062671794176,
    "created_at" : "2016-07-18 02:39:05 +0000",
    "user" : {
      "name" : "NoApp",
      "screen_name" : "myNoApp",
      "protected" : false,
      "id_str" : "741319395671085056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744767495123271685\/obZULFs0_normal.jpg",
      "id" : 741319395671085056,
      "verified" : false
    }
  },
  "id" : 756153166048165888,
  "created_at" : "2016-07-21 15:45:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildflowers",
      "indices" : [ 93, 105 ]
    }, {
      "text" : "Catskills",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756149626131054592",
  "text" : "RT @CatskillCritter: This morning on the mountain, Queen Ann's Lace in their delicate glory, #wildflowers in July. #Catskills https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/756109543592095745\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/HIxRutEza6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn49RX6WAAAzEWp.jpg",
        "id_str" : "756109156130619392",
        "id" : 756109156130619392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn49RX6WAAAzEWp.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2457,
          "resize" : "fit",
          "w" : 3276
        } ],
        "display_url" : "pic.twitter.com\/HIxRutEza6"
      } ],
      "hashtags" : [ {
        "text" : "wildflowers",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "Catskills",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756109543592095745",
    "text" : "This morning on the mountain, Queen Ann's Lace in their delicate glory, #wildflowers in July. #Catskills https:\/\/t.co\/HIxRutEza6",
    "id" : 756109543592095745,
    "created_at" : "2016-07-21 12:52:17 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 756149626131054592,
  "created_at" : "2016-07-21 15:31:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755992248173625345",
  "geo" : { },
  "id_str" : "756149512796798976",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides oh my.. sounds wonderful!",
  "id" : 756149512796798976,
  "in_reply_to_status_id" : 755992248173625345,
  "created_at" : "2016-07-21 15:31:07 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruth Parkhouse",
      "screen_name" : "cookandmum",
      "indices" : [ 3, 14 ],
      "id_str" : "2213621077",
      "id" : 2213621077
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/n88uGV8Sjb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4fom9UMAU0_CK.jpg",
      "id_str" : "756076569957773317",
      "id" : 756076569957773317,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4fom9UMAU0_CK.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/n88uGV8Sjb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/n88uGV8Sjb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4fotOUEAAm8Jq.jpg",
      "id_str" : "756076571639681024",
      "id" : 756076571639681024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4fotOUEAAm8Jq.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 541
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 541
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 541
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 511
      } ],
      "display_url" : "pic.twitter.com\/n88uGV8Sjb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/n88uGV8Sjb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4fovDVYAAsbKu.jpg",
      "id_str" : "756076572130500608",
      "id" : 756076572130500608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4fovDVYAAsbKu.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/n88uGV8Sjb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/n88uGV8Sjb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4foxBVYAg9LmC.jpg",
      "id_str" : "756076572658982920",
      "id" : 756076572658982920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4foxBVYAg9LmC.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/n88uGV8Sjb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756122447246716928",
  "text" : "RT @cookandmum: Home in the Wheatbelt https:\/\/t.co\/n88uGV8Sjb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/n88uGV8Sjb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4fom9UMAU0_CK.jpg",
        "id_str" : "756076569957773317",
        "id" : 756076569957773317,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4fom9UMAU0_CK.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/n88uGV8Sjb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/n88uGV8Sjb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4fotOUEAAm8Jq.jpg",
        "id_str" : "756076571639681024",
        "id" : 756076571639681024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4fotOUEAAm8Jq.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 541
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 541
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 541
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 511
        } ],
        "display_url" : "pic.twitter.com\/n88uGV8Sjb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/n88uGV8Sjb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4fovDVYAAsbKu.jpg",
        "id_str" : "756076572130500608",
        "id" : 756076572130500608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4fovDVYAAsbKu.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/n88uGV8Sjb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/cookandmum\/status\/756076595509460992\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/n88uGV8Sjb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4foxBVYAg9LmC.jpg",
        "id_str" : "756076572658982920",
        "id" : 756076572658982920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4foxBVYAg9LmC.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/n88uGV8Sjb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756076595509460992",
    "text" : "Home in the Wheatbelt https:\/\/t.co\/n88uGV8Sjb",
    "id" : 756076595509460992,
    "created_at" : "2016-07-21 10:41:22 +0000",
    "user" : {
      "name" : "Ruth Parkhouse",
      "screen_name" : "cookandmum",
      "protected" : false,
      "id_str" : "2213621077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780404915097079808\/yI78sNje_normal.jpg",
      "id" : 2213621077,
      "verified" : false
    }
  },
  "id" : 756122447246716928,
  "created_at" : "2016-07-21 13:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "xGogsx",
      "indices" : [ 3, 10 ],
      "id_str" : "43296233",
      "id" : 43296233
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheSlainGod\/status\/755808410310963200\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/LCBTnQaaOy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0ruoYWYAA_yev.jpg",
      "id_str" : "755808392581636096",
      "id" : 755808392581636096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0ruoYWYAA_yev.jpg",
      "sizes" : [ {
        "h" : 1475,
        "resize" : "fit",
        "w" : 1056
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 859
      }, {
        "h" : 1475,
        "resize" : "fit",
        "w" : 1056
      } ],
      "display_url" : "pic.twitter.com\/LCBTnQaaOy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755943521547321344",
  "text" : "RT @xGogsx: I really don't get the whole Pokemon thing but this is awesome. https:\/\/t.co\/LCBTnQaaOy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheSlainGod\/status\/755808410310963200\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/LCBTnQaaOy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0ruoYWYAA_yev.jpg",
        "id_str" : "755808392581636096",
        "id" : 755808392581636096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0ruoYWYAA_yev.jpg",
        "sizes" : [ {
          "h" : 1475,
          "resize" : "fit",
          "w" : 1056
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 859
        }, {
          "h" : 1475,
          "resize" : "fit",
          "w" : 1056
        } ],
        "display_url" : "pic.twitter.com\/LCBTnQaaOy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755876264242708480",
    "text" : "I really don't get the whole Pokemon thing but this is awesome. https:\/\/t.co\/LCBTnQaaOy",
    "id" : 755876264242708480,
    "created_at" : "2016-07-20 21:25:19 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "xGogsx",
      "protected" : false,
      "id_str" : "43296233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756135280562667520\/xzcPL37B_normal.jpg",
      "id" : 43296233,
      "verified" : false
    }
  },
  "id" : 755943521547321344,
  "created_at" : "2016-07-21 01:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/w15pfwanJZ",
      "expanded_url" : "https:\/\/twitter.com\/BillyCorben\/status\/755912069979910144",
      "display_url" : "twitter.com\/BillyCorben\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755926818708918273",
  "text" : "RT @Mahala: Lawd have mercy https:\/\/t.co\/w15pfwanJZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/w15pfwanJZ",
        "expanded_url" : "https:\/\/twitter.com\/BillyCorben\/status\/755912069979910144",
        "display_url" : "twitter.com\/BillyCorben\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755926533135491073",
    "text" : "Lawd have mercy https:\/\/t.co\/w15pfwanJZ",
    "id" : 755926533135491073,
    "created_at" : "2016-07-21 00:45:04 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 755926818708918273,
  "created_at" : "2016-07-21 00:46:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755923033106190337",
  "geo" : { },
  "id_str" : "755926556078444545",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time i gave up watching. was messing w my aura..lol.",
  "id" : 755926556078444545,
  "in_reply_to_status_id" : 755923033106190337,
  "created_at" : "2016-07-21 00:45:10 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755882721361158144",
  "geo" : { },
  "id_str" : "755900293624266752",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides i love the pics you post of him and hearing the stories. : )",
  "id" : 755900293624266752,
  "in_reply_to_status_id" : 755882721361158144,
  "created_at" : "2016-07-20 23:00:48 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755841695669968896",
  "geo" : { },
  "id_str" : "755861898747318272",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides DH's dog (aus shep) wont eat biscuits we leave her til we get back home.",
  "id" : 755861898747318272,
  "in_reply_to_status_id" : 755841695669968896,
  "created_at" : "2016-07-20 20:28:14 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755827372503527424",
  "geo" : { },
  "id_str" : "755833282370138112",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides he's just sooo squishable!",
  "id" : 755833282370138112,
  "in_reply_to_status_id" : 755827372503527424,
  "created_at" : "2016-07-20 18:34:31 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755764715956137984",
  "geo" : { },
  "id_str" : "755803572659519489",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides always thought i was alien. normal social was like greek 2me..",
  "id" : 755803572659519489,
  "in_reply_to_status_id" : 755764715956137984,
  "created_at" : "2016-07-20 16:36:28 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/755799140416655360\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/7xoyXMYlN3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0jT4zUEAEpfc7.jpg",
      "id_str" : "755799137040207873",
      "id" : 755799137040207873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0jT4zUEAEpfc7.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 453
      } ],
      "display_url" : "pic.twitter.com\/7xoyXMYlN3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755800572771635200",
  "text" : "RT @Chickypoo333: https:\/\/t.co\/7xoyXMYlN3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/755799140416655360\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/7xoyXMYlN3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0jT4zUEAEpfc7.jpg",
        "id_str" : "755799137040207873",
        "id" : 755799137040207873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0jT4zUEAEpfc7.jpg",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 453
        } ],
        "display_url" : "pic.twitter.com\/7xoyXMYlN3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755799140416655360",
    "text" : "https:\/\/t.co\/7xoyXMYlN3",
    "id" : 755799140416655360,
    "created_at" : "2016-07-20 16:18:51 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 755800572771635200,
  "created_at" : "2016-07-20 16:24:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755758272515276800",
  "geo" : { },
  "id_str" : "755763907445329920",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides nah. dont be sorry.",
  "id" : 755763907445329920,
  "in_reply_to_status_id" : 755758272515276800,
  "created_at" : "2016-07-20 13:58:51 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "indices" : [ 3, 19 ],
      "id_str" : "364856414",
      "id" : 364856414
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/755555903244345344\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/zOkEngLg2f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnxGEaYUEAQROtf.jpg",
      "id_str" : "755555879106121732",
      "id" : 755555879106121732,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnxGEaYUEAQROtf.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/zOkEngLg2f"
    } ],
    "hashtags" : [ {
      "text" : "bliss",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "CatsOfTwitter",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755586159548379136",
  "text" : "RT @ThomMoorePhotos: Photo-editing with the cat on my lap #bliss #CatsOfTwitter https:\/\/t.co\/zOkEngLg2f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/755555903244345344\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/zOkEngLg2f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnxGEaYUEAQROtf.jpg",
        "id_str" : "755555879106121732",
        "id" : 755555879106121732,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnxGEaYUEAQROtf.jpg",
        "sizes" : [ {
          "h" : 1920,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/zOkEngLg2f"
      } ],
      "hashtags" : [ {
        "text" : "bliss",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "CatsOfTwitter",
        "indices" : [ 44, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755555903244345344",
    "text" : "Photo-editing with the cat on my lap #bliss #CatsOfTwitter https:\/\/t.co\/zOkEngLg2f",
    "id" : 755555903244345344,
    "created_at" : "2016-07-20 00:12:19 +0000",
    "user" : {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "protected" : false,
      "id_str" : "364856414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770204744543563776\/cS24tsF9_normal.jpg",
      "id" : 364856414,
      "verified" : false
    }
  },
  "id" : 755586159548379136,
  "created_at" : "2016-07-20 02:12:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/2hYjIuifkS",
      "expanded_url" : "https:\/\/youtu.be\/l71Pvvnp3oE",
      "display_url" : "youtu.be\/l71Pvvnp3oE"
    } ]
  },
  "geo" : { },
  "id_str" : "755579777323413509",
  "text" : "Liberal Redneck - Black Lives Matter https:\/\/t.co\/2hYjIuifkS",
  "id" : 755579777323413509,
  "created_at" : "2016-07-20 01:47:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Andreshak",
      "screen_name" : "kshak68",
      "indices" : [ 3, 11 ],
      "id_str" : "217743388",
      "id" : 217743388
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kshak68\/status\/755416276512677888\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/Gx7xadDoFU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvHGKPXgAAQ1jT.jpg",
      "id_str" : "755416271156641792",
      "id" : 755416271156641792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvHGKPXgAAQ1jT.jpg",
      "sizes" : [ {
        "h" : 620,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/Gx7xadDoFU"
    } ],
    "hashtags" : [ {
      "text" : "TongueOutTuesday",
      "indices" : [ 32, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755423111982505984",
  "text" : "RT @kshak68: Just because it's  #TongueOutTuesday https:\/\/t.co\/Gx7xadDoFU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kshak68\/status\/755416276512677888\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/Gx7xadDoFU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvHGKPXgAAQ1jT.jpg",
        "id_str" : "755416271156641792",
        "id" : 755416271156641792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvHGKPXgAAQ1jT.jpg",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/Gx7xadDoFU"
      } ],
      "hashtags" : [ {
        "text" : "TongueOutTuesday",
        "indices" : [ 19, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755416276512677888",
    "text" : "Just because it's  #TongueOutTuesday https:\/\/t.co\/Gx7xadDoFU",
    "id" : 755416276512677888,
    "created_at" : "2016-07-19 14:57:29 +0000",
    "user" : {
      "name" : "Kerri Andreshak",
      "screen_name" : "kshak68",
      "protected" : false,
      "id_str" : "217743388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000462476303\/49f0bb069bada97e9dbe6b2022a0c18f_normal.jpeg",
      "id" : 217743388,
      "verified" : false
    }
  },
  "id" : 755423111982505984,
  "created_at" : "2016-07-19 15:24:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon watterson",
      "screen_name" : "Knit_n_scribble",
      "indices" : [ 3, 19 ],
      "id_str" : "35969651",
      "id" : 35969651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Phish",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/bFrWGKr77N",
      "expanded_url" : "http:\/\/goo.gl\/0mgsD3",
      "display_url" : "goo.gl\/0mgsD3"
    } ]
  },
  "geo" : { },
  "id_str" : "755216410167615488",
  "text" : "RT @Knit_n_scribble: #Phish food for knitters, new fish hat pattern, alive and well, and free  https:\/\/t.co\/bFrWGKr77N https:\/\/t.co\/vAmwFxr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Knit_n_scribble\/status\/755056727406546944\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/vAmwFxrxAy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnp_5WpVMAAghCT.jpg",
        "id_str" : "755056510846185472",
        "id" : 755056510846185472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnp_5WpVMAAghCT.jpg",
        "sizes" : [ {
          "h" : 555,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/vAmwFxrxAy"
      } ],
      "hashtags" : [ {
        "text" : "Phish",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/bFrWGKr77N",
        "expanded_url" : "http:\/\/goo.gl\/0mgsD3",
        "display_url" : "goo.gl\/0mgsD3"
      } ]
    },
    "geo" : { },
    "id_str" : "755056727406546944",
    "text" : "#Phish food for knitters, new fish hat pattern, alive and well, and free  https:\/\/t.co\/bFrWGKr77N https:\/\/t.co\/vAmwFxrxAy",
    "id" : 755056727406546944,
    "created_at" : "2016-07-18 15:08:46 +0000",
    "user" : {
      "name" : "sharon watterson",
      "screen_name" : "Knit_n_scribble",
      "protected" : false,
      "id_str" : "35969651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763169805344108544\/ETcNYudO_normal.jpg",
      "id" : 35969651,
      "verified" : false
    }
  },
  "id" : 755216410167615488,
  "created_at" : "2016-07-19 01:43:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755210986496204801",
  "geo" : { },
  "id_str" : "755216258518355969",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre lol (sorry you got locked out and sorry for chuckling)",
  "id" : 755216258518355969,
  "in_reply_to_status_id" : 755210986496204801,
  "created_at" : "2016-07-19 01:42:41 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5'7 Black Male",
      "screen_name" : "absurdistwords",
      "indices" : [ 3, 18 ],
      "id_str" : "2735655330",
      "id" : 2735655330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755171478396633088",
  "text" : "RT @absurdistwords: MAYBE (hear me out now) maybe we shouldn't have heavily armed humans policing plant growth in general.\n\nhttps:\/\/t.co\/U7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/U7jMQBzMs4",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonk\/wp\/2014\/10\/06\/heavily-armed-drug-cops-raid-retirees-garden-seize-okra-plants\/?tid=hybrid_experimentrandom_3_na",
        "display_url" : "washingtonpost.com\/news\/wonk\/wp\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755141326295932929",
    "text" : "MAYBE (hear me out now) maybe we shouldn't have heavily armed humans policing plant growth in general.\n\nhttps:\/\/t.co\/U7jMQBzMs4",
    "id" : 755141326295932929,
    "created_at" : "2016-07-18 20:44:56 +0000",
    "user" : {
      "name" : "5'7 Black Male",
      "screen_name" : "absurdistwords",
      "protected" : false,
      "id_str" : "2735655330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796454281935278081\/fOZLXo2a_normal.jpg",
      "id" : 2735655330,
      "verified" : false
    }
  },
  "id" : 755171478396633088,
  "created_at" : "2016-07-18 22:44:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fusion",
      "screen_name" : "Fusion",
      "indices" : [ 54, 61 ],
      "id_str" : "121817564",
      "id" : 121817564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/nu5JfntN7P",
      "expanded_url" : "https:\/\/twitter.com\/i\/moments\/719543329520619522",
      "display_url" : "twitter.com\/i\/moments\/7195\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755100399795900416",
  "text" : "LOLOLOL  \u26A1\uFE0F \"All Josh Raby wanted was a milkshake\" by @Fusion\n\nhttps:\/\/t.co\/nu5JfntN7P",
  "id" : 755100399795900416,
  "created_at" : "2016-07-18 18:02:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/6hGu5wRsWx",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx29ToQgX",
      "display_url" : "tmblr.co\/Zp3-jx29ToQgX"
    } ]
  },
  "geo" : { },
  "id_str" : "755099683073196032",
  "text" : "\uD83D\uDCF7 sohelpmedun: please just read the whole thing https:\/\/t.co\/6hGu5wRsWx",
  "id" : 755099683073196032,
  "created_at" : "2016-07-18 17:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "indices" : [ 0, 7 ],
      "id_str" : "18694547",
      "id" : 18694547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754829586907541504",
  "geo" : { },
  "id_str" : "754830920776093696",
  "in_reply_to_user_id" : 18694547,
  "text" : "@4ores7 like the pink hair, flowers and purple tie.",
  "id" : 754830920776093696,
  "in_reply_to_status_id" : 754829586907541504,
  "created_at" : "2016-07-18 00:11:30 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754794721831157760",
  "geo" : { },
  "id_str" : "754799389412093952",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep heehee.. if Im alone and really bored, i'll watch Lifetime network but not when DH is home (eyerolls, comments,etc)",
  "id" : 754799389412093952,
  "in_reply_to_status_id" : 754794721831157760,
  "created_at" : "2016-07-17 22:06:12 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "indices" : [ 3, 14 ],
      "id_str" : "2441608651",
      "id" : 2441608651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/754305040500727808\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/qnDmmK6QYG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnfS-TvVUAA39Ah.jpg",
      "id_str" : "754303430500372480",
      "id" : 754303430500372480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnfS-TvVUAA39Ah.jpg",
      "sizes" : [ {
        "h" : 887,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1515,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1752,
        "resize" : "fit",
        "w" : 2369
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/qnDmmK6QYG"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754792220948099072",
  "text" : "RT @mido3bitte: Japanese bush warbler singing beautifully but it was very hard to spot #birds #wildlife https:\/\/t.co\/qnDmmK6QYG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/754305040500727808\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/qnDmmK6QYG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnfS-TvVUAA39Ah.jpg",
        "id_str" : "754303430500372480",
        "id" : 754303430500372480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnfS-TvVUAA39Ah.jpg",
        "sizes" : [ {
          "h" : 887,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1515,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1752,
          "resize" : "fit",
          "w" : 2369
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/qnDmmK6QYG"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 71, 77 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754305040500727808",
    "text" : "Japanese bush warbler singing beautifully but it was very hard to spot #birds #wildlife https:\/\/t.co\/qnDmmK6QYG",
    "id" : 754305040500727808,
    "created_at" : "2016-07-16 13:21:50 +0000",
    "user" : {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "protected" : false,
      "id_str" : "2441608651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746727881498206208\/tfRux6Hm_normal.jpg",
      "id" : 2441608651,
      "verified" : false
    }
  },
  "id" : 754792220948099072,
  "created_at" : "2016-07-17 21:37:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/754703234145615873\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/hgwflqIYIi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnk-kn_XgAAQO0g.jpg",
      "id_str" : "754703211492245504",
      "id" : 754703211492245504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnk-kn_XgAAQO0g.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/hgwflqIYIi"
    } ],
    "hashtags" : [ {
      "text" : "GreatWesternCatskills",
      "indices" : [ 66, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754792045244538882",
  "text" : "RT @CatskillCritter: Morning mists over the meadow, summer in the #GreatWesternCatskills . . . https:\/\/t.co\/hgwflqIYIi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/754703234145615873\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/hgwflqIYIi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnk-kn_XgAAQO0g.jpg",
        "id_str" : "754703211492245504",
        "id" : 754703211492245504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnk-kn_XgAAQO0g.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/hgwflqIYIi"
      } ],
      "hashtags" : [ {
        "text" : "GreatWesternCatskills",
        "indices" : [ 45, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754703234145615873",
    "text" : "Morning mists over the meadow, summer in the #GreatWesternCatskills . . . https:\/\/t.co\/hgwflqIYIi",
    "id" : 754703234145615873,
    "created_at" : "2016-07-17 15:44:07 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 754792045244538882,
  "created_at" : "2016-07-17 21:37:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 34, 46 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/754486737586446337\/video\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/A1I5nmhN3x",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754486688869523456\/pu\/img\/mfytNjrFPCGWpUvc.jpg",
      "id_str" : "754486688869523456",
      "id" : 754486688869523456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754486688869523456\/pu\/img\/mfytNjrFPCGWpUvc.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/A1I5nmhN3x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754791974721511424",
  "text" : "RT @ErinEFarley: Blossom watching @ZwartblesIE's YouTube videos. \uD83D\uDE38 https:\/\/t.co\/A1I5nmhN3x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zwartbles Ireland",
        "screen_name" : "ZwartblesIE",
        "indices" : [ 17, 29 ],
        "id_str" : "299804123",
        "id" : 299804123
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/754486737586446337\/video\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/A1I5nmhN3x",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754486688869523456\/pu\/img\/mfytNjrFPCGWpUvc.jpg",
        "id_str" : "754486688869523456",
        "id" : 754486688869523456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754486688869523456\/pu\/img\/mfytNjrFPCGWpUvc.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/A1I5nmhN3x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754486737586446337",
    "text" : "Blossom watching @ZwartblesIE's YouTube videos. \uD83D\uDE38 https:\/\/t.co\/A1I5nmhN3x",
    "id" : 754486737586446337,
    "created_at" : "2016-07-17 01:23:50 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 754791974721511424,
  "created_at" : "2016-07-17 21:36:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 6, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/qn2YJAWk7K",
      "expanded_url" : "https:\/\/twitter.com\/HucksGayBFF\/status\/754760922367946752",
      "display_url" : "twitter.com\/HucksGayBFF\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754767611464916992",
  "text" : "not a #LGBT ally I presume... https:\/\/t.co\/qn2YJAWk7K",
  "id" : 754767611464916992,
  "created_at" : "2016-07-17 19:59:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Sheridan",
      "screen_name" : "sarasheridan",
      "indices" : [ 3, 16 ],
      "id_str" : "128254845",
      "id" : 128254845
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sarasheridan\/status\/754414223153913856\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/i2gj4N6V17",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cng3qj-WIAAqYTR.jpg",
      "id_str" : "754414141935329280",
      "id" : 754414141935329280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cng3qj-WIAAqYTR.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/i2gj4N6V17"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754765825719009280",
  "text" : "RT @sarasheridan: Well this is happy. Coloured marbles set into a wooden fence so they glow like stars. Weekend joy. https:\/\/t.co\/i2gj4N6V17",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sarasheridan\/status\/754414223153913856\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/i2gj4N6V17",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cng3qj-WIAAqYTR.jpg",
        "id_str" : "754414141935329280",
        "id" : 754414141935329280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cng3qj-WIAAqYTR.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/i2gj4N6V17"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754414223153913856",
    "text" : "Well this is happy. Coloured marbles set into a wooden fence so they glow like stars. Weekend joy. https:\/\/t.co\/i2gj4N6V17",
    "id" : 754414223153913856,
    "created_at" : "2016-07-16 20:35:41 +0000",
    "user" : {
      "name" : "Sara Sheridan",
      "screen_name" : "sarasheridan",
      "protected" : false,
      "id_str" : "128254845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698537374935097344\/Kf3QHXlW_normal.jpg",
      "id" : 128254845,
      "verified" : false
    }
  },
  "id" : 754765825719009280,
  "created_at" : "2016-07-17 19:52:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754739894430212097",
  "text" : "distress last night after DLing book, started listening, realized I had read\/listened B4.. gah!",
  "id" : 754739894430212097,
  "created_at" : "2016-07-17 18:09:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "ABC11 EyewitnessNews",
      "screen_name" : "ABC11_WTVD",
      "indices" : [ 118, 129 ],
      "id_str" : "18342955",
      "id" : 18342955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754739106853322752",
  "text" : "RT @dwaynereaves: They say cows in water means rain, I guess a lot of cows means a lot of rain. Yesterday n Person co @ABC11_WTVD https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC11 EyewitnessNews",
        "screen_name" : "ABC11_WTVD",
        "indices" : [ 100, 111 ],
        "id_str" : "18342955",
        "id" : 18342955
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/754707196437532672\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Ag0uoM1QmQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlCLF_XYAA9nk6.jpg",
        "id_str" : "754707170915213312",
        "id" : 754707170915213312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlCLF_XYAA9nk6.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/Ag0uoM1QmQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754707196437532672",
    "text" : "They say cows in water means rain, I guess a lot of cows means a lot of rain. Yesterday n Person co @ABC11_WTVD https:\/\/t.co\/Ag0uoM1QmQ",
    "id" : 754707196437532672,
    "created_at" : "2016-07-17 15:59:52 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 754739106853322752,
  "created_at" : "2016-07-17 18:06:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/754712325232427008\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ZAQiT8AGAZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlGzM-XYAA5emI.jpg",
      "id_str" : "754712258031345664",
      "id" : 754712258031345664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlGzM-XYAA5emI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 912
      } ],
      "display_url" : "pic.twitter.com\/ZAQiT8AGAZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/754712325232427008\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ZAQiT8AGAZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlG21AWgAAANlD.jpg",
      "id_str" : "754712320316702720",
      "id" : 754712320316702720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlG21AWgAAANlD.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 815
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 541
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 815
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 815
      } ],
      "display_url" : "pic.twitter.com\/ZAQiT8AGAZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754738994299211780",
  "text" : "RT @SouthYeoEast: Mother's cat has ventured around the house. Dogs besides themselves, cat couldn't care less! https:\/\/t.co\/ZAQiT8AGAZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/754712325232427008\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ZAQiT8AGAZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlGzM-XYAA5emI.jpg",
        "id_str" : "754712258031345664",
        "id" : 754712258031345664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlGzM-XYAA5emI.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 912
        } ],
        "display_url" : "pic.twitter.com\/ZAQiT8AGAZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/754712325232427008\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ZAQiT8AGAZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnlG21AWgAAANlD.jpg",
        "id_str" : "754712320316702720",
        "id" : 754712320316702720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnlG21AWgAAANlD.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 815
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 541
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 815
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 815
        } ],
        "display_url" : "pic.twitter.com\/ZAQiT8AGAZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754712325232427008",
    "text" : "Mother's cat has ventured around the house. Dogs besides themselves, cat couldn't care less! https:\/\/t.co\/ZAQiT8AGAZ",
    "id" : 754712325232427008,
    "created_at" : "2016-07-17 16:20:14 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 754738994299211780,
  "created_at" : "2016-07-17 18:06:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754736602430267392",
  "geo" : { },
  "id_str" : "754738807388372993",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms coming my way, eh? welcome! : )",
  "id" : 754738807388372993,
  "in_reply_to_status_id" : 754736602430267392,
  "created_at" : "2016-07-17 18:05:28 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David States",
      "screen_name" : "statesdj",
      "indices" : [ 3, 12 ],
      "id_str" : "390731779",
      "id" : 390731779
    }, {
      "name" : "Jonathan Eisen",
      "screen_name" : "phylogenomics",
      "indices" : [ 14, 28 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/uA0kStLjpF",
      "expanded_url" : "http:\/\/www.nbcnews.com\/news\/asian-america\/indiana-has-now-charged-two-asian-american-women-feticide-n332761",
      "display_url" : "nbcnews.com\/news\/asian-ame\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754706267709603840",
  "text" : "RT @statesdj: @phylogenomics And sent a woman to prison for 20 yrs for the crime of using a legal abortion pill https:\/\/t.co\/uA0kStLjpF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Eisen",
        "screen_name" : "phylogenomics",
        "indices" : [ 0, 14 ],
        "id_str" : "15154811",
        "id" : 15154811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/uA0kStLjpF",
        "expanded_url" : "http:\/\/www.nbcnews.com\/news\/asian-america\/indiana-has-now-charged-two-asian-american-women-feticide-n332761",
        "display_url" : "nbcnews.com\/news\/asian-ame\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "754681536163618816",
    "geo" : { },
    "id_str" : "754682906078015489",
    "in_reply_to_user_id" : 15154811,
    "text" : "@phylogenomics And sent a woman to prison for 20 yrs for the crime of using a legal abortion pill https:\/\/t.co\/uA0kStLjpF",
    "id" : 754682906078015489,
    "in_reply_to_status_id" : 754681536163618816,
    "created_at" : "2016-07-17 14:23:20 +0000",
    "in_reply_to_screen_name" : "phylogenomics",
    "in_reply_to_user_id_str" : "15154811",
    "user" : {
      "name" : "David States",
      "screen_name" : "statesdj",
      "protected" : false,
      "id_str" : "390731779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756591113603981312\/vsCtDcAv_normal.jpg",
      "id" : 390731779,
      "verified" : false
    }
  },
  "id" : 754706267709603840,
  "created_at" : "2016-07-17 15:56:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pok\u00E9mon GO",
      "screen_name" : "CatchEmAlI",
      "indices" : [ 3, 14 ],
      "id_str" : "2324671124",
      "id" : 2324671124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754705692838223872",
  "text" : "RT @CatchEmAlI: Everyones playing a free fun game that promotes exploring, exercising and meeting new people. \n\nJournalists: How can I make\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754695872911446016",
    "text" : "Everyones playing a free fun game that promotes exploring, exercising and meeting new people. \n\nJournalists: How can I make this sound bad",
    "id" : 754695872911446016,
    "created_at" : "2016-07-17 15:14:52 +0000",
    "user" : {
      "name" : "Pok\u00E9mon GO",
      "screen_name" : "CatchEmAlI",
      "protected" : false,
      "id_str" : "2324671124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751443166126022656\/kpXd6bDi_normal.jpg",
      "id" : 2324671124,
      "verified" : false
    }
  },
  "id" : 754705692838223872,
  "created_at" : "2016-07-17 15:53:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamgirl",
      "screen_name" : "Kamgirl47",
      "indices" : [ 3, 13 ],
      "id_str" : "143660061",
      "id" : 143660061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754484844374220800",
  "text" : "RT @Kamgirl47: You need to saturate Twitter with this info. I feel Indiana is a third world country over Patel's treatment.  https:\/\/t.co\/Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/QpnPxOxBT8",
        "expanded_url" : "https:\/\/twitter.com\/naral\/status\/754390145491689473",
        "display_url" : "twitter.com\/naral\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754413055291772929",
    "text" : "You need to saturate Twitter with this info. I feel Indiana is a third world country over Patel's treatment.  https:\/\/t.co\/QpnPxOxBT8",
    "id" : 754413055291772929,
    "created_at" : "2016-07-16 20:31:03 +0000",
    "user" : {
      "name" : "Kamgirl",
      "screen_name" : "Kamgirl47",
      "protected" : false,
      "id_str" : "143660061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796315184700784640\/20tWpdn2_normal.jpg",
      "id" : 143660061,
      "verified" : false
    }
  },
  "id" : 754484844374220800,
  "created_at" : "2016-07-17 01:16:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/754354528158355456\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ZL7jH7801v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CngBLJ0WIAAkN-u.jpg",
      "id_str" : "754354228710219776",
      "id" : 754354228710219776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CngBLJ0WIAAkN-u.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/ZL7jH7801v"
    } ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 11, 22 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 78, 93 ]
    }, {
      "text" : "clue",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754354528158355456",
  "text" : "related to #hashimotos? tan color, dry areas from chin to collar, neck sides. #chronicillness #clue https:\/\/t.co\/ZL7jH7801v",
  "id" : 754354528158355456,
  "created_at" : "2016-07-16 16:38:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 79, 84 ]
    }, {
      "text" : "feedly",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/XDICQmrB5T",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/76021ace45991d\/69835?app_id=339",
      "display_url" : "producthunt.com\/r\/76021ace4599\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754320868956835840",
  "text" : "Pokedex Battery Case \u2014 Turn your phone into a Pokedex! https:\/\/t.co\/XDICQmrB5T #tech #feedly",
  "id" : 754320868956835840,
  "created_at" : "2016-07-16 14:24:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754085460415225856",
  "geo" : { },
  "id_str" : "754106760915456001",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle ((hugs)) so sorry yr going through this.",
  "id" : 754106760915456001,
  "in_reply_to_status_id" : 754085460415225856,
  "created_at" : "2016-07-16 00:13:57 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753979980594503680",
  "text" : "RT @bend_time: Who knew? Doc says magnesium and b2 (riboflavin) are headache relievers. 400 mgs ea per day. Worth a try",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753978988108800006",
    "text" : "Who knew? Doc says magnesium and b2 (riboflavin) are headache relievers. 400 mgs ea per day. Worth a try",
    "id" : 753978988108800006,
    "created_at" : "2016-07-15 15:46:13 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 753979980594503680,
  "created_at" : "2016-07-15 15:50:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/753970497294139393\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/l4A8Jbw3tM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnakKu5W8AAUruz.jpg",
      "id_str" : "753970491925393408",
      "id" : 753970491925393408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnakKu5W8AAUruz.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/l4A8Jbw3tM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753979766840053760",
  "text" : "RT @dwaynereaves: https:\/\/t.co\/l4A8Jbw3tM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/753970497294139393\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/l4A8Jbw3tM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnakKu5W8AAUruz.jpg",
        "id_str" : "753970491925393408",
        "id" : 753970491925393408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnakKu5W8AAUruz.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/l4A8Jbw3tM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753970497294139393",
    "text" : "https:\/\/t.co\/l4A8Jbw3tM",
    "id" : 753970497294139393,
    "created_at" : "2016-07-15 15:12:29 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 753979766840053760,
  "created_at" : "2016-07-15 15:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Newsom",
      "screen_name" : "GavinNewsom",
      "indices" : [ 3, 15 ],
      "id_str" : "11347122",
      "id" : 11347122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753979483997216769",
  "text" : "RT @GavinNewsom: No one believed you, but you just announced as your VP a man who has literally threatened their freedoms and beliefs https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7ZOZzx8GSo",
        "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/742771576039460864",
        "display_url" : "twitter.com\/realDonaldTrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753974672039960577",
    "text" : "No one believed you, but you just announced as your VP a man who has literally threatened their freedoms and beliefs https:\/\/t.co\/7ZOZzx8GSo",
    "id" : 753974672039960577,
    "created_at" : "2016-07-15 15:29:04 +0000",
    "user" : {
      "name" : "Gavin Newsom",
      "screen_name" : "GavinNewsom",
      "protected" : false,
      "id_str" : "11347122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796742575612829696\/WVCWB8a-_normal.jpg",
      "id" : 11347122,
      "verified" : true
    }
  },
  "id" : 753979483997216769,
  "created_at" : "2016-07-15 15:48:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael P. Brown",
      "screen_name" : "AllAroundMBrown",
      "indices" : [ 3, 19 ],
      "id_str" : "557304154",
      "id" : 557304154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "Vote2016",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/bEE5YOjgNR",
      "expanded_url" : "https:\/\/twitter.com\/Kris_Sacrebleu\/status\/752665727946006529",
      "display_url" : "twitter.com\/Kris_Sacrebleu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753979431593672706",
  "text" : "RT @AllAroundMBrown: The #GOP seems adamant about not separating church and state. Kind of terrifying. #Vote2016 https:\/\/t.co\/bEE5YOjgNR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOP",
        "indices" : [ 4, 8 ]
      }, {
        "text" : "Vote2016",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/bEE5YOjgNR",
        "expanded_url" : "https:\/\/twitter.com\/Kris_Sacrebleu\/status\/752665727946006529",
        "display_url" : "twitter.com\/Kris_Sacrebleu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753962806698016768",
    "text" : "The #GOP seems adamant about not separating church and state. Kind of terrifying. #Vote2016 https:\/\/t.co\/bEE5YOjgNR",
    "id" : 753962806698016768,
    "created_at" : "2016-07-15 14:41:55 +0000",
    "user" : {
      "name" : "Michael P. Brown",
      "screen_name" : "AllAroundMBrown",
      "protected" : false,
      "id_str" : "557304154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3696028550\/2abf60d2a8548345864e0e9ef80adf42_normal.png",
      "id" : 557304154,
      "verified" : false
    }
  },
  "id" : 753979431593672706,
  "created_at" : "2016-07-15 15:47:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/6oIj54xa4L",
      "expanded_url" : "https:\/\/twitter.com\/wanggo_g\/status\/753831385421324288",
      "display_url" : "twitter.com\/wanggo_g\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753969335102738432",
  "text" : "&lt;3 https:\/\/t.co\/6oIj54xa4L",
  "id" : 753969335102738432,
  "created_at" : "2016-07-15 15:07:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/iblSkx0qVc",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx29KSzPh",
      "display_url" : "tmblr.co\/Zp3-jx29KSzPh"
    } ]
  },
  "geo" : { },
  "id_str" : "753947688228519936",
  "text" : "https:\/\/t.co\/iblSkx0qVc",
  "id" : 753947688228519936,
  "created_at" : "2016-07-15 13:41:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/CLJogAW4LX",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx29KSurG",
      "display_url" : "tmblr.co\/Zp3-jx29KSurG"
    } ]
  },
  "geo" : { },
  "id_str" : "753946829620932609",
  "text" : "blackmattersus: How can people be so accurate about this? https:\/\/t.co\/CLJogAW4LX",
  "id" : 753946829620932609,
  "created_at" : "2016-07-15 13:38:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7AMmi9akag",
      "expanded_url" : "https:\/\/twitter.com\/Buddybull\/status\/751953648083537920",
      "display_url" : "twitter.com\/Buddybull\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753732625844596737",
  "text" : "yup.. so God will kill humans for being \"misguided\"? but we are all precious in his sight? oy! ((headtodesk)) https:\/\/t.co\/7AMmi9akag",
  "id" : 753732625844596737,
  "created_at" : "2016-07-14 23:27:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa von Steijern",
      "screen_name" : "LisavonSteijern",
      "indices" : [ 3, 19 ],
      "id_str" : "553313044",
      "id" : 553313044
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LisavonSteijern\/status\/752191850426032128\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/T9oDMeh0vO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBSe6YWYAQdBp3.jpg",
      "id_str" : "752191828791812100",
      "id" : 752191828791812100,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBSe6YWYAQdBp3.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/T9oDMeh0vO"
    } ],
    "hashtags" : [ {
      "text" : "photofrommyheart",
      "indices" : [ 81, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753717165010853888",
  "text" : "RT @LisavonSteijern: Some more pics of the eight cygnets \nThey are very friendly\n#photofrommyheart https:\/\/t.co\/T9oDMeh0vO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LisavonSteijern\/status\/752191850426032128\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/T9oDMeh0vO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBSe6YWYAQdBp3.jpg",
        "id_str" : "752191828791812100",
        "id" : 752191828791812100,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBSe6YWYAQdBp3.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/T9oDMeh0vO"
      } ],
      "hashtags" : [ {
        "text" : "photofrommyheart",
        "indices" : [ 60, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752191850426032128",
    "text" : "Some more pics of the eight cygnets \nThey are very friendly\n#photofrommyheart https:\/\/t.co\/T9oDMeh0vO",
    "id" : 752191850426032128,
    "created_at" : "2016-07-10 17:24:46 +0000",
    "user" : {
      "name" : "Lisa von Steijern",
      "screen_name" : "LisavonSteijern",
      "protected" : false,
      "id_str" : "553313044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769058041488605184\/ykWW9kmx_normal.jpg",
      "id" : 553313044,
      "verified" : false
    }
  },
  "id" : 753717165010853888,
  "created_at" : "2016-07-14 22:25:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753677712364040192",
  "text" : "RT @benjamincorey: Here's where I watched the sunset tonight- it's a spot that has brought me inner peace since my childhood. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/benjamincorey\/status\/753424739889209345\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/jxUMmSohhu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnSzzBOWAAEE9IF.jpg",
        "id_str" : "753424726761013249",
        "id" : 753424726761013249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnSzzBOWAAEE9IF.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/jxUMmSohhu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753424739889209345",
    "text" : "Here's where I watched the sunset tonight- it's a spot that has brought me inner peace since my childhood. https:\/\/t.co\/jxUMmSohhu",
    "id" : 753424739889209345,
    "created_at" : "2016-07-14 03:03:50 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 753677712364040192,
  "created_at" : "2016-07-14 19:49:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Digital Reader",
      "screen_name" : "inkbitspixels",
      "indices" : [ 3, 17 ],
      "id_str" : "2790546893",
      "id" : 2790546893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/m548Jfp7HH",
      "expanded_url" : "http:\/\/ebookne.ws\/29KzoAp",
      "display_url" : "ebookne.ws\/29KzoAp"
    } ]
  },
  "geo" : { },
  "id_str" : "753630770145726464",
  "text" : "RT @inkbitspixels: eMusic Launches as eStories, an Audiobook Service with 80,000 Titles | The Digital Reader https:\/\/t.co\/m548Jfp7HH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/m548Jfp7HH",
        "expanded_url" : "http:\/\/ebookne.ws\/29KzoAp",
        "display_url" : "ebookne.ws\/29KzoAp"
      } ]
    },
    "geo" : { },
    "id_str" : "753624185948270593",
    "text" : "eMusic Launches as eStories, an Audiobook Service with 80,000 Titles | The Digital Reader https:\/\/t.co\/m548Jfp7HH",
    "id" : 753624185948270593,
    "created_at" : "2016-07-14 16:16:22 +0000",
    "user" : {
      "name" : "The Digital Reader",
      "screen_name" : "inkbitspixels",
      "protected" : false,
      "id_str" : "2790546893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619304105715089408\/9PRPsrJn_normal.png",
      "id" : 2790546893,
      "verified" : false
    }
  },
  "id" : 753630770145726464,
  "created_at" : "2016-07-14 16:42:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/753624602400661509\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/n4cy8QJSg2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVpk_aWcAAWr6w.jpg",
      "id_str" : "753624596872589312",
      "id" : 753624596872589312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVpk_aWcAAWr6w.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/n4cy8QJSg2"
    } ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753626289509167104",
  "text" : "RT @dwaynereaves: Evening at the lake. #photography https:\/\/t.co\/n4cy8QJSg2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/753624602400661509\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/n4cy8QJSg2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVpk_aWcAAWr6w.jpg",
        "id_str" : "753624596872589312",
        "id" : 753624596872589312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVpk_aWcAAWr6w.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/n4cy8QJSg2"
      } ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 21, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753624602400661509",
    "text" : "Evening at the lake. #photography https:\/\/t.co\/n4cy8QJSg2",
    "id" : 753624602400661509,
    "created_at" : "2016-07-14 16:18:01 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 753626289509167104,
  "created_at" : "2016-07-14 16:24:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/rdPWVmKEbk",
      "expanded_url" : "https:\/\/blog.evernote.com\/blog\/2016\/07\/12\/3-ways-catch-em-evernote-2\/",
      "display_url" : "blog.evernote.com\/blog\/2016\/07\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753614393582247936",
  "text" : "3 Ways to Catch \u2019Em All with Evernote https:\/\/t.co\/rdPWVmKEbk",
  "id" : 753614393582247936,
  "created_at" : "2016-07-14 15:37:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nintendo of America",
      "screen_name" : "NintendoAmerica",
      "indices" : [ 3, 19 ],
      "id_str" : "5162861",
      "id" : 5162861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753610696768778242",
  "text" : "RT @NintendoAmerica: The NES is coming back to stores! Pick up the new mini NES Classic Edition on 11\/11 w\/ 30 included games! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NintendoAmerica\/status\/753559995849990144\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/wFDw7lHWb7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnUun99UsAENXtn.jpg",
        "id_str" : "753559776835973121",
        "id" : 753559776835973121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnUun99UsAENXtn.jpg",
        "sizes" : [ {
          "h" : 2874,
          "resize" : "fit",
          "w" : 3216
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1830,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1072,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/wFDw7lHWb7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753559995849990144",
    "text" : "The NES is coming back to stores! Pick up the new mini NES Classic Edition on 11\/11 w\/ 30 included games! https:\/\/t.co\/wFDw7lHWb7",
    "id" : 753559995849990144,
    "created_at" : "2016-07-14 12:01:18 +0000",
    "user" : {
      "name" : "Nintendo of America",
      "screen_name" : "NintendoAmerica",
      "protected" : false,
      "id_str" : "5162861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798215824024670209\/nlzO2oHn_normal.jpg",
      "id" : 5162861,
      "verified" : true
    }
  },
  "id" : 753610696768778242,
  "created_at" : "2016-07-14 15:22:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pokemon GO!",
      "screen_name" : "iPokemonGO",
      "indices" : [ 3, 14 ],
      "id_str" : "751061903758258176",
      "id" : 751061903758258176
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iPokemonGO\/status\/753579033946886144\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/DK8QQGOlCO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVAIKGWEAANRXW.jpg",
      "id_str" : "753579021548523520",
      "id" : 753579021548523520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVAIKGWEAANRXW.jpg",
      "sizes" : [ {
        "h" : 1288,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1288,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1157
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 656
      } ],
      "display_url" : "pic.twitter.com\/DK8QQGOlCO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753610010681368576",
  "text" : "RT @iPokemonGO: Someone's dad responding to someone that doesn't understand the Pokemon Go hype. This is great. https:\/\/t.co\/DK8QQGOlCO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iPokemonGO\/status\/753579033946886144\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/DK8QQGOlCO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVAIKGWEAANRXW.jpg",
        "id_str" : "753579021548523520",
        "id" : 753579021548523520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVAIKGWEAANRXW.jpg",
        "sizes" : [ {
          "h" : 1288,
          "resize" : "fit",
          "w" : 1242
        }, {
          "h" : 1288,
          "resize" : "fit",
          "w" : 1242
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1157
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 656
        } ],
        "display_url" : "pic.twitter.com\/DK8QQGOlCO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753579033946886144",
    "text" : "Someone's dad responding to someone that doesn't understand the Pokemon Go hype. This is great. https:\/\/t.co\/DK8QQGOlCO",
    "id" : 753579033946886144,
    "created_at" : "2016-07-14 13:16:57 +0000",
    "user" : {
      "name" : "Pokemon GO!",
      "screen_name" : "iPokemonGO",
      "protected" : false,
      "id_str" : "751061903758258176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751072492345782272\/xAIzLGl9_normal.jpg",
      "id" : 751061903758258176,
      "verified" : false
    }
  },
  "id" : 753610010681368576,
  "created_at" : "2016-07-14 15:20:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Long",
      "screen_name" : "WEGOKristenL",
      "indices" : [ 3, 16 ],
      "id_str" : "752922873015201792",
      "id" : 752922873015201792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hachat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753609409952157697",
  "text" : "RT @WEGOKristenL: Be your own adovcate! If you know something is wrong with your body\/health..persist! You know best! #hachat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hachat",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752944927928123392",
    "text" : "Be your own adovcate! If you know something is wrong with your body\/health..persist! You know best! #hachat",
    "id" : 752944927928123392,
    "created_at" : "2016-07-12 19:17:14 +0000",
    "user" : {
      "name" : "Kristen Long",
      "screen_name" : "WEGOKristenL",
      "protected" : false,
      "id_str" : "752922873015201792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752944436737413120\/QNpZ2Ozu_normal.jpg",
      "id" : 752922873015201792,
      "verified" : false
    }
  },
  "id" : 753609409952157697,
  "created_at" : "2016-07-14 15:17:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "indices" : [ 3, 16 ],
      "id_str" : "217626610",
      "id" : 217626610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753389533484478465",
  "text" : "RT @jameslsutter: I look forward to all the kids in a few years saying \"Mommy and Daddy met because he wanted her jigglypuff.\"\n\nActually, w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753388404855844864",
    "text" : "I look forward to all the kids in a few years saying \"Mommy and Daddy met because he wanted her jigglypuff.\"\n\nActually, wait.",
    "id" : 753388404855844864,
    "created_at" : "2016-07-14 00:39:27 +0000",
    "user" : {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "protected" : false,
      "id_str" : "217626610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739849533346054144\/6CIwOnsG_normal.jpg",
      "id" : 217626610,
      "verified" : false
    }
  },
  "id" : 753389533484478465,
  "created_at" : "2016-07-14 00:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/753003276824698880\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/hmEUEWF4ML",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMywvLWYAELoTK.png",
      "id_str" : "753001375580184577",
      "id" : 753001375580184577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMywvLWYAELoTK.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hmEUEWF4ML"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753222091437137920",
  "text" : "RT @StarStuff42: Click the picture to see through the telescope https:\/\/t.co\/hmEUEWF4ML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff42\/status\/753003276824698880\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/hmEUEWF4ML",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMywvLWYAELoTK.png",
        "id_str" : "753001375580184577",
        "id" : 753001375580184577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMywvLWYAELoTK.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hmEUEWF4ML"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753003276824698880",
    "text" : "Click the picture to see through the telescope https:\/\/t.co\/hmEUEWF4ML",
    "id" : 753003276824698880,
    "created_at" : "2016-07-12 23:09:05 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 753222091437137920,
  "created_at" : "2016-07-13 13:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Steele",
      "screen_name" : "askboomer1949",
      "indices" : [ 3, 17 ],
      "id_str" : "3327420822",
      "id" : 3327420822
    }, {
      "name" : "The Advocate",
      "screen_name" : "TheAdvocateMag",
      "indices" : [ 107, 122 ],
      "id_str" : "21692297",
      "id" : 21692297
    }, {
      "name" : "Michael",
      "screen_name" : "mterr337",
      "indices" : [ 123, 132 ],
      "id_str" : "1634552636",
      "id" : 1634552636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christians",
      "indices" : [ 27, 38 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 64, 69 ]
    }, {
      "text" : "hope",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753199127668850688",
  "text" : "RT @askboomer1949: Not all #Christians are barbaric homophobes. #LGBT #hope \nThis church is on my block. \n.@TheAdvocateMag @mterr337 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Advocate",
        "screen_name" : "TheAdvocateMag",
        "indices" : [ 88, 103 ],
        "id_str" : "21692297",
        "id" : 21692297
      }, {
        "name" : "Michael",
        "screen_name" : "mterr337",
        "indices" : [ 104, 113 ],
        "id_str" : "1634552636",
        "id" : 1634552636
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/askboomer1949\/status\/753050561927184384\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/leAisU2qvf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNffkbVUAAvEzP.jpg",
        "id_str" : "753050558659907584",
        "id" : 753050558659907584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNffkbVUAAvEzP.jpg",
        "sizes" : [ {
          "h" : 1161,
          "resize" : "fit",
          "w" : 2064
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/leAisU2qvf"
      } ],
      "hashtags" : [ {
        "text" : "Christians",
        "indices" : [ 8, 19 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 45, 50 ]
      }, {
        "text" : "hope",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753050561927184384",
    "text" : "Not all #Christians are barbaric homophobes. #LGBT #hope \nThis church is on my block. \n.@TheAdvocateMag @mterr337 https:\/\/t.co\/leAisU2qvf",
    "id" : 753050561927184384,
    "created_at" : "2016-07-13 02:16:59 +0000",
    "user" : {
      "name" : "Jackson Steele",
      "screen_name" : "askboomer1949",
      "protected" : false,
      "id_str" : "3327420822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749421143765823488\/MCSZEbPz_normal.jpg",
      "id" : 3327420822,
      "verified" : false
    }
  },
  "id" : 753199127668850688,
  "created_at" : "2016-07-13 12:07:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouTube",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753023695195627520",
  "text" : "RT @AlisynGayle: Fox 5 News takes a look at Lyme Disease and the struggle victims face with medical treatment. #YouTube\n https:\/\/t.co\/XaWp8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 132, 140 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YouTube",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/XaWp8Ik3lw",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=YL-fBeEd6LI&list=PLcuHpcV2MbFj420zTVNNRoF3jJMJ6kFs5&sns=tw",
        "display_url" : "youtube.com\/watch?v=YL-fBe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753022504654999552",
    "text" : "Fox 5 News takes a look at Lyme Disease and the struggle victims face with medical treatment. #YouTube\n https:\/\/t.co\/XaWp8Ik3lw via @youtube",
    "id" : 753022504654999552,
    "created_at" : "2016-07-13 00:25:30 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 753023695195627520,
  "created_at" : "2016-07-13 00:30:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Manning",
      "screen_name" : "xychelsea",
      "indices" : [ 3, 13 ],
      "id_str" : "1694040764",
      "id" : 1694040764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "standwithchelsea",
      "indices" : [ 107, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752980680351576065",
  "text" : "RT @xychelsea: I am okay. I'm glad to be alive. Thank you all for your love &lt;3 I will get through this. #standwithchelsea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "standwithchelsea",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752676465443942401",
    "text" : "I am okay. I'm glad to be alive. Thank you all for your love &lt;3 I will get through this. #standwithchelsea",
    "id" : 752676465443942401,
    "created_at" : "2016-07-12 01:30:28 +0000",
    "user" : {
      "name" : "Chelsea Manning",
      "screen_name" : "xychelsea",
      "protected" : false,
      "id_str" : "1694040764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643848486010638336\/OmQvY0Rl_normal.png",
      "id" : 1694040764,
      "verified" : true
    }
  },
  "id" : 752980680351576065,
  "created_at" : "2016-07-12 21:39:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TongueOutEwesday",
      "screen_name" : "tongueoutewes",
      "indices" : [ 3, 17 ],
      "id_str" : "4867240780",
      "id" : 4867240780
    }, {
      "name" : "Caroline Mitchell",
      "screen_name" : "farmpiano",
      "indices" : [ 19, 29 ],
      "id_str" : "2779396417",
      "id" : 2779396417
    }, {
      "name" : "Russell'sPal\uD83D\uDCCE",
      "screen_name" : "RussellsPal",
      "indices" : [ 30, 42 ],
      "id_str" : "4568288054",
      "id" : 4568288054
    }, {
      "name" : "TongueOutCoosday",
      "screen_name" : "tongueoutcoos",
      "indices" : [ 43, 57 ],
      "id_str" : "4783458341",
      "id" : 4783458341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ogeikbU2E5",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2749021\/Buddy-Calf-Larry-Lamb-farmyard-friends-life-orphaned-day.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752967374563905545",
  "text" : "RT @tongueoutewes: @farmpiano @RussellsPal @tongueoutcoos Bonus \uD83D\uDC45 Still not sure if it's a Texel https:\/\/t.co\/ogeikbU2E5 https:\/\/t.co\/0oVV1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caroline Mitchell",
        "screen_name" : "farmpiano",
        "indices" : [ 0, 10 ],
        "id_str" : "2779396417",
        "id" : 2779396417
      }, {
        "name" : "Russell'sPal\uD83D\uDCCE",
        "screen_name" : "RussellsPal",
        "indices" : [ 11, 23 ],
        "id_str" : "4568288054",
        "id" : 4568288054
      }, {
        "name" : "TongueOutCoosday",
        "screen_name" : "tongueoutcoos",
        "indices" : [ 24, 38 ],
        "id_str" : "4783458341",
        "id" : 4783458341
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tongueoutewes\/status\/752887881782308864\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/0oVV17XdEj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLLggfUkAAzAsq.jpg",
        "id_str" : "752887847061852160",
        "id" : 752887847061852160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLLggfUkAAzAsq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1193,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 1193,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 251
        }, {
          "h" : 1193,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/0oVV17XdEj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/ogeikbU2E5",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2749021\/Buddy-Calf-Larry-Lamb-farmyard-friends-life-orphaned-day.html",
        "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "752876907847360512",
    "geo" : { },
    "id_str" : "752887881782308864",
    "in_reply_to_user_id" : 2779396417,
    "text" : "@farmpiano @RussellsPal @tongueoutcoos Bonus \uD83D\uDC45 Still not sure if it's a Texel https:\/\/t.co\/ogeikbU2E5 https:\/\/t.co\/0oVV17XdEj",
    "id" : 752887881782308864,
    "in_reply_to_status_id" : 752876907847360512,
    "created_at" : "2016-07-12 15:30:33 +0000",
    "in_reply_to_screen_name" : "farmpiano",
    "in_reply_to_user_id_str" : "2779396417",
    "user" : {
      "name" : "TongueOutEwesday",
      "screen_name" : "tongueoutewes",
      "protected" : false,
      "id_str" : "4867240780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697129311959195652\/9c3FZ0bK_normal.jpg",
      "id" : 4867240780,
      "verified" : false
    }
  },
  "id" : 752967374563905545,
  "created_at" : "2016-07-12 20:46:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee in Iowa",
      "screen_name" : "Lee_in_Iowa",
      "indices" : [ 3, 15 ],
      "id_str" : "146160591",
      "id" : 146160591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lee_in_Iowa\/status\/752948565119373312\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/mtOaYDROx8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMCg-AVUAApUK0.jpg",
      "id_str" : "752948328124469248",
      "id" : 752948328124469248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMCg-AVUAApUK0.jpg",
      "sizes" : [ {
        "h" : 653,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/mtOaYDROx8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752966991733030913",
  "text" : "RT @Lee_in_Iowa: Welcome, Berners! https:\/\/t.co\/mtOaYDROx8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lee_in_Iowa\/status\/752948565119373312\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/mtOaYDROx8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMCg-AVUAApUK0.jpg",
        "id_str" : "752948328124469248",
        "id" : 752948328124469248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMCg-AVUAApUK0.jpg",
        "sizes" : [ {
          "h" : 653,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/mtOaYDROx8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752948565119373312",
    "text" : "Welcome, Berners! https:\/\/t.co\/mtOaYDROx8",
    "id" : 752948565119373312,
    "created_at" : "2016-07-12 19:31:41 +0000",
    "user" : {
      "name" : "Lee in Iowa",
      "screen_name" : "Lee_in_Iowa",
      "protected" : false,
      "id_str" : "146160591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793795829249126400\/P16JTnfT_normal.jpg",
      "id" : 146160591,
      "verified" : false
    }
  },
  "id" : 752966991733030913,
  "created_at" : "2016-07-12 20:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Tullius",
      "screen_name" : "MarkTullius",
      "indices" : [ 53, 65 ],
      "id_str" : "526556141",
      "id" : 526556141
    }, {
      "name" : "Tee Quillin",
      "screen_name" : "teequillin",
      "indices" : [ 66, 77 ],
      "id_str" : "7976742",
      "id" : 7976742
    }, {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 78, 91 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 8, 14 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BlFOA58FsA",
      "expanded_url" : "https:\/\/audiobookreviewer.com\/reviews\/brightside-by-mark-tullius\/",
      "display_url" : "audiobookreviewer.com\/reviews\/bright\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752893619216982016",
  "text" : "Win the #scifi #audiobook #giveaway of Brightside by @MarkTullius @teequillin @audiobookrev https:\/\/t.co\/BlFOA58FsA",
  "id" : 752893619216982016,
  "created_at" : "2016-07-12 15:53:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "indices" : [ 3, 16 ],
      "id_str" : "59801057",
      "id" : 59801057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/mZKsZMxSAJ",
      "expanded_url" : "https:\/\/twitter.com\/astro_kate7\/status\/750215372884811776",
      "display_url" : "twitter.com\/astro_kate7\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752893103623770112",
  "text" : "RT @AudioFileMag: And she's got an #audiobook in space with her, folks! https:\/\/t.co\/mZKsZMxSAJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "audiobook",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/mZKsZMxSAJ",
        "expanded_url" : "https:\/\/twitter.com\/astro_kate7\/status\/750215372884811776",
        "display_url" : "twitter.com\/astro_kate7\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752564953773735936",
    "text" : "And she's got an #audiobook in space with her, folks! https:\/\/t.co\/mZKsZMxSAJ",
    "id" : 752564953773735936,
    "created_at" : "2016-07-11 18:07:21 +0000",
    "user" : {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "protected" : false,
      "id_str" : "59801057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525009056\/ArrowsforFacebook_normal.jpg",
      "id" : 59801057,
      "verified" : false
    }
  },
  "id" : 752893103623770112,
  "created_at" : "2016-07-12 15:51:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/MkOrPuGhBk",
      "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/752758607612145665",
      "display_url" : "twitter.com\/steven_pass\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752880681169129472",
  "text" : "cow kisses &lt;3 https:\/\/t.co\/MkOrPuGhBk",
  "id" : 752880681169129472,
  "created_at" : "2016-07-12 15:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin",
      "screen_name" : "devbost",
      "indices" : [ 3, 11 ],
      "id_str" : "21626875",
      "id" : 21626875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/Og13CKwayJ",
      "expanded_url" : "http:\/\/m.imgur.com\/KAwwxFp",
      "display_url" : "m.imgur.com\/KAwwxFp"
    } ]
  },
  "geo" : { },
  "id_str" : "752880074706354176",
  "text" : "RT @devbost: This is great. https:\/\/t.co\/Og13CKwayJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/Og13CKwayJ",
        "expanded_url" : "http:\/\/m.imgur.com\/KAwwxFp",
        "display_url" : "m.imgur.com\/KAwwxFp"
      } ]
    },
    "geo" : { },
    "id_str" : "752874921110409216",
    "text" : "This is great. https:\/\/t.co\/Og13CKwayJ",
    "id" : 752874921110409216,
    "created_at" : "2016-07-12 14:39:03 +0000",
    "user" : {
      "name" : "Devin",
      "screen_name" : "devbost",
      "protected" : false,
      "id_str" : "21626875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3694258002\/b93ef133715e27267caa69f8c49cdc83_normal.jpeg",
      "id" : 21626875,
      "verified" : false
    }
  },
  "id" : 752880074706354176,
  "created_at" : "2016-07-12 14:59:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 112, 117 ]
    }, {
      "text" : "feedly",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/eeKxhaizMW",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/5c0565c4815876\/69382?app_id=339",
      "display_url" : "producthunt.com\/r\/5c0565c48158\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752877194112798720",
  "text" : "Poke Radar for iOS and Android \u2014 User generated location based database for Pok\u00E9mon Go. https:\/\/t.co\/eeKxhaizMW #tech #feedly",
  "id" : 752877194112798720,
  "created_at" : "2016-07-12 14:48:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "feedly",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ME6WMXI8ER",
      "expanded_url" : "https:\/\/implayingpokemongo.com\/",
      "display_url" : "implayingpokemongo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "752876950943924224",
  "text" : "I'm Playing Pok\u00E9mon Go \u2014 A t-shirt shop for fans of Pok\u00E9mon Go. https:\/\/t.co\/ME6WMXI8ER #tech #feedly",
  "id" : 752876950943924224,
  "created_at" : "2016-07-12 14:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moran",
      "screen_name" : "TheMichaelMoran",
      "indices" : [ 3, 19 ],
      "id_str" : "14083693",
      "id" : 14083693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752856800513421312",
  "text" : "RT @TheMichaelMoran: Pokemon GO causes constitutional crisis in UK as Pikachu accidentally becomes interim Prime Minister https:\/\/t.co\/ki5b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheMichaelMoran\/status\/752797153819496448\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/ki5b5EiPHs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnJ48ziWAAA6zUC.jpg",
        "id_str" : "752797073746034688",
        "id" : 752797073746034688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnJ48ziWAAA6zUC.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ki5b5EiPHs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752797153819496448",
    "text" : "Pokemon GO causes constitutional crisis in UK as Pikachu accidentally becomes interim Prime Minister https:\/\/t.co\/ki5b5EiPHs",
    "id" : 752797153819496448,
    "created_at" : "2016-07-12 09:30:02 +0000",
    "user" : {
      "name" : "Michael Moran",
      "screen_name" : "TheMichaelMoran",
      "protected" : false,
      "id_str" : "14083693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761288919983988736\/6lD08tEM_normal.jpg",
      "id" : 14083693,
      "verified" : true
    }
  },
  "id" : 752856800513421312,
  "created_at" : "2016-07-12 13:27:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gretaknits",
      "screen_name" : "gretaknits",
      "indices" : [ 3, 14 ],
      "id_str" : "14568145",
      "id" : 14568145
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gretaknits\/status\/752849344777170944\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/aeJliHgN02",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnKoe39VYAEkHiv.jpg",
      "id_str" : "752849336095039489",
      "id" : 752849336095039489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnKoe39VYAEkHiv.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/aeJliHgN02"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752856045018554368",
  "text" : "RT @gretaknits: Good morning from the garden... https:\/\/t.co\/aeJliHgN02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gretaknits\/status\/752849344777170944\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/aeJliHgN02",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnKoe39VYAEkHiv.jpg",
        "id_str" : "752849336095039489",
        "id" : 752849336095039489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnKoe39VYAEkHiv.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/aeJliHgN02"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752849344777170944",
    "text" : "Good morning from the garden... https:\/\/t.co\/aeJliHgN02",
    "id" : 752849344777170944,
    "created_at" : "2016-07-12 12:57:25 +0000",
    "user" : {
      "name" : "gretaknits",
      "screen_name" : "gretaknits",
      "protected" : false,
      "id_str" : "14568145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53444423\/camellia_normal.jpg",
      "id" : 14568145,
      "verified" : false
    }
  },
  "id" : 752856045018554368,
  "created_at" : "2016-07-12 13:24:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CowParadeSurrey",
      "screen_name" : "CowParadeSurrey",
      "indices" : [ 3, 19 ],
      "id_str" : "4041494027",
      "id" : 4041494027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cowappreciationday",
      "indices" : [ 37, 56 ]
    }, {
      "text" : "followtheherd",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/isYs9Tvsqw",
      "expanded_url" : "http:\/\/ow.ly\/1y7T302a3S4",
      "display_url" : "ow.ly\/1y7T302a3S4"
    } ]
  },
  "geo" : { },
  "id_str" : "752855973123981312",
  "text" : "RT @CowParadeSurrey: It's officially #cowappreciationday today! show your love of our cows  #followtheherd https:\/\/t.co\/isYs9Tvsqw https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CowParadeSurrey\/status\/752834098289336321\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/aG7K1YXSqN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnKanonW8AAChC5.jpg",
        "id_str" : "752834093432369152",
        "id" : 752834093432369152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnKanonW8AAChC5.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3648,
          "resize" : "fit",
          "w" : 2736
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/aG7K1YXSqN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CowParadeSurrey\/status\/752834098289336321\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/aG7K1YXSqN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnKanhkXEAEkYfB.jpg",
        "id_str" : "752834091540746241",
        "id" : 752834091540746241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnKanhkXEAEkYfB.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 854,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 854,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 801,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/aG7K1YXSqN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CowParadeSurrey\/status\/752834098289336321\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/aG7K1YXSqN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnKanfIWYAAXGtm.jpg",
        "id_str" : "752834090886389760",
        "id" : 752834090886389760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnKanfIWYAAXGtm.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 533
        } ],
        "display_url" : "pic.twitter.com\/aG7K1YXSqN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CowParadeSurrey\/status\/752834098289336321\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/aG7K1YXSqN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnKanfqWgAAWN4n.jpg",
        "id_str" : "752834091029004288",
        "id" : 752834091029004288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnKanfqWgAAWN4n.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 558
        } ],
        "display_url" : "pic.twitter.com\/aG7K1YXSqN"
      } ],
      "hashtags" : [ {
        "text" : "cowappreciationday",
        "indices" : [ 16, 35 ]
      }, {
        "text" : "followtheherd",
        "indices" : [ 71, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/isYs9Tvsqw",
        "expanded_url" : "http:\/\/ow.ly\/1y7T302a3S4",
        "display_url" : "ow.ly\/1y7T302a3S4"
      } ]
    },
    "geo" : { },
    "id_str" : "752834098289336321",
    "text" : "It's officially #cowappreciationday today! show your love of our cows  #followtheherd https:\/\/t.co\/isYs9Tvsqw https:\/\/t.co\/aG7K1YXSqN",
    "id" : 752834098289336321,
    "created_at" : "2016-07-12 11:56:50 +0000",
    "user" : {
      "name" : "CowParadeSurrey",
      "screen_name" : "CowParadeSurrey",
      "protected" : false,
      "id_str" : "4041494027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658578545044779008\/YvrWL6RJ_normal.jpg",
      "id" : 4041494027,
      "verified" : false
    }
  },
  "id" : 752855973123981312,
  "created_at" : "2016-07-12 13:23:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752580872881246209",
  "text" : "RT @ZwartblesIE: With 10 foot river banks we needed a monster machine. Best thing about farming is great neighbors #farm365 https:\/\/t.co\/f1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/752576982395879425\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/f12CzR8mMg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnGwo-XWAAAl75v.jpg",
        "id_str" : "752576830729748480",
        "id" : 752576830729748480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnGwo-XWAAAl75v.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/f12CzR8mMg"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/752576982395879425\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/f12CzR8mMg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnGwo-qXgAA0Iwu.jpg",
        "id_str" : "752576830809538560",
        "id" : 752576830809538560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnGwo-qXgAA0Iwu.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/f12CzR8mMg"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752576982395879425",
    "text" : "With 10 foot river banks we needed a monster machine. Best thing about farming is great neighbors #farm365 https:\/\/t.co\/f12CzR8mMg",
    "id" : 752576982395879425,
    "created_at" : "2016-07-11 18:55:09 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 752580872881246209,
  "created_at" : "2016-07-11 19:10:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752580837808439296",
  "text" : "RT @dwaynereaves: How many of you have been nice to someone today? I hope that all of you have. Have a great day!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752578426096259074",
    "text" : "How many of you have been nice to someone today? I hope that all of you have. Have a great day!",
    "id" : 752578426096259074,
    "created_at" : "2016-07-11 19:00:53 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 752580837808439296,
  "created_at" : "2016-07-11 19:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/nuUrZ2gkGN",
      "expanded_url" : "https:\/\/vine.co\/v\/5W2AKjWu2w9",
      "display_url" : "vine.co\/v\/5W2AKjWu2w9"
    } ]
  },
  "geo" : { },
  "id_str" : "752580691095871488",
  "text" : "RT @ZwartblesIE: Oh Feck!!! Neighbors cow in the river!! https:\/\/t.co\/nuUrZ2gkGN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/nuUrZ2gkGN",
        "expanded_url" : "https:\/\/vine.co\/v\/5W2AKjWu2w9",
        "display_url" : "vine.co\/v\/5W2AKjWu2w9"
      } ]
    },
    "geo" : { },
    "id_str" : "752533355573415936",
    "text" : "Oh Feck!!! Neighbors cow in the river!! https:\/\/t.co\/nuUrZ2gkGN",
    "id" : 752533355573415936,
    "created_at" : "2016-07-11 16:01:48 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 752580691095871488,
  "created_at" : "2016-07-11 19:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5x5\/status\/752560352525742085\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/iYRHGENSRd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnGhpcEWEAAONU5.jpg",
      "id_str" : "752560346028707840",
      "id" : 752560346028707840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnGhpcEWEAAONU5.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/iYRHGENSRd"
    } ],
    "hashtags" : [ {
      "text" : "PokemonGO",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752562073339584512",
  "text" : "RT @5x5: I turned on my phone and was attacked by a Rattata coming out of the cats' litter box. #PokemonGO https:\/\/t.co\/iYRHGENSRd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5x5\/status\/752560352525742085\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/iYRHGENSRd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnGhpcEWEAAONU5.jpg",
        "id_str" : "752560346028707840",
        "id" : 752560346028707840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnGhpcEWEAAONU5.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/iYRHGENSRd"
      } ],
      "hashtags" : [ {
        "text" : "PokemonGO",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752560352525742085",
    "text" : "I turned on my phone and was attacked by a Rattata coming out of the cats' litter box. #PokemonGO https:\/\/t.co\/iYRHGENSRd",
    "id" : 752560352525742085,
    "created_at" : "2016-07-11 17:49:04 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 752562073339584512,
  "created_at" : "2016-07-11 17:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Man Chew",
      "screen_name" : "EdManChew",
      "indices" : [ 3, 13 ],
      "id_str" : "17928325",
      "id" : 17928325
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EdManChew\/status\/751429357046861830\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/5OxgZQXLi7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm2dAy0UEAAIvtb.jpg",
      "id_str" : "751429349807493120",
      "id" : 751429349807493120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm2dAy0UEAAIvtb.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/5OxgZQXLi7"
    } ],
    "hashtags" : [ {
      "text" : "PokemonGO",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752542134109085696",
  "text" : "RT @EdManChew: How am I supposed to get to work with a spearow in my car?!? #PokemonGO https:\/\/t.co\/5OxgZQXLi7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EdManChew\/status\/751429357046861830\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/5OxgZQXLi7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm2dAy0UEAAIvtb.jpg",
        "id_str" : "751429349807493120",
        "id" : 751429349807493120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm2dAy0UEAAIvtb.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/5OxgZQXLi7"
      } ],
      "hashtags" : [ {
        "text" : "PokemonGO",
        "indices" : [ 61, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751429357046861830",
    "text" : "How am I supposed to get to work with a spearow in my car?!? #PokemonGO https:\/\/t.co\/5OxgZQXLi7",
    "id" : 751429357046861830,
    "created_at" : "2016-07-08 14:54:54 +0000",
    "user" : {
      "name" : "Ed Man Chew",
      "screen_name" : "EdManChew",
      "protected" : false,
      "id_str" : "17928325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476988121192493057\/p8ZXtd2m_normal.jpeg",
      "id" : 17928325,
      "verified" : false
    }
  },
  "id" : 752542134109085696,
  "created_at" : "2016-07-11 16:36:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tor.com",
      "screen_name" : "tordotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "16151835",
      "id" : 16151835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/qGOKuA27vj",
      "expanded_url" : "http:\/\/Tor.com",
      "display_url" : "Tor.com"
    } ]
  },
  "geo" : { },
  "id_str" : "752534922951266309",
  "text" : "RT @tordotcom: Join the https:\/\/t.co\/qGOKuA27vj Ebook Club! A free eBook every month, starting with Cixin Liu's THREE-BODY PROBLEM: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/qGOKuA27vj",
        "expanded_url" : "http:\/\/Tor.com",
        "display_url" : "Tor.com"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ro98ou60uL",
        "expanded_url" : "http:\/\/ebookclub.tor.com\/",
        "display_url" : "ebookclub.tor.com"
      } ]
    },
    "geo" : { },
    "id_str" : "752518109215461376",
    "text" : "Join the https:\/\/t.co\/qGOKuA27vj Ebook Club! A free eBook every month, starting with Cixin Liu's THREE-BODY PROBLEM: https:\/\/t.co\/ro98ou60uL",
    "id" : 752518109215461376,
    "created_at" : "2016-07-11 15:01:13 +0000",
    "user" : {
      "name" : "Tor.com",
      "screen_name" : "tordotcom",
      "protected" : false,
      "id_str" : "16151835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1127889802\/RocketRings_normal.jpg",
      "id" : 16151835,
      "verified" : false
    }
  },
  "id" : 752534922951266309,
  "created_at" : "2016-07-11 16:08:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Perez",
      "screen_name" : "IGIhosT",
      "indices" : [ 3, 11 ],
      "id_str" : "21697900",
      "id" : 21697900
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/IGIhosT\/status\/752357024156028928\/video\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/3v2VfEHzNA",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/752356583221460993\/pu\/img\/pBP7CoeVirmVItmx.jpg",
      "id_str" : "752356583221460993",
      "id" : 752356583221460993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/752356583221460993\/pu\/img\/pBP7CoeVirmVItmx.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3v2VfEHzNA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752534639537975296",
  "text" : "RT @IGIhosT: Pokemon GO is just insane right now. This is in Central Park. It's basically been HQ for Pokemon GO. https:\/\/t.co\/3v2VfEHzNA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IGIhosT\/status\/752357024156028928\/video\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/3v2VfEHzNA",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/752356583221460993\/pu\/img\/pBP7CoeVirmVItmx.jpg",
        "id_str" : "752356583221460993",
        "id" : 752356583221460993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/752356583221460993\/pu\/img\/pBP7CoeVirmVItmx.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3v2VfEHzNA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752357024156028928",
    "text" : "Pokemon GO is just insane right now. This is in Central Park. It's basically been HQ for Pokemon GO. https:\/\/t.co\/3v2VfEHzNA",
    "id" : 752357024156028928,
    "created_at" : "2016-07-11 04:21:07 +0000",
    "user" : {
      "name" : "Jonathan Perez",
      "screen_name" : "IGIhosT",
      "protected" : false,
      "id_str" : "21697900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790298236649078784\/wrjtpreD_normal.jpg",
      "id" : 21697900,
      "verified" : false
    }
  },
  "id" : 752534639537975296,
  "created_at" : "2016-07-11 16:06:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/752473727988862976\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/JXSRUqFG4J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnFS3QyXEAEwCxG.jpg",
      "id_str" : "752473722100060161",
      "id" : 752473722100060161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnFS3QyXEAEwCxG.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JXSRUqFG4J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752507670729482241",
  "text" : "RT @dwaynereaves: https:\/\/t.co\/JXSRUqFG4J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/752473727988862976\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/JXSRUqFG4J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnFS3QyXEAEwCxG.jpg",
        "id_str" : "752473722100060161",
        "id" : 752473722100060161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnFS3QyXEAEwCxG.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/JXSRUqFG4J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752473727988862976",
    "text" : "https:\/\/t.co\/JXSRUqFG4J",
    "id" : 752473727988862976,
    "created_at" : "2016-07-11 12:04:51 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 752507670729482241,
  "created_at" : "2016-07-11 14:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Uhrmacher",
      "screen_name" : "Cornfrmr",
      "indices" : [ 3, 12 ],
      "id_str" : "34410927",
      "id" : 34410927
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cornfrmr\/status\/752461664172122112\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/nBb0vvaqOA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnFH4iqVUAAOe-t.jpg",
      "id_str" : "752461649450192896",
      "id" : 752461649450192896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnFH4iqVUAAOe-t.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/nBb0vvaqOA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752507043886555136",
  "text" : "RT @Cornfrmr: Good morning https:\/\/t.co\/nBb0vvaqOA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cornfrmr\/status\/752461664172122112\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/nBb0vvaqOA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnFH4iqVUAAOe-t.jpg",
        "id_str" : "752461649450192896",
        "id" : 752461649450192896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnFH4iqVUAAOe-t.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/nBb0vvaqOA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752461664172122112",
    "text" : "Good morning https:\/\/t.co\/nBb0vvaqOA",
    "id" : 752461664172122112,
    "created_at" : "2016-07-11 11:16:55 +0000",
    "user" : {
      "name" : "Randy Uhrmacher",
      "screen_name" : "Cornfrmr",
      "protected" : false,
      "id_str" : "34410927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784046461692485632\/oK5AiheE_normal.jpg",
      "id" : 34410927,
      "verified" : false
    }
  },
  "id" : 752507043886555136,
  "created_at" : "2016-07-11 14:17:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/3nUp3b2tr2",
      "expanded_url" : "http:\/\/on.mash.to\/29xUzaj",
      "display_url" : "on.mash.to\/29xUzaj"
    } ]
  },
  "geo" : { },
  "id_str" : "752506873002229760",
  "text" : "RT @mashable: Pok\u00E9mon Go on Android: Already bigger than Tinder, may soon be as big as Twitter https:\/\/t.co\/3nUp3b2tr2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/3nUp3b2tr2",
        "expanded_url" : "http:\/\/on.mash.to\/29xUzaj",
        "display_url" : "on.mash.to\/29xUzaj"
      } ]
    },
    "geo" : { },
    "id_str" : "752501216203137024",
    "text" : "Pok\u00E9mon Go on Android: Already bigger than Tinder, may soon be as big as Twitter https:\/\/t.co\/3nUp3b2tr2",
    "id" : 752501216203137024,
    "created_at" : "2016-07-11 13:54:05 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 752506873002229760,
  "created_at" : "2016-07-11 14:16:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheGoldenMirror\/status\/752277682398920704\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/OwgF2MCTAM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnCgkDfW8AAV9Yj.jpg",
      "id_str" : "752277679043440640",
      "id" : 752277679043440640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnCgkDfW8AAV9Yj.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1095
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1095
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1095
      } ],
      "display_url" : "pic.twitter.com\/OwgF2MCTAM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752278973342707712",
  "text" : "RT @TheGoldenMirror: Examine the past, but don't live in it. ~ Jerry Corstens https:\/\/t.co\/OwgF2MCTAM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheGoldenMirror\/status\/752277682398920704\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/OwgF2MCTAM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnCgkDfW8AAV9Yj.jpg",
        "id_str" : "752277679043440640",
        "id" : 752277679043440640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnCgkDfW8AAV9Yj.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1095
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1095
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1095
        } ],
        "display_url" : "pic.twitter.com\/OwgF2MCTAM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752277682398920704",
    "text" : "Examine the past, but don't live in it. ~ Jerry Corstens https:\/\/t.co\/OwgF2MCTAM",
    "id" : 752277682398920704,
    "created_at" : "2016-07-10 23:05:50 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 752278973342707712,
  "created_at" : "2016-07-10 23:10:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Moore",
      "screen_name" : "Wexcoastbirds",
      "indices" : [ 3, 17 ],
      "id_str" : "158135344",
      "id" : 158135344
    }, {
      "name" : "Biodiversity Ireland",
      "screen_name" : "BioDataCentre",
      "indices" : [ 70, 84 ],
      "id_str" : "89167656",
      "id" : 89167656
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Wexcoastbirds\/status\/751828804822261761\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/c34eKU9GFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8GqWxXgAA-HZB.jpg",
      "id_str" : "751826987531075584",
      "id" : 751826987531075584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8GqWxXgAA-HZB.jpg",
      "sizes" : [ {
        "h" : 963,
        "resize" : "fit",
        "w" : 1109
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 1109
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 1109
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/c34eKU9GFi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752278766362263552",
  "text" : "RT @Wexcoastbirds: Dark-green fritillary..\nStrandhill ,Co Sligo......\n@BioDataCentre https:\/\/t.co\/c34eKU9GFi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Biodiversity Ireland",
        "screen_name" : "BioDataCentre",
        "indices" : [ 51, 65 ],
        "id_str" : "89167656",
        "id" : 89167656
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wexcoastbirds\/status\/751828804822261761\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/c34eKU9GFi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8GqWxXgAA-HZB.jpg",
        "id_str" : "751826987531075584",
        "id" : 751826987531075584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8GqWxXgAA-HZB.jpg",
        "sizes" : [ {
          "h" : 963,
          "resize" : "fit",
          "w" : 1109
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 1109
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 1109
        }, {
          "h" : 590,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/c34eKU9GFi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751828804822261761",
    "text" : "Dark-green fritillary..\nStrandhill ,Co Sligo......\n@BioDataCentre https:\/\/t.co\/c34eKU9GFi",
    "id" : 751828804822261761,
    "created_at" : "2016-07-09 17:22:10 +0000",
    "user" : {
      "name" : "Tom Moore",
      "screen_name" : "Wexcoastbirds",
      "protected" : false,
      "id_str" : "158135344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715834878428884992\/HqTCcBty_normal.jpg",
      "id" : 158135344,
      "verified" : false
    }
  },
  "id" : 752278766362263552,
  "created_at" : "2016-07-10 23:10:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad E. Colby",
      "screen_name" : "TheChadColby",
      "indices" : [ 3, 16 ],
      "id_str" : "213651463",
      "id" : 213651463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752266633100554240",
  "text" : "RT @TheChadColby: Space Is Ruining Astronauts' Eyesight And No One Knows Why - \u200B\u200BThe tricky syndrome might hamper our https:\/\/t.co\/7oK5XUSG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Popular Mechanics",
        "screen_name" : "PopMech",
        "indices" : [ 128, 136 ],
        "id_str" : "23116280",
        "id" : 23116280
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/7oK5XUSGtL",
        "expanded_url" : "http:\/\/www.popularmechanics.com\/space\/a21757\/astronauts-eyesight-viip\/",
        "display_url" : "popularmechanics.com\/space\/a21757\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752235169625497600",
    "text" : "Space Is Ruining Astronauts' Eyesight And No One Knows Why - \u200B\u200BThe tricky syndrome might hamper our https:\/\/t.co\/7oK5XUSGtL via @PopMech",
    "id" : 752235169625497600,
    "created_at" : "2016-07-10 20:16:54 +0000",
    "user" : {
      "name" : "Chad E. Colby",
      "screen_name" : "TheChadColby",
      "protected" : false,
      "id_str" : "213651463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663545384489234432\/L8zFkYix_normal.jpg",
      "id" : 213651463,
      "verified" : false
    }
  },
  "id" : 752266633100554240,
  "created_at" : "2016-07-10 22:21:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/752258643756744705\/photo\/1",
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/bsgYzPrUZI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnCPP4DWAAAVkvT.jpg",
      "id_str" : "752258640678092800",
      "id" : 752258640678092800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnCPP4DWAAAVkvT.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/bsgYzPrUZI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752258643756744705",
  "text" : "My new look https:\/\/t.co\/bsgYzPrUZI",
  "id" : 752258643756744705,
  "created_at" : "2016-07-10 21:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No Relation",
      "screen_name" : "TheCosby",
      "indices" : [ 3, 12 ],
      "id_str" : "62037775",
      "id" : 62037775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752233689300492288",
  "text" : "RT @TheCosby: This tweet alludes to the fact that police brutality not only exists but is encouraged. Extrajudicial murders. https:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheCosby\/status\/752142496961101824\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/oZLA9PsZJZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnAlm_qXEAAHBwu.jpg",
        "id_str" : "752142489625235456",
        "id" : 752142489625235456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnAlm_qXEAAHBwu.jpg",
        "sizes" : [ {
          "h" : 623,
          "resize" : "fit",
          "w" : 1194
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 1194
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 1194
        } ],
        "display_url" : "pic.twitter.com\/oZLA9PsZJZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752142496961101824",
    "text" : "This tweet alludes to the fact that police brutality not only exists but is encouraged. Extrajudicial murders. https:\/\/t.co\/oZLA9PsZJZ",
    "id" : 752142496961101824,
    "created_at" : "2016-07-10 14:08:40 +0000",
    "user" : {
      "name" : "No Relation",
      "screen_name" : "TheCosby",
      "protected" : false,
      "id_str" : "62037775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788878477101531136\/YAR8jOu5_normal.jpg",
      "id" : 62037775,
      "verified" : false
    }
  },
  "id" : 752233689300492288,
  "created_at" : "2016-07-10 20:11:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doe Park CaravanSite",
      "screen_name" : "OurDoePark",
      "indices" : [ 3, 14 ],
      "id_str" : "1356567810",
      "id" : 1356567810
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OurDoePark\/status\/752213582461472768\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/IsyBAeLbKr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBmNFVWAAI1gNl.jpg",
      "id_str" : "752213512726904834",
      "id" : 752213512726904834,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBmNFVWAAI1gNl.jpg",
      "sizes" : [ {
        "h" : 1962,
        "resize" : "fit",
        "w" : 1778
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1087
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1962,
        "resize" : "fit",
        "w" : 1778
      } ],
      "display_url" : "pic.twitter.com\/IsyBAeLbKr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752232412843835392",
  "text" : "RT @OurDoePark: Ta da!! Hairy cow drawing finished https:\/\/t.co\/IsyBAeLbKr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OurDoePark\/status\/752213582461472768\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/IsyBAeLbKr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBmNFVWAAI1gNl.jpg",
        "id_str" : "752213512726904834",
        "id" : 752213512726904834,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBmNFVWAAI1gNl.jpg",
        "sizes" : [ {
          "h" : 1962,
          "resize" : "fit",
          "w" : 1778
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 616
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1087
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1962,
          "resize" : "fit",
          "w" : 1778
        } ],
        "display_url" : "pic.twitter.com\/IsyBAeLbKr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752213582461472768",
    "text" : "Ta da!! Hairy cow drawing finished https:\/\/t.co\/IsyBAeLbKr",
    "id" : 752213582461472768,
    "created_at" : "2016-07-10 18:51:08 +0000",
    "user" : {
      "name" : "Doe Park CaravanSite",
      "screen_name" : "OurDoePark",
      "protected" : false,
      "id_str" : "1356567810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3577027336\/8a44d3763c3184750deb03fb070ee63c_normal.jpeg",
      "id" : 1356567810,
      "verified" : false
    }
  },
  "id" : 752232412843835392,
  "created_at" : "2016-07-10 20:05:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752209105096413184",
  "text" : "RT @ZachsMind: yall do realize we are living in the future now? We just bombed a bad guy with a ROBOT. That's scifi shit. Happened in Dalla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752183740118372352",
    "text" : "yall do realize we are living in the future now? We just bombed a bad guy with a ROBOT. That's scifi shit. Happened in Dallas last Thursday.",
    "id" : 752183740118372352,
    "created_at" : "2016-07-10 16:52:33 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 752209105096413184,
  "created_at" : "2016-07-10 18:33:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "l\u03B1riss\u03B1 ph\u03B1m",
      "screen_name" : "lrsphm",
      "indices" : [ 3, 10 ],
      "id_str" : "441652894",
      "id" : 441652894
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacklivesmatter",
      "indices" : [ 105, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752209046829142016",
  "text" : "RT @lrsphm: hey, i made an ally toolkit especially for non-black poc and white people looking to support #blacklivesmatter https:\/\/t.co\/McV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blacklivesmatter",
        "indices" : [ 93, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/McVHRlL9ap",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/112by_l48h-fJ0BO6b9ZLi7M16UYf-DrZTo-e-XupcMI\/edit?usp=sharing",
        "display_url" : "docs.google.com\/document\/d\/112\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751546176151883777",
    "text" : "hey, i made an ally toolkit especially for non-black poc and white people looking to support #blacklivesmatter https:\/\/t.co\/McVHRlL9ap",
    "id" : 751546176151883777,
    "created_at" : "2016-07-08 22:39:06 +0000",
    "user" : {
      "name" : "l\u03B1riss\u03B1 ph\u03B1m",
      "screen_name" : "lrsphm",
      "protected" : false,
      "id_str" : "441652894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797363217412608000\/fTaSYE5W_normal.jpg",
      "id" : 441652894,
      "verified" : false
    }
  },
  "id" : 752209046829142016,
  "created_at" : "2016-07-10 18:33:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/752208450789269504\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/b6y2BauXVg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBhmQZXgAA_uQr.jpg",
      "id_str" : "752208447635161088",
      "id" : 752208447635161088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBhmQZXgAA_uQr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 655
      } ],
      "display_url" : "pic.twitter.com\/b6y2BauXVg"
    } ],
    "hashtags" : [ {
      "text" : "BLM",
      "indices" : [ 60, 64 ]
    }, {
      "text" : "whiteprivilege",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/4bUwdN6yvl",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/112by_l48h-fJ0BO6b9ZLi7M16UYf-DrZTo-e-XupcMI\/edit?_ts=1468175444#heading=h.7uet462cyp79",
      "display_url" : "docs.google.com\/document\/d\/112\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752208450789269504",
  "text" : "ally toolkit 7\/8\/2016 - Google Docs https:\/\/t.co\/4bUwdN6yvl #BLM #whiteprivilege https:\/\/t.co\/b6y2BauXVg",
  "id" : 752208450789269504,
  "created_at" : "2016-07-10 18:30:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/v9yCRNjuFV",
      "expanded_url" : "https:\/\/zachsmind.wordpress.com\/2016\/07\/10\/humanity-matters",
      "display_url" : "zachsmind.wordpress.com\/2016\/07\/10\/hum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752206838989479936",
  "text" : "RT @ZachsMind: Humanity Matters https:\/\/t.co\/v9yCRNjuFV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/v9yCRNjuFV",
        "expanded_url" : "https:\/\/zachsmind.wordpress.com\/2016\/07\/10\/humanity-matters",
        "display_url" : "zachsmind.wordpress.com\/2016\/07\/10\/hum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752196845531570176",
    "text" : "Humanity Matters https:\/\/t.co\/v9yCRNjuFV",
    "id" : 752196845531570176,
    "created_at" : "2016-07-10 17:44:37 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 752206838989479936,
  "created_at" : "2016-07-10 18:24:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/goiImhol6Z",
      "expanded_url" : "https:\/\/vine.co\/v\/5WwqjeFgwlz",
      "display_url" : "vine.co\/v\/5WwqjeFgwlz"
    } ]
  },
  "geo" : { },
  "id_str" : "752205223825997824",
  "text" : "RT @ZwartblesIE: The sheep \"What are you doing down there?\" Me \"Looking at your medicine cabinet\" https:\/\/t.co\/goiImhol6Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/goiImhol6Z",
        "expanded_url" : "https:\/\/vine.co\/v\/5WwqjeFgwlz",
        "display_url" : "vine.co\/v\/5WwqjeFgwlz"
      } ]
    },
    "geo" : { },
    "id_str" : "752102318758305792",
    "text" : "The sheep \"What are you doing down there?\" Me \"Looking at your medicine cabinet\" https:\/\/t.co\/goiImhol6Z",
    "id" : 752102318758305792,
    "created_at" : "2016-07-10 11:29:00 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 752205223825997824,
  "created_at" : "2016-07-10 18:17:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/752153638836047872\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/llgd3BkNqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnAvvwOWgAA7xt7.jpg",
      "id_str" : "752153635216326656",
      "id" : 752153635216326656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnAvvwOWgAA7xt7.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/llgd3BkNqE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/r32IGqTRFR",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/07\/abortion-murder-rationalists-take?_ts=1468162376",
      "display_url" : "brucegerencser.net\/2016\/07\/aborti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752153638836047872",
  "text" : "thoughful points about definitions &gt; Is Abortion Murder? (A Rationalist's Take) https:\/\/t.co\/r32IGqTRFR https:\/\/t.co\/llgd3BkNqE",
  "id" : 752153638836047872,
  "created_at" : "2016-07-10 14:52:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Montreal Gazette",
      "screen_name" : "mtlgazette",
      "indices" : [ 3, 14 ],
      "id_str" : "63177215",
      "id" : 63177215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/yPy5hfZqMD",
      "expanded_url" : "http:\/\/bit.ly\/29Evk2q",
      "display_url" : "bit.ly\/29Evk2q"
    } ]
  },
  "geo" : { },
  "id_str" : "752136541514891264",
  "text" : "RT @mtlgazette: Rosemont park has sheep landscaping for the summer https:\/\/t.co\/yPy5hfZqMD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/yPy5hfZqMD",
        "expanded_url" : "http:\/\/bit.ly\/29Evk2q",
        "display_url" : "bit.ly\/29Evk2q"
      } ]
    },
    "geo" : { },
    "id_str" : "751932124433788929",
    "text" : "Rosemont park has sheep landscaping for the summer https:\/\/t.co\/yPy5hfZqMD",
    "id" : 751932124433788929,
    "created_at" : "2016-07-10 00:12:43 +0000",
    "user" : {
      "name" : "Montreal Gazette",
      "screen_name" : "mtlgazette",
      "protected" : false,
      "id_str" : "63177215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665288771143766016\/tgLtWm97_normal.jpg",
      "id" : 63177215,
      "verified" : true
    }
  },
  "id" : 752136541514891264,
  "created_at" : "2016-07-10 13:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "indices" : [ 3, 14 ],
      "id_str" : "2815401127",
      "id" : 2815401127
    }, {
      "name" : "Adrian Clark",
      "screen_name" : "adrianjcl123",
      "indices" : [ 37, 50 ],
      "id_str" : "1038309122",
      "id" : 1038309122
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 51, 63 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 64, 76 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/751830497471434752\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/yHkplQf5xK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8Jhj8WIAQzmFw.jpg",
      "id_str" : "751830134982844420",
      "id" : 751830134982844420,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8Jhj8WIAQzmFw.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1020
      } ],
      "display_url" : "pic.twitter.com\/yHkplQf5xK"
    } ],
    "hashtags" : [ {
      "text" : "UKtrip",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751890372465393664",
  "text" : "RT @gertvanden: Grumpy sheep\n#UKtrip @adrianjcl123 @newlandfarm @ErinEFarley https:\/\/t.co\/yHkplQf5xK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adrian Clark",
        "screen_name" : "adrianjcl123",
        "indices" : [ 21, 34 ],
        "id_str" : "1038309122",
        "id" : 1038309122
      }, {
        "name" : "Newland Farm",
        "screen_name" : "newlandfarm",
        "indices" : [ 35, 47 ],
        "id_str" : "2259182801",
        "id" : 2259182801
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 48, 60 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/751830497471434752\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/yHkplQf5xK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm8Jhj8WIAQzmFw.jpg",
        "id_str" : "751830134982844420",
        "id" : 751830134982844420,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm8Jhj8WIAQzmFw.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/yHkplQf5xK"
      } ],
      "hashtags" : [ {
        "text" : "UKtrip",
        "indices" : [ 13, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751830497471434752",
    "text" : "Grumpy sheep\n#UKtrip @adrianjcl123 @newlandfarm @ErinEFarley https:\/\/t.co\/yHkplQf5xK",
    "id" : 751830497471434752,
    "created_at" : "2016-07-09 17:28:53 +0000",
    "user" : {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "protected" : false,
      "id_str" : "2815401127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635003322211147776\/tdmuR7zK_normal.jpg",
      "id" : 2815401127,
      "verified" : false
    }
  },
  "id" : 751890372465393664,
  "created_at" : "2016-07-09 21:26:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "feedly",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/9vifejJJLW",
      "expanded_url" : "http:\/\/ebookfriendly.com\/clever-bookmark-reading-light-pictures\/",
      "display_url" : "ebookfriendly.com\/clever-bookmar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751803101137530880",
  "text" : "This ingenious bookmark can be used as a mini light (pictures) https:\/\/t.co\/9vifejJJLW #books #feedly",
  "id" : 751803101137530880,
  "created_at" : "2016-07-09 15:40:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Greenwood",
      "screen_name" : "plymouthphoto",
      "indices" : [ 3, 17 ],
      "id_str" : "442561726",
      "id" : 442561726
    }, {
      "name" : "Countryside Alliance",
      "screen_name" : "CAupdates",
      "indices" : [ 115, 125 ],
      "id_str" : "20669858",
      "id" : 20669858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cowappreciationday",
      "indices" : [ 28, 47 ]
    }, {
      "text" : "dartmoor",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751780165617848320",
  "text" : "RT @plymouthphoto: Today is #cowappreciationday - one of my favorites I took when the heather was out on #dartmoor @CAupdates https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Countryside Alliance",
        "screen_name" : "CAupdates",
        "indices" : [ 96, 106 ],
        "id_str" : "20669858",
        "id" : 20669858
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/plymouthphoto\/status\/751705014545055745\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/9XhfbpYFOX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm6XljLWAAEuz8u.jpg",
        "id_str" : "751704859171225601",
        "id" : 751704859171225601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm6XljLWAAEuz8u.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1369,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1369,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 802,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/9XhfbpYFOX"
      } ],
      "hashtags" : [ {
        "text" : "cowappreciationday",
        "indices" : [ 9, 28 ]
      }, {
        "text" : "dartmoor",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751705014545055745",
    "text" : "Today is #cowappreciationday - one of my favorites I took when the heather was out on #dartmoor @CAupdates https:\/\/t.co\/9XhfbpYFOX",
    "id" : 751705014545055745,
    "created_at" : "2016-07-09 09:10:16 +0000",
    "user" : {
      "name" : "Hazel Greenwood",
      "screen_name" : "plymouthphoto",
      "protected" : false,
      "id_str" : "442561726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796959124928024576\/qT9BJA8a_normal.jpg",
      "id" : 442561726,
      "verified" : false
    }
  },
  "id" : 751780165617848320,
  "created_at" : "2016-07-09 14:08:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sandiskclipsport",
      "indices" : [ 115, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751559294198349824",
  "text" : "it took some effort to get it seen by audible manager (ugh) but now I think it should be easy to add more content. #sandiskclipsport",
  "id" : 751559294198349824,
  "created_at" : "2016-07-08 23:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751558668987035648",
  "text" : "really enjoying my sandisk clip sport so far. so nice to have buttons right there to pause and play. #audiobooks",
  "id" : 751558668987035648,
  "created_at" : "2016-07-08 23:28:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan",
      "screen_name" : "ireadlikeaboss",
      "indices" : [ 62, 77 ],
      "id_str" : "138191411",
      "id" : 138191411
    }, {
      "name" : "Collector BBF\/BGF",
      "screen_name" : "CollectorBookBF",
      "indices" : [ 79, 95 ],
      "id_str" : "2380557103",
      "id" : 2380557103
    }, {
      "name" : "AudioGals",
      "screen_name" : "AudioGals",
      "indices" : [ 97, 107 ],
      "id_str" : "762896330",
      "id" : 762896330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Audiobook",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zi4u0PiptG",
      "expanded_url" : "https:\/\/listenupaudiobooks.wordpress.com\/2016\/07\/08\/audiobook-news-reviews-0708-2",
      "display_url" : "listenupaudiobooks.wordpress.com\/2016\/07\/08\/aud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751554075133636610",
  "text" : "RT @Listen2Books: We're back! #Audiobook news &amp; reviews w\/@ireadlikeaboss, @collectorbookbf, @audiogals &amp;\u2026 https:\/\/t.co\/zi4u0PiptG https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan",
        "screen_name" : "ireadlikeaboss",
        "indices" : [ 44, 59 ],
        "id_str" : "138191411",
        "id" : 138191411
      }, {
        "name" : "Collector BBF\/BGF",
        "screen_name" : "CollectorBookBF",
        "indices" : [ 61, 77 ],
        "id_str" : "2380557103",
        "id" : 2380557103
      }, {
        "name" : "AudioGals",
        "screen_name" : "AudioGals",
        "indices" : [ 79, 89 ],
        "id_str" : "762896330",
        "id" : 762896330
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Listen2Books\/status\/751528941400141824\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/MHSRKcKgvQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm33lm3UkAA7Ml2.jpg",
        "id_str" : "751528938300542976",
        "id" : 751528938300542976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm33lm3UkAA7Ml2.jpg",
        "sizes" : [ {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/MHSRKcKgvQ"
      } ],
      "hashtags" : [ {
        "text" : "Audiobook",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/zi4u0PiptG",
        "expanded_url" : "https:\/\/listenupaudiobooks.wordpress.com\/2016\/07\/08\/audiobook-news-reviews-0708-2",
        "display_url" : "listenupaudiobooks.wordpress.com\/2016\/07\/08\/aud\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751528941400141824",
    "text" : "We're back! #Audiobook news &amp; reviews w\/@ireadlikeaboss, @collectorbookbf, @audiogals &amp;\u2026 https:\/\/t.co\/zi4u0PiptG https:\/\/t.co\/MHSRKcKgvQ",
    "id" : 751528941400141824,
    "created_at" : "2016-07-08 21:30:37 +0000",
    "user" : {
      "name" : "ListenUp Audiobooks",
      "screen_name" : "ListenUpAudio",
      "protected" : false,
      "id_str" : "423665516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798245817324683264\/GINN5xbO_normal.jpg",
      "id" : 423665516,
      "verified" : false
    }
  },
  "id" : 751554075133636610,
  "created_at" : "2016-07-08 23:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Bartholomeou",
      "screen_name" : "Iyagovos",
      "indices" : [ 3, 12 ],
      "id_str" : "110058074",
      "id" : 110058074
    }, {
      "name" : "HiroProt",
      "screen_name" : "Clatham78",
      "indices" : [ 46, 56 ],
      "id_str" : "14194946",
      "id" : 14194946
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Iyagovos\/status\/751467320946589696\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/fjrtOw97CD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm2_iC-XEAAjz4L.jpg",
      "id_str" : "751467304475627520",
      "id" : 751467304475627520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm2_iC-XEAAjz4L.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1196
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1196
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1196
      } ],
      "display_url" : "pic.twitter.com\/fjrtOw97CD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751553202806480897",
  "text" : "RT @Iyagovos: Pokemon Go. Got. Real. (Thanks, @Clatham78) https:\/\/t.co\/fjrtOw97CD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HiroProt",
        "screen_name" : "Clatham78",
        "indices" : [ 32, 42 ],
        "id_str" : "14194946",
        "id" : 14194946
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Iyagovos\/status\/751467320946589696\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/fjrtOw97CD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm2_iC-XEAAjz4L.jpg",
        "id_str" : "751467304475627520",
        "id" : 751467304475627520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm2_iC-XEAAjz4L.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1196
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1196
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1196
        } ],
        "display_url" : "pic.twitter.com\/fjrtOw97CD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751467320946589696",
    "text" : "Pokemon Go. Got. Real. (Thanks, @Clatham78) https:\/\/t.co\/fjrtOw97CD",
    "id" : 751467320946589696,
    "created_at" : "2016-07-08 17:25:45 +0000",
    "user" : {
      "name" : "James Bartholomeou",
      "screen_name" : "Iyagovos",
      "protected" : false,
      "id_str" : "110058074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778531232154021888\/UuO1wxSs_normal.jpg",
      "id" : 110058074,
      "verified" : false
    }
  },
  "id" : 751553202806480897,
  "created_at" : "2016-07-08 23:07:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751473837187952640",
  "geo" : { },
  "id_str" : "751478637577248768",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 its exactly what happened today..lol. instead of spanking me, understood im tired and said check this out.",
  "id" : 751478637577248768,
  "in_reply_to_status_id" : 751473837187952640,
  "created_at" : "2016-07-08 18:10:43 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751461734548987905",
  "text" : "sometimes, i curse the universe and it gives me a cookie.",
  "id" : 751461734548987905,
  "created_at" : "2016-07-08 17:03:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751461462212808704",
  "text" : "RT @AnnotatedBible: Love is far more important than having the correct doctrines (1 Corinthians 13)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751457220110327808",
    "text" : "Love is far more important than having the correct doctrines (1 Corinthians 13)",
    "id" : 751457220110327808,
    "created_at" : "2016-07-08 16:45:37 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 751461462212808704,
  "created_at" : "2016-07-08 17:02:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/751451745398784000\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Cbx9Nle7KU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm2xYNQWEAIHCQK.jpg",
      "id_str" : "751451742273933314",
      "id" : 751451742273933314,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm2xYNQWEAIHCQK.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/Cbx9Nle7KU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/IS2TOj52IB",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/5\/28\/8661977\/race-police-officer?_ts=1467995028",
      "display_url" : "vox.com\/2015\/5\/28\/8661\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751451745398784000",
  "text" : "I'm a black ex-cop, and this is the real truth about race and policing https:\/\/t.co\/IS2TOj52IB https:\/\/t.co\/Cbx9Nle7KU",
  "id" : 751451745398784000,
  "created_at" : "2016-07-08 16:23:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/751432940194820098\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/JwNvVP1Hs5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm2gRksWgAA--TZ.jpg",
      "id_str" : "751432936608661504",
      "id" : 751432936608661504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm2gRksWgAA--TZ.jpg",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/JwNvVP1Hs5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/lhM6F86e5t",
      "expanded_url" : "http:\/\/www.nomadpodcast.co.uk\/nomad-94-jonny-baker-pioneering-and-the-gift-of-not-fitting-in?_ts=1467990544",
      "display_url" : "nomadpodcast.co.uk\/nomad-94-jonny\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751432940194820098",
  "text" : "new perspective on not fitting in.. forging new. Pioneering and the Gift of Not Fitting In https:\/\/t.co\/lhM6F86e5t https:\/\/t.co\/JwNvVP1Hs5",
  "id" : 751432940194820098,
  "created_at" : "2016-07-08 15:09:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Legend",
      "screen_name" : "johnlegend",
      "indices" : [ 3, 14 ],
      "id_str" : "18228898",
      "id" : 18228898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751418112982024192",
  "text" : "RT @johnlegend: These Dallas shootings are horrific.  Killing these officers is morally reprehensible and completely counterproductive to k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751270252252581889",
    "text" : "These Dallas shootings are horrific.  Killing these officers is morally reprehensible and completely counterproductive to keeping us safe.",
    "id" : 751270252252581889,
    "created_at" : "2016-07-08 04:22:40 +0000",
    "user" : {
      "name" : "John Legend",
      "screen_name" : "johnlegend",
      "protected" : false,
      "id_str" : "18228898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800595595802988545\/DGnOOgL__normal.jpg",
      "id" : 18228898,
      "verified" : true
    }
  },
  "id" : 751418112982024192,
  "created_at" : "2016-07-08 14:10:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Greer",
      "screen_name" : "BroderickGreer",
      "indices" : [ 3, 18 ],
      "id_str" : "412008580",
      "id" : 412008580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751229963655909377",
  "text" : "RT @BroderickGreer: If we are all inextricably linked - and we are - then the liberation of black people is the liberation of all people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "624068968110792704",
    "geo" : { },
    "id_str" : "624069057030029312",
    "in_reply_to_user_id" : 412008580,
    "text" : "If we are all inextricably linked - and we are - then the liberation of black people is the liberation of all people.",
    "id" : 624069057030029312,
    "in_reply_to_status_id" : 624068968110792704,
    "created_at" : "2015-07-23 04:10:32 +0000",
    "in_reply_to_screen_name" : "BroderickGreer",
    "in_reply_to_user_id_str" : "412008580",
    "user" : {
      "name" : "Broderick Greer",
      "screen_name" : "BroderickGreer",
      "protected" : false,
      "id_str" : "412008580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798201830069174272\/CnJ8daYc_normal.jpg",
      "id" : 412008580,
      "verified" : true
    }
  },
  "id" : 751229963655909377,
  "created_at" : "2016-07-08 01:42:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751125222804316160",
  "geo" : { },
  "id_str" : "751126817453514752",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 DD = forumspeak for Dear Daughter..lol",
  "id" : 751126817453514752,
  "in_reply_to_status_id" : 751125222804316160,
  "created_at" : "2016-07-07 18:52:43 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751105473198297088",
  "geo" : { },
  "id_str" : "751113921914896384",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 sorry yr not feeling well. (sounds like DD.. says feels like electricity in veins)",
  "id" : 751113921914896384,
  "in_reply_to_status_id" : 751105473198297088,
  "created_at" : "2016-07-07 18:01:28 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Movie Fail",
      "screen_name" : "MovieFailBlog",
      "indices" : [ 3, 17 ],
      "id_str" : "357321796",
      "id" : 357321796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Deadwood",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751111913828941824",
  "text" : "RT @MovieFailBlog: We're pleased to announce our first installment of \"Hoopleheads,\" our new #Deadwood podcast at Movie Fail: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Deadwood",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/IWN8RZajRp",
        "expanded_url" : "http:\/\/moviefail.com\/hoopleheads-deadwood\/",
        "display_url" : "moviefail.com\/hoopleheads-de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750662081196818432",
    "text" : "We're pleased to announce our first installment of \"Hoopleheads,\" our new #Deadwood podcast at Movie Fail: https:\/\/t.co\/IWN8RZajRp",
    "id" : 750662081196818432,
    "created_at" : "2016-07-06 12:06:01 +0000",
    "user" : {
      "name" : "Movie Fail",
      "screen_name" : "MovieFailBlog",
      "protected" : false,
      "id_str" : "357321796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1501394016\/Movie_Fail_Final_normal.jpg",
      "id" : 357321796,
      "verified" : false
    }
  },
  "id" : 751111913828941824,
  "created_at" : "2016-07-07 17:53:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "indices" : [ 3, 14 ],
      "id_str" : "49698134",
      "id" : 49698134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/jxlDehyuOO",
      "expanded_url" : "https:\/\/twitter.com\/joses_nchez\/status\/750916968463474690",
      "display_url" : "twitter.com\/joses_nchez\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751085116999475200",
  "text" : "RT @JoyAnnReid: Clearly the presence of the child was no deterrent. And it won't be when the officers are cleared. https:\/\/t.co\/jxlDehyuOO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/jxlDehyuOO",
        "expanded_url" : "https:\/\/twitter.com\/joses_nchez\/status\/750916968463474690",
        "display_url" : "twitter.com\/joses_nchez\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750924855411929088",
    "text" : "Clearly the presence of the child was no deterrent. And it won't be when the officers are cleared. https:\/\/t.co\/jxlDehyuOO",
    "id" : 750924855411929088,
    "created_at" : "2016-07-07 05:30:11 +0000",
    "user" : {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "protected" : false,
      "id_str" : "49698134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796364947517161472\/O7jPbVMJ_normal.jpg",
      "id" : 49698134,
      "verified" : true
    }
  },
  "id" : 751085116999475200,
  "created_at" : "2016-07-07 16:07:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorah",
      "screen_name" : "jorah",
      "indices" : [ 3, 9 ],
      "id_str" : "10574772",
      "id" : 10574772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751084965652299776",
  "text" : "RT @jorah: Today, I guess, I moved across some line from left of center to full-on bleeding heart liberal, because my heart is bleeding tod\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751064283442737152",
    "text" : "Today, I guess, I moved across some line from left of center to full-on bleeding heart liberal, because my heart is bleeding today.",
    "id" : 751064283442737152,
    "created_at" : "2016-07-07 14:44:13 +0000",
    "user" : {
      "name" : "Jorah",
      "screen_name" : "jorah",
      "protected" : false,
      "id_str" : "10574772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801122953442238464\/tQprE8dr_normal.jpg",
      "id" : 10574772,
      "verified" : false
    }
  },
  "id" : 751084965652299776,
  "created_at" : "2016-07-07 16:06:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Floyd",
      "screen_name" : "dafloydsta",
      "indices" : [ 3, 14 ],
      "id_str" : "260902220",
      "id" : 260902220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751061091866804224",
  "text" : "RT @dafloydsta: THERAPIST: Have you tried just coming out of the closet?\n\nSKELETON: *sobbing* DO YOU THINK IT WOULD HELP?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735152421895311360",
    "text" : "THERAPIST: Have you tried just coming out of the closet?\n\nSKELETON: *sobbing* DO YOU THINK IT WOULD HELP?",
    "id" : 735152421895311360,
    "created_at" : "2016-05-24 16:56:10 +0000",
    "user" : {
      "name" : "Floyd",
      "screen_name" : "dafloydsta",
      "protected" : false,
      "id_str" : "260902220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793453486239256576\/FZjMZGQP_normal.jpg",
      "id" : 260902220,
      "verified" : false
    }
  },
  "id" : 751061091866804224,
  "created_at" : "2016-07-07 14:31:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Lowery",
      "screen_name" : "WesleyLowery",
      "indices" : [ 3, 16 ],
      "id_str" : "14849562",
      "id" : 14849562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PhilandoCastile",
      "indices" : [ 45, 61 ]
    }, {
      "text" : "falconheights",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751060465468538880",
  "text" : "RT @WesleyLowery: Here is what we know about #PhilandoCastile's death. \nThis file will update throughout the night #falconheights https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhilandoCastile",
        "indices" : [ 27, 43 ]
      }, {
        "text" : "falconheights",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/xjBmlTuGTu",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/morning-mix\/wp\/2016\/07\/07\/minn-cop-fatally-shoots-man-during-traffic-stop-aftermath-broadcast-on-facebook\/",
        "display_url" : "washingtonpost.com\/news\/morning-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750926219827408898",
    "text" : "Here is what we know about #PhilandoCastile's death. \nThis file will update throughout the night #falconheights https:\/\/t.co\/xjBmlTuGTu",
    "id" : 750926219827408898,
    "created_at" : "2016-07-07 05:35:36 +0000",
    "user" : {
      "name" : "Wesley Lowery",
      "screen_name" : "WesleyLowery",
      "protected" : false,
      "id_str" : "14849562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793529941958750209\/Sm0GWQM-_normal.jpg",
      "id" : 14849562,
      "verified" : true
    }
  },
  "id" : 751060465468538880,
  "created_at" : "2016-07-07 14:29:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "scifi",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/cEgQzPP3aA",
      "expanded_url" : "https:\/\/www.overdrive.com\/media\/1010361\/first-evidence",
      "display_url" : "overdrive.com\/media\/1010361\/\u2026"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/0j3UtrxpcZ",
      "expanded_url" : "https:\/\/twitter.com\/AudibleTips\/status\/750789254498910209",
      "display_url" : "twitter.com\/AudibleTips\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750863729080803328",
  "text" : "First Evidence by Ken Goddard https:\/\/t.co\/cEgQzPP3aA #mystery #scifi https:\/\/t.co\/0j3UtrxpcZ",
  "id" : 750863729080803328,
  "created_at" : "2016-07-07 01:27:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible Range",
      "screen_name" : "audiblerange",
      "indices" : [ 3, 16 ],
      "id_str" : "4173113283",
      "id" : 4173113283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750862831571103744",
  "text" : "RT @audiblerange: Tell a kid a story, she'll learn for a day... but teach her how to tell 'em, and it's another story entirely. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Q78j3GbSS4",
        "expanded_url" : "http:\/\/adbl.co\/kidstories",
        "display_url" : "adbl.co\/kidstories"
      } ]
    },
    "geo" : { },
    "id_str" : "750726910611783680",
    "text" : "Tell a kid a story, she'll learn for a day... but teach her how to tell 'em, and it's another story entirely. https:\/\/t.co\/Q78j3GbSS4",
    "id" : 750726910611783680,
    "created_at" : "2016-07-06 16:23:37 +0000",
    "user" : {
      "name" : "Audible Range",
      "screen_name" : "audiblerange",
      "protected" : false,
      "id_str" : "4173113283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712644092757454848\/Qz8Nhsig_normal.jpg",
      "id" : 4173113283,
      "verified" : false
    }
  },
  "id" : 750862831571103744,
  "created_at" : "2016-07-07 01:23:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Bowler",
      "screen_name" : "RichardBowler1",
      "indices" : [ 3, 18 ],
      "id_str" : "553323788",
      "id" : 553323788
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RichardBowler1\/status\/750561260924698630\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/z8rbee89uW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmqHWEUWAAAy844.jpg",
      "id_str" : "750561101096550400",
      "id" : 750561101096550400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmqHWEUWAAAy844.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1020
      } ],
      "display_url" : "pic.twitter.com\/z8rbee89uW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750823698744152064",
  "text" : "RT @RichardBowler1: Best foot forward, Harvest mouse on foxglove. https:\/\/t.co\/z8rbee89uW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RichardBowler1\/status\/750561260924698630\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/z8rbee89uW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmqHWEUWAAAy844.jpg",
        "id_str" : "750561101096550400",
        "id" : 750561101096550400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmqHWEUWAAAy844.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/z8rbee89uW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750561260924698630",
    "text" : "Best foot forward, Harvest mouse on foxglove. https:\/\/t.co\/z8rbee89uW",
    "id" : 750561260924698630,
    "created_at" : "2016-07-06 05:25:24 +0000",
    "user" : {
      "name" : "Richard Bowler",
      "screen_name" : "RichardBowler1",
      "protected" : false,
      "id_str" : "553323788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681757270745587712\/RfB32azg_normal.png",
      "id" : 553323788,
      "verified" : false
    }
  },
  "id" : 750823698744152064,
  "created_at" : "2016-07-06 22:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "indices" : [ 3, 16 ],
      "id_str" : "23150269",
      "id" : 23150269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750822223670349824",
  "text" : "RT @beardonabike: I suspect that many who fervently defend the right to carry a gun are approving of police shooting a man for having a gun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750799692334792704",
    "text" : "I suspect that many who fervently defend the right to carry a gun are approving of police shooting a man for having a gun in his pocket.",
    "id" : 750799692334792704,
    "created_at" : "2016-07-06 21:12:50 +0000",
    "user" : {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "protected" : false,
      "id_str" : "23150269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461260607669293056\/udIfmFCN_normal.jpeg",
      "id" : 23150269,
      "verified" : false
    }
  },
  "id" : 750822223670349824,
  "created_at" : "2016-07-06 22:42:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/750702036006629376\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/O61qqu5ery",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmsHewhWEAAKDdI.jpg",
      "id_str" : "750701987889549312",
      "id" : 750701987889549312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmsHewhWEAAKDdI.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/O61qqu5ery"
    } ],
    "hashtags" : [ {
      "text" : "GreatWesternCatskills",
      "indices" : [ 67, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750822186617806850",
  "text" : "RT @CatskillCritter: The upper meadow in mist, July morning in the #GreatWesternCatskills . . . https:\/\/t.co\/O61qqu5ery",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/750702036006629376\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/O61qqu5ery",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmsHewhWEAAKDdI.jpg",
        "id_str" : "750701987889549312",
        "id" : 750701987889549312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmsHewhWEAAKDdI.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/O61qqu5ery"
      } ],
      "hashtags" : [ {
        "text" : "GreatWesternCatskills",
        "indices" : [ 46, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750702036006629376",
    "text" : "The upper meadow in mist, July morning in the #GreatWesternCatskills . . . https:\/\/t.co\/O61qqu5ery",
    "id" : 750702036006629376,
    "created_at" : "2016-07-06 14:44:47 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 750822186617806850,
  "created_at" : "2016-07-06 22:42:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendra W \u2728",
      "screen_name" : "kendrawcandraw",
      "indices" : [ 3, 18 ],
      "id_str" : "1350410232",
      "id" : 1350410232
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kendrawcandraw\/status\/750508679183601664\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/nOU4SDhmQo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpXXkeWEAEHDPo.jpg",
      "id_str" : "750508350350168065",
      "id" : 750508350350168065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpXXkeWEAEHDPo.jpg",
      "sizes" : [ {
        "h" : 775,
        "resize" : "fit",
        "w" : 773
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 775,
        "resize" : "fit",
        "w" : 773
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 775,
        "resize" : "fit",
        "w" : 773
      } ],
      "display_url" : "pic.twitter.com\/nOU4SDhmQo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/kendrawcandraw\/status\/750508679183601664\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/nOU4SDhmQo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpXYWfXEAEKGF-.jpg",
      "id_str" : "750508363776200705",
      "id" : 750508363776200705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpXYWfXEAEKGF-.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 772
      } ],
      "display_url" : "pic.twitter.com\/nOU4SDhmQo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/kendrawcandraw\/status\/750508679183601664\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/nOU4SDhmQo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpXpK8WYAArqiY.jpg",
      "id_str" : "750508652734341120",
      "id" : 750508652734341120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpXpK8WYAArqiY.jpg",
      "sizes" : [ {
        "h" : 770,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 770,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 770,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nOU4SDhmQo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750813607584206849",
  "text" : "RT @kendrawcandraw: Is the person naming these colors of yarn okay https:\/\/t.co\/nOU4SDhmQo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kendrawcandraw\/status\/750508679183601664\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/nOU4SDhmQo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpXXkeWEAEHDPo.jpg",
        "id_str" : "750508350350168065",
        "id" : 750508350350168065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpXXkeWEAEHDPo.jpg",
        "sizes" : [ {
          "h" : 775,
          "resize" : "fit",
          "w" : 773
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 775,
          "resize" : "fit",
          "w" : 773
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 775,
          "resize" : "fit",
          "w" : 773
        } ],
        "display_url" : "pic.twitter.com\/nOU4SDhmQo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/kendrawcandraw\/status\/750508679183601664\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/nOU4SDhmQo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpXYWfXEAEKGF-.jpg",
        "id_str" : "750508363776200705",
        "id" : 750508363776200705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpXYWfXEAEKGF-.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 773,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 773,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 773,
          "resize" : "fit",
          "w" : 772
        } ],
        "display_url" : "pic.twitter.com\/nOU4SDhmQo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/kendrawcandraw\/status\/750508679183601664\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/nOU4SDhmQo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmpXpK8WYAArqiY.jpg",
        "id_str" : "750508652734341120",
        "id" : 750508652734341120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmpXpK8WYAArqiY.jpg",
        "sizes" : [ {
          "h" : 770,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/nOU4SDhmQo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750508679183601664",
    "text" : "Is the person naming these colors of yarn okay https:\/\/t.co\/nOU4SDhmQo",
    "id" : 750508679183601664,
    "created_at" : "2016-07-06 01:56:27 +0000",
    "user" : {
      "name" : "Kendra W \u2728",
      "screen_name" : "kendrawcandraw",
      "protected" : false,
      "id_str" : "1350410232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793502479241637892\/tSIMhZuj_normal.jpg",
      "id" : 1350410232,
      "verified" : false
    }
  },
  "id" : 750813607584206849,
  "created_at" : "2016-07-06 22:08:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750789095828381697",
  "text" : "why cant sandisk make a software to manage the clip sport? (maybe they do?) gah. using diff programs to manage, music, audiobooks, pocasts.",
  "id" : 750789095828381697,
  "created_at" : "2016-07-06 20:30:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelso",
      "screen_name" : "audible",
      "indices" : [ 28, 36 ],
      "id_str" : "1579651",
      "id" : 1579651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750749657052086272",
  "text" : "i got a refurb clip sport.. @audible should buy and improve. not a bad little player but could be smoother re: getting content.",
  "id" : 750749657052086272,
  "created_at" : "2016-07-06 17:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "indices" : [ 3, 17 ],
      "id_str" : "23372297",
      "id" : 23372297
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LorenzoTheCat\/status\/750394798448619520\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/rKqvaqTAt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmnwDl2UkAAS146.jpg",
      "id_str" : "750394757424123904",
      "id" : 750394757424123904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmnwDl2UkAAS146.jpg",
      "sizes" : [ {
        "h" : 1635,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2177,
        "resize" : "fit",
        "w" : 2727
      }, {
        "h" : 958,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/rKqvaqTAt4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750394911577542656",
  "text" : "RT @LorenzoTheCat: That's me---I needed extra hugs during the fireworks last night. https:\/\/t.co\/rKqvaqTAt4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LorenzoTheCat\/status\/750394798448619520\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/rKqvaqTAt4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmnwDl2UkAAS146.jpg",
        "id_str" : "750394757424123904",
        "id" : 750394757424123904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmnwDl2UkAAS146.jpg",
        "sizes" : [ {
          "h" : 1635,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2177,
          "resize" : "fit",
          "w" : 2727
        }, {
          "h" : 958,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/rKqvaqTAt4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750394798448619520",
    "text" : "That's me---I needed extra hugs during the fireworks last night. https:\/\/t.co\/rKqvaqTAt4",
    "id" : 750394798448619520,
    "created_at" : "2016-07-05 18:23:56 +0000",
    "user" : {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "protected" : false,
      "id_str" : "23372297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1047336743\/Marked-Americana_normal.jpg",
      "id" : 23372297,
      "verified" : true
    }
  },
  "id" : 750394911577542656,
  "created_at" : "2016-07-05 18:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/WS1M3Ht9XA",
      "expanded_url" : "https:\/\/vine.co\/v\/5a67Kb7A6Wn",
      "display_url" : "vine.co\/v\/5a67Kb7A6Wn"
    } ]
  },
  "geo" : { },
  "id_str" : "750382224328056832",
  "text" : "RT @ZwartblesIE: The horse guard horse gives me a smile https:\/\/t.co\/WS1M3Ht9XA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/WS1M3Ht9XA",
        "expanded_url" : "https:\/\/vine.co\/v\/5a67Kb7A6Wn",
        "display_url" : "vine.co\/v\/5a67Kb7A6Wn"
      } ]
    },
    "geo" : { },
    "id_str" : "750337264891330560",
    "text" : "The horse guard horse gives me a smile https:\/\/t.co\/WS1M3Ht9XA",
    "id" : 750337264891330560,
    "created_at" : "2016-07-05 14:35:19 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 750382224328056832,
  "created_at" : "2016-07-05 17:33:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Audible",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750124306252914688",
  "text" : "I finished listening to The Redemption Engine (Unabridged) by James L. Sutter, narrated by Ray Porter on my #Audible app.",
  "id" : 750124306252914688,
  "created_at" : "2016-07-05 00:29:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749657442980663296",
  "geo" : { },
  "id_str" : "749685516048687104",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 my mom made excellent potato salad.. can't eat any other.",
  "id" : 749685516048687104,
  "in_reply_to_status_id" : 749657442980663296,
  "created_at" : "2016-07-03 19:25:30 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749666963346034690",
  "text" : "She often complains of throbbing neck. 2 endos. Both just looked at numbers then moved on. #hashimotos",
  "id" : 749666963346034690,
  "created_at" : "2016-07-03 18:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749665932277063681",
  "text" : "Wonder if episodes are broken thyroid cells releasing hormones? #hashimotos",
  "id" : 749665932277063681,
  "created_at" : "2016-07-03 18:07:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "indices" : [ 3, 19 ],
      "id_str" : "2530698811",
      "id" : 2530698811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/749497759741440000\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/QS76vs7tqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmbAOkUXEAApVbG.jpg",
      "id_str" : "749497744503541760",
      "id" : 749497744503541760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmbAOkUXEAApVbG.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/QS76vs7tqE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749646430793502721",
  "text" : "RT @JRfromStrickley: The weekend traffic in The Lake District is horrendous... https:\/\/t.co\/QS76vs7tqE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/749497759741440000\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/QS76vs7tqE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmbAOkUXEAApVbG.jpg",
        "id_str" : "749497744503541760",
        "id" : 749497744503541760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmbAOkUXEAApVbG.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/QS76vs7tqE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749497759741440000",
    "text" : "The weekend traffic in The Lake District is horrendous... https:\/\/t.co\/QS76vs7tqE",
    "id" : 749497759741440000,
    "created_at" : "2016-07-03 06:59:25 +0000",
    "user" : {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "protected" : false,
      "id_str" : "2530698811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682844561933217792\/DmT71D0G_normal.jpg",
      "id" : 2530698811,
      "verified" : false
    }
  },
  "id" : 749646430793502721,
  "created_at" : "2016-07-03 16:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toto Habschned",
      "screen_name" : "totohabschned",
      "indices" : [ 0, 14 ],
      "id_str" : "46611987",
      "id" : 46611987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749621914948231168",
  "geo" : { },
  "id_str" : "749646379656568832",
  "in_reply_to_user_id" : 46611987,
  "text" : "@totohabschned I just like the picture. Have no idea what post says..lol.",
  "id" : 749646379656568832,
  "in_reply_to_status_id" : 749621914948231168,
  "created_at" : "2016-07-03 16:49:59 +0000",
  "in_reply_to_screen_name" : "totohabschned",
  "in_reply_to_user_id_str" : "46611987",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Mahnke",
      "screen_name" : "amahnke",
      "indices" : [ 3, 11 ],
      "id_str" : "14519030",
      "id" : 14519030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749645648031612932",
  "text" : "RT @amahnke: Ah, 4th of July weekend. Otherwise known as \u2018Four Long Days When Bored People Without Dogs Let Off Fireworks For Momentary Enj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749582664550772736",
    "text" : "Ah, 4th of July weekend. Otherwise known as \u2018Four Long Days When Bored People Without Dogs Let Off Fireworks For Momentary Enjoyment\u201C.",
    "id" : 749582664550772736,
    "created_at" : "2016-07-03 12:36:48 +0000",
    "user" : {
      "name" : "Aaron Mahnke",
      "screen_name" : "amahnke",
      "protected" : false,
      "id_str" : "14519030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798517533959684096\/zugr2CMm_normal.jpg",
      "id" : 14519030,
      "verified" : true
    }
  },
  "id" : 749645648031612932,
  "created_at" : "2016-07-03 16:47:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 3, 7 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CNNSOTU",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/xy1ZuFqXXI",
      "expanded_url" : "http:\/\/cnn.it\/29ghfYU",
      "display_url" : "cnn.it\/29ghfYU"
    } ]
  },
  "geo" : { },
  "id_str" : "749644039121756160",
  "text" : "RT @CNN: Cory Booker: I'm referring questions about the VP job to the Clinton campaign https:\/\/t.co\/xy1ZuFqXXI #CNNSOTU https:\/\/t.co\/6s9hRR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CNNSOTU",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/xy1ZuFqXXI",
        "expanded_url" : "http:\/\/cnn.it\/29ghfYU",
        "display_url" : "cnn.it\/29ghfYU"
      }, {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/6s9hRRiCVM",
        "expanded_url" : "http:\/\/cnn.it\/29ojk8I",
        "display_url" : "cnn.it\/29ojk8I"
      } ]
    },
    "geo" : { },
    "id_str" : "749592883792121856",
    "text" : "Cory Booker: I'm referring questions about the VP job to the Clinton campaign https:\/\/t.co\/xy1ZuFqXXI #CNNSOTU https:\/\/t.co\/6s9hRRiCVM",
    "id" : 749592883792121856,
    "created_at" : "2016-07-03 13:17:24 +0000",
    "user" : {
      "name" : "CNN",
      "screen_name" : "CNN",
      "protected" : false,
      "id_str" : "759251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508960761826131968\/LnvhR8ED_normal.png",
      "id" : 759251,
      "verified" : true
    }
  },
  "id" : 749644039121756160,
  "created_at" : "2016-07-03 16:40:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Timothy Furnish",
      "screen_name" : "Occidentaljihad",
      "indices" : [ 3, 19 ],
      "id_str" : "28374369",
      "id" : 28374369
    }, {
      "name" : "Tara Imani, AIA, CSI",
      "screen_name" : "Parthenon1",
      "indices" : [ 21, 32 ],
      "id_str" : "259839167",
      "id" : 259839167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749642670340005888",
  "text" : "RT @Occidentaljihad: @Parthenon1 Many fundamentalist Evangelicals adhere to strict Biblical literalism &amp; seem to substitute Bible for Chris\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tara Imani, AIA, CSI",
        "screen_name" : "Parthenon1",
        "indices" : [ 0, 11 ],
        "id_str" : "259839167",
        "id" : 259839167
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "745646435463401473",
    "geo" : { },
    "id_str" : "745646759066673153",
    "in_reply_to_user_id" : 259839167,
    "text" : "@Parthenon1 Many fundamentalist Evangelicals adhere to strict Biblical literalism &amp; seem to substitute Bible for Christ as Word of God.",
    "id" : 745646759066673153,
    "in_reply_to_status_id" : 745646435463401473,
    "created_at" : "2016-06-22 15:56:55 +0000",
    "in_reply_to_screen_name" : "Parthenon1",
    "in_reply_to_user_id_str" : "259839167",
    "user" : {
      "name" : "Dr. Timothy Furnish",
      "screen_name" : "Occidentaljihad",
      "protected" : false,
      "id_str" : "28374369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787735062859030528\/55EWF8ue_normal.jpg",
      "id" : 28374369,
      "verified" : false
    }
  },
  "id" : 749642670340005888,
  "created_at" : "2016-07-03 16:35:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/agsiYGJdqN",
      "expanded_url" : "http:\/\/www.flyinginthespirit.cuttys.net\/2016\/07\/03\/the-absurdity-of-the-modern-doctrine-of-hell\/",
      "display_url" : "flyinginthespirit.cuttys.net\/2016\/07\/03\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749638080894758912",
  "text" : "The Absurdity of the Modern Doctrine of Hell https:\/\/t.co\/agsiYGJdqN",
  "id" : 749638080894758912,
  "created_at" : "2016-07-03 16:17:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749626565177307136",
  "text" : "2nd Ativan 3 hrs after 1st helping her to rest.",
  "id" : 749626565177307136,
  "created_at" : "2016-07-03 15:31:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stardust",
      "screen_name" : "rockermom53",
      "indices" : [ 3, 15 ],
      "id_str" : "14522779",
      "id" : 14522779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/r7hJQS6y2M",
      "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/748699929787457537",
      "display_url" : "twitter.com\/planetepics\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749619300764360704",
  "text" : "RT @rockermom53: There is a jungle? Incredible. As in how in the heck without sunlight? https:\/\/t.co\/r7hJQS6y2M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/r7hJQS6y2M",
        "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/748699929787457537",
        "display_url" : "twitter.com\/planetepics\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749618215890800640",
    "text" : "There is a jungle? Incredible. As in how in the heck without sunlight? https:\/\/t.co\/r7hJQS6y2M",
    "id" : 749618215890800640,
    "created_at" : "2016-07-03 14:58:04 +0000",
    "user" : {
      "name" : "stardust",
      "screen_name" : "rockermom53",
      "protected" : false,
      "id_str" : "14522779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793606996817645569\/hFlxXf9M_normal.jpg",
      "id" : 14522779,
      "verified" : false
    }
  },
  "id" : 749619300764360704,
  "created_at" : "2016-07-03 15:02:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 34, 49 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749619111580332032",
  "text" : "My poor baby had episode this am. #chronicillness #hashimotos",
  "id" : 749619111580332032,
  "created_at" : "2016-07-03 15:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AudibleClips",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749398252588531712",
  "text" : "RT @audible_com: Share clips that connect the people you love with the stories that surround you. #AudibleClips: now on Android. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AudibleClips",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/7dGX9cHWQb",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=d04PDeWdTyg",
        "display_url" : "youtube.com\/watch?v=d04PDe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749346913070309376",
    "text" : "Share clips that connect the people you love with the stories that surround you. #AudibleClips: now on Android. https:\/\/t.co\/7dGX9cHWQb",
    "id" : 749346913070309376,
    "created_at" : "2016-07-02 21:00:00 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 749398252588531712,
  "created_at" : "2016-07-03 00:24:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/audible_com\/status\/749388444112195585\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/JZCqQqUcyF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZc0G1WcAQCeKw.jpg",
      "id_str" : "749388438261100548",
      "id" : 749388438261100548,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZc0G1WcAQCeKw.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/JZCqQqUcyF"
    } ],
    "hashtags" : [ {
      "text" : "HGWells",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "AudibleChannels",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749398000070451201",
  "text" : "RT @audible_com: Spend 7 days with sci-fi OG #HGWells\u2014hear a new story every day on #AudibleChannels. https:\/\/t.co\/JZCqQqUcyF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/audible_com\/status\/749388444112195585\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/JZCqQqUcyF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZc0G1WcAQCeKw.jpg",
        "id_str" : "749388438261100548",
        "id" : 749388438261100548,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZc0G1WcAQCeKw.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/JZCqQqUcyF"
      } ],
      "hashtags" : [ {
        "text" : "HGWells",
        "indices" : [ 28, 36 ]
      }, {
        "text" : "AudibleChannels",
        "indices" : [ 67, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749388444112195585",
    "text" : "Spend 7 days with sci-fi OG #HGWells\u2014hear a new story every day on #AudibleChannels. https:\/\/t.co\/JZCqQqUcyF",
    "id" : 749388444112195585,
    "created_at" : "2016-07-02 23:45:02 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 749398000070451201,
  "created_at" : "2016-07-03 00:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/749331403066793984\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/1kUh18Bgum",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmYo5GFWAAAW2qW.jpg",
      "id_str" : "749331349354446848",
      "id" : 749331349354446848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmYo5GFWAAAW2qW.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/1kUh18Bgum"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/749331403066793984\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/1kUh18Bgum",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmYo5HqXEAAkmpE.jpg",
      "id_str" : "749331349778141184",
      "id" : 749331349778141184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmYo5HqXEAAkmpE.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/1kUh18Bgum"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749397671971057664",
  "text" : "RT @newlandfarm: Making friends \uD83D\uDC2E\uD83D\uDC36\uD83D\uDC45 https:\/\/t.co\/1kUh18Bgum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/749331403066793984\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/1kUh18Bgum",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmYo5GFWAAAW2qW.jpg",
        "id_str" : "749331349354446848",
        "id" : 749331349354446848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmYo5GFWAAAW2qW.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/1kUh18Bgum"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/749331403066793984\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/1kUh18Bgum",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmYo5HqXEAAkmpE.jpg",
        "id_str" : "749331349778141184",
        "id" : 749331349778141184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmYo5HqXEAAkmpE.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/1kUh18Bgum"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749331403066793984",
    "text" : "Making friends \uD83D\uDC2E\uD83D\uDC36\uD83D\uDC45 https:\/\/t.co\/1kUh18Bgum",
    "id" : 749331403066793984,
    "created_at" : "2016-07-02 19:58:23 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 749397671971057664,
  "created_at" : "2016-07-03 00:21:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749381133062680576",
  "geo" : { },
  "id_str" : "749397569185415169",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley sweet!",
  "id" : 749397569185415169,
  "in_reply_to_status_id" : 749381133062680576,
  "created_at" : "2016-07-03 00:21:18 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/749381133062680576\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XO3jLRY7te",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZWJ7YUEAArTP0.jpg",
      "id_str" : "749381116562247680",
      "id" : 749381116562247680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZWJ7YUEAArTP0.jpg",
      "sizes" : [ {
        "h" : 1534,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1534,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 899,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/XO3jLRY7te"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/749381133062680576\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XO3jLRY7te",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZWJ9QUMAA1qV8.jpg",
      "id_str" : "749381117065572352",
      "id" : 749381117065572352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZWJ9QUMAA1qV8.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/XO3jLRY7te"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/749381133062680576\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XO3jLRY7te",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZWJ7cUkAAjFsQ.jpg",
      "id_str" : "749381116579057664",
      "id" : 749381116579057664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZWJ7cUkAAjFsQ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/XO3jLRY7te"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749397488617021440",
  "text" : "RT @ErinEFarley: The frogs still haven't moved into the village I made for them. Maybe I'm trying too hard... https:\/\/t.co\/XO3jLRY7te",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/749381133062680576\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/XO3jLRY7te",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZWJ7YUEAArTP0.jpg",
        "id_str" : "749381116562247680",
        "id" : 749381116562247680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZWJ7YUEAArTP0.jpg",
        "sizes" : [ {
          "h" : 1534,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1534,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 899,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/XO3jLRY7te"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/749381133062680576\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/XO3jLRY7te",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZWJ9QUMAA1qV8.jpg",
        "id_str" : "749381117065572352",
        "id" : 749381117065572352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZWJ9QUMAA1qV8.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/XO3jLRY7te"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/749381133062680576\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/XO3jLRY7te",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZWJ7cUkAAjFsQ.jpg",
        "id_str" : "749381116579057664",
        "id" : 749381116579057664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZWJ7cUkAAjFsQ.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/XO3jLRY7te"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749381133062680576",
    "text" : "The frogs still haven't moved into the village I made for them. Maybe I'm trying too hard... https:\/\/t.co\/XO3jLRY7te",
    "id" : 749381133062680576,
    "created_at" : "2016-07-02 23:15:59 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 749397488617021440,
  "created_at" : "2016-07-03 00:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gPqe4HCPpR",
      "expanded_url" : "https:\/\/twitter.com\/aig\/status\/672461441325211648",
      "display_url" : "twitter.com\/aig\/status\/672\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749397185247252480",
  "text" : "RT @AnnotatedBible: How can 24-hour days exist BEFORE the sun was created? \n\nHow long was the \"day\" in Genesis 2:4? https:\/\/t.co\/gPqe4HCPpR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/gPqe4HCPpR",
        "expanded_url" : "https:\/\/twitter.com\/aig\/status\/672461441325211648",
        "display_url" : "twitter.com\/aig\/status\/672\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749396063467954176",
    "text" : "How can 24-hour days exist BEFORE the sun was created? \n\nHow long was the \"day\" in Genesis 2:4? https:\/\/t.co\/gPqe4HCPpR",
    "id" : 749396063467954176,
    "created_at" : "2016-07-03 00:15:19 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 749397185247252480,
  "created_at" : "2016-07-03 00:19:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bible",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749397098618060800",
  "text" : "RT @AnnotatedBible: It makes zero sense to say that a \"day\" would be 24 hours long BEFORE the sun was created in Genesis 1:14. #Bible #crea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bible",
        "indices" : [ 107, 113 ]
      }, {
        "text" : "creationism",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "creation",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749395373530050560",
    "text" : "It makes zero sense to say that a \"day\" would be 24 hours long BEFORE the sun was created in Genesis 1:14. #Bible #creationism #creation",
    "id" : 749395373530050560,
    "created_at" : "2016-07-03 00:12:34 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 749397098618060800,
  "created_at" : "2016-07-03 00:19:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749272135210860544",
  "text" : "reading about a gal who struggles w SSA in her new christian life. trying to live right according to god.. sigh. : (",
  "id" : 749272135210860544,
  "created_at" : "2016-07-02 16:02:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Dark Room for iOS",
      "screen_name" : "ADarkRoomiOS",
      "indices" : [ 3, 16 ],
      "id_str" : "2185159123",
      "id" : 2185159123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749271312493862912",
  "text" : "RT @ADarkRoomiOS: In case you missed it, A Dark Room is officially released on Android. Retweet this and I won't kill your villagers: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/mGS40XV4f7",
        "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.yourcompany.adarkroom",
        "display_url" : "play.google.com\/store\/apps\/det\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749270562266976256",
    "text" : "In case you missed it, A Dark Room is officially released on Android. Retweet this and I won't kill your villagers: https:\/\/t.co\/mGS40XV4f7",
    "id" : 749270562266976256,
    "created_at" : "2016-07-02 15:56:37 +0000",
    "user" : {
      "name" : "A Dark Room for iOS",
      "screen_name" : "ADarkRoomiOS",
      "protected" : false,
      "id_str" : "2185159123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508661798845677568\/5vWIkqwL_normal.png",
      "id" : 2185159123,
      "verified" : false
    }
  },
  "id" : 749271312493862912,
  "created_at" : "2016-07-02 15:59:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749270952526155776",
  "text" : "it makes me sad ppl really believing they're born depraved, unworthy of love, mercy.",
  "id" : 749270952526155776,
  "created_at" : "2016-07-02 15:58:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "feedly",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HF2jqhXLZN",
      "expanded_url" : "http:\/\/the-digital-reader.com\/2016\/07\/02\/why-the-fire-tablet-still-sucks-for-reading-ebooks\/",
      "display_url" : "the-digital-reader.com\/2016\/07\/02\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749246555933270016",
  "text" : "Why the Fire Tablet Still Sucks for Reading eBooks \u2013 a Rant https:\/\/t.co\/HF2jqhXLZN #books #feedly",
  "id" : 749246555933270016,
  "created_at" : "2016-07-02 14:21:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AudibleClips",
      "indices" : [ 35, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/0lVmeQXQFC",
      "expanded_url" : "http:\/\/adbl.co\/ClipsOverview",
      "display_url" : "adbl.co\/ClipsOverview"
    }, {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/sdyes2uEv6",
      "expanded_url" : "https:\/\/twitter.com\/sahraobsessed\/status\/711227945654685696",
      "display_url" : "twitter.com\/sahraobsessed\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749244263246995456",
  "text" : "RT @audible_com: The wait is over! #AudibleClips is now available for Android: https:\/\/t.co\/0lVmeQXQFC https:\/\/t.co\/sdyes2uEv6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AudibleClips",
        "indices" : [ 18, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/0lVmeQXQFC",
        "expanded_url" : "http:\/\/adbl.co\/ClipsOverview",
        "display_url" : "adbl.co\/ClipsOverview"
      }, {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/sdyes2uEv6",
        "expanded_url" : "https:\/\/twitter.com\/sahraobsessed\/status\/711227945654685696",
        "display_url" : "twitter.com\/sahraobsessed\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748946775235522560",
    "text" : "The wait is over! #AudibleClips is now available for Android: https:\/\/t.co\/0lVmeQXQFC https:\/\/t.co\/sdyes2uEv6",
    "id" : 748946775235522560,
    "created_at" : "2016-07-01 18:30:00 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 749244263246995456,
  "created_at" : "2016-07-02 14:12:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trees etc.",
      "screen_name" : "arborsmarty",
      "indices" : [ 3, 15 ],
      "id_str" : "628270697",
      "id" : 628270697
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/arborsmarty\/status\/749043878313897984\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/7vdUHVHBPb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmUjbLnUkAAr10e.jpg",
      "id_str" : "749043862908211200",
      "id" : 749043862908211200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmUjbLnUkAAr10e.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 532
      } ],
      "display_url" : "pic.twitter.com\/7vdUHVHBPb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749051042113937408",
  "text" : "RT @arborsmarty: https:\/\/t.co\/7vdUHVHBPb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arborsmarty\/status\/749043878313897984\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/7vdUHVHBPb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmUjbLnUkAAr10e.jpg",
        "id_str" : "749043862908211200",
        "id" : 749043862908211200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmUjbLnUkAAr10e.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 532
        } ],
        "display_url" : "pic.twitter.com\/7vdUHVHBPb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749043878313897984",
    "text" : "https:\/\/t.co\/7vdUHVHBPb",
    "id" : 749043878313897984,
    "created_at" : "2016-07-02 00:55:51 +0000",
    "user" : {
      "name" : "Trees etc.",
      "screen_name" : "arborsmarty",
      "protected" : false,
      "id_str" : "628270697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735046067876569089\/krv_vUtM_normal.jpg",
      "id" : 628270697,
      "verified" : false
    }
  },
  "id" : 749051042113937408,
  "created_at" : "2016-07-02 01:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stardust",
      "screen_name" : "rockermom53",
      "indices" : [ 3, 15 ],
      "id_str" : "14522779",
      "id" : 14522779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/I8nKj9fwa7",
      "expanded_url" : "https:\/\/twitter.com\/globe_pics\/status\/749038594237538305",
      "display_url" : "twitter.com\/globe_pics\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749046531752353792",
  "text" : "RT @rockermom53: Breath taking https:\/\/t.co\/I8nKj9fwa7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/I8nKj9fwa7",
        "expanded_url" : "https:\/\/twitter.com\/globe_pics\/status\/749038594237538305",
        "display_url" : "twitter.com\/globe_pics\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749039994115747840",
    "text" : "Breath taking https:\/\/t.co\/I8nKj9fwa7",
    "id" : 749039994115747840,
    "created_at" : "2016-07-02 00:40:25 +0000",
    "user" : {
      "name" : "stardust",
      "screen_name" : "rockermom53",
      "protected" : false,
      "id_str" : "14522779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793606996817645569\/hFlxXf9M_normal.jpg",
      "id" : 14522779,
      "verified" : false
    }
  },
  "id" : 749046531752353792,
  "created_at" : "2016-07-02 01:06:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Ross",
      "screen_name" : "NickBossRoss",
      "indices" : [ 3, 16 ],
      "id_str" : "312433419",
      "id" : 312433419
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NickBossRoss\/status\/617535425138176000\/video\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/leF9ESCril",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617535106849206274\/pu\/img\/geF2cNBJ_Zxz_qFG.jpg",
      "id_str" : "617535106849206274",
      "id" : 617535106849206274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617535106849206274\/pu\/img\/geF2cNBJ_Zxz_qFG.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/leF9ESCril"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749043783828996096",
  "text" : "RT @NickBossRoss: Canada is such a stereotype. http:\/\/t.co\/leF9ESCril",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NickBossRoss\/status\/617535425138176000\/video\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/leF9ESCril",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617535106849206274\/pu\/img\/geF2cNBJ_Zxz_qFG.jpg",
        "id_str" : "617535106849206274",
        "id" : 617535106849206274,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617535106849206274\/pu\/img\/geF2cNBJ_Zxz_qFG.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/leF9ESCril"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617535425138176000",
    "text" : "Canada is such a stereotype. http:\/\/t.co\/leF9ESCril",
    "id" : 617535425138176000,
    "created_at" : "2015-07-05 03:28:13 +0000",
    "user" : {
      "name" : "Nick Ross",
      "screen_name" : "NickBossRoss",
      "protected" : false,
      "id_str" : "312433419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615054746257240064\/b_3fjjOA_normal.jpg",
      "id" : 312433419,
      "verified" : true
    }
  },
  "id" : 749043783828996096,
  "created_at" : "2016-07-02 00:55:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Collins",
      "screen_name" : "stan_sdcollins",
      "indices" : [ 3, 18 ],
      "id_str" : "858549320",
      "id" : 858549320
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stan_sdcollins\/status\/749002764542410752\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/HCY5w1nHr5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmT-CzqWIAIXdT-.jpg",
      "id_str" : "749002762231357442",
      "id" : 749002762231357442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmT-CzqWIAIXdT-.jpg",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HCY5w1nHr5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749042581103869954",
  "text" : "RT @stan_sdcollins: A little female moose out on patrol to find the tastiest bushes for lunch. https:\/\/t.co\/HCY5w1nHr5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stan_sdcollins\/status\/749002764542410752\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/HCY5w1nHr5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmT-CzqWIAIXdT-.jpg",
        "id_str" : "749002762231357442",
        "id" : 749002762231357442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmT-CzqWIAIXdT-.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HCY5w1nHr5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749002764542410752",
    "text" : "A little female moose out on patrol to find the tastiest bushes for lunch. https:\/\/t.co\/HCY5w1nHr5",
    "id" : 749002764542410752,
    "created_at" : "2016-07-01 22:12:29 +0000",
    "user" : {
      "name" : "Stan Collins",
      "screen_name" : "stan_sdcollins",
      "protected" : false,
      "id_str" : "858549320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619964096205746176\/PDQ33Uf9_normal.jpg",
      "id" : 858549320,
      "verified" : false
    }
  },
  "id" : 749042581103869954,
  "created_at" : "2016-07-02 00:50:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hachette Audio",
      "screen_name" : "HachetteAudio",
      "indices" : [ 3, 17 ],
      "id_str" : "300912850",
      "id" : 300912850
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HachetteAudio\/status\/748876982717452288\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/m9Dd5L4tRN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmSJkKfXgAAgy8B.jpg",
      "id_str" : "748874692434558976",
      "id" : 748874692434558976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmSJkKfXgAAgy8B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/m9Dd5L4tRN"
    } ],
    "hashtags" : [ {
      "text" : "LoveAudiobooks",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748920435312648192",
  "text" : "RT @HachetteAudio: Happy July! \n\n*I suddenly realize: Audiobooks Month is over... #LoveAudiobooks https:\/\/t.co\/m9Dd5L4tRN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HachetteAudio\/status\/748876982717452288\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/m9Dd5L4tRN",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmSJkKfXgAAgy8B.jpg",
        "id_str" : "748874692434558976",
        "id" : 748874692434558976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmSJkKfXgAAgy8B.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        } ],
        "display_url" : "pic.twitter.com\/m9Dd5L4tRN"
      } ],
      "hashtags" : [ {
        "text" : "LoveAudiobooks",
        "indices" : [ 63, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748876982717452288",
    "text" : "Happy July! \n\n*I suddenly realize: Audiobooks Month is over... #LoveAudiobooks https:\/\/t.co\/m9Dd5L4tRN",
    "id" : 748876982717452288,
    "created_at" : "2016-07-01 13:52:40 +0000",
    "user" : {
      "name" : "Hachette Audio",
      "screen_name" : "HachetteAudio",
      "protected" : false,
      "id_str" : "300912850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743507206369337344\/m3bGhEJM_normal.jpg",
      "id" : 300912850,
      "verified" : false
    }
  },
  "id" : 748920435312648192,
  "created_at" : "2016-07-01 16:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Ruberry",
      "screen_name" : "erinruberry",
      "indices" : [ 3, 15 ],
      "id_str" : "62502942",
      "id" : 62502942
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/erinruberry\/status\/748849104487342080\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/hh98TBaK87",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
      "id_str" : "748849097520676865",
      "id" : 748849097520676865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/hh98TBaK87"
    } ],
    "hashtags" : [ {
      "text" : "CanadaDay",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748874345016066048",
  "text" : "RT @erinruberry: Excuse me, do you have a moment to talk about #CanadaDay? https:\/\/t.co\/hh98TBaK87",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/erinruberry\/status\/748849104487342080\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/hh98TBaK87",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
        "id_str" : "748849097520676865",
        "id" : 748849097520676865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/hh98TBaK87"
      } ],
      "hashtags" : [ {
        "text" : "CanadaDay",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748849104487342080",
    "text" : "Excuse me, do you have a moment to talk about #CanadaDay? https:\/\/t.co\/hh98TBaK87",
    "id" : 748849104487342080,
    "created_at" : "2016-07-01 12:01:54 +0000",
    "user" : {
      "name" : "Erin Ruberry",
      "screen_name" : "erinruberry",
      "protected" : false,
      "id_str" : "62502942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661147247531458560\/LBG_ABbh_normal.jpg",
      "id" : 62502942,
      "verified" : true
    }
  },
  "id" : 748874345016066048,
  "created_at" : "2016-07-01 13:42:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/GFVGoBui8j",
      "expanded_url" : "https:\/\/twitter.com\/rachelheldevans\/status\/748868794555195392",
      "display_url" : "twitter.com\/rachelheldevan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748872818855649280",
  "text" : "RT @rjmedwed: It\u2019s amazing how many people confuse loss of supremacy with persecution.\n\n https:\/\/t.co\/GFVGoBui8j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/GFVGoBui8j",
        "expanded_url" : "https:\/\/twitter.com\/rachelheldevans\/status\/748868794555195392",
        "display_url" : "twitter.com\/rachelheldevan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748869059580571648",
    "text" : "It\u2019s amazing how many people confuse loss of supremacy with persecution.\n\n https:\/\/t.co\/GFVGoBui8j",
    "id" : 748869059580571648,
    "created_at" : "2016-07-01 13:21:11 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 748872818855649280,
  "created_at" : "2016-07-01 13:36:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748870679714496512",
  "text" : "everything is subjective. absolutely nothing is objective.",
  "id" : 748870679714496512,
  "created_at" : "2016-07-01 13:27:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]