Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86541993781641217",
  "text" : "Me as a kid &gt;&gt; How Quiet is Too Quiet? When Shyness is Actually a Disorder  http:\/\/yhoo.it\/jtq5RU",
  "id" : 86541993781641217,
  "created_at" : "2011-06-30 21:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86458001879339008",
  "text" : "havent been here much. been busy. smell the smoke? :D",
  "id" : 86458001879339008,
  "created_at" : "2011-06-30 15:36:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86420740366270464",
  "geo" : { },
  "id_str" : "86421660957294592",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous LOL",
  "id" : 86421660957294592,
  "in_reply_to_status_id" : 86420740366270464,
  "created_at" : "2011-06-30 13:11:44 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86421608515903488",
  "text" : "RT @Matth3ous: It's 9:06. I've completed 6\/11 tasks, one of which was create a new budget. So far I'm more productive this morning than  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86420740366270464",
    "text" : "It's 9:06. I've completed 6\/11 tasks, one of which was create a new budget. So far I'm more productive this morning than the US gov annually",
    "id" : 86420740366270464,
    "created_at" : "2011-06-30 13:08:04 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 86421608515903488,
  "created_at" : "2011-06-30 13:11:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86247628463026176",
  "geo" : { },
  "id_str" : "86421151491956736",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad aww, thank you for thinking of me. many blessings!",
  "id" : 86421151491956736,
  "in_reply_to_status_id" : 86247628463026176,
  "created_at" : "2011-06-30 13:09:42 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustDoYou",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86259185070784512",
  "text" : "RT @TheEntertainer: Screw what anyone else thinks. #JustDoYou",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JustDoYou",
        "indices" : [ 31, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86259091558772736",
    "text" : "Screw what anyone else thinks. #JustDoYou",
    "id" : 86259091558772736,
    "created_at" : "2011-06-30 02:25:44 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 86259185070784512,
  "created_at" : "2011-06-30 02:26:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86246153976418304",
  "text" : "RT @oshum: It only MATTERS if you THINK it does.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86241988986417152",
    "text" : "It only MATTERS if you THINK it does.",
    "id" : 86241988986417152,
    "created_at" : "2011-06-30 01:17:47 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 86246153976418304,
  "created_at" : "2011-06-30 01:34:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86178979152797696",
  "text" : "what a day. hub & I took his mom to Sam's Club w us. got DD 2 swimsuits (and she likes!) I kept forgetting it was weekday..lol",
  "id" : 86178979152797696,
  "created_at" : "2011-06-29 21:07:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86168967428845568",
  "geo" : { },
  "id_str" : "86178557881094146",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell yes, I think I did..lol",
  "id" : 86178557881094146,
  "in_reply_to_status_id" : 86168967428845568,
  "created_at" : "2011-06-29 21:05:43 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86062081383731200",
  "geo" : { },
  "id_str" : "86178438179860480",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle its not funny but that made me chuckle envisioning the scene!",
  "id" : 86178438179860480,
  "in_reply_to_status_id" : 86062081383731200,
  "created_at" : "2011-06-29 21:05:15 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86058283701514240",
  "text" : "dream: trying to drive car while NOT in drivers seat (in back or passenger seat). Drivers seat is empty or driver(not me) is not driving.",
  "id" : 86058283701514240,
  "created_at" : "2011-06-29 13:07:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    }, {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 23, 35 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/4Sw6obJ",
      "expanded_url" : "http:\/\/bit.ly\/iDiDRt",
      "display_url" : "bit.ly\/iDiDRt"
    } ]
  },
  "geo" : { },
  "id_str" : "85885229763530752",
  "text" : "RT @petersonguides: RT @brainpicker: This is amazing -- crows chastise bad behavior, even if it wasn't directed at them http:\/\/t.co\/4Sw6obJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Popova",
        "screen_name" : "brainpicker",
        "indices" : [ 3, 15 ],
        "id_str" : "9207632",
        "id" : 9207632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 119 ],
        "url" : "http:\/\/t.co\/4Sw6obJ",
        "expanded_url" : "http:\/\/bit.ly\/iDiDRt",
        "display_url" : "bit.ly\/iDiDRt"
      } ]
    },
    "geo" : { },
    "id_str" : "85884012924637187",
    "text" : "RT @brainpicker: This is amazing -- crows chastise bad behavior, even if it wasn't directed at them http:\/\/t.co\/4Sw6obJ",
    "id" : 85884012924637187,
    "created_at" : "2011-06-29 01:35:18 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 85885229763530752,
  "created_at" : "2011-06-29 01:40:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Hollowell",
      "screen_name" : "hughlh",
      "indices" : [ 14, 21 ],
      "id_str" : "2691501",
      "id" : 2691501
    }, {
      "name" : "Jerry Parsons",
      "screen_name" : "fireboy49",
      "indices" : [ 22, 32 ],
      "id_str" : "3254051158",
      "id" : 3254051158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85883928942096384",
  "text" : "@tragic_pizza @hughlh @fireboy49 OMG, you so nailed that! (I've always had issues w \"justice\" ..)",
  "id" : 85883928942096384,
  "created_at" : "2011-06-29 01:34:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 10, 25 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85842412525727744",
  "text" : "Thank you @petersonguides for the great bird app! Wow, it's got a lot of info!",
  "id" : 85842412525727744,
  "created_at" : "2011-06-28 22:50:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85837554959646721",
  "text" : "FREE Amazon $2 Credit for MP3s (US only) http:\/\/bit.ly\/l9z9ap exp 06\/30 at 11:59 pm PST",
  "id" : 85837554959646721,
  "created_at" : "2011-06-28 22:30:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85730999727685632",
  "text" : "RT @Jambodhi: Each person must unravel their own Darkness to reveal their Inner Light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85730201195130880",
    "text" : "Each person must unravel their own Darkness to reveal their Inner Light.",
    "id" : 85730201195130880,
    "created_at" : "2011-06-28 15:24:07 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 85730999727685632,
  "created_at" : "2011-06-28 15:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 0, 15 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85568941367361536",
  "geo" : { },
  "id_str" : "85724980465242112",
  "in_reply_to_user_id" : 123647589,
  "text" : "@petersonguides I hit \"follow\" again. Hope it stays..lol. Sorry..",
  "id" : 85724980465242112,
  "in_reply_to_status_id" : 85568941367361536,
  "created_at" : "2011-06-28 15:03:22 +0000",
  "in_reply_to_screen_name" : "petersonguides",
  "in_reply_to_user_id_str" : "123647589",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85527611333279744",
  "text" : "i love you all. you inspire me... to keep on truckin.. to be the best me I can be. thank you so much for sharing of yourselves.",
  "id" : 85527611333279744,
  "created_at" : "2011-06-28 01:59:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bible",
      "indices" : [ 73, 79 ]
    }, {
      "text" : "Freemasonry",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "Alchemy",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85527015943450624",
  "text" : "RT @Matth3ous: Can anyone recommend  a good \u03B3\u03C1\u03B5\u03B5\u03BA (Greek) version of the #Bible? I need one for my research. #Freemasonry #Alchemy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bible",
        "indices" : [ 58, 64 ]
      }, {
        "text" : "Freemasonry",
        "indices" : [ 94, 106 ]
      }, {
        "text" : "Alchemy",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85520418588463107",
    "text" : "Can anyone recommend  a good \u03B3\u03C1\u03B5\u03B5\u03BA (Greek) version of the #Bible? I need one for my research. #Freemasonry #Alchemy",
    "id" : 85520418588463107,
    "created_at" : "2011-06-28 01:30:31 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 85527015943450624,
  "created_at" : "2011-06-28 01:56:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85522702701568000",
  "geo" : { },
  "id_str" : "85526536257671169",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves you have got a very special heart, dwayne.",
  "id" : 85526536257671169,
  "in_reply_to_status_id" : 85522702701568000,
  "created_at" : "2011-06-28 01:54:49 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85506401383874560",
  "text" : "@HEATHENRABBIT @roxo99 haha that sounds like my hubby. not me, im related to the sloth.",
  "id" : 85506401383874560,
  "created_at" : "2011-06-28 00:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85495360960724992",
  "text" : "WTF?? &gt;&gt; \"In our day, it wasn\u2019t called ADHD. It was called STUPID\" http:\/\/bit.ly\/kZTyEe",
  "id" : 85495360960724992,
  "created_at" : "2011-06-27 23:50:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 0, 15 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85420200031289344",
  "geo" : { },
  "id_str" : "85452466480611328",
  "in_reply_to_user_id" : 123647589,
  "text" : "@petersonguides yup, Im following now. Thanks so much! : )",
  "id" : 85452466480611328,
  "in_reply_to_status_id" : 85420200031289344,
  "created_at" : "2011-06-27 21:00:30 +0000",
  "in_reply_to_screen_name" : "petersonguides",
  "in_reply_to_user_id_str" : "123647589",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85452257952411650",
  "text" : "@Tideliar good move I hope? so nice to hear good news!",
  "id" : 85452257952411650,
  "created_at" : "2011-06-27 20:59:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85434477194641408",
  "text" : "@Tideliar money's good.. very good. : )",
  "id" : 85434477194641408,
  "created_at" : "2011-06-27 19:49:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 67, 72 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "Rocky_Mountain_National_Park_CO",
      "indices" : [ 83, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85139595808866304",
  "text" : "RT @wildobs: For the late crowd: Moose http:\/\/wildobs.com\/wo\/12523 #EOTD #wildlife #Rocky_Mountain_National_Park_CO Bullwinkle in the Ro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 54, 59 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "Rocky_Mountain_National_Park_CO",
        "indices" : [ 70, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85137896826343424",
    "text" : "For the late crowd: Moose http:\/\/wildobs.com\/wo\/12523 #EOTD #wildlife #Rocky_Mountain_National_Park_CO Bullwinkle in the Rockies",
    "id" : 85137896826343424,
    "created_at" : "2011-06-27 00:10:31 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 85139595808866304,
  "created_at" : "2011-06-27 00:17:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85135260710473728",
  "text" : "RT @DoreenVirtue444: It\u2019s all about the highest energy of all\u2026love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85134993755619329",
    "text" : "It\u2019s all about the highest energy of all\u2026love.",
    "id" : 85134993755619329,
    "created_at" : "2011-06-26 23:58:58 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 85135260710473728,
  "created_at" : "2011-06-27 00:00:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85128007961935873",
  "text" : "I wouldnt mind visiting (meeting) several of my tweeps!",
  "id" : 85128007961935873,
  "created_at" : "2011-06-26 23:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85126900183351296",
  "text" : "I want to go to: Disney again and other areas of FL; somewhere tropical w villas, Williamsburg VA, Wash DC, AZ.",
  "id" : 85126900183351296,
  "created_at" : "2011-06-26 23:26:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85126238972280832",
  "text" : "every time I see a plane overhead, I wish I was on it",
  "id" : 85126238972280832,
  "created_at" : "2011-06-26 23:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85125197551771649",
  "text" : "2 toads found in pool drain. one dead, one barely alive. : (",
  "id" : 85125197551771649,
  "created_at" : "2011-06-26 23:20:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85115728704974848",
  "text" : "DD's cat has been puking all day. it better not be serious.",
  "id" : 85115728704974848,
  "created_at" : "2011-06-26 22:42:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84997297007640577",
  "text" : "Comments or meaning from animal totem people? http:\/\/bit.ly\/ifxTDp opossum",
  "id" : 84997297007640577,
  "created_at" : "2011-06-26 14:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Sue 'Lily'",
      "screen_name" : "Lily2000",
      "indices" : [ 12, 21 ],
      "id_str" : "21957074",
      "id" : 21957074
    }, {
      "name" : "Kaeli Ferguson",
      "screen_name" : "kaeliferguson",
      "indices" : [ 22, 36 ],
      "id_str" : "98985734",
      "id" : 98985734
    }, {
      "name" : "Lois",
      "screen_name" : "okiewife",
      "indices" : [ 37, 46 ],
      "id_str" : "41017436",
      "id" : 41017436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84821869831794690",
  "geo" : { },
  "id_str" : "84976821321474048",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts @Lily2000 @kaeliferguson @okiewife you are a doll! mwah! \u2665 you have blessed me as well ((hugs))",
  "id" : 84976821321474048,
  "in_reply_to_status_id" : 84821869831794690,
  "created_at" : "2011-06-26 13:30:27 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/5SMiym4",
      "expanded_url" : "http:\/\/yhoo.it\/mf5Zod",
      "display_url" : "yhoo.it\/mf5Zod"
    } ]
  },
  "geo" : { },
  "id_str" : "84668244144820226",
  "text" : "Financial Advice Gleaned From a Day in the Hot Seat - Yahoo! Finance http:\/\/t.co\/5SMiym4",
  "id" : 84668244144820226,
  "created_at" : "2011-06-25 17:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "equality",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "freedom",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "choice",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84642763328598016",
  "text" : "You go, NY.. show 'em how it's done! #LGBT #equality #freedom #choice",
  "id" : 84642763328598016,
  "created_at" : "2011-06-25 15:23:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84440108383731713",
  "geo" : { },
  "id_str" : "84440322305830912",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench LOL. that they are..hehe",
  "id" : 84440322305830912,
  "in_reply_to_status_id" : 84440108383731713,
  "created_at" : "2011-06-25 01:58:36 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84439351261544449",
  "geo" : { },
  "id_str" : "84439844780118017",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench hmm.. very interesting. you need a kitty whisperer.",
  "id" : 84439844780118017,
  "in_reply_to_status_id" : 84439351261544449,
  "created_at" : "2011-06-25 01:56:42 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84438223836819456",
  "geo" : { },
  "id_str" : "84438909584551937",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench did your one kitty get his voice back?",
  "id" : 84438909584551937,
  "in_reply_to_status_id" : 84438223836819456,
  "created_at" : "2011-06-25 01:52:59 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84414944640110592",
  "text" : "@Tideliar aww.. ((hugs))",
  "id" : 84414944640110592,
  "created_at" : "2011-06-25 00:17:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84386330578124800",
  "geo" : { },
  "id_str" : "84392122626748416",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves heehee.. we're quite familiar with that routine!",
  "id" : 84392122626748416,
  "in_reply_to_status_id" : 84386330578124800,
  "created_at" : "2011-06-24 22:47:04 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 15, 24 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 8, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84368507000721408",
  "text" : "special #FF to @Tideliar for his extensive use of the F word! : ) lol",
  "id" : 84368507000721408,
  "created_at" : "2011-06-24 21:13:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 23, 38 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    }, {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 39, 52 ],
      "id_str" : "44101564",
      "id" : 44101564
    }, {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 53, 67 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    }, {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 68, 78 ],
      "id_str" : "15572724",
      "id" : 15572724
    }, {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 79, 89 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84367893474721792",
  "text" : "#FF really cool peeps! @reformedbuddha @joeandrasi93 @HEATHENRABBIT @shhdragon @Matth3ous",
  "id" : 84367893474721792,
  "created_at" : "2011-06-24 21:10:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 23, 34 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 66, 82 ],
      "id_str" : "17489079",
      "id" : 17489079
    }, {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 83, 96 ],
      "id_str" : "35585695",
      "id" : 35585695
    }, {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 97, 106 ],
      "id_str" : "374293471",
      "id" : 374293471
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 107, 121 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84290021489770496",
  "text" : "#FF showing excellence @TrishScott @tragic_pizza @SamsaricWarrior @aliceinthewater @derekrootboy @BayBitch @BibleAlsoSays",
  "id" : 84290021489770496,
  "created_at" : "2011-06-24 16:01:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84272652071612417",
  "text" : "RT @Soulseedzforall: To freely bloom - that is my definition of success. \nGerry Spence",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84271739332341761",
    "text" : "To freely bloom - that is my definition of success. \nGerry Spence",
    "id" : 84271739332341761,
    "created_at" : "2011-06-24 14:48:43 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 84272652071612417,
  "created_at" : "2011-06-24 14:52:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 9, 23 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84269884845993984",
  "text" : "YES!! RT @ThisBlueWorld: Don't you just wanna cut a hole in the platform and see what's under it?",
  "id" : 84269884845993984,
  "created_at" : "2011-06-24 14:41:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Gardner",
      "screen_name" : "FireIcePhotos",
      "indices" : [ 3, 17 ],
      "id_str" : "67722263",
      "id" : 67722263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84268868381577216",
  "text" : "RT @FireIcePhotos: Photography Friday-Wolves of Mercy Falls http:\/\/nblo.gs\/jBwNi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84265210818465792",
    "text" : "Photography Friday-Wolves of Mercy Falls http:\/\/nblo.gs\/jBwNi",
    "id" : 84265210818465792,
    "created_at" : "2011-06-24 14:22:46 +0000",
    "user" : {
      "name" : "Heather Gardner",
      "screen_name" : "FireIcePhotos",
      "protected" : false,
      "id_str" : "67722263",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729678206026948609\/w8vajDua_normal.jpg",
      "id" : 67722263,
      "verified" : false
    }
  },
  "id" : 84268868381577216,
  "created_at" : "2011-06-24 14:37:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 16, 28 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "\u2615 J. B. Rainsberger",
      "screen_name" : "jbrains",
      "indices" : [ 85, 93 ],
      "id_str" : "14554494",
      "id" : 14554494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84268807237021697",
  "text" : "umm ((puke)) RT @angelaharms: Oh my friggen god. I'm glad I'm a secular humanist. RT @jbrains http:\/\/link.jbr\u2026 (cont) http:\/\/deck.ly\/~FLpT3",
  "id" : 84268807237021697,
  "created_at" : "2011-06-24 14:37:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Robinson",
      "screen_name" : "JRobinsonAuthor",
      "indices" : [ 0, 16 ],
      "id_str" : "25141551",
      "id" : 25141551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84265852622471169",
  "geo" : { },
  "id_str" : "84267620228009985",
  "in_reply_to_user_id" : 25141551,
  "text" : "@JRobinsonAuthor thanks for sharing. beautiful story!",
  "id" : 84267620228009985,
  "in_reply_to_status_id" : 84265852622471169,
  "created_at" : "2011-06-24 14:32:20 +0000",
  "in_reply_to_screen_name" : "JRobinsonAuthor",
  "in_reply_to_user_id_str" : "25141551",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Robinson",
      "screen_name" : "JRobinsonAuthor",
      "indices" : [ 3, 19 ],
      "id_str" : "25141551",
      "id" : 25141551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "AnimalRescue",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84267504809164800",
  "text" : "RT @JRobinsonAuthor: The Day My Dog Almost Died - and I Nearly Joined Him. http:\/\/bit.ly\/mjKaTN #pets #AnimalRescue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pets",
        "indices" : [ 75, 80 ]
      }, {
        "text" : "AnimalRescue",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84265852622471169",
    "text" : "The Day My Dog Almost Died - and I Nearly Joined Him. http:\/\/bit.ly\/mjKaTN #pets #AnimalRescue",
    "id" : 84265852622471169,
    "created_at" : "2011-06-24 14:25:19 +0000",
    "user" : {
      "name" : "Jeremy Robinson",
      "screen_name" : "JRobinsonAuthor",
      "protected" : false,
      "id_str" : "25141551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436555626546618368\/p_olsvnh_normal.png",
      "id" : 25141551,
      "verified" : false
    }
  },
  "id" : 84267504809164800,
  "created_at" : "2011-06-24 14:31:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84267456956334080",
  "text" : "RT @BayBitch: A fight to the death between zombies has a few inherent problems.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84266641076133888",
    "text" : "A fight to the death between zombies has a few inherent problems.",
    "id" : 84266641076133888,
    "created_at" : "2011-06-24 14:28:27 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 84267456956334080,
  "created_at" : "2011-06-24 14:31:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 7, 16 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84266675041607680",
  "text" : "LOL RT @BayBitch: If we all are here to help others , then what exactly are others here for?",
  "id" : 84266675041607680,
  "created_at" : "2011-06-24 14:28:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84264258120069120",
  "text" : "im seeing so much awesomeness in my tweet stream this morn! yay!",
  "id" : 84264258120069120,
  "created_at" : "2011-06-24 14:18:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84263467321790465",
  "geo" : { },
  "id_str" : "84263797853925376",
  "in_reply_to_user_id" : 18256901,
  "text" : "@deonnasayed blessings to you, my dear! : )",
  "id" : 84263797853925376,
  "in_reply_to_status_id" : 84263467321790465,
  "created_at" : "2011-06-24 14:17:09 +0000",
  "in_reply_to_screen_name" : "deonnakelli",
  "in_reply_to_user_id_str" : "18256901",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami",
      "screen_name" : "sundancetami",
      "indices" : [ 3, 16 ],
      "id_str" : "179878445",
      "id" : 179878445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84263692224577537",
  "text" : "RT @sundancetami: ... magic of synchronicity ever-fascinates me ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84261393037139968",
    "text" : "... magic of synchronicity ever-fascinates me ...",
    "id" : 84261393037139968,
    "created_at" : "2011-06-24 14:07:36 +0000",
    "user" : {
      "name" : "Tami",
      "screen_name" : "sundancetami",
      "protected" : false,
      "id_str" : "179878445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696883122688913408\/jYR5FLp7_normal.jpg",
      "id" : 179878445,
      "verified" : false
    }
  },
  "id" : 84263692224577537,
  "created_at" : "2011-06-24 14:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84263498087018496",
  "text" : "RT @ThisBlueWorld: Miracles = temporary tranceparency of the platform",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84263298131951616",
    "text" : "Miracles = temporary tranceparency of the platform",
    "id" : 84263298131951616,
    "created_at" : "2011-06-24 14:15:10 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 84263498087018496,
  "created_at" : "2011-06-24 14:15:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84262324709502977",
  "geo" : { },
  "id_str" : "84262590036983808",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld oh I like how you express that!",
  "id" : 84262590036983808,
  "in_reply_to_status_id" : 84262324709502977,
  "created_at" : "2011-06-24 14:12:21 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84261106192891904",
  "geo" : { },
  "id_str" : "84262071000244225",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees yes, I believe so. scary yet exciting. new world birthing.",
  "id" : 84262071000244225,
  "in_reply_to_status_id" : 84261106192891904,
  "created_at" : "2011-06-24 14:10:17 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84260594110300160",
  "text" : "RT @ThisBlueWorld: Non-local perception = C prompt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84260147274326016",
    "text" : "Non-local perception = C prompt",
    "id" : 84260147274326016,
    "created_at" : "2011-06-24 14:02:39 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 84260594110300160,
  "created_at" : "2011-06-24 14:04:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84258720376291328",
  "geo" : { },
  "id_str" : "84259694847328256",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees exactly!",
  "id" : 84259694847328256,
  "in_reply_to_status_id" : 84258720376291328,
  "created_at" : "2011-06-24 14:00:51 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84258159392333824",
  "geo" : { },
  "id_str" : "84259620377477120",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees Yes, systems have been created to protect very wealthy to keep their power over masses.",
  "id" : 84259620377477120,
  "in_reply_to_status_id" : 84258159392333824,
  "created_at" : "2011-06-24 14:00:33 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "April Thompson",
      "screen_name" : "oddlysaid",
      "indices" : [ 13, 23 ],
      "id_str" : "18835723",
      "id" : 18835723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84257280790507520",
  "geo" : { },
  "id_str" : "84258639048740864",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell @oddlysaid I heartily agree \u2665",
  "id" : 84258639048740864,
  "in_reply_to_status_id" : 84257280790507520,
  "created_at" : "2011-06-24 13:56:39 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84255829938802689",
  "geo" : { },
  "id_str" : "84256152430444544",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl ((hugs)) : )",
  "id" : 84256152430444544,
  "in_reply_to_status_id" : 84255829938802689,
  "created_at" : "2011-06-24 13:46:46 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 8, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84255973816012800",
  "text" : "I'll do #FF any which way I choose to!",
  "id" : 84255973816012800,
  "created_at" : "2011-06-24 13:46:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 17, 27 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84254967468269568",
  "text" : "ok, then! lol RT @wow_trees: This guy here at work told me that free thinking is a sin.",
  "id" : 84254967468269568,
  "created_at" : "2011-06-24 13:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84251311658373121",
  "text" : "I won't back down.",
  "id" : 84251311658373121,
  "created_at" : "2011-06-24 13:27:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84250430229590016",
  "text" : "RT @paulocoelho: Life is short. Get rid of anything that isn't useful, beautiful or joyful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84249865474945025",
    "text" : "Life is short. Get rid of anything that isn't useful, beautiful or joyful.",
    "id" : 84249865474945025,
    "created_at" : "2011-06-24 13:21:47 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 84250430229590016,
  "created_at" : "2011-06-24 13:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84247509404356608",
  "text" : "morning news show on. want to scream.",
  "id" : 84247509404356608,
  "created_at" : "2011-06-24 13:12:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 0, 10 ],
      "id_str" : "15572724",
      "id" : 15572724
    }, {
      "name" : "Ethan",
      "screen_name" : "SatorriSynoptic",
      "indices" : [ 11, 27 ],
      "id_str" : "56459711",
      "id" : 56459711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83949604734902272",
  "geo" : { },
  "id_str" : "84010747964833794",
  "in_reply_to_user_id" : 15572724,
  "text" : "@ShhDragon @SatorriSynoptic LOLOL",
  "id" : 84010747964833794,
  "in_reply_to_status_id" : 83949604734902272,
  "created_at" : "2011-06-23 21:31:37 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84009956403191808",
  "geo" : { },
  "id_str" : "84010343650701312",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell good luck! : )",
  "id" : 84010343650701312,
  "in_reply_to_status_id" : 84009956403191808,
  "created_at" : "2011-06-23 21:30:01 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 0, 10 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83946916198629376",
  "geo" : { },
  "id_str" : "83947854145662976",
  "in_reply_to_user_id" : 15572724,
  "text" : "@ShhDragon LOL",
  "id" : 83947854145662976,
  "in_reply_to_status_id" : 83946916198629376,
  "created_at" : "2011-06-23 17:21:42 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83941619266621441",
  "text" : "universe, guide me in the right direction. thanks!",
  "id" : 83941619266621441,
  "created_at" : "2011-06-23 16:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83934331923476480",
  "geo" : { },
  "id_str" : "83940905127645184",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH same here w 2 stray kittys..lol",
  "id" : 83940905127645184,
  "in_reply_to_status_id" : 83934331923476480,
  "created_at" : "2011-06-23 16:54:05 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83908808329531392",
  "geo" : { },
  "id_str" : "83909596867072000",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell LOL",
  "id" : 83909596867072000,
  "in_reply_to_status_id" : 83908808329531392,
  "created_at" : "2011-06-23 14:49:41 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 10, 22 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83906635818471424",
  "text" : "EEEK!! RT @CaroleODell: SNAKE!!!!!!!!",
  "id" : 83906635818471424,
  "created_at" : "2011-06-23 14:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83718173744054273",
  "text" : "there are some ppl I passionately disagree with. yet something draws me to them.",
  "id" : 83718173744054273,
  "created_at" : "2011-06-23 02:09:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83716907286528000",
  "text" : "so many interesting ppl in my stream. so much variety. so many passionate views.",
  "id" : 83716907286528000,
  "created_at" : "2011-06-23 02:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83646075214368768",
  "text" : "RT @UnseeingEyes: People always want to tie religion & morality together...& religion has NOTHING to do with morality.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83645792094662656",
    "text" : "People always want to tie religion & morality together...& religion has NOTHING to do with morality.",
    "id" : 83645792094662656,
    "created_at" : "2011-06-22 21:21:25 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 83646075214368768,
  "created_at" : "2011-06-22 21:22:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Photography",
      "screen_name" : "Wildlife_Photo",
      "indices" : [ 3, 18 ],
      "id_str" : "68092194",
      "id" : 68092194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83615017848672256",
  "text" : "RT @Wildlife_Photo: Moose and Fall Colors of Maine with Chris Dodds and E.J. Peiker Sept. 26-30, 2011: http:\/\/bit.ly\/mvf46T - @ChrisDodd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildlife-photography-blog.com\" rel=\"nofollow\"\u003EWildlife Photography Blog\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Dodds",
        "screen_name" : "ChrisDoddsPhoto",
        "indices" : [ 106, 122 ],
        "id_str" : "35719203",
        "id" : 35719203
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WildlifePhoto",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83613299278741506",
    "text" : "Moose and Fall Colors of Maine with Chris Dodds and E.J. Peiker Sept. 26-30, 2011: http:\/\/bit.ly\/mvf46T - @ChrisDoddsPhoto #WildlifePhoto",
    "id" : 83613299278741506,
    "created_at" : "2011-06-22 19:12:18 +0000",
    "user" : {
      "name" : "Wildlife Photography",
      "screen_name" : "Wildlife_Photo",
      "protected" : false,
      "id_str" : "68092194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378006206\/logo3_normal.png",
      "id" : 68092194,
      "verified" : false
    }
  },
  "id" : 83615017848672256,
  "created_at" : "2011-06-22 19:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83598967715282944",
  "text" : "universe, assist me in using my brain. thank you.",
  "id" : 83598967715282944,
  "created_at" : "2011-06-22 18:15:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83563290827038720",
  "geo" : { },
  "id_str" : "83563864934977537",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles this one works! lol",
  "id" : 83563864934977537,
  "in_reply_to_status_id" : 83563290827038720,
  "created_at" : "2011-06-22 15:55:52 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83559010594332673",
  "geo" : { },
  "id_str" : "83559593107652609",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles I got &gt;&gt; Sorry, the term we received \"www.gather.mn\" couldn't be resolved",
  "id" : 83559593107652609,
  "in_reply_to_status_id" : 83559010594332673,
  "created_at" : "2011-06-22 15:38:54 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Monica",
      "screen_name" : "Mz908",
      "indices" : [ 22, 28 ],
      "id_str" : "108410755",
      "id" : 108410755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83539590467694592",
  "text" : "RT @Dwayne_Reaves: RT @Mz908: People should open their minds and let their souls roam free.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica",
        "screen_name" : "Mz908",
        "indices" : [ 3, 9 ],
        "id_str" : "108410755",
        "id" : 108410755
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83536967719067649",
    "text" : "RT @Mz908: People should open their minds and let their souls roam free.",
    "id" : 83536967719067649,
    "created_at" : "2011-06-22 14:08:59 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 83539590467694592,
  "created_at" : "2011-06-22 14:19:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83339822088978432",
  "text" : "RT @ShipsofSong: Condemnation of others is simply self-judgment of yourself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83339137075249154",
    "text" : "Condemnation of others is simply self-judgment of yourself.",
    "id" : 83339137075249154,
    "created_at" : "2011-06-22 01:02:53 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 83339822088978432,
  "created_at" : "2011-06-22 01:05:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83334637954416641",
  "geo" : { },
  "id_str" : "83336608140627969",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench poor sheep get such a bad rap..lol - im too much of a loner. good thing I like myself : D",
  "id" : 83336608140627969,
  "in_reply_to_status_id" : 83334637954416641,
  "created_at" : "2011-06-22 00:52:50 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83335983218688003",
  "text" : "RT @brandonrofl: Don't ask me what's wrong, ask me what's right. And I'ma tell you what's life",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83335623959777280",
    "text" : "Don't ask me what's wrong, ask me what's right. And I'ma tell you what's life",
    "id" : 83335623959777280,
    "created_at" : "2011-06-22 00:48:55 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 83335983218688003,
  "created_at" : "2011-06-22 00:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83329508953948160",
  "geo" : { },
  "id_str" : "83335013260738560",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous now that sounds interesting!",
  "id" : 83335013260738560,
  "in_reply_to_status_id" : 83329508953948160,
  "created_at" : "2011-06-22 00:46:30 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83333018936295424",
  "geo" : { },
  "id_str" : "83334371754508289",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench how I feel a lot..lol..never was part of the \"in\" crowd ; )",
  "id" : 83334371754508289,
  "in_reply_to_status_id" : 83333018936295424,
  "created_at" : "2011-06-22 00:43:57 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83303827700334592",
  "text" : "went to a funeral today. mouth hurts from smiling so much..lol. Lots of family (married into) that havent seen me or DD for years.",
  "id" : 83303827700334592,
  "created_at" : "2011-06-21 22:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83178445546336257",
  "geo" : { },
  "id_str" : "83268885901611009",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous thx 4 recommendation.. I added to my list. : )",
  "id" : 83268885901611009,
  "in_reply_to_status_id" : 83178445546336257,
  "created_at" : "2011-06-21 20:23:44 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83268568191483904",
  "text" : "my daughter is amazing #justsayin",
  "id" : 83268568191483904,
  "created_at" : "2011-06-21 20:22:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83169962335805440",
  "geo" : { },
  "id_str" : "83178195683250176",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous no, I don't? never thought of that, I guess.",
  "id" : 83178195683250176,
  "in_reply_to_status_id" : 83169962335805440,
  "created_at" : "2011-06-21 14:23:21 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83167989171630080",
  "geo" : { },
  "id_str" : "83168528303267841",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous  sort of..lol.. i mean new eyeballs that replace my own! lol",
  "id" : 83168528303267841,
  "in_reply_to_status_id" : 83167989171630080,
  "created_at" : "2011-06-21 13:44:57 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83166435966337024",
  "geo" : { },
  "id_str" : "83167363465359360",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous im still waiting for electronic eyes...",
  "id" : 83167363465359360,
  "in_reply_to_status_id" : 83166435966337024,
  "created_at" : "2011-06-21 13:40:19 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83164064112586753",
  "text" : "RT @fearfuldogs: No, I am NOT OK http:\/\/wp.me\/popf2-Fe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83158743814115328",
    "text" : "No, I am NOT OK http:\/\/wp.me\/popf2-Fe",
    "id" : 83158743814115328,
    "created_at" : "2011-06-21 13:06:04 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 83164064112586753,
  "created_at" : "2011-06-21 13:27:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83156746121650176",
  "text" : "RT @kindlefever: Midsummer\u2019s Eve Giveaway Hop! TWO winners -- $10 Gift Card and an e-copy of one of my favourite new releases! http:\/\/sh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sharethis.com\" rel=\"nofollow\"\u003EShareThis.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83151830061821952",
    "text" : "Midsummer\u2019s Eve Giveaway Hop! TWO winners -- $10 Gift Card and an e-copy of one of my favourite new releases! http:\/\/shar.es\/Hdrk3",
    "id" : 83151830061821952,
    "created_at" : "2011-06-21 12:38:35 +0000",
    "user" : {
      "name" : "Bex",
      "screen_name" : "mssherlocked",
      "protected" : false,
      "id_str" : "276486305",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 276486305,
      "verified" : false
    }
  },
  "id" : 83156746121650176,
  "created_at" : "2011-06-21 12:58:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 3, 12 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83156486779453440",
  "text" : "RT @WahminSC: Happy Solstice!  Blessed Be!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83154190574166016",
    "text" : "Happy Solstice!  Blessed Be!",
    "id" : 83154190574166016,
    "created_at" : "2011-06-21 12:47:58 +0000",
    "user" : {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "protected" : false,
      "id_str" : "46760072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619665382\/fa008c9a-f9b0-4abf-be01-e2dc1ec3cbe4_normal.png",
      "id" : 46760072,
      "verified" : false
    }
  },
  "id" : 83156486779453440,
  "created_at" : "2011-06-21 12:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83155572400193536",
  "text" : "RT @Mahala: Sexy Latinos, Pregnant Cravings and Why I Shouldn't Leave the House http:\/\/goo.gl\/fb\/ssQU7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83148966925049857",
    "text" : "Sexy Latinos, Pregnant Cravings and Why I Shouldn't Leave the House http:\/\/goo.gl\/fb\/ssQU7",
    "id" : 83148966925049857,
    "created_at" : "2011-06-21 12:27:13 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 83155572400193536,
  "created_at" : "2011-06-21 12:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82975775665557504",
  "text" : "RT @Bashar_quotes: You are always learning and always teaching. Everyone is an equal teacher, and equal learner. It makes you an equal s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82970311569584128",
    "text" : "You are always learning and always teaching. Everyone is an equal teacher, and equal learner. It makes you an equal sharer ~ Bashar",
    "id" : 82970311569584128,
    "created_at" : "2011-06-21 00:37:18 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 82975775665557504,
  "created_at" : "2011-06-21 00:59:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82943573414264833",
  "text" : "I should start a gabslist ..lol",
  "id" : 82943573414264833,
  "created_at" : "2011-06-20 22:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82847778270752768",
  "text" : "RT @OMGFacts: The time difference between when Tyrannosaurus and Stegosaurus lived is greater than the time difference between Tyrannosa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82846238222983168",
    "text" : "The time difference between when Tyrannosaurus and Stegosaurus lived is greater than the time difference between Tyrannosaurus and now.",
    "id" : 82846238222983168,
    "created_at" : "2011-06-20 16:24:17 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 82847778270752768,
  "created_at" : "2011-06-20 16:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82826027465838592",
  "text" : "RT @DuttonBooks: Follow us & RT to enter to #win a copy of both THE LEFT HAND OF GOD & the sequel THE LAST FOUR THINGS by Paul Hoffman.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "Mondaygiveaway",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82822541755949056",
    "text" : "Follow us & RT to enter to #win a copy of both THE LEFT HAND OF GOD & the sequel THE LAST FOUR THINGS by Paul Hoffman. #Mondaygiveaway",
    "id" : 82822541755949056,
    "created_at" : "2011-06-20 14:50:07 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 82826027465838592,
  "created_at" : "2011-06-20 15:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay Bitch",
      "screen_name" : "baybitch",
      "indices" : [ 3, 12 ],
      "id_str" : "374293471",
      "id" : 374293471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82807065134907392",
  "text" : "RT @BayBitch: All of you author type ppl: If you have something coming out, let me know so I can at least put it on my wish lists.... I  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82806279319457792",
    "text" : "All of you author type ppl: If you have something coming out, let me know so I can at least put it on my wish lists.... I read a LOT!!!",
    "id" : 82806279319457792,
    "created_at" : "2011-06-20 13:45:30 +0000",
    "user" : {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "protected" : false,
      "id_str" : "46375814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790643921621704709\/PEExyX2d_normal.jpg",
      "id" : 46375814,
      "verified" : false
    }
  },
  "id" : 82807065134907392,
  "created_at" : "2011-06-20 13:48:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82796466770427904",
  "text" : "1st cup down : ) gm twitter!",
  "id" : 82796466770427904,
  "created_at" : "2011-06-20 13:06:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82600144931000320",
  "text" : "@Tideliar : )",
  "id" : 82600144931000320,
  "created_at" : "2011-06-20 00:06:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82547769755181056",
  "geo" : { },
  "id_str" : "82599676934762496",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves Yay!! (so is mine.. as it should be..lol)",
  "id" : 82599676934762496,
  "in_reply_to_status_id" : 82547769755181056,
  "created_at" : "2011-06-20 00:04:32 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82599018823290881",
  "text" : "ego ego ego",
  "id" : 82599018823290881,
  "created_at" : "2011-06-20 00:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Mark Ritch",
      "screen_name" : "JeremyRitch",
      "indices" : [ 3, 15 ],
      "id_str" : "22289976",
      "id" : 22289976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82585965478150145",
  "text" : "RT @JeremyRitch: @tragic_pizza most of our beliefs are relative to our individual situation and experience.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82580524526350336",
    "text" : "@tragic_pizza most of our beliefs are relative to our individual situation and experience.",
    "id" : 82580524526350336,
    "created_at" : "2011-06-19 22:48:25 +0000",
    "user" : {
      "name" : "Jeremy Mark Ritch",
      "screen_name" : "JeremyRitch",
      "protected" : false,
      "id_str" : "22289976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763768799795503104\/3dsBNPV-_normal.jpg",
      "id" : 22289976,
      "verified" : false
    }
  },
  "id" : 82585965478150145,
  "created_at" : "2011-06-19 23:10:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82585124692164608",
  "text" : "RT @brandonrofl: I hate when I talk about my beliefs because people get all pissy about it. Believe what YOU think is right, have some c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82583439269822464",
    "text" : "I hate when I talk about my beliefs because people get all pissy about it. Believe what YOU think is right, have some confidence in yourself",
    "id" : 82583439269822464,
    "created_at" : "2011-06-19 23:00:00 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 82585124692164608,
  "created_at" : "2011-06-19 23:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82460754141380608",
  "text" : "I need to let them be.",
  "id" : 82460754141380608,
  "created_at" : "2011-06-19 14:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82460683182153729",
  "text" : "I want to shake some ppl & say \"you just dont get it!\"..lol.. but THATS the point.. they do not get it. They are on their own path.",
  "id" : 82460683182153729,
  "created_at" : "2011-06-19 14:52:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82459800868364288",
  "text" : "I could argue\/debate all day long w ppl whose ideas\/beliefs I disagree with (some vehemently) but I choose not to. That's not where I'm at.",
  "id" : 82459800868364288,
  "created_at" : "2011-06-19 14:48:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 3, 10 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82442345215295488",
  "text" : "RT @SsmDad: Our culture brainwashes people into believing you have to be \"patriotic\" 'or support weapons and destruction or you're \"anti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82422463312568320",
    "text" : "Our culture brainwashes people into believing you have to be \"patriotic\" 'or support weapons and destruction or you're \"anti-American\" BS!",
    "id" : 82422463312568320,
    "created_at" : "2011-06-19 12:20:21 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "protected" : false,
      "id_str" : "122393631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649760376880525312\/faJeQ4K3_normal.jpg",
      "id" : 122393631,
      "verified" : false
    }
  },
  "id" : 82442345215295488,
  "created_at" : "2011-06-19 13:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82257463218409472",
  "geo" : { },
  "id_str" : "82260869437865984",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell now that does sound interesting!",
  "id" : 82260869437865984,
  "in_reply_to_status_id" : 82257463218409472,
  "created_at" : "2011-06-19 01:38:14 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82259649172226048",
  "text" : "@tragic_pizza hmm.. sounds similar to a man from 2K yrs ago ; )",
  "id" : 82259649172226048,
  "created_at" : "2011-06-19 01:33:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fast Bank",
      "screen_name" : "queerza",
      "indices" : [ 3, 11 ],
      "id_str" : "2160404250",
      "id" : 2160404250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82258952955494400",
  "text" : "RT @queerza: Hate is Not a Family Value",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82246225419706368",
    "text" : "Hate is Not a Family Value",
    "id" : 82246225419706368,
    "created_at" : "2011-06-19 00:40:02 +0000",
    "user" : {
      "name" : "Travelsnaps",
      "screen_name" : "thetravelsnaps",
      "protected" : false,
      "id_str" : "50003987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663649510963310593\/F25afB1y_normal.png",
      "id" : 50003987,
      "verified" : false
    }
  },
  "id" : 82258952955494400,
  "created_at" : "2011-06-19 01:30:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Royal Blue Texas",
      "screen_name" : "royalbluetexas",
      "indices" : [ 3, 18 ],
      "id_str" : "307900638",
      "id" : 307900638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RickPerry",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82258536133955584",
  "text" : "RT @royalbluetexas: #RickPerry sees an America built on foundation of its \"spiritual strength.\" Translation: If you're not evangelical r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RickPerry",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "RLC",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82242513536155648",
    "text" : "#RickPerry sees an America built on foundation of its \"spiritual strength.\" Translation: If you're not evangelical right-wing, go away. #RLC",
    "id" : 82242513536155648,
    "created_at" : "2011-06-19 00:25:17 +0000",
    "user" : {
      "name" : "Royal Blue Texas",
      "screen_name" : "royalbluetexas",
      "protected" : false,
      "id_str" : "307900638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374851656\/capital_of_texas_normal.jpg",
      "id" : 307900638,
      "verified" : false
    }
  },
  "id" : 82258536133955584,
  "created_at" : "2011-06-19 01:28:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Dannion Brinkley",
      "screen_name" : "dannionbrinkley",
      "indices" : [ 17, 33 ],
      "id_str" : "239096732",
      "id" : 239096732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82248706644131841",
  "text" : "RT @JohnCali: RT @dannionbrinkley: There is a legacy of understanding and love left behind by each and every soul who eve\u2026 (cont) http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dannion Brinkley",
        "screen_name" : "dannionbrinkley",
        "indices" : [ 3, 19 ],
        "id_str" : "239096732",
        "id" : 239096732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82246762361929729",
    "text" : "RT @dannionbrinkley: There is a legacy of understanding and love left behind by each and every soul who eve\u2026 (cont) http:\/\/deck.ly\/~jitAK",
    "id" : 82246762361929729,
    "created_at" : "2011-06-19 00:42:10 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 82248706644131841,
  "created_at" : "2011-06-19 00:49:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82220361957122048",
  "text" : "Pizza!! Yes, life is good : )",
  "id" : 82220361957122048,
  "created_at" : "2011-06-18 22:57:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82204121305849857",
  "text" : "just back from bike ride with my honey. my leg went a bit numb but it was fun. met a nice greyhound \"willow\" on the mall.",
  "id" : 82204121305849857,
  "created_at" : "2011-06-18 21:52:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookRooster",
      "screen_name" : "BookRooster",
      "indices" : [ 7, 19 ],
      "id_str" : "311990641",
      "id" : 311990641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82136309916893185",
  "text" : "Thanks @BookRooster for the ecopy of \"Flee\" - sent in my Amazon review : )",
  "id" : 82136309916893185,
  "created_at" : "2011-06-18 17:23:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webmistress",
      "screen_name" : "Webmistress_69",
      "indices" : [ 3, 18 ],
      "id_str" : "59681476",
      "id" : 59681476
    }, {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 23, 35 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dolphins",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/jp8oBYU",
      "expanded_url" : "http:\/\/bit.ly\/lkpVqj",
      "display_url" : "bit.ly\/lkpVqj"
    } ]
  },
  "geo" : { },
  "id_str" : "82114253011685376",
  "text" : "RT @Webmistress_69: RT @oceanshaman: Cold Chilly bumps story: #Dolphins kept vigil on Irishman's body: http:\/\/t.co\/jp8oBYU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GRAY",
        "screen_name" : "oceanshaman",
        "indices" : [ 3, 15 ],
        "id_str" : "45674330",
        "id" : 45674330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dolphins",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 102 ],
        "url" : "http:\/\/t.co\/jp8oBYU",
        "expanded_url" : "http:\/\/bit.ly\/lkpVqj",
        "display_url" : "bit.ly\/lkpVqj"
      } ]
    },
    "geo" : { },
    "id_str" : "82035176540094465",
    "text" : "RT @oceanshaman: Cold Chilly bumps story: #Dolphins kept vigil on Irishman's body: http:\/\/t.co\/jp8oBYU",
    "id" : 82035176540094465,
    "created_at" : "2011-06-18 10:41:24 +0000",
    "user" : {
      "name" : "Webmistress",
      "screen_name" : "Webmistress_69",
      "protected" : false,
      "id_str" : "59681476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523125531219218432\/p_GL8ViY_normal.jpeg",
      "id" : 59681476,
      "verified" : false
    }
  },
  "id" : 82114253011685376,
  "created_at" : "2011-06-18 15:55:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81894907354169345",
  "text" : "RT @petersonguides: RT to enter our free drawing. Win 1 of 10 copies of Peterson Birds this w\/e. Tell your friends! PetersonGuides.com # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 115, 123 ]
      }, {
        "text" : "gardening",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81852896697786368",
    "text" : "RT to enter our free drawing. Win 1 of 10 copies of Peterson Birds this w\/e. Tell your friends! PetersonGuides.com #birding #gardening",
    "id" : 81852896697786368,
    "created_at" : "2011-06-17 22:37:05 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 81894907354169345,
  "created_at" : "2011-06-18 01:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81843169544773632",
  "text" : "RT @UnseeingEyes: You can't cater your stream to one person, or to a minority of individuals, or to anyone for that matter...just be TRU ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81843017539002368",
    "text" : "You can't cater your stream to one person, or to a minority of individuals, or to anyone for that matter...just be TRUE to your SELF.",
    "id" : 81843017539002368,
    "created_at" : "2011-06-17 21:57:50 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 81843169544773632,
  "created_at" : "2011-06-17 21:58:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81837367081709568",
  "text" : "I smell BACON!!",
  "id" : 81837367081709568,
  "created_at" : "2011-06-17 21:35:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 65, 80 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81837169907478529",
  "text" : "#FF upstanding, outstanding dudes that make me feel warm & fuzzy @thesexyatheist @SamsaricWarrior",
  "id" : 81837169907478529,
  "created_at" : "2011-06-17 21:34:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 52, 66 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 67, 80 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 81, 94 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81835090216357888",
  "text" : "#FF be prepared 2 think @Reverend_Sue @tragic_pizza @BibleAlsoSays @neardeathdoc @UnseeingEyes",
  "id" : 81835090216357888,
  "created_at" : "2011-06-17 21:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 24, 38 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 39, 51 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 52, 65 ],
      "id_str" : "44101564",
      "id" : 44101564
    }, {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 66, 79 ],
      "id_str" : "133780513",
      "id" : 133780513
    }, {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 80, 95 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81834424152498176",
  "text" : "#FF lovely to chat with @Dwayne_Reaves @CaroleODell @Joeandrasi93 @JoanneMFirth @mssuzcatsilver",
  "id" : 81834424152498176,
  "created_at" : "2011-06-17 21:23:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81818692266110976",
  "text" : "RT @RichardMabry: Ah, habits are hard to break. Stopped reading book on my Kindle, and reached for a bookmark to put inside the cover!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81816389941334016",
    "text" : "Ah, habits are hard to break. Stopped reading book on my Kindle, and reached for a bookmark to put inside the cover!",
    "id" : 81816389941334016,
    "created_at" : "2011-06-17 20:12:02 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 81818692266110976,
  "created_at" : "2011-06-17 20:21:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 31, 45 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81816422430416897",
  "text" : "happy birthday to Mr. Sunshine @Dwayne_Reaves Im older (but not much..lol)",
  "id" : 81816422430416897,
  "created_at" : "2011-06-17 20:12:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81770127183446016",
  "text" : "but the same statements he uses to show other side wrong is same way he's saying he's right!",
  "id" : 81770127183446016,
  "created_at" : "2011-06-17 17:08:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81769665919062016",
  "text" : "I dont know why I still get annoyed at such drivel. He's where he's at, I'm where I'm at. It's all ok.",
  "id" : 81769665919062016,
  "created_at" : "2011-06-17 17:06:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/iDSioF8",
      "expanded_url" : "http:\/\/bit.ly\/iJytzp",
      "display_url" : "bit.ly\/iJytzp"
    } ]
  },
  "geo" : { },
  "id_str" : "81767478212042752",
  "text" : "\u201CIs God still good even though some suffer for an eternity?\u201D http:\/\/t.co\/iDSioF8 \"that is not a question asked among christians\" WHY NOT??",
  "id" : 81767478212042752,
  "created_at" : "2011-06-17 16:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81749365093433345",
  "text" : "we have lots of deep discussions with our daughter. we learn a lot ; )",
  "id" : 81749365093433345,
  "created_at" : "2011-06-17 15:45:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81740181471891457",
  "text" : "I have met so many wonderful ppl online that I have learned from! : )",
  "id" : 81740181471891457,
  "created_at" : "2011-06-17 15:09:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81737378452086784",
  "text" : "I am able to communicate, express myself, get information, have social interactions due to electronic age (that otherwise wldnt happen)",
  "id" : 81737378452086784,
  "created_at" : "2011-06-17 14:58:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81737062516146176",
  "text" : "I am def not agoraphobic but I spend lots of time at home. I only drive locally.",
  "id" : 81737062516146176,
  "created_at" : "2011-06-17 14:56:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81736632193134592",
  "text" : "I am an introvert. I naturally avoid \"real-life\" ppl & interactions. I need lots of down (alone) time.",
  "id" : 81736632193134592,
  "created_at" : "2011-06-17 14:55:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gracie",
      "screen_name" : "onlygracie",
      "indices" : [ 3, 14 ],
      "id_str" : "142741107",
      "id" : 142741107
    }, {
      "name" : "Claire Khaw",
      "screen_name" : "1party4all",
      "indices" : [ 82, 93 ],
      "id_str" : "56689645",
      "id" : 56689645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hate",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81735988111605760",
  "text" : "RT @onlygracie: The right thing according to whom?  And ok according to whom?  RT @1party4all It is OK to #hate, provided one hates the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Claire Khaw",
        "screen_name" : "1party4all",
        "indices" : [ 66, 77 ],
        "id_str" : "56689645",
        "id" : 56689645
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hate",
        "indices" : [ 90, 95 ]
      }, {
        "text" : "right",
        "indices" : [ 120, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81732575219032064",
    "text" : "The right thing according to whom?  And ok according to whom?  RT @1party4all It is OK to #hate, provided one hates the #right thing.",
    "id" : 81732575219032064,
    "created_at" : "2011-06-17 14:38:59 +0000",
    "user" : {
      "name" : "Gracie",
      "screen_name" : "onlygracie",
      "protected" : false,
      "id_str" : "142741107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693828266843598855\/1BHCgpwW_normal.jpg",
      "id" : 142741107,
      "verified" : false
    }
  },
  "id" : 81735988111605760,
  "created_at" : "2011-06-17 14:52:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81735678832025600",
  "text" : "oh and add twitter, facebook to that list, too.",
  "id" : 81735678832025600,
  "created_at" : "2011-06-17 14:51:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81735467028070401",
  "text" : "I get annoyed with ppl who think the world is going to pot because of email, internet and kindle! UGH!!",
  "id" : 81735467028070401,
  "created_at" : "2011-06-17 14:50:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81728707093475329",
  "text" : "there are ppl I agree with yet also disagree with.. and ppl I diagree with yet also agree with.. hmm..",
  "id" : 81728707093475329,
  "created_at" : "2011-06-17 14:23:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81728362426535937",
  "text" : "I think I have an epiphany brewing...",
  "id" : 81728362426535937,
  "created_at" : "2011-06-17 14:22:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81713942400999424",
  "geo" : { },
  "id_str" : "81715855066546176",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell Wonderful! Happy Anniversary! : )",
  "id" : 81715855066546176,
  "in_reply_to_status_id" : 81713942400999424,
  "created_at" : "2011-06-17 13:32:32 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sacred Witness",
      "screen_name" : "SacredWitness",
      "indices" : [ 3, 17 ],
      "id_str" : "3085133691",
      "id" : 3085133691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81531867953762304",
  "text" : "RT @SacredWitness: Cutest Photo | Baby Squirrel http:\/\/carlaroyal.com\/2010\/08\/cutest-photo-baby-squirrel\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81528706274820096",
    "text" : "Cutest Photo | Baby Squirrel http:\/\/carlaroyal.com\/2010\/08\/cutest-photo-baby-squirrel\/",
    "id" : 81528706274820096,
    "created_at" : "2011-06-17 01:08:52 +0000",
    "user" : {
      "name" : "Carla Royal",
      "screen_name" : "CarlaRoyal",
      "protected" : false,
      "id_str" : "28894048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823476520\/13fdf78af18d23f2cf1dc63aceb88301_normal.jpeg",
      "id" : 28894048,
      "verified" : false
    }
  },
  "id" : 81531867953762304,
  "created_at" : "2011-06-17 01:21:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81530820208234496",
  "text" : "@tragic_pizza no prob, sir. I'll check it out. : )",
  "id" : 81530820208234496,
  "created_at" : "2011-06-17 01:17:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81483988232962049",
  "text" : "@tragic_pizza what is diff? or what is a socialist?",
  "id" : 81483988232962049,
  "created_at" : "2011-06-16 22:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photos",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81387372096397312",
  "text" : "RT @gemswinc: Naked Female Scientist Tries to Tame Belugas #photos http:\/\/bit.ly\/kbM9t7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photos",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81385675085197314",
    "text" : "Naked Female Scientist Tries to Tame Belugas #photos http:\/\/bit.ly\/kbM9t7",
    "id" : 81385675085197314,
    "created_at" : "2011-06-16 15:40:31 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 81387372096397312,
  "created_at" : "2011-06-16 15:47:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anon",
      "screen_name" : "hellsraven",
      "indices" : [ 3, 14 ],
      "id_str" : "194714436",
      "id" : 194714436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81385633934876673",
  "text" : "RT @hellsraven: Introverts don\u2019t like to talk.\nnot true. Introverts just don\u2019t talk unless they have something to say. They hate small talk.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81370326033907713",
    "text" : "Introverts don\u2019t like to talk.\nnot true. Introverts just don\u2019t talk unless they have something to say. They hate small talk.",
    "id" : 81370326033907713,
    "created_at" : "2011-06-16 14:39:32 +0000",
    "user" : {
      "name" : "Anon",
      "screen_name" : "hellsraven",
      "protected" : false,
      "id_str" : "194714436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1838618060\/The_black_unicorn_at_winter_by_RavenMother_normal.jpg",
      "id" : 194714436,
      "verified" : false
    }
  },
  "id" : 81385633934876673,
  "created_at" : "2011-06-16 15:40:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81370523510128640",
  "text" : "answered the door looking rather rough... and cute guy on other side.. sigh.",
  "id" : 81370523510128640,
  "created_at" : "2011-06-16 14:40:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 0, 9 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Dannion Brinkley",
      "screen_name" : "dannionbrinkley",
      "indices" : [ 10, 26 ],
      "id_str" : "239096732",
      "id" : 239096732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81366241352228864",
  "geo" : { },
  "id_str" : "81368467399393280",
  "in_reply_to_user_id" : 27094110,
  "text" : "@JohnCali @dannionbrinkley YES!!",
  "id" : 81368467399393280,
  "in_reply_to_status_id" : 81366241352228864,
  "created_at" : "2011-06-16 14:32:09 +0000",
  "in_reply_to_screen_name" : "JohnCali",
  "in_reply_to_user_id_str" : "27094110",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81358405092118528",
  "text" : "need my 2nd cup o' java",
  "id" : 81358405092118528,
  "created_at" : "2011-06-16 13:52:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81358301610254336",
  "text" : "so much variety in my tweet stream and I learn from them all",
  "id" : 81358301610254336,
  "created_at" : "2011-06-16 13:51:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81358155401015296",
  "text" : "@Tideliar shouldnt it be FTFW? ; ) enjoy that bbq!",
  "id" : 81358155401015296,
  "created_at" : "2011-06-16 13:51:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81188812230889472",
  "geo" : { },
  "id_str" : "81357789301186560",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell animals and nature have always made me feel close to God.. just seeing all the awesomeness in our world!",
  "id" : 81357789301186560,
  "in_reply_to_status_id" : 81188812230889472,
  "created_at" : "2011-06-16 13:49:43 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81357286731296769",
  "text" : "@HEATHENRABBIT : ) my improvements are \"larger\" now where I can see them. Its exciting!",
  "id" : 81357286731296769,
  "created_at" : "2011-06-16 13:47:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tkd",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81355521336152064",
  "text" : "I actually enjoyed my #tkd class last night, and leadership, too, even tho I didnt want to go. hmm.. a lesson there, perhaps?",
  "id" : 81355521336152064,
  "created_at" : "2011-06-16 13:40:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81349348209860609",
  "geo" : { },
  "id_str" : "81353210589220864",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver no I didnt! but now I did..lol. I just love him! \u2665 my DD cat lays on bags, too.. and her laptop, open or closed..lol",
  "id" : 81353210589220864,
  "in_reply_to_status_id" : 81349348209860609,
  "created_at" : "2011-06-16 13:31:31 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81349332686737408",
  "text" : "RT @mssuzcatsilver: If u r feeling negative emotions, accept them & affirm 'I give myself permission to feel this emotion, I bless it &  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81346534985318400",
    "text" : "If u r feeling negative emotions, accept them & affirm 'I give myself permission to feel this emotion, I bless it & let it go with #love",
    "id" : 81346534985318400,
    "created_at" : "2011-06-16 13:04:59 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 81349332686737408,
  "created_at" : "2011-06-16 13:16:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81347700997636096",
  "geo" : { },
  "id_str" : "81349092810297344",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver Im trying to be mindful of what I RT or post. sometimes I forget O-o .. good 2B reminded. TY",
  "id" : 81349092810297344,
  "in_reply_to_status_id" : 81347700997636096,
  "created_at" : "2011-06-16 13:15:09 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81178778017083393",
  "text" : "just saw a lunar moth by our screen door. very cool!",
  "id" : 81178778017083393,
  "created_at" : "2011-06-16 01:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81169987955466241",
  "geo" : { },
  "id_str" : "81171913879203841",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell we love seeing all the diff critters..lol",
  "id" : 81171913879203841,
  "in_reply_to_status_id" : 81169987955466241,
  "created_at" : "2011-06-16 01:31:07 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tkd",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81169944024317952",
  "text" : "soooo.. I scored a point in free sparring tonight in #tkd class. (I think my opponent got 6..lol)",
  "id" : 81169944024317952,
  "created_at" : "2011-06-16 01:23:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81169074771603456",
  "text" : "so the cat food on the porch is really for the stray cats but we dont mind the possum enjoying it, too",
  "id" : 81169074771603456,
  "created_at" : "2011-06-16 01:19:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81100192786563072",
  "text" : "i dont want to go to tkd class tonight but have no legitimate reason to not go. bleh.",
  "id" : 81100192786563072,
  "created_at" : "2011-06-15 20:46:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81099995121598464",
  "text" : "my mood is bouncing around. im not bi-polar but sometimes feels like it.",
  "id" : 81099995121598464,
  "created_at" : "2011-06-15 20:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81096958680375296",
  "text" : "RT @Matth3ous: Financial tip of the day: do NOT link reoccurring subscription charges directly to your checking account. Just...no.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81094460833931264",
    "text" : "Financial tip of the day: do NOT link reoccurring subscription charges directly to your checking account. Just...no.",
    "id" : 81094460833931264,
    "created_at" : "2011-06-15 20:23:20 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 81096958680375296,
  "created_at" : "2011-06-15 20:33:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81075278545297409",
  "text" : "RT @thesexyatheist: I will not let believers hijack love and caring. http:\/\/bit.ly\/mcC7Fh Those two thingies are for everyone, even athe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81071377901305856",
    "text" : "I will not let believers hijack love and caring. http:\/\/bit.ly\/mcC7Fh Those two thingies are for everyone, even atheists, yo.",
    "id" : 81071377901305856,
    "created_at" : "2011-06-15 18:51:37 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 81075278545297409,
  "created_at" : "2011-06-15 19:07:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81074970989568000",
  "text" : "RT @hvspca: HELP!!! We're running low on food and supplies for our kittys and pups! Can you help by donating any of the... http:\/\/fb.me\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81072918280421376",
    "text" : "HELP!!! We're running low on food and supplies for our kittys and pups! Can you help by donating any of the... http:\/\/fb.me\/13aamBo5p",
    "id" : 81072918280421376,
    "created_at" : "2011-06-15 18:57:44 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 81074970989568000,
  "created_at" : "2011-06-15 19:05:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/88djNhI",
      "expanded_url" : "http:\/\/www.peggysuebrister.com\/2011\/06\/gardasil-is-devil.html",
      "display_url" : "peggysuebrister.com\/2011\/06\/gardas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81063342231400448",
  "text" : "RT @PeggySueCusses: Gardasil is the DEVIL! New Blog Post: http:\/\/t.co\/88djNhI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 57 ],
        "url" : "http:\/\/t.co\/88djNhI",
        "expanded_url" : "http:\/\/www.peggysuebrister.com\/2011\/06\/gardasil-is-devil.html",
        "display_url" : "peggysuebrister.com\/2011\/06\/gardas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "81062968812515329",
    "text" : "Gardasil is the DEVIL! New Blog Post: http:\/\/t.co\/88djNhI",
    "id" : 81062968812515329,
    "created_at" : "2011-06-15 18:18:12 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 81063342231400448,
  "created_at" : "2011-06-15 18:19:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81060924940754945",
  "geo" : { },
  "id_str" : "81063272597553153",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen becuz I dont know what I want to do?",
  "id" : 81063272597553153,
  "in_reply_to_status_id" : 81060924940754945,
  "created_at" : "2011-06-15 18:19:24 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenda van Dinther",
      "screen_name" : "B_renda",
      "indices" : [ 0, 8 ],
      "id_str" : "15946129",
      "id" : 15946129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81058388368306176",
  "geo" : { },
  "id_str" : "81062856673599491",
  "in_reply_to_user_id" : 15946129,
  "text" : "@B_renda what a profound statement. something for me to ponder.",
  "id" : 81062856673599491,
  "in_reply_to_status_id" : 81058388368306176,
  "created_at" : "2011-06-15 18:17:45 +0000",
  "in_reply_to_screen_name" : "B_renda",
  "in_reply_to_user_id_str" : "15946129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Prosperity Guru",
      "screen_name" : "reginaldcuffee",
      "indices" : [ 3, 18 ],
      "id_str" : "51550779",
      "id" : 51550779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81062357614338048",
  "text" : "RT @reginaldcuffee: You were born free, but allowed yourself to be to trapped in a prison by society's rules and norms.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81058577883738115",
    "text" : "You were born free, but allowed yourself to be to trapped in a prison by society's rules and norms.",
    "id" : 81058577883738115,
    "created_at" : "2011-06-15 18:00:45 +0000",
    "user" : {
      "name" : "The Prosperity Guru",
      "screen_name" : "reginaldcuffee",
      "protected" : false,
      "id_str" : "51550779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1432413367\/The_ProsperityGuru_normal.jpg",
      "id" : 51550779,
      "verified" : false
    }
  },
  "id" : 81062357614338048,
  "created_at" : "2011-06-15 18:15:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81058294432661504",
  "text" : "well, except for maybe a few moments here & there",
  "id" : 81058294432661504,
  "created_at" : "2011-06-15 17:59:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81058129692991488",
  "text" : "having serious soul crisis.. boredom. I do believe you can die from boredom. Sounds weird but my WHOLE life I have been bored!",
  "id" : 81058129692991488,
  "created_at" : "2011-06-15 17:58:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81050268317396992",
  "text" : "RT @GraveStomper: Where there are endings there is newness and infinite possibility.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81047254974214144",
    "text" : "Where there are endings there is newness and infinite possibility.",
    "id" : 81047254974214144,
    "created_at" : "2011-06-15 17:15:46 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 81050268317396992,
  "created_at" : "2011-06-15 17:27:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/92P4D1Q",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bng3agUOYiI&feature=share",
      "display_url" : "youtube.com\/watch?v=bng3ag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81034425541992449",
  "text" : "RT @morsemusings: YOU are the watchtower. In celebration - Jimi Hendrix - All Along The Watchtower - http:\/\/t.co\/92P4D1Q v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 102 ],
        "url" : "http:\/\/t.co\/92P4D1Q",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bng3agUOYiI&feature=share",
        "display_url" : "youtube.com\/watch?v=bng3ag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "81033038103986179",
    "text" : "YOU are the watchtower. In celebration - Jimi Hendrix - All Along The Watchtower - http:\/\/t.co\/92P4D1Q v",
    "id" : 81033038103986179,
    "created_at" : "2011-06-15 16:19:16 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 81034425541992449,
  "created_at" : "2011-06-15 16:24:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81032773711839233",
  "text" : "RT @OMGFacts: If the nucleus of an atom were enlarged to the size of a period, the closest electron would be ten meters away.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81031768114860032",
    "text" : "If the nucleus of an atom were enlarged to the size of a period, the closest electron would be ten meters away.",
    "id" : 81031768114860032,
    "created_at" : "2011-06-15 16:14:13 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 81032773711839233,
  "created_at" : "2011-06-15 16:18:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 17, 30 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81031333933105153",
  "text" : "not always... RT @morsemusings: Don't you just love the game of CHANGE.",
  "id" : 81031333933105153,
  "created_at" : "2011-06-15 16:12:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81030825335984128",
  "text" : "RT @lisarobbinyoung: I often find that when God cancels an appointment, it's because he's got bigger plans for me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81030092972752896",
    "text" : "I often find that when God cancels an appointment, it's because he's got bigger plans for me.",
    "id" : 81030092972752896,
    "created_at" : "2011-06-15 16:07:34 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 81030825335984128,
  "created_at" : "2011-06-15 16:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 3, 10 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/Zr90oLO",
      "expanded_url" : "http:\/\/www.truth-out.org\/vermont-leads-way\/1308145904",
      "display_url" : "truth-out.org\/vermont-leads-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81025569038405632",
  "text" : "RT @moosep: Vermont Leads the Way | Truthout http:\/\/t.co\/Zr90oLO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 52 ],
        "url" : "http:\/\/t.co\/Zr90oLO",
        "expanded_url" : "http:\/\/www.truth-out.org\/vermont-leads-way\/1308145904",
        "display_url" : "truth-out.org\/vermont-leads-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "81024797768826881",
    "text" : "Vermont Leads the Way | Truthout http:\/\/t.co\/Zr90oLO",
    "id" : 81024797768826881,
    "created_at" : "2011-06-15 15:46:31 +0000",
    "user" : {
      "name" : "moosep",
      "screen_name" : "moosep",
      "protected" : false,
      "id_str" : "13118692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635466686485954560\/I2iA_q6N_normal.jpg",
      "id" : 13118692,
      "verified" : false
    }
  },
  "id" : 81025569038405632,
  "created_at" : "2011-06-15 15:49:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81011511979556864",
  "text" : "RT @aliceinthewater: If Rick Perry is a modern day religious profit then why are there still homeless people in Austin?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81009772379373568",
    "text" : "If Rick Perry is a modern day religious profit then why are there still homeless people in Austin?",
    "id" : 81009772379373568,
    "created_at" : "2011-06-15 14:46:49 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 81011511979556864,
  "created_at" : "2011-06-15 14:53:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81011231191859200",
  "text" : "oh bless that lovely mrs tragic pizza who's been married to that curmudgeon @tragic_pizza for 25 years today! ; ) many many more!",
  "id" : 81011231191859200,
  "created_at" : "2011-06-15 14:52:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81009031279419392",
  "text" : "I slept too long this am now I feel all wonky",
  "id" : 81009031279419392,
  "created_at" : "2011-06-15 14:43:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80812033330774016",
  "text" : "good night my special ones \u2665",
  "id" : 80812033330774016,
  "created_at" : "2011-06-15 01:41:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80804514646589440",
  "geo" : { },
  "id_str" : "80806310618210304",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous awesome! I havent done any tournaments yet.",
  "id" : 80806310618210304,
  "in_reply_to_status_id" : 80804514646589440,
  "created_at" : "2011-06-15 01:18:20 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80803821575610368",
  "geo" : { },
  "id_str" : "80804999462010880",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous thats sweet (symbols of pets) \u2665",
  "id" : 80804999462010880,
  "in_reply_to_status_id" : 80803821575610368,
  "created_at" : "2011-06-15 01:13:07 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80804124446298113",
  "text" : "RT @stevetheseeker: Love is only as distant as you think it is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80803581925658624",
    "text" : "Love is only as distant as you think it is.",
    "id" : 80803581925658624,
    "created_at" : "2011-06-15 01:07:29 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 80804124446298113,
  "created_at" : "2011-06-15 01:09:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80797501178920961",
  "text" : "RT @SheilaWalsh: I am fiercely convinced of God's love for us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80796713366994946",
    "text" : "I am fiercely convinced of God's love for us.",
    "id" : 80796713366994946,
    "created_at" : "2011-06-15 00:40:12 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 80797501178920961,
  "created_at" : "2011-06-15 00:43:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80797405271961600",
  "text" : "RT @krisngoodbooks: *clutches pearls* madness! RT @kindlevixen: Can we please stop referring to print books as \"real\" books and eb\u2026 (con ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80796407212163073",
    "text" : "*clutches pearls* madness! RT @kindlevixen: Can we please stop referring to print books as \"real\" books and eb\u2026 (cont) http:\/\/deck.ly\/~wGmkJ",
    "id" : 80796407212163073,
    "created_at" : "2011-06-15 00:38:59 +0000",
    "user" : {
      "name" : "Kris",
      "screen_name" : "krisrandom",
      "protected" : false,
      "id_str" : "155031802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730310450345181184\/z1o8xLOf_normal.jpg",
      "id" : 155031802,
      "verified" : false
    }
  },
  "id" : 80797405271961600,
  "created_at" : "2011-06-15 00:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80794701879447552",
  "geo" : { },
  "id_str" : "80795676992217088",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous omg'ness, im dangerous w the weapons. I tend to knock myself in the head! lol (not very coordinated)",
  "id" : 80795676992217088,
  "in_reply_to_status_id" : 80794701879447552,
  "created_at" : "2011-06-15 00:36:05 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80794390154592256",
  "text" : "my bible study was eye opening today. I learned more about my MIL among other things. was all good..lol",
  "id" : 80794390154592256,
  "created_at" : "2011-06-15 00:30:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 5, 20 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80793444414537728",
  "text" : "will @mssuzcatsilver give henry a smooch for me? lol",
  "id" : 80793444414537728,
  "created_at" : "2011-06-15 00:27:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 7, 15 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80793134820376576",
  "text" : "hoping @sangyeh is feeling better from last treatment. love her tweets about all the critters in her yard. : )",
  "id" : 80793134820376576,
  "created_at" : "2011-06-15 00:25:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Overt Dictionary",
      "screen_name" : "OvertDictionary",
      "indices" : [ 3, 19 ],
      "id_str" : "264991283",
      "id" : 264991283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80792653687562240",
  "text" : "RT @OvertDictionary: The War In Iraq: killed more than half a million children and made Dick Cheney and his friends very rich.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80786141497933824",
    "text" : "The War In Iraq: killed more than half a million children and made Dick Cheney and his friends very rich.",
    "id" : 80786141497933824,
    "created_at" : "2011-06-14 23:58:11 +0000",
    "user" : {
      "name" : "The Overt Dictionary",
      "screen_name" : "OvertDictionary",
      "protected" : false,
      "id_str" : "264991283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292603379\/overt_normal.png",
      "id" : 264991283,
      "verified" : false
    }
  },
  "id" : 80792653687562240,
  "created_at" : "2011-06-15 00:24:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 62, 71 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80792498829660160",
  "text" : "havent got to read my stream much today. hope @tragic_pizza & @Tideliar getting better results today",
  "id" : 80792498829660160,
  "created_at" : "2011-06-15 00:23:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 21, 31 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80792063125360640",
  "text" : "sending blessings to @Matth3ous.. weather causing him pain",
  "id" : 80792063125360640,
  "created_at" : "2011-06-15 00:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80774935009689600",
  "text" : "RT @fearfuldogs: telling a dog 'it's ok' when they r freaked out does NOT translate in2 'I'm right 2 b scared' may not help but it does  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80769260460322816",
    "text" : "telling a dog 'it's ok' when they r freaked out does NOT translate in2 'I'm right 2 b scared' may not help but it does NOT reinforce fear",
    "id" : 80769260460322816,
    "created_at" : "2011-06-14 22:51:06 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 80774935009689600,
  "created_at" : "2011-06-14 23:13:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80774299853664257",
  "text" : "RT @UnseeingEyes: Moral of the story...when you have to go, you have to go...& it is sadistic to not allow children to piss whenever the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80772031641157632",
    "text" : "Moral of the story...when you have to go, you have to go...& it is sadistic to not allow children to piss whenever they want.",
    "id" : 80772031641157632,
    "created_at" : "2011-06-14 23:02:07 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 80774299853664257,
  "created_at" : "2011-06-14 23:11:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frequency",
      "indices" : [ 48, 58 ]
    }, {
      "text" : "quantum",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80774032890408960",
  "text" : "RT @bend_time: everything we see is part of our #frequency,#quantum signature. dont like your life?change your MIND.thats all ya gotta d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "frequency",
        "indices" : [ 33, 43 ]
      }, {
        "text" : "quantum",
        "indices" : [ 44, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80773176879099904",
    "text" : "everything we see is part of our #frequency,#quantum signature. dont like your life?change your MIND.thats all ya gotta do.simple,not easy",
    "id" : 80773176879099904,
    "created_at" : "2011-06-14 23:06:40 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 80774032890408960,
  "created_at" : "2011-06-14 23:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruff Dog Rescue",
      "screen_name" : "911RUFFORG",
      "indices" : [ 3, 14 ],
      "id_str" : "235008736",
      "id" : 235008736
    }, {
      "name" : "Ruff Dog Rescue",
      "screen_name" : "911RUFFORG",
      "indices" : [ 25, 36 ],
      "id_str" : "235008736",
      "id" : 235008736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80748644541800448",
  "text" : "RT @911RUFFORG: pls help @911RUFFORG stay in the running! Competition is winning! U  have no idea how much a $1000 prize will help! http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ruff Dog Rescue",
        "screen_name" : "911RUFFORG",
        "indices" : [ 9, 20 ],
        "id_str" : "235008736",
        "id" : 235008736
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 135 ],
        "url" : "http:\/\/t.co\/uvk00Ft",
        "expanded_url" : "http:\/\/fb.me\/WgnaT0zH",
        "display_url" : "fb.me\/WgnaT0zH"
      } ]
    },
    "geo" : { },
    "id_str" : "80631703483330560",
    "text" : "pls help @911RUFFORG stay in the running! Competition is winning! U  have no idea how much a $1000 prize will help! http:\/\/t.co\/uvk00Ft",
    "id" : 80631703483330560,
    "created_at" : "2011-06-14 13:44:30 +0000",
    "user" : {
      "name" : "Ruff Dog Rescue",
      "screen_name" : "911RUFFORG",
      "protected" : false,
      "id_str" : "235008736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668326426928619520\/arlkLv8C_normal.png",
      "id" : 235008736,
      "verified" : false
    }
  },
  "id" : 80748644541800448,
  "created_at" : "2011-06-14 21:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedRabbit",
      "screen_name" : "DonkeyPr",
      "indices" : [ 3, 12 ],
      "id_str" : "4437188367",
      "id" : 4437188367
    }, {
      "name" : "Rifugio Asinelli",
      "screen_name" : "RifugioAsinelli",
      "indices" : [ 44, 60 ],
      "id_str" : "180811981",
      "id" : 180811981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "donkeypic",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80612218818928641",
  "text" : "RT @DonkeyPR: Awww supercute donkey nose RT @RifugioAsinelli: L'inconfondibile nasone di Agostino in questa #donkeypic http:\/\/flic.kr\/p\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rifugio Asinelli",
        "screen_name" : "RifugioAsinelli",
        "indices" : [ 30, 46 ],
        "id_str" : "180811981",
        "id" : 180811981
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "donkeypic",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80610276902313985",
    "text" : "Awww supercute donkey nose RT @RifugioAsinelli: L'inconfondibile nasone di Agostino in questa #donkeypic http:\/\/flic.kr\/p\/9Tp4YQ",
    "id" : 80610276902313985,
    "created_at" : "2011-06-14 12:19:22 +0000",
    "user" : {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "protected" : false,
      "id_str" : "95607516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710457498201952257\/F4zdnP4M_normal.jpg",
      "id" : 95607516,
      "verified" : true
    }
  },
  "id" : 80612218818928641,
  "created_at" : "2011-06-14 12:27:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/P8cjZU9",
      "expanded_url" : "http:\/\/www.jennascribbles.com\/books-and-ebooks\/kindle-books-tuesda\/",
      "display_url" : "jennascribbles.com\/books-and-eboo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80605245293608960",
  "text" : "RT @JAScribbles: Free #Kindle Books for Your Tuesday Enjoyment  - one with a very nice cover... Love it! http:\/\/t.co\/P8cjZU9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 107 ],
        "url" : "http:\/\/t.co\/P8cjZU9",
        "expanded_url" : "http:\/\/www.jennascribbles.com\/books-and-ebooks\/kindle-books-tuesda\/",
        "display_url" : "jennascribbles.com\/books-and-eboo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "80599318192603136",
    "text" : "Free #Kindle Books for Your Tuesday Enjoyment  - one with a very nice cover... Love it! http:\/\/t.co\/P8cjZU9",
    "id" : 80599318192603136,
    "created_at" : "2011-06-14 11:35:49 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 80605245293608960,
  "created_at" : "2011-06-14 11:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80604511370088448",
  "text" : "having my coffee. bible study a bit later. MIL already has me going next fall w her..lol",
  "id" : 80604511370088448,
  "created_at" : "2011-06-14 11:56:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80603709243011072",
  "text" : "good morning my beautiful peeps",
  "id" : 80603709243011072,
  "created_at" : "2011-06-14 11:53:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80456268891951104",
  "text" : "signing off... back tomorrow. thx 4 being my twitter friend!",
  "id" : 80456268891951104,
  "created_at" : "2011-06-14 02:07:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 23, 32 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80455917438648320",
  "text" : "I hope @tragic_pizza & @Tideliar have a better day tomorrow",
  "id" : 80455917438648320,
  "created_at" : "2011-06-14 02:06:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 0, 9 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80433352074739712",
  "geo" : { },
  "id_str" : "80436943577559040",
  "in_reply_to_user_id" : 27094110,
  "text" : "@JohnCali think I read ACIM 1st then found those 2. ACIM really changed me. I see miracles every day! : )",
  "id" : 80436943577559040,
  "in_reply_to_status_id" : 80433352074739712,
  "created_at" : "2011-06-14 00:50:36 +0000",
  "in_reply_to_screen_name" : "JohnCali",
  "in_reply_to_user_id_str" : "27094110",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80424798865469441",
  "geo" : { },
  "id_str" : "80436123595325440",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench is that good or bad? read a sample of it on my ipod.",
  "id" : 80436123595325440,
  "in_reply_to_status_id" : 80424798865469441,
  "created_at" : "2011-06-14 00:47:20 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 3, 13 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80434362969096192",
  "text" : "RT @ScottBaio: I've been told (a few times) the Sun-maid raisin girl looks like me.......... Well...... My kid just said the same thing. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80426138236755968",
    "text" : "I've been told (a few times) the Sun-maid raisin girl looks like me.......... Well...... My kid just said the same thing. Come on!!!",
    "id" : 80426138236755968,
    "created_at" : "2011-06-14 00:07:40 +0000",
    "user" : {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "protected" : false,
      "id_str" : "82447359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742477919801335816\/O6okGPN6_normal.jpg",
      "id" : 82447359,
      "verified" : true
    }
  },
  "id" : 80434362969096192,
  "created_at" : "2011-06-14 00:40:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80434314562650112",
  "text" : "RT @TracyLatz: \"pl\u0279o\u028D \u01DD\u0265\u0287 \u0287\u0250 \u029Eool no\u028E \u028E\u0250\u028D \u01DD\u0265\u0287 \u01DD\u0183u\u0250\u0265\u0254\" :) #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 42, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80426274597769216",
    "text" : "\"pl\u0279o\u028D \u01DD\u0265\u0287 \u0287\u0250 \u029Eool no\u028E \u028E\u0250\u028D \u01DD\u0265\u0287 \u01DD\u0183u\u0250\u0265\u0254\" :) #quote",
    "id" : 80426274597769216,
    "created_at" : "2011-06-14 00:08:12 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 80434314562650112,
  "created_at" : "2011-06-14 00:40:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 0, 15 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80400174282833920",
  "geo" : { },
  "id_str" : "80432893964451840",
  "in_reply_to_user_id" : 32435460,
  "text" : "@SpiritualNurse this is cool! thx 4 sharing!",
  "id" : 80432893964451840,
  "in_reply_to_status_id" : 80400174282833920,
  "created_at" : "2011-06-14 00:34:30 +0000",
  "in_reply_to_screen_name" : "SpiritualNurse",
  "in_reply_to_user_id_str" : "32435460",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 0, 9 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80417461580726272",
  "geo" : { },
  "id_str" : "80419840912920576",
  "in_reply_to_user_id" : 27094110,
  "text" : "@JohnCali love Seth and big fan of Abraham!",
  "id" : 80419840912920576,
  "in_reply_to_status_id" : 80417461580726272,
  "created_at" : "2011-06-13 23:42:38 +0000",
  "in_reply_to_screen_name" : "JohnCali",
  "in_reply_to_user_id_str" : "27094110",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80419633613647872",
  "text" : "RT @JohnCali: Are You a Victim of Yourself?: My first real spiritual teacher was Seth, as channeled by Jane Roberts. Most of m... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80417461580726272",
    "text" : "Are You a Victim of Yourself?: My first real spiritual teacher was Seth, as channeled by Jane Roberts. Most of m... http:\/\/bit.ly\/mt4lrT",
    "id" : 80417461580726272,
    "created_at" : "2011-06-13 23:33:11 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 80419633613647872,
  "created_at" : "2011-06-13 23:41:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Vision 11:11",
      "screen_name" : "KeepSeeing1111",
      "indices" : [ 3, 18 ],
      "id_str" : "213611114",
      "id" : 213611114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80417399035265024",
  "text" : "RT @KeepSeeing1111: JOY is contagious... pass it on ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80416308604321792",
    "text" : "JOY is contagious... pass it on ...",
    "id" : 80416308604321792,
    "created_at" : "2011-06-13 23:28:36 +0000",
    "user" : {
      "name" : "Global Vision 11:11",
      "screen_name" : "KeepSeeing1111",
      "protected" : false,
      "id_str" : "213611114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1163236901\/seeing_1111_big_normal.jpg",
      "id" : 213611114,
      "verified" : false
    }
  },
  "id" : 80417399035265024,
  "created_at" : "2011-06-13 23:32:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80416264723509249",
  "text" : "sometimes I miss her so. I get a flash of what she used to be. but I know she's ok. and Im ok, too. I \u2665 you Mom",
  "id" : 80416264723509249,
  "created_at" : "2011-06-13 23:28:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "ann  :)",
      "screen_name" : "ann2066",
      "indices" : [ 16, 24 ],
      "id_str" : "27686418",
      "id" : 27686418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80401503365500928",
  "text" : "RT @SangyeH: RT @ann2066: Baltimore MD: EXTRA URGENT!! Poor Nya was adopted\/dumped back bec didn't \"act the way she was expected to\" htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ann  :)",
        "screen_name" : "ann2066",
        "indices" : [ 3, 11 ],
        "id_str" : "27686418",
        "id" : 27686418
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80400950120034304",
    "text" : "RT @ann2066: Baltimore MD: EXTRA URGENT!! Poor Nya was adopted\/dumped back bec didn't \"act the way she was expected to\" http:\/\/bit.ly\/jD59iq",
    "id" : 80400950120034304,
    "created_at" : "2011-06-13 22:27:34 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 80401503365500928,
  "created_at" : "2011-06-13 22:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Retweet",
      "screen_name" : "RetweetIfs",
      "indices" : [ 23, 34 ],
      "id_str" : "621345350",
      "id" : 621345350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80392885865943040",
  "text" : "RT @mssuzcatsilver: RT @RetweetIfs: RT if you love your Twitter friends.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Retweet",
        "screen_name" : "RetweetIfs",
        "indices" : [ 3, 14 ],
        "id_str" : "621345350",
        "id" : 621345350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80392680806432771",
    "text" : "RT @RetweetIfs: RT if you love your Twitter friends.",
    "id" : 80392680806432771,
    "created_at" : "2011-06-13 21:54:43 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 80392885865943040,
  "created_at" : "2011-06-13 21:55:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    }, {
      "name" : "Sommer Marsden",
      "screen_name" : "sommer_marsden",
      "indices" : [ 20, 35 ],
      "id_str" : "70229276",
      "id" : 70229276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80385882548469761",
  "text" : "RT @JAScribbles: RT @sommer_marsden: Cause I'm not crazy enough right now...heh ;)~ Unapologetic Fiction: Call For Submissions http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sommer Marsden",
        "screen_name" : "sommer_marsden",
        "indices" : [ 3, 18 ],
        "id_str" : "70229276",
        "id" : 70229276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 129 ],
        "url" : "http:\/\/t.co\/QlkStSS",
        "expanded_url" : "http:\/\/sommermarsden.blogspot.com\/2011\/06\/call-for-submssions-new-writers.html?spref=tw",
        "display_url" : "sommermarsden.blogspot.com\/2011\/06\/call-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "80384839878062080",
    "text" : "RT @sommer_marsden: Cause I'm not crazy enough right now...heh ;)~ Unapologetic Fiction: Call For Submissions http:\/\/t.co\/QlkStSS",
    "id" : 80384839878062080,
    "created_at" : "2011-06-13 21:23:33 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 80385882548469761,
  "created_at" : "2011-06-13 21:27:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "kindle",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "indie",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/Jijtd8p",
      "expanded_url" : "http:\/\/amzn.to\/l8pSH4",
      "display_url" : "amzn.to\/l8pSH4"
    } ]
  },
  "geo" : { },
  "id_str" : "80385815158591488",
  "text" : "RT @DougDorow: Looking for a new #thriller for your #kindle ? I just published one http:\/\/t.co\/Jijtd8p 99 cents. #indie The Ninth District.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 18, 27 ]
      }, {
        "text" : "kindle",
        "indices" : [ 37, 44 ]
      }, {
        "text" : "indie",
        "indices" : [ 98, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 87 ],
        "url" : "http:\/\/t.co\/Jijtd8p",
        "expanded_url" : "http:\/\/amzn.to\/l8pSH4",
        "display_url" : "amzn.to\/l8pSH4"
      } ]
    },
    "geo" : { },
    "id_str" : "80384889077252096",
    "text" : "Looking for a new #thriller for your #kindle ? I just published one http:\/\/t.co\/Jijtd8p 99 cents. #indie The Ninth District.",
    "id" : 80384889077252096,
    "created_at" : "2011-06-13 21:23:45 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 80385815158591488,
  "created_at" : "2011-06-13 21:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80385675869945857",
  "text" : "may be a curmudgeon but @tragic_pizza 's ideas are based on love",
  "id" : 80385675869945857,
  "created_at" : "2011-06-13 21:26:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "People Pets",
      "screen_name" : "PEOPLEPets",
      "indices" : [ 3, 14 ],
      "id_str" : "22565066",
      "id" : 22565066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80382658399571969",
  "text" : "RT @PEOPLEPets: Trace Adkins may have lost his home to a fire, but he still has his dogs, thanks to his fearless 9-year-old daughter htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80380794648002560",
    "text" : "Trace Adkins may have lost his home to a fire, but he still has his dogs, thanks to his fearless 9-year-old daughter http:\/\/ow.ly\/5gPxt",
    "id" : 80380794648002560,
    "created_at" : "2011-06-13 21:07:29 +0000",
    "user" : {
      "name" : "People Pets",
      "screen_name" : "PEOPLEPets",
      "protected" : false,
      "id_str" : "22565066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713022349474332672\/QwvQOaWJ_normal.jpg",
      "id" : 22565066,
      "verified" : true
    }
  },
  "id" : 80382658399571969,
  "created_at" : "2011-06-13 21:14:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80374683987484672",
  "text" : "RT @UnseeingEyes: Jun 13, 1920...The United States Postal Service rules that children may not be sent via Parcel Post",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80374474188406784",
    "text" : "Jun 13, 1920...The United States Postal Service rules that children may not be sent via Parcel Post",
    "id" : 80374474188406784,
    "created_at" : "2011-06-13 20:42:22 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 80374683987484672,
  "created_at" : "2011-06-13 20:43:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 0, 10 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http:\/\/t.co\/pwdMAM1",
      "expanded_url" : "http:\/\/kindleworld.blogspot.com\/2011\/05\/nook-vs-kindle-features-also-free.html",
      "display_url" : "kindleworld.blogspot.com\/2011\/05\/nook-v\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "80366340694753280",
  "geo" : { },
  "id_str" : "80368687776935936",
  "in_reply_to_user_id" : 14428947,
  "text" : "@bcmystery http:\/\/t.co\/pwdMAM1",
  "id" : 80368687776935936,
  "in_reply_to_status_id" : 80366340694753280,
  "created_at" : "2011-06-13 20:19:23 +0000",
  "in_reply_to_screen_name" : "bcmystery",
  "in_reply_to_user_id_str" : "14428947",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80367888669749248",
  "text" : "RT @bcmystery: Kindle or Nook? Can't make up my mind. Don't really want either, but something has come up to make an eReader a necessity ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "workthing",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80366340694753280",
    "text" : "Kindle or Nook? Can't make up my mind. Don't really want either, but something has come up to make an eReader a necessity. #workthing",
    "id" : 80366340694753280,
    "created_at" : "2011-06-13 20:10:03 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 80367888669749248,
  "created_at" : "2011-06-13 20:16:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80366873027424256",
  "geo" : { },
  "id_str" : "80367310287810560",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles hmm.. too much blaming, negativity or I lose interest in what they're tweeting (I change)",
  "id" : 80367310287810560,
  "in_reply_to_status_id" : 80366873027424256,
  "created_at" : "2011-06-13 20:13:54 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80352059181907968",
  "geo" : { },
  "id_str" : "80355544082288640",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer I am good! Thx 4 asking : ) mmm.. pizza... ((drool))",
  "id" : 80355544082288640,
  "in_reply_to_status_id" : 80352059181907968,
  "created_at" : "2011-06-13 19:27:09 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80347172863877120",
  "geo" : { },
  "id_str" : "80349476463718400",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen heehee.. YES! I finally got it awhile back and said, heck w this.. im doing what \"I\" want..lol",
  "id" : 80349476463718400,
  "in_reply_to_status_id" : 80347172863877120,
  "created_at" : "2011-06-13 19:03:02 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80348653826473984",
  "text" : "RT @thesexyatheist: Check out my epic interview at a religious site. http:\/\/bit.ly\/lpYo8s Team Atheist, whether we like it or not...we r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80331776735723520",
    "text" : "Check out my epic interview at a religious site. http:\/\/bit.ly\/lpYo8s Team Atheist, whether we like it or not...we represent the Team.",
    "id" : 80331776735723520,
    "created_at" : "2011-06-13 17:52:42 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 80348653826473984,
  "created_at" : "2011-06-13 18:59:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 5, 14 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80346674303741953",
  "text" : "poor @Tideliar seems to be having a sucky day. His F's are higher than usual ; )",
  "id" : 80346674303741953,
  "created_at" : "2011-06-13 18:51:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80346111918878721",
  "text" : "once you ingrain that into your brain, its much easier to not care what other ppl think or do or if they like you...",
  "id" : 80346111918878721,
  "created_at" : "2011-06-13 18:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80345777997754368",
  "text" : "no matter WHO you are or WHAT you do, there will be ppl who will NOT like you or disagree w your view or think you are WRONG",
  "id" : 80345777997754368,
  "created_at" : "2011-06-13 18:48:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80338035010568192",
  "geo" : { },
  "id_str" : "80342977989451777",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulzMayBe ok, then! lol",
  "id" : 80342977989451777,
  "in_reply_to_status_id" : 80338035010568192,
  "created_at" : "2011-06-13 18:37:13 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80312181845008384",
  "geo" : { },
  "id_str" : "80312912446623744",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles this applies to teens as well..lol",
  "id" : 80312912446623744,
  "in_reply_to_status_id" : 80312181845008384,
  "created_at" : "2011-06-13 16:37:45 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80292836280512513",
  "text" : "@Tideliar well, you ARE intimidating : ) hope your meeting goes well, tho.",
  "id" : 80292836280512513,
  "created_at" : "2011-06-13 15:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80284416991170560",
  "text" : "RT @DeepakChopra: There are only 2 responses to the world, fear or love. Your life depends on which one you choose",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80284246576594944",
    "text" : "There are only 2 responses to the world, fear or love. Your life depends on which one you choose",
    "id" : 80284246576594944,
    "created_at" : "2011-06-13 14:43:50 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 80284416991170560,
  "created_at" : "2011-06-13 14:44:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80268936985317376",
  "text" : "RT @luminanceriver: Don\u2019t stay focused on what\u2019s WRONG, focus on what\u2019s POSSIBLE.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80260477673934850",
    "text" : "Don\u2019t stay focused on what\u2019s WRONG, focus on what\u2019s POSSIBLE.",
    "id" : 80260477673934850,
    "created_at" : "2011-06-13 13:09:23 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 80268936985317376,
  "created_at" : "2011-06-13 13:43:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 92, 100 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/55ZVYm7",
      "expanded_url" : "http:\/\/cbsloc.al\/iQ5Wqg",
      "display_url" : "cbsloc.al\/iQ5Wqg"
    } ]
  },
  "geo" : { },
  "id_str" : "80263626207928320",
  "text" : "OMG - Democrat Lawmaker Wants Ban On Smoking In Cars With\u00A0Children: http:\/\/t.co\/55ZVYm7 via @addthis",
  "id" : 80263626207928320,
  "created_at" : "2011-06-13 13:21:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80250351583903744",
  "geo" : { },
  "id_str" : "80251140322766848",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 LOL",
  "id" : 80251140322766848,
  "in_reply_to_status_id" : 80250351583903744,
  "created_at" : "2011-06-13 12:32:17 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80235702960398336",
  "geo" : { },
  "id_str" : "80248967442599937",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl feeling like a superhereo today? ; )",
  "id" : 80248967442599937,
  "in_reply_to_status_id" : 80235702960398336,
  "created_at" : "2011-06-13 12:23:39 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80073363988545536",
  "text" : "I LOVE the theme for my website but might have to create a separate one for my blog. hmm...",
  "id" : 80073363988545536,
  "created_at" : "2011-06-13 00:45:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "indices" : [ 3, 18 ],
      "id_str" : "29574025",
      "id" : 29574025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80055616965586944",
  "text" : "RT @KindleObsessed: ATTN AUTHORS!!!\n\nToday is ur last chance to submit a review request through KO. I'm shutting it down again. (I've ha ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80054873013489664",
    "text" : "ATTN AUTHORS!!!\n\nToday is ur last chance to submit a review request through KO. I'm shutting it down again. (I've had 200 req in 2 weeks)",
    "id" : 80054873013489664,
    "created_at" : "2011-06-12 23:32:23 +0000",
    "user" : {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "protected" : false,
      "id_str" : "29574025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526178477213380608\/oLhvSdVV_normal.jpeg",
      "id" : 29574025,
      "verified" : false
    }
  },
  "id" : 80055616965586944,
  "created_at" : "2011-06-12 23:35:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80039419641466883",
  "geo" : { },
  "id_str" : "80045593979912192",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver omg'ness.. I feel so special! ((hugs)) and *smooches* to Henry!",
  "id" : 80045593979912192,
  "in_reply_to_status_id" : 80039419641466883,
  "created_at" : "2011-06-12 22:55:31 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Lesley-Scottish Mum",
      "screen_name" : "Scottish_Mum",
      "indices" : [ 16, 29 ],
      "id_str" : "195840877",
      "id" : 195840877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80030259172491264",
  "geo" : { },
  "id_str" : "80038546060226561",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver @Scottish_Mum that was beautiful. I sooo wanted to see him, tho..LOL",
  "id" : 80038546060226561,
  "in_reply_to_status_id" : 80030259172491264,
  "created_at" : "2011-06-12 22:27:31 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80037975999782912",
  "text" : "I stepped on baked beans (with socks on)",
  "id" : 80037975999782912,
  "created_at" : "2011-06-12 22:25:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79996420639305729",
  "geo" : { },
  "id_str" : "79999613284786177",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem we know you love us! lol : )",
  "id" : 79999613284786177,
  "in_reply_to_status_id" : 79996420639305729,
  "created_at" : "2011-06-12 19:52:48 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 58, 68 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cancer",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "treatment",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/FmCSwWi",
      "expanded_url" : "http:\/\/www.chriscade.com\/2011\/06\/my-brother-died-from-cancer-10-years-ago-on-this-day\/",
      "display_url" : "chriscade.com\/2011\/06\/my-bro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "79985790087741440",
  "text" : "My Brother Died From Cancer \u2013 10 Years Ago On This Day by @chriscade http:\/\/t.co\/FmCSwWi #cancer #treatment",
  "id" : 79985790087741440,
  "created_at" : "2011-06-12 18:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "indices" : [ 47, 56 ],
      "id_str" : "17304367",
      "id" : 17304367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/bw2UWlR",
      "expanded_url" : "http:\/\/social.e2ma.net\/share\/t\/28888\/82b5bb5ff4d36d36ccef1f23d03b0ed6\/",
      "display_url" : "social.e2ma.net\/share\/t\/28888\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "79978386616881152",
  "text" : "Check out Book of the Day! http:\/\/t.co\/bw2UWlR @bookpage",
  "id" : 79978386616881152,
  "created_at" : "2011-06-12 18:28:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 0, 13 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79885970970910720",
  "geo" : { },
  "id_str" : "79954328378544128",
  "in_reply_to_user_id" : 113458113,
  "text" : "@neardeathdoc this either \/ or thinking strikes a nerve w me..lol. Thx 4 RT!",
  "id" : 79954328378544128,
  "in_reply_to_status_id" : 79885970970910720,
  "created_at" : "2011-06-12 16:52:52 +0000",
  "in_reply_to_screen_name" : "neardeathdoc",
  "in_reply_to_user_id_str" : "113458113",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79929097245048833",
  "geo" : { },
  "id_str" : "79954073163546624",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps TY for RT : )",
  "id" : 79954073163546624,
  "in_reply_to_status_id" : 79929097245048833,
  "created_at" : "2011-06-12 16:51:51 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 30, 43 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79951835821113345",
  "text" : "from my own research, testing @derekrootboy I seem to fall well w\/in Asperger (and my DD as well)",
  "id" : 79951835821113345,
  "created_at" : "2011-06-12 16:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 12, 25 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79951309461127168",
  "text" : "even as kid @derekrootboy I knew my brain worked diff than avg person. but being a kid, I thought I was evil, bad, stupid, worthless.",
  "id" : 79951309461127168,
  "created_at" : "2011-06-12 16:40:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 22, 35 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79950927175491584",
  "text" : "my DD is very similar @derekrootboy in this regard",
  "id" : 79950927175491584,
  "created_at" : "2011-06-12 16:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 39, 52 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79950693078810624",
  "text" : "I refer to academics but also socially @derekrootboy",
  "id" : 79950693078810624,
  "created_at" : "2011-06-12 16:38:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 26, 39 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79950475566395392",
  "text" : "some of what you speak of @derekrootboy hits chord w me. I was considered intelligent yet school was hard for me. ez 4 others, tough 4 me",
  "id" : 79950475566395392,
  "created_at" : "2011-06-12 16:37:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79938407517786114",
  "text" : "RT @GraveStomper: What will you do today to connect yourself to a world \/cause larger than just yourself and your own comfort?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79937147628556288",
    "text" : "What will you do today to connect yourself to a world \/cause larger than just yourself and your own comfort?",
    "id" : 79937147628556288,
    "created_at" : "2011-06-12 15:44:35 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 79938407517786114,
  "created_at" : "2011-06-12 15:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79938282540113920",
  "text" : "RT @JosephRanseth: Oh, I've got a feeling about today... It's going to be good. ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79937688563752961",
    "text" : "Oh, I've got a feeling about today... It's going to be good. ;)",
    "id" : 79937688563752961,
    "created_at" : "2011-06-12 15:46:44 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 79938282540113920,
  "created_at" : "2011-06-12 15:49:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 4, 17 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79935700954398720",
  "geo" : { },
  "id_str" : "79936706509418496",
  "in_reply_to_user_id" : 35585695,
  "text" : "hey @derekrootboy a sloth on cannabis? ima steal that from ya. good descrip for me..lol",
  "id" : 79936706509418496,
  "in_reply_to_status_id" : 79935700954398720,
  "created_at" : "2011-06-12 15:42:50 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "saved",
      "screen_name" : "tragicpizza",
      "indices" : [ 119, 131 ],
      "id_str" : "3774411381",
      "id" : 3774411381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79928066528382977",
  "text" : "more than one way to peel a banana..at least two, and both do what they need..they produce fruit. http:\/\/bit.ly\/l0ml2v @tragicpizza",
  "id" : 79928066528382977,
  "created_at" : "2011-06-12 15:08:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Williams",
      "screen_name" : "ScottWilliams",
      "indices" : [ 3, 17 ],
      "id_str" : "2608911",
      "id" : 2608911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79924699060109313",
  "text" : "RT @ScottWilliams: The function of prayer is not to influence God, but rather to change the nature of the one who prays. ~Soren K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79898400203612160",
    "text" : "The function of prayer is not to influence God, but rather to change the nature of the one who prays. ~Soren K",
    "id" : 79898400203612160,
    "created_at" : "2011-06-12 13:10:37 +0000",
    "user" : {
      "name" : "Scott Williams",
      "screen_name" : "ScottWilliams",
      "protected" : false,
      "id_str" : "2608911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658235797707952129\/WlFBW0GY_normal.jpg",
      "id" : 2608911,
      "verified" : true
    }
  },
  "id" : 79924699060109313,
  "created_at" : "2011-06-12 14:55:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shift",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79915837816967168",
  "text" : "RT @TracyLatz: TIME- temporally induced mind experiment. Seems that way! #shift",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shift",
        "indices" : [ 58, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79901971879956480",
    "text" : "TIME- temporally induced mind experiment. Seems that way! #shift",
    "id" : 79901971879956480,
    "created_at" : "2011-06-12 13:24:49 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 79915837816967168,
  "created_at" : "2011-06-12 14:19:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "-  Jeff Goldstein",
      "screen_name" : "doctorjeff",
      "indices" : [ 17, 28 ],
      "id_str" : "19927012",
      "id" : 19927012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79914887714844672",
  "text" : "RT @gemswinc: MT @doctorjeff: Dateline 2015: teachers are happy to report testing takes up 90% of class time. (signed, those teachers th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "-  Jeff Goldstein",
        "screen_name" : "doctorjeff",
        "indices" : [ 3, 14 ],
        "id_str" : "19927012",
        "id" : 19927012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79911802200264704",
    "text" : "MT @doctorjeff: Dateline 2015: teachers are happy to report testing takes up 90% of class time. (signed, those teachers that are left)",
    "id" : 79911802200264704,
    "created_at" : "2011-06-12 14:03:52 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 79914887714844672,
  "created_at" : "2011-06-12 14:16:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    }, {
      "name" : "Friends of Bashar",
      "screen_name" : "imagine2real",
      "indices" : [ 23, 36 ],
      "id_str" : "318774357",
      "id" : 318774357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soulchat",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79914762560995328",
  "text" : "RT @AnAmericanMonk: RT @imagine2real: Your life is your message to the world. #soulchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Friends of Bashar",
        "screen_name" : "imagine2real",
        "indices" : [ 3, 16 ],
        "id_str" : "318774357",
        "id" : 318774357
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "soulchat",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79912796124487680",
    "text" : "RT @imagine2real: Your life is your message to the world. #soulchat",
    "id" : 79912796124487680,
    "created_at" : "2011-06-12 14:07:49 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 79914762560995328,
  "created_at" : "2011-06-12 14:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79914331789197312",
  "text" : "Im a lil of this, lil of that. perhaps thats why Im not taken seriously.. not enough of 1 thing 2B properly labelled! LOL",
  "id" : 79914331789197312,
  "created_at" : "2011-06-12 14:13:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79720472341782528",
  "geo" : { },
  "id_str" : "79721368891031552",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms yes, there is something special about them.. being tangible.. but I couldnt read as much w\/o my kindle &gt;&gt; ez access 2 books",
  "id" : 79721368891031552,
  "in_reply_to_status_id" : 79720472341782528,
  "created_at" : "2011-06-12 01:27:10 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79708410681110528",
  "text" : "supermodel.. such an odd term.",
  "id" : 79708410681110528,
  "created_at" : "2011-06-12 00:35:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79702884857544704",
  "text" : "RT @DharmaTalks: The Universe\/Light knows it\u2019s difficult to be human.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79702204717604864",
    "text" : "The Universe\/Light knows it\u2019s difficult to be human.",
    "id" : 79702204717604864,
    "created_at" : "2011-06-12 00:11:01 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 79702884857544704,
  "created_at" : "2011-06-12 00:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79693734089990144",
  "text" : "No one is trying to do away with books http:\/\/bit.ly\/mipK1W",
  "id" : 79693734089990144,
  "created_at" : "2011-06-11 23:37:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79680615619899392",
  "text" : "RT @SangyeH: Going to Walmart is like an assault on the psyche.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79679597771370496",
    "text" : "Going to Walmart is like an assault on the psyche.",
    "id" : 79679597771370496,
    "created_at" : "2011-06-11 22:41:11 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 79680615619899392,
  "created_at" : "2011-06-11 22:45:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/ILRBeIw",
      "expanded_url" : "http:\/\/bit.ly\/infwvL",
      "display_url" : "bit.ly\/infwvL"
    } ]
  },
  "geo" : { },
  "id_str" : "79673884206567425",
  "text" : "a new post on my blog \"Under His Wings\" http:\/\/t.co\/ILRBeIw (a cute pic & a verse)",
  "id" : 79673884206567425,
  "created_at" : "2011-06-11 22:18:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79672688217563137",
  "geo" : { },
  "id_str" : "79673051654012928",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem oh god, ANY politics drives me crazy..hehe.. I understand! lol",
  "id" : 79673051654012928,
  "in_reply_to_status_id" : 79672688217563137,
  "created_at" : "2011-06-11 22:15:10 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79671639108886528",
  "geo" : { },
  "id_str" : "79672804714356737",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt sounds delightful!",
  "id" : 79672804714356737,
  "in_reply_to_status_id" : 79671639108886528,
  "created_at" : "2011-06-11 22:14:11 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79664897138503680",
  "geo" : { },
  "id_str" : "79665526275706881",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ahh, yeah, my DD is same. She calls my kindle evil..lol",
  "id" : 79665526275706881,
  "in_reply_to_status_id" : 79664897138503680,
  "created_at" : "2011-06-11 21:45:16 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79664441863573504",
  "text" : "RT @TracyLatz: \"The bad news: There is no key to the universe. The good news: It was never locked.\" \u2014 Swami Beyondananda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79664191560093697",
    "text" : "\"The bad news: There is no key to the universe. The good news: It was never locked.\" \u2014 Swami Beyondananda",
    "id" : 79664191560093697,
    "created_at" : "2011-06-11 21:39:58 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 79664441863573504,
  "created_at" : "2011-06-11 21:40:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79663412027731968",
  "geo" : { },
  "id_str" : "79664143459815424",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses you need to get a kindle! lol (sorry, cant help myself) ; )",
  "id" : 79664143459815424,
  "in_reply_to_status_id" : 79663412027731968,
  "created_at" : "2011-06-11 21:39:46 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 4, 14 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79659693248753664",
  "geo" : { },
  "id_str" : "79660253523881984",
  "in_reply_to_user_id" : 48215218,
  "text" : "hey @bend_time where have you been?? I noticed you were gone.. was worried! ((hugs))",
  "id" : 79660253523881984,
  "in_reply_to_status_id" : 79659693248753664,
  "created_at" : "2011-06-11 21:24:19 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79627506453463040",
  "text" : "Great Thrillers on Kindle http:\/\/bit.ly\/iTRKFV - thread on KB. Indie Authors, Add Yours!",
  "id" : 79627506453463040,
  "created_at" : "2011-06-11 19:14:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "nook",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/Jijtd8p",
      "expanded_url" : "http:\/\/amzn.to\/l8pSH4",
      "display_url" : "amzn.to\/l8pSH4"
    } ]
  },
  "geo" : { },
  "id_str" : "79622161467318272",
  "text" : "RT @DougDorow: My new thriller The Ninth District is finally available for #kindle http:\/\/t.co\/Jijtd8p #nook and others soon Plz RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 60, 67 ]
      }, {
        "text" : "nook",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 87 ],
        "url" : "http:\/\/t.co\/Jijtd8p",
        "expanded_url" : "http:\/\/amzn.to\/l8pSH4",
        "display_url" : "amzn.to\/l8pSH4"
      } ]
    },
    "geo" : { },
    "id_str" : "79618062126546944",
    "text" : "My new thriller The Ninth District is finally available for #kindle http:\/\/t.co\/Jijtd8p #nook and others soon Plz RT",
    "id" : 79618062126546944,
    "created_at" : "2011-06-11 18:36:39 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 79622161467318272,
  "created_at" : "2011-06-11 18:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    }, {
      "name" : "Zappos",
      "screen_name" : "zappos",
      "indices" : [ 29, 36 ],
      "id_str" : "338601496",
      "id" : 338601496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/RD76Fw7",
      "expanded_url" : "http:\/\/yfrog.com\/kknwtj",
      "display_url" : "yfrog.com\/kknwtj"
    } ]
  },
  "geo" : { },
  "id_str" : "79600174732808192",
  "text" : "RT @aliceinthewater: I guess @zappos will be pleased to know that their shipping boxes are good cat beds. http:\/\/t.co\/RD76Fw7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zappos",
        "screen_name" : "zappos",
        "indices" : [ 8, 15 ],
        "id_str" : "338601496",
        "id" : 338601496
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 104 ],
        "url" : "http:\/\/t.co\/RD76Fw7",
        "expanded_url" : "http:\/\/yfrog.com\/kknwtj",
        "display_url" : "yfrog.com\/kknwtj"
      } ]
    },
    "geo" : { },
    "id_str" : "79598798179024896",
    "text" : "I guess @zappos will be pleased to know that their shipping boxes are good cat beds. http:\/\/t.co\/RD76Fw7",
    "id" : 79598798179024896,
    "created_at" : "2011-06-11 17:20:07 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 79600174732808192,
  "created_at" : "2011-06-11 17:25:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79595047229726720",
  "geo" : { },
  "id_str" : "79597525417459713",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater omg'ness.. looks like my Ghosty (rip) *smooches*",
  "id" : 79597525417459713,
  "in_reply_to_status_id" : 79595047229726720,
  "created_at" : "2011-06-11 17:15:03 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 9, 25 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79595365946490880",
  "geo" : { },
  "id_str" : "79596979172294656",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH @aliceinthewater LOL Cats are funny that way.. heehee",
  "id" : 79596979172294656,
  "in_reply_to_status_id" : 79595365946490880,
  "created_at" : "2011-06-11 17:12:53 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROCK",
      "indices" : [ 119, 124 ]
    }, {
      "text" : "love",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79594977096761344",
  "text" : "RT @mssuzcatsilver: I am SO infinitely blessed ... and you all make a difference & don't let anyone tell u different u #ROCK #love #appr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROCK",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "love",
        "indices" : [ 105, 110 ]
      }, {
        "text" : "appreciation",
        "indices" : [ 111, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79594667599077376",
    "text" : "I am SO infinitely blessed ... and you all make a difference & don't let anyone tell u different u #ROCK #love #appreciation.......",
    "id" : 79594667599077376,
    "created_at" : "2011-06-11 17:03:42 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 79594977096761344,
  "created_at" : "2011-06-11 17:04:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79594648431112192",
  "text" : "RT @Moonrust: Tiny village is latest victim of mystery hum http:\/\/bit.ly\/iACiji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79592797434429440",
    "text" : "Tiny village is latest victim of mystery hum http:\/\/bit.ly\/iACiji",
    "id" : 79592797434429440,
    "created_at" : "2011-06-11 16:56:16 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 79594648431112192,
  "created_at" : "2011-06-11 17:03:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79585980834783232",
  "text" : "funny little gray mouse w big beady eyes landed in our recycle bin..lol..he got out B4 DH could take him outside",
  "id" : 79585980834783232,
  "created_at" : "2011-06-11 16:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loa",
      "indices" : [ 43, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79585569935593472",
  "text" : "RT @mssuzcatsilver: There are NO accidents #loa. We are where we are and that is ok and it is enough....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loa",
        "indices" : [ 23, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79581410880528384",
    "text" : "There are NO accidents #loa. We are where we are and that is ok and it is enough....",
    "id" : 79581410880528384,
    "created_at" : "2011-06-11 16:11:01 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 79585569935593472,
  "created_at" : "2011-06-11 16:27:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79585534841860097",
  "text" : "RT @Mahala: Did you know you can mail expired coupons to bases overseas for use in commissaries?  They're good for 6 months after expira ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79581608096710656",
    "text" : "Did you know you can mail expired coupons to bases overseas for use in commissaries?  They're good for 6 months after expiration.",
    "id" : 79581608096710656,
    "created_at" : "2011-06-11 16:11:48 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 79585534841860097,
  "created_at" : "2011-06-11 16:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79585287310802944",
  "text" : "RT @bunnybuddhism: Bunniness is a life skill that is learned with time, effort, and ongoing practice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79583785343135744",
    "text" : "Bunniness is a life skill that is learned with time, effort, and ongoing practice.",
    "id" : 79583785343135744,
    "created_at" : "2011-06-11 16:20:27 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 79585287310802944,
  "created_at" : "2011-06-11 16:26:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79577375163154432",
  "text" : "@SamsaricWarrior you dont need to be strong to let it go.. you just need to stop holding : )",
  "id" : 79577375163154432,
  "created_at" : "2011-06-11 15:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 4, 12 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79567411870826496",
  "text" : "hey @twitter FYI: past 2 weeks getting twitter dm emails that are blank AND not getting emails of real msgs",
  "id" : 79567411870826496,
  "created_at" : "2011-06-11 15:15:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79342920217526272",
  "geo" : { },
  "id_str" : "79350557244006400",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench uh-oh!",
  "id" : 79350557244006400,
  "in_reply_to_status_id" : 79342920217526272,
  "created_at" : "2011-06-11 00:53:41 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 7, 15 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79301948246990848",
  "text" : "LOL RT @MWM4444: My husband and I have six cats, all of whom welove dearly. We're both pussy-whipped.",
  "id" : 79301948246990848,
  "created_at" : "2011-06-10 21:40:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79298605915185152",
  "geo" : { },
  "id_str" : "79301061990551552",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell hmm.. possibly more twitters have FB than FBers have twitter? dunno but yeah, thats interesting.",
  "id" : 79301061990551552,
  "in_reply_to_status_id" : 79298605915185152,
  "created_at" : "2011-06-10 21:37:01 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 17, 28 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79293324233674752",
  "text" : "RT @angelaharms: @moosebegab You are loved for who you are, your unique vision, your tenacity--Not for the physical work you do or don't do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "79289914998530048",
    "geo" : { },
    "id_str" : "79292276538486786",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab You are loved for who you are, your unique vision, your tenacity--Not for the physical work you do or don't do.",
    "id" : 79292276538486786,
    "in_reply_to_status_id" : 79289914998530048,
    "created_at" : "2011-06-10 21:02:06 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 79293324233674752,
  "created_at" : "2011-06-10 21:06:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 0, 13 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79290612314161152",
  "geo" : { },
  "id_str" : "79291460691832832",
  "in_reply_to_user_id" : 41965454,
  "text" : "@manzano_moon I think he equates working with goodness",
  "id" : 79291460691832832,
  "in_reply_to_status_id" : 79290612314161152,
  "created_at" : "2011-06-10 20:58:52 +0000",
  "in_reply_to_screen_name" : "manzano_moon",
  "in_reply_to_user_id_str" : "41965454",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 3, 16 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79289971252527106",
  "text" : "RT @golden_books: A good way to avoid disappointment is to appreciate people for who they are and don't try to change them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79289831993249792",
    "text" : "A good way to avoid disappointment is to appreciate people for who they are and don't try to change them.",
    "id" : 79289831993249792,
    "created_at" : "2011-06-10 20:52:23 +0000",
    "user" : {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "protected" : false,
      "id_str" : "124594428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707724561714905089\/xr54lDFv_normal.jpg",
      "id" : 124594428,
      "verified" : false
    }
  },
  "id" : 79289971252527106,
  "created_at" : "2011-06-10 20:52:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79289914998530048",
  "text" : "my hubby is a hard worker. why he married me.. who is quite sloth-like.. is beyond me!",
  "id" : 79289914998530048,
  "created_at" : "2011-06-10 20:52:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zondervan Publishers",
      "screen_name" : "Zondervan",
      "indices" : [ 3, 13 ],
      "id_str" : "13681022",
      "id" : 13681022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NIV",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79265770827284480",
  "text" : "RT @zondervan: We're giving away one more of the NIV & KJV Side-by-Side Bibles. Find out how you can enter here http:\/\/zndr.vn\/igyFq4. #NIV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NIV",
        "indices" : [ 120, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79244854143631360",
    "text" : "We're giving away one more of the NIV & KJV Side-by-Side Bibles. Find out how you can enter here http:\/\/zndr.vn\/igyFq4. #NIV",
    "id" : 79244854143631360,
    "created_at" : "2011-06-10 17:53:40 +0000",
    "user" : {
      "name" : "Zondervan Publishers",
      "screen_name" : "Zondervan",
      "protected" : false,
      "id_str" : "13681022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1977732408\/twitterprofile_normal.jpg",
      "id" : 13681022,
      "verified" : true
    }
  },
  "id" : 79265770827284480,
  "created_at" : "2011-06-10 19:16:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 93, 101 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/u2gnTiW",
      "expanded_url" : "http:\/\/bit.ly\/k37tcJ",
      "display_url" : "bit.ly\/k37tcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "79265398305992704",
  "text" : "Moose on loose barges into Swedish retirement home - KansasCity.com: http:\/\/t.co\/u2gnTiW via @AddThis",
  "id" : 79265398305992704,
  "created_at" : "2011-06-10 19:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 37, 49 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 50, 61 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 79, 88 ],
      "id_str" : "14986977",
      "id" : 14986977
    }, {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 89, 101 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 102, 114 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 115, 127 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79244560290680832",
  "text" : "#FF some nice ppl who talk to me : ) @CaroleODell @mimismutts @SamsaricWarrior @Teawench @alisyngayle @angelaharms @JAScribbles",
  "id" : 79244560290680832,
  "created_at" : "2011-06-10 17:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Del Rey Spectra",
      "screen_name" : "DelReySpectra",
      "indices" : [ 3, 17 ],
      "id_str" : "4527981915",
      "id" : 4527981915
    }, {
      "name" : "Lia Habel",
      "screen_name" : "liahabel",
      "indices" : [ 51, 60 ],
      "id_str" : "81510009",
      "id" : 81510009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Giveaway",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "D",
      "indices" : [ 108, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79241964796641280",
  "text" : "RT @DelReySpectra: #Giveaway: 2 ARCs available for @liahabel's debut, DEARLY, DEPARTED!  RT (and follow) w\/ #D\u2026 (cont) http:\/\/deck.ly\/~F2DEQ",
  "id" : 79241964796641280,
  "created_at" : "2011-06-10 17:42:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Nelson",
      "screen_name" : "Ryan_NelsonSC",
      "indices" : [ 3, 17 ],
      "id_str" : "108764706",
      "id" : 108764706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79192966207512576",
  "text" : "RT @Ryan_NelsonSC: Absolutely love all the brilliant souls in my life. Makes everything a delightful adventure.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78989441468858368",
    "text" : "Absolutely love all the brilliant souls in my life. Makes everything a delightful adventure.",
    "id" : 78989441468858368,
    "created_at" : "2011-06-10 00:58:45 +0000",
    "user" : {
      "name" : "Ryan Nelson",
      "screen_name" : "Ryan_NelsonSC",
      "protected" : false,
      "id_str" : "108764706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576412007227740161\/Ug1dLG5M_normal.jpeg",
      "id" : 108764706,
      "verified" : false
    }
  },
  "id" : 79192966207512576,
  "created_at" : "2011-06-10 14:27:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N. John Shore, Jr.",
      "screen_name" : "johnshore",
      "indices" : [ 18, 28 ],
      "id_str" : "74710075",
      "id" : 74710075
    }, {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 43, 56 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "equality",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "christian",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "ministry",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "love",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79192758228746240",
  "text" : "#FF @Reverend_Sue @johnshore @tragic_pizza @CrystalLewis #LGBT #equality #christian #ministry #love &lt;&lt; showing love to those who show love \u2665",
  "id" : 79192758228746240,
  "created_at" : "2011-06-10 14:26:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Sorenson",
      "screen_name" : "sorensword",
      "indices" : [ 3, 14 ],
      "id_str" : "252595177",
      "id" : 252595177
    }, {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 59, 69 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nook",
      "indices" : [ 85, 90 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79189986259374080",
  "text" : "RT @sorensword: Exciting book coming soon. 9th District by @DougDorow . Next week on #Nook and #Kindle. Check it out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Douglas Dorow",
        "screen_name" : "DougDorow",
        "indices" : [ 43, 53 ],
        "id_str" : "56280847",
        "id" : 56280847
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nook",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79185310176653313",
    "text" : "Exciting book coming soon. 9th District by @DougDorow . Next week on #Nook and #Kindle. Check it out.",
    "id" : 79185310176653313,
    "created_at" : "2011-06-10 13:57:03 +0000",
    "user" : {
      "name" : "Steve Sorenson",
      "screen_name" : "sorensword",
      "protected" : false,
      "id_str" : "252595177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366024936\/Book_Cover_normal.jpg",
      "id" : 252595177,
      "verified" : false
    }
  },
  "id" : 79189986259374080,
  "created_at" : "2011-06-10 14:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79180962348531712",
  "text" : "#FF Ebook authors I follow on Twitter http:\/\/bit.ly\/jtr6lj",
  "id" : 79180962348531712,
  "created_at" : "2011-06-10 13:39:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 42, 55 ],
      "id_str" : "44101564",
      "id" : 44101564
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 71, 82 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 57, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79179362032828416",
  "text" : "all by my wee li'l self? wow ((blush)) RT @Joeandrasi93: #followfriday @moosebegab &lt;!&gt;",
  "id" : 79179362032828416,
  "created_at" : "2011-06-10 13:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79176553153568768",
  "text" : "wondering if souls moult? bcuz I think mine did yesterday. feeling fresher today!",
  "id" : 79176553153568768,
  "created_at" : "2011-06-10 13:22:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79175987157413888",
  "text" : "RT @CharlesBivona: Word RT @svlgurl: Because kindness matters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79175244568477696",
    "text" : "Word RT @svlgurl: Because kindness matters",
    "id" : 79175244568477696,
    "created_at" : "2011-06-10 13:17:03 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 79175987157413888,
  "created_at" : "2011-06-10 13:20:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tricia Cardone",
      "screen_name" : "NHHealthyLiving",
      "indices" : [ 3, 19 ],
      "id_str" : "44509191",
      "id" : 44509191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79175835600433152",
  "text" : "RT @NHHealthyLiving: Forgive all who have offended you, not for them, but for yourself. ~ Harriet Nelson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79173135345266688",
    "text" : "Forgive all who have offended you, not for them, but for yourself. ~ Harriet Nelson",
    "id" : 79173135345266688,
    "created_at" : "2011-06-10 13:08:41 +0000",
    "user" : {
      "name" : "Tricia Cardone",
      "screen_name" : "NHHealthyLiving",
      "protected" : false,
      "id_str" : "44509191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2266670096\/tsewnzkp7w10oac7m6ag_normal.jpeg",
      "id" : 44509191,
      "verified" : false
    }
  },
  "id" : 79175835600433152,
  "created_at" : "2011-06-10 13:19:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79174728635523072",
  "text" : "RT @BrianMerritt: If there is love and freedom no sort of fundamentalism, judgement or exclusion can exist.   Jacques Ellul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79174342142984193",
    "text" : "If there is love and freedom no sort of fundamentalism, judgement or exclusion can exist.   Jacques Ellul",
    "id" : 79174342142984193,
    "created_at" : "2011-06-10 13:13:28 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 79174728635523072,
  "created_at" : "2011-06-10 13:15:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78939350037045248",
  "text" : "RT @petsalive: Financially this has been a terrible month 4 us. Medical costs r through the roof. If any1 can help us we put up a chip-i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/\" rel=\"nofollow\"\u003ETwitBird iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78936241999052800",
    "text" : "Financially this has been a terrible month 4 us. Medical costs r through the roof. If any1 can help us we put up a chip-in at petsalive.com",
    "id" : 78936241999052800,
    "created_at" : "2011-06-09 21:27:21 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 78939350037045248,
  "created_at" : "2011-06-09 21:39:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78938203574382592",
  "text" : "RT @petsalive: Here's the proof. All dogs DO go to Heaven. Guessing this is near the Rainbow Bridge \u2665 http:\/\/lockerz.com\/s\/109183493",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/\" rel=\"nofollow\"\u003ETwitBird iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78930687591317504",
    "text" : "Here's the proof. All dogs DO go to Heaven. Guessing this is near the Rainbow Bridge \u2665 http:\/\/lockerz.com\/s\/109183493",
    "id" : 78930687591317504,
    "created_at" : "2011-06-09 21:05:17 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 78938203574382592,
  "created_at" : "2011-06-09 21:35:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78937402353266688",
  "text" : "@SamsaricWarrior wow...",
  "id" : 78937402353266688,
  "created_at" : "2011-06-09 21:31:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78923272284160001",
  "text" : "ok, yes.. lightning frightens me!",
  "id" : 78923272284160001,
  "created_at" : "2011-06-09 20:35:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78918896773636097",
  "text" : "RT @abe_quotes: ...and not being received by those who are disallowing it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78917797249417216",
    "text" : "...and not being received by those who are disallowing it.",
    "id" : 78917797249417216,
    "created_at" : "2011-06-09 20:14:03 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 78918896773636097,
  "created_at" : "2011-06-09 20:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78918882844344320",
  "text" : "RT @abe_quotes: You just cannot redistribute the wealth of the planet evenly w\/o, in a very short period of time, it gravitating right b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78917716697812992",
    "text" : "You just cannot redistribute the wealth of the planet evenly w\/o, in a very short period of time, it gravitating right back to the allowers.",
    "id" : 78917716697812992,
    "created_at" : "2011-06-09 20:13:44 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 78918882844344320,
  "created_at" : "2011-06-09 20:18:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78918775864434688",
  "text" : "RT @abe_quotes: No one can deprive anyone else of thriving, but no one can *legislate thriving* for others either. You have 2 orchestrat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78918587422748672",
    "text" : "No one can deprive anyone else of thriving, but no one can *legislate thriving* for others either. You have 2 orchestrate your own thriving.",
    "id" : 78918587422748672,
    "created_at" : "2011-06-09 20:17:12 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 78918775864434688,
  "created_at" : "2011-06-09 20:17:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Barb_Calabrese",
      "screen_name" : "Barb_Calabrese",
      "indices" : [ 3, 18 ],
      "id_str" : "26137875",
      "id" : 26137875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78916112523329536",
  "text" : "RT @Barb_Calabrese: Often we don\u2019t realize that the only thing someone is looking for is for someone to listen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78914921852706816",
    "text" : "Often we don\u2019t realize that the only thing someone is looking for is for someone to listen.",
    "id" : 78914921852706816,
    "created_at" : "2011-06-09 20:02:38 +0000",
    "user" : {
      "name" : "@Barb_Calabrese",
      "screen_name" : "Barb_Calabrese",
      "protected" : false,
      "id_str" : "26137875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693088994486161408\/wN4tm7Gy_normal.jpg",
      "id" : 26137875,
      "verified" : false
    }
  },
  "id" : 78916112523329536,
  "created_at" : "2011-06-09 20:07:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/BSPaiKe",
      "expanded_url" : "http:\/\/www.cnn.com\/2011\/US\/06\/09\/alabama.immigration\/index.html?eref=mrss_igoogle_cnn",
      "display_url" : "cnn.com\/2011\/US\/06\/09\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "78906181007048704",
  "text" : "OH FFS! Alabama governor signs tough new immigration law #cnn http:\/\/t.co\/BSPaiKe",
  "id" : 78906181007048704,
  "created_at" : "2011-06-09 19:27:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78890977577799680",
  "geo" : { },
  "id_str" : "78903367782498304",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench snort.. hmm.. yeah, I guess thats what they do : )",
  "id" : 78903367782498304,
  "in_reply_to_status_id" : 78890977577799680,
  "created_at" : "2011-06-09 19:16:43 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78901575417995264",
  "geo" : { },
  "id_str" : "78902421874671616",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 this can easily be translated to all ppl",
  "id" : 78902421874671616,
  "in_reply_to_status_id" : 78901575417995264,
  "created_at" : "2011-06-09 19:12:57 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78901499706617857",
  "text" : "but if they do not see it, its not their fault. &lt;&lt; my lesson",
  "id" : 78901499706617857,
  "created_at" : "2011-06-09 19:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78901021094592512",
  "text" : "i guess i get frustrated at what is plainly in sight for me but others do not see.",
  "id" : 78901021094592512,
  "created_at" : "2011-06-09 19:07:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78900582697537536",
  "text" : "my daughter is amazing! I swear she came from heaven just to help me. the wisdom she spouts...",
  "id" : 78900582697537536,
  "created_at" : "2011-06-09 19:05:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78897041526366208",
  "geo" : { },
  "id_str" : "78898211514884096",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms ive spent time feeling \"guilty\" and all it did was mess me up.",
  "id" : 78898211514884096,
  "in_reply_to_status_id" : 78897041526366208,
  "created_at" : "2011-06-09 18:56:14 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78897595686207490",
  "text" : "@helloinhere potatoes cant read?",
  "id" : 78897595686207490,
  "created_at" : "2011-06-09 18:53:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78897448831041536",
  "text" : "@BibleAlsoSays lol, ok, ok.. point taken! : )",
  "id" : 78897448831041536,
  "created_at" : "2011-06-09 18:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 0, 13 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78895665387798529",
  "geo" : { },
  "id_str" : "78897061008900096",
  "in_reply_to_user_id" : 18306792,
  "text" : "@morsemusings well.. im.. speechless..lol ((blushes)) TY ((hugs))",
  "id" : 78897061008900096,
  "in_reply_to_status_id" : 78895665387798529,
  "created_at" : "2011-06-09 18:51:39 +0000",
  "in_reply_to_screen_name" : "morsemusings",
  "in_reply_to_user_id_str" : "18306792",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78896651997159424",
  "text" : "@BibleAlsoSays but you express yourself very well.. very logically.",
  "id" : 78896651997159424,
  "created_at" : "2011-06-09 18:50:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78893390116298752",
  "text" : "@BibleAlsoSays another observation.. you are highly intelligent. just remember we dont all have the brain cells you got..lol",
  "id" : 78893390116298752,
  "created_at" : "2011-06-09 18:37:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78892830835212288",
  "text" : "@BibleAlsoSays : )",
  "id" : 78892830835212288,
  "created_at" : "2011-06-09 18:34:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Donkey Tornado",
      "screen_name" : "DonkeyJohnson",
      "indices" : [ 15, 29 ],
      "id_str" : "298556408",
      "id" : 298556408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78892746659733504",
  "text" : "@BibleAlsoSays @DonkeyJohnson this was something that gnawed at me as well.. saved from what? a \"sin\" I had no part in?",
  "id" : 78892746659733504,
  "created_at" : "2011-06-09 18:34:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78890003354230785",
  "text" : "@BibleAlsoSays yes & no.. I understand bcuz I get (very) frustrated at what ppl believe (esp ppl I like)",
  "id" : 78890003354230785,
  "created_at" : "2011-06-09 18:23:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78889533277618176",
  "text" : "@BibleAlsoSays I still think you're awesome..lol",
  "id" : 78889533277618176,
  "created_at" : "2011-06-09 18:21:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78889200287625217",
  "text" : "when I was a kid, I wanted to erase my whole past cuz it wasnt \"perfect\".. had major perfection issues going on...",
  "id" : 78889200287625217,
  "created_at" : "2011-06-09 18:20:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 20, 34 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78888401360797696",
  "text" : "just an observation @BibleAlsoSays you seem so angry",
  "id" : 78888401360797696,
  "created_at" : "2011-06-09 18:17:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78887730574147584",
  "text" : "oh @angelaharms you are a doll &lt;3 : )",
  "id" : 78887730574147584,
  "created_at" : "2011-06-09 18:14:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78887468144918528",
  "text" : "maybe im getting ready for a leap? i feel some deep thinking going on...",
  "id" : 78887468144918528,
  "created_at" : "2011-06-09 18:13:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78887343511175169",
  "text" : "what is real or unreal? what is reality? how do you know?",
  "id" : 78887343511175169,
  "created_at" : "2011-06-09 18:13:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78886871974952960",
  "text" : "who needs a therapist.. ive got twitter! ha!",
  "id" : 78886871974952960,
  "created_at" : "2011-06-09 18:11:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78886670392508416",
  "text" : "digging deeper... hmm...",
  "id" : 78886670392508416,
  "created_at" : "2011-06-09 18:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78886173682049024",
  "text" : "i refuse to feel guilty for anything. some ppl think that makes me a psychopath.",
  "id" : 78886173682049024,
  "created_at" : "2011-06-09 18:08:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78885293272473600",
  "text" : "I am moosebegab, hear me ...moose?",
  "id" : 78885293272473600,
  "created_at" : "2011-06-09 18:04:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78873445328371712",
  "geo" : { },
  "id_str" : "78884709681209345",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms possibly, probably. I dunno. just feeling wacky today.",
  "id" : 78884709681209345,
  "in_reply_to_status_id" : 78873445328371712,
  "created_at" : "2011-06-09 18:02:35 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78870989894721537",
  "text" : "trying to ignore icky feeling in my soul today",
  "id" : 78870989894721537,
  "created_at" : "2011-06-09 17:08:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78869288634679296",
  "geo" : { },
  "id_str" : "78870698457710592",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous that sounds good.. heehee",
  "id" : 78870698457710592,
  "in_reply_to_status_id" : 78869288634679296,
  "created_at" : "2011-06-09 17:06:54 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 3, 16 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78852498512818176",
  "text" : "RT @ralphmacchio: http:\/\/bit.ly\/9lscGo Here's shorter link. Enjoy an Anniversary viewing, or 2 or 3! It's the gift that keeps on giving. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78848744984018944",
    "text" : "http:\/\/bit.ly\/9lscGo Here's shorter link. Enjoy an Anniversary viewing, or 2 or 3! It's the gift that keeps on giving. Oh yeah - I'm proud!",
    "id" : 78848744984018944,
    "created_at" : "2011-06-09 15:39:40 +0000",
    "user" : {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "protected" : false,
      "id_str" : "44163738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535851580667346944\/DCmtbKbq_normal.jpeg",
      "id" : 44163738,
      "verified" : true
    }
  },
  "id" : 78852498512818176,
  "created_at" : "2011-06-09 15:54:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78841633155723264",
  "text" : "ive never thought like other ppl. always wondered (and still do, sometimes) am I an alien lost on this planet?",
  "id" : 78841633155723264,
  "created_at" : "2011-06-09 15:11:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78841396169150465",
  "text" : "i dont fit in neatly in any group. im a lil this, a lil that so im my own country.",
  "id" : 78841396169150465,
  "created_at" : "2011-06-09 15:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78841158150787072",
  "text" : "im not good at chit-chat or small talk. its all a one sided conversation (you.)",
  "id" : 78841158150787072,
  "created_at" : "2011-06-09 15:09:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78840872418017281",
  "text" : "this whole be a friend to make friends has never worked for me. you have to be cool to have friends. always been that way. my cool factor=0",
  "id" : 78840872418017281,
  "created_at" : "2011-06-09 15:08:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78834668325179393",
  "text" : "RT @morsemusings: Life is a blink. Don't close your eyes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78834422501220352",
    "text" : "Life is a blink. Don't close your eyes.",
    "id" : 78834422501220352,
    "created_at" : "2011-06-09 14:42:45 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 78834668325179393,
  "created_at" : "2011-06-09 14:43:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78831925921460224",
  "geo" : { },
  "id_str" : "78834551916462080",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench : (",
  "id" : 78834551916462080,
  "in_reply_to_status_id" : 78831925921460224,
  "created_at" : "2011-06-09 14:43:16 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 4, 13 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78831163594125313",
  "text" : "hey @Teawench the kitteh saying anything yet?",
  "id" : 78831163594125313,
  "created_at" : "2011-06-09 14:29:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78830938821378048",
  "text" : "ppl think im crazy cuz I dont believe in rules.. any rules.",
  "id" : 78830938821378048,
  "created_at" : "2011-06-09 14:28:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78830239324717057",
  "geo" : { },
  "id_str" : "78830767454683136",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep politics itself seems so wrong",
  "id" : 78830767454683136,
  "in_reply_to_status_id" : 78830239324717057,
  "created_at" : "2011-06-09 14:28:14 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78830355762790400",
  "text" : "maybe im molting",
  "id" : 78830355762790400,
  "created_at" : "2011-06-09 14:26:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78826572265697280",
  "geo" : { },
  "id_str" : "78829243257200641",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep sin is falling short of the mark. nothing to do with sexual orientation. c'mon world, wake up!",
  "id" : 78829243257200641,
  "in_reply_to_status_id" : 78826572265697280,
  "created_at" : "2011-06-09 14:22:10 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78827397679554560",
  "geo" : { },
  "id_str" : "78828583769997312",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench *whip* *whip*",
  "id" : 78828583769997312,
  "in_reply_to_status_id" : 78827397679554560,
  "created_at" : "2011-06-09 14:19:33 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78822639031947264",
  "text" : "i am not very useful in this physical world",
  "id" : 78822639031947264,
  "created_at" : "2011-06-09 13:55:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78819821462097920",
  "text" : "RT @gemswinc: Good day to all!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78819710371758080",
    "text" : "Good day to all!",
    "id" : 78819710371758080,
    "created_at" : "2011-06-09 13:44:18 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 78819821462097920,
  "created_at" : "2011-06-09 13:44:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katja Rinne",
      "screen_name" : "katjarinne",
      "indices" : [ 3, 14 ],
      "id_str" : "183159761",
      "id" : 183159761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfpublishing",
      "indices" : [ 99, 114 ]
    }, {
      "text" : "amwriting",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78635277748408320",
  "text" : "RT @katjarinne: Indies: Want to be part of a HUGE eBook giveaway? http:\/\/goo.gl\/mqO6x for details. #selfpublishing #amwriting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfpublishing",
        "indices" : [ 83, 98 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78627106954805248",
    "text" : "Indies: Want to be part of a HUGE eBook giveaway? http:\/\/goo.gl\/mqO6x for details. #selfpublishing #amwriting",
    "id" : 78627106954805248,
    "created_at" : "2011-06-09 00:58:57 +0000",
    "user" : {
      "name" : "Katja Rinne",
      "screen_name" : "katjarinne",
      "protected" : false,
      "id_str" : "183159761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662257042636341248\/A7kJeycJ_normal.jpg",
      "id" : 183159761,
      "verified" : false
    }
  },
  "id" : 78635277748408320,
  "created_at" : "2011-06-09 01:31:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78626805862506497",
  "geo" : { },
  "id_str" : "78629550896070658",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench wow - hope kitty is ok.",
  "id" : 78629550896070658,
  "in_reply_to_status_id" : 78626805862506497,
  "created_at" : "2011-06-09 01:08:40 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78571319301652480",
  "geo" : { },
  "id_str" : "78572292124319744",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell well, that's a doozie..lol",
  "id" : 78572292124319744,
  "in_reply_to_status_id" : 78571319301652480,
  "created_at" : "2011-06-08 21:21:08 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 3, 12 ],
      "id_str" : "14986977",
      "id" : 14986977
    }, {
      "name" : "MPR News",
      "screen_name" : "MPRnews",
      "indices" : [ 44, 52 ],
      "id_str" : "15965292",
      "id" : 15965292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78522986411458560",
  "text" : "RT @Teawench: This really pisses me off. RT @MPRnews Wolf shot and killed after escaping at Minnesota Zoo. http:\/\/mprne.ws\/5dfSg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MPR News",
        "screen_name" : "MPRnews",
        "indices" : [ 30, 38 ],
        "id_str" : "15965292",
        "id" : 15965292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78522219147431937",
    "text" : "This really pisses me off. RT @MPRnews Wolf shot and killed after escaping at Minnesota Zoo. http:\/\/mprne.ws\/5dfSg",
    "id" : 78522219147431937,
    "created_at" : "2011-06-08 18:02:10 +0000",
    "user" : {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "protected" : false,
      "id_str" : "14986977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2242418648\/lanoire_blond_256x256_normal.jpg",
      "id" : 14986977,
      "verified" : false
    }
  },
  "id" : 78522986411458560,
  "created_at" : "2011-06-08 18:05:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78478500302041088",
  "text" : "@ReformedBuddha hmm.. i think my brain exploded.. so.. weird",
  "id" : 78478500302041088,
  "created_at" : "2011-06-08 15:08:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78471125675425792",
  "text" : "You Will Follow Me http:\/\/bit.ly\/jV7fVp",
  "id" : 78471125675425792,
  "created_at" : "2011-06-08 14:39:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 32, 38 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "nook",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "ereader",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78465339691769856",
  "text" : "RT @byoung210: Post-apocalyptic #scifi tale-Copy Bird is FREE on Smashwords. Enjoy on your #Kindle #nook or favorite #ereader. http:\/\/j. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scifi",
        "indices" : [ 17, 23 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "nook",
        "indices" : [ 84, 89 ]
      }, {
        "text" : "ereader",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "pubwrite",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78463518969573376",
    "text" : "Post-apocalyptic #scifi tale-Copy Bird is FREE on Smashwords. Enjoy on your #Kindle #nook or favorite #ereader. http:\/\/j.mp\/mzI4XH #pubwrite",
    "id" : 78463518969573376,
    "created_at" : "2011-06-08 14:08:55 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 78465339691769856,
  "created_at" : "2011-06-08 14:16:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 0, 14 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78457509140103168",
  "geo" : { },
  "id_str" : "78458020547399680",
  "in_reply_to_user_id" : 19251068,
  "text" : "@JacksonPearce fear of being late for something important or missing it altogether",
  "id" : 78458020547399680,
  "in_reply_to_status_id" : 78457509140103168,
  "created_at" : "2011-06-08 13:47:04 +0000",
  "in_reply_to_screen_name" : "JacksonPearce",
  "in_reply_to_user_id_str" : "19251068",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Beth Nelson",
      "screen_name" : "northernmagic",
      "indices" : [ 9, 23 ],
      "id_str" : "2556861443",
      "id" : 2556861443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78456887116443648",
  "text" : "LOLOL RT @NorthernMagic: My favourite position is doggy-style when I'm reading a really good book.",
  "id" : 78456887116443648,
  "created_at" : "2011-06-08 13:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78450432787222528",
  "text" : "i get so excited when i get ideas!",
  "id" : 78450432787222528,
  "created_at" : "2011-06-08 13:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78437057311162368",
  "text" : "so joyful for my well-being. no stomach or head problems for over 2 months.",
  "id" : 78437057311162368,
  "created_at" : "2011-06-08 12:23:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78430657952489472",
  "text" : "omg there's a karate show on disney...",
  "id" : 78430657952489472,
  "created_at" : "2011-06-08 11:58:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dstips",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "Directsales",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78430487982505984",
  "text" : "RT @lisarobbinyoung: Get Direct Sales Classroom's weekly tips delivered to your Kindle: http:\/\/amzn.to\/jMbCWD #dstips #Directsales",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dstips",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "Directsales",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78430073950183424",
    "text" : "Get Direct Sales Classroom's weekly tips delivered to your Kindle: http:\/\/amzn.to\/jMbCWD #dstips #Directsales",
    "id" : 78430073950183424,
    "created_at" : "2011-06-08 11:56:01 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 78430487982505984,
  "created_at" : "2011-06-08 11:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78429768915226624",
  "text" : "@tragic_pizza lol good morning my fave curmudgeon!",
  "id" : 78429768915226624,
  "created_at" : "2011-06-08 11:54:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78421936685858816",
  "text" : "i successfully got child on bus this am..lol",
  "id" : 78421936685858816,
  "created_at" : "2011-06-08 11:23:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 0, 10 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78256170128781312",
  "geo" : { },
  "id_str" : "78257023900323840",
  "in_reply_to_user_id" : 15572724,
  "text" : "@ShhDragon what chipmunk? I see no chipmunk! I still love Saki! smooches",
  "id" : 78257023900323840,
  "in_reply_to_status_id" : 78256170128781312,
  "created_at" : "2011-06-08 00:28:23 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 41, 49 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78251700196089856",
  "geo" : { },
  "id_str" : "78253413732851712",
  "in_reply_to_user_id" : 54744689,
  "text" : "im glad you get a break from it ((hugs)) @SangyeH",
  "id" : 78253413732851712,
  "in_reply_to_status_id" : 78251700196089856,
  "created_at" : "2011-06-08 00:14:02 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78230823769346048",
  "text" : "RT @JohnCali: There isn't anything in the world that feels better to a teacher than to empower another. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78230640985776128",
    "text" : "There isn't anything in the world that feels better to a teacher than to empower another. ~ Abraham",
    "id" : 78230640985776128,
    "created_at" : "2011-06-07 22:43:32 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 78230823769346048,
  "created_at" : "2011-06-07 22:44:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CJ West",
      "screen_name" : "cjwest",
      "indices" : [ 3, 10 ],
      "id_str" : "14947233",
      "id" : 14947233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebook",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "kindle",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "nook",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78230566553653249",
  "text" : "RT @cjwest: FREE  #ebook #kindle #nook from www.22wb.com   The End of Marking Time.  It's \"1984 meets Prison Break\"  Please RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebook",
        "indices" : [ 6, 12 ]
      }, {
        "text" : "kindle",
        "indices" : [ 13, 20 ]
      }, {
        "text" : "nook",
        "indices" : [ 21, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78229727743184897",
    "text" : "FREE  #ebook #kindle #nook from www.22wb.com   The End of Marking Time.  It's \"1984 meets Prison Break\"  Please RT",
    "id" : 78229727743184897,
    "created_at" : "2011-06-07 22:39:55 +0000",
    "user" : {
      "name" : "CJ West",
      "screen_name" : "cjwest",
      "protected" : false,
      "id_str" : "14947233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1477792288\/cjwest-bcon2010_normal.jpg",
      "id" : 14947233,
      "verified" : false
    }
  },
  "id" : 78230566553653249,
  "created_at" : "2011-06-07 22:43:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleINDIEpendence",
      "indices" : [ 33, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78228277591932928",
  "text" : "Want a Free Kindle?! Sign up for #KindleINDIEpendence Day! http:\/\/bit.ly\/m5SmKm",
  "id" : 78228277591932928,
  "created_at" : "2011-06-07 22:34:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 60, 73 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78213163300044800",
  "text" : "but I dont want to.. why cant I just stay dead, darn it! RT @DeepakChopra: Everything recycles",
  "id" : 78213163300044800,
  "created_at" : "2011-06-07 21:34:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Brown",
      "screen_name" : "drgwbrown",
      "indices" : [ 3, 13 ],
      "id_str" : "27631587",
      "id" : 27631587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78212299969667074",
  "text" : "RT @drgwbrown: The \"bad economy\" of one of the world's wealthiest societies is used to justify denial of services & attacks on workers,  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78202370806382594",
    "text" : "The \"bad economy\" of one of the world's wealthiest societies is used to justify denial of services & attacks on workers, but not to end war.",
    "id" : 78202370806382594,
    "created_at" : "2011-06-07 20:51:12 +0000",
    "user" : {
      "name" : "Greg Brown",
      "screen_name" : "drgwbrown",
      "protected" : false,
      "id_str" : "27631587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562027112144457728\/YzDzWBIb_normal.jpeg",
      "id" : 27631587,
      "verified" : false
    }
  },
  "id" : 78212299969667074,
  "created_at" : "2011-06-07 21:30:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78189774648770561",
  "text" : "RT @UnseeingEyes: Jun 7, 1954...Despondent over court-ordered estrogen treatments to cure his homosexuality, Alan Turing commits (cont)  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78187465378250752",
    "text" : "Jun 7, 1954...Despondent over court-ordered estrogen treatments to cure his homosexuality, Alan Turing commits (cont) http:\/\/tl.gd\/avcekt",
    "id" : 78187465378250752,
    "created_at" : "2011-06-07 19:51:59 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 78189774648770561,
  "created_at" : "2011-06-07 20:01:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kunzang Drolma",
      "screen_name" : "helpsavelives",
      "indices" : [ 0, 14 ],
      "id_str" : "80181824",
      "id" : 80181824
    }, {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 15, 23 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78179167547568128",
  "geo" : { },
  "id_str" : "78185271006478336",
  "in_reply_to_user_id" : 80181824,
  "text" : "@helpsavelives @SangyeH I knew better than to look : (",
  "id" : 78185271006478336,
  "in_reply_to_status_id" : 78179167547568128,
  "created_at" : "2011-06-07 19:43:15 +0000",
  "in_reply_to_screen_name" : "helpsavelives",
  "in_reply_to_user_id_str" : "80181824",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78165282669080576",
  "geo" : { },
  "id_str" : "78167277714939904",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem i am infp. nice to meet you, intj! lol",
  "id" : 78167277714939904,
  "in_reply_to_status_id" : 78165282669080576,
  "created_at" : "2011-06-07 18:31:45 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78161554536800257",
  "text" : "so many nice ppl in my stream. makes me smile.",
  "id" : 78161554536800257,
  "created_at" : "2011-06-07 18:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78159606219685888",
  "geo" : { },
  "id_str" : "78161208066322432",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles no reason.. just observation : )",
  "id" : 78161208066322432,
  "in_reply_to_status_id" : 78159606219685888,
  "created_at" : "2011-06-07 18:07:38 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78155112224268288",
  "geo" : { },
  "id_str" : "78155946316148737",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books : )",
  "id" : 78155946316148737,
  "in_reply_to_status_id" : 78155112224268288,
  "created_at" : "2011-06-07 17:46:44 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78154519711715329",
  "text" : "I am very blessed. life is good.",
  "id" : 78154519711715329,
  "created_at" : "2011-06-07 17:41:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78154094044397568",
  "text" : "@SamsaricWarrior its hard when they insist their way is only way (ack!) but I believe Im there for a reason so.. lol",
  "id" : 78154094044397568,
  "created_at" : "2011-06-07 17:39:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78152607209766913",
  "text" : "@SamsaricWarrior I was praying for patience and you popped in my head. thinking of how you saw the mean guy as opportunity to practice",
  "id" : 78152607209766913,
  "created_at" : "2011-06-07 17:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78152216002822146",
  "text" : "@SamsaricWarrior its hard to hear things ppl believe that make me cringe. but its not \"all about me\".. everyone has their own path",
  "id" : 78152216002822146,
  "created_at" : "2011-06-07 17:31:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78150737967845377",
  "text" : "all good..lol @SamsaricWarrior practicing what I \"preach\" so to speak",
  "id" : 78150737967845377,
  "created_at" : "2011-06-07 17:26:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Shakirah Dawud",
      "screen_name" : "ShakirahDawud",
      "indices" : [ 3, 17 ],
      "id_str" : "59802772",
      "id" : 59802772
    }, {
      "name" : "Bethanne Patrick",
      "screen_name" : "TheBookMaven",
      "indices" : [ 27, 40 ],
      "id_str" : "15779877",
      "id" : 15779877
    }, {
      "name" : "Sarah Weinman",
      "screen_name" : "sarahw",
      "indices" : [ 131, 138 ],
      "id_str" : "286703",
      "id" : 286703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78142866970521600",
  "text" : "RT @ShakirahDawud: Wow! RT @thebookmaven: Someone, somewhere must be able to rescue these 350,000 books: http:\/\/bit.ly\/jgiUnf (via @sarahw)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bethanne Patrick",
        "screen_name" : "TheBookMaven",
        "indices" : [ 8, 21 ],
        "id_str" : "15779877",
        "id" : 15779877
      }, {
        "name" : "Sarah Weinman",
        "screen_name" : "sarahw",
        "indices" : [ 112, 119 ],
        "id_str" : "286703",
        "id" : 286703
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78085823173623808",
    "text" : "Wow! RT @thebookmaven: Someone, somewhere must be able to rescue these 350,000 books: http:\/\/bit.ly\/jgiUnf (via @sarahw)",
    "id" : 78085823173623808,
    "created_at" : "2011-06-07 13:08:05 +0000",
    "user" : {
      "name" : "T. Shakirah Dawud",
      "screen_name" : "ShakirahDawud",
      "protected" : false,
      "id_str" : "59802772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1909448382\/twitterSD_normal.gif",
      "id" : 59802772,
      "verified" : false
    }
  },
  "id" : 78142866970521600,
  "created_at" : "2011-06-07 16:54:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78142046149427200",
  "text" : "hey @SamsaricWarrior I thought of you today during bible study.",
  "id" : 78142046149427200,
  "created_at" : "2011-06-07 16:51:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78085181348651009",
  "text" : "RT @RichardMabry: Interview with debut novelist Yvonne Anderson today on my blog, with a chance to win a signed copy of her novel. http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78084689067384833",
    "text" : "Interview with debut novelist Yvonne Anderson today on my blog, with a chance to win a signed copy of her novel. http:\/\/bit.ly\/k6YRgB",
    "id" : 78084689067384833,
    "created_at" : "2011-06-07 13:03:35 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 78085181348651009,
  "created_at" : "2011-06-07 13:05:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78083748691845120",
  "text" : "going to bible study in a bit with my other mommy. we are working thru 1 john 2. just a few more sessions left then done for summer.",
  "id" : 78083748691845120,
  "created_at" : "2011-06-07 12:59:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eura Reddrick",
      "screen_name" : "iTweetFacts",
      "indices" : [ 3, 15 ],
      "id_str" : "3198495413",
      "id" : 3198495413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78077171549220864",
  "text" : "RT @iTweetFacts: We may believe in different things, view  differently, live in different places but we all have 1 thing in common = TWI ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78073789249880064",
    "text" : "We may believe in different things, view  differently, live in different places but we all have 1 thing in common = TWITTER.",
    "id" : 78073789249880064,
    "created_at" : "2011-06-07 12:20:16 +0000",
    "user" : {
      "name" : "r.h. Sin",
      "screen_name" : "byRHSin",
      "protected" : false,
      "id_str" : "109970442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796238037617352705\/Kmk57vgV_normal.jpg",
      "id" : 109970442,
      "verified" : false
    }
  },
  "id" : 78077171549220864,
  "created_at" : "2011-06-07 12:33:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77884382618189825",
  "text" : "RT @ReadersWin: BookRooster.com http:\/\/bit.ly\/jMDAUc a community of passionate readers who receive free copie\u2026 (cont) http:\/\/deck.ly\/~1rkM9",
  "id" : 77884382618189825,
  "created_at" : "2011-06-06 23:47:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77882711150305280",
  "text" : "My Tumblr, All Dogs Go To Heaven http:\/\/bit.ly\/iDvrw4",
  "id" : 77882711150305280,
  "created_at" : "2011-06-06 23:40:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77868036698275840",
  "geo" : { },
  "id_str" : "77868826338918401",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous yay! congrats! : )",
  "id" : 77868826338918401,
  "in_reply_to_status_id" : 77868036698275840,
  "created_at" : "2011-06-06 22:45:49 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77787358975631360",
  "text" : "@SamsaricWarrior you're such a nut! : )",
  "id" : 77787358975631360,
  "created_at" : "2011-06-06 17:22:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77786999259533312",
  "text" : "RT @derekrootboy: Lives subject to constant monitoring will be driven to the edge of insanity. And beyond. Footballers, politicians have ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77780908278681600",
    "text" : "Lives subject to constant monitoring will be driven to the edge of insanity. And beyond. Footballers, politicians have right to private life",
    "id" : 77780908278681600,
    "created_at" : "2011-06-06 16:56:28 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 77786999259533312,
  "created_at" : "2011-06-06 17:20:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77786970289475585",
  "text" : "RT @derekrootboy: Consensual sex between adults is a matter for those concerned. If one or both party is betraying a lover, that's a mat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77781365558484992",
    "text" : "Consensual sex between adults is a matter for those concerned. If one or both party is betraying a lover, that's a matter for them alone.",
    "id" : 77781365558484992,
    "created_at" : "2011-06-06 16:58:17 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 77786970289475585,
  "created_at" : "2011-06-06 17:20:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77786340049170433",
  "text" : "@SamsaricWarrior LOL.. go ahead, make their day! ; )",
  "id" : 77786340049170433,
  "created_at" : "2011-06-06 17:18:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77786074029621249",
  "text" : "my mommy's leaving signs..hehe.",
  "id" : 77786074029621249,
  "created_at" : "2011-06-06 17:16:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motivational Quotes",
      "screen_name" : "DavidRoads",
      "indices" : [ 3, 14 ],
      "id_str" : "114685387",
      "id" : 114685387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77780631978901504",
  "text" : "RT @DavidRoads: No act of kindness, no matter how small, is ever wasted. -Aesop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77779464808960000",
    "text" : "No act of kindness, no matter how small, is ever wasted. -Aesop",
    "id" : 77779464808960000,
    "created_at" : "2011-06-06 16:50:44 +0000",
    "user" : {
      "name" : "Motivational Quotes",
      "screen_name" : "DavidRoads",
      "protected" : false,
      "id_str" : "114685387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721216106984292353\/gwWrwwY-_normal.jpg",
      "id" : 114685387,
      "verified" : false
    }
  },
  "id" : 77780631978901504,
  "created_at" : "2011-06-06 16:55:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "indices" : [ 3, 17 ],
      "id_str" : "26642006",
      "id" : 26642006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77770336057303040",
  "text" : "RT @Alyssa_Milano: This is a landmark moment: United Nations report says Internet access is a human right\u261B http:\/\/j.mp\/jv4KrW \/via @brai ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Popova",
        "screen_name" : "brainpicker",
        "indices" : [ 112, 124 ],
        "id_str" : "9207632",
        "id" : 9207632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77768718284881920",
    "text" : "This is a landmark moment: United Nations report says Internet access is a human right\u261B http:\/\/j.mp\/jv4KrW \/via @brainpicker",
    "id" : 77768718284881920,
    "created_at" : "2011-06-06 16:08:01 +0000",
    "user" : {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "protected" : false,
      "id_str" : "26642006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797077615064457217\/mSJCnze-_normal.jpg",
      "id" : 26642006,
      "verified" : true
    }
  },
  "id" : 77770336057303040,
  "created_at" : "2011-06-06 16:14:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 9, 24 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77753641561366528",
  "text" : "LOLOL RT @ReformedBuddha: All dogs go to heavan http:\/\/www.picselate.com\/wp-content\/uploads\/2010\/06\/alldogsgotoheaven-e1276285992777.jpg",
  "id" : 77753641561366528,
  "created_at" : "2011-06-06 15:08:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HarlequinTEEN",
      "screen_name" : "HarlequinTEEN",
      "indices" : [ 3, 17 ],
      "id_str" : "55277626",
      "id" : 55277626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77740275161763840",
  "text" : "RT @HarlequinTeen: Promising YA novels featured at book expo http:\/\/www.poughkeepsiejournal.com\/article\/201106\u2026 (cont) http:\/\/deck.ly\/~0fKL9",
  "id" : 77740275161763840,
  "created_at" : "2011-06-06 14:15:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hatecrime",
      "indices" : [ 109, 119 ]
    }, {
      "text" : "justice",
      "indices" : [ 120, 128 ]
    }, {
      "text" : "Muslim",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77523266125836289",
  "text" : "RT @Reverend_Sue: A victim of 9\/11 hate crime now fights for his attacker's life http:\/\/on.msnbc.com\/lrHzP6  #hatecrime #justice #Muslim ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hatecrime",
        "indices" : [ 91, 101 ]
      }, {
        "text" : "justice",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "Muslim",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "Islam",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "forgiveness",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77522167419518977",
    "text" : "A victim of 9\/11 hate crime now fights for his attacker's life http:\/\/on.msnbc.com\/lrHzP6  #hatecrime #justice #Muslim #Islam #forgiveness",
    "id" : 77522167419518977,
    "created_at" : "2011-06-05 23:48:19 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 77523266125836289,
  "created_at" : "2011-06-05 23:52:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77522915796594688",
  "text" : "I need to stop looking at books!! at least, until I find a way to pay for my reading habit..lol.. so many great stories to be discovered!",
  "id" : 77522915796594688,
  "created_at" : "2011-06-05 23:51:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77521185113522176",
  "geo" : { },
  "id_str" : "77522011013914624",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow that is wonderful!",
  "id" : 77522011013914624,
  "in_reply_to_status_id" : 77521185113522176,
  "created_at" : "2011-06-05 23:47:42 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "philosophy",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77511041021509632",
  "text" : "RT @derekrootboy: If everyone on Twitter agrees to put our heads together asap we can knock ourselves unconscious. #philosophy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "philosophy",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77510854458867712",
    "text" : "If everyone on Twitter agrees to put our heads together asap we can knock ourselves unconscious. #philosophy",
    "id" : 77510854458867712,
    "created_at" : "2011-06-05 23:03:22 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 77511041021509632,
  "created_at" : "2011-06-05 23:04:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77509156709474304",
  "geo" : { },
  "id_str" : "77510374424981505",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld lol ((hugs))",
  "id" : 77510374424981505,
  "in_reply_to_status_id" : 77509156709474304,
  "created_at" : "2011-06-05 23:01:27 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77510084942508033",
  "text" : "RT @Buddhaworld: life it not to be taken to serious, it gives it otherwise more attencion as it deserves.buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77509555097059328",
    "text" : "life it not to be taken to serious, it gives it otherwise more attencion as it deserves.buddha volko.",
    "id" : 77509555097059328,
    "created_at" : "2011-06-05 22:58:12 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 77510084942508033,
  "created_at" : "2011-06-05 23:00:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77508411541032960",
  "in_reply_to_user_id" : 40560386,
  "text" : "@buddhaworld always appreciate seeing your tweets in my stream : )",
  "id" : 77508411541032960,
  "created_at" : "2011-06-05 22:53:40 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77507837823172609",
  "geo" : { },
  "id_str" : "77508037446868993",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld ahh I see..",
  "id" : 77508037446868993,
  "in_reply_to_status_id" : 77507837823172609,
  "created_at" : "2011-06-05 22:52:10 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77506175498854400",
  "geo" : { },
  "id_str" : "77507201211699200",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld why bad if \"where am I\"?",
  "id" : 77507201211699200,
  "in_reply_to_status_id" : 77506175498854400,
  "created_at" : "2011-06-05 22:48:51 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77503738964742144",
  "geo" : { },
  "id_str" : "77504626097795074",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy hmm.. now that would be interesting!",
  "id" : 77504626097795074,
  "in_reply_to_status_id" : 77503738964742144,
  "created_at" : "2011-06-05 22:38:37 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77504107186888704",
  "geo" : { },
  "id_str" : "77504358153076736",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld who am I?",
  "id" : 77504358153076736,
  "in_reply_to_status_id" : 77504107186888704,
  "created_at" : "2011-06-05 22:37:33 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77477109722910720",
  "text" : "back from getting ice cream",
  "id" : 77477109722910720,
  "created_at" : "2011-06-05 20:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77476475518980096",
  "text" : "@SamsaricWarrior Im glad cuz I like it (and I can remember it..lol)",
  "id" : 77476475518980096,
  "created_at" : "2011-06-05 20:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Photography",
      "screen_name" : "Wildlife_Photo",
      "indices" : [ 3, 18 ],
      "id_str" : "68092194",
      "id" : 68092194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WildlifePhoto",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77408278455390208",
  "text" : "RT @Wildlife_Photo: backyard critter watch - Does this fawn look OK to you?: http:\/\/bit.ly\/jn8xgk #WildlifePhoto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildlife-photography-blog.com\" rel=\"nofollow\"\u003EWildlife Photography Blog\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WildlifePhoto",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77407387950133250",
    "text" : "backyard critter watch - Does this fawn look OK to you?: http:\/\/bit.ly\/jn8xgk #WildlifePhoto",
    "id" : 77407387950133250,
    "created_at" : "2011-06-05 16:12:14 +0000",
    "user" : {
      "name" : "Wildlife Photography",
      "screen_name" : "Wildlife_Photo",
      "protected" : false,
      "id_str" : "68092194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378006206\/logo3_normal.png",
      "id" : 68092194,
      "verified" : false
    }
  },
  "id" : 77408278455390208,
  "created_at" : "2011-06-05 16:15:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77405640154284032",
  "text" : "@SamsaricWarrior hey you changed your name back!",
  "id" : 77405640154284032,
  "created_at" : "2011-06-05 16:05:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Unruh",
      "screen_name" : "WesUnruh",
      "indices" : [ 3, 12 ],
      "id_str" : "19741048",
      "id" : 19741048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77397335562403840",
  "text" : "RT @wesunruh: it's all going to be okay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77396391810441216",
    "text" : "it's all going to be okay",
    "id" : 77396391810441216,
    "created_at" : "2011-06-05 15:28:32 +0000",
    "user" : {
      "name" : "Wes Unruh",
      "screen_name" : "WesUnruh",
      "protected" : false,
      "id_str" : "19741048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797634772268969988\/VowWxnrw_normal.jpg",
      "id" : 19741048,
      "verified" : true
    }
  },
  "id" : 77397335562403840,
  "created_at" : "2011-06-05 15:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 27, 37 ],
      "id_str" : "82447359",
      "id" : 82447359
    }, {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 42, 55 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77397222039355392",
  "text" : "Am I weird cuz I like both @scottbaio AND @ralphmacchio ? LOL (well, I am a pisces...)",
  "id" : 77397222039355392,
  "created_at" : "2011-06-05 15:31:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Whitelaw",
      "screen_name" : "lifecruise",
      "indices" : [ 3, 14 ],
      "id_str" : "16594778",
      "id" : 16594778
    }, {
      "name" : "Couurttnneeyy3",
      "screen_name" : "lillyann",
      "indices" : [ 19, 28 ],
      "id_str" : "1280832942",
      "id" : 1280832942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77395506057314304",
  "text" : "RT @lifecruise: RT @LillyAnn: You learn what to do next by paying close attention to what you are drawn to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Couurttnneeyy3",
        "screen_name" : "lillyann",
        "indices" : [ 3, 12 ],
        "id_str" : "1280832942",
        "id" : 1280832942
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77366251852275712",
    "text" : "RT @LillyAnn: You learn what to do next by paying close attention to what you are drawn to.",
    "id" : 77366251852275712,
    "created_at" : "2011-06-05 13:28:46 +0000",
    "user" : {
      "name" : "Scott Whitelaw",
      "screen_name" : "lifecruise",
      "protected" : false,
      "id_str" : "16594778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1950171633\/Scott_Small_Book_Photo_normal.jpg",
      "id" : 16594778,
      "verified" : false
    }
  },
  "id" : 77395506057314304,
  "created_at" : "2011-06-05 15:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JimNichols",
      "screen_name" : "JimNichols",
      "indices" : [ 3, 14 ],
      "id_str" : "14199707",
      "id" : 14199707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77393018155569152",
  "text" : "RT @JimNichols: We have systemic politics--two massive bureaucratic parties financially backed by big money fighting it out in Public Re ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77392435734523904",
    "text" : "We have systemic politics--two massive bureaucratic parties financially backed by big money fighting it out in Public Relations campaigns",
    "id" : 77392435734523904,
    "created_at" : "2011-06-05 15:12:49 +0000",
    "user" : {
      "name" : "JimNichols",
      "screen_name" : "JimNichols",
      "protected" : false,
      "id_str" : "14199707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638827379641573377\/xw-QPJBU_normal.jpg",
      "id" : 14199707,
      "verified" : false
    }
  },
  "id" : 77393018155569152,
  "created_at" : "2011-06-05 15:15:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77392068644831232",
  "text" : "Readers Win, Controversial WSJ article on YA fiction content http:\/\/bit.ly\/lgNCHZ",
  "id" : 77392068644831232,
  "created_at" : "2011-06-05 15:11:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77387449789202432",
  "text" : "all ya books should be about little lambs romping through the meadow ; )",
  "id" : 77387449789202432,
  "created_at" : "2011-06-05 14:53:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77379108794925056",
  "text" : "its all in the way you see the glass",
  "id" : 77379108794925056,
  "created_at" : "2011-06-05 14:19:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Garan",
      "screen_name" : "Astro_Ron",
      "indices" : [ 3, 13 ],
      "id_str" : "82453323",
      "id" : 82453323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FromSpace",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77372610995945473",
  "text" : "RT @Astro_Ron: Because I'm the only person on Twitter presently in Space I will answer your questions today 8:30-9:15pm GMT #FromSpace P ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FromSpace",
        "indices" : [ 109, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77284217586843648",
    "text" : "Because I'm the only person on Twitter presently in Space I will answer your questions today 8:30-9:15pm GMT #FromSpace Plz spread the word",
    "id" : 77284217586843648,
    "created_at" : "2011-06-05 08:02:48 +0000",
    "user" : {
      "name" : "Ron Garan",
      "screen_name" : "Astro_Ron",
      "protected" : false,
      "id_str" : "82453323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472830575\/Ron-cropped_normal.jpg",
      "id" : 82453323,
      "verified" : true
    }
  },
  "id" : 77372610995945473,
  "created_at" : "2011-06-05 13:54:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Rees Brennan",
      "screen_name" : "sarahreesbrenna",
      "indices" : [ 3, 19 ],
      "id_str" : "20950137",
      "id" : 20950137
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 45, 49 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77372249333702657",
  "text" : "RT @sarahreesbrenna: I am late to the latest @WSJ brouhaha about the Naughty YA Books Corrupting Our Kids. Yes, it's those avid readers  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 24, 28 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YAsaves",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77356612452491265",
    "text" : "I am late to the latest @WSJ brouhaha about the Naughty YA Books Corrupting Our Kids. Yes, it's those avid readers who are trouble. #YAsaves",
    "id" : 77356612452491265,
    "created_at" : "2011-06-05 12:50:28 +0000",
    "user" : {
      "name" : "Sarah Rees Brennan",
      "screen_name" : "sarahreesbrenna",
      "protected" : false,
      "id_str" : "20950137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716372577506213888\/s19kkC7P_normal.jpg",
      "id" : 20950137,
      "verified" : false
    }
  },
  "id" : 77372249333702657,
  "created_at" : "2011-06-05 13:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77371717340762112",
  "text" : "my DD just said Im immature..heehee",
  "id" : 77371717340762112,
  "created_at" : "2011-06-05 13:50:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77189268233129984",
  "text" : "perception! http:\/\/amzn.com\/k\/2G5H6O1M2U8XW #Kindle",
  "id" : 77189268233129984,
  "created_at" : "2011-06-05 01:45:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77143459558985731",
  "text" : "@Anti_Fa1994 ewwww, what? not seeing what you're replying to..lol",
  "id" : 77143459558985731,
  "created_at" : "2011-06-04 22:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77135570593255424",
  "text" : "I want ice cream cake",
  "id" : 77135570593255424,
  "created_at" : "2011-06-04 22:12:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77109190237224961",
  "text" : "RT @CoyoteSings: I can get to know some of you better, in these little boxes, than I could if you were standing right *here*.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77108742453346304",
    "text" : "I can get to know some of you better, in these little boxes, than I could if you were standing right *here*.",
    "id" : 77108742453346304,
    "created_at" : "2011-06-04 20:25:31 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 77109190237224961,
  "created_at" : "2011-06-04 20:27:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77106215490035712",
  "text" : "RT @derekrootboy: \"Trust me. I'm The Dentist.\" That's my new catchphrase. So what do you think?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77104466805006336",
    "text" : "\"Trust me. I'm The Dentist.\" That's my new catchphrase. So what do you think?",
    "id" : 77104466805006336,
    "created_at" : "2011-06-04 20:08:32 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 77106215490035712,
  "created_at" : "2011-06-04 20:15:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77095900429815808",
  "geo" : { },
  "id_str" : "77097692592996352",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ewww... and ouch!",
  "id" : 77097692592996352,
  "in_reply_to_status_id" : 77095900429815808,
  "created_at" : "2011-06-04 19:41:36 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77063379243630593",
  "text" : "RT @fearfuldogs: ppl suffering from PTSD have enlarged amygdalas which r more metabolically active cld b true 4 dogs suffering trauma 2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77060939207282688",
    "text" : "ppl suffering from PTSD have enlarged amygdalas which r more metabolically active cld b true 4 dogs suffering trauma 2",
    "id" : 77060939207282688,
    "created_at" : "2011-06-04 17:15:34 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 77063379243630593,
  "created_at" : "2011-06-04 17:25:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77050875947909120",
  "text" : "RT @namenick: Useful tips on ebooks and e-readers + fun stuff - http:\/\/ow.ly\/4Gvlm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77049663554977793",
    "text" : "Useful tips on ebooks and e-readers + fun stuff - http:\/\/ow.ly\/4Gvlm",
    "id" : 77049663554977793,
    "created_at" : "2011-06-04 16:30:45 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 77050875947909120,
  "created_at" : "2011-06-04 16:35:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77050732783747072",
  "text" : "RT @MWM4444: Don't tell ME how I'm supposed to dress or act. Tell HIM not to rape me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77049948214001665",
    "text" : "Don't tell ME how I'm supposed to dress or act. Tell HIM not to rape me.",
    "id" : 77049948214001665,
    "created_at" : "2011-06-04 16:31:53 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 77050732783747072,
  "created_at" : "2011-06-04 16:35:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77022859368734721",
  "text" : "2nd cup o' coffee is better.. cuz hubby made it",
  "id" : 77022859368734721,
  "created_at" : "2011-06-04 14:44:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "indices" : [ 3, 18 ],
      "id_str" : "29574025",
      "id" : 29574025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77022120667910144",
  "text" : "RT @KindleObsessed: Have u seen the show \"Storage Wars\" where people bid on items in storage units? Mankind is 2 months away from being  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77021995920932864",
    "text" : "Have u seen the show \"Storage Wars\" where people bid on items in storage units? Mankind is 2 months away from being completely out of ideas",
    "id" : 77021995920932864,
    "created_at" : "2011-06-04 14:40:49 +0000",
    "user" : {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "protected" : false,
      "id_str" : "29574025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526178477213380608\/oLhvSdVV_normal.jpeg",
      "id" : 29574025,
      "verified" : false
    }
  },
  "id" : 77022120667910144,
  "created_at" : "2011-06-04 14:41:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BigAl's Books and Pa",
      "screen_name" : "BooksAndPals",
      "indices" : [ 3, 16 ],
      "id_str" : "242514791",
      "id" : 242514791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 77, 84 ]
    }, {
      "text" : "nook",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77018400156688384",
  "text" : "RT @BooksAndPals: New Post: Giveaway - Eye of the Storm http:\/\/dlvr.it\/V49Sm #kindle #nook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 59, 66 ]
      }, {
        "text" : "nook",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77012819958177792",
    "text" : "New Post: Giveaway - Eye of the Storm http:\/\/dlvr.it\/V49Sm #kindle #nook",
    "id" : 77012819958177792,
    "created_at" : "2011-06-04 14:04:21 +0000",
    "user" : {
      "name" : "BigAl's Books and Pa",
      "screen_name" : "BooksAndPals",
      "protected" : false,
      "id_str" : "242514791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2210787938\/BPIcon_normal.jpg",
      "id" : 242514791,
      "verified" : false
    }
  },
  "id" : 77018400156688384,
  "created_at" : "2011-06-04 14:26:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77017094071402496",
  "text" : "RT @oshum: Does the Carterpillar know it will eventually fly? Does it dream of flying?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77016560987934720",
    "text" : "Does the Carterpillar know it will eventually fly? Does it dream of flying?",
    "id" : 77016560987934720,
    "created_at" : "2011-06-04 14:19:13 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 77017094071402496,
  "created_at" : "2011-06-04 14:21:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77015126389166080",
  "geo" : { },
  "id_str" : "77015985256796161",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves sunny day here..but need better coffee! but im good : )",
  "id" : 77015985256796161,
  "in_reply_to_status_id" : 77015126389166080,
  "created_at" : "2011-06-04 14:16:56 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 13, 27 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77005075372969984",
  "geo" : { },
  "id_str" : "77014075351105536",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell @Dwayne_Reaves LOL.. Mr. Sunshine.. I like that! : )",
  "id" : 77014075351105536,
  "in_reply_to_status_id" : 77005075372969984,
  "created_at" : "2011-06-04 14:09:21 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76815968726302722",
  "geo" : { },
  "id_str" : "76818192114266112",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles LOL",
  "id" : 76818192114266112,
  "in_reply_to_status_id" : 76815968726302722,
  "created_at" : "2011-06-04 01:10:58 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76809182124314626",
  "text" : "@Skandhasattva occasionally I feel that way about the world... but then I remember not nice things Ive done, said, thought.",
  "id" : 76809182124314626,
  "created_at" : "2011-06-04 00:35:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "BlondeTXGoddess",
      "indices" : [ 3, 19 ],
      "id_str" : "24224879",
      "id" : 24224879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76808100186828800",
  "text" : "RT @BlondeTXGoddess: RT @Irmitaari \nThe only difference between a flower and a weed is......Judgement",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76806322225553408",
    "text" : "RT @Irmitaari \nThe only difference between a flower and a weed is......Judgement",
    "id" : 76806322225553408,
    "created_at" : "2011-06-04 00:23:48 +0000",
    "user" : {
      "name" : "Amy",
      "screen_name" : "BlondeTXGoddess",
      "protected" : false,
      "id_str" : "24224879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2584751887\/wheyeauy7744ij8ikxul_normal.jpeg",
      "id" : 24224879,
      "verified" : false
    }
  },
  "id" : 76808100186828800,
  "created_at" : "2011-06-04 00:30:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76807841276637184",
  "text" : "@Skandhasattva ya.. i understand.",
  "id" : 76807841276637184,
  "created_at" : "2011-06-04 00:29:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76805358991052801",
  "text" : "@Skandhasattva ((hugs)) that dude is the one w issues. you are blessed w beautiful family.",
  "id" : 76805358991052801,
  "created_at" : "2011-06-04 00:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76791499655888896",
  "text" : "@XNutsyX I missed you. I hope you are feeling better.",
  "id" : 76791499655888896,
  "created_at" : "2011-06-03 23:24:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76786258571051010",
  "text" : "omg'ness.. you're back! ((hugs)) @XNutsyX",
  "id" : 76786258571051010,
  "created_at" : "2011-06-03 23:04:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean Esselink",
      "screen_name" : "Uncucumbered",
      "indices" : [ 3, 16 ],
      "id_str" : "17043155",
      "id" : 17043155
    }, {
      "name" : "Helen",
      "screen_name" : "Chloebeetle",
      "indices" : [ 18, 30 ],
      "id_str" : "20686934",
      "id" : 20686934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76770882973999104",
  "text" : "RT @Uncucumbered: @Chloebeetle It's frustrating when people who don't tweet criticize it. Like a kid who decides he doesn't like a food  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Helen",
        "screen_name" : "Chloebeetle",
        "indices" : [ 0, 12 ],
        "id_str" : "20686934",
        "id" : 20686934
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "76767594723557377",
    "geo" : { },
    "id_str" : "76768494376583168",
    "in_reply_to_user_id" : 20686934,
    "text" : "@Chloebeetle It's frustrating when people who don't tweet criticize it. Like a kid who decides he doesn't like a food he's never tried.",
    "id" : 76768494376583168,
    "in_reply_to_status_id" : 76767594723557377,
    "created_at" : "2011-06-03 21:53:30 +0000",
    "in_reply_to_screen_name" : "Chloebeetle",
    "in_reply_to_user_id_str" : "20686934",
    "user" : {
      "name" : "Jean Esselink",
      "screen_name" : "Uncucumbered",
      "protected" : false,
      "id_str" : "17043155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793394507719045120\/R8DN0Tpv_normal.jpg",
      "id" : 17043155,
      "verified" : false
    }
  },
  "id" : 76770882973999104,
  "created_at" : "2011-06-03 22:02:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76766648568254464",
  "geo" : { },
  "id_str" : "76770226477338624",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth ((hugs)) you are wonderful!",
  "id" : 76770226477338624,
  "in_reply_to_status_id" : 76766648568254464,
  "created_at" : "2011-06-03 22:00:22 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76764580726059008",
  "text" : "@Skandhasattva omg..you DID change your avi.. lol",
  "id" : 76764580726059008,
  "created_at" : "2011-06-03 21:37:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76741422547603456",
  "text" : "LOL you look so demure RT @Skandhasattva: OMFG! Def new avatar pic. Yes? http:\/\/yfrog.com\/gzvj4bnj",
  "id" : 76741422547603456,
  "created_at" : "2011-06-03 20:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas W Lance",
      "screen_name" : "douglance",
      "indices" : [ 3, 13 ],
      "id_str" : "757782870329024512",
      "id" : 757782870329024512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eFiction",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76702852734652416",
  "text" : "RT @DougLance: In celebration of new issue(http:\/\/bit.ly\/eFiction), #eFiction is giving away a Kindle. RT to win. Contest ends in 30 min ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eFiction",
        "indices" : [ 53, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76702205146697728",
    "text" : "In celebration of new issue(http:\/\/bit.ly\/eFiction), #eFiction is giving away a Kindle. RT to win. Contest ends in 30 minutes!!",
    "id" : 76702205146697728,
    "created_at" : "2011-06-03 17:30:05 +0000",
    "user" : {
      "name" : "Douglas W. Lance",
      "screen_name" : "DouglasWLance",
      "protected" : false,
      "id_str" : "14164456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000334743376\/a99c70bf244662760a73dc24c1b1588f_normal.png",
      "id" : 14164456,
      "verified" : false
    }
  },
  "id" : 76702852734652416,
  "created_at" : "2011-06-03 17:32:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76683508411678720",
  "text" : "Please Support the Male Fetal Implantation Act http:\/\/bit.ly\/kcPuOJ",
  "id" : 76683508411678720,
  "created_at" : "2011-06-03 16:15:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76673178059030528",
  "text" : "bless the road workers for finishing their work here & moving elsewhere",
  "id" : 76673178059030528,
  "created_at" : "2011-06-03 15:34:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/tldRbIP",
      "expanded_url" : "http:\/\/www.everythingtech.info\/how-to-manually-install-wordpress\/",
      "display_url" : "everythingtech.info\/how-to-manuall\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "76668199462109184",
  "text" : "How to manually install WordPress | Everything Tech http:\/\/t.co\/tldRbIP",
  "id" : 76668199462109184,
  "created_at" : "2011-06-03 15:14:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Len Kendall",
      "screen_name" : "LenKendall",
      "indices" : [ 3, 14 ],
      "id_str" : "9981522",
      "id" : 9981522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singularity",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76642937240432640",
  "text" : "RT @LenKendall: Scientists Create Tiny Artificial Brain That Exhibits 12 Seconds of Short Term Memory http:\/\/pulsene.ws\/1Oujk #singularity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singularity",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76637337722949632",
    "text" : "Scientists Create Tiny Artificial Brain That Exhibits 12 Seconds of Short Term Memory http:\/\/pulsene.ws\/1Oujk #singularity",
    "id" : 76637337722949632,
    "created_at" : "2011-06-03 13:12:19 +0000",
    "user" : {
      "name" : "Len Kendall",
      "screen_name" : "LenKendall",
      "protected" : false,
      "id_str" : "9981522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716053267386511364\/0yC0TK_8_normal.jpg",
      "id" : 9981522,
      "verified" : false
    }
  },
  "id" : 76642937240432640,
  "created_at" : "2011-06-03 13:34:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BestDayEver",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76642333667495936",
  "text" : "RT @JosephRanseth: Today's Challenge: Show love to someone who is a jerk. Lead by example, not just by words. #BestDayEver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BestDayEver",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76636998160494593",
    "text" : "Today's Challenge: Show love to someone who is a jerk. Lead by example, not just by words. #BestDayEver",
    "id" : 76636998160494593,
    "created_at" : "2011-06-03 13:10:58 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 76642333667495936,
  "created_at" : "2011-06-03 13:32:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76638399276126208",
  "text" : "RT @JosephRanseth: Good morning, I love you. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76633016256049152",
    "text" : "Good morning, I love you. :)",
    "id" : 76633016256049152,
    "created_at" : "2011-06-03 12:55:09 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 76638399276126208,
  "created_at" : "2011-06-03 13:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76403089061576704",
  "geo" : { },
  "id_str" : "76404706511028224",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope no ticks..hehe. just have weird itchy spots all day today that feels like something biting. dont see anything, tho.",
  "id" : 76404706511028224,
  "in_reply_to_status_id" : 76403089061576704,
  "created_at" : "2011-06-02 21:47:56 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76402880810201088",
  "text" : "I feel like tiny little bugs are eating me o-O",
  "id" : 76402880810201088,
  "created_at" : "2011-06-02 21:40:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76362864113364992",
  "text" : "RT @Mahala: Isn't there someway I can claim like.. religious freedom or something in order to remove my bra for the rest of the day w\/o  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76360997589352448",
    "text" : "Isn't there someway I can claim like.. religious freedom or something in order to remove my bra for the rest of the day w\/o getting fired?",
    "id" : 76360997589352448,
    "created_at" : "2011-06-02 18:54:15 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 76362864113364992,
  "created_at" : "2011-06-02 19:01:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruff Dog Rescue",
      "screen_name" : "911RUFFORG",
      "indices" : [ 3, 14 ],
      "id_str" : "235008736",
      "id" : 235008736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76344169626480640",
  "text" : "RT @911RUFFORG: Plz.  Nobody is sending donations.  We really need help. Plz help us http:\/\/www.911ruff.org",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76333507542130689",
    "text" : "Plz.  Nobody is sending donations.  We really need help. Plz help us http:\/\/www.911ruff.org",
    "id" : 76333507542130689,
    "created_at" : "2011-06-02 17:05:01 +0000",
    "user" : {
      "name" : "Ruff Dog Rescue",
      "screen_name" : "911RUFFORG",
      "protected" : false,
      "id_str" : "235008736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668326426928619520\/arlkLv8C_normal.png",
      "id" : 235008736,
      "verified" : false
    }
  },
  "id" : 76344169626480640,
  "created_at" : "2011-06-02 17:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Redrum Lafferty",
      "screen_name" : "mightymur",
      "indices" : [ 8, 18 ],
      "id_str" : "3025261",
      "id" : 3025261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76310616167555072",
  "geo" : { },
  "id_str" : "76311054354886656",
  "in_reply_to_user_id" : 3025261,
  "text" : "squee!! @mightymur",
  "id" : 76311054354886656,
  "in_reply_to_status_id" : 76310616167555072,
  "created_at" : "2011-06-02 15:35:47 +0000",
  "in_reply_to_screen_name" : "mightymur",
  "in_reply_to_user_id_str" : "3025261",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jennifer laurens",
      "screen_name" : "jenniferlaurens",
      "indices" : [ 0, 16 ],
      "id_str" : "16684339",
      "id" : 16684339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76307976817881089",
  "geo" : { },
  "id_str" : "76310732148445184",
  "in_reply_to_user_id" : 16684339,
  "text" : "@jenniferlaurens heavenly ebook",
  "id" : 76310732148445184,
  "in_reply_to_status_id" : 76307976817881089,
  "created_at" : "2011-06-02 15:34:30 +0000",
  "in_reply_to_screen_name" : "jenniferlaurens",
  "in_reply_to_user_id_str" : "16684339",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76290135498567681",
  "geo" : { },
  "id_str" : "76291869885202432",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle ((hugs)) good luck w appt!",
  "id" : 76291869885202432,
  "in_reply_to_status_id" : 76290135498567681,
  "created_at" : "2011-06-02 14:19:33 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebooks",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76288149273325568",
  "text" : "RT @ebookfriendly: How to Take Part in Sunday Kindle Book Giveaway http:\/\/bit.ly\/lK6GYB #ebooks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebooks",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76286986654203904",
    "text" : "How to Take Part in Sunday Kindle Book Giveaway http:\/\/bit.ly\/lK6GYB #ebooks",
    "id" : 76286986654203904,
    "created_at" : "2011-06-02 14:00:09 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 76288149273325568,
  "created_at" : "2011-06-02 14:04:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76264619664093185",
  "text" : "so appreciate my wellness!",
  "id" : 76264619664093185,
  "created_at" : "2011-06-02 12:31:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76262612014342144",
  "text" : "what an exciting time to be alive. so many changes in this world.",
  "id" : 76262612014342144,
  "created_at" : "2011-06-02 12:23:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristianRep",
      "screen_name" : "ChristianRep",
      "indices" : [ 3, 16 ],
      "id_str" : "23028288",
      "id" : 23028288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76102433260044289",
  "text" : "RT @ChristianRep: Why do you look at the speck of sawdust in your brother's eye and pay no attention to the plank in your own eye? Matt. 7:3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76102011061411840",
    "text" : "Why do you look at the speck of sawdust in your brother's eye and pay no attention to the plank in your own eye? Matt. 7:3",
    "id" : 76102011061411840,
    "created_at" : "2011-06-02 01:45:08 +0000",
    "user" : {
      "name" : "ChristianRep",
      "screen_name" : "ChristianRep",
      "protected" : false,
      "id_str" : "23028288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410317058\/c9298c612ff39e99a9702284839d424d_normal.jpeg",
      "id" : 23028288,
      "verified" : false
    }
  },
  "id" : 76102433260044289,
  "created_at" : "2011-06-02 01:46:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abeman",
      "screen_name" : "abeman",
      "indices" : [ 3, 10 ],
      "id_str" : "16679523",
      "id" : 16679523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76089868006072320",
  "text" : "RT @abeman: Zero Tuition College http:\/\/ztcollege.com\/  Now THIS is what Im talkin' about! 'Course my kids'll wanna go to 'regular' coll ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76086487199907840",
    "text" : "Zero Tuition College http:\/\/ztcollege.com\/  Now THIS is what Im talkin' about! 'Course my kids'll wanna go to 'regular' college but - THIS!",
    "id" : 76086487199907840,
    "created_at" : "2011-06-02 00:43:26 +0000",
    "user" : {
      "name" : "Abeman",
      "screen_name" : "abeman",
      "protected" : false,
      "id_str" : "16679523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643906146693091329\/qlQhnWiI_normal.jpg",
      "id" : 16679523,
      "verified" : false
    }
  },
  "id" : 76089868006072320,
  "created_at" : "2011-06-02 00:56:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "DJMVP",
      "screen_name" : "DJMVP",
      "indices" : [ 16, 22 ],
      "id_str" : "23735792",
      "id" : 23735792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76012884093710336",
  "text" : "RT @SangyeH: RT @DJMVP: What a lot of people don't know about Gov Rick scott  Is that he started a drug testing company in florida a few ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DJMVP",
        "screen_name" : "DJMVP",
        "indices" : [ 3, 9 ],
        "id_str" : "23735792",
        "id" : 23735792
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76004303134932993",
    "text" : "RT @DJMVP: What a lot of people don't know about Gov Rick scott  Is that he started a drug testing company in florida a few years ago",
    "id" : 76004303134932993,
    "created_at" : "2011-06-01 19:16:52 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 76012884093710336,
  "created_at" : "2011-06-01 19:50:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bil-Jac Dog Food",
      "screen_name" : "BilJac",
      "indices" : [ 3, 10 ],
      "id_str" : "22172087",
      "id" : 22172087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Quote",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76011576305520640",
  "text" : "RT @BilJac: \u201CThe average dog has one request to all humankind. Love me.\u201D \u2013 Helen Exley #Quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Quote",
        "indices" : [ 75, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76000197540446208",
    "text" : "\u201CThe average dog has one request to all humankind. Love me.\u201D \u2013 Helen Exley #Quote",
    "id" : 76000197540446208,
    "created_at" : "2011-06-01 19:00:33 +0000",
    "user" : {
      "name" : "Bil-Jac Dog Food",
      "screen_name" : "BilJac",
      "protected" : false,
      "id_str" : "22172087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2269513214\/5ezxanixgahtlqnk7s61_normal.gif",
      "id" : 22172087,
      "verified" : false
    }
  },
  "id" : 76011576305520640,
  "created_at" : "2011-06-01 19:45:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "Florida",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76011351444684800",
  "text" : "RT @Reverend_Sue: Another #privacy right destroyed by Gov. Rick Scott. Are your rights next? http:\/\/bit.ly\/jolqfT #Florida welfare drug- ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cnn.com\/mobile\/\" rel=\"nofollow\"\u003ECNN App for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "Florida",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76009335423123456",
    "text" : "Another #privacy right destroyed by Gov. Rick Scott. Are your rights next? http:\/\/bit.ly\/jolqfT #Florida welfare drug-screen measure signed.",
    "id" : 76009335423123456,
    "created_at" : "2011-06-01 19:36:52 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 76011351444684800,
  "created_at" : "2011-06-01 19:44:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MB's eBookNewser",
      "screen_name" : "eBookNewser",
      "indices" : [ 3, 15 ],
      "id_str" : "509372493",
      "id" : 509372493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75990764206817280",
  "text" : "RT @eBookNewser: Sven videos from Book Expo including Nook Touch and Kobo Touch demos http:\/\/mbist.ro\/iUa4WW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75989585200549888",
    "text" : "Sven videos from Book Expo including Nook Touch and Kobo Touch demos http:\/\/mbist.ro\/iUa4WW",
    "id" : 75989585200549888,
    "created_at" : "2011-06-01 18:18:23 +0000",
    "user" : {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "protected" : false,
      "id_str" : "90893629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461987151496744960\/7LSAvXUw_normal.png",
      "id" : 90893629,
      "verified" : false
    }
  },
  "id" : 75990764206817280,
  "created_at" : "2011-06-01 18:23:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75987250642558977",
  "text" : "RT @namenick: Books can help this happen... http:\/\/post.ly\/28XTY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/posterous.com\" rel=\"nofollow\"\u003EPosterous\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75984029878464512",
    "text" : "Books can help this happen... http:\/\/post.ly\/28XTY",
    "id" : 75984029878464512,
    "created_at" : "2011-06-01 17:56:19 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 75987250642558977,
  "created_at" : "2011-06-01 18:09:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eFiction",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/TweNbmT",
      "expanded_url" : "http:\/\/bit.ly\/WinAmzKindle",
      "display_url" : "bit.ly\/WinAmzKindle"
    } ]
  },
  "geo" : { },
  "id_str" : "75987081918283776",
  "text" : "I just entered to win a free Kindle from #eFiction (http:\/\/t.co\/TweNbmT) Retweet to enter!",
  "id" : 75987081918283776,
  "created_at" : "2011-06-01 18:08:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catskill Sanctuary",
      "screen_name" : "CASanctuary",
      "indices" : [ 3, 15 ],
      "id_str" : "27658173",
      "id" : 27658173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75980737203011584",
  "text" : "RT @CASanctuary: Catskill Animal Sanctuary Critter Cam is LIVE now! http:\/\/ow.ly\/57PXH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75978895534465024",
    "text" : "Catskill Animal Sanctuary Critter Cam is LIVE now! http:\/\/ow.ly\/57PXH",
    "id" : 75978895534465024,
    "created_at" : "2011-06-01 17:35:54 +0000",
    "user" : {
      "name" : "Catskill Sanctuary",
      "screen_name" : "CASanctuary",
      "protected" : false,
      "id_str" : "27658173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683067620334145537\/thzrxQtn_normal.jpg",
      "id" : 27658173,
      "verified" : false
    }
  },
  "id" : 75980737203011584,
  "created_at" : "2011-06-01 17:43:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75977261018386432",
  "text" : "@Skandhasattva look ready for a pinata party..lol",
  "id" : 75977261018386432,
  "created_at" : "2011-06-01 17:29:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75976972286693376",
  "text" : "to all my followers: I \u2665 you",
  "id" : 75976972286693376,
  "created_at" : "2011-06-01 17:28:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    }, {
      "name" : "Barry Eisler",
      "screen_name" : "barryeisler",
      "indices" : [ 32, 44 ],
      "id_str" : "26177586",
      "id" : 26177586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75976613141028864",
  "text" : "RT @andrewtshaffer: I still say @barryeisler's THE ASS IS A POOR RECEPTACLE FOR THE HEAD would make an awesome erotica title. http:\/\/amz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barry Eisler",
        "screen_name" : "barryeisler",
        "indices" : [ 12, 24 ],
        "id_str" : "26177586",
        "id" : 26177586
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75975262524809216",
    "text" : "I still say @barryeisler's THE ASS IS A POOR RECEPTACLE FOR THE HEAD would make an awesome erotica title. http:\/\/amzn.to\/mHUkrw",
    "id" : 75975262524809216,
    "created_at" : "2011-06-01 17:21:28 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 75976613141028864,
  "created_at" : "2011-06-01 17:26:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75972776464355328",
  "text" : "RT @abe_quotes: When you make peace with those who bothered you most, then you get the benefit of what they inspired you to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75972448985677824",
    "text" : "When you make peace with those who bothered you most, then you get the benefit of what they inspired you to.",
    "id" : 75972448985677824,
    "created_at" : "2011-06-01 17:10:17 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 75972776464355328,
  "created_at" : "2011-06-01 17:11:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "food",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75971340166889472",
  "text" : "RT @mercola: An intelligent #cat figures out an ingenious way to get inside his #food container. http:\/\/ow.ly\/57iso",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cat",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "food",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75970197948862465",
    "text" : "An intelligent #cat figures out an ingenious way to get inside his #food container. http:\/\/ow.ly\/57iso",
    "id" : 75970197948862465,
    "created_at" : "2011-06-01 17:01:21 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 75971340166889472,
  "created_at" : "2011-06-01 17:05:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/nZrXCIM",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2011\/06\/ok-man-says-dog-protected-wife-in-tornado\/",
      "display_url" : "lifewithdogs.tv\/2011\/06\/ok-man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "75967004984610816",
  "text" : "OK Man Says Dog Protected Wife In Tornado http:\/\/t.co\/nZrXCIM via @nigelbugger",
  "id" : 75967004984610816,
  "created_at" : "2011-06-01 16:48:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Northwest Fire",
      "screen_name" : "NorthwestFire",
      "indices" : [ 38, 52 ],
      "id_str" : "30042163",
      "id" : 30042163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75963663537803264",
  "text" : "instant mansion in heaven for him! RT @NorthwestFire Man killed helping ducklings off interstate http:\/\/on.msnbc.com\/iB3cJS",
  "id" : 75963663537803264,
  "created_at" : "2011-06-01 16:35:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 0, 10 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75956310323105792",
  "geo" : { },
  "id_str" : "75962438918483968",
  "in_reply_to_user_id" : 24636191,
  "text" : "@LukeRomyn (I know its wisdom but I wont tell) lol",
  "id" : 75962438918483968,
  "in_reply_to_status_id" : 75956310323105792,
  "created_at" : "2011-06-01 16:30:31 +0000",
  "in_reply_to_screen_name" : "LukeRomyn",
  "in_reply_to_user_id_str" : "24636191",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75962318395158528",
  "text" : "RT @LukeRomyn: Don't confuse a clock for a compass.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75956310323105792",
    "text" : "Don't confuse a clock for a compass.",
    "id" : 75956310323105792,
    "created_at" : "2011-06-01 16:06:10 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 75962318395158528,
  "created_at" : "2011-06-01 16:30:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75962119731941376",
  "text" : "RT @Matth3ous: The Comparison Trap http:\/\/j.mp\/iwggxi Really, really good advice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75956879674703872",
    "text" : "The Comparison Trap http:\/\/j.mp\/iwggxi Really, really good advice.",
    "id" : 75956879674703872,
    "created_at" : "2011-06-01 16:08:25 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 75962119731941376,
  "created_at" : "2011-06-01 16:29:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angie S.",
      "screen_name" : "angels510",
      "indices" : [ 3, 13 ],
      "id_str" : "35779792",
      "id" : 35779792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75936115412049920",
  "text" : "RT @angels510: My heart is my life's GPS. It leads me to everything that's good.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74755165860802560",
    "text" : "My heart is my life's GPS. It leads me to everything that's good.",
    "id" : 74755165860802560,
    "created_at" : "2011-05-29 08:33:15 +0000",
    "user" : {
      "name" : "Angie S.",
      "screen_name" : "angels510",
      "protected" : false,
      "id_str" : "35779792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2798450440\/c0ec929a0cd8a76bad733d4655bd24b4_normal.jpeg",
      "id" : 35779792,
      "verified" : false
    }
  },
  "id" : 75936115412049920,
  "created_at" : "2011-06-01 14:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Macrae",
      "screen_name" : "acidic",
      "indices" : [ 0, 7 ],
      "id_str" : "7704042",
      "id" : 7704042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75888692199309313",
  "geo" : { },
  "id_str" : "75915009686904834",
  "in_reply_to_user_id" : 7704042,
  "text" : "@acidic http:\/\/kindleworld.blogspot.com\/2011\/05\/nook-vs-kindle-features-also-free.html &lt;&lt;good article for comp features",
  "id" : 75915009686904834,
  "in_reply_to_status_id" : 75888692199309313,
  "created_at" : "2011-06-01 13:22:03 +0000",
  "in_reply_to_screen_name" : "acidic",
  "in_reply_to_user_id_str" : "7704042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Macrae",
      "screen_name" : "acidic",
      "indices" : [ 0, 7 ],
      "id_str" : "7704042",
      "id" : 7704042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75888692199309313",
  "geo" : { },
  "id_str" : "75914555083075586",
  "in_reply_to_user_id" : 7704042,
  "text" : "@acidic if reading a lot, get Kindle. my eyes love it!",
  "id" : 75914555083075586,
  "in_reply_to_status_id" : 75888692199309313,
  "created_at" : "2011-06-01 13:20:15 +0000",
  "in_reply_to_screen_name" : "acidic",
  "in_reply_to_user_id_str" : "7704042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0418\u0440\u0430\u043A\u043B\u0438\u0439   \u0413\u0443\u0449\u0438\u043D",
      "screen_name" : "Shatiya_La_D",
      "indices" : [ 3, 16 ],
      "id_str" : "2999594319",
      "id" : 2999594319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75912430554853376",
  "text" : "RT @Shatiya_La_D: God will speak to you in a whisper. He will speak through a person. If you fail to hear, maybe the trial will get your ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74952497961246720",
    "text" : "God will speak to you in a whisper. He will speak through a person. If you fail to hear, maybe the trial will get your attention.",
    "id" : 74952497961246720,
    "created_at" : "2011-05-29 21:37:22 +0000",
    "user" : {
      "name" : "Shatiya Figueroa",
      "screen_name" : "ShatiyaFigueroa",
      "protected" : false,
      "id_str" : "88982432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683787434438574081\/M0fa-C9T_normal.jpg",
      "id" : 88982432,
      "verified" : false
    }
  },
  "id" : 75912430554853376,
  "created_at" : "2011-06-01 13:11:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75907614420107264",
  "geo" : { },
  "id_str" : "75910822236389376",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl yes, they do... : )",
  "id" : 75910822236389376,
  "in_reply_to_status_id" : 75907614420107264,
  "created_at" : "2011-06-01 13:05:25 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]