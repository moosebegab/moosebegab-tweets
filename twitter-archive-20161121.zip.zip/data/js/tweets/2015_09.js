Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/QbK4TpMLKp",
      "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/649272389793091584",
      "display_url" : "twitter.com\/neiltyson\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649385472733618176",
  "text" : "RT @SciencePorn: This.  https:\/\/t.co\/QbK4TpMLKp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/QbK4TpMLKp",
        "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/649272389793091584",
        "display_url" : "twitter.com\/neiltyson\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649345973492260865",
    "text" : "This.  https:\/\/t.co\/QbK4TpMLKp",
    "id" : 649345973492260865,
    "created_at" : "2015-09-30 22:11:59 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 649385472733618176,
  "created_at" : "2015-10-01 00:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649317757620645888",
  "geo" : { },
  "id_str" : "649349764077780992",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater aww.. you're so sweet. : )",
  "id" : 649349764077780992,
  "in_reply_to_status_id" : 649317757620645888,
  "created_at" : "2015-09-30 22:27:02 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Elk Refuge",
      "screen_name" : "NatlElkRefuge",
      "indices" : [ 3, 17 ],
      "id_str" : "2307093782",
      "id" : 2307093782
    }, {
      "name" : "National Elk Refuge",
      "screen_name" : "NatlElkRefuge",
      "indices" : [ 105, 119 ],
      "id_str" : "2307093782",
      "id" : 2307093782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wyoming",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649264504526798849",
  "text" : "RT @NatlElkRefuge: Traffic jam, #Wyoming-style: a cow and calf moose make their way down the Refuge Road @NatlElkRefuge #wildlife http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Elk Refuge",
        "screen_name" : "NatlElkRefuge",
        "indices" : [ 86, 100 ],
        "id_str" : "2307093782",
        "id" : 2307093782
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NatlElkRefuge\/status\/649263823862394880\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/7W7AZ25Y3y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQKmAVMUwAA57bJ.jpg",
        "id_str" : "649263820913819648",
        "id" : 649263820913819648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQKmAVMUwAA57bJ.jpg",
        "sizes" : [ {
          "h" : 523,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 893,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2432,
          "resize" : "fit",
          "w" : 2790
        } ],
        "display_url" : "pic.twitter.com\/7W7AZ25Y3y"
      } ],
      "hashtags" : [ {
        "text" : "Wyoming",
        "indices" : [ 13, 21 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649263823862394880",
    "text" : "Traffic jam, #Wyoming-style: a cow and calf moose make their way down the Refuge Road @NatlElkRefuge #wildlife http:\/\/t.co\/7W7AZ25Y3y",
    "id" : 649263823862394880,
    "created_at" : "2015-09-30 16:45:33 +0000",
    "user" : {
      "name" : "National Elk Refuge",
      "screen_name" : "NatlElkRefuge",
      "protected" : false,
      "id_str" : "2307093782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474618832351293440\/g_HAq45Y_normal.jpeg",
      "id" : 2307093782,
      "verified" : false
    }
  },
  "id" : 649264504526798849,
  "created_at" : "2015-09-30 16:48:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    }, {
      "name" : "Wildlife Watch",
      "screen_name" : "wildlifewatch",
      "indices" : [ 69, 83 ],
      "id_str" : "57319246",
      "id" : 57319246
    }, {
      "name" : "The Wildlife Trusts",
      "screen_name" : "WildlifeTrusts",
      "indices" : [ 84, 99 ],
      "id_str" : "57319680",
      "id" : 57319680
    }, {
      "name" : "BBC Springwatch",
      "screen_name" : "BBCSpringwatch",
      "indices" : [ 100, 115 ],
      "id_str" : "71229689",
      "id" : 71229689
    }, {
      "name" : "The Woodland Trust",
      "screen_name" : "WoodlandTrust",
      "indices" : [ 117, 131 ],
      "id_str" : "19396413",
      "id" : 19396413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "autumn",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649261615704096768",
  "text" : "RT @WildlifeGadgets: Made some new friends this afternoon.\n\n #autumn @wildlifewatch @wildlifetrusts @BBCSpringwatch \n@WoodlandTrust http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Watch",
        "screen_name" : "wildlifewatch",
        "indices" : [ 48, 62 ],
        "id_str" : "57319246",
        "id" : 57319246
      }, {
        "name" : "The Wildlife Trusts",
        "screen_name" : "WildlifeTrusts",
        "indices" : [ 63, 78 ],
        "id_str" : "57319680",
        "id" : 57319680
      }, {
        "name" : "BBC Springwatch",
        "screen_name" : "BBCSpringwatch",
        "indices" : [ 79, 94 ],
        "id_str" : "71229689",
        "id" : 71229689
      }, {
        "name" : "The Woodland Trust",
        "screen_name" : "WoodlandTrust",
        "indices" : [ 96, 110 ],
        "id_str" : "19396413",
        "id" : 19396413
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/649259361198567424\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/fIZP0QSA7W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQKh7EsW8AAqeFM.jpg",
        "id_str" : "649259332538920960",
        "id" : 649259332538920960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQKh7EsW8AAqeFM.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fIZP0QSA7W"
      } ],
      "hashtags" : [ {
        "text" : "autumn",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649259361198567424",
    "text" : "Made some new friends this afternoon.\n\n #autumn @wildlifewatch @wildlifetrusts @BBCSpringwatch \n@WoodlandTrust http:\/\/t.co\/fIZP0QSA7W",
    "id" : 649259361198567424,
    "created_at" : "2015-09-30 16:27:49 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 649261615704096768,
  "created_at" : "2015-09-30 16:36:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Tips for ME",
      "screen_name" : "TweetTipsforME",
      "indices" : [ 3, 18 ],
      "id_str" : "2427294475",
      "id" : 2427294475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyE",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649261526738694144",
  "text" : "RT @TweetTipsforME: Today I feel mentally itchy (not the same as tired-but-wired). Does that mean anything to you?\nTrying to find good #MyE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyE",
        "indices" : [ 115, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649259372489666560",
    "text" : "Today I feel mentally itchy (not the same as tired-but-wired). Does that mean anything to you?\nTrying to find good #MyE symptom descriptions",
    "id" : 649259372489666560,
    "created_at" : "2015-09-30 16:27:51 +0000",
    "user" : {
      "name" : "Jenny Tips for ME",
      "screen_name" : "TweetTipsforME",
      "protected" : false,
      "id_str" : "2427294475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734773542659596288\/PXiwF4uP_normal.png",
      "id" : 2427294475,
      "verified" : false
    }
  },
  "id" : 649261526738694144,
  "created_at" : "2015-09-30 16:36:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herdwick Shepherd",
      "screen_name" : "herdyshepherd1",
      "indices" : [ 3, 18 ],
      "id_str" : "467507215",
      "id" : 467507215
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/649118343400701952\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/wAESGZQUxZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQIhlTyWEAAFsIM.jpg",
      "id_str" : "649118221145083904",
      "id" : 649118221145083904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQIhlTyWEAAFsIM.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wAESGZQUxZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649214706058678272",
  "text" : "RT @herdyshepherd1: Meanwhile it's the most beautiful morning in the history of the earth (again) http:\/\/t.co\/wAESGZQUxZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/649118343400701952\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/wAESGZQUxZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQIhlTyWEAAFsIM.jpg",
        "id_str" : "649118221145083904",
        "id" : 649118221145083904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQIhlTyWEAAFsIM.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wAESGZQUxZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649118343400701952",
    "text" : "Meanwhile it's the most beautiful morning in the history of the earth (again) http:\/\/t.co\/wAESGZQUxZ",
    "id" : 649118343400701952,
    "created_at" : "2015-09-30 07:07:27 +0000",
    "user" : {
      "name" : "Herdwick Shepherd",
      "screen_name" : "herdyshepherd1",
      "protected" : false,
      "id_str" : "467507215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570254290402578432\/b9xZ4wR5_normal.jpeg",
      "id" : 467507215,
      "verified" : true
    }
  },
  "id" : 649214706058678272,
  "created_at" : "2015-09-30 13:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Nightly Show",
      "screen_name" : "nightlyshow",
      "indices" : [ 3, 15 ],
      "id_str" : "2875485611",
      "id" : 2875485611
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 18, 24 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nightlyshow\/status\/648888327739953152\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UOC5fOX7EA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFQfiRUcAAFu9H.jpg",
      "id_str" : "648888324023676928",
      "id" : 648888324023676928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFQfiRUcAAFu9H.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/UOC5fOX7EA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/jDnxuHEIRn",
      "expanded_url" : "http:\/\/on.cc.com\/1JAf62i",
      "display_url" : "on.cc.com\/1JAf62i"
    } ]
  },
  "geo" : { },
  "id_str" : "649047862492446720",
  "text" : "RT @nightlyshow: .@deray with the truth: http:\/\/t.co\/jDnxuHEIRn http:\/\/t.co\/UOC5fOX7EA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 1, 7 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nightlyshow\/status\/648888327739953152\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/UOC5fOX7EA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFQfiRUcAAFu9H.jpg",
        "id_str" : "648888324023676928",
        "id" : 648888324023676928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFQfiRUcAAFu9H.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/UOC5fOX7EA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/jDnxuHEIRn",
        "expanded_url" : "http:\/\/on.cc.com\/1JAf62i",
        "display_url" : "on.cc.com\/1JAf62i"
      } ]
    },
    "geo" : { },
    "id_str" : "648888327739953152",
    "text" : ".@deray with the truth: http:\/\/t.co\/jDnxuHEIRn http:\/\/t.co\/UOC5fOX7EA",
    "id" : 648888327739953152,
    "created_at" : "2015-09-29 15:53:27 +0000",
    "user" : {
      "name" : "The Nightly Show",
      "screen_name" : "nightlyshow",
      "protected" : false,
      "id_str" : "2875485611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535217711765127168\/HnjKyEIB_normal.jpeg",
      "id" : 2875485611,
      "verified" : true
    }
  },
  "id" : 649047862492446720,
  "created_at" : "2015-09-30 02:27:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649045802413871105",
  "text" : "RT @ZachsMind: is anyone else freaking out over what i'm talking about or am i the only one freaking out over JUST HOW MIND BOGGINGLY BIG T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649037178752892928",
    "text" : "is anyone else freaking out over what i'm talking about or am i the only one freaking out over JUST HOW MIND BOGGINGLY BIG THE UNIVERSE IS!?",
    "id" : 649037178752892928,
    "created_at" : "2015-09-30 01:44:56 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 649045802413871105,
  "created_at" : "2015-09-30 02:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648998345231466496",
  "text" : "DD showed me a toad today. for some reason, toads make me smile.",
  "id" : 648998345231466496,
  "created_at" : "2015-09-29 23:10:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648990635773566976",
  "text" : "RT @Snowden: Can you hear me now?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648890134243487744",
    "text" : "Can you hear me now?",
    "id" : 648890134243487744,
    "created_at" : "2015-09-29 16:00:38 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 648990635773566976,
  "created_at" : "2015-09-29 22:39:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Numberful",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ErPOuDMf5N",
      "expanded_url" : "http:\/\/playnumberful.com\/?ref=producthunt#.VgsE-jVuHVc.twitter",
      "display_url" : "playnumberful.com\/?ref=producthu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648975615996071936",
  "text" : "fun but I hate the timer. wish it was optional. &gt; #Numberful http:\/\/t.co\/ErPOuDMf5N",
  "id" : 648975615996071936,
  "created_at" : "2015-09-29 21:40:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Wil Gafney)))",
      "screen_name" : "WilGafney",
      "indices" : [ 3, 13 ],
      "id_str" : "483206664",
      "id" : 483206664
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WilGafney\/status\/648931549220462592\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/DCgE4jzYIb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQF3zh8UYAATg5k.png",
      "id_str" : "648931548486459392",
      "id" : 648931548486459392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQF3zh8UYAATg5k.png",
      "sizes" : [ {
        "h" : 233,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/DCgE4jzYIb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648967437300441092",
  "text" : "RT @WilGafney: My abortion support story. http:\/\/t.co\/DCgE4jzYIb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WilGafney\/status\/648931549220462592\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/DCgE4jzYIb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQF3zh8UYAATg5k.png",
        "id_str" : "648931548486459392",
        "id" : 648931548486459392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQF3zh8UYAATg5k.png",
        "sizes" : [ {
          "h" : 233,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/DCgE4jzYIb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648931549220462592",
    "text" : "My abortion support story. http:\/\/t.co\/DCgE4jzYIb",
    "id" : 648931549220462592,
    "created_at" : "2015-09-29 18:45:12 +0000",
    "user" : {
      "name" : "(((Wil Gafney)))",
      "screen_name" : "WilGafney",
      "protected" : false,
      "id_str" : "483206664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800002970213486596\/GpNWuUdQ_normal.jpg",
      "id" : 483206664,
      "verified" : true
    }
  },
  "id" : 648967437300441092,
  "created_at" : "2015-09-29 21:07:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovestrawberries",
      "indices" : [ 11, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/pOlsZli30O",
      "expanded_url" : "https:\/\/twitter.com\/FHorsfield\/status\/648950947700436992",
      "display_url" : "twitter.com\/FHorsfield\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648953243972816897",
  "text" : "((drools)) #lovestrawberries https:\/\/t.co\/pOlsZli30O",
  "id" : 648953243972816897,
  "created_at" : "2015-09-29 20:11:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648947337688182785",
  "text" : "RT @JohnFugelsang: I'll sign on for results-based pay for teachers the day Congress gets the same deal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648696312326672384",
    "text" : "I'll sign on for results-based pay for teachers the day Congress gets the same deal.",
    "id" : 648696312326672384,
    "created_at" : "2015-09-29 03:10:27 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 648947337688182785,
  "created_at" : "2015-09-29 19:47:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "indices" : [ 3, 15 ],
      "id_str" : "17592150",
      "id" : 17592150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/LEh25oYPB3",
      "expanded_url" : "http:\/\/www.pbs.org\/newshour\/making-sense\/are-banks-borrowing-from-the-f\/",
      "display_url" : "pbs.org\/newshour\/makin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648946970019647488",
  "text" : "RT @thomaspluck: You can't win. Banks can: they borrow our money at .1% and then buy T-Bills that pay 3.5%. http:\/\/t.co\/LEh25oYPB3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/LEh25oYPB3",
        "expanded_url" : "http:\/\/www.pbs.org\/newshour\/making-sense\/are-banks-borrowing-from-the-f\/",
        "display_url" : "pbs.org\/newshour\/makin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648945596322181120",
    "text" : "You can't win. Banks can: they borrow our money at .1% and then buy T-Bills that pay 3.5%. http:\/\/t.co\/LEh25oYPB3",
    "id" : 648945596322181120,
    "created_at" : "2015-09-29 19:41:01 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 648946970019647488,
  "created_at" : "2015-09-29 19:46:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648868214643032064\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/rTOimNIDcN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE-I_YWIAAjTnp.jpg",
      "id_str" : "648868145491484672",
      "id" : 648868145491484672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE-I_YWIAAjTnp.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rTOimNIDcN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648868214643032064\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/rTOimNIDcN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE-JBCWcAEEhlq.jpg",
      "id_str" : "648868145936101377",
      "id" : 648868145936101377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE-JBCWcAEEhlq.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rTOimNIDcN"
    } ],
    "hashtags" : [ {
      "text" : "TongueOutCoosday",
      "indices" : [ 49, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648945130255290368",
  "text" : "RT @newlandfarm: Even Maibelle got in on the act #TongueOutCoosday http:\/\/t.co\/rTOimNIDcN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648868214643032064\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/rTOimNIDcN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE-I_YWIAAjTnp.jpg",
        "id_str" : "648868145491484672",
        "id" : 648868145491484672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE-I_YWIAAjTnp.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rTOimNIDcN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648868214643032064\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/rTOimNIDcN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE-JBCWcAEEhlq.jpg",
        "id_str" : "648868145936101377",
        "id" : 648868145936101377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE-JBCWcAEEhlq.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rTOimNIDcN"
      } ],
      "hashtags" : [ {
        "text" : "TongueOutCoosday",
        "indices" : [ 32, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648868214643032064",
    "text" : "Even Maibelle got in on the act #TongueOutCoosday http:\/\/t.co\/rTOimNIDcN",
    "id" : 648868214643032064,
    "created_at" : "2015-09-29 14:33:32 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 648945130255290368,
  "created_at" : "2015-09-29 19:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "indices" : [ 3, 17 ],
      "id_str" : "751200954",
      "id" : 751200954
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/648907112752484352\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/jOo00cd0Tj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFhlKZWoAAnjuh.jpg",
      "id_str" : "648907112391811072",
      "id" : 648907112391811072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFhlKZWoAAnjuh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3120,
        "resize" : "fit",
        "w" : 3120
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jOo00cd0Tj"
    } ],
    "hashtags" : [ {
      "text" : "teamdairy",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "Ayrshire",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648945019995455488",
  "text" : "RT @fionagraham13: Do you remember me? #teamdairy #Ayrshire http:\/\/t.co\/jOo00cd0Tj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/648907112752484352\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/jOo00cd0Tj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFhlKZWoAAnjuh.jpg",
        "id_str" : "648907112391811072",
        "id" : 648907112391811072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFhlKZWoAAnjuh.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3120,
          "resize" : "fit",
          "w" : 3120
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jOo00cd0Tj"
      } ],
      "hashtags" : [ {
        "text" : "teamdairy",
        "indices" : [ 20, 30 ]
      }, {
        "text" : "Ayrshire",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648907112752484352",
    "text" : "Do you remember me? #teamdairy #Ayrshire http:\/\/t.co\/jOo00cd0Tj",
    "id" : 648907112752484352,
    "created_at" : "2015-09-29 17:08:06 +0000",
    "user" : {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "protected" : false,
      "id_str" : "751200954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775421774179819520\/KBk03QHm_normal.jpg",
      "id" : 751200954,
      "verified" : false
    }
  },
  "id" : 648945019995455488,
  "created_at" : "2015-09-29 19:38:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648941784584749056",
  "geo" : { },
  "id_str" : "648943039965171712",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time yes.. fear tends to block out rationality.",
  "id" : 648943039965171712,
  "in_reply_to_status_id" : 648941784584749056,
  "created_at" : "2015-09-29 19:30:52 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648921143576014848",
  "text" : "RT @worldtreeman: Definately feeling some sort of build up of cosmic energies,  anyone else feel it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648920676225650688",
    "text" : "Definately feeling some sort of build up of cosmic energies,  anyone else feel it?",
    "id" : 648920676225650688,
    "created_at" : "2015-09-29 18:02:00 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 648921143576014848,
  "created_at" : "2015-09-29 18:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "indices" : [ 3, 13 ],
      "id_str" : "194209267",
      "id" : 194209267
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EpicReads\/status\/648920813308145664\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NJI7QRNaP4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFuCpZWgAASvZj.jpg",
      "id_str" : "648920813069041664",
      "id" : 648920813069041664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFuCpZWgAASvZj.jpg",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/NJI7QRNaP4"
    } ],
    "hashtags" : [ {
      "text" : "BannedBooksWeek",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648921077964500992",
  "text" : "RT @EpicReads: Don't let banned book be lonely. Go read one! \n#BannedBooksWeek http:\/\/t.co\/NJI7QRNaP4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EpicReads\/status\/648920813308145664\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/NJI7QRNaP4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFuCpZWgAASvZj.jpg",
        "id_str" : "648920813069041664",
        "id" : 648920813069041664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFuCpZWgAASvZj.jpg",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/NJI7QRNaP4"
      } ],
      "hashtags" : [ {
        "text" : "BannedBooksWeek",
        "indices" : [ 47, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648920813308145664",
    "text" : "Don't let banned book be lonely. Go read one! \n#BannedBooksWeek http:\/\/t.co\/NJI7QRNaP4",
    "id" : 648920813308145664,
    "created_at" : "2015-09-29 18:02:32 +0000",
    "user" : {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "protected" : false,
      "id_str" : "194209267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710877075469701121\/1Vj7UzYf_normal.jpg",
      "id" : 194209267,
      "verified" : true
    }
  },
  "id" : 648921077964500992,
  "created_at" : "2015-09-29 18:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.S. Guthrie",
      "screen_name" : "rsguthrie",
      "indices" : [ 0, 10 ],
      "id_str" : "358119616",
      "id" : 358119616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648898610998956033",
  "geo" : { },
  "id_str" : "648903233306542085",
  "in_reply_to_user_id" : 358119616,
  "text" : "@rsguthrie our has to lick dh toes each evening. she demands it..lol &lt;3",
  "id" : 648903233306542085,
  "in_reply_to_status_id" : 648898610998956033,
  "created_at" : "2015-09-29 16:52:41 +0000",
  "in_reply_to_screen_name" : "rsguthrie",
  "in_reply_to_user_id_str" : "358119616",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.S. Guthrie",
      "screen_name" : "rsguthrie",
      "indices" : [ 3, 13 ],
      "id_str" : "358119616",
      "id" : 358119616
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CUTE",
      "indices" : [ 15, 20 ]
    }, {
      "text" : "aussies",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "dogs",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "funnyvideo",
      "indices" : [ 107, 118 ]
    }, {
      "text" : "funny",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "videos",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/YHTO6KodXo",
      "expanded_url" : "https:\/\/youtu.be\/QClShqeSs4w",
      "display_url" : "youtu.be\/QClShqeSs4w"
    } ]
  },
  "geo" : { },
  "id_str" : "648902827230789632",
  "text" : "RT @rsguthrie: #CUTE Our 4-year-old Aussie, Zoey, sucking my thumb. https:\/\/t.co\/YHTO6KodXo #aussies #dogs #funnyvideo #funny #videos #dogl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CUTE",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "aussies",
        "indices" : [ 77, 85 ]
      }, {
        "text" : "dogs",
        "indices" : [ 86, 91 ]
      }, {
        "text" : "funnyvideo",
        "indices" : [ 92, 103 ]
      }, {
        "text" : "funny",
        "indices" : [ 104, 110 ]
      }, {
        "text" : "videos",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "doglovers",
        "indices" : [ 119, 129 ]
      }, {
        "text" : "RT",
        "indices" : [ 130, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/YHTO6KodXo",
        "expanded_url" : "https:\/\/youtu.be\/QClShqeSs4w",
        "display_url" : "youtu.be\/QClShqeSs4w"
      } ]
    },
    "geo" : { },
    "id_str" : "648898610998956033",
    "text" : "#CUTE Our 4-year-old Aussie, Zoey, sucking my thumb. https:\/\/t.co\/YHTO6KodXo #aussies #dogs #funnyvideo #funny #videos #doglovers #RT",
    "id" : 648898610998956033,
    "created_at" : "2015-09-29 16:34:19 +0000",
    "user" : {
      "name" : "R.S. Guthrie",
      "screen_name" : "rsguthrie",
      "protected" : false,
      "id_str" : "358119616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2165923410\/Rob-75x2000-Cropped_normal.jpg",
      "id" : 358119616,
      "verified" : false
    }
  },
  "id" : 648902827230789632,
  "created_at" : "2015-09-29 16:51:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 4, 12 ]
    }, {
      "text" : "options",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "beinghuman",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/PAH8XrzAAR",
      "expanded_url" : "https:\/\/twitter.com\/HelloPoodle\/status\/648896897755824128",
      "display_url" : "twitter.com\/HelloPoodle\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648900970852806656",
  "text" : "yup #freedom #options #beinghuman https:\/\/t.co\/PAH8XrzAAR",
  "id" : 648900970852806656,
  "created_at" : "2015-09-29 16:43:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa M. Gott",
      "screen_name" : "LisaMGott",
      "indices" : [ 3, 13 ],
      "id_str" : "164312699",
      "id" : 164312699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LisaMGott\/status\/648896927275331584\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Vh3XrbCKOG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFYTztUYAAUnIr.jpg",
      "id_str" : "648896918639108096",
      "id" : 648896918639108096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFYTztUYAAUnIr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Vh3XrbCKOG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648900630275338241",
  "text" : "RT @LisaMGott: Be BOLD! Chase those dreams! Become your own superhero. Inspire others to do the same \u2764\uFE0F http:\/\/t.co\/Vh3XrbCKOG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LisaMGott\/status\/648896927275331584\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Vh3XrbCKOG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFYTztUYAAUnIr.jpg",
        "id_str" : "648896918639108096",
        "id" : 648896918639108096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFYTztUYAAUnIr.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Vh3XrbCKOG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648896927275331584",
    "text" : "Be BOLD! Chase those dreams! Become your own superhero. Inspire others to do the same \u2764\uFE0F http:\/\/t.co\/Vh3XrbCKOG",
    "id" : 648896927275331584,
    "created_at" : "2015-09-29 16:27:38 +0000",
    "user" : {
      "name" : "Lisa M. Gott",
      "screen_name" : "LisaMGott",
      "protected" : false,
      "id_str" : "164312699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766829254830985217\/gVoGq-_p_normal.jpg",
      "id" : 164312699,
      "verified" : false
    }
  },
  "id" : 648900630275338241,
  "created_at" : "2015-09-29 16:42:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 0, 16 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648897082934210560",
  "geo" : { },
  "id_str" : "648900545244217344",
  "in_reply_to_user_id" : 24233147,
  "text" : "@fairlyspiritual discover with fresh eyes!",
  "id" : 648900545244217344,
  "in_reply_to_status_id" : 648897082934210560,
  "created_at" : "2015-09-29 16:42:00 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Android",
      "screen_name" : "Android",
      "indices" : [ 3, 11 ],
      "id_str" : "382267114",
      "id" : 382267114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AndroidMarshmallow",
      "indices" : [ 13, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648900237747224576",
  "text" : "RT @Android: #AndroidMarshmallow will begin rolling out to Nexus 5, 6, 7, 9 and Nexus Player starting next week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AndroidMarshmallow",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648897088915288064",
    "text" : "#AndroidMarshmallow will begin rolling out to Nexus 5, 6, 7, 9 and Nexus Player starting next week.",
    "id" : 648897088915288064,
    "created_at" : "2015-09-29 16:28:16 +0000",
    "user" : {
      "name" : "Android",
      "screen_name" : "Android",
      "protected" : false,
      "id_str" : "382267114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616076655547682816\/6gMRtQyY_normal.jpg",
      "id" : 382267114,
      "verified" : true
    }
  },
  "id" : 648900237747224576,
  "created_at" : "2015-09-29 16:40:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 0, 16 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648897646111797248",
  "geo" : { },
  "id_str" : "648899238965981184",
  "in_reply_to_user_id" : 24233147,
  "text" : "@fairlyspiritual can you expand on why? (had to look up prog. relativism)",
  "id" : 648899238965981184,
  "in_reply_to_status_id" : 648897646111797248,
  "created_at" : "2015-09-29 16:36:49 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/es8bmbNfRQ",
      "expanded_url" : "http:\/\/bit.ly\/1Otbg2y",
      "display_url" : "bit.ly\/1Otbg2y"
    } ]
  },
  "geo" : { },
  "id_str" : "648898171096145920",
  "text" : "RT @jonlieffmd: Individual cells have different ways of movement for different three-dimensional situations. http:\/\/t.co\/es8bmbNfRQ http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/648897602419822593\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/XvOc45EAX1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQFY7mfXAAAqUQg.jpg",
        "id_str" : "648897602285666304",
        "id" : 648897602285666304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQFY7mfXAAAqUQg.jpg",
        "sizes" : [ {
          "h" : 208,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/XvOc45EAX1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/es8bmbNfRQ",
        "expanded_url" : "http:\/\/bit.ly\/1Otbg2y",
        "display_url" : "bit.ly\/1Otbg2y"
      } ]
    },
    "geo" : { },
    "id_str" : "648897602419822593",
    "text" : "Individual cells have different ways of movement for different three-dimensional situations. http:\/\/t.co\/es8bmbNfRQ http:\/\/t.co\/XvOc45EAX1",
    "id" : 648897602419822593,
    "created_at" : "2015-09-29 16:30:19 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 648898171096145920,
  "created_at" : "2015-09-29 16:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/AGgBEik69K",
      "expanded_url" : "http:\/\/wp.me\/p24yff-1aD",
      "display_url" : "wp.me\/p24yff-1aD"
    } ]
  },
  "geo" : { },
  "id_str" : "648896201010610176",
  "text" : "Doug Wilson, localized into American English http:\/\/t.co\/AGgBEik69K",
  "id" : 648896201010610176,
  "created_at" : "2015-09-29 16:24:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648879703525298176",
  "geo" : { },
  "id_str" : "648882562073554944",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields the illiberal left part comment I agree with.",
  "id" : 648882562073554944,
  "in_reply_to_status_id" : 648879703525298176,
  "created_at" : "2015-09-29 15:30:33 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Robert Melillo",
      "screen_name" : "DrRobMelillo",
      "indices" : [ 3, 16 ],
      "id_str" : "619101692",
      "id" : 619101692
    }, {
      "name" : "Health",
      "screen_name" : "goodhealth",
      "indices" : [ 91, 102 ],
      "id_str" : "15566901",
      "id" : 15566901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Probiotics",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "Anxiety",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "wellness",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/mIwoKQMgmJ",
      "expanded_url" : "http:\/\/ow.ly\/SMe3b",
      "display_url" : "ow.ly\/SMe3b"
    } ]
  },
  "geo" : { },
  "id_str" : "648880617799684097",
  "text" : "RT @DrRobMelillo: How #Probiotics May Help Ease Social #Anxiety http:\/\/t.co\/mIwoKQMgmJ via @goodhealth #wellness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Health",
        "screen_name" : "goodhealth",
        "indices" : [ 73, 84 ],
        "id_str" : "15566901",
        "id" : 15566901
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Probiotics",
        "indices" : [ 4, 15 ]
      }, {
        "text" : "Anxiety",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "wellness",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/mIwoKQMgmJ",
        "expanded_url" : "http:\/\/ow.ly\/SMe3b",
        "display_url" : "ow.ly\/SMe3b"
      } ]
    },
    "geo" : { },
    "id_str" : "648835979470630912",
    "text" : "How #Probiotics May Help Ease Social #Anxiety http:\/\/t.co\/mIwoKQMgmJ via @goodhealth #wellness",
    "id" : 648835979470630912,
    "created_at" : "2015-09-29 12:25:26 +0000",
    "user" : {
      "name" : "Dr Robert Melillo",
      "screen_name" : "DrRobMelillo",
      "protected" : false,
      "id_str" : "619101692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694246778179158016\/_Fmdzd-E_normal.jpg",
      "id" : 619101692,
      "verified" : false
    }
  },
  "id" : 648880617799684097,
  "created_at" : "2015-09-29 15:22:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648842294288711680",
  "geo" : { },
  "id_str" : "648879450633990144",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields hmm.. got a point there..",
  "id" : 648879450633990144,
  "in_reply_to_status_id" : 648842294288711680,
  "created_at" : "2015-09-29 15:18:11 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648867838309044224\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/tM7u7fnHPa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE9zz6WsAAhGkP.jpg",
      "id_str" : "648867781635649536",
      "id" : 648867781635649536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE9zz6WsAAhGkP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tM7u7fnHPa"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648867838309044224\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/tM7u7fnHPa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE9z1AWEAA4kdk.jpg",
      "id_str" : "648867781929209856",
      "id" : 648867781929209856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE9z1AWEAA4kdk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tM7u7fnHPa"
    } ],
    "hashtags" : [ {
      "text" : "TongueOutCoosday",
      "indices" : [ 30, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648875956912943104",
  "text" : "RT @newlandfarm: Guess who \uD83D\uDE1D\uD83D\uDE1B\uD83D\uDE1D#TongueOutCoosday \n\nHe's grown but still not sure he has full control of his \uD83D\uDC45 http:\/\/t.co\/tM7u7fnHPa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648867838309044224\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/tM7u7fnHPa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE9zz6WsAAhGkP.jpg",
        "id_str" : "648867781635649536",
        "id" : 648867781635649536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE9zz6WsAAhGkP.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tM7u7fnHPa"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/648867838309044224\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/tM7u7fnHPa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE9z1AWEAA4kdk.jpg",
        "id_str" : "648867781929209856",
        "id" : 648867781929209856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE9z1AWEAA4kdk.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tM7u7fnHPa"
      } ],
      "hashtags" : [ {
        "text" : "TongueOutCoosday",
        "indices" : [ 13, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648867838309044224",
    "text" : "Guess who \uD83D\uDE1D\uD83D\uDE1B\uD83D\uDE1D#TongueOutCoosday \n\nHe's grown but still not sure he has full control of his \uD83D\uDC45 http:\/\/t.co\/tM7u7fnHPa",
    "id" : 648867838309044224,
    "created_at" : "2015-09-29 14:32:02 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 648875956912943104,
  "created_at" : "2015-09-29 15:04:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 3, 18 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 111, 124 ]
    }, {
      "text" : "birdbath",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648872891648487424",
  "text" : "RT @PoetsLoveBirds: Leonardo, the Eastern Bluebird, visits Le Avian Rural Day Spa for his daily bath.  \n#birds #birdwatching #birdbath http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PoetsLoveBirds\/status\/648868048066232320\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/63El38w6G6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE-DQEUcAAp52p.jpg",
        "id_str" : "648868046891675648",
        "id" : 648868046891675648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE-DQEUcAAp52p.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 722,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1340,
          "resize" : "fit",
          "w" : 1900
        } ],
        "display_url" : "pic.twitter.com\/63El38w6G6"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 84, 90 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 91, 104 ]
      }, {
        "text" : "birdbath",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648868048066232320",
    "text" : "Leonardo, the Eastern Bluebird, visits Le Avian Rural Day Spa for his daily bath.  \n#birds #birdwatching #birdbath http:\/\/t.co\/63El38w6G6",
    "id" : 648868048066232320,
    "created_at" : "2015-09-29 14:32:52 +0000",
    "user" : {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "protected" : false,
      "id_str" : "818814906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153554844\/2f757111dc3eedb25debd1db4e264f85_normal.jpeg",
      "id" : 818814906,
      "verified" : false
    }
  },
  "id" : 648872891648487424,
  "created_at" : "2015-09-29 14:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 3, 18 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648872786866368512",
  "text" : "RT @PoetsLoveBirds: Leonardo, the Eastern Bluebird, dries his feathers after his bath at Le Avian Rural Day Spa.  \n#birds #birdwatching htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PoetsLoveBirds\/status\/648868587273351168\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/YYDxswDGJ1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQE-ikBWwAACWhu.jpg",
        "id_str" : "648868584823898112",
        "id" : 648868584823898112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQE-ikBWwAACWhu.jpg",
        "sizes" : [ {
          "h" : 1384,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 886,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YYDxswDGJ1"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648868587273351168",
    "text" : "Leonardo, the Eastern Bluebird, dries his feathers after his bath at Le Avian Rural Day Spa.  \n#birds #birdwatching http:\/\/t.co\/YYDxswDGJ1",
    "id" : 648868587273351168,
    "created_at" : "2015-09-29 14:35:01 +0000",
    "user" : {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "protected" : false,
      "id_str" : "818814906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153554844\/2f757111dc3eedb25debd1db4e264f85_normal.jpeg",
      "id" : 818814906,
      "verified" : false
    }
  },
  "id" : 648872786866368512,
  "created_at" : "2015-09-29 14:51:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Health Quest",
      "screen_name" : "my_healthquest",
      "indices" : [ 3, 18 ],
      "id_str" : "540258509",
      "id" : 540258509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648622816678518784",
  "text" : "RT @my_healthquest: NY is 50th out of 50 states in the % of residents enrolled as organ donors. Let's change that on 10\/6: http:\/\/t.co\/BK1S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DonorDay2015",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/BK1SS99k0X",
        "expanded_url" : "http:\/\/on.fb.me\/1gOIb2W",
        "display_url" : "on.fb.me\/1gOIb2W"
      } ]
    },
    "geo" : { },
    "id_str" : "647455776198422528",
    "text" : "NY is 50th out of 50 states in the % of residents enrolled as organ donors. Let's change that on 10\/6: http:\/\/t.co\/BK1SS99k0X #DonorDay2015",
    "id" : 647455776198422528,
    "created_at" : "2015-09-25 17:01:00 +0000",
    "user" : {
      "name" : "My Health Quest",
      "screen_name" : "my_healthquest",
      "protected" : false,
      "id_str" : "540258509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661216097815818240\/P0U1svlf_normal.jpg",
      "id" : 540258509,
      "verified" : false
    }
  },
  "id" : 648622816678518784,
  "created_at" : "2015-09-28 22:18:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmers of Canada",
      "screen_name" : "FarmersOfCanada",
      "indices" : [ 3, 19 ],
      "id_str" : "1117252483",
      "id" : 1117252483
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FarmersOfCanada\/status\/648531380457050112\/video\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/qCbkfq9584",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/648531350102917120\/pu\/img\/abKvi9-Lkej551An.jpg",
      "id_str" : "648531350102917120",
      "id" : 648531350102917120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/648531350102917120\/pu\/img\/abKvi9-Lkej551An.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qCbkfq9584"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648572816607084545",
  "text" : "RT @FarmersOfCanada: Calgary Stampede Champion Clyde stud announcing his arrival http:\/\/t.co\/qCbkfq9584",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmersOfCanada\/status\/648531380457050112\/video\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/qCbkfq9584",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/648531350102917120\/pu\/img\/abKvi9-Lkej551An.jpg",
        "id_str" : "648531350102917120",
        "id" : 648531350102917120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/648531350102917120\/pu\/img\/abKvi9-Lkej551An.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qCbkfq9584"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648531380457050112",
    "text" : "Calgary Stampede Champion Clyde stud announcing his arrival http:\/\/t.co\/qCbkfq9584",
    "id" : 648531380457050112,
    "created_at" : "2015-09-28 16:15:04 +0000",
    "user" : {
      "name" : "Farmers of Canada",
      "screen_name" : "FarmersOfCanada",
      "protected" : false,
      "id_str" : "1117252483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787824728719306752\/sz_-_Kpa_normal.jpg",
      "id" : 1117252483,
      "verified" : false
    }
  },
  "id" : 648572816607084545,
  "created_at" : "2015-09-28 18:59:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648571213695070208",
  "text" : "RT @PisseArtiste: Universal healthcare is awesome, in case you didn't know.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647851710162051072",
    "text" : "Universal healthcare is awesome, in case you didn't know.",
    "id" : 647851710162051072,
    "created_at" : "2015-09-26 19:14:18 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 648571213695070208,
  "created_at" : "2015-09-28 18:53:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "North Woods Ranch",
      "screen_name" : "NorthWoodsRanch",
      "indices" : [ 3, 19 ],
      "id_str" : "431004831",
      "id" : 431004831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/648494628640002048\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/67amgo0R2x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP_qbW3XAAAnKYc.jpg",
      "id_str" : "648494627079782400",
      "id" : 648494627079782400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP_qbW3XAAAnKYc.jpg",
      "sizes" : [ {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2114,
        "resize" : "fit",
        "w" : 3951
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/67amgo0R2x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648519468252045318",
  "text" : "RT @NorthWoodsRanch: Older cows heads down grazing while youngins keep wary eyes on paparazzo... http:\/\/t.co\/67amgo0R2x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/648494628640002048\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/67amgo0R2x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP_qbW3XAAAnKYc.jpg",
        "id_str" : "648494627079782400",
        "id" : 648494627079782400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP_qbW3XAAAnKYc.jpg",
        "sizes" : [ {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2114,
          "resize" : "fit",
          "w" : 3951
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/67amgo0R2x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648494628640002048",
    "text" : "Older cows heads down grazing while youngins keep wary eyes on paparazzo... http:\/\/t.co\/67amgo0R2x",
    "id" : 648494628640002048,
    "created_at" : "2015-09-28 13:49:02 +0000",
    "user" : {
      "name" : "North Woods Ranch",
      "screen_name" : "NorthWoodsRanch",
      "protected" : false,
      "id_str" : "431004831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1735387668\/DSC05143_normal.JPG",
      "id" : 431004831,
      "verified" : false
    }
  },
  "id" : 648519468252045318,
  "created_at" : "2015-09-28 15:27:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 105, 119 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/doZH73EFbw",
      "expanded_url" : "https:\/\/shar.es\/17kszY",
      "display_url" : "shar.es\/17kszY"
    } ]
  },
  "geo" : { },
  "id_str" : "648509000393355264",
  "text" : "Could you be so holy that you wouldn\u2019t be sad when your children go to hell? https:\/\/t.co\/doZH73EFbw via @UnfundieXians",
  "id" : 648509000393355264,
  "created_at" : "2015-09-28 14:46:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648505990049067009",
  "text" : "RT @Matth3ous: Someone needs to make a music video with Missy set to Voltaire\u2019s \u2018When You\u2019re Evil\u2019. #DoctorWho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648503879944941569",
    "text" : "Someone needs to make a music video with Missy set to Voltaire\u2019s \u2018When You\u2019re Evil\u2019. #DoctorWho",
    "id" : 648503879944941569,
    "created_at" : "2015-09-28 14:25:48 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 648505990049067009,
  "created_at" : "2015-09-28 14:34:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Dye",
      "screen_name" : "DYECASTING",
      "indices" : [ 3, 14 ],
      "id_str" : "17612162",
      "id" : 17612162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/RmKJlvGyqG",
      "expanded_url" : "http:\/\/buff.ly\/1MA3LUs",
      "display_url" : "buff.ly\/1MA3LUs"
    } ]
  },
  "geo" : { },
  "id_str" : "648504221072011273",
  "text" : "RT @DYECASTING: The Decline of Play and Rise in Children's Mental Disorders http:\/\/t.co\/RmKJlvGyqG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/RmKJlvGyqG",
        "expanded_url" : "http:\/\/buff.ly\/1MA3LUs",
        "display_url" : "buff.ly\/1MA3LUs"
      } ]
    },
    "geo" : { },
    "id_str" : "648407199836950528",
    "text" : "The Decline of Play and Rise in Children's Mental Disorders http:\/\/t.co\/RmKJlvGyqG",
    "id" : 648407199836950528,
    "created_at" : "2015-09-28 08:01:37 +0000",
    "user" : {
      "name" : "Eric Dye",
      "screen_name" : "DYECASTING",
      "protected" : false,
      "id_str" : "17612162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743068356341796864\/PnrJaBc4_normal.jpg",
      "id" : 17612162,
      "verified" : false
    }
  },
  "id" : 648504221072011273,
  "created_at" : "2015-09-28 14:27:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "indices" : [ 3, 12 ],
      "id_str" : "12642282",
      "id" : 12642282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dasparky\/status\/648277917265358848\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9QUQ4V6QLT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP8lVLPUcAAwTA1.jpg",
      "id_str" : "648277917089165312",
      "id" : 648277917089165312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP8lVLPUcAAwTA1.jpg",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1058,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1434,
        "resize" : "fit",
        "w" : 1388
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9QUQ4V6QLT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648278394694709248",
  "text" : "RT @dasparky: Recuperating hen has decided my leg is a fine perch. http:\/\/t.co\/9QUQ4V6QLT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dasparky\/status\/648277917265358848\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/9QUQ4V6QLT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP8lVLPUcAAwTA1.jpg",
        "id_str" : "648277917089165312",
        "id" : 648277917089165312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP8lVLPUcAAwTA1.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1058,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1434,
          "resize" : "fit",
          "w" : 1388
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9QUQ4V6QLT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648277917265358848",
    "text" : "Recuperating hen has decided my leg is a fine perch. http:\/\/t.co\/9QUQ4V6QLT",
    "id" : 648277917265358848,
    "created_at" : "2015-09-27 23:27:54 +0000",
    "user" : {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "protected" : false,
      "id_str" : "12642282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650055629004902400\/VG1lD7ep_normal.png",
      "id" : 12642282,
      "verified" : false
    }
  },
  "id" : 648278394694709248,
  "created_at" : "2015-09-27 23:29:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShoutYourAbortion",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648266630145941504",
  "text" : "RT @phinasays: The most accurate &amp; convincing argument for the rights of a woman to make decisions about her body #ShoutYourAbortion http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/scareaphina\/status\/646425271285977092\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/447EHROzXg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPiQW95W8AAjXVG.jpg",
        "id_str" : "646425270774329344",
        "id" : 646425270774329344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPiQW95W8AAjXVG.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1034,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 1034,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 843,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/447EHROzXg"
      } ],
      "hashtags" : [ {
        "text" : "ShoutYourAbortion",
        "indices" : [ 103, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646425271285977092",
    "text" : "The most accurate &amp; convincing argument for the rights of a woman to make decisions about her body #ShoutYourAbortion http:\/\/t.co\/447EHROzXg",
    "id" : 646425271285977092,
    "created_at" : "2015-09-22 20:46:09 +0000",
    "user" : {
      "name" : "Imperator Malizia",
      "screen_name" : "scareaphina",
      "protected" : false,
      "id_str" : "35119109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715172579519148032\/7Q1dbz-p_normal.jpg",
      "id" : 35119109,
      "verified" : false
    }
  },
  "id" : 648266630145941504,
  "created_at" : "2015-09-27 22:43:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/GnM89i4lSi",
      "expanded_url" : "http:\/\/rxoutreach.org\/find-your-medications",
      "display_url" : "rxoutreach.org\/find-your-medi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "648237089239232512",
  "geo" : { },
  "id_str" : "648238401762795520",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe http:\/\/t.co\/GnM89i4lSi",
  "id" : 648238401762795520,
  "in_reply_to_status_id" : 648237089239232512,
  "created_at" : "2015-09-27 20:50:53 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648236532277620736",
  "geo" : { },
  "id_str" : "648237546254827520",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe darn. my effexor was about $50 for 3 months.",
  "id" : 648237546254827520,
  "in_reply_to_status_id" : 648236532277620736,
  "created_at" : "2015-09-27 20:47:29 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/7RnMlhgSBY",
      "expanded_url" : "https:\/\/twitter.com\/Inspireert\/status\/648103775153037312",
      "display_url" : "twitter.com\/Inspireert\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648237021220204544",
  "text" : "RT @dhammagirl: Yes...\nThanks for the reminder! \uD83D\uDE09  https:\/\/t.co\/7RnMlhgSBY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/7RnMlhgSBY",
        "expanded_url" : "https:\/\/twitter.com\/Inspireert\/status\/648103775153037312",
        "display_url" : "twitter.com\/Inspireert\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648167248130084864",
    "text" : "Yes...\nThanks for the reminder! \uD83D\uDE09  https:\/\/t.co\/7RnMlhgSBY",
    "id" : 648167248130084864,
    "created_at" : "2015-09-27 16:08:08 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 648237021220204544,
  "created_at" : "2015-09-27 20:45:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/4JefbVZ3RV",
      "expanded_url" : "http:\/\/needymeds.org",
      "display_url" : "needymeds.org"
    } ]
  },
  "in_reply_to_status_id_str" : "648225721270333440",
  "geo" : { },
  "id_str" : "648235847184187392",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe also check http:\/\/t.co\/4JefbVZ3RV",
  "id" : 648235847184187392,
  "in_reply_to_status_id" : 648225721270333440,
  "created_at" : "2015-09-27 20:40:44 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/IK6hKHZDKO",
      "expanded_url" : "http:\/\/healthwarehouse.com",
      "display_url" : "healthwarehouse.com"
    } ]
  },
  "in_reply_to_status_id_str" : "648225721270333440",
  "geo" : { },
  "id_str" : "648235334883516416",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe check http:\/\/t.co\/IK6hKHZDKO .. i used to get my effexor thru them.",
  "id" : 648235334883516416,
  "in_reply_to_status_id" : 648225721270333440,
  "created_at" : "2015-09-27 20:38:42 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648152761033469952",
  "text" : "RT @ZachsMind: \"Its okay when THEY die, but when WE die, there's a problem.\" \n\nThat IS the problem.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648097484003106816",
    "text" : "\"Its okay when THEY die, but when WE die, there's a problem.\" \n\nThat IS the problem.",
    "id" : 648097484003106816,
    "created_at" : "2015-09-27 11:30:55 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 648152761033469952,
  "created_at" : "2015-09-27 15:10:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angie",
      "screen_name" : "SavvyBabii",
      "indices" : [ 3, 14 ],
      "id_str" : "54439786",
      "id" : 54439786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648152289979551744",
  "text" : "RT @SavvyBabii: If I quit now, I will be back to where I started, &amp; when I started I was desperately wishing to be where I am now. - Unknow\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 129, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648074656713449472",
    "text" : "If I quit now, I will be back to where I started, &amp; when I started I was desperately wishing to be where I am now. - Unknown #quote",
    "id" : 648074656713449472,
    "created_at" : "2015-09-27 10:00:13 +0000",
    "user" : {
      "name" : "Angie",
      "screen_name" : "SavvyBabii",
      "protected" : false,
      "id_str" : "54439786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663017940082663424\/isBfLuQx_normal.jpg",
      "id" : 54439786,
      "verified" : false
    }
  },
  "id" : 648152289979551744,
  "created_at" : "2015-09-27 15:08:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 96, 110 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frenchpolynesia",
      "indices" : [ 21, 37 ]
    }, {
      "text" : "GoodMorning",
      "indices" : [ 78, 90 ]
    }, {
      "text" : "YearInSpace",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648151271111806976",
  "text" : "RT @StationCDRKelly: #frenchpolynesia you are as remote as you are beautiful! #GoodMorning from @Space_Station. #YearInSpace http:\/\/t.co\/vj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 75, 89 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/648121141429731328\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/vjEW1hpCmX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP6Wvl2UcAIkF_X.jpg",
        "id_str" : "648121140745891842",
        "id" : 648121140745891842,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP6Wvl2UcAIkF_X.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/vjEW1hpCmX"
      } ],
      "hashtags" : [ {
        "text" : "frenchpolynesia",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "GoodMorning",
        "indices" : [ 57, 69 ]
      }, {
        "text" : "YearInSpace",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648121141429731328",
    "text" : "#frenchpolynesia you are as remote as you are beautiful! #GoodMorning from @Space_Station. #YearInSpace http:\/\/t.co\/vjEW1hpCmX",
    "id" : 648121141429731328,
    "created_at" : "2015-09-27 13:04:56 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 648151271111806976,
  "created_at" : "2015-09-27 15:04:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/647922763026558976\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/6A4Wvwuz8P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP3iS1NVAAA_M87.jpg",
      "id_str" : "647922734559723520",
      "id" : 647922734559723520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP3iS1NVAAA_M87.jpg",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/6A4Wvwuz8P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647923342805192704",
  "text" : "RT @parkstepp: Birds and the Sun...what a great combination.... http:\/\/t.co\/6A4Wvwuz8P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/647922763026558976\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/6A4Wvwuz8P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP3iS1NVAAA_M87.jpg",
        "id_str" : "647922734559723520",
        "id" : 647922734559723520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP3iS1NVAAA_M87.jpg",
        "sizes" : [ {
          "h" : 354,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/6A4Wvwuz8P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647922763026558976",
    "text" : "Birds and the Sun...what a great combination.... http:\/\/t.co\/6A4Wvwuz8P",
    "id" : 647922763026558976,
    "created_at" : "2015-09-26 23:56:39 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 647923342805192704,
  "created_at" : "2015-09-26 23:58:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "[Au]",
      "screen_name" : "thronesofgold",
      "indices" : [ 3, 17 ],
      "id_str" : "2206507579",
      "id" : 2206507579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647921480072871937",
  "text" : "RT @thronesofgold: If people pushed what everyone else has told them aside and looked at what they truly believe, they'd find many things w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "643578902976159746",
    "geo" : { },
    "id_str" : "643579795918340097",
    "in_reply_to_user_id" : 2206507579,
    "text" : "If people pushed what everyone else has told them aside and looked at what they truly believe, they'd find many things which do not align.",
    "id" : 643579795918340097,
    "in_reply_to_status_id" : 643578902976159746,
    "created_at" : "2015-09-15 00:19:15 +0000",
    "in_reply_to_screen_name" : "thronesofgold",
    "in_reply_to_user_id_str" : "2206507579",
    "user" : {
      "name" : "[Au]",
      "screen_name" : "thronesofgold",
      "protected" : false,
      "id_str" : "2206507579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722624267053981696\/llth-bhJ_normal.jpg",
      "id" : 2206507579,
      "verified" : false
    }
  },
  "id" : 647921480072871937,
  "created_at" : "2015-09-26 23:51:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643234512197914624",
  "geo" : { },
  "id_str" : "647893561434836992",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia a lot of what ppl see or say is projection...",
  "id" : 647893561434836992,
  "in_reply_to_status_id" : 643234512197914624,
  "created_at" : "2015-09-26 22:00:36 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647863029351055360",
  "geo" : { },
  "id_str" : "647887416628510720",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater awww.. sweet pic!",
  "id" : 647887416628510720,
  "in_reply_to_status_id" : 647863029351055360,
  "created_at" : "2015-09-26 21:36:11 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/647858345379004416\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/2vaVHCLWUD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP2nu2NUAAAR0FA.jpg",
      "id_str" : "647858344678391808",
      "id" : 647858344678391808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP2nu2NUAAAR0FA.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2vaVHCLWUD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647859973947551744",
  "text" : "RT @mercola: Despite its convenience, instant noodles are NEVER a smart food choice. http:\/\/t.co\/2vaVHCLWUD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/647858345379004416\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/2vaVHCLWUD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP2nu2NUAAAR0FA.jpg",
        "id_str" : "647858344678391808",
        "id" : 647858344678391808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP2nu2NUAAAR0FA.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2vaVHCLWUD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647858345379004416",
    "text" : "Despite its convenience, instant noodles are NEVER a smart food choice. http:\/\/t.co\/2vaVHCLWUD",
    "id" : 647858345379004416,
    "created_at" : "2015-09-26 19:40:40 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 647859973947551744,
  "created_at" : "2015-09-26 19:47:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647849273346912257",
  "text" : "i hope i got karma points for suffering thru 20 min of vvs15 video.. ugh.. why oh why do i do this to myself??",
  "id" : 647849273346912257,
  "created_at" : "2015-09-26 19:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647836829165686784",
  "text" : "ppl on FB liking a post \"now for some good news\" europe's largest mosque on fire. wtf is wrong w ppl?? o-O",
  "id" : 647836829165686784,
  "created_at" : "2015-09-26 18:15:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gamble",
      "screen_name" : "Farnell_Simmys",
      "indices" : [ 3, 18 ],
      "id_str" : "338444354",
      "id" : 338444354
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Farnell_Simmys\/status\/647801088586969088\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/UrhwELKPrF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP1zP1UW8AADsvD.jpg",
      "id_str" : "647800637258919936",
      "id" : 647800637258919936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP1zP1UW8AADsvD.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UrhwELKPrF"
    } ],
    "hashtags" : [ {
      "text" : "simmental",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647820107247431680",
  "text" : "RT @Farnell_Simmys: The latest thing in cow brushes!\n#simmental http:\/\/t.co\/UrhwELKPrF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Farnell_Simmys\/status\/647801088586969088\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/UrhwELKPrF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP1zP1UW8AADsvD.jpg",
        "id_str" : "647800637258919936",
        "id" : 647800637258919936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP1zP1UW8AADsvD.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1161,
          "resize" : "fit",
          "w" : 2064
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/UrhwELKPrF"
      } ],
      "hashtags" : [ {
        "text" : "simmental",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647801088586969088",
    "text" : "The latest thing in cow brushes!\n#simmental http:\/\/t.co\/UrhwELKPrF",
    "id" : 647801088586969088,
    "created_at" : "2015-09-26 15:53:09 +0000",
    "user" : {
      "name" : "Alan Gamble",
      "screen_name" : "Farnell_Simmys",
      "protected" : false,
      "id_str" : "338444354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688803447668379648\/oPoqpGoV_normal.jpg",
      "id" : 338444354,
      "verified" : false
    }
  },
  "id" : 647820107247431680,
  "created_at" : "2015-09-26 17:08:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stereo Williams",
      "screen_name" : "stereowilliams",
      "indices" : [ 3, 18 ],
      "id_str" : "24245360",
      "id" : 24245360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647816619297738753",
  "text" : "RT @stereowilliams: White pride, straight pride, \"meninists;\" it's all the same thing. A reaction to marginalized people's refusal to stay \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647720983118368769",
    "text" : "White pride, straight pride, \"meninists;\" it's all the same thing. A reaction to marginalized people's refusal to stay on the margins.",
    "id" : 647720983118368769,
    "created_at" : "2015-09-26 10:34:51 +0000",
    "user" : {
      "name" : "Stereo Williams",
      "screen_name" : "stereowilliams",
      "protected" : false,
      "id_str" : "24245360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800085339838840832\/EpCahzZH_normal.jpg",
      "id" : 24245360,
      "verified" : false
    }
  },
  "id" : 647816619297738753,
  "created_at" : "2015-09-26 16:54:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birding Ninja",
      "screen_name" : "BirdingNinja",
      "indices" : [ 3, 16 ],
      "id_str" : "2655858858",
      "id" : 2655858858
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BirdingNinja\/status\/646656943847661568\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/JnkxDbYLNz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPljECoU8AAbU3J.jpg",
      "id_str" : "646656942581018624",
      "id" : 646656942581018624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPljECoU8AAbU3J.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/JnkxDbYLNz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/uNtel332Al",
      "expanded_url" : "http:\/\/birding.ninja\/2015\/09\/23\/swing",
      "display_url" : "birding.ninja\/2015\/09\/23\/swi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647805026577027072",
  "text" : "RT @BirdingNinja: Swing http:\/\/t.co\/uNtel332Al http:\/\/t.co\/JnkxDbYLNz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdingNinja\/status\/646656943847661568\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/JnkxDbYLNz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPljECoU8AAbU3J.jpg",
        "id_str" : "646656942581018624",
        "id" : 646656942581018624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPljECoU8AAbU3J.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/JnkxDbYLNz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/uNtel332Al",
        "expanded_url" : "http:\/\/birding.ninja\/2015\/09\/23\/swing",
        "display_url" : "birding.ninja\/2015\/09\/23\/swi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "646656943847661568",
    "text" : "Swing http:\/\/t.co\/uNtel332Al http:\/\/t.co\/JnkxDbYLNz",
    "id" : 646656943847661568,
    "created_at" : "2015-09-23 12:06:44 +0000",
    "user" : {
      "name" : "Birding Ninja",
      "screen_name" : "BirdingNinja",
      "protected" : false,
      "id_str" : "2655858858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490014454382223360\/TY_yLeJg_normal.png",
      "id" : 2655858858,
      "verified" : false
    }
  },
  "id" : 647805026577027072,
  "created_at" : "2015-09-26 16:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birding Ninja",
      "screen_name" : "BirdingNinja",
      "indices" : [ 3, 16 ],
      "id_str" : "2655858858",
      "id" : 2655858858
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BirdingNinja\/status\/647019618771439616\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/wkJLOm3pTG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPqs6flUAAAyJTt.jpg",
      "id_str" : "647019617391476736",
      "id" : 647019617391476736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPqs6flUAAAyJTt.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/wkJLOm3pTG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/rPCPiwFYMd",
      "expanded_url" : "http:\/\/birding.ninja\/2015\/09\/24\/ceiling-bird",
      "display_url" : "birding.ninja\/2015\/09\/24\/cei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647804985678385152",
  "text" : "RT @BirdingNinja: Ceiling Bird http:\/\/t.co\/rPCPiwFYMd http:\/\/t.co\/wkJLOm3pTG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdingNinja\/status\/647019618771439616\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/wkJLOm3pTG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPqs6flUAAAyJTt.jpg",
        "id_str" : "647019617391476736",
        "id" : 647019617391476736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPqs6flUAAAyJTt.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/wkJLOm3pTG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/rPCPiwFYMd",
        "expanded_url" : "http:\/\/birding.ninja\/2015\/09\/24\/ceiling-bird",
        "display_url" : "birding.ninja\/2015\/09\/24\/cei\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647019618771439616",
    "text" : "Ceiling Bird http:\/\/t.co\/rPCPiwFYMd http:\/\/t.co\/wkJLOm3pTG",
    "id" : 647019618771439616,
    "created_at" : "2015-09-24 12:07:52 +0000",
    "user" : {
      "name" : "Birding Ninja",
      "screen_name" : "BirdingNinja",
      "protected" : false,
      "id_str" : "2655858858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490014454382223360\/TY_yLeJg_normal.png",
      "id" : 2655858858,
      "verified" : false
    }
  },
  "id" : 647804985678385152,
  "created_at" : "2015-09-26 16:08:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/DTWU3mqeX3",
      "expanded_url" : "http:\/\/randalrauser.com\/2015\/09\/gods-not-dead-in-7-minutes\/",
      "display_url" : "randalrauser.com\/2015\/09\/gods-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647789790067298304",
  "text" : "God\u2019s not Dead in 7 Minutes http:\/\/t.co\/DTWU3mqeX3",
  "id" : 647789790067298304,
  "created_at" : "2015-09-26 15:08:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u305F\uFF08*\u3086\u304D\uFF09",
      "screen_name" : "utabun321",
      "indices" : [ 3, 13 ],
      "id_str" : "2402999881",
      "id" : 2402999881
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/utabun321\/status\/647388305441452032\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/O43gQmJ3fg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPv8NcBU8AEyAwl.jpg",
      "id_str" : "647388279248056321",
      "id" : 647388279248056321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPv8NcBU8AEyAwl.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O43gQmJ3fg"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/utabun321\/status\/647388305441452032\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/O43gQmJ3fg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPv8Nc0UwAAnp0s.jpg",
      "id_str" : "647388279461953536",
      "id" : 647388279461953536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPv8Nc0UwAAnp0s.jpg",
      "sizes" : [ {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/O43gQmJ3fg"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/utabun321\/status\/647388305441452032\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/O43gQmJ3fg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPv8NdeUwAQwz3G.jpg",
      "id_str" : "647388279638114308",
      "id" : 647388279638114308,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPv8NdeUwAQwz3G.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O43gQmJ3fg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647601193418661888",
  "text" : "RT @utabun321: \u3069\u3046\u304B\u3057\u3089\u3053\u306E\u65B0\u3057\u3044\u6307\u8F2A\u2026 http:\/\/t.co\/O43gQmJ3fg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/utabun321\/status\/647388305441452032\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/O43gQmJ3fg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPv8NcBU8AEyAwl.jpg",
        "id_str" : "647388279248056321",
        "id" : 647388279248056321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPv8NcBU8AEyAwl.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/O43gQmJ3fg"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/utabun321\/status\/647388305441452032\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/O43gQmJ3fg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPv8Nc0UwAAnp0s.jpg",
        "id_str" : "647388279461953536",
        "id" : 647388279461953536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPv8Nc0UwAAnp0s.jpg",
        "sizes" : [ {
          "h" : 1023,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/O43gQmJ3fg"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/utabun321\/status\/647388305441452032\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/O43gQmJ3fg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPv8NdeUwAQwz3G.jpg",
        "id_str" : "647388279638114308",
        "id" : 647388279638114308,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPv8NdeUwAQwz3G.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/O43gQmJ3fg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647388305441452032",
    "text" : "\u3069\u3046\u304B\u3057\u3089\u3053\u306E\u65B0\u3057\u3044\u6307\u8F2A\u2026 http:\/\/t.co\/O43gQmJ3fg",
    "id" : 647388305441452032,
    "created_at" : "2015-09-25 12:32:54 +0000",
    "user" : {
      "name" : "\u3046\u305F\uFF08*\u3086\u304D\uFF09",
      "screen_name" : "utabun321",
      "protected" : false,
      "id_str" : "2402999881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644728804053659649\/rRJphHg9_normal.jpg",
      "id" : 2402999881,
      "verified" : false
    }
  },
  "id" : 647601193418661888,
  "created_at" : "2015-09-26 02:38:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOOD",
      "screen_name" : "good",
      "indices" : [ 93, 98 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/g3Szox9Fcb",
      "expanded_url" : "http:\/\/magazine.good.is\/articles\/super-fast-camera-works-at-light-speed",
      "display_url" : "magazine.good.is\/articles\/super\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647541763201212417",
  "text" : "It has a resolution rate of one frame per trillionth of a second. http:\/\/t.co\/g3Szox9Fcb via @good",
  "id" : 647541763201212417,
  "created_at" : "2015-09-25 22:42:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647525804633665537",
  "geo" : { },
  "id_str" : "647531395276009472",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley pretty print",
  "id" : 647531395276009472,
  "in_reply_to_status_id" : 647525804633665537,
  "created_at" : "2015-09-25 22:01:29 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647510113675313153",
  "text" : "RT @TheGodLight: You are wiser than you think, just slow your thoughts down, &amp; when the inner noise ceases, wisdom will have chance to spea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647508499921039360",
    "text" : "You are wiser than you think, just slow your thoughts down, &amp; when the inner noise ceases, wisdom will have chance to speak.",
    "id" : 647508499921039360,
    "created_at" : "2015-09-25 20:30:31 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 647510113675313153,
  "created_at" : "2015-09-25 20:36:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "indices" : [ 3, 14 ],
      "id_str" : "220895419",
      "id" : 220895419
    }, {
      "name" : "Bob's Red Mill",
      "screen_name" : "BobsRedMill",
      "indices" : [ 86, 98 ],
      "id_str" : "16569176",
      "id" : 16569176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "riseandshine",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/aWyMWQnXSD",
      "expanded_url" : "http:\/\/www.wellplated.com\/chocolate-oatmeal\/",
      "display_url" : "wellplated.com\/chocolate-oatm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647507789007429632",
  "text" : "RT @WellPlated: Oatmeal that'll keep chocoholics and health nuts happy! #riseandshine @BobsRedMill http:\/\/t.co\/aWyMWQnXSD http:\/\/t.co\/91ESU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bob's Red Mill",
        "screen_name" : "BobsRedMill",
        "indices" : [ 70, 82 ],
        "id_str" : "16569176",
        "id" : 16569176
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WellPlated\/status\/647503113960718336\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/91ESULY1qy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPxkpq7XAAAUt2H.jpg",
        "id_str" : "647503113495183360",
        "id" : 647503113495183360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPxkpq7XAAAUt2H.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/91ESULY1qy"
      } ],
      "hashtags" : [ {
        "text" : "riseandshine",
        "indices" : [ 56, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/aWyMWQnXSD",
        "expanded_url" : "http:\/\/www.wellplated.com\/chocolate-oatmeal\/",
        "display_url" : "wellplated.com\/chocolate-oatm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647503113960718336",
    "text" : "Oatmeal that'll keep chocoholics and health nuts happy! #riseandshine @BobsRedMill http:\/\/t.co\/aWyMWQnXSD http:\/\/t.co\/91ESULY1qy",
    "id" : 647503113960718336,
    "created_at" : "2015-09-25 20:09:07 +0000",
    "user" : {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "protected" : false,
      "id_str" : "220895419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621711174824914944\/lOVoCMeS_normal.jpg",
      "id" : 220895419,
      "verified" : false
    }
  },
  "id" : 647507789007429632,
  "created_at" : "2015-09-25 20:27:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/a2PUUtMl03",
      "expanded_url" : "https:\/\/twitter.com\/ducksandclucks\/status\/647503274002751489",
      "display_url" : "twitter.com\/ducksandclucks\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647506408406188032",
  "text" : "adorable https:\/\/t.co\/a2PUUtMl03",
  "id" : 647506408406188032,
  "created_at" : "2015-09-25 20:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/G4NY5cQ6md",
      "expanded_url" : "https:\/\/twitter.com\/VeggieTales\/status\/647504601109757952",
      "display_url" : "twitter.com\/VeggieTales\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647505895153401856",
  "text" : "this is why kindness, compassion so important, no? https:\/\/t.co\/G4NY5cQ6md",
  "id" : 647505895153401856,
  "created_at" : "2015-09-25 20:20:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647493851079385088",
  "text" : "say what?? why? &gt; \"its the socialist among us that are the problem\" - ben carson vvs15",
  "id" : 647493851079385088,
  "created_at" : "2015-09-25 19:32:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647482525628133381",
  "geo" : { },
  "id_str" : "647484382157086720",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves but yr smart, talented and pretty darn nice. i wish success would find you.",
  "id" : 647484382157086720,
  "in_reply_to_status_id" : 647482525628133381,
  "created_at" : "2015-09-25 18:54:41 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647482525628133381",
  "geo" : { },
  "id_str" : "647484069534658561",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves i understand yr frustration as anything I try has no (or negative) success.. gah.",
  "id" : 647484069534658561,
  "in_reply_to_status_id" : 647482525628133381,
  "created_at" : "2015-09-25 18:53:26 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Life Done Quick",
      "screen_name" : "SpeedRunsLife",
      "indices" : [ 3, 17 ],
      "id_str" : "3399591687",
      "id" : 3399591687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647482760425275392",
  "text" : "RT @SpeedRunsLife: The existential crisis status can waste anywhere from 4 hours to 40 years depending on the severity, so avoiding this st\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630412041975660545",
    "text" : "The existential crisis status can waste anywhere from 4 hours to 40 years depending on the severity, so avoiding this status is recommended.",
    "id" : 630412041975660545,
    "created_at" : "2015-08-09 16:15:17 +0000",
    "user" : {
      "name" : "Real Life Done Quick",
      "screen_name" : "SpeedRunsLife",
      "protected" : false,
      "id_str" : "3399591687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660966512518299648\/WZ7CXJBK_normal.png",
      "id" : 3399591687,
      "verified" : false
    }
  },
  "id" : 647482760425275392,
  "created_at" : "2015-09-25 18:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647459452363272193",
  "geo" : { },
  "id_str" : "647482605462532096",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater nice!!",
  "id" : 647482605462532096,
  "in_reply_to_status_id" : 647459452363272193,
  "created_at" : "2015-09-25 18:47:37 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "indices" : [ 3, 19 ],
      "id_str" : "2530698811",
      "id" : 2530698811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/647444537984614400\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/DQEteH20Qj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwvS3EWIAAbZtD.jpg",
      "id_str" : "647444447500836864",
      "id" : 647444447500836864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwvS3EWIAAbZtD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/DQEteH20Qj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647482195112800257",
  "text" : "RT @JRfromStrickley: Lugless Douglas\uD83D\uDE00 http:\/\/t.co\/DQEteH20Qj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/647444537984614400\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/DQEteH20Qj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwvS3EWIAAbZtD.jpg",
        "id_str" : "647444447500836864",
        "id" : 647444447500836864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwvS3EWIAAbZtD.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/DQEteH20Qj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647444537984614400",
    "text" : "Lugless Douglas\uD83D\uDE00 http:\/\/t.co\/DQEteH20Qj",
    "id" : 647444537984614400,
    "created_at" : "2015-09-25 16:16:21 +0000",
    "user" : {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "protected" : false,
      "id_str" : "2530698811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682844561933217792\/DmT71D0G_normal.jpg",
      "id" : 2530698811,
      "verified" : false
    }
  },
  "id" : 647482195112800257,
  "created_at" : "2015-09-25 18:45:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647481118330105856",
  "geo" : { },
  "id_str" : "647482159939325952",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves lol.. your relationship with social media.. glad you'll stay on twitter! : )",
  "id" : 647482159939325952,
  "in_reply_to_status_id" : 647481118330105856,
  "created_at" : "2015-09-25 18:45:51 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 3, 19 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/647464582169161729\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/pZ1iCXcl5i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPxBSjpXAAAkAyI.jpg",
      "id_str" : "647464233496674304",
      "id" : 647464233496674304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPxBSjpXAAAkAyI.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/pZ1iCXcl5i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647465948010692609",
  "text" : "RT @hilltopfarmgirl: Belties emerging from the mist. http:\/\/t.co\/pZ1iCXcl5i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/647464582169161729\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/pZ1iCXcl5i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPxBSjpXAAAkAyI.jpg",
        "id_str" : "647464233496674304",
        "id" : 647464233496674304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPxBSjpXAAAkAyI.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/pZ1iCXcl5i"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647464582169161729",
    "text" : "Belties emerging from the mist. http:\/\/t.co\/pZ1iCXcl5i",
    "id" : 647464582169161729,
    "created_at" : "2015-09-25 17:36:00 +0000",
    "user" : {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "protected" : false,
      "id_str" : "457436503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3491566457\/61244b7682c638ad4b0a097321ae762e_normal.jpeg",
      "id" : 457436503,
      "verified" : false
    }
  },
  "id" : 647465948010692609,
  "created_at" : "2015-09-25 17:41:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Meyers",
      "screen_name" : "HaroldThomasMe2",
      "indices" : [ 3, 19 ],
      "id_str" : "3749061255",
      "id" : 3749061255
    }, {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 21, 37 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647465838396731392",
  "text" : "RT @HaroldThomasMe2: @TheHudsonValley my buddy Mr.White Cloud,is a therapy bunny,today he is visiting a nursing home in festive pumpkin htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Hudson Valley",
        "screen_name" : "TheHudsonValley",
        "indices" : [ 0, 16 ],
        "id_str" : "102313523",
        "id" : 102313523
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HaroldThomasMe2\/status\/646841467277824000\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xuOiJsUi3H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPoK3_aUYAAGCfP.jpg",
        "id_str" : "646841453511991296",
        "id" : 646841453511991296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPoK3_aUYAAGCfP.jpg",
        "sizes" : [ {
          "h" : 638,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xuOiJsUi3H"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "646806579241713664",
    "geo" : { },
    "id_str" : "646841467277824000",
    "in_reply_to_user_id" : 102313523,
    "text" : "@TheHudsonValley my buddy Mr.White Cloud,is a therapy bunny,today he is visiting a nursing home in festive pumpkin http:\/\/t.co\/xuOiJsUi3H",
    "id" : 646841467277824000,
    "in_reply_to_status_id" : 646806579241713664,
    "created_at" : "2015-09-24 00:19:58 +0000",
    "in_reply_to_screen_name" : "TheHudsonValley",
    "in_reply_to_user_id_str" : "102313523",
    "user" : {
      "name" : "Tommy Meyers",
      "screen_name" : "HaroldThomasMe2",
      "protected" : false,
      "id_str" : "3749061255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735975330729611264\/uxsipNbN_normal.jpg",
      "id" : 3749061255,
      "verified" : false
    }
  },
  "id" : 647465838396731392,
  "created_at" : "2015-09-25 17:40:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jena C.",
      "screen_name" : "JenaC2",
      "indices" : [ 3, 10 ],
      "id_str" : "2430564295",
      "id" : 2430564295
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JenaC2\/status\/647404627105746944\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/MyP7PSOg1y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwLEPEVEAA2zfp.jpg",
      "id_str" : "647404613826580480",
      "id" : 647404613826580480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwLEPEVEAA2zfp.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/MyP7PSOg1y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647465658536562689",
  "text" : "RT @JenaC2: \uD83D\uDC96\uD83D\uDC9A\uD83D\uDC9BFound a comfy spot:)\uD83D\uDC96\uD83D\uDC9B\uD83D\uDC9A http:\/\/t.co\/MyP7PSOg1y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenaC2\/status\/647404627105746944\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/MyP7PSOg1y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwLEPEVEAA2zfp.jpg",
        "id_str" : "647404613826580480",
        "id" : 647404613826580480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwLEPEVEAA2zfp.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/MyP7PSOg1y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "647403775464857600",
    "geo" : { },
    "id_str" : "647404627105746944",
    "in_reply_to_user_id" : 2430564295,
    "text" : "\uD83D\uDC96\uD83D\uDC9A\uD83D\uDC9BFound a comfy spot:)\uD83D\uDC96\uD83D\uDC9B\uD83D\uDC9A http:\/\/t.co\/MyP7PSOg1y",
    "id" : 647404627105746944,
    "in_reply_to_status_id" : 647403775464857600,
    "created_at" : "2015-09-25 13:37:45 +0000",
    "in_reply_to_screen_name" : "JenaC2",
    "in_reply_to_user_id_str" : "2430564295",
    "user" : {
      "name" : "Jena C.",
      "screen_name" : "JenaC2",
      "protected" : false,
      "id_str" : "2430564295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486298165872558080\/iIbifN84_normal.jpeg",
      "id" : 2430564295,
      "verified" : false
    }
  },
  "id" : 647465658536562689,
  "created_at" : "2015-09-25 17:40:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "gneicco",
      "indices" : [ 3, 11 ],
      "id_str" : "20819636",
      "id" : 20819636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647458530199511040",
  "text" : "RT @gneicco: Global warming is an eviction notice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647451292755890180",
    "text" : "Global warming is an eviction notice.",
    "id" : 647451292755890180,
    "created_at" : "2015-09-25 16:43:11 +0000",
    "user" : {
      "name" : "Dave",
      "screen_name" : "gneicco",
      "protected" : false,
      "id_str" : "20819636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503656271887605760\/a60IvDzL_normal.jpeg",
      "id" : 20819636,
      "verified" : false
    }
  },
  "id" : 647458530199511040,
  "created_at" : "2015-09-25 17:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 0, 9 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647457258587201536",
  "geo" : { },
  "id_str" : "647458440156217344",
  "in_reply_to_user_id" : 64009474,
  "text" : "@Adenovir i think ive read thrillers with this premise...",
  "id" : 647458440156217344,
  "in_reply_to_status_id" : 647457258587201536,
  "created_at" : "2015-09-25 17:11:35 +0000",
  "in_reply_to_screen_name" : "Adenovir",
  "in_reply_to_user_id_str" : "64009474",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/2L9g6YcsyC",
      "expanded_url" : "https:\/\/www.facebook.com\/RBReich\/videos\/1072031682809427\/?comment_id=1072382752774320&offset=0&total_comments=530&comment_tracking=",
      "display_url" : "facebook.com\/RBReich\/videos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647442370947076096",
  "text" : "constructs of mind comment on Robert Reich - Saving Capitalism: For the Many, Not the Few https:\/\/t.co\/2L9g6YcsyC\u007B\"tn\":\"R9\"\u007D&amp;_ts=1443197257",
  "id" : 647442370947076096,
  "created_at" : "2015-09-25 16:07:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/nYXdd4THsn",
      "expanded_url" : "http:\/\/reverbpress.com\/politics\/economics\/robert-reich-explains-sanders-policies-cost-america-nothing-video\/",
      "display_url" : "reverbpress.com\/politics\/econo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647440261677772804",
  "text" : "Robert Reich Explains Why Sanders\u2019 Policies Would Cost America Nothing (VIDEO) http:\/\/t.co\/nYXdd4THsn",
  "id" : 647440261677772804,
  "created_at" : "2015-09-25 15:59:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/VXpLhZCwsg",
      "expanded_url" : "https:\/\/twitter.com\/MonaLimah\/status\/647420009740943360",
      "display_url" : "twitter.com\/MonaLimah\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647435388706009088",
  "text" : "wtfff is right.. jeez.. https:\/\/t.co\/VXpLhZCwsg",
  "id" : 647435388706009088,
  "created_at" : "2015-09-25 15:40:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/647430849542008832\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/kG1R6ndzSu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwi5VjUAAApfDR.jpg",
      "id_str" : "647430814867652608",
      "id" : 647430814867652608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwi5VjUAAApfDR.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kG1R6ndzSu"
    } ],
    "hashtags" : [ {
      "text" : "flowers",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "myyard",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647433702310588416",
  "text" : "RT @rm123077: Autumn Joy Sedum #flowers #myyard http:\/\/t.co\/kG1R6ndzSu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/647430849542008832\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/kG1R6ndzSu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwi5VjUAAApfDR.jpg",
        "id_str" : "647430814867652608",
        "id" : 647430814867652608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwi5VjUAAApfDR.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kG1R6ndzSu"
      } ],
      "hashtags" : [ {
        "text" : "flowers",
        "indices" : [ 17, 25 ]
      }, {
        "text" : "myyard",
        "indices" : [ 26, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647430849542008832",
    "text" : "Autumn Joy Sedum #flowers #myyard http:\/\/t.co\/kG1R6ndzSu",
    "id" : 647430849542008832,
    "created_at" : "2015-09-25 15:21:57 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 647433702310588416,
  "created_at" : "2015-09-25 15:33:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647416828252299264",
  "text" : "dd: mom, you need to stop and smell the roses me: when im dead dd: but they're not the same roses! you need to smell these roses!",
  "id" : 647416828252299264,
  "created_at" : "2015-09-25 14:26:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647254896513683458",
  "geo" : { },
  "id_str" : "647415003243507712",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe dont panic! ((hugs))",
  "id" : 647415003243507712,
  "in_reply_to_status_id" : 647254896513683458,
  "created_at" : "2015-09-25 14:18:59 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QuantumNothingness",
      "screen_name" : "fuelandseed",
      "indices" : [ 3, 15 ],
      "id_str" : "497652988",
      "id" : 497652988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647410863905873920",
  "text" : "RT @fuelandseed: Spoiler alert: You die at the end.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647296972265648128",
    "text" : "Spoiler alert: You die at the end.",
    "id" : 647296972265648128,
    "created_at" : "2015-09-25 06:29:59 +0000",
    "user" : {
      "name" : "QuantumNothingness",
      "screen_name" : "fuelandseed",
      "protected" : false,
      "id_str" : "497652988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745739382565416960\/WMxCUN8u_normal.jpg",
      "id" : 497652988,
      "verified" : false
    }
  },
  "id" : 647410863905873920,
  "created_at" : "2015-09-25 14:02:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature Conservancy",
      "screen_name" : "nature_org",
      "indices" : [ 3, 14 ],
      "id_str" : "17596622",
      "id" : 17596622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ocfVUv5uRh",
      "expanded_url" : "http:\/\/bit.ly\/1gNzIxd",
      "display_url" : "bit.ly\/1gNzIxd"
    } ]
  },
  "geo" : { },
  "id_str" : "647221994895900673",
  "text" : "RT @nature_org: For the 1st time in a century, scientists found the most elusive bird: the Night Parrot. http:\/\/t.co\/ocfVUv5uRh http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nature_org\/status\/647171657371484160\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/rimV7iFSJx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPs3MYOUcAAbgkT.jpg",
        "id_str" : "647171657258266624",
        "id" : 647171657258266624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPs3MYOUcAAbgkT.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/rimV7iFSJx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/ocfVUv5uRh",
        "expanded_url" : "http:\/\/bit.ly\/1gNzIxd",
        "display_url" : "bit.ly\/1gNzIxd"
      } ]
    },
    "geo" : { },
    "id_str" : "647171657371484160",
    "text" : "For the 1st time in a century, scientists found the most elusive bird: the Night Parrot. http:\/\/t.co\/ocfVUv5uRh http:\/\/t.co\/rimV7iFSJx",
    "id" : 647171657371484160,
    "created_at" : "2015-09-24 22:12:01 +0000",
    "user" : {
      "name" : "Nature Conservancy",
      "screen_name" : "nature_org",
      "protected" : false,
      "id_str" : "17596622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608258767092908033\/njR5TGTo_normal.png",
      "id" : 17596622,
      "verified" : true
    }
  },
  "id" : 647221994895900673,
  "created_at" : "2015-09-25 01:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/647220304683663360\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/V8ppldu3iP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPtjcApUAAAIdXl.jpg",
      "id_str" : "647220304318562304",
      "id" : 647220304318562304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPtjcApUAAAIdXl.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/V8ppldu3iP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/MqNRWDSsrT",
      "expanded_url" : "http:\/\/ow.ly\/SvmFs",
      "display_url" : "ow.ly\/SvmFs"
    } ]
  },
  "geo" : { },
  "id_str" : "647221442564751361",
  "text" : "RT @mercola: 6 reasons to ditch regular toothpaste for coconut oil. http:\/\/t.co\/MqNRWDSsrT http:\/\/t.co\/V8ppldu3iP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/647220304683663360\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/V8ppldu3iP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPtjcApUAAAIdXl.jpg",
        "id_str" : "647220304318562304",
        "id" : 647220304318562304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPtjcApUAAAIdXl.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/V8ppldu3iP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/MqNRWDSsrT",
        "expanded_url" : "http:\/\/ow.ly\/SvmFs",
        "display_url" : "ow.ly\/SvmFs"
      } ]
    },
    "geo" : { },
    "id_str" : "647220304683663360",
    "text" : "6 reasons to ditch regular toothpaste for coconut oil. http:\/\/t.co\/MqNRWDSsrT http:\/\/t.co\/V8ppldu3iP",
    "id" : 647220304683663360,
    "created_at" : "2015-09-25 01:25:20 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 647221442564751361,
  "created_at" : "2015-09-25 01:29:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SugarhousePark",
      "indices" : [ 56, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647219132144951296",
  "text" : "RT @ducksandclucks: Saying hello to the Canada geese at #SugarhousePark - Check out the attitude I'm getting from the\u2026 https:\/\/t.co\/JnZ24kJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SugarhousePark",
        "indices" : [ 36, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/JnZ24kJMvz",
        "expanded_url" : "https:\/\/instagram.com\/p\/8CM1YLBH3F\/",
        "display_url" : "instagram.com\/p\/8CM1YLBH3F\/"
      } ]
    },
    "geo" : { },
    "id_str" : "647214263128457216",
    "text" : "Saying hello to the Canada geese at #SugarhousePark - Check out the attitude I'm getting from the\u2026 https:\/\/t.co\/JnZ24kJMvz",
    "id" : 647214263128457216,
    "created_at" : "2015-09-25 01:01:19 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 647219132144951296,
  "created_at" : "2015-09-25 01:20:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canadageese",
      "indices" : [ 53, 65 ]
    }, {
      "text" : "SugarhousePark",
      "indices" : [ 66, 81 ]
    }, {
      "text" : "Sugarhouse",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/QdbcUBVwoZ",
      "expanded_url" : "https:\/\/instagram.com\/p\/8CN64FBH5Z\/",
      "display_url" : "instagram.com\/p\/8CN64FBH5Z\/"
    } ]
  },
  "geo" : { },
  "id_str" : "647218087448678404",
  "text" : "RT @ducksandclucks: Geese as far as the eye can see. #canadageese #SugarhousePark #Sugarhouse https:\/\/t.co\/QdbcUBVwoZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "canadageese",
        "indices" : [ 33, 45 ]
      }, {
        "text" : "SugarhousePark",
        "indices" : [ 46, 61 ]
      }, {
        "text" : "Sugarhouse",
        "indices" : [ 62, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/QdbcUBVwoZ",
        "expanded_url" : "https:\/\/instagram.com\/p\/8CN64FBH5Z\/",
        "display_url" : "instagram.com\/p\/8CN64FBH5Z\/"
      } ]
    },
    "geo" : { },
    "id_str" : "647216648013922304",
    "text" : "Geese as far as the eye can see. #canadageese #SugarhousePark #Sugarhouse https:\/\/t.co\/QdbcUBVwoZ",
    "id" : 647216648013922304,
    "created_at" : "2015-09-25 01:10:48 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 647218087448678404,
  "created_at" : "2015-09-25 01:16:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/y1GjS36jAW",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/647182237771784192",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647184535357140992",
  "text" : "beautiful https:\/\/t.co\/y1GjS36jAW",
  "id" : 647184535357140992,
  "created_at" : "2015-09-24 23:03:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalesbrad Holsteins",
      "screen_name" : "Dalesbrad007",
      "indices" : [ 3, 16 ],
      "id_str" : "1618461726",
      "id" : 1618461726
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sheepdogbob",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647159451103965184",
  "text" : "RT @Dalesbrad007: This old Swale ewe refused to walk home, so Bob thought, if you can't beat em, join em!!\r#sheepdogbob http:\/\/t.co\/YDLL40c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dalesbrad007\/status\/647144211607891968\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/YDLL40cBaZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPseOvOUcAAC4Hg.jpg",
        "id_str" : "647144210001326080",
        "id" : 647144210001326080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPseOvOUcAAC4Hg.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YDLL40cBaZ"
      } ],
      "hashtags" : [ {
        "text" : "sheepdogbob",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647144211607891968",
    "text" : "This old Swale ewe refused to walk home, so Bob thought, if you can't beat em, join em!!\r#sheepdogbob http:\/\/t.co\/YDLL40cBaZ",
    "id" : 647144211607891968,
    "created_at" : "2015-09-24 20:22:58 +0000",
    "user" : {
      "name" : "Dalesbrad Holsteins",
      "screen_name" : "Dalesbrad007",
      "protected" : false,
      "id_str" : "1618461726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786433832916512768\/Gp67gNql_normal.jpg",
      "id" : 1618461726,
      "verified" : false
    }
  },
  "id" : 647159451103965184,
  "created_at" : "2015-09-24 21:23:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Roberts",
      "screen_name" : "drvox",
      "indices" : [ 0, 6 ],
      "id_str" : "22737278",
      "id" : 22737278
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 7, 17 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647127330977001472",
  "geo" : { },
  "id_str" : "647149920034557953",
  "in_reply_to_user_id" : 22737278,
  "text" : "@drvox @bend_time i dont get why it would? hmm.. ((ponders))",
  "id" : 647149920034557953,
  "in_reply_to_status_id" : 647127330977001472,
  "created_at" : "2015-09-24 20:45:39 +0000",
  "in_reply_to_screen_name" : "drvox",
  "in_reply_to_user_id_str" : "22737278",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina",
      "screen_name" : "tinatbh",
      "indices" : [ 3, 11 ],
      "id_str" : "612043406",
      "id" : 612043406
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tinatbh\/status\/647093953607671808\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/E0xGqsHSO1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPrwhYGWIAAp2mZ.jpg",
      "id_str" : "647093952676503552",
      "id" : 647093952676503552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPrwhYGWIAAp2mZ.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/E0xGqsHSO1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647146210705473536",
  "text" : "RT @tinatbh: my relationship with most people http:\/\/t.co\/E0xGqsHSO1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tinatbh\/status\/647093953607671808\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/E0xGqsHSO1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPrwhYGWIAAp2mZ.jpg",
        "id_str" : "647093952676503552",
        "id" : 647093952676503552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPrwhYGWIAAp2mZ.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/E0xGqsHSO1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647093953607671808",
    "text" : "my relationship with most people http:\/\/t.co\/E0xGqsHSO1",
    "id" : 647093953607671808,
    "created_at" : "2015-09-24 17:03:15 +0000",
    "user" : {
      "name" : "tina",
      "screen_name" : "tinatbh",
      "protected" : false,
      "id_str" : "612043406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422220676410261504\/l8lqEZaN_normal.jpeg",
      "id" : 612043406,
      "verified" : false
    }
  },
  "id" : 647146210705473536,
  "created_at" : "2015-09-24 20:30:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647097551779438596",
  "geo" : { },
  "id_str" : "647124697004527616",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides had to look up orthogonal..lol",
  "id" : 647124697004527616,
  "in_reply_to_status_id" : 647097551779438596,
  "created_at" : "2015-09-24 19:05:25 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647123825985998848",
  "text" : "i cut my own hair. I leaned over and cut straight across. yah..",
  "id" : 647123825985998848,
  "created_at" : "2015-09-24 19:01:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ira Willey",
      "screen_name" : "irawilley",
      "indices" : [ 66, 76 ],
      "id_str" : "392365725",
      "id" : 392365725
    }, {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 80, 92 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/cRl06K81eN",
      "expanded_url" : "http:\/\/www.producthunt.com\/games\/where-is-cat",
      "display_url" : "producthunt.com\/games\/where-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647108151830028288",
  "text" : "Cute! &gt;&gt; Where Is Cat?: An adorable hidden object game. via @irawilley on @ProductHunt http:\/\/t.co\/cRl06K81eN",
  "id" : 647108151830028288,
  "created_at" : "2015-09-24 17:59:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647091018068836352",
  "geo" : { },
  "id_str" : "647097130247712768",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides thanks, i'll look into these.",
  "id" : 647097130247712768,
  "in_reply_to_status_id" : 647091018068836352,
  "created_at" : "2015-09-24 17:15:52 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647090834911969280",
  "text" : "im tired of all these med pros thinking its in her head. and the endo thinks the nausea, anxiety not from #hashimotos",
  "id" : 647090834911969280,
  "created_at" : "2015-09-24 16:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647090297357377536",
  "text" : "ins wont cover odansetron (not fda approved for anxiety.. gah) so she needs a diff nausea drug..",
  "id" : 647090297357377536,
  "created_at" : "2015-09-24 16:48:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647089756283797504",
  "text" : "so GI doc told her to get back on prilosec (for 3 months) and get off reglan (due to neurological side effects over long term)",
  "id" : 647089756283797504,
  "created_at" : "2015-09-24 16:46:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647075930674987008",
  "text" : "RT @ZachsMind: so pretty much everything being sold to me in restaurants and supermarkets is bad for me. what the fuck am i supposed to eat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647074518905712641",
    "text" : "so pretty much everything being sold to me in restaurants and supermarkets is bad for me. what the fuck am i supposed to eat? air?",
    "id" : 647074518905712641,
    "created_at" : "2015-09-24 15:46:02 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 647075930674987008,
  "created_at" : "2015-09-24 15:51:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/646741513569964033\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/fF0cy5P8iX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmv-tTWoAA3CDL.jpg",
      "id_str" : "646741513351897088",
      "id" : 646741513351897088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmv-tTWoAA3CDL.jpg",
      "sizes" : [ {
        "h" : 498,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fF0cy5P8iX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646742221107105792",
  "text" : "RT @PinarAkal1: What we are looking for is what is looking.\n\n~ St. Francis of Assisi http:\/\/t.co\/fF0cy5P8iX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/646741513569964033\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/fF0cy5P8iX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmv-tTWoAA3CDL.jpg",
        "id_str" : "646741513351897088",
        "id" : 646741513351897088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmv-tTWoAA3CDL.jpg",
        "sizes" : [ {
          "h" : 498,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fF0cy5P8iX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646741513569964033",
    "text" : "What we are looking for is what is looking.\n\n~ St. Francis of Assisi http:\/\/t.co\/fF0cy5P8iX",
    "id" : 646741513569964033,
    "created_at" : "2015-09-23 17:42:47 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 646742221107105792,
  "created_at" : "2015-09-23 17:45:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/GYNKPmjT0D",
      "expanded_url" : "https:\/\/www.newscientist.com\/article\/giraffes-spend-their-evenings-humming-to-each-other\/",
      "display_url" : "newscientist.com\/article\/giraff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646733515401371648",
  "text" : "Giraffes spend their evenings humming to each other https:\/\/t.co\/GYNKPmjT0D",
  "id" : 646733515401371648,
  "created_at" : "2015-09-23 17:11:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soundcloud",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/9GMwk7UU7E",
      "expanded_url" : "https:\/\/soundcloud.com\/new-scientist\/giraffes-humming?utm_source=soundcloud&utm_campaign=wtshare&utm_medium=Twitter&utm_content=https:\/\/soundcloud.com\/new-scientist\/giraffes-humming",
      "display_url" : "soundcloud.com\/new-scientist\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646733344043069440",
  "text" : "Giraffes humming by New Scientist via #soundcloud https:\/\/t.co\/9GMwk7UU7E",
  "id" : 646733344043069440,
  "created_at" : "2015-09-23 17:10:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/646679676451188736\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/oXXwr31ajQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPl3jSRVEAAdNPZ.jpg",
      "id_str" : "646679469588025344",
      "id" : 646679469588025344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPl3jSRVEAAdNPZ.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/oXXwr31ajQ"
    } ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646683751733415937",
  "text" : "RT @CatskillCritter: Mist lifting off the high meadow, this first fall morning in the #Catskills . . . http:\/\/t.co\/oXXwr31ajQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/646679676451188736\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/oXXwr31ajQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPl3jSRVEAAdNPZ.jpg",
        "id_str" : "646679469588025344",
        "id" : 646679469588025344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPl3jSRVEAAdNPZ.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/oXXwr31ajQ"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646679676451188736",
    "text" : "Mist lifting off the high meadow, this first fall morning in the #Catskills . . . http:\/\/t.co\/oXXwr31ajQ",
    "id" : 646679676451188736,
    "created_at" : "2015-09-23 13:37:04 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 646683751733415937,
  "created_at" : "2015-09-23 13:53:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "measured",
      "screen_name" : "measured",
      "indices" : [ 3, 12 ],
      "id_str" : "20870356",
      "id" : 20870356
    }, {
      "name" : "patently",
      "screen_name" : "patently",
      "indices" : [ 14, 23 ],
      "id_str" : "20524211",
      "id" : 20524211
    }, {
      "name" : "Sam Kalidi",
      "screen_name" : "samkalidi",
      "indices" : [ 37, 47 ],
      "id_str" : "102475469",
      "id" : 102475469
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/samkalidi\/status\/644005389227298816\/video\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/hCN9ODc6mV",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644005342746030081\/pu\/img\/eP7GPJxwRhkLcvHk.jpg",
      "id_str" : "644005342746030081",
      "id" : 644005342746030081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644005342746030081\/pu\/img\/eP7GPJxwRhkLcvHk.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hCN9ODc6mV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646422262124572672",
  "text" : "RT @measured: @patently This &gt; RT @samkalidi: Hedgehog getting a massage. http:\/\/t.co\/hCN9ODc6mV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "patently",
        "screen_name" : "patently",
        "indices" : [ 0, 9 ],
        "id_str" : "20524211",
        "id" : 20524211
      }, {
        "name" : "Sam Kalidi",
        "screen_name" : "samkalidi",
        "indices" : [ 23, 33 ],
        "id_str" : "102475469",
        "id" : 102475469
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/samkalidi\/status\/644005389227298816\/video\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/hCN9ODc6mV",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644005342746030081\/pu\/img\/eP7GPJxwRhkLcvHk.jpg",
        "id_str" : "644005342746030081",
        "id" : 644005342746030081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644005342746030081\/pu\/img\/eP7GPJxwRhkLcvHk.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hCN9ODc6mV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646409793016565760",
    "in_reply_to_user_id" : 20524211,
    "text" : "@patently This &gt; RT @samkalidi: Hedgehog getting a massage. http:\/\/t.co\/hCN9ODc6mV",
    "id" : 646409793016565760,
    "created_at" : "2015-09-22 19:44:39 +0000",
    "in_reply_to_screen_name" : "patently",
    "in_reply_to_user_id_str" : "20524211",
    "user" : {
      "name" : "measured",
      "screen_name" : "measured",
      "protected" : false,
      "id_str" : "20870356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453927768\/pink_penguins_small_1__normal.jpg",
      "id" : 20870356,
      "verified" : false
    }
  },
  "id" : 646422262124572672,
  "created_at" : "2015-09-22 20:34:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/H8oMrnt9XR",
      "expanded_url" : "http:\/\/reverbpress.com\/politics\/battlegrounds\/bombshell-funding-carly-fiorina-one-gop-rivals\/",
      "display_url" : "reverbpress.com\/politics\/battl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646415934714957824",
  "text" : "interesting &gt;&gt; BOMBSHELL: Who Is Funding Carly Fiorina? One Of Her GOP \u2018Rivals!\u2019 http:\/\/t.co\/H8oMrnt9XR",
  "id" : 646415934714957824,
  "created_at" : "2015-09-22 20:09:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646371758984044544",
  "text" : "RT @dhammagirl: \"When the student is ready, \nThe teacher will DISappear.\n\n...what if we have been doing it all wrong?\n\n         QUESTION EV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646285334452510720",
    "text" : "\"When the student is ready, \nThe teacher will DISappear.\n\n...what if we have been doing it all wrong?\n\n         QUESTION EVERY THING",
    "id" : 646285334452510720,
    "created_at" : "2015-09-22 11:30:05 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 646371758984044544,
  "created_at" : "2015-09-22 17:13:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ADF",
      "screen_name" : "AlinaDal_F",
      "indices" : [ 3, 14 ],
      "id_str" : "1484891485",
      "id" : 1484891485
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LakeToblino",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646354648123764736",
  "text" : "RT @AlinaDal_F: Life is a mirror and will reflect back to the thinker what he thinks into it.\nErnest Holmes\n#LakeToblino http:\/\/t.co\/rpQlrd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AlinaDal_F\/status\/644043092023214080\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/rpQlrdsPNA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPAZx1kWEAA6mJB.jpg",
        "id_str" : "644043090697785344",
        "id" : 644043090697785344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPAZx1kWEAA6mJB.jpg",
        "sizes" : [ {
          "h" : 658,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rpQlrdsPNA"
      } ],
      "hashtags" : [ {
        "text" : "LakeToblino",
        "indices" : [ 92, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644043092023214080",
    "text" : "Life is a mirror and will reflect back to the thinker what he thinks into it.\nErnest Holmes\n#LakeToblino http:\/\/t.co\/rpQlrdsPNA",
    "id" : 644043092023214080,
    "created_at" : "2015-09-16 07:00:13 +0000",
    "user" : {
      "name" : "ADF",
      "screen_name" : "AlinaDal_F",
      "protected" : false,
      "id_str" : "1484891485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728238240889712640\/sM8dPtFi_normal.jpg",
      "id" : 1484891485,
      "verified" : false
    }
  },
  "id" : 646354648123764736,
  "created_at" : "2015-09-22 16:05:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/fpsa31qyzm",
      "expanded_url" : "https:\/\/youtu.be\/1thcO_olHas",
      "display_url" : "youtu.be\/1thcO_olHas"
    } ]
  },
  "geo" : { },
  "id_str" : "646353451744628736",
  "text" : "is this real? wow... &gt; Programmer under oath admits computers rig elections https:\/\/t.co\/fpsa31qyzm",
  "id" : 646353451744628736,
  "created_at" : "2015-09-22 16:00:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Webb",
      "screen_name" : "dairychris",
      "indices" : [ 3, 14 ],
      "id_str" : "1070911393",
      "id" : 1070911393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646066984380203008",
  "text" : "RT @dairychris: He's getting up &amp; down but still short fast breaths so presumably struggling. Temperature normal. Out of ideas. :( http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dairychris\/status\/645949002442252288\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/RAzEgWoBrx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPbfISdWsAAlH01.jpg",
        "id_str" : "645948930061152256",
        "id" : 645948930061152256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPbfISdWsAAlH01.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RAzEgWoBrx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645949002442252288",
    "text" : "He's getting up &amp; down but still short fast breaths so presumably struggling. Temperature normal. Out of ideas. :( http:\/\/t.co\/RAzEgWoBrx",
    "id" : 645949002442252288,
    "created_at" : "2015-09-21 13:13:37 +0000",
    "user" : {
      "name" : "Chris Webb",
      "screen_name" : "dairychris",
      "protected" : false,
      "id_str" : "1070911393",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545584404051935232\/PwBY-8Kw_normal.png",
      "id" : 1070911393,
      "verified" : false
    }
  },
  "id" : 646066984380203008,
  "created_at" : "2015-09-21 21:02:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645998212675969025",
  "text" : "RT @Angelapaints: all these mysterious illnesses, with known causes, are yet a mystery. shall we discuss immune system destroyers?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645996569041465345",
    "text" : "all these mysterious illnesses, with known causes, are yet a mystery. shall we discuss immune system destroyers?",
    "id" : 645996569041465345,
    "created_at" : "2015-09-21 16:22:38 +0000",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 645998212675969025,
  "created_at" : "2015-09-21 16:29:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forrest",
      "screen_name" : "fbaum",
      "indices" : [ 3, 9 ],
      "id_str" : "15387489",
      "id" : 15387489
    }, {
      "name" : "Mason Berkenbosch",
      "screen_name" : "Mason_Bosch",
      "indices" : [ 11, 23 ],
      "id_str" : "1375232022",
      "id" : 1375232022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645661619603787776",
  "text" : "RT @fbaum: @Mason_Bosch they can definitely have that opinion. Separation of Church &amp; State should govern what they can *do* with it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mason Berkenbosch",
        "screen_name" : "Mason_Bosch",
        "indices" : [ 0, 12 ],
        "id_str" : "1375232022",
        "id" : 1375232022
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "645656708900102144",
    "geo" : { },
    "id_str" : "645658217763106816",
    "in_reply_to_user_id" : 1375232022,
    "text" : "@Mason_Bosch they can definitely have that opinion. Separation of Church &amp; State should govern what they can *do* with it.",
    "id" : 645658217763106816,
    "in_reply_to_status_id" : 645656708900102144,
    "created_at" : "2015-09-20 17:58:09 +0000",
    "in_reply_to_screen_name" : "Mason_Bosch",
    "in_reply_to_user_id_str" : "1375232022",
    "user" : {
      "name" : "Forrest",
      "screen_name" : "fbaum",
      "protected" : false,
      "id_str" : "15387489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1357191931\/Screen_shot_2011-05-16_at_8.39.42_PM_normal.png",
      "id" : 15387489,
      "verified" : false
    }
  },
  "id" : 645661619603787776,
  "created_at" : "2015-09-20 18:11:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "\u041E\u043B\u044C\u0433\u0430 \u041F\u043E\u043B\u043E\u0432\u043D\u0438\u043A\u043E\u0432\u0430",
      "screen_name" : "LYMEnytt",
      "indices" : [ 71, 80 ],
      "id_str" : "4832349700",
      "id" : 4832349700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mecfs",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ZKMwhBsGig",
      "expanded_url" : "http:\/\/kavlifondet.no\/2015\/04\/tackling-a-medical-mystery\/#.Vf7Qc7Yz6t0.twitter",
      "display_url" : "kavlifondet.no\/2015\/04\/tackli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645626299294294016",
  "text" : "RT @AlisynGayle: Tackling a medical mystery http:\/\/t.co\/ZKMwhBsGig via @LYMEnytt #mecfs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u041E\u043B\u044C\u0433\u0430 \u041F\u043E\u043B\u043E\u0432\u043D\u0438\u043A\u043E\u0432\u0430",
        "screen_name" : "LYMEnytt",
        "indices" : [ 54, 63 ],
        "id_str" : "4832349700",
        "id" : 4832349700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mecfs",
        "indices" : [ 64, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/ZKMwhBsGig",
        "expanded_url" : "http:\/\/kavlifondet.no\/2015\/04\/tackling-a-medical-mystery\/#.Vf7Qc7Yz6t0.twitter",
        "display_url" : "kavlifondet.no\/2015\/04\/tackli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "645623643427442689",
    "text" : "Tackling a medical mystery http:\/\/t.co\/ZKMwhBsGig via @LYMEnytt #mecfs",
    "id" : 645623643427442689,
    "created_at" : "2015-09-20 15:40:46 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 645626299294294016,
  "created_at" : "2015-09-20 15:51:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Cook",
      "screen_name" : "michelemcook1",
      "indices" : [ 3, 17 ],
      "id_str" : "2769664981",
      "id" : 2769664981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645599199694843905",
  "text" : "RT @michelemcook1: I saw old Autumn in the misty morn stand shadowless like silence, listening to silence. (Thomas Hood 1799 - 1845) http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michelemcook1\/status\/645499426778316800\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/OuMqs8bI6J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPVGTtDWgAA7OVl.jpg",
        "id_str" : "645499425922646016",
        "id" : 645499425922646016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPVGTtDWgAA7OVl.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 693
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 693
        } ],
        "display_url" : "pic.twitter.com\/OuMqs8bI6J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645499426778316800",
    "text" : "I saw old Autumn in the misty morn stand shadowless like silence, listening to silence. (Thomas Hood 1799 - 1845) http:\/\/t.co\/OuMqs8bI6J",
    "id" : 645499426778316800,
    "created_at" : "2015-09-20 07:27:10 +0000",
    "user" : {
      "name" : "Michele Cook",
      "screen_name" : "michelemcook1",
      "protected" : false,
      "id_str" : "2769664981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560539974160760832\/XmcUz9Cb_normal.jpeg",
      "id" : 2769664981,
      "verified" : false
    }
  },
  "id" : 645599199694843905,
  "created_at" : "2015-09-20 14:03:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emergency Wolf",
      "screen_name" : "EmergencyWolf",
      "indices" : [ 3, 17 ],
      "id_str" : "2393118097",
      "id" : 2393118097
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EmergencyWolf\/status\/645038459107700736\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/h845W5fsgT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CPOjDtjUAAAica6.png",
      "id_str" : "645038455806754816",
      "id" : 645038455806754816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CPOjDtjUAAAica6.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 425
      } ],
      "display_url" : "pic.twitter.com\/h845W5fsgT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645387365352087552",
  "text" : "RT @EmergencyWolf: Headtilt. http:\/\/t.co\/h845W5fsgT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EmergencyWolf\/status\/645038459107700736\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/h845W5fsgT",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CPOjDtjUAAAica6.png",
        "id_str" : "645038455806754816",
        "id" : 645038455806754816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CPOjDtjUAAAica6.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 425
        } ],
        "display_url" : "pic.twitter.com\/h845W5fsgT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645038459107700736",
    "text" : "Headtilt. http:\/\/t.co\/h845W5fsgT",
    "id" : 645038459107700736,
    "created_at" : "2015-09-19 00:55:27 +0000",
    "user" : {
      "name" : "Emergency Wolf",
      "screen_name" : "EmergencyWolf",
      "protected" : false,
      "id_str" : "2393118097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445266228253175808\/YYJbGT5d_normal.jpeg",
      "id" : 2393118097,
      "verified" : false
    }
  },
  "id" : 645387365352087552,
  "created_at" : "2015-09-20 00:01:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave M",
      "screen_name" : "SpotTheLoon2010",
      "indices" : [ 3, 19 ],
      "id_str" : "118867974",
      "id" : 118867974
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpotTheLoon2010\/status\/645309159886360576\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/0QjPBY1ktp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPSZQwiUEAAQJh4.jpg",
      "id_str" : "645309159806603264",
      "id" : 645309159806603264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPSZQwiUEAAQJh4.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0QjPBY1ktp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645360285281320960",
  "text" : "RT @SpotTheLoon2010: ;-) http:\/\/t.co\/0QjPBY1ktp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/gplus.to\/carbonandroid\" rel=\"nofollow\"\u003ECarbon v2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpotTheLoon2010\/status\/645309159886360576\/photo\/1",
        "indices" : [ 4, 26 ],
        "url" : "http:\/\/t.co\/0QjPBY1ktp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPSZQwiUEAAQJh4.jpg",
        "id_str" : "645309159806603264",
        "id" : 645309159806603264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPSZQwiUEAAQJh4.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0QjPBY1ktp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645309159886360576",
    "text" : ";-) http:\/\/t.co\/0QjPBY1ktp",
    "id" : 645309159886360576,
    "created_at" : "2015-09-19 18:51:07 +0000",
    "user" : {
      "name" : "Dave M",
      "screen_name" : "SpotTheLoon2010",
      "protected" : false,
      "id_str" : "118867974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000733018611\/c11580222922d7d2006dda1586bf392a_normal.jpeg",
      "id" : 118867974,
      "verified" : false
    }
  },
  "id" : 645360285281320960,
  "created_at" : "2015-09-19 22:14:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave M",
      "screen_name" : "SpotTheLoon2010",
      "indices" : [ 3, 19 ],
      "id_str" : "118867974",
      "id" : 118867974
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpotTheLoon2010\/status\/645309456377470976\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/3UV1lAGygy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPSZiAQUkAAONtP.jpg",
      "id_str" : "645309456083881984",
      "id" : 645309456083881984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPSZiAQUkAAONtP.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/3UV1lAGygy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645360155031420928",
  "text" : "RT @SpotTheLoon2010: Catman http:\/\/t.co\/3UV1lAGygy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/gplus.to\/carbonandroid\" rel=\"nofollow\"\u003ECarbon v2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpotTheLoon2010\/status\/645309456377470976\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/3UV1lAGygy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPSZiAQUkAAONtP.jpg",
        "id_str" : "645309456083881984",
        "id" : 645309456083881984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPSZiAQUkAAONtP.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 584,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 584,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 584,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/3UV1lAGygy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645309456377470976",
    "text" : "Catman http:\/\/t.co\/3UV1lAGygy",
    "id" : 645309456377470976,
    "created_at" : "2015-09-19 18:52:18 +0000",
    "user" : {
      "name" : "Dave M",
      "screen_name" : "SpotTheLoon2010",
      "protected" : false,
      "id_str" : "118867974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000733018611\/c11580222922d7d2006dda1586bf392a_normal.jpeg",
      "id" : 118867974,
      "verified" : false
    }
  },
  "id" : 645360155031420928,
  "created_at" : "2015-09-19 22:13:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Sutcliffe",
      "screen_name" : "ChasSutcliffe",
      "indices" : [ 3, 17 ],
      "id_str" : "51045839",
      "id" : 51045839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trouble",
      "indices" : [ 35, 43 ]
    }, {
      "text" : "Whiskyoclock",
      "indices" : [ 84, 97 ]
    }, {
      "text" : "lovecows",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "lovefarming",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645346889399947264",
  "text" : "RT @ChasSutcliffe: I've just given #Trouble his bottle, last job of day so now it's #Whiskyoclock! #lovecows #lovefarming \uD83D\uDC4D\uD83D\uDC2E\uD83D\uDE03\uD83D\uDE03 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChasSutcliffe\/status\/645308259134537728\/video\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/luq3jeJjak",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/645305444806852608\/pu\/img\/3ZRe1G2c-OA9xFpn.jpg",
        "id_str" : "645305444806852608",
        "id" : 645305444806852608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/645305444806852608\/pu\/img\/3ZRe1G2c-OA9xFpn.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/luq3jeJjak"
      } ],
      "hashtags" : [ {
        "text" : "Trouble",
        "indices" : [ 16, 24 ]
      }, {
        "text" : "Whiskyoclock",
        "indices" : [ 65, 78 ]
      }, {
        "text" : "lovecows",
        "indices" : [ 80, 89 ]
      }, {
        "text" : "lovefarming",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645308259134537728",
    "text" : "I've just given #Trouble his bottle, last job of day so now it's #Whiskyoclock! #lovecows #lovefarming \uD83D\uDC4D\uD83D\uDC2E\uD83D\uDE03\uD83D\uDE03 http:\/\/t.co\/luq3jeJjak",
    "id" : 645308259134537728,
    "created_at" : "2015-09-19 18:47:32 +0000",
    "user" : {
      "name" : "Charlie Sutcliffe",
      "screen_name" : "ChasSutcliffe",
      "protected" : false,
      "id_str" : "51045839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556915520935456768\/4zFyjb09_normal.png",
      "id" : 51045839,
      "verified" : false
    }
  },
  "id" : 645346889399947264,
  "created_at" : "2015-09-19 21:21:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645323696320679936",
  "text" : "RT @Swanwhisperer: Happy to say That we have found Flash &amp; Whisper's Juv Swans And Wow they are Nearly White All 4 Safe and well http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/645323028126171140\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/GRsazG4KyN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPSl341W8Ak1YFd.jpg",
        "id_str" : "645323026188398601",
        "id" : 645323026188398601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPSl341W8Ak1YFd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1038
        }, {
          "h" : 584,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GRsazG4KyN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645323028126171140",
    "text" : "Happy to say That we have found Flash &amp; Whisper's Juv Swans And Wow they are Nearly White All 4 Safe and well http:\/\/t.co\/GRsazG4KyN",
    "id" : 645323028126171140,
    "created_at" : "2015-09-19 19:46:14 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 645323696320679936,
  "created_at" : "2015-09-19 19:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ik5xI8MkeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsHQUUYAEcJiz.jpg",
      "id_str" : "645259518515896321",
      "id" : 645259518515896321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsHQUUYAEcJiz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ik5xI8MkeU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ik5xI8MkeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsL94WoAEXbtG.jpg",
      "id_str" : "645259599466110977",
      "id" : 645259599466110977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsL94WoAEXbtG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ik5xI8MkeU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ik5xI8MkeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsQkVWgAAmMfM.jpg",
      "id_str" : "645259678507761664",
      "id" : 645259678507761664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsQkVWgAAmMfM.jpg",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ik5xI8MkeU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ik5xI8MkeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsU2CWoAA87hs.jpg",
      "id_str" : "645259751979393024",
      "id" : 645259751979393024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsU2CWoAA87hs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ik5xI8MkeU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645320088950804481",
  "text" : "RT @SouthYeoEast: A field of Teddies http:\/\/t.co\/ik5xI8MkeU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ik5xI8MkeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsHQUUYAEcJiz.jpg",
        "id_str" : "645259518515896321",
        "id" : 645259518515896321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsHQUUYAEcJiz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ik5xI8MkeU"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ik5xI8MkeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsL94WoAEXbtG.jpg",
        "id_str" : "645259599466110977",
        "id" : 645259599466110977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsL94WoAEXbtG.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ik5xI8MkeU"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ik5xI8MkeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsQkVWgAAmMfM.jpg",
        "id_str" : "645259678507761664",
        "id" : 645259678507761664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsQkVWgAAmMfM.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ik5xI8MkeU"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/645259754177208320\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ik5xI8MkeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRsU2CWoAA87hs.jpg",
        "id_str" : "645259751979393024",
        "id" : 645259751979393024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRsU2CWoAA87hs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ik5xI8MkeU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645259754177208320",
    "text" : "A field of Teddies http:\/\/t.co\/ik5xI8MkeU",
    "id" : 645259754177208320,
    "created_at" : "2015-09-19 15:34:48 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 645320088950804481,
  "created_at" : "2015-09-19 19:34:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645319960106008576",
  "text" : "RT @dhammagirl: \"They\" will always have SOMETHING to say. \n\nKeep doing what you're doing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645308347307163648",
    "text" : "\"They\" will always have SOMETHING to say. \n\nKeep doing what you're doing.",
    "id" : 645308347307163648,
    "created_at" : "2015-09-19 18:47:53 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 645319960106008576,
  "created_at" : "2015-09-19 19:34:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keegan",
      "screen_name" : "JohnDoe_997",
      "indices" : [ 0, 12 ],
      "id_str" : "3123500449",
      "id" : 3123500449
    }, {
      "name" : "ASH: SciP(h)er",
      "screen_name" : "ScientiaPercept",
      "indices" : [ 13, 29 ],
      "id_str" : "25916739",
      "id" : 25916739
    }, {
      "name" : "Preacher",
      "screen_name" : "_OnlineGospel_",
      "indices" : [ 30, 45 ],
      "id_str" : "1624769948",
      "id" : 1624769948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645258371709296640",
  "geo" : { },
  "id_str" : "645298004811976704",
  "in_reply_to_user_id" : 3123500449,
  "text" : "@JohnDoe_997 @ScientiaPercept @_OnlineGospel_ ahh.. exc visual description.. I like it!",
  "id" : 645298004811976704,
  "in_reply_to_status_id" : 645258371709296640,
  "created_at" : "2015-09-19 18:06:48 +0000",
  "in_reply_to_screen_name" : "JohnDoe_997",
  "in_reply_to_user_id_str" : "3123500449",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keegan",
      "screen_name" : "JohnDoe_997",
      "indices" : [ 3, 15 ],
      "id_str" : "3123500449",
      "id" : 3123500449
    }, {
      "name" : "Preacher",
      "screen_name" : "_OnlineGospel_",
      "indices" : [ 17, 32 ],
      "id_str" : "1624769948",
      "id" : 1624769948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645297753887739904",
  "text" : "RT @JohnDoe_997: @_OnlineGospel_  The prevailing idea is that Mass distorts space-time much the way a bowling ball would distort bedsheets.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Preacher",
        "screen_name" : "_OnlineGospel_",
        "indices" : [ 0, 15 ],
        "id_str" : "1624769948",
        "id" : 1624769948
      }, {
        "name" : "ASH: SciP(h)er",
        "screen_name" : "ScientiaPercept",
        "indices" : [ 122, 138 ],
        "id_str" : "25916739",
        "id" : 25916739
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "645257858414592000",
    "geo" : { },
    "id_str" : "645258371709296640",
    "in_reply_to_user_id" : 1624769948,
    "text" : "@_OnlineGospel_  The prevailing idea is that Mass distorts space-time much the way a bowling ball would distort bedsheets.@ScientiaPercept",
    "id" : 645258371709296640,
    "in_reply_to_status_id" : 645257858414592000,
    "created_at" : "2015-09-19 15:29:18 +0000",
    "in_reply_to_screen_name" : "_OnlineGospel_",
    "in_reply_to_user_id_str" : "1624769948",
    "user" : {
      "name" : "Keegan",
      "screen_name" : "JohnDoe_997",
      "protected" : false,
      "id_str" : "3123500449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797191778939990016\/W4za7nxN_normal.jpg",
      "id" : 3123500449,
      "verified" : false
    }
  },
  "id" : 645297753887739904,
  "created_at" : "2015-09-19 18:05:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645297399657811968",
  "text" : "RT @_NealeDWalsch: We simply call God\u2019s communications something else. Serendipity . . coincidence  . . women\u2019s intuition ... inspiration. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645296336875692032",
    "text" : "We simply call God\u2019s communications something else. Serendipity . . coincidence  . . women\u2019s intuition ... inspiration. .  a sudden insight",
    "id" : 645296336875692032,
    "created_at" : "2015-09-19 18:00:10 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 645297399657811968,
  "created_at" : "2015-09-19 18:04:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/8BeIJnLD9B",
      "expanded_url" : "http:\/\/goo.gl\/s5s0Us",
      "display_url" : "goo.gl\/s5s0Us"
    } ]
  },
  "geo" : { },
  "id_str" : "645297278786359296",
  "text" : "RT @openculture: The Solar System Drawn Amazingly to Scale Across 7 Miles of Nevada\u2019s Black Rock Desert http:\/\/t.co\/8BeIJnLD9B http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/645270131866644480\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/LPk19K5lz8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRoNzQUcAEh-Gs.png",
        "id_str" : "645255232927068161",
        "id" : 645255232927068161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRoNzQUcAEh-Gs.png",
        "sizes" : [ {
          "h" : 329,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/LPk19K5lz8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/8BeIJnLD9B",
        "expanded_url" : "http:\/\/goo.gl\/s5s0Us",
        "display_url" : "goo.gl\/s5s0Us"
      } ]
    },
    "geo" : { },
    "id_str" : "645270131866644480",
    "text" : "The Solar System Drawn Amazingly to Scale Across 7 Miles of Nevada\u2019s Black Rock Desert http:\/\/t.co\/8BeIJnLD9B http:\/\/t.co\/LPk19K5lz8",
    "id" : 645270131866644480,
    "created_at" : "2015-09-19 16:16:02 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74425623\/open_culture_white_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 645297278786359296,
  "created_at" : "2015-09-19 18:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645296737821806592",
  "text" : "for a long time, i couldnt get that the stars I saw were from the past. the concept didnt compute..lol.",
  "id" : 645296737821806592,
  "created_at" : "2015-09-19 18:01:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Egan",
      "screen_name" : "CeciliaEgan1",
      "indices" : [ 3, 16 ],
      "id_str" : "2775390047",
      "id" : 2775390047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CeciliaEgan1\/status\/639836724814839809\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/HJV3PXP1c9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COEoGupWoAANyzy.jpg",
      "id_str" : "639836718129127424",
      "id" : 639836718129127424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COEoGupWoAANyzy.jpg",
      "sizes" : [ {
        "h" : 553,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1111
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HJV3PXP1c9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645295967605014528",
  "text" : "RT @CeciliaEgan1: You can still hear the quite sound of the waves lapping at Doughmore Beach. CO Clare Ireland. http:\/\/t.co\/HJV3PXP1c9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CeciliaEgan1\/status\/639836724814839809\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/HJV3PXP1c9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COEoGupWoAANyzy.jpg",
        "id_str" : "639836718129127424",
        "id" : 639836718129127424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COEoGupWoAANyzy.jpg",
        "sizes" : [ {
          "h" : 553,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1111
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HJV3PXP1c9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639836724814839809",
    "text" : "You can still hear the quite sound of the waves lapping at Doughmore Beach. CO Clare Ireland. http:\/\/t.co\/HJV3PXP1c9",
    "id" : 639836724814839809,
    "created_at" : "2015-09-04 16:25:37 +0000",
    "user" : {
      "name" : "Cecilia Egan",
      "screen_name" : "CeciliaEgan1",
      "protected" : false,
      "id_str" : "2775390047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785123086135881728\/s03dvxo1_normal.jpg",
      "id" : 2775390047,
      "verified" : false
    }
  },
  "id" : 645295967605014528,
  "created_at" : "2015-09-19 17:58:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/LSYL9Eb51c",
      "expanded_url" : "https:\/\/medium.com\/@tracischmidley\/are-you-really-pro-life-ab5c5acbb293?source=tw-1f0b30a1b811-1442682434022",
      "display_url" : "medium.com\/@tracischmidle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645283196167434240",
  "text" : "\u201CAre You Really Pro-Life?\u201D by Traci Schmidley https:\/\/t.co\/LSYL9Eb51c",
  "id" : 645283196167434240,
  "created_at" : "2015-09-19 17:07:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/xh7oj6z0Ob",
      "expanded_url" : "https:\/\/twitter.com\/Orchidano\/status\/644603945088774144",
      "display_url" : "twitter.com\/Orchidano\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645269088747548672",
  "text" : "i think it becomes part of identity. hard to give up. https:\/\/t.co\/xh7oj6z0Ob",
  "id" : 645269088747548672,
  "created_at" : "2015-09-19 16:11:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ASH: SciP(h)er",
      "screen_name" : "ScientiaPercept",
      "indices" : [ 0, 16 ],
      "id_str" : "25916739",
      "id" : 25916739
    }, {
      "name" : "Preacher",
      "screen_name" : "_OnlineGospel_",
      "indices" : [ 17, 32 ],
      "id_str" : "1624769948",
      "id" : 1624769948
    }, {
      "name" : "Keegan",
      "screen_name" : "JohnDoe_997",
      "indices" : [ 33, 45 ],
      "id_str" : "3123500449",
      "id" : 3123500449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645259629346197509",
  "geo" : { },
  "id_str" : "645268381164306432",
  "in_reply_to_user_id" : 25916739,
  "text" : "@ScientiaPercept @_OnlineGospel_ @JohnDoe_997 tbh.. not ez to understand this stuff. 49yo and just \"getting it\". love reading physics.",
  "id" : 645268381164306432,
  "in_reply_to_status_id" : 645259629346197509,
  "created_at" : "2015-09-19 16:09:05 +0000",
  "in_reply_to_screen_name" : "ScientiaPercept",
  "in_reply_to_user_id_str" : "25916739",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645267422052773888",
  "text" : "RT @UnseelieMe: If Stephen King were to write a bk based on whats going on in our country right now, it would be the fucking scariest book \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645265148727422976",
    "text" : "If Stephen King were to write a bk based on whats going on in our country right now, it would be the fucking scariest book hes ever written.",
    "id" : 645265148727422976,
    "created_at" : "2015-09-19 15:56:14 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 645267422052773888,
  "created_at" : "2015-09-19 16:05:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/645266888730152962\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BYh0mOrch8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRy0EJW8AAPaxz.jpg",
      "id_str" : "645266885412581376",
      "id" : 645266885412581376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRy0EJW8AAPaxz.jpg",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 1259
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BYh0mOrch8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/3BG2IRgZ02",
      "expanded_url" : "http:\/\/www.dwaynereavesphotography.com\/2015\/09\/i-have-been-using-camera-for-30-plus.html",
      "display_url" : "dwaynereavesphotography.com\/2015\/09\/i-have\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645266888730152962",
  "text" : "Dwayne Reaves Photography: The Butterfly http:\/\/t.co\/3BG2IRgZ02 http:\/\/t.co\/BYh0mOrch8",
  "id" : 645266888730152962,
  "created_at" : "2015-09-19 16:03:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shakeitoffbaby",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645264423616036864",
  "text" : "ugh.. read some really ugly timelines.. now my aura needs a shower.. poor thing. #shakeitoffbaby",
  "id" : 645264423616036864,
  "created_at" : "2015-09-19 15:53:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandbox Cooperative",
      "screen_name" : "sandboxcoop",
      "indices" : [ 3, 15 ],
      "id_str" : "2252594576",
      "id" : 2252594576
    }, {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 69, 82 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645257621008740352",
  "text" : "RT @sandboxcoop: \"I let science be science without rejecting faith.\" @mikemchargue Hear more in person or online 9.27 at 7 pm CST. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science Mike",
        "screen_name" : "mikemchargue",
        "indices" : [ 52, 65 ],
        "id_str" : "6091632",
        "id" : 6091632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sandboxcoop\/status\/645238613056311297\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/xt4ohiMfbv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRZGUEWcAAIFVG.png",
        "id_str" : "645238611621867520",
        "id" : 645238611621867520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRZGUEWcAAIFVG.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 618
        } ],
        "display_url" : "pic.twitter.com\/xt4ohiMfbv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645238613056311297",
    "text" : "\"I let science be science without rejecting faith.\" @mikemchargue Hear more in person or online 9.27 at 7 pm CST. http:\/\/t.co\/xt4ohiMfbv",
    "id" : 645238613056311297,
    "created_at" : "2015-09-19 14:10:47 +0000",
    "user" : {
      "name" : "Sandbox Cooperative",
      "screen_name" : "sandboxcoop",
      "protected" : false,
      "id_str" : "2252594576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428279390829436928\/kvYCpnmB_normal.png",
      "id" : 2252594576,
      "verified" : false
    }
  },
  "id" : 645257621008740352,
  "created_at" : "2015-09-19 15:26:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brome",
      "screen_name" : "Bromebirdcare",
      "indices" : [ 3, 17 ],
      "id_str" : "455153572",
      "id" : 455153572
    }, {
      "name" : "Matt pinner",
      "screen_name" : "Matt_Pinner",
      "indices" : [ 32, 44 ],
      "id_str" : "624036196",
      "id" : 624036196
    }, {
      "name" : "Mudeford Quay",
      "screen_name" : "MudefordQuay",
      "indices" : [ 54, 67 ],
      "id_str" : "1707815694",
      "id" : 1707815694
    }, {
      "name" : "Bournemouthecho",
      "screen_name" : "Bournemouthecho",
      "indices" : [ 68, 84 ],
      "id_str" : "16579769",
      "id" : 16579769
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Matt_Pinner\/status\/639512647273172996\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/sLUr1nlT9J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COABV5AWoAEHtsO.jpg",
      "id_str" : "639512622677794817",
      "id" : 639512622677794817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COABV5AWoAEHtsO.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/sLUr1nlT9J"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 109, 115 ]
    }, {
      "text" : "partyideas",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645256957822136320",
  "text" : "RT @Bromebirdcare: Party Time! \"@Matt_Pinner: Tonight @MudefordQuay @Bournemouthecho http:\/\/t.co\/sLUr1nlT9J\u201D #birds #partyideas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt pinner",
        "screen_name" : "Matt_Pinner",
        "indices" : [ 13, 25 ],
        "id_str" : "624036196",
        "id" : 624036196
      }, {
        "name" : "Mudeford Quay",
        "screen_name" : "MudefordQuay",
        "indices" : [ 35, 48 ],
        "id_str" : "1707815694",
        "id" : 1707815694
      }, {
        "name" : "Bournemouthecho",
        "screen_name" : "Bournemouthecho",
        "indices" : [ 49, 65 ],
        "id_str" : "16579769",
        "id" : 16579769
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Matt_Pinner\/status\/639512647273172996\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/sLUr1nlT9J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COABV5AWoAEHtsO.jpg",
        "id_str" : "639512622677794817",
        "id" : 639512622677794817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COABV5AWoAEHtsO.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/sLUr1nlT9J"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 90, 96 ]
      }, {
        "text" : "partyideas",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639512647273172996",
    "geo" : { },
    "id_str" : "639518234278887424",
    "in_reply_to_user_id" : 624036196,
    "text" : "Party Time! \"@Matt_Pinner: Tonight @MudefordQuay @Bournemouthecho http:\/\/t.co\/sLUr1nlT9J\u201D #birds #partyideas",
    "id" : 639518234278887424,
    "in_reply_to_status_id" : 639512647273172996,
    "created_at" : "2015-09-03 19:20:03 +0000",
    "in_reply_to_screen_name" : "Matt_Pinner",
    "in_reply_to_user_id_str" : "624036196",
    "user" : {
      "name" : "Brome",
      "screen_name" : "Bromebirdcare",
      "protected" : false,
      "id_str" : "455153572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786226572793643008\/969rW1j3_normal.jpg",
      "id" : 455153572,
      "verified" : false
    }
  },
  "id" : 645256957822136320,
  "created_at" : "2015-09-19 15:23:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Int Crane Foundation",
      "screen_name" : "savingcranes",
      "indices" : [ 3, 16 ],
      "id_str" : "221834911",
      "id" : 221834911
    }, {
      "name" : "Audubon Society",
      "screen_name" : "audubonsociety",
      "indices" : [ 69, 84 ],
      "id_str" : "19711765",
      "id" : 19711765
    }, {
      "name" : "Tom Lynn",
      "screen_name" : "TLynnphoto",
      "indices" : [ 86, 97 ],
      "id_str" : "19048410",
      "id" : 19048410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/HWbWyT9wFd",
      "expanded_url" : "http:\/\/goo.gl\/ljyEi3",
      "display_url" : "goo.gl\/ljyEi3"
    } ]
  },
  "geo" : { },
  "id_str" : "645256100942585856",
  "text" : "RT @savingcranes: \"Whooping Cranes nearly went the way of the Dodo.\" @audubonsociety\u200B @TLynnphoto http:\/\/t.co\/HWbWyT9wFd http:\/\/t.co\/MrCuFY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audubon Society",
        "screen_name" : "audubonsociety",
        "indices" : [ 51, 66 ],
        "id_str" : "19711765",
        "id" : 19711765
      }, {
        "name" : "Tom Lynn",
        "screen_name" : "TLynnphoto",
        "indices" : [ 68, 79 ],
        "id_str" : "19048410",
        "id" : 19048410
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/savingcranes\/status\/641581830165016576\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/MrCuFY8Urm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COFrpxrWEAUN-4a.jpg",
        "id_str" : "639910987517267973",
        "id" : 639910987517267973,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COFrpxrWEAUN-4a.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/MrCuFY8Urm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/HWbWyT9wFd",
        "expanded_url" : "http:\/\/goo.gl\/ljyEi3",
        "display_url" : "goo.gl\/ljyEi3"
      } ]
    },
    "geo" : { },
    "id_str" : "641581830165016576",
    "text" : "\"Whooping Cranes nearly went the way of the Dodo.\" @audubonsociety\u200B @TLynnphoto http:\/\/t.co\/HWbWyT9wFd http:\/\/t.co\/MrCuFY8Urm",
    "id" : 641581830165016576,
    "created_at" : "2015-09-09 12:00:02 +0000",
    "user" : {
      "name" : "Int Crane Foundation",
      "screen_name" : "savingcranes",
      "protected" : false,
      "id_str" : "221834911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1218263642\/icf_logo_normal.jpg",
      "id" : 221834911,
      "verified" : false
    }
  },
  "id" : 645256100942585856,
  "created_at" : "2015-09-19 15:20:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Jaffe",
      "screen_name" : "jennyjaffe",
      "indices" : [ 3, 14 ],
      "id_str" : "21380227",
      "id" : 21380227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IStandWithPP",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645255793537847296",
  "text" : "RT @jennyjaffe: If you are anti abortion, how can you POSSIBLY be anti birth control access??? #IStandWithPP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IStandWithPP",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644960539790192641",
    "text" : "If you are anti abortion, how can you POSSIBLY be anti birth control access??? #IStandWithPP",
    "id" : 644960539790192641,
    "created_at" : "2015-09-18 19:45:50 +0000",
    "user" : {
      "name" : "Jenny Jaffe",
      "screen_name" : "jennyjaffe",
      "protected" : false,
      "id_str" : "21380227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792601732299812864\/KiqeSnuP_normal.jpg",
      "id" : 21380227,
      "verified" : true
    }
  },
  "id" : 645255793537847296,
  "created_at" : "2015-09-19 15:19:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeet Heer",
      "screen_name" : "HeerJeet",
      "indices" : [ 3, 12 ],
      "id_str" : "604940737",
      "id" : 604940737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645255542399746048",
  "text" : "RT @HeerJeet: To be honest, I think the proper answer to \"Is Obama a Muslim?\" question is: \"It doesn't matter. There is no religious test f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645066561737371648",
    "text" : "To be honest, I think the proper answer to \"Is Obama a Muslim?\" question is: \"It doesn't matter. There is no religious test for office.\"",
    "id" : 645066561737371648,
    "created_at" : "2015-09-19 02:47:07 +0000",
    "user" : {
      "name" : "Jeet Heer",
      "screen_name" : "HeerJeet",
      "protected" : false,
      "id_str" : "604940737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771802394195668992\/sdiSWCGC_normal.jpg",
      "id" : 604940737,
      "verified" : true
    }
  },
  "id" : 645255542399746048,
  "created_at" : "2015-09-19 15:18:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda",
      "screen_name" : "lindasraven",
      "indices" : [ 3, 15 ],
      "id_str" : "2512480038",
      "id" : 2512480038
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lindasraven\/status\/642366209359511552\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/RBWqtAJAdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COokqFNW8AUScBR.jpg",
      "id_str" : "642366202225029125",
      "id" : 642366202225029125,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COokqFNW8AUScBR.jpg",
      "sizes" : [ {
        "h" : 693,
        "resize" : "fit",
        "w" : 693
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 693
      } ],
      "display_url" : "pic.twitter.com\/RBWqtAJAdu"
    } ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 45, 57 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 58, 67 ]
    }, {
      "text" : "nature",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "squirrel",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645255290171052032",
  "text" : "RT @lindasraven: Another shot of this cutie\u263A\n#photography #wildlife #nature #squirrel http:\/\/t.co\/RBWqtAJAdu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lindasraven\/status\/642366209359511552\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/RBWqtAJAdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COokqFNW8AUScBR.jpg",
        "id_str" : "642366202225029125",
        "id" : 642366202225029125,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COokqFNW8AUScBR.jpg",
        "sizes" : [ {
          "h" : 693,
          "resize" : "fit",
          "w" : 693
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 693
        } ],
        "display_url" : "pic.twitter.com\/RBWqtAJAdu"
      } ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 28, 40 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "nature",
        "indices" : [ 51, 58 ]
      }, {
        "text" : "squirrel",
        "indices" : [ 59, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642366209359511552",
    "text" : "Another shot of this cutie\u263A\n#photography #wildlife #nature #squirrel http:\/\/t.co\/RBWqtAJAdu",
    "id" : 642366209359511552,
    "created_at" : "2015-09-11 15:56:53 +0000",
    "user" : {
      "name" : "Linda",
      "screen_name" : "lindasraven",
      "protected" : false,
      "id_str" : "2512480038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559387084755324929\/jP1NuQNI_normal.jpeg",
      "id" : 2512480038,
      "verified" : false
    }
  },
  "id" : 645255290171052032,
  "created_at" : "2015-09-19 15:17:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645253534334758912",
  "geo" : { },
  "id_str" : "645254990722953216",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe oh dear ((hugs))",
  "id" : 645254990722953216,
  "in_reply_to_status_id" : 645253534334758912,
  "created_at" : "2015-09-19 15:15:52 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/645253560368664576\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/5pQYy3PbZB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRmrtlVAAEUzZX.jpg",
      "id_str" : "645253547777392641",
      "id" : 645253547777392641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRmrtlVAAEUzZX.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5pQYy3PbZB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645254803480821760",
  "text" : "RT @MimiMadeira1: The funniest thing in today's Arizona Republic is by Mike Luckovich http:\/\/t.co\/5pQYy3PbZB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/645253560368664576\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/5pQYy3PbZB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPRmrtlVAAEUzZX.jpg",
        "id_str" : "645253547777392641",
        "id" : 645253547777392641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPRmrtlVAAEUzZX.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5pQYy3PbZB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645253560368664576",
    "text" : "The funniest thing in today's Arizona Republic is by Mike Luckovich http:\/\/t.co\/5pQYy3PbZB",
    "id" : 645253560368664576,
    "created_at" : "2015-09-19 15:10:11 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 645254803480821760,
  "created_at" : "2015-09-19 15:15:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645254722031611904",
  "text" : "RT @Swanwhisperer: SWANWATCH - mute swans numbers have started to rise to the canal , with 10 in yesterday .Good too see last years juvs ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/645195191801020416\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/trBqBM2OKx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPQxkAKW8AAk1la.jpg",
        "id_str" : "645195141209321472",
        "id" : 645195141209321472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPQxkAKW8AAk1la.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/trBqBM2OKx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645195191801020416",
    "text" : "SWANWATCH - mute swans numbers have started to rise to the canal , with 10 in yesterday .Good too see last years juvs http:\/\/t.co\/trBqBM2OKx",
    "id" : 645195191801020416,
    "created_at" : "2015-09-19 11:18:15 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 645254722031611904,
  "created_at" : "2015-09-19 15:14:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ponta \uD83E\uDD82",
      "screen_name" : "typicalfeminist",
      "indices" : [ 3, 19 ],
      "id_str" : "248890039",
      "id" : 248890039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644984888286953472",
  "text" : "RT @typicalfeminist: If you're against abortion, you should be fighting FOR affordable and accessible birth control. Not trying to defund i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IStandWithPP",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644957735377879040",
    "text" : "If you're against abortion, you should be fighting FOR affordable and accessible birth control. Not trying to defund it. #IStandWithPP",
    "id" : 644957735377879040,
    "created_at" : "2015-09-18 19:34:41 +0000",
    "user" : {
      "name" : "Ponta \uD83E\uDD82",
      "screen_name" : "typicalfeminist",
      "protected" : false,
      "id_str" : "248890039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641260022559846400\/x3nlKSRl_normal.png",
      "id" : 248890039,
      "verified" : false
    }
  },
  "id" : 644984888286953472,
  "created_at" : "2015-09-18 21:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/644569918197886977\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/mRuMLci8II",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPH46PGWsAA483U.jpg",
      "id_str" : "644569901059977216",
      "id" : 644569901059977216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPH46PGWsAA483U.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mRuMLci8II"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644978399480532993",
  "text" : "RT @Salmonae1: Sparrow on the Rhododendron flower http:\/\/t.co\/mRuMLci8II",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/644569918197886977\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/mRuMLci8II",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPH46PGWsAA483U.jpg",
        "id_str" : "644569901059977216",
        "id" : 644569901059977216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPH46PGWsAA483U.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mRuMLci8II"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644569918197886977",
    "text" : "Sparrow on the Rhododendron flower http:\/\/t.co\/mRuMLci8II",
    "id" : 644569918197886977,
    "created_at" : "2015-09-17 17:53:38 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 644978399480532993,
  "created_at" : "2015-09-18 20:56:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Woodland Trust",
      "screen_name" : "WoodlandTrust",
      "indices" : [ 3, 17 ],
      "id_str" : "19396413",
      "id" : 19396413
    }, {
      "name" : "Hants & IOW Wildlife",
      "screen_name" : "HantsIWWildlife",
      "indices" : [ 22, 38 ],
      "id_str" : "243651212",
      "id" : 243651212
    }, {
      "name" : "Northcourt House",
      "screen_name" : "NorthcourtHouse",
      "indices" : [ 62, 78 ],
      "id_str" : "2318480887",
      "id" : 2318480887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644978223231692800",
  "text" : "RT @WoodlandTrust: MT @HantsIWWildlife: lovely dormouse found @NorthcourtHouse. Agile &amp; mainly nocturnal, dormice are hard to spot! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hants & IOW Wildlife",
        "screen_name" : "HantsIWWildlife",
        "indices" : [ 3, 19 ],
        "id_str" : "243651212",
        "id" : 243651212
      }, {
        "name" : "Northcourt House",
        "screen_name" : "NorthcourtHouse",
        "indices" : [ 43, 59 ],
        "id_str" : "2318480887",
        "id" : 2318480887
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NorthcourtHouse\/status\/642015645350109184\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/dOYx3GqjQ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COjl03MWcAALfBN.jpg",
        "id_str" : "642015643232006144",
        "id" : 642015643232006144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COjl03MWcAALfBN.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dOYx3GqjQ2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642260805765963776",
    "text" : "MT @HantsIWWildlife: lovely dormouse found @NorthcourtHouse. Agile &amp; mainly nocturnal, dormice are hard to spot! http:\/\/t.co\/dOYx3GqjQ2",
    "id" : 642260805765963776,
    "created_at" : "2015-09-11 08:58:03 +0000",
    "user" : {
      "name" : "The Woodland Trust",
      "screen_name" : "WoodlandTrust",
      "protected" : false,
      "id_str" : "19396413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3767503798\/072d99980f1842cc81731e9df98a7fc3_normal.jpeg",
      "id" : 19396413,
      "verified" : true
    }
  },
  "id" : 644978223231692800,
  "created_at" : "2015-09-18 20:56:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica",
      "screen_name" : "Ca_lassic",
      "indices" : [ 3, 13 ],
      "id_str" : "1083110029",
      "id" : 1083110029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644973042574213121",
  "text" : "RT @Ca_lassic: Considering ZERO federal funding goes towards abortion, defunding PP is nothing but an attack on low income women. #IStandWi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IStandWithPP",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644945546235482112",
    "text" : "Considering ZERO federal funding goes towards abortion, defunding PP is nothing but an attack on low income women. #IStandWithPP",
    "id" : 644945546235482112,
    "created_at" : "2015-09-18 18:46:15 +0000",
    "user" : {
      "name" : "Erica",
      "screen_name" : "Ca_lassic",
      "protected" : false,
      "id_str" : "1083110029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714440002583859201\/fd2nPNVF_normal.jpg",
      "id" : 1083110029,
      "verified" : false
    }
  },
  "id" : 644973042574213121,
  "created_at" : "2015-09-18 20:35:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Wyland",
      "screen_name" : "kennywyland",
      "indices" : [ 3, 15 ],
      "id_str" : "17197717",
      "id" : 17197717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644972955634659328",
  "text" : "RT @kennywyland: I've been denied by three Urgent Care clinics b\/c they accept insurance for my GROUP but not PROVIDER.\n\nTHIS IS WHY WE NEE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644970906054340608",
    "text" : "I've been denied by three Urgent Care clinics b\/c they accept insurance for my GROUP but not PROVIDER.\n\nTHIS IS WHY WE NEED SINGLE PAYER.",
    "id" : 644970906054340608,
    "created_at" : "2015-09-18 20:27:01 +0000",
    "user" : {
      "name" : "Kenny Wyland",
      "screen_name" : "kennywyland",
      "protected" : false,
      "id_str" : "17197717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000733694211\/8e2f5afc73c47cd1aa96d51a3427a810_normal.png",
      "id" : 17197717,
      "verified" : false
    }
  },
  "id" : 644972955634659328,
  "created_at" : "2015-09-18 20:35:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tessa Dare",
      "screen_name" : "TessaDare",
      "indices" : [ 3, 13 ],
      "id_str" : "24810051",
      "id" : 24810051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644957031544299520",
  "text" : "RT @TessaDare: My pick for the $10 bill would be Sojourner Truth. Psst, candidates - feel free to crib that answer next time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644376464180162560",
    "text" : "My pick for the $10 bill would be Sojourner Truth. Psst, candidates - feel free to crib that answer next time.",
    "id" : 644376464180162560,
    "created_at" : "2015-09-17 05:04:55 +0000",
    "user" : {
      "name" : "Tessa Dare",
      "screen_name" : "TessaDare",
      "protected" : false,
      "id_str" : "24810051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799797121503244290\/a3Me_7ee_normal.jpg",
      "id" : 24810051,
      "verified" : true
    }
  },
  "id" : 644957031544299520,
  "created_at" : "2015-09-18 19:31:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Dote",
      "screen_name" : "AuntieDote",
      "indices" : [ 3, 14 ],
      "id_str" : "362602281",
      "id" : 362602281
    }, {
      "name" : "Rio Slade",
      "screen_name" : "RioSlade",
      "indices" : [ 43, 52 ],
      "id_str" : "409503621",
      "id" : 409503621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644956957296734209",
  "text" : "RT @AuntieDote: Goliath takes on David MT \"@RioSlade: they're saying every Palestinian youth stone-thrower... is an enemy combatant\nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rio Slade",
        "screen_name" : "RioSlade",
        "indices" : [ 27, 36 ],
        "id_str" : "409503621",
        "id" : 409503621
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/RSCa9J1nGG",
        "expanded_url" : "http:\/\/www.rt.com\/news\/315801-jerusalem-approves-sniper-fire\/",
        "display_url" : "rt.com\/news\/315801-je\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "644952038061813760",
    "geo" : { },
    "id_str" : "644955168619032580",
    "in_reply_to_user_id" : 409503621,
    "text" : "Goliath takes on David MT \"@RioSlade: they're saying every Palestinian youth stone-thrower... is an enemy combatant\nhttp:\/\/t.co\/RSCa9J1nGG\"",
    "id" : 644955168619032580,
    "in_reply_to_status_id" : 644952038061813760,
    "created_at" : "2015-09-18 19:24:29 +0000",
    "in_reply_to_screen_name" : "RioSlade",
    "in_reply_to_user_id_str" : "409503621",
    "user" : {
      "name" : "Auntie Dote",
      "screen_name" : "AuntieDote",
      "protected" : false,
      "id_str" : "362602281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678216306135588864\/Cnh7A5FG_normal.jpg",
      "id" : 362602281,
      "verified" : false
    }
  },
  "id" : 644956957296734209,
  "created_at" : "2015-09-18 19:31:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    }, {
      "name" : "Planned Parenthood",
      "screen_name" : "PPFA",
      "indices" : [ 46, 51 ],
      "id_str" : "402957663",
      "id" : 402957663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/bWwvwJ5rpu",
      "expanded_url" : "http:\/\/news.yahoo.com\/house-bills-hit-planned-parenthood-abortion-doctors-071656307--politics.html",
      "display_url" : "news.yahoo.com\/house-bills-hi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644934501957824512",
  "text" : "RT @RevDebra: Breaking: House votes to defund @PPFA http:\/\/t.co\/bWwvwJ5rpu To be clear, gov't funding supports BIRTH CONTROL.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Planned Parenthood",
        "screen_name" : "PPFA",
        "indices" : [ 32, 37 ],
        "id_str" : "402957663",
        "id" : 402957663
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/bWwvwJ5rpu",
        "expanded_url" : "http:\/\/news.yahoo.com\/house-bills-hit-planned-parenthood-abortion-doctors-071656307--politics.html",
        "display_url" : "news.yahoo.com\/house-bills-hi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644928650689794048",
    "text" : "Breaking: House votes to defund @PPFA http:\/\/t.co\/bWwvwJ5rpu To be clear, gov't funding supports BIRTH CONTROL.",
    "id" : 644928650689794048,
    "created_at" : "2015-09-18 17:39:07 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 644934501957824512,
  "created_at" : "2015-09-18 18:02:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644886220758085632",
  "geo" : { },
  "id_str" : "644930057178365952",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time \"align themselves with ideological agendas\" &lt;&lt; isnt that what THEY are doing?? gah.",
  "id" : 644930057178365952,
  "in_reply_to_status_id" : 644886220758085632,
  "created_at" : "2015-09-18 17:44:42 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644928206638870528",
  "text" : "also dd eats different since 1st episode. her body just got weird. the med pros just dont get that.",
  "id" : 644928206638870528,
  "created_at" : "2015-09-18 17:37:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noschedule",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644927681377779713",
  "text" : "when do you have breakfast? when I get up. when is that? whenever I get up. ... #noschedule",
  "id" : 644927681377779713,
  "created_at" : "2015-09-18 17:35:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644927243156889600",
  "text" : "nutritionist was inhouse yesterday when we went to dr appt so we saw her. didnt go so well. maybe some helpful info but prob not going back.",
  "id" : 644927243156889600,
  "created_at" : "2015-09-18 17:33:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644896422500925440",
  "geo" : { },
  "id_str" : "644925155282714624",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe i get it. ppl told me im too nice to \"discipline\" dd. she's always been sensitive. pushing her didnt work!",
  "id" : 644925155282714624,
  "in_reply_to_status_id" : 644896422500925440,
  "created_at" : "2015-09-18 17:25:13 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/xZoAopS1uO",
      "expanded_url" : "http:\/\/christianity-without-the-religion.blogspot.com\/2015\/09\/w-paul-young-saying-yes-or-no-to-god.html?spref=tw",
      "display_url" : "\u2026ity-without-the-religion.blogspot.com\/2015\/09\/w-paul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644908933660938241",
  "text" : "interesting... \"Christianity Without the Religion\" Blog: W. Paul Young - Saying Yes or No to God http:\/\/t.co\/xZoAopS1uO",
  "id" : 644908933660938241,
  "created_at" : "2015-09-18 16:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644673028626993152",
  "text" : "RT @ducksandclucks: Goosie sitting on my lap with her bill tucked in my shirt, snoozing. This is what a few crackers will\u2026 https:\/\/t.co\/5q1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/5q1wtWCxB8",
        "expanded_url" : "https:\/\/instagram.com\/p\/7wIJhjhHwv\/",
        "display_url" : "instagram.com\/p\/7wIJhjhHwv\/"
      } ]
    },
    "geo" : { },
    "id_str" : "644670681536438272",
    "text" : "Goosie sitting on my lap with her bill tucked in my shirt, snoozing. This is what a few crackers will\u2026 https:\/\/t.co\/5q1wtWCxB8",
    "id" : 644670681536438272,
    "created_at" : "2015-09-18 00:34:02 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 644673028626993152,
  "created_at" : "2015-09-18 00:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "indices" : [ 3, 19 ],
      "id_str" : "624392588",
      "id" : 624392588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644665704881496064",
  "text" : "RT @IvanMor79062729: Things are speeding up.\n\nWe are at the cusp of something BIG.\n\nAND SHITS ABOUT TO GET.... Very interesting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644662936686870528",
    "text" : "Things are speeding up.\n\nWe are at the cusp of something BIG.\n\nAND SHITS ABOUT TO GET.... Very interesting",
    "id" : 644662936686870528,
    "created_at" : "2015-09-18 00:03:16 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "protected" : false,
      "id_str" : "624392588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507966772410974208\/so1kO-9u_normal.jpeg",
      "id" : 624392588,
      "verified" : false
    }
  },
  "id" : 644665704881496064,
  "created_at" : "2015-09-18 00:14:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Howard",
      "screen_name" : "highland_andy",
      "indices" : [ 3, 17 ],
      "id_str" : "789877778",
      "id" : 789877778
    }, {
      "name" : "The Cairngorms",
      "screen_name" : "TheCairngorms",
      "indices" : [ 103, 117 ],
      "id_str" : "2166664801",
      "id" : 2166664801
    }, {
      "name" : "BTO Scotland",
      "screen_name" : "BTO_Scotland",
      "indices" : [ 118, 131 ],
      "id_str" : "966196788",
      "id" : 966196788
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ptarmigan",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "Cairngorms",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644649447264141312",
  "text" : "RT @highland_andy: #Ptarmigan striking a pose. BTW that's not rain, its a cloud of midges!\n#Cairngorms @TheCairngorms @BTO_Scotland http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Cairngorms",
        "screen_name" : "TheCairngorms",
        "indices" : [ 84, 98 ],
        "id_str" : "2166664801",
        "id" : 2166664801
      }, {
        "name" : "BTO Scotland",
        "screen_name" : "BTO_Scotland",
        "indices" : [ 99, 112 ],
        "id_str" : "966196788",
        "id" : 966196788
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/highland_andy\/status\/644581793446916096\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/fjGiAfXnVJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPIDuYwWoAARWj6.jpg",
        "id_str" : "644581792121528320",
        "id" : 644581792121528320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPIDuYwWoAARWj6.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fjGiAfXnVJ"
      } ],
      "hashtags" : [ {
        "text" : "Ptarmigan",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Cairngorms",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644581793446916096",
    "text" : "#Ptarmigan striking a pose. BTW that's not rain, its a cloud of midges!\n#Cairngorms @TheCairngorms @BTO_Scotland http:\/\/t.co\/fjGiAfXnVJ",
    "id" : 644581793446916096,
    "created_at" : "2015-09-17 18:40:49 +0000",
    "user" : {
      "name" : "Andy Howard",
      "screen_name" : "highland_andy",
      "protected" : false,
      "id_str" : "789877778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475227511757213696\/q9k4UPII_normal.jpeg",
      "id" : 789877778,
      "verified" : false
    }
  },
  "id" : 644649447264141312,
  "created_at" : "2015-09-17 23:09:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644644522048155648",
  "text" : "RT @DarciaHelle: Ever notice how doctors make you fill out 10 pages on your medical history before an appointment, but they never actually \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644643553713393664",
    "text" : "Ever notice how doctors make you fill out 10 pages on your medical history before an appointment, but they never actually read it?",
    "id" : 644643553713393664,
    "created_at" : "2015-09-17 22:46:14 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 644644522048155648,
  "created_at" : "2015-09-17 22:50:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Almond Valley",
      "screen_name" : "AlmondValleyHC",
      "indices" : [ 3, 18 ],
      "id_str" : "36094567",
      "id" : 36094567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlmondValleyHC\/status\/644554345183363072\/video\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/LiOwGdBwts",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644554224542568448\/pu\/img\/PtGn6C4SH8co1G7T.jpg",
      "id_str" : "644554224542568448",
      "id" : 644554224542568448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644554224542568448\/pu\/img\/PtGn6C4SH8co1G7T.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LiOwGdBwts"
    } ],
    "hashtags" : [ {
      "text" : "budgie",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "romance",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644603938084364289",
  "text" : "RT @AlmondValleyHC: #budgie #romance Too cute. Male on the right, female on the left. http:\/\/t.co\/LiOwGdBwts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlmondValleyHC\/status\/644554345183363072\/video\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/LiOwGdBwts",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644554224542568448\/pu\/img\/PtGn6C4SH8co1G7T.jpg",
        "id_str" : "644554224542568448",
        "id" : 644554224542568448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/644554224542568448\/pu\/img\/PtGn6C4SH8co1G7T.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LiOwGdBwts"
      } ],
      "hashtags" : [ {
        "text" : "budgie",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "romance",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644554345183363072",
    "text" : "#budgie #romance Too cute. Male on the right, female on the left. http:\/\/t.co\/LiOwGdBwts",
    "id" : 644554345183363072,
    "created_at" : "2015-09-17 16:51:45 +0000",
    "user" : {
      "name" : "Almond Valley",
      "screen_name" : "AlmondValleyHC",
      "protected" : false,
      "id_str" : "36094567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188455212\/logo_normal.jpg",
      "id" : 36094567,
      "verified" : false
    }
  },
  "id" : 644603938084364289,
  "created_at" : "2015-09-17 20:08:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Roberts, M.A.",
      "screen_name" : "KimRoberts108",
      "indices" : [ 3, 17 ],
      "id_str" : "253865582",
      "id" : 253865582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644534831322234880",
  "text" : "RT @KimRoberts108: \"Anxiety has now surpassed depression as the most common mental health diagnosis among college students.\"... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/AOZIKqOShv",
        "expanded_url" : "http:\/\/fb.me\/H9mUoKkI",
        "display_url" : "fb.me\/H9mUoKkI"
      } ]
    },
    "geo" : { },
    "id_str" : "644360271096643584",
    "text" : "\"Anxiety has now surpassed depression as the most common mental health diagnosis among college students.\"... http:\/\/t.co\/AOZIKqOShv",
    "id" : 644360271096643584,
    "created_at" : "2015-09-17 04:00:34 +0000",
    "user" : {
      "name" : "Kim Roberts, M.A.",
      "screen_name" : "KimRoberts108",
      "protected" : false,
      "id_str" : "253865582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491705675261571072\/UKeCnXQw_normal.jpeg",
      "id" : 253865582,
      "verified" : false
    }
  },
  "id" : 644534831322234880,
  "created_at" : "2015-09-17 15:34:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/VKRZY2wxYQ",
      "expanded_url" : "https:\/\/youtu.be\/acTIZt3NgAM",
      "display_url" : "youtu.be\/acTIZt3NgAM"
    } ]
  },
  "geo" : { },
  "id_str" : "644522143896707072",
  "text" : "How a Mama horse teaches her baby https:\/\/t.co\/VKRZY2wxYQ",
  "id" : 644522143896707072,
  "created_at" : "2015-09-17 14:43:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angiepooos",
      "screen_name" : "Angiepooos",
      "indices" : [ 3, 14 ],
      "id_str" : "26450811",
      "id" : 26450811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Angiepooos\/status\/641353572802674689\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/vBAWDY2kwn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COaLrKdVAAAVp1-.jpg",
      "id_str" : "641353570604875776",
      "id" : 641353570604875776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COaLrKdVAAAVp1-.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1129,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1588,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vBAWDY2kwn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644513179993796608",
  "text" : "RT @Angiepooos: Such a lovely bond with this Welsh Mountain pony mum and foal. http:\/\/t.co\/vBAWDY2kwn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Angiepooos\/status\/641353572802674689\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/vBAWDY2kwn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COaLrKdVAAAVp1-.jpg",
        "id_str" : "641353570604875776",
        "id" : 641353570604875776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COaLrKdVAAAVp1-.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1129,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1588,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vBAWDY2kwn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641353572802674689",
    "text" : "Such a lovely bond with this Welsh Mountain pony mum and foal. http:\/\/t.co\/vBAWDY2kwn",
    "id" : 641353572802674689,
    "created_at" : "2015-09-08 20:53:02 +0000",
    "user" : {
      "name" : "Angiepooos",
      "screen_name" : "Angiepooos",
      "protected" : false,
      "id_str" : "26450811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772708667011522560\/cTnbL2AZ_normal.jpg",
      "id" : 26450811,
      "verified" : false
    }
  },
  "id" : 644513179993796608,
  "created_at" : "2015-09-17 14:08:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angiepooos",
      "screen_name" : "Angiepooos",
      "indices" : [ 3, 14 ],
      "id_str" : "26450811",
      "id" : 26450811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Angiepooos\/status\/644222242323361792\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/m4reArUYt3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPC8twVXAAUfXZ4.jpg",
      "id_str" : "644222240968605701",
      "id" : 644222240968605701,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPC8twVXAAUfXZ4.jpg",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 959,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/m4reArUYt3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644298698055397376",
  "text" : "RT @Angiepooos: Geese coming into land tonight, got lucky with this shot! http:\/\/t.co\/m4reArUYt3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Angiepooos\/status\/644222242323361792\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/m4reArUYt3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPC8twVXAAUfXZ4.jpg",
        "id_str" : "644222240968605701",
        "id" : 644222240968605701,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPC8twVXAAUfXZ4.jpg",
        "sizes" : [ {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 959,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/m4reArUYt3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644222242323361792",
    "text" : "Geese coming into land tonight, got lucky with this shot! http:\/\/t.co\/m4reArUYt3",
    "id" : 644222242323361792,
    "created_at" : "2015-09-16 18:52:06 +0000",
    "user" : {
      "name" : "Angiepooos",
      "screen_name" : "Angiepooos",
      "protected" : false,
      "id_str" : "26450811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772708667011522560\/cTnbL2AZ_normal.jpg",
      "id" : 26450811,
      "verified" : false
    }
  },
  "id" : 644298698055397376,
  "created_at" : "2015-09-16 23:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Pass",
      "screen_name" : "steven_pass",
      "indices" : [ 3, 15 ],
      "id_str" : "2311437785",
      "id" : 2311437785
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/644206625620914177\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/N7sH8FwL0L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCudZ_WUAAn7we.jpg",
      "id_str" : "644206566930010112",
      "id" : 644206566930010112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCudZ_WUAAn7we.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/N7sH8FwL0L"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/644206625620914177\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/N7sH8FwL0L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCufP9WoAEBa9N.jpg",
      "id_str" : "644206598597025793",
      "id" : 644206598597025793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCufP9WoAEBa9N.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/N7sH8FwL0L"
    } ],
    "hashtags" : [ {
      "text" : "highlandcattle",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644288726844211200",
  "text" : "RT @steven_pass: Hanna says hello. #highlandcattle http:\/\/t.co\/N7sH8FwL0L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/644206625620914177\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/N7sH8FwL0L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCudZ_WUAAn7we.jpg",
        "id_str" : "644206566930010112",
        "id" : 644206566930010112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCudZ_WUAAn7we.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/N7sH8FwL0L"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/644206625620914177\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/N7sH8FwL0L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCufP9WoAEBa9N.jpg",
        "id_str" : "644206598597025793",
        "id" : 644206598597025793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCufP9WoAEBa9N.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/N7sH8FwL0L"
      } ],
      "hashtags" : [ {
        "text" : "highlandcattle",
        "indices" : [ 18, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644206625620914177",
    "text" : "Hanna says hello. #highlandcattle http:\/\/t.co\/N7sH8FwL0L",
    "id" : 644206625620914177,
    "created_at" : "2015-09-16 17:50:02 +0000",
    "user" : {
      "name" : "Steven Pass",
      "screen_name" : "steven_pass",
      "protected" : false,
      "id_str" : "2311437785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792643598831452160\/puKwwP4Y_normal.jpg",
      "id" : 2311437785,
      "verified" : false
    }
  },
  "id" : 644288726844211200,
  "created_at" : "2015-09-16 23:16:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Danger Guerrero",
      "screen_name" : "dangerguerrero",
      "indices" : [ 3, 18 ],
      "id_str" : "707647734832979968",
      "id" : 707647734832979968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644287220665438208",
  "text" : "RT @DangerGuerrero: BREAKING: The British appear to have developed some sort of giant bomb, possibly attached to a rocket. http:\/\/t.co\/KMAl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DangerGuerrero\/status\/644200972093399040\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/KMAltDZvP7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCo4wBWUAEdoKa.jpg",
        "id_str" : "644200439630680065",
        "id" : 644200439630680065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCo4wBWUAEdoKa.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/KMAltDZvP7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644200972093399040",
    "text" : "BREAKING: The British appear to have developed some sort of giant bomb, possibly attached to a rocket. http:\/\/t.co\/KMAltDZvP7",
    "id" : 644200972093399040,
    "created_at" : "2015-09-16 17:27:35 +0000",
    "user" : {
      "name" : "Brian Grubb",
      "screen_name" : "briancgrubb",
      "protected" : false,
      "id_str" : "106116852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705812383449686016\/qrEoSqv2_normal.jpg",
      "id" : 106116852,
      "verified" : true
    }
  },
  "id" : 644287220665438208,
  "created_at" : "2015-09-16 23:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/644286025938944000\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/rUTQD4AQfX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPD2uYPW8AA8GiO.jpg",
      "id_str" : "644286023355265024",
      "id" : 644286023355265024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPD2uYPW8AA8GiO.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 802
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 802
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rUTQD4AQfX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ZHk1367SLE",
      "expanded_url" : "http:\/\/www.hushtinnitus.com\/home?c2=SU&did=567911&au=9ce2a339acd1112a&ts=117068647.28&_ts=1442444732#",
      "display_url" : "hushtinnitus.com\/home?c2=SU&did\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644286025938944000",
  "text" : "preview test on page... Instant tinnitus relief \u2013 custom sound therapy, only $29.95 http:\/\/t.co\/ZHk1367SLE http:\/\/t.co\/rUTQD4AQfX",
  "id" : 644286025938944000,
  "created_at" : "2015-09-16 23:05:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644268438626566146",
  "text" : "RT @umairh: Can we try to treat every nerdy minority kid, outcast, person who doesn't quite fit, with the same love we're now treating Ahme\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644263894010216449",
    "text" : "Can we try to treat every nerdy minority kid, outcast, person who doesn't quite fit, with the same love we're now treating Ahmed? Thanks \uD83D\uDE0E\uD83D\uDC4D",
    "id" : 644263894010216449,
    "created_at" : "2015-09-16 21:37:36 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 644268438626566146,
  "created_at" : "2015-09-16 21:55:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644251578208272384",
  "geo" : { },
  "id_str" : "644262297393762304",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley i thought i was going to die.. DD came running cuz I screamed..lol",
  "id" : 644262297393762304,
  "in_reply_to_status_id" : 644251578208272384,
  "created_at" : "2015-09-16 21:31:16 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644238777808908288",
  "text" : "think im gonna have a blister from the coffee pot. snapped on lid and my pinkie skin got caught.. OUCH!!!",
  "id" : 644238777808908288,
  "created_at" : "2015-09-16 19:57:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/644229792666112000\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/URdTeyc8rf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPDDlImW8AEPejo.jpg",
      "id_str" : "644229789444927489",
      "id" : 644229789444927489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPDDlImW8AEPejo.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/URdTeyc8rf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ZEE1IIswPi",
      "expanded_url" : "http:\/\/www.addictinginfo.org\/2015\/09\/15\/mi-hospital-denies-pregnant-woman-medical-treatment-because-religion-video\/",
      "display_url" : "addictinginfo.org\/2015\/09\/15\/mi-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644229792666112000",
  "text" : "MI Hospital Denies Pregnant Woman Medical Treatment Because \u2018Religion\u2019 (... http:\/\/t.co\/ZEE1IIswPi http:\/\/t.co\/URdTeyc8rf",
  "id" : 644229792666112000,
  "created_at" : "2015-09-16 19:22:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "feedly",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/rtGqaKW0Vi",
      "expanded_url" : "http:\/\/www.flyinginthespirit.cuttys.net\/2015\/09\/16\/teaching-about-hell\/",
      "display_url" : "flyinginthespirit.cuttys.net\/2015\/09\/16\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644202117859790848",
  "text" : "Teaching about Hell? http:\/\/t.co\/rtGqaKW0Vi #religion #feedly",
  "id" : 644202117859790848,
  "created_at" : "2015-09-16 17:32:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/HZqgFs73NF",
      "expanded_url" : "https:\/\/vine.co\/v\/eUMpdKWH2iX",
      "display_url" : "vine.co\/v\/eUMpdKWH2iX"
    } ]
  },
  "geo" : { },
  "id_str" : "644197965154906112",
  "text" : "RT @ZwartblesIE: Heavy breathing with kisses. What more do you want? https:\/\/t.co\/HZqgFs73NF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/HZqgFs73NF",
        "expanded_url" : "https:\/\/vine.co\/v\/eUMpdKWH2iX",
        "display_url" : "vine.co\/v\/eUMpdKWH2iX"
      } ]
    },
    "geo" : { },
    "id_str" : "644174605284954112",
    "text" : "Heavy breathing with kisses. What more do you want? https:\/\/t.co\/HZqgFs73NF",
    "id" : 644174605284954112,
    "created_at" : "2015-09-16 15:42:48 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 644197965154906112,
  "created_at" : "2015-09-16 17:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sockyarnshop.com",
      "screen_name" : "SockYarnShop",
      "indices" : [ 3, 16 ],
      "id_str" : "215578621",
      "id" : 215578621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SockYarnShop\/status\/644189605714075648\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/sIcM7genS0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCfCEqWIAAsvgd.jpg",
      "id_str" : "644189604673888256",
      "id" : 644189604673888256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCfCEqWIAAsvgd.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/sIcM7genS0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644197511377354753",
  "text" : "RT @SockYarnShop: hopeful Leonard http:\/\/t.co\/sIcM7genS0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SockYarnShop\/status\/644189605714075648\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/sIcM7genS0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPCfCEqWIAAsvgd.jpg",
        "id_str" : "644189604673888256",
        "id" : 644189604673888256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPCfCEqWIAAsvgd.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/sIcM7genS0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644189605714075648",
    "text" : "hopeful Leonard http:\/\/t.co\/sIcM7genS0",
    "id" : 644189605714075648,
    "created_at" : "2015-09-16 16:42:25 +0000",
    "user" : {
      "name" : "sockyarnshop.com",
      "screen_name" : "SockYarnShop",
      "protected" : false,
      "id_str" : "215578621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1409679918\/DSC_0212_normal.jpg",
      "id" : 215578621,
      "verified" : false
    }
  },
  "id" : 644197511377354753,
  "created_at" : "2015-09-16 17:13:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644194586055806976",
  "text" : "RT @POTUS: Cool clock, Ahmed. Want to bring it to the White House? We should inspire more kids like you to like science. It's what makes Am\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644193755814342656",
    "text" : "Cool clock, Ahmed. Want to bring it to the White House? We should inspire more kids like you to like science. It's what makes America great.",
    "id" : 644193755814342656,
    "created_at" : "2015-09-16 16:58:54 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 644194586055806976,
  "created_at" : "2015-09-16 17:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644190984738369536",
  "text" : "so now DD will get her ativan from mh office instead of her reg doc.",
  "id" : 644190984738369536,
  "created_at" : "2015-09-16 16:47:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644190428674281472",
  "text" : "1st intake therapy appt for DD today went well. next one goes into personal issues (im anxious becuz im sick?). she mentioned aspergers.",
  "id" : 644190428674281472,
  "created_at" : "2015-09-16 16:45:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Asher Johnson",
      "screen_name" : "astrojohnjohn",
      "indices" : [ 3, 17 ],
      "id_str" : "1128725844",
      "id" : 1128725844
    }, {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 20, 30 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644189460675055616",
  "text" : "RT @astrojohnjohn: .@ShaunKing Next time I see a white kid walking across MIT campus with a piece of electronics, I'm calling the cops unle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shaun King",
        "screen_name" : "ShaunKing",
        "indices" : [ 1, 11 ],
        "id_str" : "755113",
        "id" : 755113
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "644175344887574532",
    "geo" : { },
    "id_str" : "644178802948620288",
    "in_reply_to_user_id" : 755113,
    "text" : ".@ShaunKing Next time I see a white kid walking across MIT campus with a piece of electronics, I'm calling the cops unless broadly explained",
    "id" : 644178802948620288,
    "in_reply_to_status_id" : 644175344887574532,
    "created_at" : "2015-09-16 15:59:29 +0000",
    "in_reply_to_screen_name" : "ShaunKing",
    "in_reply_to_user_id_str" : "755113",
    "user" : {
      "name" : "John Asher Johnson",
      "screen_name" : "astrojohnjohn",
      "protected" : false,
      "id_str" : "1128725844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636611469287682052\/6qTX_YjU_normal.jpg",
      "id" : 1128725844,
      "verified" : false
    }
  },
  "id" : 644189460675055616,
  "created_at" : "2015-09-16 16:41:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allan Thompson",
      "screen_name" : "allandthompson",
      "indices" : [ 3, 18 ],
      "id_str" : "108323737",
      "id" : 108323737
    }, {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 20, 30 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644189390034595840",
  "text" : "RT @allandthompson: @ShaunKing they were trying to bully him into a confession. Sickening.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shaun King",
        "screen_name" : "ShaunKing",
        "indices" : [ 0, 10 ],
        "id_str" : "755113",
        "id" : 755113
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "644175344887574532",
    "geo" : { },
    "id_str" : "644175824124403712",
    "in_reply_to_user_id" : 755113,
    "text" : "@ShaunKing they were trying to bully him into a confession. Sickening.",
    "id" : 644175824124403712,
    "in_reply_to_status_id" : 644175344887574532,
    "created_at" : "2015-09-16 15:47:39 +0000",
    "in_reply_to_screen_name" : "ShaunKing",
    "in_reply_to_user_id_str" : "755113",
    "user" : {
      "name" : "Allan Thompson",
      "screen_name" : "allandthompson",
      "protected" : false,
      "id_str" : "108323737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557592251371511809\/prKnLKMM_normal.jpeg",
      "id" : 108323737,
      "verified" : false
    }
  },
  "id" : 644189390034595840,
  "created_at" : "2015-09-16 16:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 3, 15 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644188320038289408",
  "text" : "RT @marcoarment: Worst part of Ahmed\u2019s story is the culture of \u201Carrest first, ask later.\u201D\n\nAn arrest is major psychological trauma. He\u2019s af\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644151582737743872",
    "text" : "Worst part of Ahmed\u2019s story is the culture of \u201Carrest first, ask later.\u201D\n\nAn arrest is major psychological trauma. He\u2019s affected for LIFE.",
    "id" : 644151582737743872,
    "created_at" : "2015-09-16 14:11:19 +0000",
    "user" : {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "protected" : false,
      "id_str" : "14231571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1282173124\/untitled-158-2_normal.jpg",
      "id" : 14231571,
      "verified" : true
    }
  },
  "id" : 644188320038289408,
  "created_at" : "2015-09-16 16:37:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fam'ron",
      "screen_name" : "kidnoble",
      "indices" : [ 3, 12 ],
      "id_str" : "23406730",
      "id" : 23406730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644126789699268613",
  "text" : "RT @kidnoble: Sometimes holding onto things does more damage than what we perceive will happen by letting go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643942057682317313",
    "text" : "Sometimes holding onto things does more damage than what we perceive will happen by letting go.",
    "id" : 643942057682317313,
    "created_at" : "2015-09-16 00:18:45 +0000",
    "user" : {
      "name" : "Fam'ron",
      "screen_name" : "kidnoble",
      "protected" : false,
      "id_str" : "23406730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794390882799599616\/fBsQnv9F_normal.jpg",
      "id" : 23406730,
      "verified" : false
    }
  },
  "id" : 644126789699268613,
  "created_at" : "2015-09-16 12:32:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy G",
      "screen_name" : "GuellichPhoto",
      "indices" : [ 3, 17 ],
      "id_str" : "2216765432",
      "id" : 2216765432
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/643963915089539072\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/BwdYszXc8J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO_RwafUwAA2GPY.jpg",
      "id_str" : "643963901411901440",
      "id" : 643963901411901440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO_RwafUwAA2GPY.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BwdYszXc8J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644126602536820736",
  "text" : "RT @GuellichPhoto: Wow.... http:\/\/t.co\/BwdYszXc8J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/643963915089539072\/photo\/1",
        "indices" : [ 8, 30 ],
        "url" : "http:\/\/t.co\/BwdYszXc8J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CO_RwafUwAA2GPY.jpg",
        "id_str" : "643963901411901440",
        "id" : 643963901411901440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO_RwafUwAA2GPY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BwdYszXc8J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643963915089539072",
    "text" : "Wow.... http:\/\/t.co\/BwdYszXc8J",
    "id" : 643963915089539072,
    "created_at" : "2015-09-16 01:45:36 +0000",
    "user" : {
      "name" : "Kathy G",
      "screen_name" : "GuellichPhoto",
      "protected" : false,
      "id_str" : "2216765432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712289505932214272\/O9BsG-vM_normal.jpg",
      "id" : 2216765432,
      "verified" : false
    }
  },
  "id" : 644126602536820736,
  "created_at" : "2015-09-16 12:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643980261705785345",
  "geo" : { },
  "id_str" : "644125476731125761",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle (((hugs)))",
  "id" : 644125476731125761,
  "in_reply_to_status_id" : 643980261705785345,
  "created_at" : "2015-09-16 12:27:35 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynley wyeth",
      "screen_name" : "LynleyWyeth",
      "indices" : [ 3, 15 ],
      "id_str" : "3399621073",
      "id" : 3399621073
    }, {
      "name" : "Sophie Barnes",
      "screen_name" : "SheepishSophie",
      "indices" : [ 17, 32 ],
      "id_str" : "26878636",
      "id" : 26878636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LynleyWyeth\/status\/644019093809446912\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/RsItAcPPmq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPAD0qVUAAA3SFg.jpg",
      "id_str" : "644018949965742080",
      "id" : 644018949965742080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPAD0qVUAAA3SFg.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RsItAcPPmq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644123895503654913",
  "text" : "RT @LynleyWyeth: @SheepishSophie  -spot the odd me out! http:\/\/t.co\/RsItAcPPmq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sophie Barnes",
        "screen_name" : "SheepishSophie",
        "indices" : [ 0, 15 ],
        "id_str" : "26878636",
        "id" : 26878636
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LynleyWyeth\/status\/644019093809446912\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/RsItAcPPmq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPAD0qVUAAA3SFg.jpg",
        "id_str" : "644018949965742080",
        "id" : 644018949965742080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPAD0qVUAAA3SFg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RsItAcPPmq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644019093809446912",
    "in_reply_to_user_id" : 26878636,
    "text" : "@SheepishSophie  -spot the odd me out! http:\/\/t.co\/RsItAcPPmq",
    "id" : 644019093809446912,
    "created_at" : "2015-09-16 05:24:51 +0000",
    "in_reply_to_screen_name" : "SheepishSophie",
    "in_reply_to_user_id_str" : "26878636",
    "user" : {
      "name" : "Lynley wyeth",
      "screen_name" : "LynleyWyeth",
      "protected" : false,
      "id_str" : "3399621073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730697190549508097\/MxJ4hkzu_normal.jpg",
      "id" : 3399621073,
      "verified" : false
    }
  },
  "id" : 644123895503654913,
  "created_at" : "2015-09-16 12:21:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles PM",
      "screen_name" : "CharlesPulliam",
      "indices" : [ 3, 18 ],
      "id_str" : "19189000",
      "id" : 19189000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/0FhUZeP2OR",
      "expanded_url" : "http:\/\/fusion.net\/story\/197958\/irving-texas-police-arrest-muslim-teen-clock\/",
      "display_url" : "fusion.net\/story\/197958\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644123651495825408",
  "text" : "RT @CharlesPulliam: Irving Texas police arrest Muslim high school inventor for building a clock: http:\/\/t.co\/0FhUZeP2OR http:\/\/t.co\/pEKPEhe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CharlesPulliam\/status\/644052653018845184\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/pEKPEheBDj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPAiXikW8AAobyg.png",
        "id_str" : "644052534525620224",
        "id" : 644052534525620224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPAiXikW8AAobyg.png",
        "sizes" : [ {
          "h" : 717,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 970
        } ],
        "display_url" : "pic.twitter.com\/pEKPEheBDj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/0FhUZeP2OR",
        "expanded_url" : "http:\/\/fusion.net\/story\/197958\/irving-texas-police-arrest-muslim-teen-clock\/",
        "display_url" : "fusion.net\/story\/197958\/i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644052653018845184",
    "text" : "Irving Texas police arrest Muslim high school inventor for building a clock: http:\/\/t.co\/0FhUZeP2OR http:\/\/t.co\/pEKPEheBDj",
    "id" : 644052653018845184,
    "created_at" : "2015-09-16 07:38:13 +0000",
    "user" : {
      "name" : "Charles PM",
      "screen_name" : "CharlesPulliam",
      "protected" : false,
      "id_str" : "19189000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797536207387422720\/fx7MX412_normal.jpg",
      "id" : 19189000,
      "verified" : true
    }
  },
  "id" : 644123651495825408,
  "created_at" : "2015-09-16 12:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Hughes",
      "screen_name" : "DurhamFarmer",
      "indices" : [ 3, 16 ],
      "id_str" : "2726316501",
      "id" : 2726316501
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DurhamFarmer\/status\/644070815252750336\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/L8lblr2wB3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPAy8uCWsAANHBm.jpg",
      "id_str" : "644070765445427200",
      "id" : 644070765445427200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPAy8uCWsAANHBm.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L8lblr2wB3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644122920667738112",
  "text" : "RT @DurhamFarmer: Abby making sure my morning is anything but dull (excuse the mud, it poured down yesterday) http:\/\/t.co\/L8lblr2wB3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DurhamFarmer\/status\/644070815252750336\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/L8lblr2wB3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPAy8uCWsAANHBm.jpg",
        "id_str" : "644070765445427200",
        "id" : 644070765445427200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPAy8uCWsAANHBm.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/L8lblr2wB3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644070815252750336",
    "text" : "Abby making sure my morning is anything but dull (excuse the mud, it poured down yesterday) http:\/\/t.co\/L8lblr2wB3",
    "id" : 644070815252750336,
    "created_at" : "2015-09-16 08:50:23 +0000",
    "user" : {
      "name" : "Al Hughes",
      "screen_name" : "DurhamFarmer",
      "protected" : false,
      "id_str" : "2726316501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761266853209575424\/Fp2QFAsL_normal.jpg",
      "id" : 2726316501,
      "verified" : false
    }
  },
  "id" : 644122920667738112,
  "created_at" : "2015-09-16 12:17:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 3, 7 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/YmPMeaxUCt",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/g9ub\/xmtp",
      "display_url" : "cards.twitter.com\/cards\/g9ub\/xmtp"
    } ]
  },
  "geo" : { },
  "id_str" : "643943841595326464",
  "text" : "RT @CNN: Don\u2019t miss round 2! The GOP debates start tomorrow at 6pET. https:\/\/t.co\/YmPMeaxUCt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/YmPMeaxUCt",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/g9ub\/xmtp",
        "display_url" : "cards.twitter.com\/cards\/g9ub\/xmtp"
      } ]
    },
    "geo" : { },
    "id_str" : "643635379497635840",
    "text" : "Don\u2019t miss round 2! The GOP debates start tomorrow at 6pET. https:\/\/t.co\/YmPMeaxUCt",
    "id" : 643635379497635840,
    "created_at" : "2015-09-15 04:00:07 +0000",
    "user" : {
      "name" : "CNN",
      "screen_name" : "CNN",
      "protected" : false,
      "id_str" : "759251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508960761826131968\/LnvhR8ED_normal.png",
      "id" : 759251,
      "verified" : true
    }
  },
  "id" : 643943841595326464,
  "created_at" : "2015-09-16 00:25:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/CWN5ASqWEf",
      "expanded_url" : "https:\/\/twitter.com\/lugmag\/status\/643167909045534721",
      "display_url" : "twitter.com\/lugmag\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643943263423041536",
  "text" : "RT @Irish_Atheist: Intersex people are....elves?  https:\/\/t.co\/CWN5ASqWEf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/CWN5ASqWEf",
        "expanded_url" : "https:\/\/twitter.com\/lugmag\/status\/643167909045534721",
        "display_url" : "twitter.com\/lugmag\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643942882584342528",
    "text" : "Intersex people are....elves?  https:\/\/t.co\/CWN5ASqWEf",
    "id" : 643942882584342528,
    "created_at" : "2015-09-16 00:22:01 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 643943263423041536,
  "created_at" : "2015-09-16 00:23:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/643943070170513408\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ve2tNAbGwg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO--zrxWoAAnRSt.jpg",
      "id_str" : "643943066869604352",
      "id" : 643943066869604352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO--zrxWoAAnRSt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/ve2tNAbGwg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/RHK0ExI9RQ",
      "expanded_url" : "http:\/\/www.theblaze.com\/stories\/2015\/07\/28\/ex-pastor-who-ignited-evangelical-furor-when-he-questioned-ideas-about-the-afterlife-explains-why-he-doesnt-believe-god-would-burn-people-in-hell-for-eternity\/",
      "display_url" : "theblaze.com\/stories\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643943070170513408",
  "text" : "What He Said About Hell and the Bible Rocked the Christian World. Here\u2019s What Ex-Pastor R... http:\/\/t.co\/RHK0ExI9RQ http:\/\/t.co\/ve2tNAbGwg",
  "id" : 643943070170513408,
  "created_at" : "2015-09-16 00:22:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Wolfson",
      "screen_name" : "EricWolfson",
      "indices" : [ 3, 15 ],
      "id_str" : "62510409",
      "id" : 62510409
    }, {
      "name" : "TheNewDeal",
      "screen_name" : "TheNewDeal",
      "indices" : [ 18, 29 ],
      "id_str" : "78569026",
      "id" : 78569026
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EricWolfson\/status\/643863622721081345\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/6K7lCH3wiY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO92i80WIAAVbL2.jpg",
      "id_str" : "643863614550581248",
      "id" : 643863614550581248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO92i80WIAAVbL2.jpg",
      "sizes" : [ {
        "h" : 676,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/6K7lCH3wiY"
    } ],
    "hashtags" : [ {
      "text" : "HowTwitterHelpsMeCope",
      "indices" : [ 51, 73 ]
    }, {
      "text" : "p2",
      "indices" : [ 74, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643903258583543808",
  "text" : "RT @EricWolfson: .@TheNewDeal put it best --&gt;\n\n #HowTwitterHelpsMeCope #p2 http:\/\/t.co\/6K7lCH3wiY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheNewDeal",
        "screen_name" : "TheNewDeal",
        "indices" : [ 1, 12 ],
        "id_str" : "78569026",
        "id" : 78569026
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EricWolfson\/status\/643863622721081345\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/6K7lCH3wiY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CO92i80WIAAVbL2.jpg",
        "id_str" : "643863614550581248",
        "id" : 643863614550581248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO92i80WIAAVbL2.jpg",
        "sizes" : [ {
          "h" : 676,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/6K7lCH3wiY"
      } ],
      "hashtags" : [ {
        "text" : "HowTwitterHelpsMeCope",
        "indices" : [ 34, 56 ]
      }, {
        "text" : "p2",
        "indices" : [ 57, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643863622721081345",
    "text" : ".@TheNewDeal put it best --&gt;\n\n #HowTwitterHelpsMeCope #p2 http:\/\/t.co\/6K7lCH3wiY",
    "id" : 643863622721081345,
    "created_at" : "2015-09-15 19:07:04 +0000",
    "user" : {
      "name" : "Eric Wolfson",
      "screen_name" : "EricWolfson",
      "protected" : false,
      "id_str" : "62510409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3373517986\/bf35a847483ea8b30679d52c445fb255_normal.jpeg",
      "id" : 62510409,
      "verified" : false
    }
  },
  "id" : 643903258583543808,
  "created_at" : "2015-09-15 21:44:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nacho Vhenan",
      "screen_name" : "AhnethAhra",
      "indices" : [ 3, 14 ],
      "id_str" : "3064447919",
      "id" : 3064447919
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AhnethAhra\/status\/643543823050768384\/video\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/WI346lCb2b",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/643543758479470592\/pu\/img\/z6K3UFfM_wvZwaiU.jpg",
      "id_str" : "643543758479470592",
      "id" : 643543758479470592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/643543758479470592\/pu\/img\/z6K3UFfM_wvZwaiU.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/WI346lCb2b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643549590038421505",
  "text" : "RT @AhnethAhra: Whooph http:\/\/t.co\/WI346lCb2b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AhnethAhra\/status\/643543823050768384\/video\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/WI346lCb2b",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/643543758479470592\/pu\/img\/z6K3UFfM_wvZwaiU.jpg",
        "id_str" : "643543758479470592",
        "id" : 643543758479470592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/643543758479470592\/pu\/img\/z6K3UFfM_wvZwaiU.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/WI346lCb2b"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643543823050768384",
    "text" : "Whooph http:\/\/t.co\/WI346lCb2b",
    "id" : 643543823050768384,
    "created_at" : "2015-09-14 21:56:18 +0000",
    "user" : {
      "name" : "Nacho Vhenan",
      "screen_name" : "AhnethAhra",
      "protected" : false,
      "id_str" : "3064447919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794209720575922176\/z9Leytp4_normal.jpg",
      "id" : 3064447919,
      "verified" : false
    }
  },
  "id" : 643549590038421505,
  "created_at" : "2015-09-14 22:19:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643425072275922944",
  "geo" : { },
  "id_str" : "643479280702373888",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe LOLOL.. that would be me, too..hehe!",
  "id" : 643479280702373888,
  "in_reply_to_status_id" : 643425072275922944,
  "created_at" : "2015-09-14 17:39:50 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/wjCKcC5PL0",
      "expanded_url" : "https:\/\/youtu.be\/OmM4Tra-rg0",
      "display_url" : "youtu.be\/OmM4Tra-rg0"
    } ]
  },
  "geo" : { },
  "id_str" : "643453222565343232",
  "text" : "hmm... \"It's a frame.\" - CeeCee Lyles \"September 11 - The New Pearl Harbor\" - Trailer https:\/\/t.co\/wjCKcC5PL0",
  "id" : 643453222565343232,
  "created_at" : "2015-09-14 15:56:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "indices" : [ 3, 19 ],
      "id_str" : "289118612",
      "id" : 289118612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GyKrohYTtE",
      "expanded_url" : "https:\/\/youtu.be\/hCUY8z15EsY",
      "display_url" : "youtu.be\/hCUY8z15EsY"
    } ]
  },
  "geo" : { },
  "id_str" : "643255411479584769",
  "text" : "RT @TomthunkitsMind: Mentally Ill Woman, Natasha McKenna Is Tased To Death In Jail By Deputies On Video. https:\/\/t.co\/GyKrohYTtE http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TomthunkitsMind\/status\/643246735565979652\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/VEsTHD4nfV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CO1FfxzUEAE3r4Y.png",
        "id_str" : "643246734030671873",
        "id" : 643246734030671873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO1FfxzUEAE3r4Y.png",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VEsTHD4nfV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/GyKrohYTtE",
        "expanded_url" : "https:\/\/youtu.be\/hCUY8z15EsY",
        "display_url" : "youtu.be\/hCUY8z15EsY"
      } ]
    },
    "geo" : { },
    "id_str" : "643246735565979652",
    "text" : "Mentally Ill Woman, Natasha McKenna Is Tased To Death In Jail By Deputies On Video. https:\/\/t.co\/GyKrohYTtE http:\/\/t.co\/VEsTHD4nfV",
    "id" : 643246735565979652,
    "created_at" : "2015-09-14 02:15:47 +0000",
    "user" : {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "protected" : false,
      "id_str" : "289118612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720292487898783746\/B736BdgO_normal.jpg",
      "id" : 289118612,
      "verified" : false
    }
  },
  "id" : 643255411479584769,
  "created_at" : "2015-09-14 02:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Sancho",
      "screen_name" : "eaglefeather43",
      "indices" : [ 3, 18 ],
      "id_str" : "59947923",
      "id" : 59947923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/JHUMp1hDrq",
      "expanded_url" : "https:\/\/twitter.com\/bernievideos\/status\/643160077696925696",
      "display_url" : "twitter.com\/bernievideos\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643215145716551680",
  "text" : "RT @eaglefeather43: Senator Bernie Sanders is the man of the hour!  We love Bernie Sanders. https:\/\/t.co\/JHUMp1hDrq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/JHUMp1hDrq",
        "expanded_url" : "https:\/\/twitter.com\/bernievideos\/status\/643160077696925696",
        "display_url" : "twitter.com\/bernievideos\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643161958317957120",
    "text" : "Senator Bernie Sanders is the man of the hour!  We love Bernie Sanders. https:\/\/t.co\/JHUMp1hDrq",
    "id" : 643161958317957120,
    "created_at" : "2015-09-13 20:38:54 +0000",
    "user" : {
      "name" : "Pablo Sancho",
      "screen_name" : "eaglefeather43",
      "protected" : false,
      "id_str" : "59947923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/376478908\/10255_normal.JPG",
      "id" : 59947923,
      "verified" : false
    }
  },
  "id" : 643215145716551680,
  "created_at" : "2015-09-14 00:10:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShawnElliott",
      "screen_name" : "ShawnElliott",
      "indices" : [ 3, 16 ],
      "id_str" : "15518530",
      "id" : 15518530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/QPExwKvo0H",
      "expanded_url" : "https:\/\/vine.co\/v\/eT5qTrBbXKJ",
      "display_url" : "vine.co\/v\/eT5qTrBbXKJ"
    } ]
  },
  "geo" : { },
  "id_str" : "643214596766048260",
  "text" : "RT @ShawnElliott: https:\/\/t.co\/QPExwKvo0H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/QPExwKvo0H",
        "expanded_url" : "https:\/\/vine.co\/v\/eT5qTrBbXKJ",
        "display_url" : "vine.co\/v\/eT5qTrBbXKJ"
      } ]
    },
    "geo" : { },
    "id_str" : "643176097010466816",
    "text" : "https:\/\/t.co\/QPExwKvo0H",
    "id" : 643176097010466816,
    "created_at" : "2015-09-13 21:35:05 +0000",
    "user" : {
      "name" : "ShawnElliott",
      "screen_name" : "ShawnElliott",
      "protected" : false,
      "id_str" : "15518530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261567074041\/822a33be5644fbedbb76e467882f63a1_normal.jpeg",
      "id" : 15518530,
      "verified" : false
    }
  },
  "id" : 643214596766048260,
  "created_at" : "2015-09-14 00:08:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    }, {
      "name" : "GWWMike",
      "screen_name" : "CWWMIKE",
      "indices" : [ 125, 133 ],
      "id_str" : "272366187",
      "id" : 272366187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643087245029863424",
  "text" : "RT @Swanwhisperer: Cooler night rolling as 9 mute swans flying in at the mute swan gathering point photo taken by my brother @CWWMIKE http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GWWMike",
        "screen_name" : "CWWMIKE",
        "indices" : [ 106, 114 ],
        "id_str" : "272366187",
        "id" : 272366187
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/642953658649477120\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/oAFWT1OOXK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COw67ThWcAAH6AT.jpg",
        "id_str" : "642953637333987328",
        "id" : 642953637333987328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COw67ThWcAAH6AT.jpg",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oAFWT1OOXK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642953658649477120",
    "text" : "Cooler night rolling as 9 mute swans flying in at the mute swan gathering point photo taken by my brother @CWWMIKE http:\/\/t.co\/oAFWT1OOXK",
    "id" : 642953658649477120,
    "created_at" : "2015-09-13 06:51:12 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 643087245029863424,
  "created_at" : "2015-09-13 15:42:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marylin Delgado",
      "screen_name" : "philosophypills",
      "indices" : [ 3, 19 ],
      "id_str" : "583903782",
      "id" : 583903782
    }, {
      "name" : "Martin Montoya",
      "screen_name" : "MartinMontoya__",
      "indices" : [ 66, 82 ],
      "id_str" : "364880716",
      "id" : 364880716
    }, {
      "name" : "Francisco O'Reilly",
      "screen_name" : "ibnreilly",
      "indices" : [ 88, 98 ],
      "id_str" : "148722326",
      "id" : 148722326
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ibnreilly\/status\/642466328620716032\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/y4uEtLIebW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COp_uHeWoAAeGUp.jpg",
      "id_str" : "642466327110787072",
      "id" : 642466327110787072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COp_uHeWoAAeGUp.jpg",
      "sizes" : [ {
        "h" : 929,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 929,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y4uEtLIebW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643076774432256001",
  "text" : "RT @philosophypills: Philosophy Dept.\nhttp:\/\/t.co\/y4uEtLIebW \nvia @MartinMontoya__  via @ibnreilly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Montoya",
        "screen_name" : "MartinMontoya__",
        "indices" : [ 45, 61 ],
        "id_str" : "364880716",
        "id" : 364880716
      }, {
        "name" : "Francisco O'Reilly",
        "screen_name" : "ibnreilly",
        "indices" : [ 67, 77 ],
        "id_str" : "148722326",
        "id" : 148722326
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ibnreilly\/status\/642466328620716032\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/y4uEtLIebW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COp_uHeWoAAeGUp.jpg",
        "id_str" : "642466327110787072",
        "id" : 642466327110787072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COp_uHeWoAAeGUp.jpg",
        "sizes" : [ {
          "h" : 929,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 929,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 581,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/y4uEtLIebW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642851006334812160",
    "text" : "Philosophy Dept.\nhttp:\/\/t.co\/y4uEtLIebW \nvia @MartinMontoya__  via @ibnreilly",
    "id" : 642851006334812160,
    "created_at" : "2015-09-13 00:03:18 +0000",
    "user" : {
      "name" : "Marylin Delgado",
      "screen_name" : "philosophypills",
      "protected" : false,
      "id_str" : "583903782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768842222674534400\/aWk5BwuV_normal.jpg",
      "id" : 583903782,
      "verified" : false
    }
  },
  "id" : 643076774432256001,
  "created_at" : "2015-09-13 15:00:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/642864745368932352\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/8BwaukPBsq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COvqEygXAAApkyG.jpg",
      "id_str" : "642864739828301824",
      "id" : 642864739828301824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COvqEygXAAApkyG.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 3072,
        "resize" : "fit",
        "w" : 1728
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8BwaukPBsq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642864745368932352",
  "text" : "Supervising the making of the bed. http:\/\/t.co\/8BwaukPBsq",
  "id" : 642864745368932352,
  "created_at" : "2015-09-13 00:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Taiji",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "animalcruelty",
      "indices" : [ 108, 122 ]
    }, {
      "text" : "barbaric",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/uUFzL1H0CQ",
      "expanded_url" : "http:\/\/thedo.do\/1ijZlqW",
      "display_url" : "thedo.do\/1ijZlqW"
    } ]
  },
  "geo" : { },
  "id_str" : "642834849414414336",
  "text" : "RT @SangyeH: Terrified Dolphin Throws Himself At Man's Feet To Escape Hunters http:\/\/t.co\/uUFzL1H0CQ\n#Taiji #animalcruelty #barbaric",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Taiji",
        "indices" : [ 88, 94 ]
      }, {
        "text" : "animalcruelty",
        "indices" : [ 95, 109 ]
      }, {
        "text" : "barbaric",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/uUFzL1H0CQ",
        "expanded_url" : "http:\/\/thedo.do\/1ijZlqW",
        "display_url" : "thedo.do\/1ijZlqW"
      } ]
    },
    "geo" : { },
    "id_str" : "642804640267026433",
    "text" : "Terrified Dolphin Throws Himself At Man's Feet To Escape Hunters http:\/\/t.co\/uUFzL1H0CQ\n#Taiji #animalcruelty #barbaric",
    "id" : 642804640267026433,
    "created_at" : "2015-09-12 20:59:03 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 642834849414414336,
  "created_at" : "2015-09-12 22:59:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642803113229975552",
  "text" : "DD picked up illustrated Alice in Wonderland and Growing up in Heaven by James Van Praagh. She wants to discuss GUIH w us..lol",
  "id" : 642803113229975552,
  "created_at" : "2015-09-12 20:52:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theosophy",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642802552715804672",
  "text" : "picked up 2 used books.. both #theosophy.. one by rudolf steiner, other by william q. judge.",
  "id" : 642802552715804672,
  "created_at" : "2015-09-12 20:50:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642790378215596032",
  "geo" : { },
  "id_str" : "642792687771516929",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time she did this in her previous home when stressed (which was often).",
  "id" : 642792687771516929,
  "in_reply_to_status_id" : 642790378215596032,
  "created_at" : "2015-09-12 20:11:33 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smelly",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "stillloveher",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642782113088020480",
  "text" : "good cat gone bad.. came home to messy bed. have to wash that bedding along w vacation clothes. #smelly #stillloveher",
  "id" : 642782113088020480,
  "created_at" : "2015-09-12 19:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugene Wyatt",
      "screen_name" : "CatskillMerino",
      "indices" : [ 3, 18 ],
      "id_str" : "132014370",
      "id" : 132014370
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillMerino\/status\/642691531460116481\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yN48DhpbLh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COtMiZOUcAA-S_6.jpg",
      "id_str" : "642691525600636928",
      "id" : 642691525600636928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COtMiZOUcAA-S_6.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/yN48DhpbLh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642707417587937280",
  "text" : "RT @CatskillMerino: We will be a vendor at the Duchess Co. Sheep &amp; Wool Festival in Rhinbeck oct 18th &amp; 19th. http:\/\/t.co\/yN48DhpbLh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillMerino\/status\/642691531460116481\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/yN48DhpbLh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COtMiZOUcAA-S_6.jpg",
        "id_str" : "642691525600636928",
        "id" : 642691525600636928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COtMiZOUcAA-S_6.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/yN48DhpbLh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642691531460116481",
    "text" : "We will be a vendor at the Duchess Co. Sheep &amp; Wool Festival in Rhinbeck oct 18th &amp; 19th. http:\/\/t.co\/yN48DhpbLh",
    "id" : 642691531460116481,
    "created_at" : "2015-09-12 13:29:36 +0000",
    "user" : {
      "name" : "Eugene Wyatt",
      "screen_name" : "CatskillMerino",
      "protected" : false,
      "id_str" : "132014370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709705594819768320\/5CVNYOMJ_normal.jpg",
      "id" : 132014370,
      "verified" : false
    }
  },
  "id" : 642707417587937280,
  "created_at" : "2015-09-12 14:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "indices" : [ 3, 19 ],
      "id_str" : "179121328",
      "id" : 179121328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642706507029684224",
  "text" : "RT @thesilverspiral: I'd rather spend the time I have on earth being madly in love with the world, joyfully happy, and finding adventure in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642706306076422148",
    "text" : "I'd rather spend the time I have on earth being madly in love with the world, joyfully happy, and finding adventure in a walk around town.",
    "id" : 642706306076422148,
    "created_at" : "2015-09-12 14:28:18 +0000",
    "user" : {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "protected" : false,
      "id_str" : "179121328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476331163322052609\/9eQZmrqN_normal.jpeg",
      "id" : 179121328,
      "verified" : false
    }
  },
  "id" : 642706507029684224,
  "created_at" : "2015-09-12 14:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cove Guardians",
      "screen_name" : "CoveGuardians",
      "indices" : [ 3, 17 ],
      "id_str" : "556297194",
      "id" : 556297194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642407481138913280",
  "text" : "RT @CoveGuardians: The pod is in the cove now as the nets are being dropped. The first slaughter of the season is about to start. 10:24am #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tweet4taiji",
        "indices" : [ 119, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642147174466260992",
    "text" : "The pod is in the cove now as the nets are being dropped. The first slaughter of the season is about to start. 10:24am #tweet4taiji",
    "id" : 642147174466260992,
    "created_at" : "2015-09-11 01:26:31 +0000",
    "user" : {
      "name" : "Cove Guardians",
      "screen_name" : "CoveGuardians",
      "protected" : false,
      "id_str" : "556297194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2187715195\/image_normal.jpg",
      "id" : 556297194,
      "verified" : false
    }
  },
  "id" : 642407481138913280,
  "created_at" : "2015-09-11 18:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    }, {
      "name" : "Herdwick Shepherd",
      "screen_name" : "herdyshepherd1",
      "indices" : [ 16, 31 ],
      "id_str" : "467507215",
      "id" : 467507215
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/I9YjPwJSSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmlkzWIAAEVCE.jpg",
      "id_str" : "642086848853057536",
      "id" : 642086848853057536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmlkzWIAAEVCE.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I9YjPwJSSe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/I9YjPwJSSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmllNXAAAzcEP.jpg",
      "id_str" : "642086848962166784",
      "id" : 642086848962166784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmllNXAAAzcEP.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I9YjPwJSSe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/I9YjPwJSSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmllmWgAAT5A4.jpg",
      "id_str" : "642086849066991616",
      "id" : 642086849066991616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmllmWgAAT5A4.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I9YjPwJSSe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/I9YjPwJSSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmlmPWUAAMiEo.jpg",
      "id_str" : "642086849238945792",
      "id" : 642086849238945792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmlmPWUAAMiEo.jpg",
      "sizes" : [ {
        "h" : 787,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I9YjPwJSSe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642137973824294913",
  "text" : "RT @dailyMorag: @herdyshepherd1 Mooooo &amp; Hello from Morag - a Highland x Riggit Galloway http:\/\/t.co\/I9YjPwJSSe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Herdwick Shepherd",
        "screen_name" : "herdyshepherd1",
        "indices" : [ 0, 15 ],
        "id_str" : "467507215",
        "id" : 467507215
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/I9YjPwJSSe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmlkzWIAAEVCE.jpg",
        "id_str" : "642086848853057536",
        "id" : 642086848853057536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmlkzWIAAEVCE.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I9YjPwJSSe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/I9YjPwJSSe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmllNXAAAzcEP.jpg",
        "id_str" : "642086848962166784",
        "id" : 642086848962166784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmllNXAAAzcEP.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/I9YjPwJSSe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/I9YjPwJSSe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmllmWgAAT5A4.jpg",
        "id_str" : "642086849066991616",
        "id" : 642086849066991616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmllmWgAAT5A4.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/I9YjPwJSSe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/642086934836326400\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/I9YjPwJSSe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COkmlmPWUAAMiEo.jpg",
        "id_str" : "642086849238945792",
        "id" : 642086849238945792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COkmlmPWUAAMiEo.jpg",
        "sizes" : [ {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I9YjPwJSSe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "642078465676693504",
    "geo" : { },
    "id_str" : "642086934836326400",
    "in_reply_to_user_id" : 467507215,
    "text" : "@herdyshepherd1 Mooooo &amp; Hello from Morag - a Highland x Riggit Galloway http:\/\/t.co\/I9YjPwJSSe",
    "id" : 642086934836326400,
    "in_reply_to_status_id" : 642078465676693504,
    "created_at" : "2015-09-10 21:27:09 +0000",
    "in_reply_to_screen_name" : "herdyshepherd1",
    "in_reply_to_user_id_str" : "467507215",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 642137973824294913,
  "created_at" : "2015-09-11 00:49:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFLScience",
      "screen_name" : "IFLScience",
      "indices" : [ 3, 14 ],
      "id_str" : "838464523",
      "id" : 838464523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641786051875500032",
  "text" : "RT @IFLScience: Discovered frozen in the permafrost of Siberia, scientists will attempt to reanimate a long extinct \u201Cgiant\u201D virus. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/pP1ndk67br",
        "expanded_url" : "http:\/\/bit.ly\/1JW8pv0",
        "display_url" : "bit.ly\/1JW8pv0"
      } ]
    },
    "geo" : { },
    "id_str" : "641704598948978688",
    "text" : "Discovered frozen in the permafrost of Siberia, scientists will attempt to reanimate a long extinct \u201Cgiant\u201D virus. http:\/\/t.co\/pP1ndk67br",
    "id" : 641704598948978688,
    "created_at" : "2015-09-09 20:07:53 +0000",
    "user" : {
      "name" : "IFLScience",
      "screen_name" : "IFLScience",
      "protected" : false,
      "id_str" : "838464523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3754753652\/332b63f654122526ce21dc98715b8eca_normal.jpeg",
      "id" : 838464523,
      "verified" : false
    }
  },
  "id" : 641786051875500032,
  "created_at" : "2015-09-10 01:31:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Check123",
      "screen_name" : "check123com",
      "indices" : [ 3, 15 ],
      "id_str" : "2733961215",
      "id" : 2733961215
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/check123com\/status\/641718017827708928\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Jh2GuPDacz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COfXIxyWoAIf5pX.jpg",
      "id_str" : "641718017727045634",
      "id" : 641718017727045634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COfXIxyWoAIf5pX.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/Jh2GuPDacz"
    } ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "birds",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ZKo9Ya57dY",
      "expanded_url" : "http:\/\/buff.ly\/1g9k7rp",
      "display_url" : "buff.ly\/1g9k7rp"
    } ]
  },
  "geo" : { },
  "id_str" : "641784619306762240",
  "text" : "RT @check123com: This bird steels from humans to impress the lady birds!\nhttp:\/\/t.co\/ZKo9Ya57dY\n#nature #birds http:\/\/t.co\/Jh2GuPDacz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/check123com\/status\/641718017827708928\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/Jh2GuPDacz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COfXIxyWoAIf5pX.jpg",
        "id_str" : "641718017727045634",
        "id" : 641718017727045634,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COfXIxyWoAIf5pX.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/Jh2GuPDacz"
      } ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 79, 86 ]
      }, {
        "text" : "birds",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/ZKo9Ya57dY",
        "expanded_url" : "http:\/\/buff.ly\/1g9k7rp",
        "display_url" : "buff.ly\/1g9k7rp"
      } ]
    },
    "geo" : { },
    "id_str" : "641718017827708928",
    "text" : "This bird steels from humans to impress the lady birds!\nhttp:\/\/t.co\/ZKo9Ya57dY\n#nature #birds http:\/\/t.co\/Jh2GuPDacz",
    "id" : 641718017827708928,
    "created_at" : "2015-09-09 21:01:12 +0000",
    "user" : {
      "name" : "Check123",
      "screen_name" : "check123com",
      "protected" : false,
      "id_str" : "2733961215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581780433051918336\/EFr9s-S4_normal.jpg",
      "id" : 2733961215,
      "verified" : false
    }
  },
  "id" : 641784619306762240,
  "created_at" : "2015-09-10 01:25:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6oWQdGrTQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj6DWUAAmKrZ.jpg",
      "id_str" : "641661309197635584",
      "id" : 641661309197635584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj6DWUAAmKrZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6oWQdGrTQv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6oWQdGrTQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj6fWoAM6rmS.jpg",
      "id_str" : "641661309315096579",
      "id" : 641661309315096579,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj6fWoAM6rmS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6oWQdGrTQv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6oWQdGrTQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj67WsAATjz8.jpg",
      "id_str" : "641661309432541184",
      "id" : 641661309432541184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj67WsAATjz8.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6oWQdGrTQv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6oWQdGrTQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj7WWoAAb-QZ.jpg",
      "id_str" : "641661309545783296",
      "id" : 641661309545783296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj7WWoAAb-QZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6oWQdGrTQv"
    } ],
    "hashtags" : [ {
      "text" : "teamStripe",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "calfpix",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "calving15",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641690074107744256",
  "text" : "RT @newlandfarm: Here he is, last nights Belted Galloway bullcalf, might make a bull #teamStripe #calfpix #calving15 http:\/\/t.co\/6oWQdGrTQv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/6oWQdGrTQv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj6DWUAAmKrZ.jpg",
        "id_str" : "641661309197635584",
        "id" : 641661309197635584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj6DWUAAmKrZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6oWQdGrTQv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/6oWQdGrTQv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj6fWoAM6rmS.jpg",
        "id_str" : "641661309315096579",
        "id" : 641661309315096579,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj6fWoAM6rmS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6oWQdGrTQv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/6oWQdGrTQv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj67WsAATjz8.jpg",
        "id_str" : "641661309432541184",
        "id" : 641661309432541184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj67WsAATjz8.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6oWQdGrTQv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/641661435454582784\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/6oWQdGrTQv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COejj7WWoAAb-QZ.jpg",
        "id_str" : "641661309545783296",
        "id" : 641661309545783296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COejj7WWoAAb-QZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6oWQdGrTQv"
      } ],
      "hashtags" : [ {
        "text" : "teamStripe",
        "indices" : [ 68, 79 ]
      }, {
        "text" : "calfpix",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "calving15",
        "indices" : [ 89, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641661435454582784",
    "text" : "Here he is, last nights Belted Galloway bullcalf, might make a bull #teamStripe #calfpix #calving15 http:\/\/t.co\/6oWQdGrTQv",
    "id" : 641661435454582784,
    "created_at" : "2015-09-09 17:16:22 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 641690074107744256,
  "created_at" : "2015-09-09 19:10:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    }, {
      "name" : "Jimmys Farm",
      "screen_name" : "JimmysFarmHQ",
      "indices" : [ 16, 29 ],
      "id_str" : "522193125",
      "id" : 522193125
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DR9VHbTTAy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COeee_ZWUAAT1xU.jpg",
      "id_str" : "641655727174602752",
      "id" : 641655727174602752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeee_ZWUAAT1xU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DR9VHbTTAy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DR9VHbTTAy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COeee_1W8AAfUwY.jpg",
      "id_str" : "641655727292084224",
      "id" : 641655727292084224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeee_1W8AAfUwY.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DR9VHbTTAy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DR9VHbTTAy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COeefAQWwAATr8n.jpg",
      "id_str" : "641655727405318144",
      "id" : 641655727405318144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeefAQWwAATr8n.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DR9VHbTTAy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DR9VHbTTAy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COeefA3WIAAQoBR.jpg",
      "id_str" : "641655727568855040",
      "id" : 641655727568855040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeefA3WIAAQoBR.jpg",
      "sizes" : [ {
        "h" : 787,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DR9VHbTTAy"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641690005879005184",
  "text" : "RT @dailyMorag: @JimmysFarmHQ I see yours, here's mine #dailyMorag as a baby and yesterday http:\/\/t.co\/DR9VHbTTAy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jimmys Farm",
        "screen_name" : "JimmysFarmHQ",
        "indices" : [ 0, 13 ],
        "id_str" : "522193125",
        "id" : 522193125
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/DR9VHbTTAy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COeee_ZWUAAT1xU.jpg",
        "id_str" : "641655727174602752",
        "id" : 641655727174602752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeee_ZWUAAT1xU.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DR9VHbTTAy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/DR9VHbTTAy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COeee_1W8AAfUwY.jpg",
        "id_str" : "641655727292084224",
        "id" : 641655727292084224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeee_1W8AAfUwY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DR9VHbTTAy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/DR9VHbTTAy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COeefAQWwAATr8n.jpg",
        "id_str" : "641655727405318144",
        "id" : 641655727405318144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeefAQWwAATr8n.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DR9VHbTTAy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641655821047332864\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/DR9VHbTTAy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COeefA3WIAAQoBR.jpg",
        "id_str" : "641655727568855040",
        "id" : 641655727568855040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeefA3WIAAQoBR.jpg",
        "sizes" : [ {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DR9VHbTTAy"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 39, 50 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "641537916670492672",
    "geo" : { },
    "id_str" : "641655821047332864",
    "in_reply_to_user_id" : 522193125,
    "text" : "@JimmysFarmHQ I see yours, here's mine #dailyMorag as a baby and yesterday http:\/\/t.co\/DR9VHbTTAy",
    "id" : 641655821047332864,
    "in_reply_to_status_id" : 641537916670492672,
    "created_at" : "2015-09-09 16:54:03 +0000",
    "in_reply_to_screen_name" : "JimmysFarmHQ",
    "in_reply_to_user_id_str" : "522193125",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 641690005879005184,
  "created_at" : "2015-09-09 19:09:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/PqjwujU45t",
      "expanded_url" : "http:\/\/mashable.com\/2015\/09\/09\/bird-borrows-fur-for-nest\/?utm_source=feedly&utm_medium=webfeeds",
      "display_url" : "mashable.com\/2015\/09\/09\/bir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641653829444964352",
  "text" : "RT @screek: Dog is totally cool with bird borrowing his fur to build a nest http:\/\/t.co\/PqjwujU45t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/PqjwujU45t",
        "expanded_url" : "http:\/\/mashable.com\/2015\/09\/09\/bird-borrows-fur-for-nest\/?utm_source=feedly&utm_medium=webfeeds",
        "display_url" : "mashable.com\/2015\/09\/09\/bir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641652413456257025",
    "text" : "Dog is totally cool with bird borrowing his fur to build a nest http:\/\/t.co\/PqjwujU45t",
    "id" : 641652413456257025,
    "created_at" : "2015-09-09 16:40:31 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 641653829444964352,
  "created_at" : "2015-09-09 16:46:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641652742507900932",
  "text" : "RT @BrianRathbone: A good book will expand your mind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641652628657696768",
    "text" : "A good book will expand your mind.",
    "id" : 641652628657696768,
    "created_at" : "2015-09-09 16:41:22 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 641652742507900932,
  "created_at" : "2015-09-09 16:41:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "indices" : [ 3, 16 ],
      "id_str" : "1413936181",
      "id" : 1413936181
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FionaJDavies\/status\/641646457607598081\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5GzMA0xYCS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COeWCOvWoAEPdoE.jpg",
      "id_str" : "641646436984201217",
      "id" : 641646436984201217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeWCOvWoAEPdoE.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5GzMA0xYCS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641652656440803328",
  "text" : "RT @FionaJDavies: Early or late! Must only be a few hours old \uD83D\uDE2F\uD83D\uDC0F http:\/\/t.co\/5GzMA0xYCS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FionaJDavies\/status\/641646457607598081\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/5GzMA0xYCS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COeWCOvWoAEPdoE.jpg",
        "id_str" : "641646436984201217",
        "id" : 641646436984201217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeWCOvWoAEPdoE.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5GzMA0xYCS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641646457607598081",
    "text" : "Early or late! Must only be a few hours old \uD83D\uDE2F\uD83D\uDC0F http:\/\/t.co\/5GzMA0xYCS",
    "id" : 641646457607598081,
    "created_at" : "2015-09-09 16:16:51 +0000",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "protected" : false,
      "id_str" : "1413936181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456679350880829440\/z2YfOoH2_normal.jpeg",
      "id" : 1413936181,
      "verified" : false
    }
  },
  "id" : 641652656440803328,
  "created_at" : "2015-09-09 16:41:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmys Farm",
      "screen_name" : "JimmysFarmHQ",
      "indices" : [ 3, 16 ],
      "id_str" : "522193125",
      "id" : 522193125
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JimmysFarmHQ\/status\/641537916670492672\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/2gFHwh3kCX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COczVfvUcAEa4FY.jpg",
      "id_str" : "641537916313825281",
      "id" : 641537916313825281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COczVfvUcAEa4FY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/2gFHwh3kCX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641649798882422784",
  "text" : "RT @JimmysFarmHQ: Isn't she just the cutest? http:\/\/t.co\/2gFHwh3kCX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JimmysFarmHQ\/status\/641537916670492672\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/2gFHwh3kCX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COczVfvUcAEa4FY.jpg",
        "id_str" : "641537916313825281",
        "id" : 641537916313825281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COczVfvUcAEa4FY.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/2gFHwh3kCX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641537916670492672",
    "text" : "Isn't she just the cutest? http:\/\/t.co\/2gFHwh3kCX",
    "id" : 641537916670492672,
    "created_at" : "2015-09-09 09:05:33 +0000",
    "user" : {
      "name" : "Jimmys Farm",
      "screen_name" : "JimmysFarmHQ",
      "protected" : false,
      "id_str" : "522193125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519107582569357313\/LdQLhpIB_normal.jpeg",
      "id" : 522193125,
      "verified" : false
    }
  },
  "id" : 641649798882422784,
  "created_at" : "2015-09-09 16:30:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "indices" : [ 3, 19 ],
      "id_str" : "30364057",
      "id" : 30364057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641612851497574400",
  "text" : "RT @SarahKSilverman: Can we all agree that we're on a planet in outer space?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641439409200435200",
    "text" : "Can we all agree that we're on a planet in outer space?",
    "id" : 641439409200435200,
    "created_at" : "2015-09-09 02:34:07 +0000",
    "user" : {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "protected" : false,
      "id_str" : "30364057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533405266658615296\/ULwCXwFs_normal.jpeg",
      "id" : 30364057,
      "verified" : true
    }
  },
  "id" : 641612851497574400,
  "created_at" : "2015-09-09 14:03:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641544666748440576",
  "geo" : { },
  "id_str" : "641612729099399169",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre (((hugs)))",
  "id" : 641612729099399169,
  "in_reply_to_status_id" : 641544666748440576,
  "created_at" : "2015-09-09 14:02:49 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/VGbvj9k8Xl",
      "expanded_url" : "https:\/\/twitter.com\/nbcnews\/status\/641575624369405952",
      "display_url" : "twitter.com\/nbcnews\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641610444168372224",
  "text" : "RT @deray: Y'all.  https:\/\/t.co\/VGbvj9k8Xl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/VGbvj9k8Xl",
        "expanded_url" : "https:\/\/twitter.com\/nbcnews\/status\/641575624369405952",
        "display_url" : "twitter.com\/nbcnews\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641582014605475841",
    "text" : "Y'all.  https:\/\/t.co\/VGbvj9k8Xl",
    "id" : 641582014605475841,
    "created_at" : "2015-09-09 12:00:46 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 641610444168372224,
  "created_at" : "2015-09-09 13:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641610338991894528",
  "text" : "RT @aliceinthewater: You are not alone. You can make it through this. People care about you and want to see you survive. You are loved and \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641573224795377664",
    "text" : "You are not alone. You can make it through this. People care about you and want to see you survive. You are loved and don't know it.",
    "id" : 641573224795377664,
    "created_at" : "2015-09-09 11:25:51 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 641610338991894528,
  "created_at" : "2015-09-09 13:53:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/RM0D7OwbnT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57a9WgAIr4Ze.jpg",
      "id_str" : "641334058702766082",
      "id" : 641334058702766082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57a9WgAIr4Ze.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RM0D7OwbnT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/RM0D7OwbnT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57baW8AARhT0.jpg",
      "id_str" : "641334058824429568",
      "id" : 641334058824429568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57baW8AARhT0.jpg",
      "sizes" : [ {
        "h" : 668,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RM0D7OwbnT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/RM0D7OwbnT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57elWIAAv8l3.jpg",
      "id_str" : "641334059675820032",
      "id" : 641334059675820032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57elWIAAv8l3.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RM0D7OwbnT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/RM0D7OwbnT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57-fWsAASEEF.jpg",
      "id_str" : "641334068240625664",
      "id" : 641334068240625664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57-fWsAASEEF.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RM0D7OwbnT"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641423558741258240",
  "text" : "RT @dailyMorag: What a pair #dailyMorag http:\/\/t.co\/RM0D7OwbnT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/RM0D7OwbnT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57a9WgAIr4Ze.jpg",
        "id_str" : "641334058702766082",
        "id" : 641334058702766082,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57a9WgAIr4Ze.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RM0D7OwbnT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/RM0D7OwbnT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57baW8AARhT0.jpg",
        "id_str" : "641334058824429568",
        "id" : 641334058824429568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57baW8AARhT0.jpg",
        "sizes" : [ {
          "h" : 668,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RM0D7OwbnT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/RM0D7OwbnT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57elWIAAv8l3.jpg",
        "id_str" : "641334059675820032",
        "id" : 641334059675820032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57elWIAAv8l3.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RM0D7OwbnT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641334291239170049\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/RM0D7OwbnT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ57-fWsAASEEF.jpg",
        "id_str" : "641334068240625664",
        "id" : 641334068240625664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ57-fWsAASEEF.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RM0D7OwbnT"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 12, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641334291239170049",
    "text" : "What a pair #dailyMorag http:\/\/t.co\/RM0D7OwbnT",
    "id" : 641334291239170049,
    "created_at" : "2015-09-08 19:36:25 +0000",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 641423558741258240,
  "created_at" : "2015-09-09 01:31:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Wood",
      "screen_name" : "SarahWoodwriter",
      "indices" : [ 3, 19 ],
      "id_str" : "191546705",
      "id" : 191546705
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SarahWoodwriter\/status\/641340431955988481\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/lR3vExuXch",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ_uKfVAAAqhza.jpg",
      "id_str" : "641340428013338624",
      "id" : 641340428013338624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ_uKfVAAAqhza.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lR3vExuXch"
    } ],
    "hashtags" : [ {
      "text" : "KimDavis",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641423450792435712",
  "text" : "RT @SarahWoodwriter: #KimDavis http:\/\/t.co\/lR3vExuXch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SarahWoodwriter\/status\/641340431955988481\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/lR3vExuXch",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COZ_uKfVAAAqhza.jpg",
        "id_str" : "641340428013338624",
        "id" : 641340428013338624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COZ_uKfVAAAqhza.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lR3vExuXch"
      } ],
      "hashtags" : [ {
        "text" : "KimDavis",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641340431955988481",
    "text" : "#KimDavis http:\/\/t.co\/lR3vExuXch",
    "id" : 641340431955988481,
    "created_at" : "2015-09-08 20:00:49 +0000",
    "user" : {
      "name" : "Sarah Wood",
      "screen_name" : "SarahWoodwriter",
      "protected" : false,
      "id_str" : "191546705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796241917965004802\/csS1i5RM_normal.jpg",
      "id" : 191546705,
      "verified" : false
    }
  },
  "id" : 641423450792435712,
  "created_at" : "2015-09-09 01:30:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 16, 28 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "indices" : [ 110, 124 ],
      "id_str" : "751200954",
      "id" : 751200954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641423072596258817",
  "text" : "RT @dailyMorag: @ErinEFarley think I caught the best of their relationship today, these two are my favourites @fionagraham13 http:\/\/t.co\/c0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 0, 12 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      }, {
        "name" : "Fiona Graham",
        "screen_name" : "fionagraham13",
        "indices" : [ 94, 108 ],
        "id_str" : "751200954",
        "id" : 751200954
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641370057243803649\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/c0L0iPk5lW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COaaoZRWcAAvCRn.jpg",
        "id_str" : "641370015715979264",
        "id" : 641370015715979264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COaaoZRWcAAvCRn.jpg",
        "sizes" : [ {
          "h" : 668,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/c0L0iPk5lW"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/641370057243803649\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/c0L0iPk5lW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COaaoZqWEAAHuZu.jpg",
        "id_str" : "641370015820812288",
        "id" : 641370015820812288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COaaoZqWEAAHuZu.jpg",
        "sizes" : [ {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/c0L0iPk5lW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "641362081543942144",
    "geo" : { },
    "id_str" : "641370057243803649",
    "in_reply_to_user_id" : 1305052615,
    "text" : "@ErinEFarley think I caught the best of their relationship today, these two are my favourites @fionagraham13 http:\/\/t.co\/c0L0iPk5lW",
    "id" : 641370057243803649,
    "in_reply_to_status_id" : 641362081543942144,
    "created_at" : "2015-09-08 21:58:32 +0000",
    "in_reply_to_screen_name" : "ErinEFarley",
    "in_reply_to_user_id_str" : "1305052615",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 641423072596258817,
  "created_at" : "2015-09-09 01:29:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Chan",
      "screen_name" : "RonDanChan",
      "indices" : [ 3, 14 ],
      "id_str" : "23258851",
      "id" : 23258851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641422992199839745",
  "text" : "RT @RonDanChan: Manga Studio users! DO NOT update your Wacom driver to 6.3.14. It will fuck your world up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641120334414942209",
    "text" : "Manga Studio users! DO NOT update your Wacom driver to 6.3.14. It will fuck your world up.",
    "id" : 641120334414942209,
    "created_at" : "2015-09-08 05:26:13 +0000",
    "user" : {
      "name" : "Ron Chan",
      "screen_name" : "RonDanChan",
      "protected" : false,
      "id_str" : "23258851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793490841096433664\/RX7zh-4-_normal.jpg",
      "id" : 23258851,
      "verified" : false
    }
  },
  "id" : 641422992199839745,
  "created_at" : "2015-09-09 01:28:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641383272153546753",
  "geo" : { },
  "id_str" : "641422876839686144",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe aww, bless him. &lt;3",
  "id" : 641422876839686144,
  "in_reply_to_status_id" : 641383272153546753,
  "created_at" : "2015-09-09 01:28:25 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Stevenson",
      "screen_name" : "tourscotland",
      "indices" : [ 3, 16 ],
      "id_str" : "15842676",
      "id" : 15842676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641422311736918016",
  "text" : "RT @tourscotland: Good night with most requested Tour Scotland pic of Highland Cows by Duart Castle on ancestry visit to Isle of Mull http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tourscotland\/status\/641390824794755072\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/tfJnC4gQ1a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COatjk6WcAAUzLW.jpg",
        "id_str" : "641390823662317568",
        "id" : 641390823662317568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COatjk6WcAAUzLW.jpg",
        "sizes" : [ {
          "h" : 437,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 765
        } ],
        "display_url" : "pic.twitter.com\/tfJnC4gQ1a"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641390824794755072",
    "text" : "Good night with most requested Tour Scotland pic of Highland Cows by Duart Castle on ancestry visit to Isle of Mull http:\/\/t.co\/tfJnC4gQ1a",
    "id" : 641390824794755072,
    "created_at" : "2015-09-08 23:21:03 +0000",
    "user" : {
      "name" : "Sandy Stevenson",
      "screen_name" : "tourscotland",
      "protected" : false,
      "id_str" : "15842676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70101487\/Sandy_Stevenson_normal.jpg",
      "id" : 15842676,
      "verified" : false
    }
  },
  "id" : 641422311736918016,
  "created_at" : "2015-09-09 01:26:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641343749763629060",
  "geo" : { },
  "id_str" : "641421647208153088",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe I don't know if she ordered 3ds but I know she ordered game. She loves AC.",
  "id" : 641421647208153088,
  "in_reply_to_status_id" : 641343749763629060,
  "created_at" : "2015-09-09 01:23:32 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641313243156344832",
  "geo" : { },
  "id_str" : "641340243854032896",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe DD says nice! She preordered hers as well.",
  "id" : 641340243854032896,
  "in_reply_to_status_id" : 641313243156344832,
  "created_at" : "2015-09-08 20:00:04 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641261536384782336",
  "text" : "Mouse in the car yesterday. Crawled all over DH. Didn't want to leave.",
  "id" : 641261536384782336,
  "created_at" : "2015-09-08 14:47:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Barton",
      "screen_name" : "shutter_j",
      "indices" : [ 3, 13 ],
      "id_str" : "2928648858",
      "id" : 2928648858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640891315346141184",
  "text" : "RT @shutter_j: As a child and teen, not one single person took a book away from me and told me that it was inappropriate. I'm a better pers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640889329447862276",
    "text" : "As a child and teen, not one single person took a book away from me and told me that it was inappropriate. I'm a better person for it.",
    "id" : 640889329447862276,
    "created_at" : "2015-09-07 14:08:17 +0000",
    "user" : {
      "name" : "Naomi Barton",
      "screen_name" : "shutter_j",
      "protected" : false,
      "id_str" : "2928648858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727292020541149184\/xAuZJPoG_normal.jpg",
      "id" : 2928648858,
      "verified" : false
    }
  },
  "id" : 640891315346141184,
  "created_at" : "2015-09-07 14:16:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stanley behrman",
      "screen_name" : "stanleybehrman",
      "indices" : [ 3, 18 ],
      "id_str" : "248100395",
      "id" : 248100395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640889474847744001",
  "text" : "RT @stanleybehrman: I am more likely to answer a tweet than a call.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327893196359217152",
    "text" : "I am more likely to answer a tweet than a call.",
    "id" : 327893196359217152,
    "created_at" : "2013-04-26 21:13:24 +0000",
    "user" : {
      "name" : "stanley behrman",
      "screen_name" : "stanleybehrman",
      "protected" : false,
      "id_str" : "248100395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000812229522\/c1d70878071939af2785e680a60075c9_normal.jpeg",
      "id" : 248100395,
      "verified" : false
    }
  },
  "id" : 640889474847744001,
  "created_at" : "2015-09-07 14:08:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny Coates",
      "screen_name" : "DennyCoates",
      "indices" : [ 3, 15 ],
      "id_str" : "33998869",
      "id" : 33998869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640889411413123073",
  "text" : "RT @DennyCoates: \"There is no greater hell than to be a prisoner of fear.\" - Ben Jonson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640877769312894976",
    "text" : "\"There is no greater hell than to be a prisoner of fear.\" - Ben Jonson",
    "id" : 640877769312894976,
    "created_at" : "2015-09-07 13:22:21 +0000",
    "user" : {
      "name" : "Denny Coates",
      "screen_name" : "DennyCoates",
      "protected" : false,
      "id_str" : "33998869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616644668600651776\/oOmY-MhL_normal.jpg",
      "id" : 33998869,
      "verified" : false
    }
  },
  "id" : 640889411413123073,
  "created_at" : "2015-09-07 14:08:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640884878662242304",
  "geo" : { },
  "id_str" : "640887205678989312",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves you, too, Dwayne :)",
  "id" : 640887205678989312,
  "in_reply_to_status_id" : 640884878662242304,
  "created_at" : "2015-09-07 13:59:51 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640690118878171136",
  "text" : "RT @1CatShepherd: I took the human for a walk today showing her autumn flowers in field&amp;garden Purpleclover, Scabia &amp; Blackeyed Susan http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/640612679464407041\/photo\/1",
        "indices" : [ 124, 146 ],
        "url" : "http:\/\/t.co\/vQfeZoFJwF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPpwmIWsAAbJPp.jpg",
        "id_str" : "640612593095323648",
        "id" : 640612593095323648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPpwmIWsAAbJPp.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/vQfeZoFJwF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/640612679464407041\/photo\/1",
        "indices" : [ 124, 146 ],
        "url" : "http:\/\/t.co\/vQfeZoFJwF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPpwmbWIAAK02t.jpg",
        "id_str" : "640612593174978560",
        "id" : 640612593174978560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPpwmbWIAAK02t.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vQfeZoFJwF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/640612679464407041\/photo\/1",
        "indices" : [ 124, 146 ],
        "url" : "http:\/\/t.co\/vQfeZoFJwF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPpwm8WIAAMcc1.jpg",
        "id_str" : "640612593313390592",
        "id" : 640612593313390592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPpwm8WIAAMcc1.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vQfeZoFJwF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/640612679464407041\/photo\/1",
        "indices" : [ 124, 146 ],
        "url" : "http:\/\/t.co\/vQfeZoFJwF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPpwn_WsAAAMjU.jpg",
        "id_str" : "640612593594445824",
        "id" : 640612593594445824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPpwn_WsAAAMjU.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vQfeZoFJwF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640612679464407041",
    "text" : "I took the human for a walk today showing her autumn flowers in field&amp;garden Purpleclover, Scabia &amp; Blackeyed Susan http:\/\/t.co\/vQfeZoFJwF",
    "id" : 640612679464407041,
    "created_at" : "2015-09-06 19:48:59 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 640690118878171136,
  "created_at" : "2015-09-07 00:56:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinamrdh",
      "screen_name" : "tinamrdh",
      "indices" : [ 3, 12 ],
      "id_str" : "97604630",
      "id" : 97604630
    }, {
      "name" : "Jerry Brown",
      "screen_name" : "JerryBrownGov",
      "indices" : [ 116, 130 ],
      "id_str" : "19418459",
      "id" : 19418459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hearus",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "SB277Referendum",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640625959197143044",
  "text" : "RT @tinamrdh: Instead of mandating more vax how about we find out why our kids r so sick! #hearus #SB277Referendum .@JerryBrownGov http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jerry Brown",
        "screen_name" : "JerryBrownGov",
        "indices" : [ 102, 116 ],
        "id_str" : "19418459",
        "id" : 19418459
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tinamrdh\/status\/640619881193299968\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/4zY5h4tGM4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPwYeWUwAA34qK.jpg",
        "id_str" : "640619875270967296",
        "id" : 640619875270967296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPwYeWUwAA34qK.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        } ],
        "display_url" : "pic.twitter.com\/4zY5h4tGM4"
      } ],
      "hashtags" : [ {
        "text" : "hearus",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "SB277Referendum",
        "indices" : [ 84, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640619881193299968",
    "text" : "Instead of mandating more vax how about we find out why our kids r so sick! #hearus #SB277Referendum .@JerryBrownGov http:\/\/t.co\/4zY5h4tGM4",
    "id" : 640619881193299968,
    "created_at" : "2015-09-06 20:17:36 +0000",
    "user" : {
      "name" : "tinamrdh",
      "screen_name" : "tinamrdh",
      "protected" : false,
      "id_str" : "97604630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590387857463779328\/DtxA3sCC_normal.jpg",
      "id" : 97604630,
      "verified" : false
    }
  },
  "id" : 640625959197143044,
  "created_at" : "2015-09-06 20:41:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640549896140005377",
  "geo" : { },
  "id_str" : "640553056447373312",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides true...",
  "id" : 640553056447373312,
  "in_reply_to_status_id" : 640549896140005377,
  "created_at" : "2015-09-06 15:52:04 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/FZSm9uEMn0",
      "expanded_url" : "https:\/\/vine.co\/v\/euUIb9JUOpP",
      "display_url" : "vine.co\/v\/euUIb9JUOpP"
    } ]
  },
  "geo" : { },
  "id_str" : "640171402969153536",
  "text" : "RT @ZwartblesIE: Mintsause detours through the Wood Anemones to give me a head butt https:\/\/t.co\/FZSm9uEMn0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/FZSm9uEMn0",
        "expanded_url" : "https:\/\/vine.co\/v\/euUIb9JUOpP",
        "display_url" : "vine.co\/v\/euUIb9JUOpP"
      } ]
    },
    "geo" : { },
    "id_str" : "640130467619078144",
    "text" : "Mintsause detours through the Wood Anemones to give me a head butt https:\/\/t.co\/FZSm9uEMn0",
    "id" : 640130467619078144,
    "created_at" : "2015-09-05 11:52:51 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 640171402969153536,
  "created_at" : "2015-09-05 14:35:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NY Wolf Center",
      "screen_name" : "nywolforg",
      "indices" : [ 3, 13 ],
      "id_str" : "529540495",
      "id" : 529540495
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nywolforg\/status\/639969835225628672\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/XvZhtnIUKC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COGhLHFUYAA29bX.jpg",
      "id_str" : "639969834315309056",
      "id" : 639969834315309056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COGhLHFUYAA29bX.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XvZhtnIUKC"
    } ],
    "hashtags" : [ {
      "text" : "TGIF",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639975764851605504",
  "text" : "RT @nywolforg: #TGIF http:\/\/t.co\/XvZhtnIUKC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nywolforg\/status\/639969835225628672\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/XvZhtnIUKC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COGhLHFUYAA29bX.jpg",
        "id_str" : "639969834315309056",
        "id" : 639969834315309056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COGhLHFUYAA29bX.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XvZhtnIUKC"
      } ],
      "hashtags" : [ {
        "text" : "TGIF",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639969835225628672",
    "text" : "#TGIF http:\/\/t.co\/XvZhtnIUKC",
    "id" : 639969835225628672,
    "created_at" : "2015-09-05 01:14:33 +0000",
    "user" : {
      "name" : "NY Wolf Center",
      "screen_name" : "nywolforg",
      "protected" : false,
      "id_str" : "529540495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1915465365\/Atka_photo_crop_normal.jpg",
      "id" : 529540495,
      "verified" : true
    }
  },
  "id" : 639975764851605504,
  "created_at" : "2015-09-05 01:38:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639972071183937540",
  "text" : "RT @fairlyspiritual: Some of the meanest, most unkind emails I\u2019ve ever received come from Christians who disagree with my theology. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/n7GLquVAqs",
        "expanded_url" : "http:\/\/fairlyspiritual.org\/2015\/09\/04\/without-kindness-its-simply-not-biblical\/",
        "display_url" : "fairlyspiritual.org\/2015\/09\/04\/wit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639970789228343297",
    "text" : "Some of the meanest, most unkind emails I\u2019ve ever received come from Christians who disagree with my theology. http:\/\/t.co\/n7GLquVAqs",
    "id" : 639970789228343297,
    "created_at" : "2015-09-05 01:18:20 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 639972071183937540,
  "created_at" : "2015-09-05 01:23:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639944943608426497",
  "text" : "RT @Angelapaints: Pay no attention to that man behind the curtain!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639944368913166336",
    "text" : "Pay no attention to that man behind the curtain!",
    "id" : 639944368913166336,
    "created_at" : "2015-09-04 23:33:21 +0000",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 639944943608426497,
  "created_at" : "2015-09-04 23:35:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639883530235981825",
  "geo" : { },
  "id_str" : "639939508465737733",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe i hope you get yr glasses sorted out. ugh.",
  "id" : 639939508465737733,
  "in_reply_to_status_id" : 639883530235981825,
  "created_at" : "2015-09-04 23:14:02 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kathy rybolt",
      "screen_name" : "kathyrybolt",
      "indices" : [ 3, 15 ],
      "id_str" : "329914614",
      "id" : 329914614
    }, {
      "name" : "JashSF",
      "screen_name" : "jashsf",
      "indices" : [ 17, 24 ],
      "id_str" : "45446985",
      "id" : 45446985
    }, {
      "name" : "Jeb Bush",
      "screen_name" : "JebBush",
      "indices" : [ 25, 33 ],
      "id_str" : "113047940",
      "id" : 113047940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639938890615398400",
  "text" : "RT @kathyrybolt: @jashsf @JebBush \n\nJeb CLEARLY &amp; shamefully used\/ misused\/ abused this woman for a purely self-serving &amp; hypocritical  pol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JashSF",
        "screen_name" : "jashsf",
        "indices" : [ 0, 7 ],
        "id_str" : "45446985",
        "id" : 45446985
      }, {
        "name" : "Jeb Bush",
        "screen_name" : "JebBush",
        "indices" : [ 8, 16 ],
        "id_str" : "113047940",
        "id" : 113047940
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639485094860689408",
    "geo" : { },
    "id_str" : "639511778905341952",
    "in_reply_to_user_id" : 45446985,
    "text" : "@jashsf @JebBush \n\nJeb CLEARLY &amp; shamefully used\/ misused\/ abused this woman for a purely self-serving &amp; hypocritical  political prop. SAD!!",
    "id" : 639511778905341952,
    "in_reply_to_status_id" : 639485094860689408,
    "created_at" : "2015-09-03 18:54:24 +0000",
    "in_reply_to_screen_name" : "jashsf",
    "in_reply_to_user_id_str" : "45446985",
    "user" : {
      "name" : "kathy rybolt",
      "screen_name" : "kathyrybolt",
      "protected" : false,
      "id_str" : "329914614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585397254279663616\/B2FHHaHE_normal.jpg",
      "id" : 329914614,
      "verified" : false
    }
  },
  "id" : 639938890615398400,
  "created_at" : "2015-09-04 23:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/639919821413441536\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/MkWNxGEmil",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COFzrwbWEAEWpS_.jpg",
      "id_str" : "639919817634484225",
      "id" : 639919817634484225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COFzrwbWEAEWpS_.jpg",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/MkWNxGEmil"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/sXuxZ5Fwrs",
      "expanded_url" : "http:\/\/neyhart.blogspot.com\/2015\/09\/a-hermeneutic-of-love-or-how-i-read.html",
      "display_url" : "neyhart.blogspot.com\/2015\/09\/a-herm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639919821413441536",
  "text" : "Jennifer Neyhart: A Hermeneutic of Love, or How I Read the Bible (Part 1) http:\/\/t.co\/sXuxZ5Fwrs http:\/\/t.co\/MkWNxGEmil",
  "id" : 639919821413441536,
  "created_at" : "2015-09-04 21:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/oOvxamqH3s",
      "expanded_url" : "http:\/\/disq.us\/8oig45",
      "display_url" : "disq.us\/8oig45"
    } ]
  },
  "geo" : { },
  "id_str" : "639908024145068032",
  "text" : "\"Let's take the focus off... beliefs the woman has and look at it as if it was any other moral stand.\" http:\/\/t.co\/oOvxamqH3s",
  "id" : 639908024145068032,
  "created_at" : "2015-09-04 21:08:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639811033067048960",
  "geo" : { },
  "id_str" : "639902969350254592",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe say what?? well those ppl dont know what they're missing out on.. jerks. ((hugs))",
  "id" : 639902969350254592,
  "in_reply_to_status_id" : 639811033067048960,
  "created_at" : "2015-09-04 20:48:51 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Defining America",
      "screen_name" : "DefiningAmerica",
      "indices" : [ 3, 19 ],
      "id_str" : "2700946206",
      "id" : 2700946206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Grassroots",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "DNC",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "debates",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "AllowDebate",
      "indices" : [ 72, 84 ]
    }, {
      "text" : "HillaryClinton",
      "indices" : [ 85, 100 ]
    }, {
      "text" : "MartinOMalley",
      "indices" : [ 101, 115 ]
    }, {
      "text" : "BernieSanders",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639586651891757056",
  "text" : "RT @DefiningAmerica: #Grassroots turn up heat on #DNC for more #debates #AllowDebate #HillaryClinton #MartinOMalley #BernieSanders 7 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Grassroots",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "DNC",
        "indices" : [ 28, 32 ]
      }, {
        "text" : "debates",
        "indices" : [ 42, 50 ]
      }, {
        "text" : "AllowDebate",
        "indices" : [ 51, 63 ]
      }, {
        "text" : "HillaryClinton",
        "indices" : [ 64, 79 ]
      }, {
        "text" : "MartinOMalley",
        "indices" : [ 80, 94 ]
      }, {
        "text" : "BernieSanders",
        "indices" : [ 95, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/8gmMADnDJp",
        "expanded_url" : "http:\/\/ow.ly\/RJuru",
        "display_url" : "ow.ly\/RJuru"
      } ]
    },
    "geo" : { },
    "id_str" : "639586278342795264",
    "text" : "#Grassroots turn up heat on #DNC for more #debates #AllowDebate #HillaryClinton #MartinOMalley #BernieSanders 7 http:\/\/t.co\/8gmMADnDJp",
    "id" : 639586278342795264,
    "created_at" : "2015-09-03 23:50:26 +0000",
    "user" : {
      "name" : "Defining America",
      "screen_name" : "DefiningAmerica",
      "protected" : false,
      "id_str" : "2700946206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495584374868303873\/qpOMMjkC_normal.jpeg",
      "id" : 2700946206,
      "verified" : false
    }
  },
  "id" : 639586651891757056,
  "created_at" : "2015-09-03 23:51:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopthepersecution",
      "indices" : [ 79, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/1AAT02puRH",
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/639519427709542400",
      "display_url" : "twitter.com\/tedcruz\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639565832259960832",
  "text" : "RT @SangyeH: How about calling on every American to stop harassing LGBT folks? #stopthepersecution  https:\/\/t.co\/1AAT02puRH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stopthepersecution",
        "indices" : [ 66, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/1AAT02puRH",
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/639519427709542400",
        "display_url" : "twitter.com\/tedcruz\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639531233026908160",
    "text" : "How about calling on every American to stop harassing LGBT folks? #stopthepersecution  https:\/\/t.co\/1AAT02puRH",
    "id" : 639531233026908160,
    "created_at" : "2015-09-03 20:11:42 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 639565832259960832,
  "created_at" : "2015-09-03 22:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KimDavis",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/1AAT02puRH",
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/639519427709542400",
      "display_url" : "twitter.com\/tedcruz\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639565516869341184",
  "text" : "RT @SangyeH: What do Republicans call a worker who collects a salary but refuses to work? A moocher. \n\n#KimDavis  https:\/\/t.co\/1AAT02puRH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KimDavis",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/1AAT02puRH",
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/639519427709542400",
        "display_url" : "twitter.com\/tedcruz\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639535102104576000",
    "text" : "What do Republicans call a worker who collects a salary but refuses to work? A moocher. \n\n#KimDavis  https:\/\/t.co\/1AAT02puRH",
    "id" : 639535102104576000,
    "created_at" : "2015-09-03 20:27:04 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 639565516869341184,
  "created_at" : "2015-09-03 22:27:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "separationofchurchandstate",
      "indices" : [ 53, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/3C1lY8mlCg",
      "expanded_url" : "https:\/\/twitter.com\/cjwerleman\/status\/639541331241533440",
      "display_url" : "twitter.com\/cjwerleman\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639565127562301440",
  "text" : "WHAT criminalization of christianity?? WTF Huckabee? #separationofchurchandstate  https:\/\/t.co\/3C1lY8mlCg",
  "id" : 639565127562301440,
  "created_at" : "2015-09-03 22:26:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/639563767664087040\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/CM0Iuic7w1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COAv2sjWIAEcPRV.jpg",
      "id_str" : "639563763805462529",
      "id" : 639563763805462529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COAv2sjWIAEcPRV.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 437
      }, {
        "h" : 1209,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 247
      }, {
        "h" : 1209,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/CM0Iuic7w1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/LZ7w1dcKFE",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=10207364949183500&set=a.1770517384274.102227.1279420498&type=1",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639563767664087040",
  "text" : "Get mined legally.. DH had a good LOL with this. https:\/\/t.co\/LZ7w1dcKFE http:\/\/t.co\/CM0Iuic7w1",
  "id" : 639563767664087040,
  "created_at" : "2015-09-03 22:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lance Jaynes",
      "screen_name" : "LuckyLanceJ",
      "indices" : [ 3, 15 ],
      "id_str" : "739848938",
      "id" : 739848938
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LuckyLanceJ\/status\/639282229475188736\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/OqhImDobuN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN8vzPBWEAAu5xo.jpg",
      "id_str" : "639282229361905664",
      "id" : 639282229361905664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN8vzPBWEAAu5xo.jpg",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 529
      } ],
      "display_url" : "pic.twitter.com\/OqhImDobuN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639491617460756480",
  "text" : "RT @LuckyLanceJ: http:\/\/t.co\/OqhImDobuN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LuckyLanceJ\/status\/639282229475188736\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/OqhImDobuN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN8vzPBWEAAu5xo.jpg",
        "id_str" : "639282229361905664",
        "id" : 639282229361905664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN8vzPBWEAAu5xo.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 529
        } ],
        "display_url" : "pic.twitter.com\/OqhImDobuN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639282229475188736",
    "text" : "http:\/\/t.co\/OqhImDobuN",
    "id" : 639282229475188736,
    "created_at" : "2015-09-03 03:42:15 +0000",
    "user" : {
      "name" : "Lance Jaynes",
      "screen_name" : "LuckyLanceJ",
      "protected" : false,
      "id_str" : "739848938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792970715519520768\/lHBzHuKM_normal.jpg",
      "id" : 739848938,
      "verified" : false
    }
  },
  "id" : 639491617460756480,
  "created_at" : "2015-09-03 17:34:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/MpOwixKJD2",
      "expanded_url" : "https:\/\/twitter.com\/MatthewKeysLive\/status\/639282196956602368",
      "display_url" : "twitter.com\/MatthewKeysLiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639491534900056064",
  "text" : ":D https:\/\/t.co\/MpOwixKJD2",
  "id" : 639491534900056064,
  "created_at" : "2015-09-03 17:33:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639436756497006592",
  "geo" : { },
  "id_str" : "639489981023653888",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind good song.. elvis costello.",
  "id" : 639489981023653888,
  "in_reply_to_status_id" : 639436756497006592,
  "created_at" : "2015-09-03 17:27:47 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvanian Families",
      "screen_name" : "SylvanianUK",
      "indices" : [ 3, 15 ],
      "id_str" : "2290269306",
      "id" : 2290269306
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SylvanianUK\/status\/639454330827997184\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/65j737DkwE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_MU1cUsAAfOnB.jpg",
      "id_str" : "639454330425225216",
      "id" : 639454330425225216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_MU1cUsAAfOnB.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/65j737DkwE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639488934628708353",
  "text" : "RT @SylvanianUK: We're singing in the rain! http:\/\/t.co\/65j737DkwE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SylvanianUK\/status\/639454330827997184\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/65j737DkwE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_MU1cUsAAfOnB.jpg",
        "id_str" : "639454330425225216",
        "id" : 639454330425225216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_MU1cUsAAfOnB.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/65j737DkwE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639454330827997184",
    "text" : "We're singing in the rain! http:\/\/t.co\/65j737DkwE",
    "id" : 639454330827997184,
    "created_at" : "2015-09-03 15:06:07 +0000",
    "user" : {
      "name" : "Sylvanian Families",
      "screen_name" : "SylvanianUK",
      "protected" : false,
      "id_str" : "2290269306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464088241025454080\/vrDjzwrc_normal.jpeg",
      "id" : 2290269306,
      "verified" : false
    }
  },
  "id" : 639488934628708353,
  "created_at" : "2015-09-03 17:23:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "indices" : [ 3, 14 ],
      "id_str" : "14606079",
      "id" : 14606079
    }, {
      "name" : "Megan Rose",
      "screen_name" : "MegMcCloskey",
      "indices" : [ 63, 76 ],
      "id_str" : "25110115",
      "id" : 25110115
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BoondoggleHQ",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/TpgQtr8J27",
      "expanded_url" : "http:\/\/propub.ca\/1Up8Cid",
      "display_url" : "propub.ca\/1Up8Cid"
    } ]
  },
  "geo" : { },
  "id_str" : "639488281500102656",
  "text" : "RT @ProPublica: Total spent on this type of waste? $42M+. Read @MegMcCloskey's #BoondoggleHQ for more: http:\/\/t.co\/TpgQtr8J27 http:\/\/t.co\/E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan Rose",
        "screen_name" : "MegMcCloskey",
        "indices" : [ 47, 60 ],
        "id_str" : "25110115",
        "id" : 25110115
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ProPublica\/status\/639442472293302272\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/ETESm4EmXU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_Bij0W8AAYXwl.png",
        "id_str" : "639442471584460800",
        "id" : 639442471584460800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_Bij0W8AAYXwl.png",
        "sizes" : [ {
          "h" : 644,
          "resize" : "fit",
          "w" : 1274
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ETESm4EmXU"
      } ],
      "hashtags" : [ {
        "text" : "BoondoggleHQ",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/TpgQtr8J27",
        "expanded_url" : "http:\/\/propub.ca\/1Up8Cid",
        "display_url" : "propub.ca\/1Up8Cid"
      } ]
    },
    "in_reply_to_status_id_str" : "639441419652870144",
    "geo" : { },
    "id_str" : "639442472293302272",
    "in_reply_to_user_id" : 14606079,
    "text" : "Total spent on this type of waste? $42M+. Read @MegMcCloskey's #BoondoggleHQ for more: http:\/\/t.co\/TpgQtr8J27 http:\/\/t.co\/ETESm4EmXU",
    "id" : 639442472293302272,
    "in_reply_to_status_id" : 639441419652870144,
    "created_at" : "2015-09-03 14:19:00 +0000",
    "in_reply_to_screen_name" : "ProPublica",
    "in_reply_to_user_id_str" : "14606079",
    "user" : {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "protected" : false,
      "id_str" : "14606079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660147326091182081\/Q4TLW_Fe_normal.jpg",
      "id" : 14606079,
      "verified" : true
    }
  },
  "id" : 639488281500102656,
  "created_at" : "2015-09-03 17:21:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Schindler",
      "screen_name" : "donschindler",
      "indices" : [ 3, 16 ],
      "id_str" : "6032632",
      "id" : 6032632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 113, 119 ]
    }, {
      "text" : "quoteoftheday",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639487961625661440",
  "text" : "RT @donschindler: You need to choose wisely about who you follow. They have a lot more influence than you think. #quote #quoteoftheday http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/donschindler\/status\/639456112350208001\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xXzfeidhhF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_N73RVEAA1yiy.jpg",
        "id_str" : "639456100442509312",
        "id" : 639456100442509312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_N73RVEAA1yiy.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xXzfeidhhF"
      } ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "quoteoftheday",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639456112350208001",
    "text" : "You need to choose wisely about who you follow. They have a lot more influence than you think. #quote #quoteoftheday http:\/\/t.co\/xXzfeidhhF",
    "id" : 639456112350208001,
    "created_at" : "2015-09-03 15:13:12 +0000",
    "user" : {
      "name" : "Don Schindler",
      "screen_name" : "donschindler",
      "protected" : false,
      "id_str" : "6032632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535545063820898304\/32CJcNXb_normal.png",
      "id" : 6032632,
      "verified" : false
    }
  },
  "id" : 639487961625661440,
  "created_at" : "2015-09-03 17:19:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobooked",
      "screen_name" : "audiobooked",
      "indices" : [ 3, 15 ],
      "id_str" : "2797832461",
      "id" : 2797832461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/vvZweE4IkR",
      "expanded_url" : "https:\/\/audiobooked.net\/blog\/version-3-3",
      "display_url" : "audiobooked.net\/blog\/version-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639455600989093892",
  "text" : "RT @audiobooked: The wait is over! Audiobooked v3.3 is here. Get it now ;) https:\/\/t.co\/vvZweE4IkR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/vvZweE4IkR",
        "expanded_url" : "https:\/\/audiobooked.net\/blog\/version-3-3",
        "display_url" : "audiobooked.net\/blog\/version-3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639090812240838656",
    "text" : "The wait is over! Audiobooked v3.3 is here. Get it now ;) https:\/\/t.co\/vvZweE4IkR",
    "id" : 639090812240838656,
    "created_at" : "2015-09-02 15:01:38 +0000",
    "user" : {
      "name" : "Audiobooked",
      "screen_name" : "audiobooked",
      "protected" : false,
      "id_str" : "2797832461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549989531525476352\/I9hyTetO_normal.png",
      "id" : 2797832461,
      "verified" : false
    }
  },
  "id" : 639455600989093892,
  "created_at" : "2015-09-03 15:11:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie Hetherington",
      "screen_name" : "R_o_s_i_e_H",
      "indices" : [ 3, 15 ],
      "id_str" : "1209666504",
      "id" : 1209666504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/R_o_s_i_e_H\/status\/639152434636541952\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/YwVLQkxqkM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN65t7aXAAA9GUI.jpg",
      "id_str" : "639152395826692096",
      "id" : 639152395826692096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN65t7aXAAA9GUI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/YwVLQkxqkM"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/R_o_s_i_e_H\/status\/639152434636541952\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/YwVLQkxqkM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN65uliWEAQJ7qz.jpg",
      "id_str" : "639152407134474244",
      "id" : 639152407134474244,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN65uliWEAQJ7qz.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/YwVLQkxqkM"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/R_o_s_i_e_H\/status\/639152434636541952\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/YwVLQkxqkM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN65vgVWgAAhWoC.jpg",
      "id_str" : "639152422917668864",
      "id" : 639152422917668864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN65vgVWgAAhWoC.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/YwVLQkxqkM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639234539898949633",
  "text" : "RT @R_o_s_i_e_H: Sophy isn't happy with her restrictive diet.. http:\/\/t.co\/YwVLQkxqkM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/R_o_s_i_e_H\/status\/639152434636541952\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/YwVLQkxqkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN65t7aXAAA9GUI.jpg",
        "id_str" : "639152395826692096",
        "id" : 639152395826692096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN65t7aXAAA9GUI.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/YwVLQkxqkM"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/R_o_s_i_e_H\/status\/639152434636541952\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/YwVLQkxqkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN65uliWEAQJ7qz.jpg",
        "id_str" : "639152407134474244",
        "id" : 639152407134474244,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN65uliWEAQJ7qz.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/YwVLQkxqkM"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/R_o_s_i_e_H\/status\/639152434636541952\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/YwVLQkxqkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN65vgVWgAAhWoC.jpg",
        "id_str" : "639152422917668864",
        "id" : 639152422917668864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN65vgVWgAAhWoC.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/YwVLQkxqkM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639152434636541952",
    "text" : "Sophy isn't happy with her restrictive diet.. http:\/\/t.co\/YwVLQkxqkM",
    "id" : 639152434636541952,
    "created_at" : "2015-09-02 19:06:29 +0000",
    "user" : {
      "name" : "Rosie Hetherington",
      "screen_name" : "R_o_s_i_e_H",
      "protected" : false,
      "id_str" : "1209666504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713451168983343104\/E1noM-JI_normal.jpg",
      "id" : 1209666504,
      "verified" : false
    }
  },
  "id" : 639234539898949633,
  "created_at" : "2015-09-03 00:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Green Goat",
      "screen_name" : "TheGreenGoat_SF",
      "indices" : [ 3, 19 ],
      "id_str" : "180022710",
      "id" : 180022710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humpday",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "animals",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6xnW0QT51V",
      "expanded_url" : "http:\/\/www.livescience.com\/27408-moose.html",
      "display_url" : "livescience.com\/27408-moose.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639114561652695040",
  "text" : "RT @TheGreenGoat_SF: In honor of #humpday, #animals with humps: presenting Mr. Moose! The largest deer (dear).\nhttp:\/\/t.co\/6xnW0QT51V http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheGreenGoat_SF\/status\/639108031620366336\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/GK8kqFCuRy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6RXjsUcAIzs2o.jpg",
        "id_str" : "639108031037337602",
        "id" : 639108031037337602,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6RXjsUcAIzs2o.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GK8kqFCuRy"
      } ],
      "hashtags" : [ {
        "text" : "humpday",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "animals",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/6xnW0QT51V",
        "expanded_url" : "http:\/\/www.livescience.com\/27408-moose.html",
        "display_url" : "livescience.com\/27408-moose.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639108031620366336",
    "text" : "In honor of #humpday, #animals with humps: presenting Mr. Moose! The largest deer (dear).\nhttp:\/\/t.co\/6xnW0QT51V http:\/\/t.co\/GK8kqFCuRy",
    "id" : 639108031620366336,
    "created_at" : "2015-09-02 16:10:03 +0000",
    "user" : {
      "name" : "The Green Goat",
      "screen_name" : "TheGreenGoat_SF",
      "protected" : false,
      "id_str" : "180022710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1105829277\/Goat-Avatar_normal.png",
      "id" : 180022710,
      "verified" : false
    }
  },
  "id" : 639114561652695040,
  "created_at" : "2015-09-02 16:36:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/lNbspxo1HD",
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/639088719908216832",
      "display_url" : "twitter.com\/Elverojaguar\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639091148531871744",
  "text" : "LOLOL https:\/\/t.co\/lNbspxo1HD",
  "id" : 639091148531871744,
  "created_at" : "2015-09-02 15:02:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638918221282844672",
  "geo" : { },
  "id_str" : "639087444189683712",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe yes! I get this. it's like a living work of art.",
  "id" : 639087444189683712,
  "in_reply_to_status_id" : 638918221282844672,
  "created_at" : "2015-09-02 14:48:15 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/qKaNqUhAm6",
      "expanded_url" : "https:\/\/twitter.com\/stan_sdcollins\/status\/639005820923965441",
      "display_url" : "twitter.com\/stan_sdcollins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639085248907714560",
  "text" : "beautiful https:\/\/t.co\/qKaNqUhAm6",
  "id" : 639085248907714560,
  "created_at" : "2015-09-02 14:39:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stavros\u2122 = \u03A3\u03C4\u03B1\u03C5\u03C1o\u03C2\u00A9",
      "screen_name" : "dodona777",
      "indices" : [ 3, 13 ],
      "id_str" : "448692159",
      "id" : 448692159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638882575268868096",
  "text" : "RT @dodona777: I wrote this last year. Still think it's true. I'll add &gt; dream shared &amp; acted on with others offline can make change http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dodona777\/status\/638881472967933952\/photo\/1",
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/0AttdzPMF6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN3DUEcUcAAb0Ij.jpg",
        "id_str" : "638881471713800192",
        "id" : 638881471713800192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN3DUEcUcAAb0Ij.jpg",
        "sizes" : [ {
          "h" : 290,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 521
        } ],
        "display_url" : "pic.twitter.com\/0AttdzPMF6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638881472967933952",
    "text" : "I wrote this last year. Still think it's true. I'll add &gt; dream shared &amp; acted on with others offline can make change http:\/\/t.co\/0AttdzPMF6",
    "id" : 638881472967933952,
    "created_at" : "2015-09-02 01:09:47 +0000",
    "user" : {
      "name" : "Stavros\u2122 = \u03A3\u03C4\u03B1\u03C5\u03C1o\u03C2\u00A9",
      "screen_name" : "dodona777",
      "protected" : false,
      "id_str" : "448692159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637499620759736322\/WmpdcbHw_normal.jpg",
      "id" : 448692159,
      "verified" : false
    }
  },
  "id" : 638882575268868096,
  "created_at" : "2015-09-02 01:14:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KunzangPalyulCholing",
      "screen_name" : "kunzangpalyul",
      "indices" : [ 3, 17 ],
      "id_str" : "20122068",
      "id" : 20122068
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 103, 113 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kunzangpalyul\/status\/638848868281528320\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/5IgVMdYfKd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN18ICvWgAE_q38.jpg",
      "id_str" : "638803199772753921",
      "id" : 638803199772753921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN18ICvWgAE_q38.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5IgVMdYfKd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638873846758678528",
  "text" : "RT @kunzangpalyul: \"Try to be as generous as possible to all sentient beings.\"\n\n~ Jetsunma Ahkon Lhamo @JALPalyul http:\/\/t.co\/5IgVMdYfKd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 84, 94 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kunzangpalyul\/status\/638848868281528320\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5IgVMdYfKd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN18ICvWgAE_q38.jpg",
        "id_str" : "638803199772753921",
        "id" : 638803199772753921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN18ICvWgAE_q38.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5IgVMdYfKd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638848868281528320",
    "text" : "\"Try to be as generous as possible to all sentient beings.\"\n\n~ Jetsunma Ahkon Lhamo @JALPalyul http:\/\/t.co\/5IgVMdYfKd",
    "id" : 638848868281528320,
    "created_at" : "2015-09-01 23:00:14 +0000",
    "user" : {
      "name" : "KunzangPalyulCholing",
      "screen_name" : "kunzangpalyul",
      "protected" : false,
      "id_str" : "20122068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3385399554\/26d77d13c3558ccdf368e6097ed3304a_normal.jpeg",
      "id" : 20122068,
      "verified" : false
    }
  },
  "id" : 638873846758678528,
  "created_at" : "2015-09-02 00:39:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KunzangPalyulCholing",
      "screen_name" : "kunzangpalyul",
      "indices" : [ 3, 17 ],
      "id_str" : "20122068",
      "id" : 20122068
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 126, 136 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638873782959124480",
  "text" : "RT @kunzangpalyul: One should do nothing other than what is directly or indirectly of benefit to living beings.\n~ Shantideva\n\n@JALPAlyul ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 107, 117 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kunzangpalyul\/status\/638833759559639040\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BUGovRQpld",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN17-4PWIAApSGv.jpg",
        "id_str" : "638803042335334400",
        "id" : 638803042335334400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN17-4PWIAApSGv.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BUGovRQpld"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638833759559639040",
    "text" : "One should do nothing other than what is directly or indirectly of benefit to living beings.\n~ Shantideva\n\n@JALPAlyul http:\/\/t.co\/BUGovRQpld",
    "id" : 638833759559639040,
    "created_at" : "2015-09-01 22:00:11 +0000",
    "user" : {
      "name" : "KunzangPalyulCholing",
      "screen_name" : "kunzangpalyul",
      "protected" : false,
      "id_str" : "20122068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3385399554\/26d77d13c3558ccdf368e6097ed3304a_normal.jpeg",
      "id" : 20122068,
      "verified" : false
    }
  },
  "id" : 638873782959124480,
  "created_at" : "2015-09-02 00:39:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Fusion News",
      "screen_name" : "FusionNews",
      "indices" : [ 9, 20 ],
      "id_str" : "436873679",
      "id" : 436873679
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BLM",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638860726355013636",
  "geo" : { },
  "id_str" : "638873367223889922",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH @FusionNews wow.. Even though I get #BLM , this really explains it!",
  "id" : 638873367223889922,
  "in_reply_to_status_id" : 638860726355013636,
  "created_at" : "2015-09-02 00:37:35 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Fusion News",
      "screen_name" : "FusionNews",
      "indices" : [ 116, 127 ],
      "id_str" : "436873679",
      "id" : 436873679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tfvy3xi77v",
      "expanded_url" : "http:\/\/fusion.net\/story\/170591\/the-next-time-someone-says-all-lives-matter-show-them-these-5-paragraphs\/?utm_source=twitter&utm_medium=social&utm_campaign=socialshare&utm_content=sticky+nav",
      "display_url" : "fusion.net\/story\/170591\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638872958749024256",
  "text" : "RT @SangyeH: The next time someone says 'all lives matter,' show them these 5 paragraphs http:\/\/t.co\/tfvy3xi77v via @FusionNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fusion News",
        "screen_name" : "FusionNews",
        "indices" : [ 103, 114 ],
        "id_str" : "436873679",
        "id" : 436873679
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/tfvy3xi77v",
        "expanded_url" : "http:\/\/fusion.net\/story\/170591\/the-next-time-someone-says-all-lives-matter-show-them-these-5-paragraphs\/?utm_source=twitter&utm_medium=social&utm_campaign=socialshare&utm_content=sticky+nav",
        "display_url" : "fusion.net\/story\/170591\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638860726355013636",
    "text" : "The next time someone says 'all lives matter,' show them these 5 paragraphs http:\/\/t.co\/tfvy3xi77v via @FusionNews",
    "id" : 638860726355013636,
    "created_at" : "2015-09-01 23:47:21 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 638872958749024256,
  "created_at" : "2015-09-02 00:35:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/638747120355381252\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/rylm9OGHWq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN1JGQEW8AAbJpW.jpg",
      "id_str" : "638747093897768960",
      "id" : 638747093897768960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN1JGQEW8AAbJpW.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/rylm9OGHWq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638843904197021696",
  "text" : "RT @1CatShepherd: Time to get back to work http:\/\/t.co\/rylm9OGHWq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/638747120355381252\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/rylm9OGHWq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN1JGQEW8AAbJpW.jpg",
        "id_str" : "638747093897768960",
        "id" : 638747093897768960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN1JGQEW8AAbJpW.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/rylm9OGHWq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638747120355381252",
    "text" : "Time to get back to work http:\/\/t.co\/rylm9OGHWq",
    "id" : 638747120355381252,
    "created_at" : "2015-09-01 16:15:55 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 638843904197021696,
  "created_at" : "2015-09-01 22:40:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Snider",
      "screen_name" : "grantdraws",
      "indices" : [ 3, 14 ],
      "id_str" : "299825874",
      "id" : 299825874
    }, {
      "name" : "Fred Rogers Center",
      "screen_name" : "FredRogersCtr",
      "indices" : [ 50, 64 ],
      "id_str" : "32539107",
      "id" : 32539107
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/grantdraws\/status\/638780592721653760\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CFe0HFviJE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN1nkE3WsAA-Oee.jpg",
      "id_str" : "638780591635345408",
      "id" : 638780591635345408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN1nkE3WsAA-Oee.jpg",
      "sizes" : [ {
        "h" : 1184,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1184,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 1015,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CFe0HFviJE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/UCdiKY5MHj",
      "expanded_url" : "http:\/\/www.incidentalcomics.com\/2015\/09\/how-to-grow-imagination.html",
      "display_url" : "incidentalcomics.com\/2015\/09\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638843800706748416",
  "text" : "RT @grantdraws: Here's a new comic I drew for the @FredRogersCtr about using your imagination: http:\/\/t.co\/UCdiKY5MHj http:\/\/t.co\/CFe0HFviJE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fred Rogers Center",
        "screen_name" : "FredRogersCtr",
        "indices" : [ 34, 48 ],
        "id_str" : "32539107",
        "id" : 32539107
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/grantdraws\/status\/638780592721653760\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/CFe0HFviJE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN1nkE3WsAA-Oee.jpg",
        "id_str" : "638780591635345408",
        "id" : 638780591635345408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN1nkE3WsAA-Oee.jpg",
        "sizes" : [ {
          "h" : 1184,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1184,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 1015,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CFe0HFviJE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/UCdiKY5MHj",
        "expanded_url" : "http:\/\/www.incidentalcomics.com\/2015\/09\/how-to-grow-imagination.html",
        "display_url" : "incidentalcomics.com\/2015\/09\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638780592721653760",
    "text" : "Here's a new comic I drew for the @FredRogersCtr about using your imagination: http:\/\/t.co\/UCdiKY5MHj http:\/\/t.co\/CFe0HFviJE",
    "id" : 638780592721653760,
    "created_at" : "2015-09-01 18:28:55 +0000",
    "user" : {
      "name" : "Grant Snider",
      "screen_name" : "grantdraws",
      "protected" : false,
      "id_str" : "299825874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801093455082504193\/kV5TbwAb_normal.jpg",
      "id" : 299825874,
      "verified" : false
    }
  },
  "id" : 638843800706748416,
  "created_at" : "2015-09-01 22:40:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrinceRupert",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638843348099440640",
  "text" : "RT @ScarlettWulf: I'm in Awe of them. To spend such close &amp; personal time with these two, is really something. #PrinceRupert http:\/\/t.co\/YC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/636179399511900160\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/YCQXezXx1p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQpyMqVEAADgL_.jpg",
        "id_str" : "636179389735047168",
        "id" : 636179389735047168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQpyMqVEAADgL_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 691,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 691,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YCQXezXx1p"
      } ],
      "hashtags" : [ {
        "text" : "PrinceRupert",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636179399511900160",
    "text" : "I'm in Awe of them. To spend such close &amp; personal time with these two, is really something. #PrinceRupert http:\/\/t.co\/YCQXezXx1p",
    "id" : 636179399511900160,
    "created_at" : "2015-08-25 14:12:43 +0000",
    "user" : {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "protected" : false,
      "id_str" : "1348108910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741919775668867072\/yzqHRx03_normal.jpg",
      "id" : 1348108910,
      "verified" : false
    }
  },
  "id" : 638843348099440640,
  "created_at" : "2015-09-01 22:38:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ilovethewoo",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638802236697628672",
  "geo" : { },
  "id_str" : "638815526979022848",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time lol.. that's ok, I still like you : ) &lt;3 #ilovethewoo",
  "id" : 638815526979022848,
  "in_reply_to_status_id" : 638802236697628672,
  "created_at" : "2015-09-01 20:47:44 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/s7GVxdIjPs",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/a-sincere-question-for-my-friends-who-believe-in-hell\/",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638739198833487872",
  "text" : "RT @benjamincorey: A Sincere Question For My Friends Who Believe In Hell: http:\/\/t.co\/s7GVxdIjPs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/s7GVxdIjPs",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/a-sincere-question-for-my-friends-who-believe-in-hell\/",
        "display_url" : "patheos.com\/blogs\/formerly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638726826374889472",
    "text" : "A Sincere Question For My Friends Who Believe In Hell: http:\/\/t.co\/s7GVxdIjPs",
    "id" : 638726826374889472,
    "created_at" : "2015-09-01 14:55:17 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 638739198833487872,
  "created_at" : "2015-09-01 15:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P.S. Brooks",
      "screen_name" : "P_S_Brooks",
      "indices" : [ 3, 14 ],
      "id_str" : "2789435040",
      "id" : 2789435040
    }, {
      "name" : "Pinch Punch Post",
      "screen_name" : "pinchpunchpost",
      "indices" : [ 42, 57 ],
      "id_str" : "3166164415",
      "id" : 3166164415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pinchpunchpost",
      "indices" : [ 26, 41 ]
    }, {
      "text" : "2dart",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638725574706495488",
  "text" : "RT @P_S_Brooks: Sheep for #pinchpunchpost @pinchpunchpost (on time this month!) + (very early) Tea Rose Colour Collective #2dart :) http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pinch Punch Post",
        "screen_name" : "pinchpunchpost",
        "indices" : [ 26, 41 ],
        "id_str" : "3166164415",
        "id" : 3166164415
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/P_S_Brooks\/status\/638486809115271168\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/yqibBQaaYH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNxcXnfXAAQk87E.jpg",
        "id_str" : "638486807987027972",
        "id" : 638486807987027972,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNxcXnfXAAQk87E.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1340
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/yqibBQaaYH"
      } ],
      "hashtags" : [ {
        "text" : "pinchpunchpost",
        "indices" : [ 10, 25 ]
      }, {
        "text" : "2dart",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638486809115271168",
    "text" : "Sheep for #pinchpunchpost @pinchpunchpost (on time this month!) + (very early) Tea Rose Colour Collective #2dart :) http:\/\/t.co\/yqibBQaaYH",
    "id" : 638486809115271168,
    "created_at" : "2015-08-31 23:01:32 +0000",
    "user" : {
      "name" : "P.S. Brooks",
      "screen_name" : "P_S_Brooks",
      "protected" : false,
      "id_str" : "2789435040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652222064565350400\/mOulK5SE_normal.jpg",
      "id" : 2789435040,
      "verified" : false
    }
  },
  "id" : 638725574706495488,
  "created_at" : "2015-09-01 14:50:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Tom (Graham)",
      "screen_name" : "oaklawnfarms",
      "indices" : [ 3, 16 ],
      "id_str" : "197984793",
      "id" : 197984793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638724870679986176",
  "text" : "RT @oaklawnfarms: Been watching this on radar for almost an hour, hasn't moved. Base is 40 miles west over NE Columbus http:\/\/t.co\/ROcpd17o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oaklawnfarms\/status\/638486401504313344\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/ROcpd17oDB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNxb-p9UEAIt_LK.jpg",
        "id_str" : "638486379152805890",
        "id" : 638486379152805890,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNxb-p9UEAIt_LK.jpg",
        "sizes" : [ {
          "h" : 392,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 888
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 888
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ROcpd17oDB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638486401504313344",
    "text" : "Been watching this on radar for almost an hour, hasn't moved. Base is 40 miles west over NE Columbus http:\/\/t.co\/ROcpd17oDB",
    "id" : 638486401504313344,
    "created_at" : "2015-08-31 22:59:55 +0000",
    "user" : {
      "name" : "Farmer Tom (Graham)",
      "screen_name" : "oaklawnfarms",
      "protected" : false,
      "id_str" : "197984793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799033942590496769\/J3KJPMm4_normal.jpg",
      "id" : 197984793,
      "verified" : false
    }
  },
  "id" : 638724870679986176,
  "created_at" : "2015-09-01 14:47:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Vaughn",
      "screen_name" : "DonVaughnDJ",
      "indices" : [ 3, 15 ],
      "id_str" : "284066171",
      "id" : 284066171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638724433692217344",
  "text" : "RT @DonVaughnDJ: Family member: what are you doing with your life?\n\nme: it's a surprise",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638712949457072128",
    "text" : "Family member: what are you doing with your life?\n\nme: it's a surprise",
    "id" : 638712949457072128,
    "created_at" : "2015-09-01 14:00:08 +0000",
    "user" : {
      "name" : "Don Vaughn",
      "screen_name" : "DonVaughnDJ",
      "protected" : false,
      "id_str" : "284066171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624709781450719232\/4zAGecfJ_normal.png",
      "id" : 284066171,
      "verified" : false
    }
  },
  "id" : 638724433692217344,
  "created_at" : "2015-09-01 14:45:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]