Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Alan Grayson",
      "screen_name" : "AlanGrayson",
      "indices" : [ 3, 15 ],
      "id_str" : "41017380",
      "id" : 41017380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406961135498567680",
  "text" : "RT @AlanGrayson: We're asking the health insurance companies to serve two masters: patients, and profit. They can\u2019t do it. No one can. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QkkwBKXbdG",
        "expanded_url" : "http:\/\/gray.sn\/1iojI46",
        "display_url" : "gray.sn\/1iojI46"
      } ]
    },
    "geo" : { },
    "id_str" : "406942021828362240",
    "text" : "We're asking the health insurance companies to serve two masters: patients, and profit. They can\u2019t do it. No one can. http:\/\/t.co\/QkkwBKXbdG",
    "id" : 406942021828362240,
    "created_at" : "2013-12-01 00:25:13 +0000",
    "user" : {
      "name" : "Rep. Alan Grayson",
      "screen_name" : "AlanGrayson",
      "protected" : false,
      "id_str" : "41017380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1586639544\/Screen_Shot_2011-10-13_at_11.43.30_AM_normal.png",
      "id" : 41017380,
      "verified" : true
    }
  },
  "id" : 406961135498567680,
  "created_at" : "2013-12-01 01:41:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "James Iacobus",
      "screen_name" : "JamesIacobus",
      "indices" : [ 31, 44 ],
      "id_str" : "1578264330",
      "id" : 1578264330
    }, {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 45, 61 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406896215289118720",
  "geo" : { },
  "id_str" : "406957758609518592",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible good question! @JamesIacobus @CounterApologis",
  "id" : 406957758609518592,
  "in_reply_to_status_id" : 406896215289118720,
  "created_at" : "2013-12-01 01:27:45 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 38, 53 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339159945385742336",
  "geo" : { },
  "id_str" : "406957303166808064",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis thats pretty deep... @AnnotatedBible",
  "id" : 406957303166808064,
  "in_reply_to_status_id" : 339159945385742336,
  "created_at" : "2013-12-01 01:25:56 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "veronic negroni",
      "screen_name" : "veronicnegroni",
      "indices" : [ 3, 18 ],
      "id_str" : "985142635",
      "id" : 985142635
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/veronicnegroni\/status\/404752642645049344\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/tjp9dQQEfE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ34Yk9CQAArc5p.jpg",
      "id_str" : "404752642653437952",
      "id" : 404752642653437952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ34Yk9CQAArc5p.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/tjp9dQQEfE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406941598728351745",
  "text" : "RT @veronicnegroni: lago de Bled Iglesia Santa Maria una joya maravillosa en Eslovenia..un regalo de Navidad.. http:\/\/t.co\/tjp9dQQEfE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/veronicnegroni\/status\/404752642645049344\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/tjp9dQQEfE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ34Yk9CQAArc5p.jpg",
        "id_str" : "404752642653437952",
        "id" : 404752642653437952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ34Yk9CQAArc5p.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/tjp9dQQEfE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404752642645049344",
    "text" : "lago de Bled Iglesia Santa Maria una joya maravillosa en Eslovenia..un regalo de Navidad.. http:\/\/t.co\/tjp9dQQEfE",
    "id" : 404752642645049344,
    "created_at" : "2013-11-24 23:25:24 +0000",
    "user" : {
      "name" : "veronic negroni",
      "screen_name" : "veronicnegroni",
      "protected" : false,
      "id_str" : "985142635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580809621570334720\/8OBrK0KF_normal.jpg",
      "id" : 985142635,
      "verified" : false
    }
  },
  "id" : 406941598728351745,
  "created_at" : "2013-12-01 00:23:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hey",
      "screen_name" : "pinealgland101",
      "indices" : [ 3, 18 ],
      "id_str" : "1074404180",
      "id" : 1074404180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406940001122131968",
  "text" : "RT @PinealGland101: I never want to halt my blessings by engaging &amp; responding to negativity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406935001297465344",
    "text" : "I never want to halt my blessings by engaging &amp; responding to negativity.",
    "id" : 406935001297465344,
    "created_at" : "2013-11-30 23:57:19 +0000",
    "user" : {
      "name" : "THE CULTURE",
      "screen_name" : "Toussaint215",
      "protected" : false,
      "id_str" : "889732015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793667017920380928\/xkPe1lFt_normal.jpg",
      "id" : 889732015,
      "verified" : false
    }
  },
  "id" : 406940001122131968,
  "created_at" : "2013-12-01 00:17:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "BookWorm33333",
      "indices" : [ 3, 17 ],
      "id_str" : "1162427282",
      "id" : 1162427282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406939938555703296",
  "text" : "RT @BookWorm33333: Adorable:-)\n\u201C@volflady: http:\/\/t.co\/BoBS7a38wc\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/volflady\/status\/406829276181188609\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/BoBS7a38wc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVZEjtCUAAVUdF.jpg",
        "id_str" : "406829276185382912",
        "id" : 406829276185382912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVZEjtCUAAVUdF.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BoBS7a38wc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "406829276181188609",
    "geo" : { },
    "id_str" : "406832118795624448",
    "in_reply_to_user_id" : 560545385,
    "text" : "Adorable:-)\n\u201C@volflady: http:\/\/t.co\/BoBS7a38wc\u201D",
    "id" : 406832118795624448,
    "in_reply_to_status_id" : 406829276181188609,
    "created_at" : "2013-11-30 17:08:30 +0000",
    "in_reply_to_screen_name" : "wolves_my_love",
    "in_reply_to_user_id_str" : "560545385",
    "user" : {
      "name" : "Lisa",
      "screen_name" : "BookWorm33333",
      "protected" : false,
      "id_str" : "1162427282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556842823853817856\/yhFN9k8u_normal.jpeg",
      "id" : 1162427282,
      "verified" : false
    }
  },
  "id" : 406939938555703296,
  "created_at" : "2013-12-01 00:16:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Effie Mcintosh",
      "screen_name" : "AKbirder",
      "indices" : [ 28, 37 ],
      "id_str" : "4202024795",
      "id" : 4202024795
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AKbirder\/status\/406878463014862848\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/y006f6zmGo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaWFzmnCQAAnu--.jpg",
      "id_str" : "406878462930993152",
      "id" : 406878462930993152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaWFzmnCQAAnu--.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y006f6zmGo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406926811072069632",
  "text" : "RT @KerriFar: Love this! RT @AKbirder: Cute couple in our bird feeder right now: http:\/\/t.co\/y006f6zmGo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Effie Mcintosh",
        "screen_name" : "AKbirder",
        "indices" : [ 14, 23 ],
        "id_str" : "4202024795",
        "id" : 4202024795
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AKbirder\/status\/406878463014862848\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/y006f6zmGo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaWFzmnCQAAnu--.jpg",
        "id_str" : "406878462930993152",
        "id" : 406878462930993152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaWFzmnCQAAnu--.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/y006f6zmGo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "406878463014862848",
    "geo" : { },
    "id_str" : "406921867887648768",
    "in_reply_to_user_id" : 85193539,
    "text" : "Love this! RT @AKbirder: Cute couple in our bird feeder right now: http:\/\/t.co\/y006f6zmGo",
    "id" : 406921867887648768,
    "in_reply_to_status_id" : 406878463014862848,
    "created_at" : "2013-11-30 23:05:08 +0000",
    "in_reply_to_screen_name" : "IdahoLark",
    "in_reply_to_user_id_str" : "85193539",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 406926811072069632,
  "created_at" : "2013-11-30 23:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 17, 31 ],
      "id_str" : "109003770",
      "id" : 109003770
    }, {
      "name" : "Geographic Photo",
      "screen_name" : "GeographicWorld",
      "indices" : [ 35, 51 ],
      "id_str" : "1453514216",
      "id" : 1453514216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GeographicWorld\/status\/402744906470281216\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/8OpOQIBTTP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZbWW82CUAACYc1.jpg",
      "id_str" : "402744906474475520",
      "id" : 402744906474475520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZbWW82CUAACYc1.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 554
      } ],
      "display_url" : "pic.twitter.com\/8OpOQIBTTP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402744906470281216",
  "geo" : { },
  "id_str" : "406847044284715008",
  "in_reply_to_user_id" : 1453514216,
  "text" : "nice disguise RT @CUMALi_YILDIZ RT @GeographicWorld http:\/\/t.co\/8OpOQIBTTP",
  "id" : 406847044284715008,
  "in_reply_to_status_id" : 402744906470281216,
  "created_at" : "2013-11-30 18:07:48 +0000",
  "in_reply_to_screen_name" : "GeographicWorld",
  "in_reply_to_user_id_str" : "1453514216",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 24, 38 ],
      "id_str" : "109003770",
      "id" : 109003770
    }, {
      "name" : "Geographic Photo",
      "screen_name" : "GeographicWorld",
      "indices" : [ 43, 59 ],
      "id_str" : "1453514216",
      "id" : 1453514216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GeographicWorld\/status\/403202059341533184\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/2FySjkpNOa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZh2IwACEAEDw4h.jpg",
      "id_str" : "403202059345727489",
      "id" : 403202059345727489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZh2IwACEAEDw4h.jpg",
      "sizes" : [ {
        "h" : 703,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1118
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2FySjkpNOa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403202059341533184",
  "geo" : { },
  "id_str" : "406846343957590017",
  "in_reply_to_user_id" : 1453514216,
  "text" : "i could live in here RT @CUMALi_YILDIZ  RT @GeographicWorld http:\/\/t.co\/2FySjkpNOa",
  "id" : 406846343957590017,
  "in_reply_to_status_id" : 403202059341533184,
  "created_at" : "2013-11-30 18:05:01 +0000",
  "in_reply_to_screen_name" : "GeographicWorld",
  "in_reply_to_user_id_str" : "1453514216",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 9, 23 ],
      "id_str" : "109003770",
      "id" : 109003770
    }, {
      "name" : "Geographic Photo",
      "screen_name" : "GeographicWorld",
      "indices" : [ 27, 43 ],
      "id_str" : "1453514216",
      "id" : 1453514216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GeographicWorld\/status\/404668280041795585\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/YRbJrBzhpj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ2rqBwCcAA6Erp.jpg",
      "id_str" : "404668280045989888",
      "id" : 404668280045989888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ2rqBwCcAA6Erp.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 986
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 986
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/YRbJrBzhpj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404668280041795585",
  "geo" : { },
  "id_str" : "406844430855860224",
  "in_reply_to_user_id" : 1453514216,
  "text" : "cozy! RT @CUMALi_YILDIZ RT @GeographicWorld http:\/\/t.co\/YRbJrBzhpj",
  "id" : 406844430855860224,
  "in_reply_to_status_id" : 404668280041795585,
  "created_at" : "2013-11-30 17:57:25 +0000",
  "in_reply_to_screen_name" : "GeographicWorld",
  "in_reply_to_user_id_str" : "1453514216",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seeprevioustweet",
      "indices" : [ 36, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406836358888452096",
  "text" : "i feel dirty just RTing that... o-O #seeprevioustweet",
  "id" : 406836358888452096,
  "created_at" : "2013-11-30 17:25:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donovan Payton",
      "screen_name" : "dtpayton",
      "indices" : [ 3, 12 ],
      "id_str" : "798270960927436800",
      "id" : 798270960927436800
    }, {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 14, 28 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406835479460728832",
  "text" : "RT @dtpayton: @JohnFugelsang birth control is not medication, it's a safety net for morally bankrupt.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Fugelsang",
        "screen_name" : "JohnFugelsang",
        "indices" : [ 0, 14 ],
        "id_str" : "33276161",
        "id" : 33276161
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "405469294365925376",
    "geo" : { },
    "id_str" : "406822300676526080",
    "in_reply_to_user_id" : 33276161,
    "text" : "@JohnFugelsang birth control is not medication, it's a safety net for morally bankrupt.",
    "id" : 406822300676526080,
    "in_reply_to_status_id" : 405469294365925376,
    "created_at" : "2013-11-30 16:29:29 +0000",
    "in_reply_to_screen_name" : "JohnFugelsang",
    "in_reply_to_user_id_str" : "33276161",
    "user" : {
      "name" : "Truth Hammer",
      "screen_name" : "TruthHammer1",
      "protected" : false,
      "id_str" : "243450221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798266278364463106\/dMnPvOyg_normal.jpg",
      "id" : 243450221,
      "verified" : false
    }
  },
  "id" : 406835479460728832,
  "created_at" : "2013-11-30 17:21:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WTF!",
      "screen_name" : "yikesks",
      "indices" : [ 3, 11 ],
      "id_str" : "335978747",
      "id" : 335978747
    }, {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 107, 116 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/BTvrvuloTF",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/30\/1259227\/-Alan-Grayson-Offers-a-Progressive-Fix-for-the-ACA-Medicare-Buy-In",
      "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406833541717434368",
  "text" : "RT @yikesks: Alan Grayson Offers a Progressive Fix for the ACA: Medicare Buy-In http:\/\/t.co\/BTvrvuloTF via @dailykos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Kos",
        "screen_name" : "dailykos",
        "indices" : [ 94, 103 ],
        "id_str" : "20818801",
        "id" : 20818801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/BTvrvuloTF",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/30\/1259227\/-Alan-Grayson-Offers-a-Progressive-Fix-for-the-ACA-Medicare-Buy-In",
        "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406832437960777728",
    "text" : "Alan Grayson Offers a Progressive Fix for the ACA: Medicare Buy-In http:\/\/t.co\/BTvrvuloTF via @dailykos",
    "id" : 406832437960777728,
    "created_at" : "2013-11-30 17:09:46 +0000",
    "user" : {
      "name" : "WTF!",
      "screen_name" : "yikesks",
      "protected" : false,
      "id_str" : "335978747",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798617835555655680\/L3WNgmh1_normal.jpg",
      "id" : 335978747,
      "verified" : false
    }
  },
  "id" : 406833541717434368,
  "created_at" : "2013-11-30 17:14:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/406827187996598272\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Dz6uPl2D9y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVXLAoCIAA0fob.jpg",
      "id_str" : "406827188004986880",
      "id" : 406827188004986880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVXLAoCIAA0fob.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 692
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 692
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Dz6uPl2D9y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406827957559504896",
  "text" : "RT @jacqueduncalf: \"Er would you mind doing your squabbling some where else I cant ruddy see\" http:\/\/t.co\/Dz6uPl2D9y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/406827187996598272\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/Dz6uPl2D9y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVXLAoCIAA0fob.jpg",
        "id_str" : "406827188004986880",
        "id" : 406827188004986880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVXLAoCIAA0fob.jpg",
        "sizes" : [ {
          "h" : 446,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 692
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 692
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Dz6uPl2D9y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406827187996598272",
    "text" : "\"Er would you mind doing your squabbling some where else I cant ruddy see\" http:\/\/t.co\/Dz6uPl2D9y",
    "id" : 406827187996598272,
    "created_at" : "2013-11-30 16:48:54 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 406827957559504896,
  "created_at" : "2013-11-30 16:51:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 0, 14 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406827187996598272",
  "geo" : { },
  "id_str" : "406827916761104384",
  "in_reply_to_user_id" : 1963095853,
  "text" : "@jacqueduncalf LOL",
  "id" : 406827916761104384,
  "in_reply_to_status_id" : 406827187996598272,
  "created_at" : "2013-11-30 16:51:48 +0000",
  "in_reply_to_screen_name" : "jacqueduncalf",
  "in_reply_to_user_id_str" : "1963095853",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "Hobby Lobby Newsroom",
      "screen_name" : "hobbylobbystore",
      "indices" : [ 27, 43 ],
      "id_str" : "2964199984",
      "id" : 2964199984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406814661879660544",
  "geo" : { },
  "id_str" : "406823087695343616",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos creepy... @HobbyLobbyStore",
  "id" : 406823087695343616,
  "in_reply_to_status_id" : 406814661879660544,
  "created_at" : "2013-11-30 16:32:37 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "Matt Miner",
      "screen_name" : "MattMinerXVX",
      "indices" : [ 45, 58 ],
      "id_str" : "3439061",
      "id" : 3439061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406820531472580608",
  "geo" : { },
  "id_str" : "406822949207826433",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos this pleases me greatly : ) @MattMinerXVX",
  "id" : 406822949207826433,
  "in_reply_to_status_id" : 406820531472580608,
  "created_at" : "2013-11-30 16:32:04 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406816973629034496",
  "geo" : { },
  "id_str" : "406820275984928769",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits its the intention that matters",
  "id" : 406820275984928769,
  "in_reply_to_status_id" : 406816973629034496,
  "created_at" : "2013-11-30 16:21:26 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406798181260079104",
  "text" : "RT @ChrisCapparell: As far as I can tell, Potential is the light from the projector, not the wall onto which it is projected.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406794933341671425",
    "text" : "As far as I can tell, Potential is the light from the projector, not the wall onto which it is projected.",
    "id" : 406794933341671425,
    "created_at" : "2013-11-30 14:40:44 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 406798181260079104,
  "created_at" : "2013-11-30 14:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "indices" : [ 3, 15 ],
      "id_str" : "954590804",
      "id" : 954590804
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/406558452400816128\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/LPVNZEs8po",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaRiwiDIQAAxb0C.jpg",
      "id_str" : "406558452283359232",
      "id" : 406558452283359232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaRiwiDIQAAxb0C.jpg",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/LPVNZEs8po"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406798069104402432",
  "text" : "RT @planetepics: Hello, I am a giant whale, pleased to meet you! http:\/\/t.co\/LPVNZEs8po",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/406558452400816128\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/LPVNZEs8po",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaRiwiDIQAAxb0C.jpg",
        "id_str" : "406558452283359232",
        "id" : 406558452283359232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaRiwiDIQAAxb0C.jpg",
        "sizes" : [ {
          "h" : 439,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 774,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 774,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 774,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/LPVNZEs8po"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406558452400816128",
    "text" : "Hello, I am a giant whale, pleased to meet you! http:\/\/t.co\/LPVNZEs8po",
    "id" : 406558452400816128,
    "created_at" : "2013-11-29 23:01:03 +0000",
    "user" : {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "protected" : false,
      "id_str" : "954590804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463495027600015360\/_Jyj6WD6_normal.jpeg",
      "id" : 954590804,
      "verified" : false
    }
  },
  "id" : 406798069104402432,
  "created_at" : "2013-11-30 14:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hollywood Reporter",
      "screen_name" : "THR",
      "indices" : [ 3, 7 ],
      "id_str" : "17446621",
      "id" : 17446621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/M2h8joLJte",
      "expanded_url" : "http:\/\/j.mp\/IkTVty",
      "display_url" : "j.mp\/IkTVty"
    } ]
  },
  "geo" : { },
  "id_str" : "406797426851606528",
  "text" : "RT @THR: CNN's 'Blackfish' Doc Causes Barenaked Ladies to Cancel SeaWorld Gig http:\/\/t.co\/M2h8joLJte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/M2h8joLJte",
        "expanded_url" : "http:\/\/j.mp\/IkTVty",
        "display_url" : "j.mp\/IkTVty"
      } ]
    },
    "geo" : { },
    "id_str" : "406484462936281088",
    "text" : "CNN's 'Blackfish' Doc Causes Barenaked Ladies to Cancel SeaWorld Gig http:\/\/t.co\/M2h8joLJte",
    "id" : 406484462936281088,
    "created_at" : "2013-11-29 18:07:02 +0000",
    "user" : {
      "name" : "Hollywood Reporter",
      "screen_name" : "THR",
      "protected" : false,
      "id_str" : "17446621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528317230367268865\/Po8lHinI_normal.jpeg",
      "id" : 17446621,
      "verified" : true
    }
  },
  "id" : 406797426851606528,
  "created_at" : "2013-11-30 14:50:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vaccines",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "Vaccine",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "Whooping",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "Cough",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "health",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xKQe3HavCG",
      "expanded_url" : "http:\/\/bit.ly\/1bxErie",
      "display_url" : "bit.ly\/1bxErie"
    } ]
  },
  "geo" : { },
  "id_str" : "406796991528968193",
  "text" : "RT @drbloem: Study Proves #Vaccines, Not #Vaccine Refusers Are Behind #Whooping #Cough Outbreaks #health http:\/\/t.co\/xKQe3HavCG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vaccines",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "Vaccine",
        "indices" : [ 28, 36 ]
      }, {
        "text" : "Whooping",
        "indices" : [ 57, 66 ]
      }, {
        "text" : "Cough",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "health",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/xKQe3HavCG",
        "expanded_url" : "http:\/\/bit.ly\/1bxErie",
        "display_url" : "bit.ly\/1bxErie"
      } ]
    },
    "geo" : { },
    "id_str" : "406793310469378049",
    "text" : "Study Proves #Vaccines, Not #Vaccine Refusers Are Behind #Whooping #Cough Outbreaks #health http:\/\/t.co\/xKQe3HavCG",
    "id" : 406793310469378049,
    "created_at" : "2013-11-30 14:34:17 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 406796991528968193,
  "created_at" : "2013-11-30 14:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    }, {
      "name" : "Honor",
      "screen_name" : "zenmommaNgrimes",
      "indices" : [ 16, 32 ],
      "id_str" : "440433547",
      "id" : 440433547
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zenmommaNgrimes\/status\/402513058469523456\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/5uDnxTAHHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZYDfm1IIAEuvXU.png",
      "id_str" : "402513058230444033",
      "id" : 402513058230444033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZYDfm1IIAEuvXU.png",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5uDnxTAHHb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406794921115660288",
  "text" : "RT @drbloem: RT @zenmommaNgrimes: Corruption... http:\/\/t.co\/5uDnxTAHHb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Honor",
        "screen_name" : "zenmommaNgrimes",
        "indices" : [ 3, 19 ],
        "id_str" : "440433547",
        "id" : 440433547
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zenmommaNgrimes\/status\/402513058469523456\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/5uDnxTAHHb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZYDfm1IIAEuvXU.png",
        "id_str" : "402513058230444033",
        "id" : 402513058230444033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZYDfm1IIAEuvXU.png",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5uDnxTAHHb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 39.1390559, -77.0827389 ]
    },
    "id_str" : "406787328800460800",
    "text" : "RT @zenmommaNgrimes: Corruption... http:\/\/t.co\/5uDnxTAHHb",
    "id" : 406787328800460800,
    "created_at" : "2013-11-30 14:10:31 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 406794921115660288,
  "created_at" : "2013-11-30 14:40:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/UygCkJuCcb",
      "expanded_url" : "http:\/\/vaxtruth.org\/2012\/01\/kaylynne-matten-cause-of-death-undetermined-parents-believe-flu-vaccine-killed-their-7-year-old-daughter\/",
      "display_url" : "vaxtruth.org\/2012\/01\/kaylyn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406794597801553920",
  "text" : "interesting article re immune system &gt; Parents Believe Flu Vaccine Killed Their 7 Year-Old Daughter. http:\/\/t.co\/UygCkJuCcb",
  "id" : 406794597801553920,
  "created_at" : "2013-11-30 14:39:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Death",
      "indices" : [ 13, 19 ]
    }, {
      "text" : "FluShot",
      "indices" : [ 23, 31 ]
    }, {
      "text" : "Vaccine",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "health",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/i4hDOVEuUF",
      "expanded_url" : "http:\/\/bit.ly\/1aymgoS",
      "display_url" : "bit.ly\/1aymgoS"
    } ]
  },
  "geo" : { },
  "id_str" : "406794208813809665",
  "text" : "RT @drbloem: #Death by #FluShot - 7 Year-Old Receives Flu #Vaccine; Dies 4 Days Later #health http:\/\/t.co\/i4hDOVEuUF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Death",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "FluShot",
        "indices" : [ 10, 18 ]
      }, {
        "text" : "Vaccine",
        "indices" : [ 45, 53 ]
      }, {
        "text" : "health",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/i4hDOVEuUF",
        "expanded_url" : "http:\/\/bit.ly\/1aymgoS",
        "display_url" : "bit.ly\/1aymgoS"
      } ]
    },
    "geo" : { },
    "id_str" : "406788258631528448",
    "text" : "#Death by #FluShot - 7 Year-Old Receives Flu #Vaccine; Dies 4 Days Later #health http:\/\/t.co\/i4hDOVEuUF",
    "id" : 406788258631528448,
    "created_at" : "2013-11-30 14:14:13 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 406794208813809665,
  "created_at" : "2013-11-30 14:37:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406788919725129728",
  "text" : "RT @ChrisCapparell: And when one's clothes fit perfectly, they cease to exist, and even the very concept of nudity is forgotten once again.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406653380354768896",
    "text" : "And when one's clothes fit perfectly, they cease to exist, and even the very concept of nudity is forgotten once again.",
    "id" : 406653380354768896,
    "created_at" : "2013-11-30 05:18:15 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 406788919725129728,
  "created_at" : "2013-11-30 14:16:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Min",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406786684064657408",
  "text" : "RT @InvisCollege: Heaven is in the heart and hell in the head and free will is the vehicle that can take you to either. #Min",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Min",
        "indices" : [ 102, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406772668864544770",
    "text" : "Heaven is in the heart and hell in the head and free will is the vehicle that can take you to either. #Min",
    "id" : 406772668864544770,
    "created_at" : "2013-11-30 13:12:16 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 406786684064657408,
  "created_at" : "2013-11-30 14:07:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "indices" : [ 3, 15 ],
      "id_str" : "38205414",
      "id" : 38205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406784950147756032",
  "text" : "RT @marcuschown: The Sun. Taken at night. Not looking up at the sky but down through 8000 miles of rock. Not with light but neutrinos. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marcuschown\/status\/282614370180161536\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/pJGGXtny",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-wMRbeCYAAvA3h.jpg",
        "id_str" : "282614370188550144",
        "id" : 282614370188550144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-wMRbeCYAAvA3h.jpg",
        "sizes" : [ {
          "h" : 529,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pJGGXtny"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406550975680630784",
    "text" : "The Sun. Taken at night. Not looking up at the sky but down through 8000 miles of rock. Not with light but neutrinos. http:\/\/t.co\/pJGGXtny",
    "id" : 406550975680630784,
    "created_at" : "2013-11-29 22:31:20 +0000",
    "user" : {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "protected" : false,
      "id_str" : "38205414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681518625090580480\/BJUBjRiS_normal.jpg",
      "id" : 38205414,
      "verified" : false
    }
  },
  "id" : 406784950147756032,
  "created_at" : "2013-11-30 14:01:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vlh",
      "screen_name" : "coton_luver",
      "indices" : [ 3, 15 ],
      "id_str" : "545474475",
      "id" : 545474475
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GrandOldParody1\/status\/394152513072803840\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/0j4hUMYa8Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXhPn0tIAAAQ6bu.jpg",
      "id_str" : "394152512976322560",
      "id" : 394152512976322560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXhPn0tIAAAQ6bu.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 876
      } ],
      "display_url" : "pic.twitter.com\/0j4hUMYa8Y"
    } ],
    "hashtags" : [ {
      "text" : "uppers",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406782956888686592",
  "text" : "RT @coton_luver: \"#uppers Where your 2012 \"Federal Income Taxes\" went. So clearly, we need to cut food stamps. http:\/\/t.co\/0j4hUMYa8Y\" @Gra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grand Old Parody",
        "screen_name" : "GrandOldParody1",
        "indices" : [ 118, 134 ],
        "id_str" : "1437267764",
        "id" : 1437267764
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GrandOldParody1\/status\/394152513072803840\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/0j4hUMYa8Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXhPn0tIAAAQ6bu.jpg",
        "id_str" : "394152512976322560",
        "id" : 394152512976322560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXhPn0tIAAAQ6bu.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 876
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 876
        } ],
        "display_url" : "pic.twitter.com\/0j4hUMYa8Y"
      } ],
      "hashtags" : [ {
        "text" : "uppers",
        "indices" : [ 1, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404256346683346944",
    "text" : "\"#uppers Where your 2012 \"Federal Income Taxes\" went. So clearly, we need to cut food stamps. http:\/\/t.co\/0j4hUMYa8Y\" @GrandOldParody1\"\"",
    "id" : 404256346683346944,
    "created_at" : "2013-11-23 14:33:18 +0000",
    "user" : {
      "name" : "vlh",
      "screen_name" : "coton_luver",
      "protected" : false,
      "id_str" : "545474475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800451880392409088\/oRzX3kvx_normal.jpg",
      "id" : 545474475,
      "verified" : false
    }
  },
  "id" : 406782956888686592,
  "created_at" : "2013-11-30 13:53:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "indices" : [ 3, 14 ],
      "id_str" : "16042794",
      "id" : 16042794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406597243526213632",
  "text" : "RT @GuardianUS: Fees on government issued prepaid cards are not just an annoyance, but money that could have gone towards food http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/CZUgbUsam7",
        "expanded_url" : "http:\/\/trib.al\/f5Jh6Tw",
        "display_url" : "trib.al\/f5Jh6Tw"
      } ]
    },
    "geo" : { },
    "id_str" : "406595953068879872",
    "text" : "Fees on government issued prepaid cards are not just an annoyance, but money that could have gone towards food http:\/\/t.co\/CZUgbUsam7",
    "id" : 406595953068879872,
    "created_at" : "2013-11-30 01:30:04 +0000",
    "user" : {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "protected" : false,
      "id_str" : "16042794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743073930827698176\/MawT7psS_normal.jpg",
      "id" : 16042794,
      "verified" : true
    }
  },
  "id" : 406597243526213632,
  "created_at" : "2013-11-30 01:35:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "indices" : [ 2, 10 ],
      "id_str" : "8192222",
      "id" : 8192222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406489610307780608",
  "geo" : { },
  "id_str" : "406511819071582208",
  "in_reply_to_user_id" : 8192222,
  "text" : ". @Jezebel perhaps she is ill and might not have another thanksgiving with her family.. sure, she acted like a jerk but elan was jerkier.",
  "id" : 406511819071582208,
  "in_reply_to_status_id" : 406489610307780608,
  "created_at" : "2013-11-29 19:55:44 +0000",
  "in_reply_to_screen_name" : "Jezebel",
  "in_reply_to_user_id_str" : "8192222",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TMD",
      "indices" : [ 77, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406489436017278976",
  "text" : "my left jaw is still sore and making my ear sore as well, also twinges. ugh. #TMD ?",
  "id" : 406489436017278976,
  "created_at" : "2013-11-29 18:26:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSGV",
      "screen_name" : "CSGV",
      "indices" : [ 3, 8 ],
      "id_str" : "33256849",
      "id" : 33256849
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GA",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406479365439250432",
  "text" : "RT @CSGV: Unarmed 72 y\/o Man with Alzheimer's Shot, Killed in #GA. No Charges Filed Under State's \"Stand Your Ground\" Law http:\/\/t.co\/r86Sr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GA",
        "indices" : [ 52, 55 ]
      }, {
        "text" : "p2",
        "indices" : [ 135, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/r86SrUOwTY",
        "expanded_url" : "http:\/\/www.timesfreepress.com\/news\/2013\/nov\/28\/wandering-man-with-alzheimers-shot-killed\/",
        "display_url" : "timesfreepress.com\/news\/2013\/nov\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406475043510579201",
    "text" : "Unarmed 72 y\/o Man with Alzheimer's Shot, Killed in #GA. No Charges Filed Under State's \"Stand Your Ground\" Law http:\/\/t.co\/r86SrUOwTY #p2",
    "id" : 406475043510579201,
    "created_at" : "2013-11-29 17:29:36 +0000",
    "user" : {
      "name" : "CSGV",
      "screen_name" : "CSGV",
      "protected" : false,
      "id_str" : "33256849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739821044572250112\/Xdu2V_dB_normal.jpg",
      "id" : 33256849,
      "verified" : true
    }
  },
  "id" : 406479365439250432,
  "created_at" : "2013-11-29 17:46:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "indices" : [ 0, 14 ],
      "id_str" : "255780065",
      "id" : 255780065
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cats",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406475242878427136",
  "geo" : { },
  "id_str" : "406476891390877696",
  "in_reply_to_user_id" : 255780065,
  "text" : "@Crowtographer LOL #cats",
  "id" : 406476891390877696,
  "in_reply_to_status_id" : 406475242878427136,
  "created_at" : "2013-11-29 17:36:57 +0000",
  "in_reply_to_screen_name" : "Crowtographer",
  "in_reply_to_user_id_str" : "255780065",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406458200293376000",
  "text" : "RT @knittingknots: Fox Business host Stuart Varney weighs in on the Pope, suddenly hates religion mixed with politics -  http:\/\/t.co\/LXyKfK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/LXyKfK19fZ",
        "expanded_url" : "http:\/\/freakoutnation.com\/2013\/11\/27\/fox-business-host-stuart-varney-weighs-in-on-the-pope-suddenly-hates-religion-mixed-with-politics\/",
        "display_url" : "freakoutnation.com\/2013\/11\/27\/fox\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406457700600410112",
    "text" : "Fox Business host Stuart Varney weighs in on the Pope, suddenly hates religion mixed with politics -  http:\/\/t.co\/LXyKfK19fZ",
    "id" : 406457700600410112,
    "created_at" : "2013-11-29 16:20:42 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 406458200293376000,
  "created_at" : "2013-11-29 16:22:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/JejdYu79t8",
      "expanded_url" : "http:\/\/goo.gl\/2UHO4M",
      "display_url" : "goo.gl\/2UHO4M"
    } ]
  },
  "geo" : { },
  "id_str" : "406083500002263040",
  "text" : "RT @dailygalaxy: New Star System Similar to Ours Discovered --\u201CWe Cannot Stress Just How Important This Is\"  http:\/\/t.co\/JejdYu79t8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/JejdYu79t8",
        "expanded_url" : "http:\/\/goo.gl\/2UHO4M",
        "display_url" : "goo.gl\/2UHO4M"
      } ]
    },
    "geo" : { },
    "id_str" : "406081585205612544",
    "text" : "New Star System Similar to Ours Discovered --\u201CWe Cannot Stress Just How Important This Is\"  http:\/\/t.co\/JejdYu79t8",
    "id" : 406081585205612544,
    "created_at" : "2013-11-28 15:26:09 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 406083500002263040,
  "created_at" : "2013-11-28 15:33:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley Wx",
      "screen_name" : "HudsonValleyWx",
      "indices" : [ 3, 18 ],
      "id_str" : "349189238",
      "id" : 349189238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406081149182955520",
  "text" : "RT @HudsonValleyWx: There was once a kid who from about 7 years old loved the weather. This kid was obsessed, would rather watch the... htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/YOggcCuqUd",
        "expanded_url" : "http:\/\/fb.me\/2XQImzKCf",
        "display_url" : "fb.me\/2XQImzKCf"
      } ]
    },
    "geo" : { },
    "id_str" : "406079639472193536",
    "text" : "There was once a kid who from about 7 years old loved the weather. This kid was obsessed, would rather watch the... http:\/\/t.co\/YOggcCuqUd",
    "id" : 406079639472193536,
    "created_at" : "2013-11-28 15:18:25 +0000",
    "user" : {
      "name" : "Hudson Valley Wx",
      "screen_name" : "HudsonValleyWx",
      "protected" : false,
      "id_str" : "349189238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000705307925\/ac8e9f1c9fb5a95c6eb54a9b38d09ff7_normal.jpeg",
      "id" : 349189238,
      "verified" : false
    }
  },
  "id" : 406081149182955520,
  "created_at" : "2013-11-28 15:24:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Griffith",
      "screen_name" : "TarotHeals",
      "indices" : [ 3, 14 ],
      "id_str" : "35105327",
      "id" : 35105327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qws26KDbIH",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/377950593699915084\/",
      "display_url" : "pinterest.com\/pin\/3779505936\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406075320463552512",
  "text" : "RT @TarotHeals: 11+28+2013=9 Hermit Today you may want to hide out, but remember.... A hermit is asked to shine his  http:\/\/t.co\/qws26KDbIH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pinterest.com\" rel=\"nofollow\"\u003EPinterest\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/qws26KDbIH",
        "expanded_url" : "http:\/\/pinterest.com\/pin\/377950593699915084\/",
        "display_url" : "pinterest.com\/pin\/3779505936\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406074861174661120",
    "text" : "11+28+2013=9 Hermit Today you may want to hide out, but remember.... A hermit is asked to shine his  http:\/\/t.co\/qws26KDbIH",
    "id" : 406074861174661120,
    "created_at" : "2013-11-28 14:59:26 +0000",
    "user" : {
      "name" : "Cindy Griffith",
      "screen_name" : "TarotHeals",
      "protected" : false,
      "id_str" : "35105327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603941015423217664\/jeP-h5xH_normal.jpg",
      "id" : 35105327,
      "verified" : false
    }
  },
  "id" : 406075320463552512,
  "created_at" : "2013-11-28 15:01:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406071459639869440",
  "text" : "carrie underwood in the sound of music.. uhh, NO.",
  "id" : 406071459639869440,
  "created_at" : "2013-11-28 14:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406070722327347202",
  "text" : "lola and the kinky boots on macy's parade.. im sure we'll hear about that from the america is going to hell crowd...",
  "id" : 406070722327347202,
  "created_at" : "2013-11-28 14:42:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howlin' Mad Herrmann",
      "screen_name" : "ThatJoeHerrmann",
      "indices" : [ 3, 19 ],
      "id_str" : "369532697",
      "id" : 369532697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405866572491005953",
  "text" : "RT @ThatJoeHerrmann: Remember: If you camp out for a tv, you're a good consumer. If you camp out for social justice, you're a dirty hippie \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405412426717614080",
    "text" : "Remember: If you camp out for a tv, you're a good consumer. If you camp out for social justice, you're a dirty hippie and will be maced.",
    "id" : 405412426717614080,
    "created_at" : "2013-11-26 19:07:09 +0000",
    "user" : {
      "name" : "Howlin' Mad Herrmann",
      "screen_name" : "ThatJoeHerrmann",
      "protected" : false,
      "id_str" : "369532697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798290801818238976\/8BQhEVtt_normal.jpg",
      "id" : 369532697,
      "verified" : false
    }
  },
  "id" : 405866572491005953,
  "created_at" : "2013-11-28 01:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PocahontasB Wolf",
      "screen_name" : "OleHippieChick",
      "indices" : [ 3, 18 ],
      "id_str" : "256510253",
      "id" : 256510253
    }, {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 107, 116 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Germany",
      "indices" : [ 20, 28 ]
    }, {
      "text" : "KT2",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/dyRE1W5l5t",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/27\/1258730\/-Germany-Introduces-Minimum-Wage-lowers-retirement-age",
      "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405861628295786496",
  "text" : "RT @OleHippieChick: #Germany sets Minimum Wage at $11.54, lowers retirement age http:\/\/t.co\/dyRE1W5l5t via @dailykos #KT2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Kos",
        "screen_name" : "dailykos",
        "indices" : [ 87, 96 ],
        "id_str" : "20818801",
        "id" : 20818801
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Germany",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "KT2",
        "indices" : [ 97, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/dyRE1W5l5t",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/27\/1258730\/-Germany-Introduces-Minimum-Wage-lowers-retirement-age",
        "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405806690076856320",
    "text" : "#Germany sets Minimum Wage at $11.54, lowers retirement age http:\/\/t.co\/dyRE1W5l5t via @dailykos #KT2",
    "id" : 405806690076856320,
    "created_at" : "2013-11-27 21:13:49 +0000",
    "user" : {
      "name" : "PocahontasB Wolf",
      "screen_name" : "OleHippieChick",
      "protected" : false,
      "id_str" : "256510253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1727544047\/Jump__you_fuckers__normal.jpg",
      "id" : 256510253,
      "verified" : false
    }
  },
  "id" : 405861628295786496,
  "created_at" : "2013-11-28 00:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405847352814370816",
  "text" : "RT @bunnybuddhism: We only see the carrots we are ready to see.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405842347713642496",
    "text" : "We only see the carrots we are ready to see.",
    "id" : 405842347713642496,
    "created_at" : "2013-11-27 23:35:30 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 405847352814370816,
  "created_at" : "2013-11-27 23:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "indices" : [ 27, 36 ],
      "id_str" : "19636553",
      "id" : 19636553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405847222610571265",
  "text" : "RT @CoyoteSings: Awwww! RT @LunaJune: I have a little sparrow under my awning, my christmas lights bother her when she sleeps so I have to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "June O'Reilly",
        "screen_name" : "LunaJune",
        "indices" : [ 10, 19 ],
        "id_str" : "19636553",
        "id" : 19636553
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405842545638248448",
    "text" : "Awwww! RT @LunaJune: I have a little sparrow under my awning, my christmas lights bother her when she sleeps so I have to turn them off",
    "id" : 405842545638248448,
    "created_at" : "2013-11-27 23:36:17 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 405847222610571265,
  "created_at" : "2013-11-27 23:54:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u269Cdenisebourassa\u269C",
      "screen_name" : "denise_bourassa",
      "indices" : [ 3, 19 ],
      "id_str" : "989456820",
      "id" : 989456820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/denise_bourassa\/status\/405820201004175360\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/8KAIBlrA2J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaHDUpJIEAAdT8V.jpg",
      "id_str" : "405820200848986112",
      "id" : 405820200848986112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaHDUpJIEAAdT8V.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8KAIBlrA2J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405821125231644672",
  "text" : "RT @denise_bourassa: http:\/\/t.co\/8KAIBlrA2J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/denise_bourassa\/status\/405820201004175360\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/8KAIBlrA2J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaHDUpJIEAAdT8V.jpg",
        "id_str" : "405820200848986112",
        "id" : 405820200848986112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaHDUpJIEAAdT8V.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8KAIBlrA2J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405820201004175360",
    "text" : "http:\/\/t.co\/8KAIBlrA2J",
    "id" : 405820201004175360,
    "created_at" : "2013-11-27 22:07:30 +0000",
    "user" : {
      "name" : "\u269Cdenisebourassa\u269C",
      "screen_name" : "denise_bourassa",
      "protected" : false,
      "id_str" : "989456820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796521376387657728\/an2TElGA_normal.jpg",
      "id" : 989456820,
      "verified" : false
    }
  },
  "id" : 405821125231644672,
  "created_at" : "2013-11-27 22:11:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron T",
      "screen_name" : "AaronsNotes",
      "indices" : [ 3, 15 ],
      "id_str" : "69414105",
      "id" : 69414105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405808220046127104",
  "text" : "RT @AaronsNotes: To improve state exchanges created under Obamacare, states should follow suit w\/VT and create single-payer health insuranc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405787710498959360",
    "text" : "To improve state exchanges created under Obamacare, states should follow suit w\/VT and create single-payer health insurance systems.",
    "id" : 405787710498959360,
    "created_at" : "2013-11-27 19:58:24 +0000",
    "user" : {
      "name" : "Aaron T",
      "screen_name" : "AaronsNotes",
      "protected" : false,
      "id_str" : "69414105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597976322732728320\/GrHUf_ZF_normal.jpg",
      "id" : 69414105,
      "verified" : false
    }
  },
  "id" : 405808220046127104,
  "created_at" : "2013-11-27 21:19:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Chapman",
      "screen_name" : "fawfulfan",
      "indices" : [ 3, 13 ],
      "id_str" : "716813053",
      "id" : 716813053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405808127347814400",
  "text" : "RT @fawfulfan: @thegreatbobo @AllOnMedicare no, you have maximum choice in single-payer. You have universal choice of your hospital and doc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 14, 28 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.4474813716, -71.3951881954 ]
    },
    "id_str" : "405777300534620160",
    "text" : "@thegreatbobo @AllOnMedicare no, you have maximum choice in single-payer. You have universal choice of your hospital and doctor.",
    "id" : 405777300534620160,
    "created_at" : "2013-11-27 19:17:02 +0000",
    "user" : {
      "name" : "Matthew Chapman",
      "screen_name" : "fawfulfan",
      "protected" : false,
      "id_str" : "716813053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702270242974642176\/DsEg0u6e_normal.jpg",
      "id" : 716813053,
      "verified" : false
    }
  },
  "id" : 405808127347814400,
  "created_at" : "2013-11-27 21:19:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Chapman",
      "screen_name" : "fawfulfan",
      "indices" : [ 3, 13 ],
      "id_str" : "716813053",
      "id" : 716813053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405808005218058241",
  "text" : "RT @fawfulfan: @thegreatbobo @AllOnMedicare in single-payer countries, ANY doctor with a medical license is \"govt-approved\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 14, 28 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.447491549, -71.3952151593 ]
    },
    "id_str" : "405778774077489152",
    "text" : "@thegreatbobo @AllOnMedicare in single-payer countries, ANY doctor with a medical license is \"govt-approved\".",
    "id" : 405778774077489152,
    "created_at" : "2013-11-27 19:22:53 +0000",
    "user" : {
      "name" : "Matthew Chapman",
      "screen_name" : "fawfulfan",
      "protected" : false,
      "id_str" : "716813053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702270242974642176\/DsEg0u6e_normal.jpg",
      "id" : 716813053,
      "verified" : false
    }
  },
  "id" : 405808005218058241,
  "created_at" : "2013-11-27 21:19:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Chapman",
      "screen_name" : "fawfulfan",
      "indices" : [ 3, 13 ],
      "id_str" : "716813053",
      "id" : 716813053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405807948460736512",
  "text" : "RT @fawfulfan: @thegreatbobo @AllOnMedicare hospitals and doctors remain private under many single-payer setups. Insurance is socialized, n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 14, 28 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.4474743007, -71.3951996198 ]
    },
    "id_str" : "405779750087831552",
    "text" : "@thegreatbobo @AllOnMedicare hospitals and doctors remain private under many single-payer setups. Insurance is socialized, not care itself.",
    "id" : 405779750087831552,
    "created_at" : "2013-11-27 19:26:46 +0000",
    "user" : {
      "name" : "Matthew Chapman",
      "screen_name" : "fawfulfan",
      "protected" : false,
      "id_str" : "716813053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702270242974642176\/DsEg0u6e_normal.jpg",
      "id" : 716813053,
      "verified" : false
    }
  },
  "id" : 405807948460736512,
  "created_at" : "2013-11-27 21:18:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405805549582680064",
  "geo" : { },
  "id_str" : "405806498816618496",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves you, too, Dwayne. Hope your daughter is doing well.",
  "id" : 405806498816618496,
  "in_reply_to_status_id" : 405805549582680064,
  "created_at" : "2013-11-27 21:13:03 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Jeff",
      "screen_name" : "HumourousRace",
      "indices" : [ 17, 31 ],
      "id_str" : "1064074980",
      "id" : 1064074980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405734850021588993",
  "text" : "RT @Floridaline: @HumourousRace Hell is a barbaric doctrine, Jeff. No human deserves eternal torment. Thank goodness, it's a myth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff",
        "screen_name" : "HumourousRace",
        "indices" : [ 0, 14 ],
        "id_str" : "1064074980",
        "id" : 1064074980
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "405724792558342144",
    "geo" : { },
    "id_str" : "405727402514345984",
    "in_reply_to_user_id" : 1064074980,
    "text" : "@HumourousRace Hell is a barbaric doctrine, Jeff. No human deserves eternal torment. Thank goodness, it's a myth.",
    "id" : 405727402514345984,
    "in_reply_to_status_id" : 405724792558342144,
    "created_at" : "2013-11-27 15:58:45 +0000",
    "in_reply_to_screen_name" : "HumourousRace",
    "in_reply_to_user_id_str" : "1064074980",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 405734850021588993,
  "created_at" : "2013-11-27 16:28:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/6qJO9S5n2B",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/24\/1258135\/-Obama-just-launched-single-payer-in-America",
      "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405500141055922176",
  "text" : "Obama just launched single-payer in America http:\/\/t.co\/6qJO9S5n2B",
  "id" : 405500141055922176,
  "created_at" : "2013-11-27 00:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405498123390156800",
  "geo" : { },
  "id_str" : "405499024737697792",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth ((hugs)) im sorry",
  "id" : 405499024737697792,
  "in_reply_to_status_id" : 405498123390156800,
  "created_at" : "2013-11-27 00:51:15 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "indices" : [ 3, 16 ],
      "id_str" : "8659362",
      "id" : 8659362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CuteOverload\/status\/405463012263198720\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/pBu9eieGRF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaB-dhuCQAA2Unn.jpg",
      "id_str" : "405463012196106240",
      "id" : 405463012196106240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaB-dhuCQAA2Unn.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 645
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 645
      } ],
      "display_url" : "pic.twitter.com\/pBu9eieGRF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/5rmgSjErat",
      "expanded_url" : "http:\/\/bit.ly\/Ih2FAC",
      "display_url" : "bit.ly\/Ih2FAC"
    } ]
  },
  "geo" : { },
  "id_str" : "405466287360311296",
  "text" : "RT @CuteOverload: Prison inmates get rescue cats ready for adoption: \nhttp:\/\/t.co\/5rmgSjErat http:\/\/t.co\/pBu9eieGRF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CuteOverload\/status\/405463012263198720\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/pBu9eieGRF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaB-dhuCQAA2Unn.jpg",
        "id_str" : "405463012196106240",
        "id" : 405463012196106240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaB-dhuCQAA2Unn.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 645
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 645
        } ],
        "display_url" : "pic.twitter.com\/pBu9eieGRF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5rmgSjErat",
        "expanded_url" : "http:\/\/bit.ly\/Ih2FAC",
        "display_url" : "bit.ly\/Ih2FAC"
      } ]
    },
    "geo" : { },
    "id_str" : "405463012263198720",
    "text" : "Prison inmates get rescue cats ready for adoption: \nhttp:\/\/t.co\/5rmgSjErat http:\/\/t.co\/pBu9eieGRF",
    "id" : 405463012263198720,
    "created_at" : "2013-11-26 22:28:09 +0000",
    "user" : {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "protected" : false,
      "id_str" : "8659362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680609450495873025\/0RV8NzVo_normal.png",
      "id" : 8659362,
      "verified" : false
    }
  },
  "id" : 405466287360311296,
  "created_at" : "2013-11-26 22:41:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Wentzel",
      "screen_name" : "danwentzel",
      "indices" : [ 3, 14 ],
      "id_str" : "77012285",
      "id" : 77012285
    }, {
      "name" : "California OneCare",
      "screen_name" : "CAOneCare",
      "indices" : [ 128, 138 ],
      "id_str" : "38363816",
      "id" : 38363816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405454125539680256",
  "text" : "RT @danwentzel: ACA gives any state the ability to go #singlepayer by 2017 as Vermont is doing.  California needs single-payer. @CAOneCare \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "California OneCare",
        "screen_name" : "CAOneCare",
        "indices" : [ 112, 122 ],
        "id_str" : "38363816",
        "id" : 38363816
      }, {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 123, 137 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 38, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405446084014534656",
    "text" : "ACA gives any state the ability to go #singlepayer by 2017 as Vermont is doing.  California needs single-payer. @CAOneCare @AllOnMedicare",
    "id" : 405446084014534656,
    "created_at" : "2013-11-26 21:20:53 +0000",
    "user" : {
      "name" : "Dan Wentzel",
      "screen_name" : "danwentzel",
      "protected" : false,
      "id_str" : "77012285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708344086231527428\/Ufk2YFZX_normal.jpg",
      "id" : 77012285,
      "verified" : false
    }
  },
  "id" : 405454125539680256,
  "created_at" : "2013-11-26 21:52:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "indices" : [ 3, 17 ],
      "id_str" : "23372297",
      "id" : 23372297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405453267162775552",
  "text" : "RT @LorenzoTheCat: Pope Francis is sounding a lot like his animal-loving namesake and that's a good thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405439437300961280",
    "text" : "Pope Francis is sounding a lot like his animal-loving namesake and that's a good thing.",
    "id" : 405439437300961280,
    "created_at" : "2013-11-26 20:54:29 +0000",
    "user" : {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "protected" : false,
      "id_str" : "23372297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1047336743\/Marked-Americana_normal.jpg",
      "id" : 23372297,
      "verified" : true
    }
  },
  "id" : 405453267162775552,
  "created_at" : "2013-11-26 21:49:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 61, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/UWxA9hWXE5",
      "expanded_url" : "http:\/\/www.ustream.tv\/recorded\/41139226",
      "display_url" : "ustream.tv\/recorded\/41139\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405447968053940225",
  "text" : "\"Kindness covers all of my political beliefs.\" - Roger Ebert #Obama 27:15 http:\/\/t.co\/UWxA9hWXE5",
  "id" : 405447968053940225,
  "created_at" : "2013-11-26 21:28:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Hartmann",
      "screen_name" : "Thom_Hartmann",
      "indices" : [ 3, 17 ],
      "id_str" : "21414576",
      "id" : 21414576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "money",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/kYmnD1d9wh",
      "expanded_url" : "http:\/\/ow.ly\/rcT4U",
      "display_url" : "ow.ly\/rcT4U"
    } ]
  },
  "geo" : { },
  "id_str" : "405431417418444800",
  "text" : "RT @Thom_Hartmann: A Basic Income is Not a Crazy Idea #money http:\/\/t.co\/kYmnD1d9wh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "money",
        "indices" : [ 35, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/kYmnD1d9wh",
        "expanded_url" : "http:\/\/ow.ly\/rcT4U",
        "display_url" : "ow.ly\/rcT4U"
      } ]
    },
    "geo" : { },
    "id_str" : "405422227564134400",
    "text" : "A Basic Income is Not a Crazy Idea #money http:\/\/t.co\/kYmnD1d9wh",
    "id" : 405422227564134400,
    "created_at" : "2013-11-26 19:46:06 +0000",
    "user" : {
      "name" : "Thom Hartmann",
      "screen_name" : "Thom_Hartmann",
      "protected" : false,
      "id_str" : "21414576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1284920980\/thom-2011-150_normal.jpg",
      "id" : 21414576,
      "verified" : true
    }
  },
  "id" : 405431417418444800,
  "created_at" : "2013-11-26 20:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pOLYCGqp4W",
      "expanded_url" : "http:\/\/www.eclectablog.com\/2013\/11\/michigan-about-to-require-women-to-buy-rape-insurance-based-on-petition-signed-by-4-2-of-voters.html",
      "display_url" : "eclectablog.com\/2013\/11\/michig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405429743987605505",
  "text" : "RT @Floridaline: Michigan about to require women to buy \"rape insurance\" based on petition signed by 4.2% of voters: http:\/\/t.co\/pOLYCGqp4W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/pOLYCGqp4W",
        "expanded_url" : "http:\/\/www.eclectablog.com\/2013\/11\/michigan-about-to-require-women-to-buy-rape-insurance-based-on-petition-signed-by-4-2-of-voters.html",
        "display_url" : "eclectablog.com\/2013\/11\/michig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405408902168064001",
    "text" : "Michigan about to require women to buy \"rape insurance\" based on petition signed by 4.2% of voters: http:\/\/t.co\/pOLYCGqp4W",
    "id" : 405408902168064001,
    "created_at" : "2013-11-26 18:53:09 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 405429743987605505,
  "created_at" : "2013-11-26 20:15:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "indices" : [ 3, 19 ],
      "id_str" : "829603410",
      "id" : 829603410
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Fifthcolumnblue\/status\/405411591836803072\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Kck2z0vAhO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaBPsd_CIAE7UX1.jpg",
      "id_str" : "405411591845191681",
      "id" : 405411591845191681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaBPsd_CIAE7UX1.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 319
      } ],
      "display_url" : "pic.twitter.com\/Kck2z0vAhO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405424396711370752",
  "text" : "RT @Fifthcolumnblue: Making us pay: http:\/\/t.co\/Kck2z0vAhO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fifthcolumnblue\/status\/405411591836803072\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/Kck2z0vAhO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaBPsd_CIAE7UX1.jpg",
        "id_str" : "405411591845191681",
        "id" : 405411591845191681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaBPsd_CIAE7UX1.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 319
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 319
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 319
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 319
        } ],
        "display_url" : "pic.twitter.com\/Kck2z0vAhO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405411591836803072",
    "text" : "Making us pay: http:\/\/t.co\/Kck2z0vAhO",
    "id" : 405411591836803072,
    "created_at" : "2013-11-26 19:03:50 +0000",
    "user" : {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "protected" : false,
      "id_str" : "829603410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796277104707047424\/MgURyKNE_normal.jpg",
      "id" : 829603410,
      "verified" : false
    }
  },
  "id" : 405424396711370752,
  "created_at" : "2013-11-26 19:54:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405403213933068289",
  "text" : "RT @rachelheldevans: Conservative readers, plase help me understand this: 2 questions regarding the HHS mandate and religious liberty http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PtUjOTdMzY",
        "expanded_url" : "http:\/\/buff.ly\/1cqYbAO",
        "display_url" : "buff.ly\/1cqYbAO"
      } ]
    },
    "geo" : { },
    "id_str" : "405401616729509889",
    "text" : "Conservative readers, plase help me understand this: 2 questions regarding the HHS mandate and religious liberty http:\/\/t.co\/PtUjOTdMzY",
    "id" : 405401616729509889,
    "created_at" : "2013-11-26 18:24:12 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 405403213933068289,
  "created_at" : "2013-11-26 18:30:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405395930830344192",
  "text" : "RT @rachelheldevans: Re: HHS mandate: If Christian employers can refuse to cover birth control, could Jehovah's Witnesses refuse to cover b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405393997671047168",
    "text" : "Re: HHS mandate: If Christian employers can refuse to cover birth control, could Jehovah's Witnesses refuse to cover blood transfusions?",
    "id" : 405393997671047168,
    "created_at" : "2013-11-26 17:53:55 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 405395930830344192,
  "created_at" : "2013-11-26 18:01:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Read",
      "screen_name" : "Read4Congress",
      "indices" : [ 3, 17 ],
      "id_str" : "2154899852",
      "id" : 2154899852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Read4Congress\/status\/400877623753973760\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/CXz6BOXDwD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZA0EyrCIAEpG5e.png",
      "id_str" : "400877623762362369",
      "id" : 400877623762362369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZA0EyrCIAEpG5e.png",
      "sizes" : [ {
        "h" : 533,
        "resize" : "fit",
        "w" : 796
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 796
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CXz6BOXDwD"
    } ],
    "hashtags" : [ {
      "text" : "MN06",
      "indices" : [ 60, 65 ]
    }, {
      "text" : "mnleg",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405394844102975488",
  "text" : "RT @Read4Congress: \"... No. We're not going back to that.\"  #MN06 #mnleg http:\/\/t.co\/CXz6BOXDwD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Read4Congress\/status\/400877623753973760\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/CXz6BOXDwD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZA0EyrCIAEpG5e.png",
        "id_str" : "400877623762362369",
        "id" : 400877623762362369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZA0EyrCIAEpG5e.png",
        "sizes" : [ {
          "h" : 533,
          "resize" : "fit",
          "w" : 796
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 796
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CXz6BOXDwD"
      } ],
      "hashtags" : [ {
        "text" : "MN06",
        "indices" : [ 41, 46 ]
      }, {
        "text" : "mnleg",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400877623753973760",
    "text" : "\"... No. We're not going back to that.\"  #MN06 #mnleg http:\/\/t.co\/CXz6BOXDwD",
    "id" : 400877623753973760,
    "created_at" : "2013-11-14 06:47:28 +0000",
    "user" : {
      "name" : "Jim Read",
      "screen_name" : "Read4Congress",
      "protected" : false,
      "id_str" : "2154899852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000691031731\/7102ca0893570a8431109c4b1790c038_normal.jpeg",
      "id" : 2154899852,
      "verified" : true
    }
  },
  "id" : 405394844102975488,
  "created_at" : "2013-11-26 17:57:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    }, {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 99, 102 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TIME\/status\/405357910852505600\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/riL65BacUH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaAe30ECcAENVTE.jpg",
      "id_str" : "405357910680563713",
      "id" : 405357910680563713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaAe30ECcAENVTE.jpg",
      "sizes" : [ {
        "h" : 788,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/riL65BacUH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/BsNm6qZnig",
      "expanded_url" : "http:\/\/ti.me\/1cMvo9z",
      "display_url" : "ti.me\/1cMvo9z"
    } ]
  },
  "geo" : { },
  "id_str" : "405394463260147713",
  "text" : "RT @TIME: Balto, one of the 15 most influential animals of all time http:\/\/t.co\/BsNm6qZnig (image: @AP) http:\/\/t.co\/riL65BacUH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Associated Press",
        "screen_name" : "AP",
        "indices" : [ 89, 92 ],
        "id_str" : "51241574",
        "id" : 51241574
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TIME\/status\/405357910852505600\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/riL65BacUH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaAe30ECcAENVTE.jpg",
        "id_str" : "405357910680563713",
        "id" : 405357910680563713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaAe30ECcAENVTE.jpg",
        "sizes" : [ {
          "h" : 788,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 788,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/riL65BacUH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/BsNm6qZnig",
        "expanded_url" : "http:\/\/ti.me\/1cMvo9z",
        "display_url" : "ti.me\/1cMvo9z"
      } ]
    },
    "geo" : { },
    "id_str" : "405357910852505600",
    "text" : "Balto, one of the 15 most influential animals of all time http:\/\/t.co\/BsNm6qZnig (image: @AP) http:\/\/t.co\/riL65BacUH",
    "id" : 405357910852505600,
    "created_at" : "2013-11-26 15:30:31 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 405394463260147713,
  "created_at" : "2013-11-26 17:55:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TARDIS",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "philosophy",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405390742694400000",
  "text" : "RT @derekrootboy: Your brain is like a #TARDIS: bigger on the inside. If you don't believe me open your skull and take a look. #philosophy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TARDIS",
        "indices" : [ 21, 28 ]
      }, {
        "text" : "philosophy",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405382835659227136",
    "text" : "Your brain is like a #TARDIS: bigger on the inside. If you don't believe me open your skull and take a look. #philosophy",
    "id" : 405382835659227136,
    "created_at" : "2013-11-26 17:09:34 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 405390742694400000,
  "created_at" : "2013-11-26 17:40:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405383803356848128",
  "geo" : { },
  "id_str" : "405390590965059584",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone we have a dead tree that a squirrel pair have made a home. we've been watching them past week, very active!",
  "id" : 405390590965059584,
  "in_reply_to_status_id" : 405383803356848128,
  "created_at" : "2013-11-26 17:40:23 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405386042020085760",
  "geo" : { },
  "id_str" : "405388526973243392",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare im really lovin' this new pope : )",
  "id" : 405388526973243392,
  "in_reply_to_status_id" : 405386042020085760,
  "created_at" : "2013-11-26 17:32:11 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    }, {
      "name" : "Carl Heath",
      "screen_name" : "Ralph_nader",
      "indices" : [ 94, 106 ],
      "id_str" : "2415088812",
      "id" : 2415088812
    }, {
      "name" : "Common Dreams",
      "screen_name" : "commondreams",
      "indices" : [ 108, 121 ],
      "id_str" : "14296273",
      "id" : 14296273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405139882726928384",
  "text" : "RT @SenSanders: Must Read: 21 Ways the Canadian Health Care System is Better than Obamacare - @Ralph_Nader, @CommonDreams: http:\/\/t.co\/OFtf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carl Heath",
        "screen_name" : "Ralph_nader",
        "indices" : [ 78, 90 ],
        "id_str" : "2415088812",
        "id" : 2415088812
      }, {
        "name" : "Common Dreams",
        "screen_name" : "commondreams",
        "indices" : [ 92, 105 ],
        "id_str" : "14296273",
        "id" : 14296273
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/OFtfgGamus",
        "expanded_url" : "http:\/\/www.sanders.senate.gov\/newsroom\/must-read\/21-ways-the-canadian-health-care-system-is-better-than-obamacare",
        "display_url" : "sanders.senate.gov\/newsroom\/must-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405041475026554880",
    "text" : "Must Read: 21 Ways the Canadian Health Care System is Better than Obamacare - @Ralph_Nader, @CommonDreams: http:\/\/t.co\/OFtfgGamus",
    "id" : 405041475026554880,
    "created_at" : "2013-11-25 18:33:07 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 405139882726928384,
  "created_at" : "2013-11-26 01:04:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "indices" : [ 3, 12 ],
      "id_str" : "265346131",
      "id" : 265346131
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/404764126267715585\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/FR3A1eahvR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ4C1ADCEAAS0Pe.jpg",
      "id_str" : "404764126078963712",
      "id" : 404764126078963712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ4C1ADCEAAS0Pe.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1258
      } ],
      "display_url" : "pic.twitter.com\/FR3A1eahvR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405008411974459392",
  "text" : "RT @iauaauoo: Break http:\/\/t.co\/FR3A1eahvR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/404764126267715585\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/FR3A1eahvR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ4C1ADCEAAS0Pe.jpg",
        "id_str" : "404764126078963712",
        "id" : 404764126078963712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ4C1ADCEAAS0Pe.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 1258
        } ],
        "display_url" : "pic.twitter.com\/FR3A1eahvR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404764126267715585",
    "text" : "Break http:\/\/t.co\/FR3A1eahvR",
    "id" : 404764126267715585,
    "created_at" : "2013-11-25 00:11:02 +0000",
    "user" : {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "protected" : false,
      "id_str" : "265346131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768291432213774336\/m7AAnnuF_normal.jpg",
      "id" : 265346131,
      "verified" : false
    }
  },
  "id" : 405008411974459392,
  "created_at" : "2013-11-25 16:21:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404957962965229568",
  "geo" : { },
  "id_str" : "404974081247678464",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 jeepers, poor mum. she'll need lots of purrs and cuddling. ((hugs))",
  "id" : 404974081247678464,
  "in_reply_to_status_id" : 404957962965229568,
  "created_at" : "2013-11-25 14:05:19 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404960610829348864",
  "geo" : { },
  "id_str" : "404971406414200832",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis ((hugs))",
  "id" : 404971406414200832,
  "in_reply_to_status_id" : 404960610829348864,
  "created_at" : "2013-11-25 13:54:41 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martha Bourke",
      "screen_name" : "Martha_Bourke",
      "indices" : [ 3, 17 ],
      "id_str" : "157436010",
      "id" : 157436010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/ShPdeC95nb",
      "expanded_url" : "http:\/\/thatpartwhere.com\/",
      "display_url" : "thatpartwhere.com"
    } ]
  },
  "geo" : { },
  "id_str" : "404968967330365440",
  "text" : "RT @Martha_Bourke: New! A free excerpt from Forbidden Call at http:\/\/t.co\/ShPdeC95nb -a new site connecting readers to new books through au\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/ShPdeC95nb",
        "expanded_url" : "http:\/\/thatpartwhere.com\/",
        "display_url" : "thatpartwhere.com"
      } ]
    },
    "geo" : { },
    "id_str" : "404663124692705281",
    "text" : "New! A free excerpt from Forbidden Call at http:\/\/t.co\/ShPdeC95nb -a new site connecting readers to new books through author selected scenes",
    "id" : 404663124692705281,
    "created_at" : "2013-11-24 17:29:41 +0000",
    "user" : {
      "name" : "Martha Bourke",
      "screen_name" : "Martha_Bourke",
      "protected" : false,
      "id_str" : "157436010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570776368938364928\/qJI4Uln3_normal.jpeg",
      "id" : 157436010,
      "verified" : false
    }
  },
  "id" : 404968967330365440,
  "created_at" : "2013-11-25 13:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Fuller \u262E\uFE0F\uD83D\uDDFD\uD83D\uDD96",
      "screen_name" : "bannerite",
      "indices" : [ 3, 13 ],
      "id_str" : "19088288",
      "id" : 19088288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404757292966764545",
  "text" : "RT @bannerite: This is sad and beautiful.---&gt;In rural Kentucky, health-care debate takes back seat as the long-uninsured line up http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 140, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/bl7Jevgys9",
        "expanded_url" : "http:\/\/wapo.st\/1ceY1fM",
        "display_url" : "wapo.st\/1ceY1fM"
      } ]
    },
    "geo" : { },
    "id_str" : "404727325704478720",
    "text" : "This is sad and beautiful.---&gt;In rural Kentucky, health-care debate takes back seat as the long-uninsured line up http:\/\/t.co\/bl7Jevgys9 #p2",
    "id" : 404727325704478720,
    "created_at" : "2013-11-24 21:44:48 +0000",
    "user" : {
      "name" : "Pat Fuller \u262E\uFE0F\uD83D\uDDFD\uD83D\uDD96",
      "screen_name" : "bannerite",
      "protected" : false,
      "id_str" : "19088288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800731163660648448\/UXw_n--l_normal.jpg",
      "id" : 19088288,
      "verified" : false
    }
  },
  "id" : 404757292966764545,
  "created_at" : "2013-11-24 23:43:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404751156741931008",
  "geo" : { },
  "id_str" : "404752007203811328",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell ohh good one.. lack of awareness = sin.",
  "id" : 404752007203811328,
  "in_reply_to_status_id" : 404751156741931008,
  "created_at" : "2013-11-24 23:22:53 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404751401617616896",
  "text" : "i scared poor possum about 1 hr ago putting out leftovers. he was eating kibble. turned, saw me, tripped over dish, almost knocked water..",
  "id" : 404751401617616896,
  "created_at" : "2013-11-24 23:20:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/i5eBl9OUAg",
      "expanded_url" : "http:\/\/huff.to\/1e9KHKX",
      "display_url" : "huff.to\/1e9KHKX"
    } ]
  },
  "geo" : { },
  "id_str" : "404718322148589568",
  "text" : "This Is Why Poor People's Bad Decisions Make Perfect Sense http:\/\/t.co\/i5eBl9OUAg",
  "id" : 404718322148589568,
  "created_at" : "2013-11-24 21:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404704757849153537",
  "geo" : { },
  "id_str" : "404705743539949568",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind the problem lies with the people",
  "id" : 404705743539949568,
  "in_reply_to_status_id" : 404704757849153537,
  "created_at" : "2013-11-24 20:19:02 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Valenzuela",
      "screen_name" : "Yecora51",
      "indices" : [ 3, 12 ],
      "id_str" : "91808397",
      "id" : 91808397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Yecora51\/status\/404663041909739520\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/MhCIcJRrVU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ2m5HuCEAAaipM.jpg",
      "id_str" : "404663041788088320",
      "id" : 404663041788088320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ2m5HuCEAAaipM.jpg",
      "sizes" : [ {
        "h" : 727,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 727,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MhCIcJRrVU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404667307253059584",
  "text" : "RT @Yecora51: Paul Ryan plan http:\/\/t.co\/MhCIcJRrVU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Yecora51\/status\/404663041909739520\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/MhCIcJRrVU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ2m5HuCEAAaipM.jpg",
        "id_str" : "404663041788088320",
        "id" : 404663041788088320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ2m5HuCEAAaipM.jpg",
        "sizes" : [ {
          "h" : 727,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 727,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MhCIcJRrVU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404663041909739520",
    "text" : "Paul Ryan plan http:\/\/t.co\/MhCIcJRrVU",
    "id" : 404663041909739520,
    "created_at" : "2013-11-24 17:29:22 +0000",
    "user" : {
      "name" : "David Valenzuela",
      "screen_name" : "Yecora51",
      "protected" : false,
      "id_str" : "91808397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592475762491461632\/qo_xEw5S_normal.png",
      "id" : 91808397,
      "verified" : false
    }
  },
  "id" : 404667307253059584,
  "created_at" : "2013-11-24 17:46:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 46, 54 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404665740181393408",
  "geo" : { },
  "id_str" : "404666415455547392",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind @GodlessBastard1 i really hate how @twitter changed the pictures (showing more) .. poor kitty..",
  "id" : 404666415455547392,
  "in_reply_to_status_id" : 404665740181393408,
  "created_at" : "2013-11-24 17:42:46 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/404664007534993408\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/7xDCtz9DdL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ2nxU9CUAAk-H7.jpg",
      "id_str" : "404664007413354496",
      "id" : 404664007413354496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ2nxU9CUAAk-H7.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 425
      } ],
      "display_url" : "pic.twitter.com\/7xDCtz9DdL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404665732648431616",
  "text" : "RT @ChrisCapparell: THIS IS HOW THE BIBLE WORKS on a very small scale. Consider 1:6 http:\/\/t.co\/7xDCtz9DdL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/404664007534993408\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/7xDCtz9DdL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ2nxU9CUAAk-H7.jpg",
        "id_str" : "404664007413354496",
        "id" : 404664007413354496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ2nxU9CUAAk-H7.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 425
        } ],
        "display_url" : "pic.twitter.com\/7xDCtz9DdL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404664007534993408",
    "text" : "THIS IS HOW THE BIBLE WORKS on a very small scale. Consider 1:6 http:\/\/t.co\/7xDCtz9DdL",
    "id" : 404664007534993408,
    "created_at" : "2013-11-24 17:33:12 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 404665732648431616,
  "created_at" : "2013-11-24 17:40:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404664007534993408",
  "geo" : { },
  "id_str" : "404665670320652289",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell wisdom is found when seeing through eyes of love : )",
  "id" : 404665670320652289,
  "in_reply_to_status_id" : 404664007534993408,
  "created_at" : "2013-11-24 17:39:48 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 3, 17 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404662325309104129",
  "text" : "RT @johnnie_cakes: Shaming people for wanting to purchase things they might not be able to afford unless they're dirt cheap isn't going to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404658819797499905",
    "text" : "Shaming people for wanting to purchase things they might not be able to afford unless they're dirt cheap isn't going to fix the problem.",
    "id" : 404658819797499905,
    "created_at" : "2013-11-24 17:12:35 +0000",
    "user" : {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "protected" : false,
      "id_str" : "16901470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765066200657166336\/h3XngAjO_normal.jpg",
      "id" : 16901470,
      "verified" : false
    }
  },
  "id" : 404662325309104129,
  "created_at" : "2013-11-24 17:26:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helaine Olen",
      "screen_name" : "helaineolen",
      "indices" : [ 3, 15 ],
      "id_str" : "54731136",
      "id" : 54731136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/DmlfQFLCwN",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/24\/us\/custody-battle-raises-questions-about-the-rights-of-women.html?ref=us",
      "display_url" : "nytimes.com\/2013\/11\/24\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404661772256559105",
  "text" : "RT @helaineolen: Wow. Just wow. The custody case of Bode Miller vs. Sara McKenna. http:\/\/t.co\/DmlfQFLCwN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/DmlfQFLCwN",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/24\/us\/custody-battle-raises-questions-about-the-rights-of-women.html?ref=us",
        "display_url" : "nytimes.com\/2013\/11\/24\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "404425982666235905",
    "text" : "Wow. Just wow. The custody case of Bode Miller vs. Sara McKenna. http:\/\/t.co\/DmlfQFLCwN",
    "id" : 404425982666235905,
    "created_at" : "2013-11-24 01:47:22 +0000",
    "user" : {
      "name" : "Helaine Olen",
      "screen_name" : "helaineolen",
      "protected" : false,
      "id_str" : "54731136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738548002034421760\/zU2NBmt__normal.jpg",
      "id" : 54731136,
      "verified" : true
    }
  },
  "id" : 404661772256559105,
  "created_at" : "2013-11-24 17:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Steve Phillips Photo",
      "screen_name" : "StevePhillips7",
      "indices" : [ 27, 42 ],
      "id_str" : "331082510",
      "id" : 331082510
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StevePhillips7\/status\/404246041970900992\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1SgHkD2AII",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZwrogbIIAAGgey.jpg",
      "id_str" : "404246041454977024",
      "id" : 404246041454977024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZwrogbIIAAGgey.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1840
      } ],
      "display_url" : "pic.twitter.com\/1SgHkD2AII"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404646764281860097",
  "text" : "RT @KerriFar: Gorgeous! RT @StevePhillips7: Gwen on our morning walk in some stunning light http:\/\/t.co\/1SgHkD2AII",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Phillips Photo",
        "screen_name" : "StevePhillips7",
        "indices" : [ 13, 28 ],
        "id_str" : "331082510",
        "id" : 331082510
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StevePhillips7\/status\/404246041970900992\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/1SgHkD2AII",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZwrogbIIAAGgey.jpg",
        "id_str" : "404246041454977024",
        "id" : 404246041454977024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZwrogbIIAAGgey.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1816,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 1840
        } ],
        "display_url" : "pic.twitter.com\/1SgHkD2AII"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404641962260955136",
    "text" : "Gorgeous! RT @StevePhillips7: Gwen on our morning walk in some stunning light http:\/\/t.co\/1SgHkD2AII",
    "id" : 404641962260955136,
    "created_at" : "2013-11-24 16:05:36 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 404646764281860097,
  "created_at" : "2013-11-24 16:24:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Sam",
      "screen_name" : "S_J_Johnson",
      "indices" : [ 73, 85 ],
      "id_str" : "940077925",
      "id" : 940077925
    }, {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 86, 100 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404645440748261376",
  "text" : "RT @ZachsMind: and i'm saying we can't even know what we observe is true @S_J_Johnson @CosmicHominid cuz all human knowledge goes thru subj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam",
        "screen_name" : "S_J_Johnson",
        "indices" : [ 58, 70 ],
        "id_str" : "940077925",
        "id" : 940077925
      }, {
        "name" : "Cosmic Hominid",
        "screen_name" : "CosmicHominid",
        "indices" : [ 71, 85 ],
        "id_str" : "1193933845",
        "id" : 1193933845
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "404641257424949249",
    "geo" : { },
    "id_str" : "404641435120443394",
    "in_reply_to_user_id" : 940077925,
    "text" : "and i'm saying we can't even know what we observe is true @S_J_Johnson @CosmicHominid cuz all human knowledge goes thru subjective filters.",
    "id" : 404641435120443394,
    "in_reply_to_status_id" : 404641257424949249,
    "created_at" : "2013-11-24 16:03:30 +0000",
    "in_reply_to_screen_name" : "S_J_Johnson",
    "in_reply_to_user_id_str" : "940077925",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 404645440748261376,
  "created_at" : "2013-11-24 16:19:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404633163332214784",
  "text" : "The American People have been snookered. We need to help each other to wake up to stop this atrocity.",
  "id" : 404633163332214784,
  "created_at" : "2013-11-24 15:30:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404632770166538240",
  "text" : "51% of The People's tax dollars go toward the military.. to further corporations getting wealthier.",
  "id" : 404632770166538240,
  "created_at" : "2013-11-24 15:29:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/7CJqPoTZj6",
      "expanded_url" : "http:\/\/youtu.be\/XuPecJ8dez0",
      "display_url" : "youtu.be\/XuPecJ8dez0"
    } ]
  },
  "geo" : { },
  "id_str" : "404629981839384576",
  "text" : "im sick!! &gt;&gt; The Video the US Military Doesn't Want You to See!: http:\/\/t.co\/7CJqPoTZj6",
  "id" : 404629981839384576,
  "created_at" : "2013-11-24 15:17:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan to Mars or bust",
      "screen_name" : "AbovegroundDan",
      "indices" : [ 0, 15 ],
      "id_str" : "65675951",
      "id" : 65675951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404347836470276096",
  "geo" : { },
  "id_str" : "404351588220690433",
  "in_reply_to_user_id" : 65675951,
  "text" : "@AbovegroundDan got this on my ipod touch recently. strangely addicting.",
  "id" : 404351588220690433,
  "in_reply_to_status_id" : 404347836470276096,
  "created_at" : "2013-11-23 20:51:45 +0000",
  "in_reply_to_screen_name" : "AbovegroundDan",
  "in_reply_to_user_id_str" : "65675951",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404333073401012224",
  "geo" : { },
  "id_str" : "404333815117520897",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem no holiday pay? i thought thats what unions were for.. protect the worker?",
  "id" : 404333815117520897,
  "in_reply_to_status_id" : 404333073401012224,
  "created_at" : "2013-11-23 19:41:08 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    }, {
      "name" : "Earth Pics",
      "screen_name" : "EarthPix",
      "indices" : [ 116, 125 ],
      "id_str" : "1152279248",
      "id" : 1152279248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/dfDelyLH3T",
      "expanded_url" : "https:\/\/twitter.com\/EarthPix\/status\/399054049880072192\/photo\/1",
      "display_url" : "pic.twitter.com\/dfDelyLH3T"
    } ]
  },
  "geo" : { },
  "id_str" : "404332646169587712",
  "text" : "RT @PinarAkal1: Go to the truth beyond the mind. Love is the bridge. ~Stephen Levine pic via http:\/\/t.co\/dfDelyLH3T @EarthPix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Earth Pics",
        "screen_name" : "EarthPix",
        "indices" : [ 100, 109 ],
        "id_str" : "1152279248",
        "id" : 1152279248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/dfDelyLH3T",
        "expanded_url" : "https:\/\/twitter.com\/EarthPix\/status\/399054049880072192\/photo\/1",
        "display_url" : "pic.twitter.com\/dfDelyLH3T"
      } ]
    },
    "in_reply_to_status_id_str" : "399054049880072192",
    "geo" : { },
    "id_str" : "404328501047595010",
    "in_reply_to_user_id" : 1152279248,
    "text" : "Go to the truth beyond the mind. Love is the bridge. ~Stephen Levine pic via http:\/\/t.co\/dfDelyLH3T @EarthPix",
    "id" : 404328501047595010,
    "in_reply_to_status_id" : 399054049880072192,
    "created_at" : "2013-11-23 19:20:01 +0000",
    "in_reply_to_screen_name" : "EarthPix",
    "in_reply_to_user_id_str" : "1152279248",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 404332646169587712,
  "created_at" : "2013-11-23 19:36:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ActorBuster",
      "screen_name" : "ActorBuster",
      "indices" : [ 3, 15 ],
      "id_str" : "2588026416",
      "id" : 2588026416
    }, {
      "name" : "Young Conservative\u2122",
      "screen_name" : "steve0423",
      "indices" : [ 17, 27 ],
      "id_str" : "5644772",
      "id" : 5644772
    }, {
      "name" : "Stronger Together",
      "screen_name" : "UniteBlue",
      "indices" : [ 28, 38 ],
      "id_str" : "360285166",
      "id" : 360285166
    }, {
      "name" : "Benny",
      "screen_name" : "BRios82",
      "indices" : [ 39, 47 ],
      "id_str" : "117983479",
      "id" : 117983479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404328841260580864",
  "text" : "RT @ActorBuster: @steve0423 @UniteBlue @BRios82 You spew BS. No market is free where industries are rigged like corrupt casinos.  Health is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Young Conservative\u2122",
        "screen_name" : "steve0423",
        "indices" : [ 0, 10 ],
        "id_str" : "5644772",
        "id" : 5644772
      }, {
        "name" : "Stronger Together",
        "screen_name" : "UniteBlue",
        "indices" : [ 11, 21 ],
        "id_str" : "360285166",
        "id" : 360285166
      }, {
        "name" : "Benny",
        "screen_name" : "BRios82",
        "indices" : [ 22, 30 ],
        "id_str" : "117983479",
        "id" : 117983479
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "404320743942782976",
    "geo" : { },
    "id_str" : "404328619092082688",
    "in_reply_to_user_id" : 5644772,
    "text" : "@steve0423 @UniteBlue @BRios82 You spew BS. No market is free where industries are rigged like corrupt casinos.  Health isn't a product.",
    "id" : 404328619092082688,
    "in_reply_to_status_id" : 404320743942782976,
    "created_at" : "2013-11-23 19:20:29 +0000",
    "in_reply_to_screen_name" : "steve0423",
    "in_reply_to_user_id_str" : "5644772",
    "user" : {
      "name" : "We R Gonna Fix This",
      "screen_name" : "wtb6chiny",
      "protected" : false,
      "id_str" : "204947822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787487931212718080\/lpOT5NLK_normal.jpg",
      "id" : 204947822,
      "verified" : false
    }
  },
  "id" : 404328841260580864,
  "created_at" : "2013-11-23 19:21:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Pack of Wolves",
      "screen_name" : "MyPackofWolves",
      "indices" : [ 3, 18 ],
      "id_str" : "851861838",
      "id" : 851861838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MyPackofWolves\/status\/403257152187297793\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Tn8Q6kJQnY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZioPkaCcAAcBpq.jpg",
      "id_str" : "403257152074051584",
      "id" : 403257152074051584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZioPkaCcAAcBpq.jpg",
      "sizes" : [ {
        "h" : 661,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Tn8Q6kJQnY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404325508839923712",
  "text" : "RT @MyPackofWolves: hehehehehe Thats my seat! http:\/\/t.co\/Tn8Q6kJQnY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MyPackofWolves\/status\/403257152187297793\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/Tn8Q6kJQnY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZioPkaCcAAcBpq.jpg",
        "id_str" : "403257152074051584",
        "id" : 403257152074051584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZioPkaCcAAcBpq.jpg",
        "sizes" : [ {
          "h" : 661,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Tn8Q6kJQnY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403257152187297793",
    "text" : "hehehehehe Thats my seat! http:\/\/t.co\/Tn8Q6kJQnY",
    "id" : 403257152187297793,
    "created_at" : "2013-11-20 20:22:51 +0000",
    "user" : {
      "name" : "My Pack of Wolves",
      "screen_name" : "MyPackofWolves",
      "protected" : false,
      "id_str" : "851861838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2660262168\/469376a48ae91d19690e0b33588b9f02_normal.png",
      "id" : 851861838,
      "verified" : false
    }
  },
  "id" : 404325508839923712,
  "created_at" : "2013-11-23 19:08:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackthorne",
      "screen_name" : "_Blackth0rne_",
      "indices" : [ 3, 17 ],
      "id_str" : "719268756",
      "id" : 719268756
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Blackthornicus\/status\/302502832274292736\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/ep1YrKNx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDK0uSWCQAM6lQS.jpg",
      "id_str" : "302502832278487043",
      "id" : 302502832278487043,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDK0uSWCQAM6lQS.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/ep1YrKNx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404315216735125505",
  "text" : "RT @_Blackth0rne_: Harder to get a decongestant than a gun: http:\/\/t.co\/ep1YrKNx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Blackthornicus\/status\/302502832274292736\/photo\/1",
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/ep1YrKNx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDK0uSWCQAM6lQS.jpg",
        "id_str" : "302502832278487043",
        "id" : 302502832278487043,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDK0uSWCQAM6lQS.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/ep1YrKNx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302502832274292736",
    "text" : "Harder to get a decongestant than a gun: http:\/\/t.co\/ep1YrKNx",
    "id" : 302502832274292736,
    "created_at" : "2013-02-15 19:41:10 +0000",
    "user" : {
      "name" : "Blackthorne",
      "screen_name" : "_Blackth0rne_",
      "protected" : false,
      "id_str" : "719268756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3180215388\/db90a0ae68d708f0d314318405655dd7_normal.png",
      "id" : 719268756,
      "verified" : false
    }
  },
  "id" : 404315216735125505,
  "created_at" : "2013-11-23 18:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Thornton",
      "screen_name" : "mrshllthornton",
      "indices" : [ 2, 17 ],
      "id_str" : "19794894",
      "id" : 19794894
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 45, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404272845636636673",
  "geo" : { },
  "id_str" : "404278343446437888",
  "in_reply_to_user_id" : 19794894,
  "text" : ". @mrshllthornton gives me hope for national #SinglePayer .. either federal-based or state-by-state follow suit.",
  "id" : 404278343446437888,
  "in_reply_to_status_id" : 404272845636636673,
  "created_at" : "2013-11-23 16:00:42 +0000",
  "in_reply_to_screen_name" : "mrshllthornton",
  "in_reply_to_user_id_str" : "19794894",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Thornton",
      "screen_name" : "mrshllthornton",
      "indices" : [ 3, 18 ],
      "id_str" : "19794894",
      "id" : 19794894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404277705476423680",
  "text" : "RT @mrshllthornton: Four days ago, Vermont approved a single-payer system. Of course, if you follow the news you wouldn't know it.... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/d5tOBqoyGc",
        "expanded_url" : "http:\/\/fb.me\/2v0s7cMGA",
        "display_url" : "fb.me\/2v0s7cMGA"
      } ]
    },
    "geo" : { },
    "id_str" : "404272845636636673",
    "text" : "Four days ago, Vermont approved a single-payer system. Of course, if you follow the news you wouldn't know it.... http:\/\/t.co\/d5tOBqoyGc",
    "id" : 404272845636636673,
    "created_at" : "2013-11-23 15:38:52 +0000",
    "user" : {
      "name" : "Marshall Thornton",
      "screen_name" : "mrshllthornton",
      "protected" : false,
      "id_str" : "19794894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669828383\/AnotherOption_normal.jpg",
      "id" : 19794894,
      "verified" : false
    }
  },
  "id" : 404277705476423680,
  "created_at" : "2013-11-23 15:58:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "105926473",
      "id" : 105926473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/IJsx8KqLHh",
      "expanded_url" : "http:\/\/tinyurl.com\/lswjdtm",
      "display_url" : "tinyurl.com\/lswjdtm"
    } ]
  },
  "geo" : { },
  "id_str" : "404053826426376193",
  "text" : "RT @consciousbridge: The Health Care Debate--Free Market Choices vs. Basic Human Right? http:\/\/t.co\/IJsx8KqLHh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/IJsx8KqLHh",
        "expanded_url" : "http:\/\/tinyurl.com\/lswjdtm",
        "display_url" : "tinyurl.com\/lswjdtm"
      } ]
    },
    "geo" : { },
    "id_str" : "404037368342016000",
    "text" : "The Health Care Debate--Free Market Choices vs. Basic Human Right? http:\/\/t.co\/IJsx8KqLHh",
    "id" : 404037368342016000,
    "created_at" : "2013-11-23 00:03:09 +0000",
    "user" : {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "protected" : false,
      "id_str" : "105926473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200394907\/172_normal.JPG",
      "id" : 105926473,
      "verified" : false
    }
  },
  "id" : 404053826426376193,
  "created_at" : "2013-11-23 01:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jennifer pastiloff",
      "screen_name" : "JenPastiloff",
      "indices" : [ 76, 89 ],
      "id_str" : "18662439",
      "id" : 18662439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/EPw8m9vS6f",
      "expanded_url" : "http:\/\/wp.me\/p1J25D-1qA",
      "display_url" : "wp.me\/p1J25D-1qA"
    } ]
  },
  "geo" : { },
  "id_str" : "404048045282557952",
  "text" : "beautiful &gt;&gt; What My Dog's Death Taught Me http:\/\/t.co\/EPw8m9vS6f via @JenPastiloff",
  "id" : 404048045282557952,
  "created_at" : "2013-11-23 00:45:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/2AnhrzzF0h",
      "expanded_url" : "http:\/\/thinkprogress.org\/economy\/2013\/11\/21\/2977711\/john-stossel-poor-people\/",
      "display_url" : "thinkprogress.org\/economy\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404046102241890304",
  "text" : "Fox News Chastises People For Giving To The Homeless: 'You're An Enabler' | ThinkProgress http:\/\/t.co\/2AnhrzzF0h",
  "id" : 404046102241890304,
  "created_at" : "2013-11-23 00:37:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404044072278425600",
  "text" : "i love modern family..",
  "id" : 404044072278425600,
  "created_at" : "2013-11-23 00:29:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/u6zfkeMQlQ",
      "expanded_url" : "http:\/\/www.imdb.com\/title\/tt0388482\/",
      "display_url" : "imdb.com\/title\/tt038848\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403986658908848129",
  "text" : "watching The Transporter 2 .. lots of action! http:\/\/t.co\/u6zfkeMQlQ",
  "id" : 403986658908848129,
  "created_at" : "2013-11-22 20:41:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/9QivnWYJzi",
      "expanded_url" : "http:\/\/youtu.be\/eP6jDM6sXhA",
      "display_url" : "youtu.be\/eP6jDM6sXhA"
    } ]
  },
  "geo" : { },
  "id_str" : "403977976439529472",
  "text" : "\"see ya, im going to lunch\" WTH? 06:25 &gt;&gt; JFK Conspiracy: Did Secret Service Stand Down?: http:\/\/t.co\/9QivnWYJzi",
  "id" : 403977976439529472,
  "created_at" : "2013-11-22 20:07:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmazonCoins",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "AndroidApp",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/zeDOl7HiMj",
      "expanded_url" : "http:\/\/owl.li\/r5ej6",
      "display_url" : "owl.li\/r5ej6"
    } ]
  },
  "geo" : { },
  "id_str" : "403900698347470848",
  "text" : "RT @BooksOnTheKnob: http:\/\/t.co\/zeDOl7HiMj One-time bonus of 250 free #AmazonCoins for the first purchase of any #AndroidApp from this list",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmazonCoins",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "AndroidApp",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/zeDOl7HiMj",
        "expanded_url" : "http:\/\/owl.li\/r5ej6",
        "display_url" : "owl.li\/r5ej6"
      } ]
    },
    "geo" : { },
    "id_str" : "403881741049663488",
    "text" : "http:\/\/t.co\/zeDOl7HiMj One-time bonus of 250 free #AmazonCoins for the first purchase of any #AndroidApp from this list",
    "id" : 403881741049663488,
    "created_at" : "2013-11-22 13:44:45 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 403900698347470848,
  "created_at" : "2013-11-22 15:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Penniston",
      "screen_name" : "Joanne10020",
      "indices" : [ 3, 15 ],
      "id_str" : "99353519",
      "id" : 99353519
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joanne10020\/status\/403696907823771649\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/BqBe4iEpgU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZo4MspCAAAfboG.jpg",
      "id_str" : "403696907395923968",
      "id" : 403696907395923968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZo4MspCAAAfboG.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BqBe4iEpgU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403697344480575488",
  "text" : "RT @Joanne10020: Wild Turkeys that wouldn't get out of my way http:\/\/t.co\/BqBe4iEpgU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joanne10020\/status\/403696907823771649\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/BqBe4iEpgU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZo4MspCAAAfboG.jpg",
        "id_str" : "403696907395923968",
        "id" : 403696907395923968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZo4MspCAAAfboG.jpg",
        "sizes" : [ {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BqBe4iEpgU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403696907823771649",
    "text" : "Wild Turkeys that wouldn't get out of my way http:\/\/t.co\/BqBe4iEpgU",
    "id" : 403696907823771649,
    "created_at" : "2013-11-22 01:30:17 +0000",
    "user" : {
      "name" : "Joanne Penniston",
      "screen_name" : "Joanne10020",
      "protected" : false,
      "id_str" : "99353519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782401941422743552\/dheHopBw_normal.jpg",
      "id" : 99353519,
      "verified" : false
    }
  },
  "id" : 403697344480575488,
  "created_at" : "2013-11-22 01:32:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi",
      "screen_name" : "Thisangelbites",
      "indices" : [ 3, 18 ],
      "id_str" : "39065424",
      "id" : 39065424
    }, {
      "name" : "Sunday's Sparrow",
      "screen_name" : "SundaysSparrow",
      "indices" : [ 51, 66 ],
      "id_str" : "627784011",
      "id" : 627784011
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SundaysSparrow\/status\/397382341061918720\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/f0rAzmGU2m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYPJIj9CQAIuRck.jpg",
      "id_str" : "397382341066113026",
      "id" : 397382341066113026,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYPJIj9CQAIuRck.jpg",
      "sizes" : [ {
        "h" : 828,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/f0rAzmGU2m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403614972552699904",
  "text" : "RT @Thisangelbites: I have to retweet this --&gt; \u201C@SundaysSparrow: Oh I'm just so fluffy...... http:\/\/t.co\/f0rAzmGU2m\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sunday's Sparrow",
        "screen_name" : "SundaysSparrow",
        "indices" : [ 31, 46 ],
        "id_str" : "627784011",
        "id" : 627784011
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SundaysSparrow\/status\/397382341061918720\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/f0rAzmGU2m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYPJIj9CQAIuRck.jpg",
        "id_str" : "397382341066113026",
        "id" : 397382341066113026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYPJIj9CQAIuRck.jpg",
        "sizes" : [ {
          "h" : 828,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/f0rAzmGU2m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "397382341061918720",
    "geo" : { },
    "id_str" : "403613914862477312",
    "in_reply_to_user_id" : 627784011,
    "text" : "I have to retweet this --&gt; \u201C@SundaysSparrow: Oh I'm just so fluffy...... http:\/\/t.co\/f0rAzmGU2m\u201D",
    "id" : 403613914862477312,
    "in_reply_to_status_id" : 397382341061918720,
    "created_at" : "2013-11-21 20:00:30 +0000",
    "in_reply_to_screen_name" : "SundaysSparrow",
    "in_reply_to_user_id_str" : "627784011",
    "user" : {
      "name" : "Naomi",
      "screen_name" : "Thisangelbites",
      "protected" : false,
      "id_str" : "39065424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1623221299\/image_normal.png",
      "id" : 39065424,
      "verified" : false
    }
  },
  "id" : 403614972552699904,
  "created_at" : "2013-11-21 20:04:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403613188966453248",
  "text" : "@weakSquare keeping my lips zipped... ((starts dancing around)) LOL",
  "id" : 403613188966453248,
  "created_at" : "2013-11-21 19:57:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "indices" : [ 3, 17 ],
      "id_str" : "253228348",
      "id" : 253228348
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GreyMuzzleOrg\/status\/403581267100569601\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/h43NwQbJk1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZnPBiXIAAABfRE.jpg",
      "id_str" : "403581266936987648",
      "id" : 403581266936987648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZnPBiXIAAABfRE.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 678
      } ],
      "display_url" : "pic.twitter.com\/h43NwQbJk1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403581735252017152",
  "text" : "RT @GreyMuzzleOrg: Keep your dog safe this Thanksgiving. http:\/\/t.co\/h43NwQbJk1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GreyMuzzleOrg\/status\/403581267100569601\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/h43NwQbJk1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZnPBiXIAAABfRE.jpg",
        "id_str" : "403581266936987648",
        "id" : 403581266936987648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZnPBiXIAAABfRE.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 678
        } ],
        "display_url" : "pic.twitter.com\/h43NwQbJk1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403581267100569601",
    "text" : "Keep your dog safe this Thanksgiving. http:\/\/t.co\/h43NwQbJk1",
    "id" : 403581267100569601,
    "created_at" : "2013-11-21 17:50:46 +0000",
    "user" : {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "protected" : false,
      "id_str" : "253228348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770761270416908289\/ZOXprD-__normal.jpg",
      "id" : 253228348,
      "verified" : false
    }
  },
  "id" : 403581735252017152,
  "created_at" : "2013-11-21 17:52:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie McCormack",
      "screen_name" : "ktxmac",
      "indices" : [ 3, 10 ],
      "id_str" : "43593833",
      "id" : 43593833
    }, {
      "name" : "Don Berwick",
      "screen_name" : "berwickforMA",
      "indices" : [ 39, 52 ],
      "id_str" : "1083393391",
      "id" : 1083393391
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ktxmac\/status\/403565656421203968\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/TnqRnMEa7i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZnA03_IMAANITg.jpg",
      "id_str" : "403565656240828416",
      "id" : 403565656240828416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZnA03_IMAANITg.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TnqRnMEa7i"
    } ],
    "hashtags" : [ {
      "text" : "magov",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "mapoli",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403573137847373824",
  "text" : "RT @ktxmac: Today at State House steps @berwickforMA says hes exploring the single payer option. #magov #mapoli http:\/\/t.co\/TnqRnMEa7i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Don Berwick",
        "screen_name" : "berwickforMA",
        "indices" : [ 27, 40 ],
        "id_str" : "1083393391",
        "id" : 1083393391
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ktxmac\/status\/403565656421203968\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/TnqRnMEa7i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZnA03_IMAANITg.jpg",
        "id_str" : "403565656240828416",
        "id" : 403565656240828416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZnA03_IMAANITg.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/TnqRnMEa7i"
      } ],
      "hashtags" : [ {
        "text" : "magov",
        "indices" : [ 85, 91 ]
      }, {
        "text" : "mapoli",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403565656421203968",
    "text" : "Today at State House steps @berwickforMA says hes exploring the single payer option. #magov #mapoli http:\/\/t.co\/TnqRnMEa7i",
    "id" : 403565656421203968,
    "created_at" : "2013-11-21 16:48:45 +0000",
    "user" : {
      "name" : "Katie McCormack",
      "screen_name" : "ktxmac",
      "protected" : false,
      "id_str" : "43593833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608405446261665792\/HOEQhIKw_normal.jpg",
      "id" : 43593833,
      "verified" : false
    }
  },
  "id" : 403573137847373824,
  "created_at" : "2013-11-21 17:18:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/c6Oyj3pdpK",
      "expanded_url" : "http:\/\/fullist.co.uk\/2013\/11\/get-ready-weirdest-1-minute-41-seconds-life\/",
      "display_url" : "fullist.co.uk\/2013\/11\/get-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403564758843932673",
  "text" : "LOL &gt;&gt; Get Ready For The Weirdest 1 Minute 41 Seconds Of Your Life: http:\/\/t.co\/c6Oyj3pdpK",
  "id" : 403564758843932673,
  "created_at" : "2013-11-21 16:45:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403538498872807424",
  "text" : "is everyone going to move to vermont now that they're implementing #SinglePayer ? or will the other states follow suit?",
  "id" : 403538498872807424,
  "created_at" : "2013-11-21 15:00:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turn Ky Blue",
      "screen_name" : "TurnKyBlue",
      "indices" : [ 3, 14 ],
      "id_str" : "600444379",
      "id" : 600444379
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopTheHate",
      "indices" : [ 130, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/DE4qXtysQP",
      "expanded_url" : "http:\/\/www.occupydemocrats.com\/vermont-makes-promise-people-video\/",
      "display_url" : "occupydemocrats.com\/vermont-makes-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403331453548625920",
  "text" : "RT @TurnKyBlue: Vermont Approves Single-Payer Health Care: &amp;#8216;Everybody in, nobody out&amp;#8217; http:\/\/t.co\/DE4qXtysQP \n#StopTheHate #Shu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopTheHate",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "ShutDownTheGOP",
        "indices" : [ 127, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/DE4qXtysQP",
        "expanded_url" : "http:\/\/www.occupydemocrats.com\/vermont-makes-promise-people-video\/",
        "display_url" : "occupydemocrats.com\/vermont-makes-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403321332936368129",
    "text" : "Vermont Approves Single-Payer Health Care: &amp;#8216;Everybody in, nobody out&amp;#8217; http:\/\/t.co\/DE4qXtysQP \n#StopTheHate #ShutDownTheGOP",
    "id" : 403321332936368129,
    "created_at" : "2013-11-21 00:37:53 +0000",
    "user" : {
      "name" : "Turn Ky Blue",
      "screen_name" : "TurnKyBlue",
      "protected" : false,
      "id_str" : "600444379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530483207892787200\/Tp6D6o8S_normal.jpeg",
      "id" : 600444379,
      "verified" : false
    }
  },
  "id" : 403331453548625920,
  "created_at" : "2013-11-21 01:18:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juliet Harrison",
      "screen_name" : "lecheval",
      "indices" : [ 3, 12 ],
      "id_str" : "17257283",
      "id" : 17257283
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lecheval\/status\/403282327599476736\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/YYmephChT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZi_I9xCcAANgqZ.jpg",
      "id_str" : "403282327389761536",
      "id" : 403282327389761536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZi_I9xCcAANgqZ.jpg",
      "sizes" : [ {
        "h" : 935,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2778,
        "resize" : "fit",
        "w" : 1783
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1595,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YYmephChT8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403285471260049408",
  "text" : "RT @lecheval: Love the \"long ears\"! http:\/\/t.co\/YYmephChT8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lecheval\/status\/403282327599476736\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/YYmephChT8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZi_I9xCcAANgqZ.jpg",
        "id_str" : "403282327389761536",
        "id" : 403282327389761536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZi_I9xCcAANgqZ.jpg",
        "sizes" : [ {
          "h" : 935,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2778,
          "resize" : "fit",
          "w" : 1783
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1595,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YYmephChT8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403282327599476736",
    "text" : "Love the \"long ears\"! http:\/\/t.co\/YYmephChT8",
    "id" : 403282327599476736,
    "created_at" : "2013-11-20 22:02:54 +0000",
    "user" : {
      "name" : "Juliet Harrison",
      "screen_name" : "lecheval",
      "protected" : false,
      "id_str" : "17257283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220023348\/417-23ab_normal.jpg",
      "id" : 17257283,
      "verified" : false
    }
  },
  "id" : 403285471260049408,
  "created_at" : "2013-11-20 22:15:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gardner",
      "screen_name" : "Bill_Gardner",
      "indices" : [ 3, 16 ],
      "id_str" : "17943537",
      "id" : 17943537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403282569439248384",
  "text" : "RT @Bill_Gardner: In Canada, there isn't a single payer system. There's one for each province. Now we have the first one in Vermont. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/pOKmPuMePR",
        "expanded_url" : "http:\/\/www.minnpost.com\/community-voices\/2013\/11\/health-insurance-problems-keep-arising-vermont-offers-ray-hope",
        "display_url" : "minnpost.com\/community-voic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403232084031844352",
    "text" : "In Canada, there isn't a single payer system. There's one for each province. Now we have the first one in Vermont. http:\/\/t.co\/pOKmPuMePR",
    "id" : 403232084031844352,
    "created_at" : "2013-11-20 18:43:15 +0000",
    "user" : {
      "name" : "Bill Gardner",
      "screen_name" : "Bill_Gardner",
      "protected" : false,
      "id_str" : "17943537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796731755025698816\/GVd3RQsu_normal.jpg",
      "id" : 17943537,
      "verified" : false
    }
  },
  "id" : 403282569439248384,
  "created_at" : "2013-11-20 22:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u06AF\u0631\u0628\u0647",
      "screen_name" : "Shmangy",
      "indices" : [ 3, 11 ],
      "id_str" : "331369575",
      "id" : 331369575
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Shmangy\/status\/401516461593612288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/uOOThlo5Ll",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZJ5GDFCUAAQ8wg.jpg",
      "id_str" : "401516461602000896",
      "id" : 401516461602000896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZJ5GDFCUAAQ8wg.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/uOOThlo5Ll"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403259577577533440",
  "text" : "RT @Shmangy: Baby elephant being held captive chained to a tree in Borneo; looks like little guy has been crying :( http:\/\/t.co\/uOOThlo5Ll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Shmangy\/status\/401516461593612288\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/uOOThlo5Ll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZJ5GDFCUAAQ8wg.jpg",
        "id_str" : "401516461602000896",
        "id" : 401516461602000896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZJ5GDFCUAAQ8wg.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/uOOThlo5Ll"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401516461593612288",
    "text" : "Baby elephant being held captive chained to a tree in Borneo; looks like little guy has been crying :( http:\/\/t.co\/uOOThlo5Ll",
    "id" : 401516461593612288,
    "created_at" : "2013-11-16 01:05:59 +0000",
    "user" : {
      "name" : "\u06AF\u0631\u0628\u0647",
      "screen_name" : "Shmangy",
      "protected" : false,
      "id_str" : "331369575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1431611582\/untitled_normal.png",
      "id" : 331369575,
      "verified" : false
    }
  },
  "id" : 403259577577533440,
  "created_at" : "2013-11-20 20:32:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Radel",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403231397936386048",
  "text" : "RT @SangyeH: Rep Trey #Radel was funding his cocaine &amp; alcoholism using taxpayer dollars. But all hell breaks loose if a poor person buys a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Radel",
        "indices" : [ 9, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403229558981160960",
    "text" : "Rep Trey #Radel was funding his cocaine &amp; alcoholism using taxpayer dollars. But all hell breaks loose if a poor person buys a bag of Fritos",
    "id" : 403229558981160960,
    "created_at" : "2013-11-20 18:33:13 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 403231397936386048,
  "created_at" : "2013-11-20 18:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403223659768066048",
  "geo" : { },
  "id_str" : "403229696503971841",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos hehe.. i could see my DD doing this..",
  "id" : 403229696503971841,
  "in_reply_to_status_id" : 403223659768066048,
  "created_at" : "2013-11-20 18:33:45 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "indices" : [ 44, 56 ],
      "id_str" : "16126957",
      "id" : 16126957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/OSEYTIyM90",
      "expanded_url" : "http:\/\/www.baldhiker.com\/2013\/08\/28\/hello-feathered-friend\/",
      "display_url" : "baldhiker.com\/2013\/08\/28\/hel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403197929839951872",
  "text" : "RT @KerriFar: Love this little sweetie!! RT @paul_steele: Hello feathered friend\u2026. http:\/\/t.co\/OSEYTIyM90",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Steele",
        "screen_name" : "paul_steele",
        "indices" : [ 30, 42 ],
        "id_str" : "16126957",
        "id" : 16126957
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/OSEYTIyM90",
        "expanded_url" : "http:\/\/www.baldhiker.com\/2013\/08\/28\/hello-feathered-friend\/",
        "display_url" : "baldhiker.com\/2013\/08\/28\/hel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403190402460971008",
    "text" : "Love this little sweetie!! RT @paul_steele: Hello feathered friend\u2026. http:\/\/t.co\/OSEYTIyM90",
    "id" : 403190402460971008,
    "created_at" : "2013-11-20 15:57:37 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 403197929839951872,
  "created_at" : "2013-11-20 16:27:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/403193288653434880\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/MOG2HQFkRo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZhuKOBCEAEcjIy.jpg",
      "id_str" : "403193288489832449",
      "id" : 403193288489832449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZhuKOBCEAEcjIy.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MOG2HQFkRo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403196587947851776",
  "text" : "RT @phylogenomics: Well - this is an interesting new breakfast cereal http:\/\/t.co\/MOG2HQFkRo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/403193288653434880\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/MOG2HQFkRo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZhuKOBCEAEcjIy.jpg",
        "id_str" : "403193288489832449",
        "id" : 403193288489832449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZhuKOBCEAEcjIy.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/MOG2HQFkRo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403193288653434880",
    "text" : "Well - this is an interesting new breakfast cereal http:\/\/t.co\/MOG2HQFkRo",
    "id" : 403193288653434880,
    "created_at" : "2013-11-20 16:09:05 +0000",
    "user" : {
      "name" : "Jonathan Eisen",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 403196587947851776,
  "created_at" : "2013-11-20 16:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403178047551311872",
  "text" : "RT @LOLGOP: If you want to stop abortions, it's simple. Make sure everyone has health care, education and birth control. Not the exact oppo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402631002008207360",
    "text" : "If you want to stop abortions, it's simple. Make sure everyone has health care, education and birth control. Not the exact opposite.",
    "id" : 402631002008207360,
    "created_at" : "2013-11-19 02:54:46 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 403178047551311872,
  "created_at" : "2013-11-20 15:08:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 3, 15 ],
      "id_str" : "409492415",
      "id" : 409492415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403160904780759040",
  "text" : "RT @Coyotetooth: Yesterday was a stripped back, stark day.  An exposed day.  A raw, vulnerable day.  A day that exposed thorns which hid in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402784266066862081",
    "text" : "Yesterday was a stripped back, stark day.  An exposed day.  A raw, vulnerable day.  A day that exposed thorns which hid in the mist.",
    "id" : 402784266066862081,
    "created_at" : "2013-11-19 13:03:47 +0000",
    "user" : {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "protected" : false,
      "id_str" : "409492415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502871900054642688\/RlK3naNt_normal.jpeg",
      "id" : 409492415,
      "verified" : false
    }
  },
  "id" : 403160904780759040,
  "created_at" : "2013-11-20 14:00:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 3, 15 ],
      "id_str" : "409492415",
      "id" : 409492415
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/403147065704083456\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/LsXHuKq1W7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZhEHsHIEAApS6n.jpg",
      "id_str" : "403147065540481024",
      "id" : 403147065540481024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZhEHsHIEAApS6n.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LsXHuKq1W7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403160493474734080",
  "text" : "RT @Coyotetooth: Met a young friend during my break http:\/\/t.co\/LsXHuKq1W7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/403147065704083456\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/LsXHuKq1W7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZhEHsHIEAApS6n.jpg",
        "id_str" : "403147065540481024",
        "id" : 403147065540481024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZhEHsHIEAApS6n.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LsXHuKq1W7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403147065704083456",
    "text" : "Met a young friend during my break http:\/\/t.co\/LsXHuKq1W7",
    "id" : 403147065704083456,
    "created_at" : "2013-11-20 13:05:25 +0000",
    "user" : {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "protected" : false,
      "id_str" : "409492415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502871900054642688\/RlK3naNt_normal.jpeg",
      "id" : 409492415,
      "verified" : false
    }
  },
  "id" : 403160493474734080,
  "created_at" : "2013-11-20 13:58:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 0, 12 ],
      "id_str" : "409492415",
      "id" : 409492415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403147065704083456",
  "geo" : { },
  "id_str" : "403160440676425728",
  "in_reply_to_user_id" : 409492415,
  "text" : "@Coyotetooth beautiful!",
  "id" : 403160440676425728,
  "in_reply_to_status_id" : 403147065704083456,
  "created_at" : "2013-11-20 13:58:34 +0000",
  "in_reply_to_screen_name" : "Coyotetooth",
  "in_reply_to_user_id_str" : "409492415",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403149602242560000",
  "geo" : { },
  "id_str" : "403154340107407361",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater ((dancin'))",
  "id" : 403154340107407361,
  "in_reply_to_status_id" : 403149602242560000,
  "created_at" : "2013-11-20 13:34:19 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/jsZykgpsXD",
      "expanded_url" : "http:\/\/youtu.be\/q2wF0vTtkRM",
      "display_url" : "youtu.be\/q2wF0vTtkRM"
    } ]
  },
  "geo" : { },
  "id_str" : "402989844185370624",
  "text" : "adorbs! lol &gt;&gt; World's Laziest Corgi Fight: http:\/\/t.co\/jsZykgpsXD",
  "id" : 402989844185370624,
  "created_at" : "2013-11-20 02:40:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402929866833932288",
  "text" : "RT @rzarosco: Knock on your neighbors door and ask if they've seen your cat. When they say no pull your cat out of your pocket and make the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283028697353711616",
    "text" : "Knock on your neighbors door and ask if they've seen your cat. When they say no pull your cat out of your pocket and make the introductions",
    "id" : 283028697353711616,
    "created_at" : "2012-12-24 01:57:54 +0000",
    "user" : {
      "name" : "crapunzel",
      "screen_name" : "Karate_Horse",
      "protected" : false,
      "id_str" : "553836803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734180212221612034\/ZWL1mr7m_normal.jpg",
      "id" : 553836803,
      "verified" : false
    }
  },
  "id" : 402929866833932288,
  "created_at" : "2013-11-19 22:42:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 0, 13 ],
      "id_str" : "17068546",
      "id" : 17068546
    }, {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 29, 41 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402926158519336960",
  "geo" : { },
  "id_str" : "402927275768700928",
  "in_reply_to_user_id" : 17068546,
  "text" : "@TorontoLydia me, too... : ) @CoyoteSings",
  "id" : 402927275768700928,
  "in_reply_to_status_id" : 402926158519336960,
  "created_at" : "2013-11-19 22:32:03 +0000",
  "in_reply_to_screen_name" : "TorontoLydia",
  "in_reply_to_user_id_str" : "17068546",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yapaz (Esenler)",
      "screen_name" : "Yapaz_Esenler",
      "indices" : [ 3, 17 ],
      "id_str" : "1960995594",
      "id" : 1960995594
    }, {
      "name" : "Dean Stoker",
      "screen_name" : "StokerDean",
      "indices" : [ 20, 31 ],
      "id_str" : "579106229",
      "id" : 579106229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StokerDean\/status\/394928264570863616\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UNfYxIDK7e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXsRKgnCAAAgbkW.jpg",
      "id_str" : "394928264575057920",
      "id" : 394928264575057920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXsRKgnCAAAgbkW.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/UNfYxIDK7e"
    } ],
    "hashtags" : [ {
      "text" : "HighlandCow",
      "indices" : [ 48, 60 ]
    }, {
      "text" : "Applecross",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "Scotland",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402925688694788096",
  "text" : "RT @Yapaz_Esenler: \"@StokerDean 'Blonde Beauty' #HighlandCow #Applecross #Scotland http:\/\/t.co\/UNfYxIDK7e\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dean Stoker",
        "screen_name" : "StokerDean",
        "indices" : [ 1, 12 ],
        "id_str" : "579106229",
        "id" : 579106229
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StokerDean\/status\/394928264570863616\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/UNfYxIDK7e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXsRKgnCAAAgbkW.jpg",
        "id_str" : "394928264575057920",
        "id" : 394928264575057920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXsRKgnCAAAgbkW.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/UNfYxIDK7e"
      } ],
      "hashtags" : [ {
        "text" : "HighlandCow",
        "indices" : [ 29, 41 ]
      }, {
        "text" : "Applecross",
        "indices" : [ 42, 53 ]
      }, {
        "text" : "Scotland",
        "indices" : [ 54, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401464030553853952",
    "text" : "\"@StokerDean 'Blonde Beauty' #HighlandCow #Applecross #Scotland http:\/\/t.co\/UNfYxIDK7e\"",
    "id" : 401464030553853952,
    "created_at" : "2013-11-15 21:37:38 +0000",
    "user" : {
      "name" : "yapaz (Esenler)",
      "screen_name" : "Yapaz_Esenler",
      "protected" : false,
      "id_str" : "1960995594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663111769670475776\/vvytXRIy_normal.jpg",
      "id" : 1960995594,
      "verified" : false
    }
  },
  "id" : 402925688694788096,
  "created_at" : "2013-11-19 22:25:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402921191704244224",
  "text" : "assuming i have TMD .. it's still sore.",
  "id" : 402921191704244224,
  "created_at" : "2013-11-19 22:07:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/4iduUvqgsk",
      "expanded_url" : "http:\/\/youtu.be\/EGmqje9v2bw",
      "display_url" : "youtu.be\/EGmqje9v2bw"
    } ]
  },
  "geo" : { },
  "id_str" : "402875118977699840",
  "text" : "LOL &gt;&gt; no cats, they're all deceivers says MP - Do pets go to Heaven? Michael Pearl: http:\/\/t.co\/4iduUvqgsk 03:07",
  "id" : 402875118977699840,
  "created_at" : "2013-11-19 19:04:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cute Emergency\uD83C\uDF84",
      "screen_name" : "CuteEmergency",
      "indices" : [ 3, 17 ],
      "id_str" : "568825492",
      "id" : 568825492
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CuteEmergency\/status\/402599642531381248\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/bcO3zutdM8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZZSPd6IAAAhVM0.jpg",
      "id_str" : "402599642376175616",
      "id" : 402599642376175616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZZSPd6IAAAhVM0.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/bcO3zutdM8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402611520238264320",
  "text" : "RT @CuteEmergency: Valais Blacknose Sheep from Switzerland http:\/\/t.co\/bcO3zutdM8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CuteEmergency\/status\/402599642531381248\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/bcO3zutdM8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZZSPd6IAAAhVM0.jpg",
        "id_str" : "402599642376175616",
        "id" : 402599642376175616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZZSPd6IAAAhVM0.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/bcO3zutdM8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402599642531381248",
    "text" : "Valais Blacknose Sheep from Switzerland http:\/\/t.co\/bcO3zutdM8",
    "id" : 402599642531381248,
    "created_at" : "2013-11-19 00:50:09 +0000",
    "user" : {
      "name" : "Cute Emergency\uD83C\uDF84",
      "screen_name" : "CuteEmergency",
      "protected" : false,
      "id_str" : "568825492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551428167760486404\/DMyfmQDA_normal.jpeg",
      "id" : 568825492,
      "verified" : true
    }
  },
  "id" : 402611520238264320,
  "created_at" : "2013-11-19 01:37:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carola",
      "screen_name" : "caroliolio",
      "indices" : [ 3, 14 ],
      "id_str" : "227785899",
      "id" : 227785899
    }, {
      "name" : "Margreet Joustra",
      "screen_name" : "MargreetJoustra",
      "indices" : [ 25, 41 ],
      "id_str" : "238195237",
      "id" : 238195237
    }, {
      "name" : "Animal Life",
      "screen_name" : "MeetAnimals",
      "indices" : [ 68, 80 ],
      "id_str" : "953278568",
      "id" : 953278568
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MeetAnimals\/status\/396404371413819392\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/USpXnoZAqj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYBPrOUIEAApSrr.jpg",
      "id_str" : "396404371204083712",
      "id" : 396404371204083712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYBPrOUIEAApSrr.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/USpXnoZAqj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402607822221099008",
  "text" : "RT @caroliolio: dinnetje @margreetjoustra mag jij niet missen... RT @MeetAnimals: Baby elephant making friends http:\/\/t.co\/USpXnoZAqj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Margreet Joustra",
        "screen_name" : "MargreetJoustra",
        "indices" : [ 9, 25 ],
        "id_str" : "238195237",
        "id" : 238195237
      }, {
        "name" : "Animal Life",
        "screen_name" : "MeetAnimals",
        "indices" : [ 52, 64 ],
        "id_str" : "953278568",
        "id" : 953278568
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MeetAnimals\/status\/396404371413819392\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/USpXnoZAqj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYBPrOUIEAApSrr.jpg",
        "id_str" : "396404371204083712",
        "id" : 396404371204083712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYBPrOUIEAApSrr.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/USpXnoZAqj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396404806127861760",
    "text" : "dinnetje @margreetjoustra mag jij niet missen... RT @MeetAnimals: Baby elephant making friends http:\/\/t.co\/USpXnoZAqj",
    "id" : 396404806127861760,
    "created_at" : "2013-11-01 22:34:05 +0000",
    "user" : {
      "name" : "carola",
      "screen_name" : "caroliolio",
      "protected" : false,
      "id_str" : "227785899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640243792470233089\/5pmBWKB0_normal.jpg",
      "id" : 227785899,
      "verified" : false
    }
  },
  "id" : 402607822221099008,
  "created_at" : "2013-11-19 01:22:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402604470464692224",
  "text" : "RT @CoyoteSings: Look into the night sky at all the beautiful stars and then realize that some of them haven't existed since before you wer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402594610838396928",
    "text" : "Look into the night sky at all the beautiful stars and then realize that some of them haven't existed since before you were born.",
    "id" : 402594610838396928,
    "created_at" : "2013-11-19 00:30:09 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 402604470464692224,
  "created_at" : "2013-11-19 01:09:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 3, 17 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402604230651166720",
  "text" : "RT @LilMissCoyote: I walk in darkness because the light is blinding.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402595018784776192",
    "text" : "I walk in darkness because the light is blinding.",
    "id" : 402595018784776192,
    "created_at" : "2013-11-19 00:31:46 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 402604230651166720,
  "created_at" : "2013-11-19 01:08:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 0, 12 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    }, {
      "name" : "The Bible Lied",
      "screen_name" : "antibible_t",
      "indices" : [ 13, 25 ],
      "id_str" : "825718357",
      "id" : 825718357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402604006557495296",
  "text" : "@HelloPoodle @antibible_t ppl like him scare me",
  "id" : 402604006557495296,
  "created_at" : "2013-11-19 01:07:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "indices" : [ 3, 16 ],
      "id_str" : "42481335",
      "id" : 42481335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402601002928320512",
  "text" : "RT @LegionAvalon: The notion that science and spirituality are somehow mutually exclusive does a disservice to both. ~ Carl Sagan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/smqueue.com\" rel=\"nofollow\"\u003Esmqueue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402598656789856257",
    "text" : "The notion that science and spirituality are somehow mutually exclusive does a disservice to both. ~ Carl Sagan",
    "id" : 402598656789856257,
    "created_at" : "2013-11-19 00:46:14 +0000",
    "user" : {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "protected" : false,
      "id_str" : "42481335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3391327613\/c795db5eaa583c2e7f3d9799771ff3c3_normal.jpeg",
      "id" : 42481335,
      "verified" : false
    }
  },
  "id" : 402601002928320512,
  "created_at" : "2013-11-19 00:55:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "indices" : [ 3, 15 ],
      "id_str" : "954590804",
      "id" : 954590804
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/402572416339431424\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/JM5dQNOhVb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZY5esfIAAELgfL.jpg",
      "id_str" : "402572416196804609",
      "id" : 402572416196804609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZY5esfIAAELgfL.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/JM5dQNOhVb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402578745661620224",
  "text" : "RT @planetepics: Naps http:\/\/t.co\/JM5dQNOhVb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/402572416339431424\/photo\/1",
        "indices" : [ 5, 27 ],
        "url" : "http:\/\/t.co\/JM5dQNOhVb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZY5esfIAAELgfL.jpg",
        "id_str" : "402572416196804609",
        "id" : 402572416196804609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZY5esfIAAELgfL.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/JM5dQNOhVb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402572416339431424",
    "text" : "Naps http:\/\/t.co\/JM5dQNOhVb",
    "id" : 402572416339431424,
    "created_at" : "2013-11-18 23:01:58 +0000",
    "user" : {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "protected" : false,
      "id_str" : "954590804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463495027600015360\/_Jyj6WD6_normal.jpeg",
      "id" : 954590804,
      "verified" : false
    }
  },
  "id" : 402578745661620224,
  "created_at" : "2013-11-18 23:27:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kliff",
      "screen_name" : "sarahkliff",
      "indices" : [ 3, 14 ],
      "id_str" : "19734832",
      "id" : 19734832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/LnHWQPFsSJ",
      "expanded_url" : "http:\/\/knowmore.washingtonpost.com\/2013\/11\/18\/single-payer-is-a-whole-lot-more-popular-than-americas-absurd-health-care-system\/",
      "display_url" : "knowmore.washingtonpost.com\/2013\/11\/18\/sin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402577911959793664",
  "text" : "RT @sarahkliff: Americans hate their health care system more than any other country. http:\/\/t.co\/LnHWQPFsSJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/LnHWQPFsSJ",
        "expanded_url" : "http:\/\/knowmore.washingtonpost.com\/2013\/11\/18\/single-payer-is-a-whole-lot-more-popular-than-americas-absurd-health-care-system\/",
        "display_url" : "knowmore.washingtonpost.com\/2013\/11\/18\/sin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402452265488769025",
    "text" : "Americans hate their health care system more than any other country. http:\/\/t.co\/LnHWQPFsSJ",
    "id" : 402452265488769025,
    "created_at" : "2013-11-18 15:04:31 +0000",
    "user" : {
      "name" : "Sarah Kliff",
      "screen_name" : "sarahkliff",
      "protected" : false,
      "id_str" : "19734832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765529412301455361\/_faRepBm_normal.jpg",
      "id" : 19734832,
      "verified" : true
    }
  },
  "id" : 402577911959793664,
  "created_at" : "2013-11-18 23:23:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Birkenfeld",
      "screen_name" : "KBirkenfeld",
      "indices" : [ 3, 15 ],
      "id_str" : "37144893",
      "id" : 37144893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402577854069997568",
  "text" : "RT @KBirkenfeld: Every developed country in the world provides healthcare to all citizens, except ONE. \n\nvia @MiamiLib http:\/\/t.co\/ukIUI76j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MiamiLib\/status\/395189015235678209\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ukIUI76jKf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXv-UL7CQAIC_0O.jpg",
        "id_str" : "395189015076290562",
        "id" : 395189015076290562,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXv-UL7CQAIC_0O.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ukIUI76jKf"
      } ],
      "hashtags" : [ {
        "text" : "UniteBlue",
        "indices" : [ 125, 135 ]
      }, {
        "text" : "ACA",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "395189015235678209",
    "geo" : { },
    "id_str" : "402141594906005504",
    "in_reply_to_user_id" : 898533348,
    "text" : "Every developed country in the world provides healthcare to all citizens, except ONE. \n\nvia @MiamiLib http:\/\/t.co\/ukIUI76jKf #UniteBlue #ACA",
    "id" : 402141594906005504,
    "in_reply_to_status_id" : 395189015235678209,
    "created_at" : "2013-11-17 18:30:02 +0000",
    "in_reply_to_screen_name" : "LibsInAmerica",
    "in_reply_to_user_id_str" : "898533348",
    "user" : {
      "name" : "Kim Birkenfeld",
      "screen_name" : "KBirkenfeld",
      "protected" : false,
      "id_str" : "37144893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670600309790498817\/7ubpd3_F_normal.png",
      "id" : 37144893,
      "verified" : false
    }
  },
  "id" : 402577854069997568,
  "created_at" : "2013-11-18 23:23:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Baxter Bean",
      "screen_name" : "TheBaxterBean",
      "indices" : [ 3, 17 ],
      "id_str" : "166329578",
      "id" : 166329578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 129, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/jGLcBT6KmQ",
      "expanded_url" : "http:\/\/www.ibtimes.com\/anthem-blue-cross-wellpoint-wlp-unit-sued-allegedly-tricking-tens-thousands-dropping-grandfathered",
      "display_url" : "ibtimes.com\/anthem-blue-cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402510137124216832",
  "text" : "RT @TheBaxterBean: Anthem Blue Cross Sued For Tricking 900,000 Into Dropping 'Grandfathered' Health Plans http:\/\/t.co\/jGLcBT6KmQ #p2 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheBaxterBean\/status\/402505836058406912\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/TwjLwj6w4f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZX87NEIAAEneNN.jpg",
        "id_str" : "402505835768971265",
        "id" : 402505835768971265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZX87NEIAAEneNN.jpg",
        "sizes" : [ {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 770
        } ],
        "display_url" : "pic.twitter.com\/TwjLwj6w4f"
      } ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 110, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/jGLcBT6KmQ",
        "expanded_url" : "http:\/\/www.ibtimes.com\/anthem-blue-cross-wellpoint-wlp-unit-sued-allegedly-tricking-tens-thousands-dropping-grandfathered",
        "display_url" : "ibtimes.com\/anthem-blue-cr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402505836058406912",
    "text" : "Anthem Blue Cross Sued For Tricking 900,000 Into Dropping 'Grandfathered' Health Plans http:\/\/t.co\/jGLcBT6KmQ #p2 http:\/\/t.co\/TwjLwj6w4f",
    "id" : 402505836058406912,
    "created_at" : "2013-11-18 18:37:24 +0000",
    "user" : {
      "name" : "The Baxter Bean",
      "screen_name" : "TheBaxterBean",
      "protected" : false,
      "id_str" : "166329578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783083617589268480\/N7Rw1nBd_normal.jpg",
      "id" : 166329578,
      "verified" : false
    }
  },
  "id" : 402510137124216832,
  "created_at" : "2013-11-18 18:54:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/4QdSV7GlLZ",
      "expanded_url" : "http:\/\/dailygarlic.com\/picture\/this-womans-shocking-medical-story-deserves-to-be-spread-xpost-from-rwtf-22009",
      "display_url" : "dailygarlic.com\/picture\/this-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402504260564156416",
  "text" : "This woman's shocking medical story deserves to be spread: http:\/\/t.co\/4QdSV7GlLZ",
  "id" : 402504260564156416,
  "created_at" : "2013-11-18 18:31:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zbigniew",
      "screen_name" : "zbrad111",
      "indices" : [ 3, 12 ],
      "id_str" : "879917970",
      "id" : 879917970
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zbrad111\/status\/402091278713647104\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/m75z8pvgno",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZSD4zOCAAAAuDN.jpg",
      "id_str" : "402091278587789312",
      "id" : 402091278587789312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZSD4zOCAAAAuDN.jpg",
      "sizes" : [ {
        "h" : 596,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/m75z8pvgno"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402493457601925121",
  "text" : "RT @zbrad111: Horses... http:\/\/t.co\/m75z8pvgno",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zbrad111\/status\/402091278713647104\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/m75z8pvgno",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZSD4zOCAAAAuDN.jpg",
        "id_str" : "402091278587789312",
        "id" : 402091278587789312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZSD4zOCAAAAuDN.jpg",
        "sizes" : [ {
          "h" : 596,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/m75z8pvgno"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402091278713647104",
    "text" : "Horses... http:\/\/t.co\/m75z8pvgno",
    "id" : 402091278713647104,
    "created_at" : "2013-11-17 15:10:06 +0000",
    "user" : {
      "name" : "Zbigniew",
      "screen_name" : "zbrad111",
      "protected" : false,
      "id_str" : "879917970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3418002769\/5291e69ab07441fc79c68f98b0e2fe26_normal.jpeg",
      "id" : 879917970,
      "verified" : false
    }
  },
  "id" : 402493457601925121,
  "created_at" : "2013-11-18 17:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra Batchelder",
      "screen_name" : "myrabatchelder",
      "indices" : [ 3, 18 ],
      "id_str" : "87358629",
      "id" : 87358629
    }, {
      "name" : "Kaiser Health News",
      "screen_name" : "KHNews",
      "indices" : [ 121, 128 ],
      "id_str" : "23999515",
      "id" : 23999515
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dental",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/08AqgokFJT",
      "expanded_url" : "http:\/\/www.kaiserhealthnews.org\/Stories\/2013\/November\/18\/michigan-uninsured-dental-volunteer.aspx",
      "display_url" : "kaiserhealthnews.org\/Stories\/2013\/N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402492884890693632",
  "text" : "RT @myrabatchelder: Uninsured In Michigan County Can Pay For #Dental Care With Volunteer Work http:\/\/t.co\/08AqgokFJT via @khnews  #healthca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kaiser Health News",
        "screen_name" : "KHNews",
        "indices" : [ 101, 108 ],
        "id_str" : "23999515",
        "id" : 23999515
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dental",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "healthcare",
        "indices" : [ 110, 121 ]
      }, {
        "text" : "ObamaCare",
        "indices" : [ 122, 132 ]
      }, {
        "text" : "p2",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/08AqgokFJT",
        "expanded_url" : "http:\/\/www.kaiserhealthnews.org\/Stories\/2013\/November\/18\/michigan-uninsured-dental-volunteer.aspx",
        "display_url" : "kaiserhealthnews.org\/Stories\/2013\/N\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402488210871173120",
    "text" : "Uninsured In Michigan County Can Pay For #Dental Care With Volunteer Work http:\/\/t.co\/08AqgokFJT via @khnews  #healthcare #ObamaCare #p2",
    "id" : 402488210871173120,
    "created_at" : "2013-11-18 17:27:22 +0000",
    "user" : {
      "name" : "Myra Batchelder",
      "screen_name" : "myrabatchelder",
      "protected" : false,
      "id_str" : "87358629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779354079004860416\/Vy67RCtq_normal.jpg",
      "id" : 87358629,
      "verified" : false
    }
  },
  "id" : 402492884890693632,
  "created_at" : "2013-11-18 17:45:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ABATGKP5DT",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/regajha\/this-guys-live-tweets-of-his-neighbors-break-up-are-hilariou?bffb",
      "display_url" : "buzzfeed.com\/regajha\/this-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402491996717481984",
  "text" : "RT @micahjmurray: I give it two days until Hollywood options the rights to this story. Not kidding. http:\/\/t.co\/ABATGKP5DT (caution: swears)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/ABATGKP5DT",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/regajha\/this-guys-live-tweets-of-his-neighbors-break-up-are-hilariou?bffb",
        "display_url" : "buzzfeed.com\/regajha\/this-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402491040583528448",
    "text" : "I give it two days until Hollywood options the rights to this story. Not kidding. http:\/\/t.co\/ABATGKP5DT (caution: swears)",
    "id" : 402491040583528448,
    "created_at" : "2013-11-18 17:38:36 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 402491996717481984,
  "created_at" : "2013-11-18 17:42:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402243423027347456",
  "text" : "RT @DharmaTalks: As the transformation begins we hear the call to be of service. Slowly at first then it surges to a euphony of movement wi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402242319065546752",
    "text" : "As the transformation begins we hear the call to be of service. Slowly at first then it surges to a euphony of movement within the heart.",
    "id" : 402242319065546752,
    "created_at" : "2013-11-18 01:10:16 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 402243423027347456,
  "created_at" : "2013-11-18 01:14:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u029D\u0454\u0455\u0455\u03B9\u00A2\u03B1 \u03B1\u044F\u043C\u0454\u0438\u0442\u03B9 \u2654",
      "screen_name" : "jessmariex0",
      "indices" : [ 0, 12 ],
      "id_str" : "160284136",
      "id" : 160284136
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 84, 98 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/gvWhOu9VXx",
      "expanded_url" : "http:\/\/gizmodo.com\/5978064\/how-to-make-sure-your-twitter-archive-is-always-up-to-date",
      "display_url" : "gizmodo.com\/5978064\/how-to\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402223827297763328",
  "geo" : { },
  "id_str" : "402231359579508736",
  "in_reply_to_user_id" : 160284136,
  "text" : "@jessmariex0 i used this to keep my archive updated &gt;&gt; http:\/\/t.co\/gvWhOu9VXx @CharlesBivona",
  "id" : 402231359579508736,
  "in_reply_to_status_id" : 402223827297763328,
  "created_at" : "2013-11-18 00:26:43 +0000",
  "in_reply_to_screen_name" : "jessmariex0",
  "in_reply_to_user_id_str" : "160284136",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u029D\u0454\u0455\u0455\u03B9\u00A2\u03B1 \u03B1\u044F\u043C\u0454\u0438\u0442\u03B9 \u2654",
      "screen_name" : "jessmariex0",
      "indices" : [ 0, 12 ],
      "id_str" : "160284136",
      "id" : 160284136
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 95, 109 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/N0LWWY0Ij6",
      "expanded_url" : "https:\/\/blog.twitter.com\/2012\/your-twitter-archive",
      "display_url" : "blog.twitter.com\/2012\/your-twit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402223827297763328",
  "geo" : { },
  "id_str" : "402230598430756865",
  "in_reply_to_user_id" : 160284136,
  "text" : "@jessmariex0 i think you can, if you request your archive from twitter https:\/\/t.co\/N0LWWY0Ij6 @CharlesBivona",
  "id" : 402230598430756865,
  "in_reply_to_status_id" : 402223827297763328,
  "created_at" : "2013-11-18 00:23:42 +0000",
  "in_reply_to_screen_name" : "jessmariex0",
  "in_reply_to_user_id_str" : "160284136",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theresa",
      "screen_name" : "theresamax",
      "indices" : [ 3, 14 ],
      "id_str" : "247744426",
      "id" : 247744426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402181716087144449",
  "text" : "RT @theresamax: \u201CRT ~ @Lily__lou: @Keikowmd Bonjour Keiko... http:\/\/t.co\/XUGGpGnn7C\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keiko *.\uFF61",
        "screen_name" : "Keikowmd",
        "indices" : [ 18, 27 ],
        "id_str" : "999681116",
        "id" : 999681116
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lily__lou\/status\/402098558246977537\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/XUGGpGnn7C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZSKgiGCAAAQ6NJ.jpg",
        "id_str" : "402098558255366144",
        "id" : 402098558255366144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZSKgiGCAAAQ6NJ.jpg",
        "sizes" : [ {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XUGGpGnn7C"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "402098558246977537",
    "geo" : { },
    "id_str" : "402180075258265600",
    "in_reply_to_user_id" : 1670794088,
    "text" : "\u201CRT ~ @Lily__lou: @Keikowmd Bonjour Keiko... http:\/\/t.co\/XUGGpGnn7C\u201D",
    "id" : 402180075258265600,
    "in_reply_to_status_id" : 402098558246977537,
    "created_at" : "2013-11-17 21:02:56 +0000",
    "in_reply_to_screen_name" : "2036June",
    "in_reply_to_user_id_str" : "1670794088",
    "user" : {
      "name" : "Theresa",
      "screen_name" : "theresamax",
      "protected" : false,
      "id_str" : "247744426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484633511648063488\/cpCE-N52_normal.jpeg",
      "id" : 247744426,
      "verified" : false
    }
  },
  "id" : 402181716087144449,
  "created_at" : "2013-11-17 21:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/XErJAhec1x",
      "expanded_url" : "http:\/\/disq.us\/8g7ime",
      "display_url" : "disq.us\/8g7ime"
    } ]
  },
  "geo" : { },
  "id_str" : "402179493843845120",
  "text" : "\"She would probably still be here today if she'd had Medicaid.\" http:\/\/t.co\/XErJAhec1x #ACA #SinglePayer",
  "id" : 402179493843845120,
  "created_at" : "2013-11-17 21:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/L61QXC9Goq",
      "expanded_url" : "http:\/\/www.texasobserver.org\/a-galveston-med-student-describes-life-and-death-in-the-safety-net\/#.UokqWBJcv8Y.twitter",
      "display_url" : "texasobserver.org\/a-galveston-me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402178039137570816",
  "text" : "Rick Perry.. damn you! &gt;&gt; A Galveston Med Student Describes Life and Death in the \"Safety Net\": http:\/\/t.co\/L61QXC9Goq",
  "id" : 402178039137570816,
  "created_at" : "2013-11-17 20:54:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "M Tramov",
      "screen_name" : "MTramov",
      "indices" : [ 79, 87 ],
      "id_str" : "20671248",
      "id" : 20671248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402136329263546368",
  "text" : "RT @ZachsMind: i dunno. i'm trapped in a subjective meat sack, same as you. RT @MTramov: and what truth is that?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "M Tramov",
        "screen_name" : "MTramov",
        "indices" : [ 64, 72 ],
        "id_str" : "20671248",
        "id" : 20671248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402134390655819776",
    "text" : "i dunno. i'm trapped in a subjective meat sack, same as you. RT @MTramov: and what truth is that?",
    "id" : 402134390655819776,
    "created_at" : "2013-11-17 18:01:24 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 402136329263546368,
  "created_at" : "2013-11-17 18:09:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Ping",
      "screen_name" : "SultanOfPing",
      "indices" : [ 110, 123 ],
      "id_str" : "1272487508",
      "id" : 1272487508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402133936601849856",
  "text" : "RT @ZachsMind: \"Careful men! He's got a feather! Anyone here ticklish?\" \"yeah!\" \"yes.\" \"ohmigawd\" \"momma!\" RT @SultanOfPing: http:\/\/t.co\/0K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ping",
        "screen_name" : "SultanOfPing",
        "indices" : [ 95, 108 ],
        "id_str" : "1272487508",
        "id" : 1272487508
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/0KXHRBNxYD",
        "expanded_url" : "https:\/\/twitter.com\/SultanOfPing\/status\/402126491711860736\/photo\/1",
        "display_url" : "pic.twitter.com\/0KXHRBNxYD"
      } ]
    },
    "geo" : { },
    "id_str" : "402132516540129280",
    "text" : "\"Careful men! He's got a feather! Anyone here ticklish?\" \"yeah!\" \"yes.\" \"ohmigawd\" \"momma!\" RT @SultanOfPing: http:\/\/t.co\/0KXHRBNxYD",
    "id" : 402132516540129280,
    "created_at" : "2013-11-17 17:53:57 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 402133936601849856,
  "created_at" : "2013-11-17 17:59:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402124698613317633",
  "text" : "regardless if Jackie shot him or not.. im wondering why before shot, he leans to her.. almost looks like he's not well.. just.. interesting",
  "id" : 402124698613317633,
  "created_at" : "2013-11-17 17:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/7wCZvSyua2",
      "expanded_url" : "http:\/\/youtu.be\/vsfRr6INwYk",
      "display_url" : "youtu.be\/vsfRr6INwYk"
    } ]
  },
  "geo" : { },
  "id_str" : "402123934184660993",
  "text" : "Assassins: Pt.1 Johnny And Jackie Did Johnny. Murder In Plain Sight: http:\/\/t.co\/7wCZvSyua2",
  "id" : 402123934184660993,
  "created_at" : "2013-11-17 17:19:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Zaruba",
      "screen_name" : "zenshine",
      "indices" : [ 3, 12 ],
      "id_str" : "17028156",
      "id" : 17028156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402121373839286272",
  "text" : "RT @zenshine: I have been a seeker and I still am,\nbut I stopped asking the books and the stars. I started listening to the teaching of my \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402120085097037824",
    "text" : "I have been a seeker and I still am,\nbut I stopped asking the books and the stars. I started listening to the teaching of my Soul. ~Rumi",
    "id" : 402120085097037824,
    "created_at" : "2013-11-17 17:04:33 +0000",
    "user" : {
      "name" : "Colleen Zaruba",
      "screen_name" : "zenshine",
      "protected" : false,
      "id_str" : "17028156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617125747719696384\/sdml83ut_normal.jpg",
      "id" : 17028156,
      "verified" : false
    }
  },
  "id" : 402121373839286272,
  "created_at" : "2013-11-17 17:09:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402114647588749312",
  "geo" : { },
  "id_str" : "402118317537648641",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time lately i have seen some theories.. oswald related to polio vaccine.. he was set up (knew too much) and another: Jackie O did it.",
  "id" : 402118317537648641,
  "in_reply_to_status_id" : 402114647588749312,
  "created_at" : "2013-11-17 16:57:32 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/9yubAkvoVG",
      "expanded_url" : "http:\/\/www.webmd.com\/oral-health\/guide\/temporomandibular-disorders",
      "display_url" : "webmd.com\/oral-health\/gu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402115806089072640",
  "text" : "i think my TMJ is irritated, not my ear.. &gt;&gt; http:\/\/t.co\/9yubAkvoVG",
  "id" : 402115806089072640,
  "created_at" : "2013-11-17 16:47:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NancyT",
      "screen_name" : "nlt5926",
      "indices" : [ 3, 11 ],
      "id_str" : "45878494",
      "id" : 45878494
    }, {
      "name" : "Theresa",
      "screen_name" : "theresamax",
      "indices" : [ 16, 27 ],
      "id_str" : "247744426",
      "id" : 247744426
    }, {
      "name" : "SALVA",
      "screen_name" : "salvado10903734",
      "indices" : [ 33, 49 ],
      "id_str" : "623239627",
      "id" : 623239627
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/salvado10903734\/status\/399880880635654144\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/gIqAuJUsf3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYypitMCMAAX1j8.jpg",
      "id_str" : "399880880639848448",
      "id" : 399880880639848448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYypitMCMAAX1j8.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gIqAuJUsf3"
    } ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402113707637215232",
  "text" : "RT @nlt5926: RT @theresamax: \u201CRT @salvado10903734: http:\/\/t.co\/gIqAuJUsf3 &gt; beautiful #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Theresa",
        "screen_name" : "theresamax",
        "indices" : [ 3, 14 ],
        "id_str" : "247744426",
        "id" : 247744426
      }, {
        "name" : "SALVA",
        "screen_name" : "salvado10903734",
        "indices" : [ 20, 36 ],
        "id_str" : "623239627",
        "id" : 623239627
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/salvado10903734\/status\/399880880635654144\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/gIqAuJUsf3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYypitMCMAAX1j8.jpg",
        "id_str" : "399880880639848448",
        "id" : 399880880639848448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYypitMCMAAX1j8.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 683
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 683
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gIqAuJUsf3"
      } ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "400019121339129856",
    "geo" : { },
    "id_str" : "401413688634396672",
    "in_reply_to_user_id" : 247744426,
    "text" : "RT @theresamax: \u201CRT @salvado10903734: http:\/\/t.co\/gIqAuJUsf3 &gt; beautiful #nature",
    "id" : 401413688634396672,
    "in_reply_to_status_id" : 400019121339129856,
    "created_at" : "2013-11-15 18:17:35 +0000",
    "in_reply_to_screen_name" : "theresamax",
    "in_reply_to_user_id_str" : "247744426",
    "user" : {
      "name" : "NancyT",
      "screen_name" : "nlt5926",
      "protected" : false,
      "id_str" : "45878494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788685188062740481\/4p1svqxS_normal.jpg",
      "id" : 45878494,
      "verified" : false
    }
  },
  "id" : 402113707637215232,
  "created_at" : "2013-11-17 16:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/zqoJBXwucG",
      "expanded_url" : "http:\/\/www.godvine.com\/Banker-Rescues-Ducklings-in-the-Most-Heartwarming-Way-1304.html#.UojlVwqgHW4.twitter",
      "display_url" : "godvine.com\/Banker-Rescues\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402101103073824768",
  "text" : "Banker Rescues Ducklings in the Most Heartwarming Way - Inspirational Video http:\/\/t.co\/zqoJBXwucG",
  "id" : 402101103073824768,
  "created_at" : "2013-11-17 15:49:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Left-Wing Teen",
      "screen_name" : "TeenProgressive",
      "indices" : [ 0, 16 ],
      "id_str" : "726957703",
      "id" : 726957703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401851516849778688",
  "geo" : { },
  "id_str" : "401856692712796160",
  "in_reply_to_user_id" : 726957703,
  "text" : "@TeenProgressive those figures makes sense since ppl have to fight tooth and nail to get things covered so more admin costs in private ins.",
  "id" : 401856692712796160,
  "in_reply_to_status_id" : 401851516849778688,
  "created_at" : "2013-11-16 23:37:56 +0000",
  "in_reply_to_screen_name" : "TeenProgressive",
  "in_reply_to_user_id_str" : "726957703",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 0, 9 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401831219232776193",
  "geo" : { },
  "id_str" : "401844848036020224",
  "in_reply_to_user_id" : 64009474,
  "text" : "@Adenovir they dont see it as a problem. they see healthcare as a privilege for those wealthy enough or get the right job.",
  "id" : 401844848036020224,
  "in_reply_to_status_id" : 401831219232776193,
  "created_at" : "2013-11-16 22:50:52 +0000",
  "in_reply_to_screen_name" : "Adenovir",
  "in_reply_to_user_id_str" : "64009474",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/puJWXlcvjc",
      "expanded_url" : "http:\/\/www.minds.com\/blog\/view\/248215469679448064\/german-town-abolishes-traffic-lights-and-codes-accidents-are-now-almost-non-existent",
      "display_url" : "minds.com\/blog\/view\/2482\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401831034137759744",
  "text" : "German town abolishes traffic lights and codes. Accidents are now almost non-existent! | Minds http:\/\/t.co\/puJWXlcvjc",
  "id" : 401831034137759744,
  "created_at" : "2013-11-16 21:55:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YellowstoneNPS",
      "screen_name" : "YellowstoneNPS",
      "indices" : [ 3, 18 ],
      "id_str" : "44992488",
      "id" : 44992488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gridlock",
      "indices" : [ 114, 123 ]
    }, {
      "text" : "trafficjam",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401771069184671744",
  "text" : "RT @YellowstoneNPS: \"Sorry honey, I'm going to be late. Traffic is bumper to bumper on the road to Mammoth.\" (nh) #gridlock #trafficjam htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YellowstoneNPS\/status\/401515052571701249\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/snocx7FU93",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZJ30CECMAAItvX.jpg",
        "id_str" : "401515052580089856",
        "id" : 401515052580089856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZJ30CECMAAItvX.jpg",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 813,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/snocx7FU93"
      } ],
      "hashtags" : [ {
        "text" : "gridlock",
        "indices" : [ 94, 103 ]
      }, {
        "text" : "trafficjam",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401515052571701249",
    "text" : "\"Sorry honey, I'm going to be late. Traffic is bumper to bumper on the road to Mammoth.\" (nh) #gridlock #trafficjam http:\/\/t.co\/snocx7FU93",
    "id" : 401515052571701249,
    "created_at" : "2013-11-16 01:00:23 +0000",
    "user" : {
      "name" : "YellowstoneNPS",
      "screen_name" : "YellowstoneNPS",
      "protected" : false,
      "id_str" : "44992488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000833279259\/f42e72461f57cfcef3c49a7883a5f5fc_normal.png",
      "id" : 44992488,
      "verified" : true
    }
  },
  "id" : 401771069184671744,
  "created_at" : "2013-11-16 17:57:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 0, 14 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401762377378430977",
  "geo" : { },
  "id_str" : "401770561333772288",
  "in_reply_to_user_id" : 109003770,
  "text" : "@CUMALi_YILDIZ awww...",
  "id" : 401770561333772288,
  "in_reply_to_status_id" : 401762377378430977,
  "created_at" : "2013-11-16 17:55:41 +0000",
  "in_reply_to_screen_name" : "CUMALi_YILDIZ",
  "in_reply_to_user_id_str" : "109003770",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401770118767988736",
  "text" : "RT @micahjmurray: Well, I guess that settles it? \/\/ Nigerian grad student uses magnets to 'prove' gay marriage is wrong &gt;&gt; http:\/\/t.co\/Z3Pf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Z3PfDFOK6n",
        "expanded_url" : "http:\/\/bit.ly\/18di9zQ",
        "display_url" : "bit.ly\/18di9zQ"
      } ]
    },
    "geo" : { },
    "id_str" : "401763942097514496",
    "text" : "Well, I guess that settles it? \/\/ Nigerian grad student uses magnets to 'prove' gay marriage is wrong &gt;&gt; http:\/\/t.co\/Z3PfDFOK6n",
    "id" : 401763942097514496,
    "created_at" : "2013-11-16 17:29:22 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 401770118767988736,
  "created_at" : "2013-11-16 17:53:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401769217470787584",
  "text" : "RT @Adenovir: Free market works for iPads and other widgets but in health care it means sick people die. @mancinibarbie @KennettDems @scien\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kennett Area Dems",
        "screen_name" : "KennettDems",
        "indices" : [ 106, 118 ],
        "id_str" : "959596692",
        "id" : 959596692
      }, {
        "name" : "Science Betty",
        "screen_name" : "sciencebetty",
        "indices" : [ 119, 132 ],
        "id_str" : "248469693",
        "id" : 248469693
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401765232307351552",
    "text" : "Free market works for iPads and other widgets but in health care it means sick people die. @mancinibarbie @KennettDems @sciencebetty",
    "id" : 401765232307351552,
    "created_at" : "2013-11-16 17:34:30 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 401769217470787584,
  "created_at" : "2013-11-16 17:50:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "diane straub",
      "screen_name" : "didikins4life",
      "indices" : [ 3, 17 ],
      "id_str" : "22831232",
      "id" : 22831232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/W8mFVXcXoO",
      "expanded_url" : "http:\/\/freakoutnation.com\/2013\/11\/15\/what-a-douche-texas-schools-christian-dating-coach-advises-girls-to-shut-the-fck-up\/",
      "display_url" : "freakoutnation.com\/2013\/11\/15\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401758629642403840",
  "text" : "RT @didikins4life: What a douche: Texas school\u2019s \u2018Christian\u2019 dating coach advises girls to shut the f*ck up -  http:\/\/t.co\/W8mFVXcXoO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/W8mFVXcXoO",
        "expanded_url" : "http:\/\/freakoutnation.com\/2013\/11\/15\/what-a-douche-texas-schools-christian-dating-coach-advises-girls-to-shut-the-fck-up\/",
        "display_url" : "freakoutnation.com\/2013\/11\/15\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401749278604816384",
    "text" : "What a douche: Texas school\u2019s \u2018Christian\u2019 dating coach advises girls to shut the f*ck up -  http:\/\/t.co\/W8mFVXcXoO",
    "id" : 401749278604816384,
    "created_at" : "2013-11-16 16:31:06 +0000",
    "user" : {
      "name" : "diane straub",
      "screen_name" : "didikins4life",
      "protected" : false,
      "id_str" : "22831232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689643909736169472\/8NCHCNao_normal.jpg",
      "id" : 22831232,
      "verified" : false
    }
  },
  "id" : 401758629642403840,
  "created_at" : "2013-11-16 17:08:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DakDcjQGXT",
      "expanded_url" : "http:\/\/www.nationalmemo.com\/shocker-obamacare-is-working-best-in-states-that-arent-trying-to-sabotage-it\/",
      "display_url" : "nationalmemo.com\/shocker-obamac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401753094369079296",
  "text" : "RT @LOLGOP: SHOCKER: Obamacare Is Working Best In States That Aren\u2019t Trying To Sabotage It http:\/\/t.co\/DakDcjQGXT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/DakDcjQGXT",
        "expanded_url" : "http:\/\/www.nationalmemo.com\/shocker-obamacare-is-working-best-in-states-that-arent-trying-to-sabotage-it\/",
        "display_url" : "nationalmemo.com\/shocker-obamac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401538482008358912",
    "text" : "SHOCKER: Obamacare Is Working Best In States That Aren\u2019t Trying To Sabotage It http:\/\/t.co\/DakDcjQGXT",
    "id" : 401538482008358912,
    "created_at" : "2013-11-16 02:33:28 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 401753094369079296,
  "created_at" : "2013-11-16 16:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Posttime7777",
      "screen_name" : "Posttime7777",
      "indices" : [ 3, 16 ],
      "id_str" : "864623053",
      "id" : 864623053
    }, {
      "name" : "L G J",
      "screen_name" : "wcgirl1",
      "indices" : [ 18, 26 ],
      "id_str" : "146060152",
      "id" : 146060152
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Posttime7777\/status\/401719144724189185\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/O9krPPtU2p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZMxbwkCUAE7VLZ.jpg",
      "id_str" : "401719144728383489",
      "id" : 401719144728383489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZMxbwkCUAE7VLZ.jpg",
      "sizes" : [ {
        "h" : 311,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 608
      } ],
      "display_url" : "pic.twitter.com\/O9krPPtU2p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401734324783185921",
  "text" : "RT @Posttime7777: @wcgirl1 tell congress this is just wrong http:\/\/t.co\/O9krPPtU2p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "L G J",
        "screen_name" : "wcgirl1",
        "indices" : [ 0, 8 ],
        "id_str" : "146060152",
        "id" : 146060152
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Posttime7777\/status\/401719144724189185\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/O9krPPtU2p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZMxbwkCUAE7VLZ.jpg",
        "id_str" : "401719144728383489",
        "id" : 401719144728383489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZMxbwkCUAE7VLZ.jpg",
        "sizes" : [ {
          "h" : 311,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 608
        } ],
        "display_url" : "pic.twitter.com\/O9krPPtU2p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "401718500747526145",
    "geo" : { },
    "id_str" : "401719144724189185",
    "in_reply_to_user_id" : 146060152,
    "text" : "@wcgirl1 tell congress this is just wrong http:\/\/t.co\/O9krPPtU2p",
    "id" : 401719144724189185,
    "in_reply_to_status_id" : 401718500747526145,
    "created_at" : "2013-11-16 14:31:22 +0000",
    "in_reply_to_screen_name" : "wcgirl1",
    "in_reply_to_user_id_str" : "146060152",
    "user" : {
      "name" : "Posttime7777",
      "screen_name" : "Posttime7777",
      "protected" : false,
      "id_str" : "864623053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709827110567698432\/FC4iV4Yu_normal.jpg",
      "id" : 864623053,
      "verified" : false
    }
  },
  "id" : 401734324783185921,
  "created_at" : "2013-11-16 15:31:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UV",
      "screen_name" : "UltraVerified",
      "indices" : [ 3, 17 ],
      "id_str" : "25508307",
      "id" : 25508307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401734118507302912",
  "text" : "RT @UltraVerified: 19 yo black girl shot dead while going for help after car accident:corpse tested for drugs.\n\nShooter? He was white.\n\nAny\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401590231003963392",
    "text" : "19 yo black girl shot dead while going for help after car accident:corpse tested for drugs.\n\nShooter? He was white.\n\nAny questions, America?",
    "id" : 401590231003963392,
    "created_at" : "2013-11-16 05:59:06 +0000",
    "user" : {
      "name" : "UV",
      "screen_name" : "UltraVerified",
      "protected" : false,
      "id_str" : "25508307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480516510440374272\/K33nB1CJ_normal.jpeg",
      "id" : 25508307,
      "verified" : false
    }
  },
  "id" : 401734118507302912,
  "created_at" : "2013-11-16 15:30:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401732216352296960",
  "geo" : { },
  "id_str" : "401733963829350400",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits i like!",
  "id" : 401733963829350400,
  "in_reply_to_status_id" : 401732216352296960,
  "created_at" : "2013-11-16 15:30:15 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/CDyJ0dlpru",
      "expanded_url" : "http:\/\/claireconner.com\/2013\/08\/30\/one-womans-heart-from-pro-life-to-choice\/",
      "display_url" : "claireconner.com\/2013\/08\/30\/one\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401732050002001920",
  "text" : "One Woman\u2019s Heart: From Pro-life to Choice http:\/\/t.co\/CDyJ0dlpru",
  "id" : 401732050002001920,
  "created_at" : "2013-11-16 15:22:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401723486009163776",
  "text" : "still got the weird crunchy ear thing going on...",
  "id" : 401723486009163776,
  "created_at" : "2013-11-16 14:48:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 13, 25 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401491356771962880",
  "geo" : { },
  "id_str" : "401517157286043648",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline @VirgoJohnny lol.. wth is wrong with hugging trees?? (or any of those things, well, except for joining cults..)",
  "id" : 401517157286043648,
  "in_reply_to_status_id" : 401491356771962880,
  "created_at" : "2013-11-16 01:08:44 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jadedjenny",
      "screen_name" : "jadedjenny71",
      "indices" : [ 3, 16 ],
      "id_str" : "143521190",
      "id" : 143521190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jadedjenny71\/status\/401495331281448960\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/YTluzeBCpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZJl4F7CQAAsjbx.jpg",
      "id_str" : "401495331126263808",
      "id" : 401495331126263808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZJl4F7CQAAsjbx.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YTluzeBCpA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401514315557396480",
  "text" : "RT @jadedjenny71: They got THIS guy to speak about how to be \"dateable\"?... http:\/\/t.co\/YTluzeBCpA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jadedjenny71\/status\/401495331281448960\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/YTluzeBCpA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZJl4F7CQAAsjbx.jpg",
        "id_str" : "401495331126263808",
        "id" : 401495331126263808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZJl4F7CQAAsjbx.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YTluzeBCpA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401495331281448960",
    "text" : "They got THIS guy to speak about how to be \"dateable\"?... http:\/\/t.co\/YTluzeBCpA",
    "id" : 401495331281448960,
    "created_at" : "2013-11-15 23:42:01 +0000",
    "user" : {
      "name" : "jadedjenny",
      "screen_name" : "jadedjenny71",
      "protected" : false,
      "id_str" : "143521190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015512308813824\/bMjE63Qf_normal.jpg",
      "id" : 143521190,
      "verified" : false
    }
  },
  "id" : 401514315557396480,
  "created_at" : "2013-11-16 00:57:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Spencer",
      "screen_name" : "libbyspencer",
      "indices" : [ 3, 16 ],
      "id_str" : "53257286",
      "id" : 53257286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401507745243086850",
  "text" : "RT @libbyspencer: Talked to a MD today who works in a reduced Medicaid state. It's essentially a death sentence for the hospitals and the p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401496821815463936",
    "text" : "Talked to a MD today who works in a reduced Medicaid state. It's essentially a death sentence for the hospitals and the poor patients. #ACA",
    "id" : 401496821815463936,
    "created_at" : "2013-11-15 23:47:56 +0000",
    "user" : {
      "name" : "Libby Spencer",
      "screen_name" : "libbyspencer",
      "protected" : false,
      "id_str" : "53257286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647924861285720064\/uoG9TX0o_normal.jpg",
      "id" : 53257286,
      "verified" : false
    }
  },
  "id" : 401507745243086850,
  "created_at" : "2013-11-16 00:31:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You know who",
      "screen_name" : "1whoknu",
      "indices" : [ 3, 11 ],
      "id_str" : "69487701",
      "id" : 69487701
    }, {
      "name" : "Bontesla",
      "screen_name" : "Bontesla",
      "indices" : [ 16, 25 ],
      "id_str" : "2511519631",
      "id" : 2511519631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/o36DuKOS7Y",
      "expanded_url" : "http:\/\/m.dailykos.com\/story\/2009\/06\/23\/746091\/-CBO-Analysis-How-Much-Would-Single-Payer-Cost-updatex2",
      "display_url" : "m.dailykos.com\/story\/2009\/06\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401506869187194880",
  "text" : "RT @1whoknu: RT @Bontesla: A single payer system would cost less than 180 per month http:\/\/t.co\/o36DuKOS7Y | but who will think of the insu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bontesla",
        "screen_name" : "Bontesla",
        "indices" : [ 3, 12 ],
        "id_str" : "2511519631",
        "id" : 2511519631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/o36DuKOS7Y",
        "expanded_url" : "http:\/\/m.dailykos.com\/story\/2009\/06\/23\/746091\/-CBO-Analysis-How-Much-Would-Single-Payer-Cost-updatex2",
        "display_url" : "m.dailykos.com\/story\/2009\/06\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401471358267187200",
    "text" : "RT @Bontesla: A single payer system would cost less than 180 per month http:\/\/t.co\/o36DuKOS7Y | but who will think of the insurance co.'s?",
    "id" : 401471358267187200,
    "created_at" : "2013-11-15 22:06:45 +0000",
    "user" : {
      "name" : "You know who",
      "screen_name" : "1whoknu",
      "protected" : false,
      "id_str" : "69487701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574219418474938368\/44SVlVTe_normal.jpeg",
      "id" : 69487701,
      "verified" : false
    }
  },
  "id" : 401506869187194880,
  "created_at" : "2013-11-16 00:27:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 0, 9 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401503124365795328",
  "geo" : { },
  "id_str" : "401505032731758592",
  "in_reply_to_user_id" : 13112692,
  "text" : "@gemswinc : (",
  "id" : 401505032731758592,
  "in_reply_to_status_id" : 401503124365795328,
  "created_at" : "2013-11-16 00:20:34 +0000",
  "in_reply_to_screen_name" : "gemswinc",
  "in_reply_to_user_id_str" : "13112692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Constantine",
      "screen_name" : "th628406",
      "indices" : [ 22, 31 ],
      "id_str" : "397307128",
      "id" : 397307128
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/th628406\/status\/400292059279405056\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/nZAPVYvDFq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY4fgcmCIAE5YK0.jpg",
      "id_str" : "400292059174543361",
      "id" : 400292059174543361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY4fgcmCIAE5YK0.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 674
      } ],
      "display_url" : "pic.twitter.com\/nZAPVYvDFq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400292059279405056",
  "geo" : { },
  "id_str" : "401492013700247552",
  "in_reply_to_user_id" : 397307128,
  "text" : "omg.. awesome pic! RT @th628406 http:\/\/t.co\/nZAPVYvDFq",
  "id" : 401492013700247552,
  "in_reply_to_status_id" : 400292059279405056,
  "created_at" : "2013-11-15 23:28:50 +0000",
  "in_reply_to_screen_name" : "th628406",
  "in_reply_to_user_id_str" : "397307128",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 3, 18 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freebook",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/HgefFeqH41",
      "expanded_url" : "http:\/\/www.heatherwardell.com\/giveaway.shtml",
      "display_url" : "heatherwardell.com\/giveaway.shtml"
    } ]
  },
  "geo" : { },
  "id_str" : "401486652641918976",
  "text" : "RT @HeatherWardell: Want to win my new novel, \"Fifty Million Reasons\"? Visit http:\/\/t.co\/HgefFeqH41 by Nov 16th to enter! Pls RT! #freebook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freebook",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/HgefFeqH41",
        "expanded_url" : "http:\/\/www.heatherwardell.com\/giveaway.shtml",
        "display_url" : "heatherwardell.com\/giveaway.shtml"
      } ]
    },
    "geo" : { },
    "id_str" : "400991972720001024",
    "text" : "Want to win my new novel, \"Fifty Million Reasons\"? Visit http:\/\/t.co\/HgefFeqH41 by Nov 16th to enter! Pls RT! #freebook",
    "id" : 400991972720001024,
    "created_at" : "2013-11-14 14:21:51 +0000",
    "user" : {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "protected" : false,
      "id_str" : "155212706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774370444124295169\/k7AWAU4H_normal.jpg",
      "id" : 155212706,
      "verified" : false
    }
  },
  "id" : 401486652641918976,
  "created_at" : "2013-11-15 23:07:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401450527143108608",
  "text" : "marsha blackburn does not want PBO to use his magic wand..lol",
  "id" : 401450527143108608,
  "created_at" : "2013-11-15 20:43:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401447580095479809",
  "text" : "RT @AllOnMedicare: The #SinglePayer movement is growing in the USA and on Twitter. Can we make #SinglePayer trend today? #TeamSinglePayerHe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 4, 16 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 76, 88 ]
      }, {
        "text" : "TeamSinglePayerHealthCare",
        "indices" : [ 102, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401444074407747584",
    "text" : "The #SinglePayer movement is growing in the USA and on Twitter. Can we make #SinglePayer trend today? #TeamSinglePayerHealthCare",
    "id" : 401444074407747584,
    "created_at" : "2013-11-15 20:18:20 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 401447580095479809,
  "created_at" : "2013-11-15 20:32:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James",
      "screen_name" : "jazgar",
      "indices" : [ 3, 10 ],
      "id_str" : "17845639",
      "id" : 17845639
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 101, 104 ]
    }, {
      "text" : "tcot",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3b9OuQvjTi",
      "expanded_url" : "http:\/\/feedly.com\/k\/17yvYKz",
      "display_url" : "feedly.com\/k\/17yvYKz"
    } ]
  },
  "geo" : { },
  "id_str" : "401438468750188544",
  "text" : "RT @jazgar: Stabilized Footage of the JFK Assassination Is Unsettlingly Real http:\/\/t.co\/3b9OuQvjTi  #p2 #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.feedly.com\" rel=\"nofollow\"\u003Efeedly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 89, 92 ]
      }, {
        "text" : "tcot",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/3b9OuQvjTi",
        "expanded_url" : "http:\/\/feedly.com\/k\/17yvYKz",
        "display_url" : "feedly.com\/k\/17yvYKz"
      } ]
    },
    "geo" : { },
    "id_str" : "401430777985892352",
    "text" : "Stabilized Footage of the JFK Assassination Is Unsettlingly Real http:\/\/t.co\/3b9OuQvjTi  #p2 #tcot",
    "id" : 401430777985892352,
    "created_at" : "2013-11-15 19:25:30 +0000",
    "user" : {
      "name" : "James",
      "screen_name" : "jazgar",
      "protected" : false,
      "id_str" : "17845639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3531762798\/965a3a1fe3de0dc94cc41970131c0690_normal.jpeg",
      "id" : 17845639,
      "verified" : false
    }
  },
  "id" : 401438468750188544,
  "created_at" : "2013-11-15 19:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NancyT",
      "screen_name" : "nlt5926",
      "indices" : [ 3, 11 ],
      "id_str" : "45878494",
      "id" : 45878494
    }, {
      "name" : "Donald Cottner",
      "screen_name" : "dc_designworks",
      "indices" : [ 16, 31 ],
      "id_str" : "167298434",
      "id" : 167298434
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dc_designworks\/status\/401172348419575809\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/BwnpDeiiAY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZFAIBMCAAATZmO.jpg",
      "id_str" : "401172348314714112",
      "id" : 401172348314714112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZFAIBMCAAATZmO.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BwnpDeiiAY"
    } ],
    "hashtags" : [ {
      "text" : "followart",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401435721476878336",
  "text" : "RT @nlt5926: RT @dc_designworks: Bamboo forest in Japan~ http:\/\/t.co\/BwnpDeiiAY &gt; amazing! #followart",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald Cottner",
        "screen_name" : "dc_designworks",
        "indices" : [ 3, 18 ],
        "id_str" : "167298434",
        "id" : 167298434
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dc_designworks\/status\/401172348419575809\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/BwnpDeiiAY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZFAIBMCAAATZmO.jpg",
        "id_str" : "401172348314714112",
        "id" : 401172348314714112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZFAIBMCAAATZmO.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BwnpDeiiAY"
      } ],
      "hashtags" : [ {
        "text" : "followart",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "401172348419575809",
    "geo" : { },
    "id_str" : "401425845686136832",
    "in_reply_to_user_id" : 167298434,
    "text" : "RT @dc_designworks: Bamboo forest in Japan~ http:\/\/t.co\/BwnpDeiiAY &gt; amazing! #followart",
    "id" : 401425845686136832,
    "in_reply_to_status_id" : 401172348419575809,
    "created_at" : "2013-11-15 19:05:54 +0000",
    "in_reply_to_screen_name" : "dc_designworks",
    "in_reply_to_user_id_str" : "167298434",
    "user" : {
      "name" : "NancyT",
      "screen_name" : "nlt5926",
      "protected" : false,
      "id_str" : "45878494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788685188062740481\/4p1svqxS_normal.jpg",
      "id" : 45878494,
      "verified" : false
    }
  },
  "id" : 401435721476878336,
  "created_at" : "2013-11-15 19:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 105, 117 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/EHm2KL11JA",
      "expanded_url" : "http:\/\/kck.st\/1fE7rUq",
      "display_url" : "kck.st\/1fE7rUq"
    } ]
  },
  "geo" : { },
  "id_str" : "401424585607757825",
  "text" : "play digital ios\/googleplay\/kindlefire - 4 Thrones Playing Cards by Kurt Bieg http:\/\/t.co\/EHm2KL11JA via @kickstarter",
  "id" : 401424585607757825,
  "created_at" : "2013-11-15 19:00:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Valley Forge",
      "screen_name" : "Ruffdogchance",
      "indices" : [ 17, 31 ],
      "id_str" : "705019499",
      "id" : 705019499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401394305551851520",
  "text" : "RT @mindymayhem: @Ruffdogchance I call modern day slavery (NO comparison to actual slavery) working your ass off and not being able to feed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valley Forge",
        "screen_name" : "Ruffdogchance",
        "indices" : [ 0, 14 ],
        "id_str" : "705019499",
        "id" : 705019499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "401376321311215616",
    "geo" : { },
    "id_str" : "401382110662897664",
    "in_reply_to_user_id" : 705019499,
    "text" : "@Ruffdogchance I call modern day slavery (NO comparison to actual slavery) working your ass off and not being able to feed your family, hon.",
    "id" : 401382110662897664,
    "in_reply_to_status_id" : 401376321311215616,
    "created_at" : "2013-11-15 16:12:07 +0000",
    "in_reply_to_screen_name" : "Ruffdogchance",
    "in_reply_to_user_id_str" : "705019499",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 401394305551851520,
  "created_at" : "2013-11-15 17:00:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Valley Forge",
      "screen_name" : "Ruffdogchance",
      "indices" : [ 17, 31 ],
      "id_str" : "705019499",
      "id" : 705019499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401394251160121345",
  "text" : "RT @mindymayhem: @Ruffdogchance Yes. Because nothing says \"slavery\" quite like feeding the working poor and their kids. I bet you looooove \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valley Forge",
        "screen_name" : "Ruffdogchance",
        "indices" : [ 0, 14 ],
        "id_str" : "705019499",
        "id" : 705019499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "401376321311215616",
    "geo" : { },
    "id_str" : "401381540615041024",
    "in_reply_to_user_id" : 705019499,
    "text" : "@Ruffdogchance Yes. Because nothing says \"slavery\" quite like feeding the working poor and their kids. I bet you looooove fetuses, though!",
    "id" : 401381540615041024,
    "in_reply_to_status_id" : 401376321311215616,
    "created_at" : "2013-11-15 16:09:51 +0000",
    "in_reply_to_screen_name" : "Ruffdogchance",
    "in_reply_to_user_id_str" : "705019499",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 401394251160121345,
  "created_at" : "2013-11-15 17:00:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Valley Forge",
      "screen_name" : "Ruffdogchance",
      "indices" : [ 17, 31 ],
      "id_str" : "705019499",
      "id" : 705019499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401394195132608512",
  "text" : "RT @mindymayhem: @Ruffdogchance SNAP, as \"a career\"? Funny, I work full time, doing manual labor while standing on hard tile for over 8 hou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valley Forge",
        "screen_name" : "Ruffdogchance",
        "indices" : [ 0, 14 ],
        "id_str" : "705019499",
        "id" : 705019499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "401376321311215616",
    "geo" : { },
    "id_str" : "401381023423791104",
    "in_reply_to_user_id" : 705019499,
    "text" : "@Ruffdogchance SNAP, as \"a career\"? Funny, I work full time, doing manual labor while standing on hard tile for over 8 hours, 5 days a week.",
    "id" : 401381023423791104,
    "in_reply_to_status_id" : 401376321311215616,
    "created_at" : "2013-11-15 16:07:47 +0000",
    "in_reply_to_screen_name" : "Ruffdogchance",
    "in_reply_to_user_id_str" : "705019499",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 401394195132608512,
  "created_at" : "2013-11-15 17:00:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401392766694854656",
  "text" : "health insurance plans LIMIT which DR's you see! less choice! #SinglePayer",
  "id" : 401392766694854656,
  "created_at" : "2013-11-15 16:54:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "indices" : [ 3, 15 ],
      "id_str" : "2147864503",
      "id" : 2147864503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/401081512310751232\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2YE8TQnO51",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDtgqvCQAA13xh.jpg",
      "id_str" : "401081512319139840",
      "id" : 401081512319139840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDtgqvCQAA13xh.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/2YE8TQnO51"
    } ],
    "hashtags" : [ {
      "text" : "Birding",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401392240184287232",
  "text" : "RT @goodbirding: Cedar Waxwing doing it's best Hummingbird impression. #Birding http:\/\/t.co\/2YE8TQnO51",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/401081512310751232\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/2YE8TQnO51",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDtgqvCQAA13xh.jpg",
        "id_str" : "401081512319139840",
        "id" : 401081512319139840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDtgqvCQAA13xh.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/2YE8TQnO51"
      } ],
      "hashtags" : [ {
        "text" : "Birding",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401081512310751232",
    "text" : "Cedar Waxwing doing it's best Hummingbird impression. #Birding http:\/\/t.co\/2YE8TQnO51",
    "id" : 401081512310751232,
    "created_at" : "2013-11-14 20:17:39 +0000",
    "user" : {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "protected" : false,
      "id_str" : "2147864503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630185970\/5de84b9e4fc1f4fdba0d8f537c4d543e_normal.jpeg",
      "id" : 2147864503,
      "verified" : false
    }
  },
  "id" : 401392240184287232,
  "created_at" : "2013-11-15 16:52:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 0, 14 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401067672340668416",
  "geo" : { },
  "id_str" : "401391120464093185",
  "in_reply_to_user_id" : 109003770,
  "text" : "@CUMALi_YILDIZ precious : )",
  "id" : 401391120464093185,
  "in_reply_to_status_id" : 401067672340668416,
  "created_at" : "2013-11-15 16:47:55 +0000",
  "in_reply_to_screen_name" : "CUMALi_YILDIZ",
  "in_reply_to_user_id_str" : "109003770",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/401067672340668416\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/bSzMpWL6sB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDg7E0CIAAc8g0.jpg",
      "id_str" : "401067672344862720",
      "id" : 401067672344862720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDg7E0CIAAc8g0.jpg",
      "sizes" : [ {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/bSzMpWL6sB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401391042353971200",
  "text" : "RT @CUMALi_YILDIZ: http:\/\/t.co\/bSzMpWL6sB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/401067672340668416\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/bSzMpWL6sB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDg7E0CIAAc8g0.jpg",
        "id_str" : "401067672344862720",
        "id" : 401067672344862720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDg7E0CIAAc8g0.jpg",
        "sizes" : [ {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/bSzMpWL6sB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401067672340668416",
    "text" : "http:\/\/t.co\/bSzMpWL6sB",
    "id" : 401067672340668416,
    "created_at" : "2013-11-14 19:22:39 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 401391042353971200,
  "created_at" : "2013-11-15 16:47:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    }, {
      "name" : "Peaceful Revolution",
      "screen_name" : "Equalist_",
      "indices" : [ 16, 26 ],
      "id_str" : "1938115418",
      "id" : 1938115418
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Equalist_\/status\/398567232709861376\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KyFCodITp8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYf-yUoIIAAVxCd.jpg",
      "id_str" : "398567232529506304",
      "id" : 398567232529506304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYf-yUoIIAAVxCd.jpg",
      "sizes" : [ {
        "h" : 954,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 954,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KyFCodITp8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401374057423446016",
  "text" : "RT @drbloem: RT @Equalist_: Why do I have to go to school? http:\/\/t.co\/KyFCodITp8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peaceful Revolution",
        "screen_name" : "Equalist_",
        "indices" : [ 3, 13 ],
        "id_str" : "1938115418",
        "id" : 1938115418
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Equalist_\/status\/398567232709861376\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/KyFCodITp8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYf-yUoIIAAVxCd.jpg",
        "id_str" : "398567232529506304",
        "id" : 398567232529506304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYf-yUoIIAAVxCd.jpg",
        "sizes" : [ {
          "h" : 954,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 954,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KyFCodITp8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401373853609246720",
    "text" : "RT @Equalist_: Why do I have to go to school? http:\/\/t.co\/KyFCodITp8",
    "id" : 401373853609246720,
    "created_at" : "2013-11-15 15:39:18 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 401374057423446016,
  "created_at" : "2013-11-15 15:40:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Leia Cator",
      "screen_name" : "mscator",
      "indices" : [ 23, 31 ],
      "id_str" : "21659631",
      "id" : 21659631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mscator\/status\/401306163759046657\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9BDnKXytAd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZG51GAIAAAFEGJ.jpg",
      "id_str" : "401306163608027136",
      "id" : 401306163608027136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZG51GAIAAAFEGJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/9BDnKXytAd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401373531667431425",
  "text" : "RT @KerriFar: LOVE! RT @mscator: Morning poetry, lost in my photographs. Here's one I call \"Through the Trees:\" http:\/\/t.co\/9BDnKXytAd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leia Cator",
        "screen_name" : "mscator",
        "indices" : [ 9, 17 ],
        "id_str" : "21659631",
        "id" : 21659631
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mscator\/status\/401306163759046657\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/9BDnKXytAd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZG51GAIAAAFEGJ.jpg",
        "id_str" : "401306163608027136",
        "id" : 401306163608027136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZG51GAIAAAFEGJ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 774,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/9BDnKXytAd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401372920951615488",
    "text" : "LOVE! RT @mscator: Morning poetry, lost in my photographs. Here's one I call \"Through the Trees:\" http:\/\/t.co\/9BDnKXytAd",
    "id" : 401372920951615488,
    "created_at" : "2013-11-15 15:35:36 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 401373531667431425,
  "created_at" : "2013-11-15 15:38:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401372100025663488",
  "geo" : { },
  "id_str" : "401373324145467392",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell ahh, i see what you're getting at. for some reason, im not seeing it that way (abandoning logic)",
  "id" : 401373324145467392,
  "in_reply_to_status_id" : 401372100025663488,
  "created_at" : "2013-11-15 15:37:12 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyssa Farah",
      "screen_name" : "Alyssafarah",
      "indices" : [ 3, 15 ],
      "id_str" : "37841185",
      "id" : 37841185
    }, {
      "name" : "Free Beacon",
      "screen_name" : "FreeBeacon",
      "indices" : [ 128, 139 ],
      "id_str" : "455764741",
      "id" : 455764741
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hillary2016",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/3yymxGWkZ8",
      "expanded_url" : "http:\/\/bit.ly\/1d1YIO8",
      "display_url" : "bit.ly\/1d1YIO8"
    } ]
  },
  "geo" : { },
  "id_str" : "401370082087301120",
  "text" : "RT @Alyssafarah: ICYMI: Top Clinton aide publicly advocates for single-payer healthcare #Hillary2016 http:\/\/t.co\/3yymxGWkZ8 via @FreeBeacon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Free Beacon",
        "screen_name" : "FreeBeacon",
        "indices" : [ 111, 122 ],
        "id_str" : "455764741",
        "id" : 455764741
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hillary2016",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/3yymxGWkZ8",
        "expanded_url" : "http:\/\/bit.ly\/1d1YIO8",
        "display_url" : "bit.ly\/1d1YIO8"
      } ]
    },
    "geo" : { },
    "id_str" : "401367111768891392",
    "text" : "ICYMI: Top Clinton aide publicly advocates for single-payer healthcare #Hillary2016 http:\/\/t.co\/3yymxGWkZ8 via @FreeBeacon",
    "id" : 401367111768891392,
    "created_at" : "2013-11-15 15:12:31 +0000",
    "user" : {
      "name" : "Alyssa Farah",
      "screen_name" : "Alyssafarah",
      "protected" : false,
      "id_str" : "37841185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764471571276705793\/Jz8y6xGL_normal.jpg",
      "id" : 37841185,
      "verified" : false
    }
  },
  "id" : 401370082087301120,
  "created_at" : "2013-11-15 15:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401369586374701056",
  "text" : "this is mean but.. i do not like marsha blackburn at all. she thinks she's all that.",
  "id" : 401369586374701056,
  "created_at" : "2013-11-15 15:22:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401099315436744704",
  "geo" : { },
  "id_str" : "401369341800611840",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell is mistaken? do you mean because it doesn't need to be \"either\/or\" (which i agree)",
  "id" : 401369341800611840,
  "in_reply_to_status_id" : 401099315436744704,
  "created_at" : "2013-11-15 15:21:22 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401095835108143104",
  "geo" : { },
  "id_str" : "401368624880840704",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell he's asking questions.. trying to make sense of this crazy world and so many different world views...",
  "id" : 401368624880840704,
  "in_reply_to_status_id" : 401095835108143104,
  "created_at" : "2013-11-15 15:18:31 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LION",
      "screen_name" : "LIONS4Mercy",
      "indices" : [ 3, 15 ],
      "id_str" : "977580523",
      "id" : 977580523
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LIONS4Mercy\/status\/400860419419832320\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/9aUqvwBUFh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZAkbXCIUAEgnbB.jpg",
      "id_str" : "400860419293990913",
      "id" : 400860419293990913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZAkbXCIUAEgnbB.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 619
      } ],
      "display_url" : "pic.twitter.com\/9aUqvwBUFh"
    } ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401129361887481856",
  "text" : "RT @LIONS4Mercy: RT if you agree! #Blackfish http:\/\/t.co\/9aUqvwBUFh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LIONS4Mercy\/status\/400860419419832320\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/9aUqvwBUFh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZAkbXCIUAEgnbB.jpg",
        "id_str" : "400860419293990913",
        "id" : 400860419293990913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZAkbXCIUAEgnbB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 619
        } ],
        "display_url" : "pic.twitter.com\/9aUqvwBUFh"
      } ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400860419419832320",
    "text" : "RT if you agree! #Blackfish http:\/\/t.co\/9aUqvwBUFh",
    "id" : 400860419419832320,
    "created_at" : "2013-11-14 05:39:06 +0000",
    "user" : {
      "name" : "LION",
      "screen_name" : "LIONS4Mercy",
      "protected" : false,
      "id_str" : "977580523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616004966789025793\/dv6IVe9S_normal.jpg",
      "id" : 977580523,
      "verified" : false
    }
  },
  "id" : 401129361887481856,
  "created_at" : "2013-11-14 23:27:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401121258625966081",
  "text" : "very nervous.. discomfort in right jaw, yesterday and today. makes crunchy noise when rubbed. moisture says hubby. poss earache.. ugh.",
  "id" : 401121258625966081,
  "created_at" : "2013-11-14 22:55:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "indices" : [ 3, 14 ],
      "id_str" : "417189310",
      "id" : 417189310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401095849893453824",
  "text" : "RT @DianeJReed: You don't #love someone for their looks, clothes or fancy car but because they sing a song only you can hear http:\/\/t.co\/Ks\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DianeJReed\/status\/401095328016789504\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/KsCwWZh8tN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZD6E1qCUAARGoR.jpg",
        "id_str" : "401095327865786368",
        "id" : 401095327865786368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZD6E1qCUAARGoR.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/KsCwWZh8tN"
      } ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 10, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401095328016789504",
    "text" : "You don't #love someone for their looks, clothes or fancy car but because they sing a song only you can hear http:\/\/t.co\/KsCwWZh8tN",
    "id" : 401095328016789504,
    "created_at" : "2013-11-14 21:12:32 +0000",
    "user" : {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "protected" : false,
      "id_str" : "417189310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695055759181160448\/du6nVVbQ_normal.jpg",
      "id" : 417189310,
      "verified" : false
    }
  },
  "id" : 401095849893453824,
  "created_at" : "2013-11-14 21:14:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401092679871627265",
  "text" : "@Skeptical_Lady LOL",
  "id" : 401092679871627265,
  "created_at" : "2013-11-14 21:02:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    }, {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 24, 37 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 41, 56 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401090024131018752",
  "geo" : { },
  "id_str" : "401092451059773440",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell perhaps @micahjmurray or @AnnotatedBible will chime in if they know. (my thought, too, did it go back that far..)",
  "id" : 401092451059773440,
  "in_reply_to_status_id" : 401090024131018752,
  "created_at" : "2013-11-14 21:01:06 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401087375398281217",
  "geo" : { },
  "id_str" : "401088648143073281",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell who's on first? LOLOL .. just saw your post regarding right-hand\/left-hand .. makes sense.",
  "id" : 401088648143073281,
  "in_reply_to_status_id" : 401087375398281217,
  "created_at" : "2013-11-14 20:46:00 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401085305890947072",
  "geo" : { },
  "id_str" : "401086280022249472",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell i suspect they were chosen specifically.. yes, why?",
  "id" : 401086280022249472,
  "in_reply_to_status_id" : 401085305890947072,
  "created_at" : "2013-11-14 20:36:35 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401078792262656000",
  "geo" : { },
  "id_str" : "401085001560649728",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell perhaps just symbols for opposites? hmm.. i wonder, too..",
  "id" : 401085001560649728,
  "in_reply_to_status_id" : 401078792262656000,
  "created_at" : "2013-11-14 20:31:30 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ocean Advocate News",
      "screen_name" : "oceanadvocatefl",
      "indices" : [ 3, 19 ],
      "id_str" : "1099592130",
      "id" : 1099592130
    }, {
      "name" : "Tilikum",
      "screen_name" : "WhaleTilikum",
      "indices" : [ 21, 34 ],
      "id_str" : "274564981",
      "id" : 274564981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/oceanadvocatefl\/status\/399182499206922240\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/hLw7V7AFZI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYouXiuIQAAXuI4.jpg",
      "id_str" : "399182498967863296",
      "id" : 399182498967863296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYouXiuIQAAXuI4.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1840,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hLw7V7AFZI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401063026826444800",
  "text" : "RT @oceanadvocatefl: @WhaleTilikum You were stolen from your family 30 years ago today http:\/\/t.co\/hLw7V7AFZI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tilikum",
        "screen_name" : "WhaleTilikum",
        "indices" : [ 0, 13 ],
        "id_str" : "274564981",
        "id" : 274564981
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oceanadvocatefl\/status\/399182499206922240\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/hLw7V7AFZI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYouXiuIQAAXuI4.jpg",
        "id_str" : "399182498967863296",
        "id" : 399182498967863296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYouXiuIQAAXuI4.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1840,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hLw7V7AFZI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399182499206922240",
    "in_reply_to_user_id" : 274564981,
    "text" : "@WhaleTilikum You were stolen from your family 30 years ago today http:\/\/t.co\/hLw7V7AFZI",
    "id" : 399182499206922240,
    "created_at" : "2013-11-09 14:31:38 +0000",
    "in_reply_to_screen_name" : "WhaleTilikum",
    "in_reply_to_user_id_str" : "274564981",
    "user" : {
      "name" : "Ocean Advocate News",
      "screen_name" : "oceanadvocatefl",
      "protected" : false,
      "id_str" : "1099592130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549769878421245952\/ee0ld_IO_normal.jpeg",
      "id" : 1099592130,
      "verified" : false
    }
  },
  "id" : 401063026826444800,
  "created_at" : "2013-11-14 19:04:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401055838497824768",
  "text" : "the more i let myself become of the world, the angrier i get. much more peaceful going w the flow. interesting...",
  "id" : 401055838497824768,
  "created_at" : "2013-11-14 18:35:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LibrarianShipwreck",
      "screen_name" : "libshipwreck",
      "indices" : [ 3, 16 ],
      "id_str" : "1143288666",
      "id" : 1143288666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "ACA",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401044753237938176",
  "text" : "RT @libshipwreck: The way to \"fix\" #Obamacare is called #singlepayer. The #ACA is a bailout for the for-profit health insurance industry.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 38, 50 ]
      }, {
        "text" : "ACA",
        "indices" : [ 56, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401040195320958976",
    "text" : "The way to \"fix\" #Obamacare is called #singlepayer. The #ACA is a bailout for the for-profit health insurance industry.",
    "id" : 401040195320958976,
    "created_at" : "2013-11-14 17:33:28 +0000",
    "user" : {
      "name" : "LibrarianShipwreck",
      "screen_name" : "libshipwreck",
      "protected" : false,
      "id_str" : "1143288666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248710190\/dc853bf46f9bd1d9335e2fc2482fe87b_normal.jpeg",
      "id" : 1143288666,
      "verified" : false
    }
  },
  "id" : 401044753237938176,
  "created_at" : "2013-11-14 17:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Corn",
      "screen_name" : "DavidCornDC",
      "indices" : [ 3, 15 ],
      "id_str" : "15220768",
      "id" : 15220768
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 18, 33 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401037147337420801",
  "text" : "RT @DavidCornDC: .@SpeakerBoehner, if US hlth system is No. 1, why is US 51st in life expectancy (behind Greece, Puerto Rico, Jordan) https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 1, 16 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/eGWHoDxtbS",
        "expanded_url" : "https:\/\/www.cia.gov\/library\/publications\/the-world-factbook\/rankorder\/2102rank.html",
        "display_url" : "cia.gov\/library\/public\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401035620128006144",
    "text" : ".@SpeakerBoehner, if US hlth system is No. 1, why is US 51st in life expectancy (behind Greece, Puerto Rico, Jordan) https:\/\/t.co\/eGWHoDxtbS",
    "id" : 401035620128006144,
    "created_at" : "2013-11-14 17:15:17 +0000",
    "user" : {
      "name" : "David Corn",
      "screen_name" : "DavidCornDC",
      "protected" : false,
      "id_str" : "15220768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431276795216678912\/K9GgLuad_normal.png",
      "id" : 15220768,
      "verified" : true
    }
  },
  "id" : 401037147337420801,
  "created_at" : "2013-11-14 17:21:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birmingham Donkeys",
      "screen_name" : "BhamDonkeys",
      "indices" : [ 3, 15 ],
      "id_str" : "947681610",
      "id" : 947681610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adoptadonkey",
      "indices" : [ 38, 51 ]
    }, {
      "text" : "Christmas",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/dKQibVkxey",
      "expanded_url" : "http:\/\/www.adoptadonkey.org.uk\/index.html",
      "display_url" : "adoptadonkey.org.uk\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "401027808866336769",
  "text" : "RT @BhamDonkeys: Love anyone enough?  #adoptadonkey ideal Birthday #Christmas gift, any age, 6 UK locations http:\/\/t.co\/dKQibVkxey http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BhamDonkeys\/status\/400960175810433024\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/CvXSFjMqMx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZB_J9DCUAECLzd.jpg",
        "id_str" : "400960175818821633",
        "id" : 400960175818821633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZB_J9DCUAECLzd.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CvXSFjMqMx"
      } ],
      "hashtags" : [ {
        "text" : "adoptadonkey",
        "indices" : [ 21, 34 ]
      }, {
        "text" : "Christmas",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/dKQibVkxey",
        "expanded_url" : "http:\/\/www.adoptadonkey.org.uk\/index.html",
        "display_url" : "adoptadonkey.org.uk\/index.html"
      } ]
    },
    "geo" : { },
    "id_str" : "400960175810433024",
    "text" : "Love anyone enough?  #adoptadonkey ideal Birthday #Christmas gift, any age, 6 UK locations http:\/\/t.co\/dKQibVkxey http:\/\/t.co\/CvXSFjMqMx",
    "id" : 400960175810433024,
    "created_at" : "2013-11-14 12:15:30 +0000",
    "user" : {
      "name" : "Birmingham Donkeys",
      "screen_name" : "BhamDonkeys",
      "protected" : false,
      "id_str" : "947681610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793207940555603968\/5Dg4avYQ_normal.jpg",
      "id" : 947681610,
      "verified" : false
    }
  },
  "id" : 401027808866336769,
  "created_at" : "2013-11-14 16:44:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dominic dyer",
      "screen_name" : "domdyer70",
      "indices" : [ 3, 13 ],
      "id_str" : "566688127",
      "id" : 566688127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thewatermargin\/status\/399266715206684672\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/C8Vu9pNjI8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYp69jhIQAAopLx.jpg",
      "id_str" : "399266714900512768",
      "id" : 399266714900512768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYp69jhIQAAopLx.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/C8Vu9pNjI8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401027634593034240",
  "text" : "RT @domdyer70: Scratch my private parts &amp; put up two paws to NFU &amp; Paterson stop the crazy cruel badger cull http:\/\/t.co\/C8Vu9pNjI8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thewatermargin\/status\/399266715206684672\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/C8Vu9pNjI8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYp69jhIQAAopLx.jpg",
        "id_str" : "399266714900512768",
        "id" : 399266714900512768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYp69jhIQAAopLx.jpg",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/C8Vu9pNjI8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401022985072812033",
    "text" : "Scratch my private parts &amp; put up two paws to NFU &amp; Paterson stop the crazy cruel badger cull http:\/\/t.co\/C8Vu9pNjI8",
    "id" : 401022985072812033,
    "created_at" : "2013-11-14 16:25:04 +0000",
    "user" : {
      "name" : "dominic dyer",
      "screen_name" : "domdyer70",
      "protected" : false,
      "id_str" : "566688127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569555444193296384\/liRrvIiO_normal.jpeg",
      "id" : 566688127,
      "verified" : false
    }
  },
  "id" : 401027634593034240,
  "created_at" : "2013-11-14 16:43:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401027481723207680",
  "text" : "RT @InvisCollege: Fear is the disease and love is the antidote. Min",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401024722936139776",
    "text" : "Fear is the disease and love is the antidote. Min",
    "id" : 401024722936139776,
    "created_at" : "2013-11-14 16:31:59 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 401027481723207680,
  "created_at" : "2013-11-14 16:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamSinglePayerHealthcare",
      "indices" : [ 10, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401007472468836352",
  "text" : "RT @wilw: #TeamSinglePayerHealthcare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamSinglePayerHealthcare",
        "indices" : [ 0, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400813996300705792",
    "text" : "#TeamSinglePayerHealthcare",
    "id" : 400813996300705792,
    "created_at" : "2013-11-14 02:34:38 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503013851631616\/55p1uw70_normal.jpg",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 401007472468836352,
  "created_at" : "2013-11-14 15:23:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 3, 12 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401002365975019520",
  "text" : "RT @Pontifex: Take care of God\u2019s creation.  But above all, take care of people in need.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400994197966057472",
    "text" : "Take care of God\u2019s creation.  But above all, take care of people in need.",
    "id" : 400994197966057472,
    "created_at" : "2013-11-14 14:30:41 +0000",
    "user" : {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "protected" : false,
      "id_str" : "500704345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507818066814590976\/KNG-IkT9_normal.jpeg",
      "id" : 500704345,
      "verified" : true
    }
  },
  "id" : 401002365975019520,
  "created_at" : "2013-11-14 15:03:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/400998490223812608\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/RkGbulw6To",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZCiAIzCcAAi6se.jpg",
      "id_str" : "400998490081226752",
      "id" : 400998490081226752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZCiAIzCcAAi6se.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/RkGbulw6To"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401000672390565888",
  "text" : "RT @Chickypoo333: Mornin Fred, Mornin Molly http:\/\/t.co\/RkGbulw6To",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/400998490223812608\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/RkGbulw6To",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZCiAIzCcAAi6se.jpg",
        "id_str" : "400998490081226752",
        "id" : 400998490081226752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZCiAIzCcAAi6se.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/RkGbulw6To"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400998490223812608",
    "text" : "Mornin Fred, Mornin Molly http:\/\/t.co\/RkGbulw6To",
    "id" : 400998490223812608,
    "created_at" : "2013-11-14 14:47:44 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 401000672390565888,
  "created_at" : "2013-11-14 14:56:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400987119083982848",
  "geo" : { },
  "id_str" : "400995570346504192",
  "in_reply_to_user_id" : 99910224,
  "text" : "@PaganGmaSayin (((hugs)))",
  "id" : 400995570346504192,
  "in_reply_to_status_id" : 400987119083982848,
  "created_at" : "2013-11-14 14:36:08 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Wong",
      "screen_name" : "ten24get",
      "indices" : [ 3, 12 ],
      "id_str" : "399712913",
      "id" : 399712913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hardball",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400796576270258177",
  "text" : "RT @ten24get: #hardball Which of Pope Francis' liberal policies is Palin opposed? Feeding hungry, healing the sick, justice for oppressed?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hardball",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400784539401715712",
    "text" : "#hardball Which of Pope Francis' liberal policies is Palin opposed? Feeding hungry, healing the sick, justice for oppressed?",
    "id" : 400784539401715712,
    "created_at" : "2013-11-14 00:37:35 +0000",
    "user" : {
      "name" : "Bill Wong",
      "screen_name" : "ten24get",
      "protected" : false,
      "id_str" : "399712913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410317100\/526bae50e871281547b4e3afa799111d_normal.jpeg",
      "id" : 399712913,
      "verified" : false
    }
  },
  "id" : 400796576270258177,
  "created_at" : "2013-11-14 01:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Morrison",
      "screen_name" : "JamesPMorrison",
      "indices" : [ 3, 18 ],
      "id_str" : "23125412",
      "id" : 23125412
    }, {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 122, 131 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/QWwc0gQjSJ",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/10\/1254596\/-Another-Health-Insurer-Caught-Falsely-Cancelling-Thousands-of-Health-Plans",
      "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400796549586124800",
  "text" : "RT @JamesPMorrison: Another Health Insurer Caught Falsely Cancelling Thousands of Health Plans http:\/\/t.co\/QWwc0gQjSJ via @dailykos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Kos",
        "screen_name" : "dailykos",
        "indices" : [ 102, 111 ],
        "id_str" : "20818801",
        "id" : 20818801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/QWwc0gQjSJ",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/11\/10\/1254596\/-Another-Health-Insurer-Caught-Falsely-Cancelling-Thousands-of-Health-Plans",
        "display_url" : "dailykos.com\/story\/2013\/11\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400782727147819009",
    "text" : "Another Health Insurer Caught Falsely Cancelling Thousands of Health Plans http:\/\/t.co\/QWwc0gQjSJ via @dailykos",
    "id" : 400782727147819009,
    "created_at" : "2013-11-14 00:30:22 +0000",
    "user" : {
      "name" : "James Morrison",
      "screen_name" : "JamesPMorrison",
      "protected" : false,
      "id_str" : "23125412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680571620180639748\/yNkgM7wB_normal.jpg",
      "id" : 23125412,
      "verified" : true
    }
  },
  "id" : 400796549586124800,
  "created_at" : "2013-11-14 01:25:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big History Project",
      "screen_name" : "BigHistoryPro",
      "indices" : [ 3, 17 ],
      "id_str" : "260472369",
      "id" : 260472369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/KyyPis4DlE",
      "expanded_url" : "http:\/\/bit.ly\/1gzcJDu",
      "display_url" : "bit.ly\/1gzcJDu"
    } ]
  },
  "geo" : { },
  "id_str" : "400631695294332928",
  "text" : "RT @BigHistoryPro: The Big History Project is now available to everyone - completely free, open, and online!  \nhttp:\/\/t.co\/KyyPis4DlE http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BigHistoryPro\/status\/399282466914975744\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/TtyRRl7QZy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYqJSb0CAAEPrFr.jpg",
        "id_str" : "399282466772353025",
        "id" : 399282466772353025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYqJSb0CAAEPrFr.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 833
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 833
        } ],
        "display_url" : "pic.twitter.com\/TtyRRl7QZy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/KyyPis4DlE",
        "expanded_url" : "http:\/\/bit.ly\/1gzcJDu",
        "display_url" : "bit.ly\/1gzcJDu"
      } ]
    },
    "geo" : { },
    "id_str" : "399282466914975744",
    "text" : "The Big History Project is now available to everyone - completely free, open, and online!  \nhttp:\/\/t.co\/KyyPis4DlE http:\/\/t.co\/TtyRRl7QZy",
    "id" : 399282466914975744,
    "created_at" : "2013-11-09 21:08:53 +0000",
    "user" : {
      "name" : "Big History Project",
      "screen_name" : "BigHistoryPro",
      "protected" : false,
      "id_str" : "260472369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000215242721\/4011342e02f4bf1c63a806e553b82d1a_normal.png",
      "id" : 260472369,
      "verified" : false
    }
  },
  "id" : 400631695294332928,
  "created_at" : "2013-11-13 14:30:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30FD(\u0CA0_\u0CA0)\u30CE",
      "screen_name" : "JoeMomasNuts",
      "indices" : [ 3, 16 ],
      "id_str" : "220548561",
      "id" : 220548561
    }, {
      "name" : "SonnyBee",
      "screen_name" : "SonnyBeez",
      "indices" : [ 45, 55 ],
      "id_str" : "589164746",
      "id" : 589164746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JoeMomasNuts\/status\/399212336839282688\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/eFPwWPg1RG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYpJgVeCUAAL6QZ.jpg",
      "id_str" : "399212336843476992",
      "id" : 399212336843476992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYpJgVeCUAAL6QZ.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 469
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 469
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 469
      } ],
      "display_url" : "pic.twitter.com\/eFPwWPg1RG"
    } ],
    "hashtags" : [ {
      "text" : "BEES",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "GMO",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400631080099000320",
  "text" : "RT @JoeMomasNuts: Protect The #BEES! NO #GMO @SonnyBeez http:\/\/t.co\/eFPwWPg1RG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SonnyBee",
        "screen_name" : "SonnyBeez",
        "indices" : [ 27, 37 ],
        "id_str" : "589164746",
        "id" : 589164746
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoeMomasNuts\/status\/399212336839282688\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/eFPwWPg1RG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYpJgVeCUAAL6QZ.jpg",
        "id_str" : "399212336843476992",
        "id" : 399212336843476992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYpJgVeCUAAL6QZ.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 469
        } ],
        "display_url" : "pic.twitter.com\/eFPwWPg1RG"
      } ],
      "hashtags" : [ {
        "text" : "BEES",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "GMO",
        "indices" : [ 22, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399212336839282688",
    "text" : "Protect The #BEES! NO #GMO @SonnyBeez http:\/\/t.co\/eFPwWPg1RG",
    "id" : 399212336839282688,
    "created_at" : "2013-11-09 16:30:12 +0000",
    "user" : {
      "name" : "\u30FD(\u0CA0_\u0CA0)\u30CE",
      "screen_name" : "JoeMomasNuts",
      "protected" : false,
      "id_str" : "220548561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3507052749\/f5a2be8752f279c2fd67fa844382064f_normal.jpeg",
      "id" : 220548561,
      "verified" : false
    }
  },
  "id" : 400631080099000320,
  "created_at" : "2013-11-13 14:27:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400436737421225985",
  "text" : "sometimes i feel bursts of love for humanity &lt;3",
  "id" : 400436737421225985,
  "created_at" : "2013-11-13 01:35:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400382834587615233",
  "text" : "@weakSquare wth?",
  "id" : 400382834587615233,
  "created_at" : "2013-11-12 22:01:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 3, 19 ],
      "id_str" : "41377983",
      "id" : 41377983
    }, {
      "name" : "PamMc",
      "screen_name" : "Pamreader",
      "indices" : [ 116, 126 ],
      "id_str" : "72830308",
      "id" : 72830308
    }, {
      "name" : "kblathers",
      "screen_name" : "kblathers",
      "indices" : [ 127, 137 ],
      "id_str" : "21287895",
      "id" : 21287895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ReH55cvIz8",
      "expanded_url" : "http:\/\/www.nottinghampost.com\/Swan-tries-steal-chocolate-bar-West-Bridgford\/story-20065541-detail\/story.html",
      "display_url" : "nottinghampost.com\/Swan-tries-ste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400379635126779906",
  "text" : "RT @emperorsclothes: Swan tries to steal chocolate bar in West Bridgford shop: http:\/\/t.co\/ReH55cvIz8 Top story via @pamreader @kblathers @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PamMc",
        "screen_name" : "Pamreader",
        "indices" : [ 95, 105 ],
        "id_str" : "72830308",
        "id" : 72830308
      }, {
        "name" : "kblathers",
        "screen_name" : "kblathers",
        "indices" : [ 106, 116 ],
        "id_str" : "21287895",
        "id" : 21287895
      }, {
        "name" : "Nottingham Post",
        "screen_name" : "Nottingham_Post",
        "indices" : [ 117, 133 ],
        "id_str" : "20507237",
        "id" : 20507237
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ReH55cvIz8",
        "expanded_url" : "http:\/\/www.nottinghampost.com\/Swan-tries-steal-chocolate-bar-West-Bridgford\/story-20065541-detail\/story.html",
        "display_url" : "nottinghampost.com\/Swan-tries-ste\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400375646473691136",
    "text" : "Swan tries to steal chocolate bar in West Bridgford shop: http:\/\/t.co\/ReH55cvIz8 Top story via @pamreader @kblathers @Nottingham_Post",
    "id" : 400375646473691136,
    "created_at" : "2013-11-12 21:32:47 +0000",
    "user" : {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "protected" : false,
      "id_str" : "41377983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451424284636745728\/EOavGMYP_normal.jpeg",
      "id" : 41377983,
      "verified" : true
    }
  },
  "id" : 400379635126779906,
  "created_at" : "2013-11-12 21:48:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Wendell Potter",
      "screen_name" : "wendellpotter",
      "indices" : [ 20, 34 ],
      "id_str" : "16950628",
      "id" : 16950628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 95, 107 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400367671604412417",
  "text" : "RT @AllOnMedicare: .@wendellpotter Neat to see Big Pharma and Managed Care admitting fear that #SinglePayer #MedicareForAll on doorstep: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wendell Potter",
        "screen_name" : "wendellpotter",
        "indices" : [ 1, 15 ],
        "id_str" : "16950628",
        "id" : 16950628
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 76, 88 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 89, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/aXAvkxeiu3",
        "expanded_url" : "http:\/\/blog.pharmexec.com\/2013\/11\/11\/single-payer-issue-will-rise-again\/",
        "display_url" : "blog.pharmexec.com\/2013\/11\/11\/sin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400366454760955904",
    "text" : ".@wendellpotter Neat to see Big Pharma and Managed Care admitting fear that #SinglePayer #MedicareForAll on doorstep: http:\/\/t.co\/aXAvkxeiu3",
    "id" : 400366454760955904,
    "created_at" : "2013-11-12 20:56:15 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 400367671604412417,
  "created_at" : "2013-11-12 21:01:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 3, 17 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheists",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/jId1g2GxGE",
      "expanded_url" : "http:\/\/zite.to\/1i2l9T3",
      "display_url" : "zite.to\/1i2l9T3"
    } ]
  },
  "geo" : { },
  "id_str" : "400363497059790850",
  "text" : "RT @allthewayleft: Palin links \u2018zealot-like\u2019 #atheists to the \u2018war on Christmas\u2019 and \u2018slavery\u2019 from federal debt http:\/\/t.co\/jId1g2GxGE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheists",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/jId1g2GxGE",
        "expanded_url" : "http:\/\/zite.to\/1i2l9T3",
        "display_url" : "zite.to\/1i2l9T3"
      } ]
    },
    "geo" : { },
    "id_str" : "400352343658856448",
    "text" : "Palin links \u2018zealot-like\u2019 #atheists to the \u2018war on Christmas\u2019 and \u2018slavery\u2019 from federal debt http:\/\/t.co\/jId1g2GxGE",
    "id" : 400352343658856448,
    "created_at" : "2013-11-12 20:00:11 +0000",
    "user" : {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "protected" : false,
      "id_str" : "345207173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000852111499\/8d917b25d9062fc1d0af08d0f98ccd71_normal.jpeg",
      "id" : 345207173,
      "verified" : false
    }
  },
  "id" : 400363497059790850,
  "created_at" : "2013-11-12 20:44:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400325095861661696",
  "text" : "i think universe wants me to learn tolerance better. thats why i go to bible study. seems lately, been getting my dander up a lot..lol",
  "id" : 400325095861661696,
  "created_at" : "2013-11-12 18:11:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Michael",
      "screen_name" : "TonyMichael",
      "indices" : [ 3, 15 ],
      "id_str" : "17722477",
      "id" : 17722477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 117, 121 ]
    }, {
      "text" : "Monsanto",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400324734367576064",
  "text" : "RT @TonyMichael: This what you must wear when preparing to spray pesticides on the crops we eat.\n\nLooks safe to eat. #yum\n\n#Monsanto\n. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TonyMichael\/status\/399357246561193984\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/PdAHxKJzUw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYrNTL_CYAAySCQ.jpg",
        "id_str" : "399357246494105600",
        "id" : 399357246494105600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYrNTL_CYAAySCQ.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PdAHxKJzUw"
      } ],
      "hashtags" : [ {
        "text" : "yum",
        "indices" : [ 100, 104 ]
      }, {
        "text" : "Monsanto",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399357246561193984",
    "text" : "This what you must wear when preparing to spray pesticides on the crops we eat.\n\nLooks safe to eat. #yum\n\n#Monsanto\n. http:\/\/t.co\/PdAHxKJzUw",
    "id" : 399357246561193984,
    "created_at" : "2013-11-10 02:06:01 +0000",
    "user" : {
      "name" : "Tony Michael",
      "screen_name" : "TonyMichael",
      "protected" : false,
      "id_str" : "17722477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780747222\/HotAir_normal.jpg",
      "id" : 17722477,
      "verified" : false
    }
  },
  "id" : 400324734367576064,
  "created_at" : "2013-11-12 18:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400322879629164545",
  "geo" : { },
  "id_str" : "400324477004701696",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell that verse was in our bible study today. going through genesis.. at gen 6. verses relating to how evil mankind is..",
  "id" : 400324477004701696,
  "in_reply_to_status_id" : 400322879629164545,
  "created_at" : "2013-11-12 18:09:27 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400323760504332288",
  "text" : "politicians that speak of \"enemies\".. GAHH!!",
  "id" : 400323760504332288,
  "created_at" : "2013-11-12 18:06:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#Cosmic_Warrior",
      "screen_name" : "Peta_de_Aztlan",
      "indices" : [ 3, 18 ],
      "id_str" : "30693810",
      "id" : 30693810
    }, {
      "name" : "EnigMaa",
      "screen_name" : "EnigmaNetxx",
      "indices" : [ 20, 32 ],
      "id_str" : "166001916",
      "id" : 166001916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400041077409079296",
  "text" : "RT @Peta_de_Aztlan: @EnigmaNetxx I believe and know of Creator, but cannot constrain myself with the label Christian. Are we not children o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EnigMaa",
        "screen_name" : "EnigmaNetxx",
        "indices" : [ 0, 12 ],
        "id_str" : "166001916",
        "id" : 166001916
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400007346262253568",
    "in_reply_to_user_id" : 166001916,
    "text" : "@EnigmaNetxx I believe and know of Creator, but cannot constrain myself with the label Christian. Are we not children of the Creator?",
    "id" : 400007346262253568,
    "created_at" : "2013-11-11 21:09:17 +0000",
    "in_reply_to_screen_name" : "EnigmaNetxx",
    "in_reply_to_user_id_str" : "166001916",
    "user" : {
      "name" : "#Cosmic_Warrior",
      "screen_name" : "Peta_de_Aztlan",
      "protected" : false,
      "id_str" : "30693810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1767425430\/Geronimo-FB_normal.jpg",
      "id" : 30693810,
      "verified" : false
    }
  },
  "id" : 400041077409079296,
  "created_at" : "2013-11-11 23:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turn Texas Blue",
      "screen_name" : "UniteBlueTX",
      "indices" : [ 3, 15 ],
      "id_str" : "414488432",
      "id" : 414488432
    }, {
      "name" : "Sarah Palin",
      "screen_name" : "SarahPalinUSA",
      "indices" : [ 18, 32 ],
      "id_str" : "65493023",
      "id" : 65493023
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400040782025228288",
  "text" : "RT @UniteBlueTX: .@SarahPalinUSA Outraged over Closed WWII Memorial but Not a Peep when GOP cuts Food to 900,000 Vets! #HonoringVets http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Palin",
        "screen_name" : "SarahPalinUSA",
        "indices" : [ 1, 15 ],
        "id_str" : "65493023",
        "id" : 65493023
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UniteBlueTX\/status\/399979424558235648\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/SfAhRzBBjF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY0DKt7CQAAktsC.jpg",
        "id_str" : "399979424566624256",
        "id" : 399979424566624256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY0DKt7CQAAktsC.jpg",
        "sizes" : [ {
          "h" : 481,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/SfAhRzBBjF"
      } ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399979424558235648",
    "text" : ".@SarahPalinUSA Outraged over Closed WWII Memorial but Not a Peep when GOP cuts Food to 900,000 Vets! #HonoringVets http:\/\/t.co\/SfAhRzBBjF",
    "id" : 399979424558235648,
    "created_at" : "2013-11-11 19:18:20 +0000",
    "user" : {
      "name" : "Turn Texas Blue",
      "screen_name" : "UniteBlueTX",
      "protected" : false,
      "id_str" : "414488432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529838849476681728\/MSqhuzqP_normal.png",
      "id" : 414488432,
      "verified" : false
    }
  },
  "id" : 400040782025228288,
  "created_at" : "2013-11-11 23:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400038661061738496",
  "text" : "many ppl who think they're \"bad\" are way ahead of me soul-wise... ive got a looong road ahead of me and it aint pretty.",
  "id" : 400038661061738496,
  "created_at" : "2013-11-11 23:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400037357866340352",
  "text" : "forgot to do something today and now feel like crap (about forgetting) .. responsible is not something you'd ever call me.. sigh.",
  "id" : 400037357866340352,
  "created_at" : "2013-11-11 23:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HUUwwtgvq5",
      "expanded_url" : "http:\/\/huff.to\/1bonTHy",
      "display_url" : "huff.to\/1bonTHy"
    } ]
  },
  "geo" : { },
  "id_str" : "400014664165113856",
  "text" : "Sarah Palin And Matt Lauer Had An Insane Conversation http:\/\/t.co\/HUUwwtgvq5",
  "id" : 400014664165113856,
  "created_at" : "2013-11-11 21:38:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399922510885814272",
  "text" : "RT @seejayel: if no one comes from the future to prevent you from doing it, then how bad of a decision could it really be?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298943431785455616",
    "text" : "if no one comes from the future to prevent you from doing it, then how bad of a decision could it really be?",
    "id" : 298943431785455616,
    "created_at" : "2013-02-05 23:57:22 +0000",
    "user" : {
      "name" : "KRIS-tuh-FAH",
      "screen_name" : "seejaylinco",
      "protected" : false,
      "id_str" : "471554883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767255395886825472\/EW8dXCaf_normal.jpg",
      "id" : 471554883,
      "verified" : false
    }
  },
  "id" : 399922510885814272,
  "created_at" : "2013-11-11 15:32:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oEM38i9iCM",
      "expanded_url" : "http:\/\/www.naturalnews.com\/041963_vaccines_cancer_viruses_Dr_Maurice_Hilleman.html",
      "display_url" : "naturalnews.com\/041963_vaccine\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399920705522782208",
  "text" : "Merck vaccine developer admits vaccines routinely contain hidden cancer viruses derived from diseased monkeys http:\/\/t.co\/oEM38i9iCM",
  "id" : 399920705522782208,
  "created_at" : "2013-11-11 15:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399916252530896897",
  "text" : "i can take only so much negative then i start to feel physically ill...",
  "id" : 399916252530896897,
  "created_at" : "2013-11-11 15:07:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Licata",
      "screen_name" : "BLicata",
      "indices" : [ 3, 11 ],
      "id_str" : "14298089",
      "id" : 14298089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sschat",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/PzK33xGxRU",
      "expanded_url" : "http:\/\/www.npr.org\/2013\/11\/10\/243981006\/inconsistencies-haunt-official-record-of-kennedys-death",
      "display_url" : "npr.org\/2013\/11\/10\/243\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399712981661286400",
  "text" : "RT @BLicata: Inconsistencies in JFKs official death records http:\/\/t.co\/PzK33xGxRU #sschat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sschat",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/PzK33xGxRU",
        "expanded_url" : "http:\/\/www.npr.org\/2013\/11\/10\/243981006\/inconsistencies-haunt-official-record-of-kennedys-death",
        "display_url" : "npr.org\/2013\/11\/10\/243\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399710089814495232",
    "text" : "Inconsistencies in JFKs official death records http:\/\/t.co\/PzK33xGxRU #sschat",
    "id" : 399710089814495232,
    "created_at" : "2013-11-11 01:28:06 +0000",
    "user" : {
      "name" : "Brian Licata",
      "screen_name" : "BLicata",
      "protected" : false,
      "id_str" : "14298089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789981044774756352\/AoSJK2Dp_normal.jpg",
      "id" : 14298089,
      "verified" : false
    }
  },
  "id" : 399712981661286400,
  "created_at" : "2013-11-11 01:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 0, 10 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399701765911613440",
  "text" : "@ID_vs_EGO took me a minute.. lol",
  "id" : 399701765911613440,
  "created_at" : "2013-11-11 00:55:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 3, 16 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cicada_ntx\/status\/399627933532160000\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/sBuQuMhAEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYvDfP1CAAAVu3m.png",
      "id_str" : "399627933544742912",
      "id" : 399627933544742912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYvDfP1CAAAVu3m.png",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 307
      } ],
      "display_url" : "pic.twitter.com\/sBuQuMhAEx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399689961517350912",
  "text" : "RT @hypatiadotca: Apparently forced-birthers in TX are now plotting kidnapping women seeking abortions: http:\/\/t.co\/sBuQuMhAEx \/via @cicada\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cicada collective",
        "screen_name" : "cicada_ntx",
        "indices" : [ 114, 125 ],
        "id_str" : "1638519660",
        "id" : 1638519660
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cicada_ntx\/status\/399627933532160000\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/sBuQuMhAEx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYvDfP1CAAAVu3m.png",
        "id_str" : "399627933544742912",
        "id" : 399627933544742912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYvDfP1CAAAVu3m.png",
        "sizes" : [ {
          "h" : 523,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 307
        } ],
        "display_url" : "pic.twitter.com\/sBuQuMhAEx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "399627933532160000",
    "geo" : { },
    "id_str" : "399670819493662720",
    "in_reply_to_user_id" : 1638519660,
    "text" : "Apparently forced-birthers in TX are now plotting kidnapping women seeking abortions: http:\/\/t.co\/sBuQuMhAEx \/via @cicada_ntx",
    "id" : 399670819493662720,
    "in_reply_to_status_id" : 399627933532160000,
    "created_at" : "2013-11-10 22:52:03 +0000",
    "in_reply_to_screen_name" : "cicada_ntx",
    "in_reply_to_user_id_str" : "1638519660",
    "user" : {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "protected" : false,
      "id_str" : "6742522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777680485501722624\/ZOiZulxt_normal.jpg",
      "id" : 6742522,
      "verified" : true
    }
  },
  "id" : 399689961517350912,
  "created_at" : "2013-11-11 00:08:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CelticClover13",
      "screen_name" : "celticclover13",
      "indices" : [ 3, 18 ],
      "id_str" : "30551330",
      "id" : 30551330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/celticclover13\/status\/399675279444279296\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/2Hny1LCdnC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYvujImIYAENvgC.jpg",
      "id_str" : "399675279322669057",
      "id" : 399675279322669057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYvujImIYAENvgC.jpg",
      "sizes" : [ {
        "h" : 598,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 602,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 602,
        "resize" : "fit",
        "w" : 604
      } ],
      "display_url" : "pic.twitter.com\/2Hny1LCdnC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399688095635091456",
  "text" : "RT @celticclover13: Self love http:\/\/t.co\/2Hny1LCdnC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/celticclover13\/status\/399675279444279296\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/2Hny1LCdnC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYvujImIYAENvgC.jpg",
        "id_str" : "399675279322669057",
        "id" : 399675279322669057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYvujImIYAENvgC.jpg",
        "sizes" : [ {
          "h" : 598,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 602,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 602,
          "resize" : "fit",
          "w" : 604
        } ],
        "display_url" : "pic.twitter.com\/2Hny1LCdnC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399675279444279296",
    "text" : "Self love http:\/\/t.co\/2Hny1LCdnC",
    "id" : 399675279444279296,
    "created_at" : "2013-11-10 23:09:46 +0000",
    "user" : {
      "name" : "CelticClover13",
      "screen_name" : "celticclover13",
      "protected" : false,
      "id_str" : "30551330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703445261079588864\/CKsMinZf_normal.jpg",
      "id" : 30551330,
      "verified" : false
    }
  },
  "id" : 399688095635091456,
  "created_at" : "2013-11-11 00:00:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Mat Lazenby",
      "screen_name" : "Mat_LB",
      "indices" : [ 18, 25 ],
      "id_str" : "53301133",
      "id" : 53301133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/TuBDPmHvos",
      "expanded_url" : "https:\/\/twitter.com\/feebee79\/status\/399495568289837056\/photo\/1",
      "display_url" : "pic.twitter.com\/TuBDPmHvos"
    } ]
  },
  "geo" : { },
  "id_str" : "399665222929371136",
  "text" : "RT @Silvercrone: \u201C@Mat_LB: Powerful, saddening words from one of the last living soldiers of World War One http:\/\/t.co\/TuBDPmHvos\u201D\n(AMEN!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mat Lazenby",
        "screen_name" : "Mat_LB",
        "indices" : [ 1, 8 ],
        "id_str" : "53301133",
        "id" : 53301133
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/TuBDPmHvos",
        "expanded_url" : "https:\/\/twitter.com\/feebee79\/status\/399495568289837056\/photo\/1",
        "display_url" : "pic.twitter.com\/TuBDPmHvos"
      } ]
    },
    "in_reply_to_status_id_str" : "399518672039190528",
    "geo" : { },
    "id_str" : "399663427624636417",
    "in_reply_to_user_id" : 53301133,
    "text" : "\u201C@Mat_LB: Powerful, saddening words from one of the last living soldiers of World War One http:\/\/t.co\/TuBDPmHvos\u201D\n(AMEN!)",
    "id" : 399663427624636417,
    "in_reply_to_status_id" : 399518672039190528,
    "created_at" : "2013-11-10 22:22:41 +0000",
    "in_reply_to_screen_name" : "Mat_LB",
    "in_reply_to_user_id_str" : "53301133",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 399665222929371136,
  "created_at" : "2013-11-10 22:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Refusers",
      "screen_name" : "the_refusers",
      "indices" : [ 3, 16 ],
      "id_str" : "268117600",
      "id" : 268117600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/BV78Lotv2C",
      "expanded_url" : "http:\/\/fb.me\/6yBoPh96G",
      "display_url" : "fb.me\/6yBoPh96G"
    } ]
  },
  "geo" : { },
  "id_str" : "399664774621175808",
  "text" : "RT @the_refusers: The Amish refuse vaccines, drink raw milk, survive germs and don't have allergies or autism. http:\/\/t.co\/BV78Lotv2C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/BV78Lotv2C",
        "expanded_url" : "http:\/\/fb.me\/6yBoPh96G",
        "display_url" : "fb.me\/6yBoPh96G"
      } ]
    },
    "geo" : { },
    "id_str" : "399664142359203840",
    "text" : "The Amish refuse vaccines, drink raw milk, survive germs and don't have allergies or autism. http:\/\/t.co\/BV78Lotv2C",
    "id" : 399664142359203840,
    "created_at" : "2013-11-10 22:25:31 +0000",
    "user" : {
      "name" : "The Refusers",
      "screen_name" : "the_refusers",
      "protected" : false,
      "id_str" : "268117600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754058318138658816\/jfNg0Wnf_normal.jpg",
      "id" : 268117600,
      "verified" : false
    }
  },
  "id" : 399664774621175808,
  "created_at" : "2013-11-10 22:28:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christine Ann Muff",
      "screen_name" : "snowleopard56",
      "indices" : [ 13, 27 ],
      "id_str" : "1013504090",
      "id" : 1013504090
    }, {
      "name" : "Jan Kurdman",
      "screen_name" : "dyakomard",
      "indices" : [ 28, 38 ],
      "id_str" : "1076394487",
      "id" : 1076394487
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/snowleopard56\/status\/399646838325641216\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/XHX17SvNCr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYvUro4CAAAwNFU.jpg",
      "id_str" : "399646838124314624",
      "id" : 399646838124314624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYvUro4CAAAwNFU.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 634
      } ],
      "display_url" : "pic.twitter.com\/XHX17SvNCr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399646838325641216",
  "geo" : { },
  "id_str" : "399650752273997825",
  "in_reply_to_user_id" : 1013504090,
  "text" : "precious! RT @snowleopard56 @dyakomard enjoy a new week! XxxxxX http:\/\/t.co\/XHX17SvNCr",
  "id" : 399650752273997825,
  "in_reply_to_status_id" : 399646838325641216,
  "created_at" : "2013-11-10 21:32:19 +0000",
  "in_reply_to_screen_name" : "snowleopard56",
  "in_reply_to_user_id_str" : "1013504090",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hardy Jones",
      "screen_name" : "BlueVoiceOrg",
      "indices" : [ 3, 16 ],
      "id_str" : "34279241",
      "id" : 34279241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeaWorld",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399615129303920640",
  "text" : "RT @BlueVoiceOrg: #SeaWorld stock has plummeted since the film Blackfish exposed the brutal way orca are treated and trainers put in jeopar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SeaWorld",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398897344264941569",
    "text" : "#SeaWorld stock has plummeted since the film Blackfish exposed the brutal way orca are treated and trainers put in jeopardy.",
    "id" : 398897344264941569,
    "created_at" : "2013-11-08 19:38:32 +0000",
    "user" : {
      "name" : "Hardy Jones",
      "screen_name" : "BlueVoiceOrg",
      "protected" : false,
      "id_str" : "34279241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/154979940\/AmongDolphinEyes_normal.jpg",
      "id" : 34279241,
      "verified" : false
    }
  },
  "id" : 399615129303920640,
  "created_at" : "2013-11-10 19:10:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MariElena",
      "screen_name" : "MIA_ELS",
      "indices" : [ 3, 11 ],
      "id_str" : "1398404390",
      "id" : 1398404390
    }, {
      "name" : "Orca S\u203BO\u203BS",
      "screen_name" : "OrcaSOS",
      "indices" : [ 96, 104 ],
      "id_str" : "495088169",
      "id" : 495088169
    }, {
      "name" : "ANIMAL ADVOCATE  \u24CB",
      "screen_name" : "_AnimalAdvocate",
      "indices" : [ 105, 121 ],
      "id_str" : "1540529606",
      "id" : 1540529606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeaWorld",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "Blackfish",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399614762042273793",
  "text" : "RT @MIA_ELS: Protest Tomorrow #SeaWorld San Diego, CA. 10am-1pm wear Black and white #Blackfish @OrcaSOS @_AnimalAdvocate http:\/\/t.co\/vRHyo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Orca S\u203BO\u203BS",
        "screen_name" : "OrcaSOS",
        "indices" : [ 83, 91 ],
        "id_str" : "495088169",
        "id" : 495088169
      }, {
        "name" : "ANIMAL ADVOCATE  \u24CB",
        "screen_name" : "_AnimalAdvocate",
        "indices" : [ 92, 108 ],
        "id_str" : "1540529606",
        "id" : 1540529606
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MIA_ELS\/status\/399404085952004097\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/vRHyop6Mxf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYr35mHCcAAWvHJ.jpg",
        "id_str" : "399404085830381568",
        "id" : 399404085830381568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYr35mHCcAAWvHJ.jpg",
        "sizes" : [ {
          "h" : 445,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 911
        } ],
        "display_url" : "pic.twitter.com\/vRHyop6Mxf"
      } ],
      "hashtags" : [ {
        "text" : "SeaWorld",
        "indices" : [ 17, 26 ]
      }, {
        "text" : "Blackfish",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399404085952004097",
    "text" : "Protest Tomorrow #SeaWorld San Diego, CA. 10am-1pm wear Black and white #Blackfish @OrcaSOS @_AnimalAdvocate http:\/\/t.co\/vRHyop6Mxf",
    "id" : 399404085952004097,
    "created_at" : "2013-11-10 05:12:09 +0000",
    "user" : {
      "name" : "MariElena",
      "screen_name" : "MIA_ELS",
      "protected" : false,
      "id_str" : "1398404390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000376357434\/3c486fa8de025337c75f2606ca125ca0_normal.jpeg",
      "id" : 1398404390,
      "verified" : false
    }
  },
  "id" : 399614762042273793,
  "created_at" : "2013-11-10 19:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "indices" : [ 0, 10 ],
      "id_str" : "23539037",
      "id" : 23539037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399565669831671809",
  "geo" : { },
  "id_str" : "399580760991997953",
  "in_reply_to_user_id" : 23539037,
  "text" : "@OhYouGirl aww... cute. : )",
  "id" : 399580760991997953,
  "in_reply_to_status_id" : 399565669831671809,
  "created_at" : "2013-11-10 16:54:11 +0000",
  "in_reply_to_screen_name" : "OhYouGirl",
  "in_reply_to_user_id_str" : "23539037",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399569111211995136",
  "geo" : { },
  "id_str" : "399578852478836738",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes i cannot stand those memes that go around FB that kids are not beaten enough so we're getting \"bad\" kids.. sigh.",
  "id" : 399578852478836738,
  "in_reply_to_status_id" : 399569111211995136,
  "created_at" : "2013-11-10 16:46:36 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Loop",
      "screen_name" : "matthewloop",
      "indices" : [ 3, 15 ],
      "id_str" : "16241626",
      "id" : 16241626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gardasil",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/rW2jFgpO9O",
      "expanded_url" : "http:\/\/wtim.es\/1fzzUxa",
      "display_url" : "wtim.es\/1fzzUxa"
    } ]
  },
  "geo" : { },
  "id_str" : "399578519602470912",
  "text" : "RT @matthewloop: US court pays $6 million to #Gardasil victims http:\/\/t.co\/rW2jFgpO9O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gardasil",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/rW2jFgpO9O",
        "expanded_url" : "http:\/\/wtim.es\/1fzzUxa",
        "display_url" : "wtim.es\/1fzzUxa"
      } ]
    },
    "geo" : { },
    "id_str" : "390094120582008832",
    "text" : "US court pays $6 million to #Gardasil victims http:\/\/t.co\/rW2jFgpO9O",
    "id" : 390094120582008832,
    "created_at" : "2013-10-15 12:37:40 +0000",
    "user" : {
      "name" : "Matthew Loop",
      "screen_name" : "matthewloop",
      "protected" : false,
      "id_str" : "16241626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678615861188497408\/Nk6RWCof_normal.jpg",
      "id" : 16241626,
      "verified" : true
    }
  },
  "id" : 399578519602470912,
  "created_at" : "2013-11-10 16:45:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    }, {
      "name" : "Dr. Brent Potter",
      "screen_name" : "DrBrentPotter",
      "indices" : [ 22, 36 ],
      "id_str" : "637227269",
      "id" : 637227269
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "society",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "poverty",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/0HfFqF5ba5",
      "expanded_url" : "http:\/\/lnkd.in\/b9vjKix",
      "display_url" : "lnkd.in\/b9vjKix"
    } ]
  },
  "geo" : { },
  "id_str" : "399338244216999936",
  "text" : "RT @NewMindMirror: RT @DrBrentPotter: It is illegal to feed the homeless in cities all over  http:\/\/t.co\/0HfFqF5ba5 #society #poverty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Brent Potter",
        "screen_name" : "DrBrentPotter",
        "indices" : [ 3, 17 ],
        "id_str" : "637227269",
        "id" : 637227269
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "society",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "poverty",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/0HfFqF5ba5",
        "expanded_url" : "http:\/\/lnkd.in\/b9vjKix",
        "display_url" : "lnkd.in\/b9vjKix"
      } ]
    },
    "in_reply_to_status_id_str" : "399312178987024384",
    "geo" : { },
    "id_str" : "399322844477128705",
    "in_reply_to_user_id" : 637227269,
    "text" : "RT @DrBrentPotter: It is illegal to feed the homeless in cities all over  http:\/\/t.co\/0HfFqF5ba5 #society #poverty",
    "id" : 399322844477128705,
    "in_reply_to_status_id" : 399312178987024384,
    "created_at" : "2013-11-09 23:49:19 +0000",
    "in_reply_to_screen_name" : "DrBrentPotter",
    "in_reply_to_user_id_str" : "637227269",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 399338244216999936,
  "created_at" : "2013-11-10 00:50:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399330289337765888",
  "geo" : { },
  "id_str" : "399336077195898880",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell oh god, that doesnt bode well for me...",
  "id" : 399336077195898880,
  "in_reply_to_status_id" : 399330289337765888,
  "created_at" : "2013-11-10 00:41:54 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Oqu2TDrUb2",
      "expanded_url" : "http:\/\/youtu.be\/vVkDrIacHJM",
      "display_url" : "youtu.be\/vVkDrIacHJM"
    } ]
  },
  "geo" : { },
  "id_str" : "399330297692450816",
  "text" : "The Backwater Gospel: http:\/\/t.co\/Oqu2TDrUb2",
  "id" : 399330297692450816,
  "created_at" : "2013-11-10 00:18:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edgar Eraspuss",
      "screen_name" : "EdgarEraspuss",
      "indices" : [ 20, 34 ],
      "id_str" : "1477178534",
      "id" : 1477178534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whichone",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399307004663320576",
  "text" : "RT @missysongbird: \u201C@EdgarEraspuss: That's a funny looking bird@ #whichone? MT @OopsLand \n@celinech86 http:\/\/t.co\/NCpaMvRq2j\u201DLove!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edgar Eraspuss",
        "screen_name" : "EdgarEraspuss",
        "indices" : [ 1, 15 ],
        "id_str" : "1477178534",
        "id" : 1477178534
      }, {
        "name" : "C\u00E9line",
        "screen_name" : "celinech86",
        "indices" : [ 71, 82 ],
        "id_str" : "1217769356",
        "id" : 1217769356
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whichone",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/NCpaMvRq2j",
        "expanded_url" : "https:\/\/twitter.com\/OopsLand\/status\/380229905864466432\/photo\/1",
        "display_url" : "pic.twitter.com\/NCpaMvRq2j"
      } ]
    },
    "in_reply_to_status_id_str" : "398043534080884736",
    "geo" : { },
    "id_str" : "398214775290613760",
    "in_reply_to_user_id" : 1477178534,
    "text" : "\u201C@EdgarEraspuss: That's a funny looking bird@ #whichone? MT @OopsLand \n@celinech86 http:\/\/t.co\/NCpaMvRq2j\u201DLove!",
    "id" : 398214775290613760,
    "in_reply_to_status_id" : 398043534080884736,
    "created_at" : "2013-11-06 22:26:15 +0000",
    "in_reply_to_screen_name" : "EdgarEraspuss",
    "in_reply_to_user_id_str" : "1477178534",
    "user" : {
      "name" : "M Birdy",
      "screen_name" : "mebirdy777",
      "protected" : false,
      "id_str" : "1336543388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560464161864298497\/8ZxkWSeh_normal.jpeg",
      "id" : 1336543388,
      "verified" : false
    }
  },
  "id" : 399307004663320576,
  "created_at" : "2013-11-09 22:46:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "indices" : [ 3, 18 ],
      "id_str" : "299413847",
      "id" : 299413847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399198396382461952",
  "text" : "RT @InjusticeFacts: Governments in the world spend $1300 billion each year on military expenditures while it only takes $13 billion to feed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399191788017037313",
    "text" : "Governments in the world spend $1300 billion each year on military expenditures while it only takes $13 billion to feed the world's hungry.",
    "id" : 399191788017037313,
    "created_at" : "2013-11-09 15:08:33 +0000",
    "user" : {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "protected" : false,
      "id_str" : "299413847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554067441\/injustice_normal.jpg",
      "id" : 299413847,
      "verified" : false
    }
  },
  "id" : 399198396382461952,
  "created_at" : "2013-11-09 15:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackmoresNight",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399195949378969601",
  "text" : "good show last night in peekskill ny. #BlackmoresNight - the kids got the biggest applause i think..lol. adorable!",
  "id" : 399195949378969601,
  "created_at" : "2013-11-09 15:25:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Stoker",
      "screen_name" : "StokerDean",
      "indices" : [ 3, 14 ],
      "id_str" : "579106229",
      "id" : 579106229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StokerDean\/status\/398902113368961024\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/4jZV4ju33U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkvW8_CcAEfNs1.jpg",
      "id_str" : "398902113373155329",
      "id" : 398902113373155329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkvW8_CcAEfNs1.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4jZV4ju33U"
    } ],
    "hashtags" : [ {
      "text" : "HighlandCow",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "Applecross",
      "indices" : [ 47, 58 ]
    }, {
      "text" : "Scotland",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398920074297237504",
  "text" : "RT @StokerDean: 'Highland Faceoff #HighlandCow #Applecross #Scotland http:\/\/t.co\/4jZV4ju33U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StokerDean\/status\/398902113368961024\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/4jZV4ju33U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkvW8_CcAEfNs1.jpg",
        "id_str" : "398902113373155329",
        "id" : 398902113373155329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkvW8_CcAEfNs1.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4jZV4ju33U"
      } ],
      "hashtags" : [ {
        "text" : "HighlandCow",
        "indices" : [ 18, 30 ]
      }, {
        "text" : "Applecross",
        "indices" : [ 31, 42 ]
      }, {
        "text" : "Scotland",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398902113368961024",
    "text" : "'Highland Faceoff #HighlandCow #Applecross #Scotland http:\/\/t.co\/4jZV4ju33U",
    "id" : 398902113368961024,
    "created_at" : "2013-11-08 19:57:29 +0000",
    "user" : {
      "name" : "Dean Stoker",
      "screen_name" : "StokerDean",
      "protected" : false,
      "id_str" : "579106229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799339653308489728\/fhoIsZe5_normal.jpg",
      "id" : 579106229,
      "verified" : false
    }
  },
  "id" : 398920074297237504,
  "created_at" : "2013-11-08 21:08:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I am the Doctor",
      "screen_name" : "LiamPhuckall",
      "indices" : [ 3, 16 ],
      "id_str" : "77892917",
      "id" : 77892917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398875885304311808",
  "text" : "RT @LiamPhuckall: Fucking storms..we've broken the planet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398862728250793984",
    "text" : "Fucking storms..we've broken the planet",
    "id" : 398862728250793984,
    "created_at" : "2013-11-08 17:20:59 +0000",
    "user" : {
      "name" : "I am the Doctor",
      "screen_name" : "LiamPhuckall",
      "protected" : false,
      "id_str" : "77892917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799060406153134085\/n0X7p1dt_normal.jpg",
      "id" : 77892917,
      "verified" : false
    }
  },
  "id" : 398875885304311808,
  "created_at" : "2013-11-08 18:13:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/3KcKuVSaXZ",
      "expanded_url" : "http:\/\/www.wimp.com\/helpinganimals\/",
      "display_url" : "wimp.com\/helpinganimals\/"
    } ]
  },
  "geo" : { },
  "id_str" : "398861187317649408",
  "text" : "made me cry, so beautiful. http:\/\/t.co\/3KcKuVSaXZ #compassion",
  "id" : 398861187317649408,
  "created_at" : "2013-11-08 17:14:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/7ekXopBGdT",
      "expanded_url" : "http:\/\/sploid.gizmodo.com\/super-typhon-haiyan-just-broke-all-scientific-intensity-1460295415",
      "display_url" : "sploid.gizmodo.com\/super-typhon-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398859991563898880",
  "text" : "RT @atheistlady76: Super typhoon Haiyan just broke all scientific intensity scales http:\/\/t.co\/7ekXopBGdT &lt;climate change anyone?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/7ekXopBGdT",
        "expanded_url" : "http:\/\/sploid.gizmodo.com\/super-typhon-haiyan-just-broke-all-scientific-intensity-1460295415",
        "display_url" : "sploid.gizmodo.com\/super-typhon-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398857850497163264",
    "text" : "Super typhoon Haiyan just broke all scientific intensity scales http:\/\/t.co\/7ekXopBGdT &lt;climate change anyone?",
    "id" : 398857850497163264,
    "created_at" : "2013-11-08 17:01:36 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 398859991563898880,
  "created_at" : "2013-11-08 17:10:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398858848078794752\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Z3kYovTw8x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkIAlPCEAEZoS1.jpg",
      "id_str" : "398858848087183361",
      "id" : 398858848087183361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkIAlPCEAEZoS1.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/Z3kYovTw8x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398859601934036992",
  "text" : "RT @jacqueduncalf: Buffalo's In The Mist!!  JD http:\/\/t.co\/Z3kYovTw8x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398858848078794752\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/Z3kYovTw8x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkIAlPCEAEZoS1.jpg",
        "id_str" : "398858848087183361",
        "id" : 398858848087183361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkIAlPCEAEZoS1.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/Z3kYovTw8x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398858848078794752",
    "text" : "Buffalo's In The Mist!!  JD http:\/\/t.co\/Z3kYovTw8x",
    "id" : 398858848078794752,
    "created_at" : "2013-11-08 17:05:34 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 398859601934036992,
  "created_at" : "2013-11-08 17:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/398858963447332864\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/CY3QJmmFqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkIHSXCEAAH4ng.jpg",
      "id_str" : "398858963279548416",
      "id" : 398858963279548416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkIHSXCEAAH4ng.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/CY3QJmmFqE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398859526356877313",
  "text" : "RT @Chickypoo333: Raven\u2019s Flight, Sussex, England http:\/\/t.co\/CY3QJmmFqE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/398858963447332864\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/CY3QJmmFqE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkIHSXCEAAH4ng.jpg",
        "id_str" : "398858963279548416",
        "id" : 398858963279548416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkIHSXCEAAH4ng.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/CY3QJmmFqE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398858963447332864",
    "text" : "Raven\u2019s Flight, Sussex, England http:\/\/t.co\/CY3QJmmFqE",
    "id" : 398858963447332864,
    "created_at" : "2013-11-08 17:06:01 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 398859526356877313,
  "created_at" : "2013-11-08 17:08:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 0, 9 ],
      "id_str" : "552094863",
      "id" : 552094863
    }, {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 28, 44 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398480627856445440",
  "geo" : { },
  "id_str" : "398854112449536000",
  "in_reply_to_user_id" : 552094863,
  "text" : "@AWrobley aww.. sweet face! @CatskillCritter",
  "id" : 398854112449536000,
  "in_reply_to_status_id" : 398480627856445440,
  "created_at" : "2013-11-08 16:46:45 +0000",
  "in_reply_to_screen_name" : "AWrobley",
  "in_reply_to_user_id_str" : "552094863",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 0, 14 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398846988940091394",
  "geo" : { },
  "id_str" : "398853818160390145",
  "in_reply_to_user_id" : 1963095853,
  "text" : "@jacqueduncalf heehee!",
  "id" : 398853818160390145,
  "in_reply_to_status_id" : 398846988940091394,
  "created_at" : "2013-11-08 16:45:35 +0000",
  "in_reply_to_screen_name" : "jacqueduncalf",
  "in_reply_to_user_id_str" : "1963095853",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398853723746992128",
  "text" : "RT @jacqueduncalf: \"Has it gone yet Socks\"\"No it's gone up the drain pipe\"\"What are three hiding from\"\"A big Spider\"\"It's a fly son\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398846988940091394\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/hKWiSDkZRF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYj9OSgCIAEaxUY.jpg",
        "id_str" : "398846988948480001",
        "id" : 398846988948480001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYj9OSgCIAEaxUY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 432
        } ],
        "display_url" : "pic.twitter.com\/hKWiSDkZRF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398846988940091394",
    "text" : "\"Has it gone yet Socks\"\"No it's gone up the drain pipe\"\"What are three hiding from\"\"A big Spider\"\"It's a fly son\" http:\/\/t.co\/hKWiSDkZRF",
    "id" : 398846988940091394,
    "created_at" : "2013-11-08 16:18:27 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 398853723746992128,
  "created_at" : "2013-11-08 16:45:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Earth Pics",
      "screen_name" : "ThatsEarth",
      "indices" : [ 18, 29 ],
      "id_str" : "1201661238",
      "id" : 1201661238
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThatsEarth\/status\/398840374544044032\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/QFBscoAanL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYj3NRjIIAAxtZG.jpg",
      "id_str" : "398840374443384832",
      "id" : 398840374443384832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYj3NRjIIAAxtZG.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QFBscoAanL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398853333265686528",
  "text" : "RT @Silvercrone: \u201C@ThatsEarth: Time lapse photo of the sun setting. http:\/\/t.co\/QFBscoAanL\u201D\n\uD83D\uDC9Clovely!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Earth Pics",
        "screen_name" : "ThatsEarth",
        "indices" : [ 1, 12 ],
        "id_str" : "1201661238",
        "id" : 1201661238
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThatsEarth\/status\/398840374544044032\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/QFBscoAanL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYj3NRjIIAAxtZG.jpg",
        "id_str" : "398840374443384832",
        "id" : 398840374443384832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYj3NRjIIAAxtZG.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QFBscoAanL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "398840374544044032",
    "geo" : { },
    "id_str" : "398847362346811392",
    "in_reply_to_user_id" : 1201661238,
    "text" : "\u201C@ThatsEarth: Time lapse photo of the sun setting. http:\/\/t.co\/QFBscoAanL\u201D\n\uD83D\uDC9Clovely!",
    "id" : 398847362346811392,
    "in_reply_to_status_id" : 398840374544044032,
    "created_at" : "2013-11-08 16:19:56 +0000",
    "in_reply_to_screen_name" : "ThatsEarth",
    "in_reply_to_user_id_str" : "1201661238",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 398853333265686528,
  "created_at" : "2013-11-08 16:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Classics",
      "screen_name" : "PenguinClassics",
      "indices" : [ 3, 19 ],
      "id_str" : "23459740",
      "id" : 23459740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ZbughVAwey",
      "expanded_url" : "http:\/\/bit.ly\/1ch28bu",
      "display_url" : "bit.ly\/1ch28bu"
    } ]
  },
  "geo" : { },
  "id_str" : "398840612398829568",
  "text" : "RT @PenguinClassics: RT this tweet for chance to win our new Deluxe edition of FAIRY TALES FROM THE BROTHERS GRIMM! http:\/\/t.co\/ZbughVAwey \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PenguinClassics\/status\/398832396520275969\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/5LI0ZgzFrk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYjv85gCQAEzu8t.jpg",
        "id_str" : "398832396528664577",
        "id" : 398832396528664577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYjv85gCQAEzu8t.jpg",
        "sizes" : [ {
          "h" : 670,
          "resize" : "fit",
          "w" : 438
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 438
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 438
        } ],
        "display_url" : "pic.twitter.com\/5LI0ZgzFrk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ZbughVAwey",
        "expanded_url" : "http:\/\/bit.ly\/1ch28bu",
        "display_url" : "bit.ly\/1ch28bu"
      } ]
    },
    "geo" : { },
    "id_str" : "398832396520275969",
    "text" : "RT this tweet for chance to win our new Deluxe edition of FAIRY TALES FROM THE BROTHERS GRIMM! http:\/\/t.co\/ZbughVAwey http:\/\/t.co\/5LI0ZgzFrk",
    "id" : 398832396520275969,
    "created_at" : "2013-11-08 15:20:28 +0000",
    "user" : {
      "name" : "Penguin Classics",
      "screen_name" : "PenguinClassics",
      "protected" : false,
      "id_str" : "23459740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686939408348483584\/4ZNl1a_O_normal.png",
      "id" : 23459740,
      "verified" : true
    }
  },
  "id" : 398840612398829568,
  "created_at" : "2013-11-08 15:53:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 3, 19 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398836951144726528",
  "text" : "RT @ChristnNitemare: George W. Bush to raise money for group that converts Jews for Jesus to hasten the Second Coming of Christ http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/QQpJna67Im",
        "expanded_url" : "http:\/\/goo.gl\/Y5nhNo",
        "display_url" : "goo.gl\/Y5nhNo"
      } ]
    },
    "geo" : { },
    "id_str" : "398833532069363712",
    "text" : "George W. Bush to raise money for group that converts Jews for Jesus to hasten the Second Coming of Christ http:\/\/t.co\/QQpJna67Im",
    "id" : 398833532069363712,
    "created_at" : "2013-11-08 15:24:58 +0000",
    "user" : {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "protected" : false,
      "id_str" : "116009507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1537898085\/Christian_Nightmares_mug_normal.jpg",
      "id" : 116009507,
      "verified" : false
    }
  },
  "id" : 398836951144726528,
  "created_at" : "2013-11-08 15:38:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tsem Tulku Rinpoche",
      "screen_name" : "tsemtulku",
      "indices" : [ 3, 13 ],
      "id_str" : "23065876",
      "id" : 23065876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398836791786360832",
  "text" : "RT @tsemtulku: Ok, leaving Pennsylvania today and going to New York state. Will be there for a few days. According to Sp, the mountains are\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398834121784700928",
    "text" : "Ok, leaving Pennsylvania today and going to New York state. Will be there for a few days. According to Sp, the mountains are taller there.",
    "id" : 398834121784700928,
    "created_at" : "2013-11-08 15:27:19 +0000",
    "user" : {
      "name" : "Tsem Tulku Rinpoche",
      "screen_name" : "tsemtulku",
      "protected" : false,
      "id_str" : "23065876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1165356530\/aaaaa_normal.jpg",
      "id" : 23065876,
      "verified" : false
    }
  },
  "id" : 398836791786360832,
  "created_at" : "2013-11-08 15:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/cIQ2I2oZKu",
      "expanded_url" : "http:\/\/po.st\/bLoCM6",
      "display_url" : "po.st\/bLoCM6"
    } ]
  },
  "geo" : { },
  "id_str" : "398553336980328448",
  "text" : "Mark Ames: Paul Ryan\u2019s Guru Ayn Rand Worshipped a Serial Killer Who Kidnapped and Dismembered Little Girls http:\/\/t.co\/cIQ2I2oZKu",
  "id" : 398553336980328448,
  "created_at" : "2013-11-07 20:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrell Lewis",
      "screen_name" : "SgBz",
      "indices" : [ 3, 8 ],
      "id_str" : "21954033",
      "id" : 21954033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 113, 116 ]
    }, {
      "text" : "tcot",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/NXKkXHS7dZ",
      "expanded_url" : "http:\/\/is.gd\/bMgucW",
      "display_url" : "is.gd\/bMgucW"
    } ]
  },
  "geo" : { },
  "id_str" : "398546775734484992",
  "text" : "RT @SgBz: Texas school tosses 6th grader\u2019s breakfast in trash after he can\u2019t pay 30 cents http:\/\/t.co\/NXKkXHS7dZ #p2 #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial\u00A9 PRO\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 103, 106 ]
      }, {
        "text" : "tcot",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/NXKkXHS7dZ",
        "expanded_url" : "http:\/\/is.gd\/bMgucW",
        "display_url" : "is.gd\/bMgucW"
      } ]
    },
    "geo" : { },
    "id_str" : "398544479314915328",
    "text" : "Texas school tosses 6th grader\u2019s breakfast in trash after he can\u2019t pay 30 cents http:\/\/t.co\/NXKkXHS7dZ #p2 #tcot",
    "id" : 398544479314915328,
    "created_at" : "2013-11-07 20:16:23 +0000",
    "user" : {
      "name" : "Terrell Lewis",
      "screen_name" : "SgBz",
      "protected" : false,
      "id_str" : "21954033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798941178934792192\/fUEkowk5_normal.jpg",
      "id" : 21954033,
      "verified" : false
    }
  },
  "id" : 398546775734484992,
  "created_at" : "2013-11-07 20:25:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallStNYC",
      "indices" : [ 3, 19 ],
      "id_str" : "335972576",
      "id" : 335972576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/8tkNQknZ9q",
      "expanded_url" : "http:\/\/www.dissentmagazine.org\/blog\/the-public-option-for-higher-education",
      "display_url" : "dissentmagazine.org\/blog\/the-publi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398545593393770496",
  "text" : "RT @OccupyWallStNYC: A 'Public Option' for free higher ed would cost less than 1\/6th of Wall St's ongoing subsidy: http:\/\/t.co\/8tkNQknZ9q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/8tkNQknZ9q",
        "expanded_url" : "http:\/\/www.dissentmagazine.org\/blog\/the-public-option-for-higher-education",
        "display_url" : "dissentmagazine.org\/blog\/the-publi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398524267094372352",
    "text" : "A 'Public Option' for free higher ed would cost less than 1\/6th of Wall St's ongoing subsidy: http:\/\/t.co\/8tkNQknZ9q",
    "id" : 398524267094372352,
    "created_at" : "2013-11-07 18:56:04 +0000",
    "user" : {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallStNYC",
      "protected" : false,
      "id_str" : "335972576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567403358772662272\/BxNhe6D1_normal.jpeg",
      "id" : 335972576,
      "verified" : false
    }
  },
  "id" : 398545593393770496,
  "created_at" : "2013-11-07 20:20:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evolutionvsgod",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hSo8OCyuRo",
      "expanded_url" : "http:\/\/youtu.be\/OPJ6ece-rII",
      "display_url" : "youtu.be\/OPJ6ece-rII"
    } ]
  },
  "geo" : { },
  "id_str" : "398538909010759680",
  "text" : "\"we are only this year's model of humanity\" 01:04:27 RRS vs. Kirk Cameron \/ Ray Comfort Nightline http:\/\/t.co\/hSo8OCyuRo  #evolutionvsgod",
  "id" : 398538909010759680,
  "created_at" : "2013-11-07 19:54:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398534733334085632",
  "text" : "RT @CrystalLewis: Unfortunately, this is the nature of what we do as humans-- we try to exclude others from the definition of full humanity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398534397084696576",
    "text" : "Unfortunately, this is the nature of what we do as humans-- we try to exclude others from the definition of full humanity.",
    "id" : 398534397084696576,
    "created_at" : "2013-11-07 19:36:19 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 398534733334085632,
  "created_at" : "2013-11-07 19:37:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evolutionvsgod",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hSo8OCyuRo",
      "expanded_url" : "http:\/\/youtu.be\/OPJ6ece-rII",
      "display_url" : "youtu.be\/OPJ6ece-rII"
    } ]
  },
  "geo" : { },
  "id_str" : "398534456140496896",
  "text" : "ugh.. both sides are annoying me! RRS vs. Kirk Cameron \/ Ray Comfort Nightline http:\/\/t.co\/hSo8OCyuRo #evolutionvsgod",
  "id" : 398534456140496896,
  "created_at" : "2013-11-07 19:36:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/holycutenesss\/status\/398502921072947200\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/X0ty3KGeFH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYfES5zCMAAceoY.jpg",
      "id_str" : "398502921077141504",
      "id" : 398502921077141504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYfES5zCMAAceoY.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/X0ty3KGeFH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/pCEzd6qXll",
      "expanded_url" : "http:\/\/bit.ly\/HJ6C1c",
      "display_url" : "bit.ly\/HJ6C1c"
    } ]
  },
  "geo" : { },
  "id_str" : "398515435970494464",
  "text" : "RT @holycutenesss: Calf and cat are BFF's http:\/\/t.co\/pCEzd6qXll http:\/\/t.co\/X0ty3KGeFH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/holycutenesss\/status\/398502921072947200\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/X0ty3KGeFH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYfES5zCMAAceoY.jpg",
        "id_str" : "398502921077141504",
        "id" : 398502921077141504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYfES5zCMAAceoY.jpg",
        "sizes" : [ {
          "h" : 364,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/X0ty3KGeFH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/pCEzd6qXll",
        "expanded_url" : "http:\/\/bit.ly\/HJ6C1c",
        "display_url" : "bit.ly\/HJ6C1c"
      } ]
    },
    "geo" : { },
    "id_str" : "398502921072947200",
    "text" : "Calf and cat are BFF's http:\/\/t.co\/pCEzd6qXll http:\/\/t.co\/X0ty3KGeFH",
    "id" : 398502921072947200,
    "created_at" : "2013-11-07 17:31:14 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 398515435970494464,
  "created_at" : "2013-11-07 18:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Untold Secrets",
      "screen_name" : "mostsecretfacts",
      "indices" : [ 3, 19 ],
      "id_str" : "915931760",
      "id" : 915931760
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MostSecretFacts\/status\/397185652455796737\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Q36LcyTrkE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYMWPxzCcAAI_ed.jpg",
      "id_str" : "397185652459991040",
      "id" : 397185652459991040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYMWPxzCcAAI_ed.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Q36LcyTrkE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398514630026592256",
  "text" : "RT @MostSecretFacts: Happy fox and his human friend\u2026 http:\/\/t.co\/Q36LcyTrkE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MostSecretFacts\/status\/397185652455796737\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/Q36LcyTrkE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYMWPxzCcAAI_ed.jpg",
        "id_str" : "397185652459991040",
        "id" : 397185652459991040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYMWPxzCcAAI_ed.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Q36LcyTrkE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397185652455796737",
    "text" : "Happy fox and his human friend\u2026 http:\/\/t.co\/Q36LcyTrkE",
    "id" : 397185652455796737,
    "created_at" : "2013-11-04 02:16:53 +0000",
    "user" : {
      "name" : "Learn Something",
      "screen_name" : "EarnKnowledge",
      "protected" : false,
      "id_str" : "843112550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770497822844006400\/3TwwqOGL_normal.jpg",
      "id" : 843112550,
      "verified" : false
    }
  },
  "id" : 398514630026592256,
  "created_at" : "2013-11-07 18:17:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atekon",
      "screen_name" : "atekonkon",
      "indices" : [ 20, 30 ],
      "id_str" : "262253266",
      "id" : 262253266
    }, {
      "name" : "Templar Knight",
      "screen_name" : "TemplarKnight3",
      "indices" : [ 101, 116 ],
      "id_str" : "1302066865",
      "id" : 1302066865
    }, {
      "name" : "P_Haasan",
      "screen_name" : "P_Haasan",
      "indices" : [ 119, 128 ],
      "id_str" : "1121648666",
      "id" : 1121648666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SuzanneLepage1\/status\/398290095033184256\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/zLqzfx4poO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYcCuzBCcAET5If.jpg",
      "id_str" : "398290095037378561",
      "id" : 398290095037378561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYcCuzBCcAET5If.jpg",
      "sizes" : [ {
        "h" : 607,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zLqzfx4poO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398514528746749952",
  "text" : "RT @missysongbird: \u201C@atekonkon: Rainbow over the Pannonian Plain, Serbia! http:\/\/t.co\/zLqzfx4poO\"\u201DRT @TemplarKnight3: .@P_Haasan: \"@Suzanne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "atekon",
        "screen_name" : "atekonkon",
        "indices" : [ 1, 11 ],
        "id_str" : "262253266",
        "id" : 262253266
      }, {
        "name" : "Templar Knight",
        "screen_name" : "TemplarKnight3",
        "indices" : [ 82, 97 ],
        "id_str" : "1302066865",
        "id" : 1302066865
      }, {
        "name" : "P_Haasan",
        "screen_name" : "P_Haasan",
        "indices" : [ 100, 109 ],
        "id_str" : "1121648666",
        "id" : 1121648666
      }, {
        "name" : "Suzanne Lepage",
        "screen_name" : "SuzanneLepage1",
        "indices" : [ 112, 127 ],
        "id_str" : "350593129",
        "id" : 350593129
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SuzanneLepage1\/status\/398290095033184256\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/zLqzfx4poO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYcCuzBCcAET5If.jpg",
        "id_str" : "398290095037378561",
        "id" : 398290095037378561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYcCuzBCcAET5If.jpg",
        "sizes" : [ {
          "h" : 607,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zLqzfx4poO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "398500223539892224",
    "geo" : { },
    "id_str" : "398508751033876480",
    "in_reply_to_user_id" : 262253266,
    "text" : "\u201C@atekonkon: Rainbow over the Pannonian Plain, Serbia! http:\/\/t.co\/zLqzfx4poO\"\u201DRT @TemplarKnight3: .@P_Haasan: \"@SuzanneLepage1:\u201DLove\uD83D\uDE0D",
    "id" : 398508751033876480,
    "in_reply_to_status_id" : 398500223539892224,
    "created_at" : "2013-11-07 17:54:24 +0000",
    "in_reply_to_screen_name" : "atekonkon",
    "in_reply_to_user_id_str" : "262253266",
    "user" : {
      "name" : "M Birdy",
      "screen_name" : "mebirdy777",
      "protected" : false,
      "id_str" : "1336543388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560464161864298497\/8ZxkWSeh_normal.jpeg",
      "id" : 1336543388,
      "verified" : false
    }
  },
  "id" : 398514528746749952,
  "created_at" : "2013-11-07 18:17:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raycomfort",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/zoSVDttCfj",
      "expanded_url" : "http:\/\/youtu.be\/zyzF8SMQOxU",
      "display_url" : "youtu.be\/zyzF8SMQOxU"
    } ]
  },
  "geo" : { },
  "id_str" : "398500615652798464",
  "text" : "UMM &gt;&gt; \"lot of nut cases gravitate toward the warmth...of local church\" http:\/\/t.co\/zoSVDttCfj  48:20 #raycomfort",
  "id" : 398500615652798464,
  "created_at" : "2013-11-07 17:22:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raycomfort",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/zoSVDttCfj",
      "expanded_url" : "http:\/\/youtu.be\/zyzF8SMQOxU",
      "display_url" : "youtu.be\/zyzF8SMQOxU"
    } ]
  },
  "geo" : { },
  "id_str" : "398497208921636864",
  "text" : "\"but there's lots of things in the bible i dont agree with\" http:\/\/t.co\/zoSVDttCfj 42:46 #raycomfort",
  "id" : 398497208921636864,
  "created_at" : "2013-11-07 17:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "indices" : [ 3, 16 ],
      "id_str" : "8659362",
      "id" : 8659362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CuteOverload\/status\/398483258972721153\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QUi5tqq1Ni",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYeyaaACIAAJueP.jpg",
      "id_str" : "398483258771382272",
      "id" : 398483258771382272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYeyaaACIAAJueP.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/QUi5tqq1Ni"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/WDzDWDjvb3",
      "expanded_url" : "http:\/\/cuteoverload.com\/2013\/11\/07\/this-just-in-finland-owl-rescue-action\/",
      "display_url" : "cuteoverload.com\/2013\/11\/07\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398484094700777472",
  "text" : "RT @CuteOverload: Everybody, check out this story for a terrific Owl Rescue in Finland!\nhttp:\/\/t.co\/WDzDWDjvb3 http:\/\/t.co\/QUi5tqq1Ni",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CuteOverload\/status\/398483258972721153\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/QUi5tqq1Ni",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYeyaaACIAAJueP.jpg",
        "id_str" : "398483258771382272",
        "id" : 398483258771382272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYeyaaACIAAJueP.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/QUi5tqq1Ni"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/WDzDWDjvb3",
        "expanded_url" : "http:\/\/cuteoverload.com\/2013\/11\/07\/this-just-in-finland-owl-rescue-action\/",
        "display_url" : "cuteoverload.com\/2013\/11\/07\/thi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398483258972721153",
    "text" : "Everybody, check out this story for a terrific Owl Rescue in Finland!\nhttp:\/\/t.co\/WDzDWDjvb3 http:\/\/t.co\/QUi5tqq1Ni",
    "id" : 398483258972721153,
    "created_at" : "2013-11-07 16:13:07 +0000",
    "user" : {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "protected" : false,
      "id_str" : "8659362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680609450495873025\/0RV8NzVo_normal.png",
      "id" : 8659362,
      "verified" : false
    }
  },
  "id" : 398484094700777472,
  "created_at" : "2013-11-07 16:16:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398483410261262336",
  "text" : "@weakSquare yeah, i could do with less of the anti gawd talk..lol",
  "id" : 398483410261262336,
  "created_at" : "2013-11-07 16:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398473676976173057",
  "text" : "@weakSquare ring of species.. interesting. she talks a bit fast but i like how she draws it out.",
  "id" : 398473676976173057,
  "created_at" : "2013-11-07 15:35:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398464592814145538\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/gxVk9fl1A7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYehb56CAAAnNjZ.jpg",
      "id_str" : "398464592818339840",
      "id" : 398464592818339840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYehb56CAAAnNjZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gxVk9fl1A7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398469748121686016",
  "text" : "RT @jacqueduncalf: Stunning beauty!! http:\/\/t.co\/gxVk9fl1A7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398464592814145538\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/gxVk9fl1A7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYehb56CAAAnNjZ.jpg",
        "id_str" : "398464592818339840",
        "id" : 398464592818339840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYehb56CAAAnNjZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gxVk9fl1A7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398464592814145538",
    "text" : "Stunning beauty!! http:\/\/t.co\/gxVk9fl1A7",
    "id" : 398464592814145538,
    "created_at" : "2013-11-07 14:58:56 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 398469748121686016,
  "created_at" : "2013-11-07 15:19:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 20, 34 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398453655176626176\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LJPDkPqKNb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYeXfQDCQAAdx4W.jpg",
      "id_str" : "398453655185014784",
      "id" : 398453655185014784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYeXfQDCQAAdx4W.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LJPDkPqKNb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398459955629801472",
  "text" : "RT @missysongbird: \u201C@jacqueduncalf: \"We want to play mummy\"\"not whilst there are stranger's walking around the park\" http:\/\/t.co\/LJPDkPqKNb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jacqueline duncalf",
        "screen_name" : "jacqueduncalf",
        "indices" : [ 1, 15 ],
        "id_str" : "1963095853",
        "id" : 1963095853
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/398453655176626176\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/LJPDkPqKNb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYeXfQDCQAAdx4W.jpg",
        "id_str" : "398453655185014784",
        "id" : 398453655185014784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYeXfQDCQAAdx4W.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LJPDkPqKNb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "398453655176626176",
    "geo" : { },
    "id_str" : "398454228005306368",
    "in_reply_to_user_id" : 1963095853,
    "text" : "\u201C@jacqueduncalf: \"We want to play mummy\"\"not whilst there are stranger's walking around the park\" http:\/\/t.co\/LJPDkPqKNb\u201DSo sweet!",
    "id" : 398454228005306368,
    "in_reply_to_status_id" : 398453655176626176,
    "created_at" : "2013-11-07 14:17:45 +0000",
    "in_reply_to_screen_name" : "jacqueduncalf",
    "in_reply_to_user_id_str" : "1963095853",
    "user" : {
      "name" : "M Birdy",
      "screen_name" : "mebirdy777",
      "protected" : false,
      "id_str" : "1336543388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560464161864298497\/8ZxkWSeh_normal.jpeg",
      "id" : 1336543388,
      "verified" : false
    }
  },
  "id" : 398459955629801472,
  "created_at" : "2013-11-07 14:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaclyn Glenn",
      "screen_name" : "JaclynGlenn",
      "indices" : [ 41, 53 ],
      "id_str" : "397756361",
      "id" : 397756361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398459764419481601",
  "text" : "@weakSquare thanks, i'll take a look : ) @JaclynGlenn",
  "id" : 398459764419481601,
  "created_at" : "2013-11-07 14:39:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398453275457904640",
  "geo" : { },
  "id_str" : "398456990474584064",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter so peaceful",
  "id" : 398456990474584064,
  "in_reply_to_status_id" : 398453275457904640,
  "created_at" : "2013-11-07 14:28:44 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evolutionsvsgod",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398453814564368384",
  "text" : ". @weakSquare someone should make a webpage or document going through each point on his dvd. #evolutionsvsgod",
  "id" : 398453814564368384,
  "created_at" : "2013-11-07 14:16:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398444634726481920",
  "text" : "RT @micahjmurray: I'm amazed at the terrible things people say about God's nature while still maintaining that He is Love. The word \"Love\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398442223743668224",
    "text" : "I'm amazed at the terrible things people say about God's nature while still maintaining that He is Love. The word \"Love\" becomes meaningless",
    "id" : 398442223743668224,
    "created_at" : "2013-11-07 13:30:03 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 398444634726481920,
  "created_at" : "2013-11-07 13:39:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dream hampton",
      "screen_name" : "dreamhampton",
      "indices" : [ 3, 16 ],
      "id_str" : "122208388",
      "id" : 122208388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398263175751426048",
  "text" : "RT @dreamhampton: Because she's a Black woman, not man, Renisha McBride's story will likely not go viral, though it's exactly like Jonathan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398177143714091008",
    "text" : "Because she's a Black woman, not man, Renisha McBride's story will likely not go viral, though it's exactly like Jonathan Ferrell's",
    "id" : 398177143714091008,
    "created_at" : "2013-11-06 19:56:43 +0000",
    "user" : {
      "name" : "dream hampton",
      "screen_name" : "dreamhampton",
      "protected" : false,
      "id_str" : "122208388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619906672400723970\/oq-Ku-a5_normal.jpg",
      "id" : 122208388,
      "verified" : false
    }
  },
  "id" : 398263175751426048,
  "created_at" : "2013-11-07 01:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Solid Muldoon",
      "screen_name" : "Solid_Muldoon",
      "indices" : [ 3, 17 ],
      "id_str" : "921840582",
      "id" : 921840582
    }, {
      "name" : "jef",
      "screen_name" : "mx328",
      "indices" : [ 19, 25 ],
      "id_str" : "279033347",
      "id" : 279033347
    }, {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 26, 40 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398252333840494592",
  "text" : "RT @Solid_Muldoon: @mx328 @JohnFugelsang The goal of every prison should be to become obsolete. If their goal is to make money, their goal \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jef",
        "screen_name" : "mx328",
        "indices" : [ 0, 6 ],
        "id_str" : "279033347",
        "id" : 279033347
      }, {
        "name" : "John Fugelsang",
        "screen_name" : "JohnFugelsang",
        "indices" : [ 7, 21 ],
        "id_str" : "33276161",
        "id" : 33276161
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "398236055960576000",
    "geo" : { },
    "id_str" : "398244940200685568",
    "in_reply_to_user_id" : 279033347,
    "text" : "@mx328 @JohnFugelsang The goal of every prison should be to become obsolete. If their goal is to make money, their goal is more crime.",
    "id" : 398244940200685568,
    "in_reply_to_status_id" : 398236055960576000,
    "created_at" : "2013-11-07 00:26:07 +0000",
    "in_reply_to_screen_name" : "mx328",
    "in_reply_to_user_id_str" : "279033347",
    "user" : {
      "name" : "Solid Muldoon",
      "screen_name" : "Solid_Muldoon",
      "protected" : false,
      "id_str" : "921840582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2798703055\/e0f0a5d4f4592aa519cc4ae42bb7e741_normal.png",
      "id" : 921840582,
      "verified" : false
    }
  },
  "id" : 398252333840494592,
  "created_at" : "2013-11-07 00:55:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strength and Honor",
      "screen_name" : "Avitusparta",
      "indices" : [ 3, 15 ],
      "id_str" : "421047121",
      "id" : 421047121
    }, {
      "name" : "Daily Mirror",
      "screen_name" : "DailyMirror",
      "indices" : [ 119, 131 ],
      "id_str" : "16887175",
      "id" : 16887175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/cm3tz34WMB",
      "expanded_url" : "http:\/\/mirr.im\/1aG0Glu",
      "display_url" : "mirr.im\/1aG0Glu"
    } ]
  },
  "geo" : { },
  "id_str" : "398247344913018880",
  "text" : "RT @Avitusparta: TORY DEPUTY MAYOR: THE BEST THING FOR DISABLED CHILDREN IS THE GUILLOTINE http:\/\/t.co\/cm3tz34WMB  via @DailyMirror",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Mirror",
        "screen_name" : "DailyMirror",
        "indices" : [ 102, 114 ],
        "id_str" : "16887175",
        "id" : 16887175
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/cm3tz34WMB",
        "expanded_url" : "http:\/\/mirr.im\/1aG0Glu",
        "display_url" : "mirr.im\/1aG0Glu"
      } ]
    },
    "geo" : { },
    "id_str" : "398239939604652032",
    "text" : "TORY DEPUTY MAYOR: THE BEST THING FOR DISABLED CHILDREN IS THE GUILLOTINE http:\/\/t.co\/cm3tz34WMB  via @DailyMirror",
    "id" : 398239939604652032,
    "created_at" : "2013-11-07 00:06:15 +0000",
    "user" : {
      "name" : "Strength and Honor",
      "screen_name" : "Avitusparta",
      "protected" : false,
      "id_str" : "421047121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466290589659430912\/h8hN-XYg_normal.jpeg",
      "id" : 421047121,
      "verified" : false
    }
  },
  "id" : 398247344913018880,
  "created_at" : "2013-11-07 00:35:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "indices" : [ 3, 17 ],
      "id_str" : "169354425",
      "id" : 169354425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/bqen3JNo4r",
      "expanded_url" : "http:\/\/dld.bz\/cTDWe",
      "display_url" : "dld.bz\/cTDWe"
    } ]
  },
  "geo" : { },
  "id_str" : "398211230894415872",
  "text" : "RT @MontyMcSquill: After Eating His Dog to Survive, Hiker Is Offered a New One http:\/\/t.co\/bqen3JNo4r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/bqen3JNo4r",
        "expanded_url" : "http:\/\/dld.bz\/cTDWe",
        "display_url" : "dld.bz\/cTDWe"
      } ]
    },
    "geo" : { },
    "id_str" : "398201985687904256",
    "text" : "After Eating His Dog to Survive, Hiker Is Offered a New One http:\/\/t.co\/bqen3JNo4r",
    "id" : 398201985687904256,
    "created_at" : "2013-11-06 21:35:26 +0000",
    "user" : {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "protected" : false,
      "id_str" : "169354425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083700728\/McSquill_normal.jpg",
      "id" : 169354425,
      "verified" : false
    }
  },
  "id" : 398211230894415872,
  "created_at" : "2013-11-06 22:12:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/398182094334992384\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/G0B9mmtm0l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYaggUeCMAA2FW_.jpg",
      "id_str" : "398182094179807232",
      "id" : 398182094179807232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYaggUeCMAA2FW_.jpg",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G0B9mmtm0l"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Xhcw2gFPq8",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/emofly\/reasons-masterchef-junior-is-the-best",
      "display_url" : "buzzfeed.com\/emofly\/reasons\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398186390737129472",
  "text" : "RT @SpiritualNurse: 25 Reasons \u201CMasterchef Junior\u201D Might Be The Best Show On TV\nhttp:\/\/t.co\/Xhcw2gFPq8 http:\/\/t.co\/G0B9mmtm0l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/398182094334992384\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/G0B9mmtm0l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYaggUeCMAA2FW_.jpg",
        "id_str" : "398182094179807232",
        "id" : 398182094179807232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYaggUeCMAA2FW_.jpg",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/G0B9mmtm0l"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/Xhcw2gFPq8",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/emofly\/reasons-masterchef-junior-is-the-best",
        "display_url" : "buzzfeed.com\/emofly\/reasons\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398182094334992384",
    "text" : "25 Reasons \u201CMasterchef Junior\u201D Might Be The Best Show On TV\nhttp:\/\/t.co\/Xhcw2gFPq8 http:\/\/t.co\/G0B9mmtm0l",
    "id" : 398182094334992384,
    "created_at" : "2013-11-06 20:16:23 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 398186390737129472,
  "created_at" : "2013-11-06 20:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stewart",
      "screen_name" : "PaulStewartII",
      "indices" : [ 3, 17 ],
      "id_str" : "291336460",
      "id" : 291336460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StandWithWomen",
      "indices" : [ 99, 114 ]
    }, {
      "text" : "WomenVote",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/1CeivrZEQ0",
      "expanded_url" : "http:\/\/bit.ly\/HATsn3",
      "display_url" : "bit.ly\/HATsn3"
    } ]
  },
  "geo" : { },
  "id_str" : "398185098753110016",
  "text" : "RT @PaulStewartII: Woman arrested and shackled under fetus 'Personhood' law http:\/\/t.co\/1CeivrZEQ0 #StandWithWomen #WomenVote http:\/\/t.co\/8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PaulStewartII\/status\/398164193821880321\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/8iApcDLjTx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYaQOYAIgAAr99L.jpg",
        "id_str" : "398164193704443904",
        "id" : 398164193704443904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYaQOYAIgAAr99L.jpg",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8iApcDLjTx"
      } ],
      "hashtags" : [ {
        "text" : "StandWithWomen",
        "indices" : [ 80, 95 ]
      }, {
        "text" : "WomenVote",
        "indices" : [ 96, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/1CeivrZEQ0",
        "expanded_url" : "http:\/\/bit.ly\/HATsn3",
        "display_url" : "bit.ly\/HATsn3"
      } ]
    },
    "geo" : { },
    "id_str" : "398164193821880321",
    "text" : "Woman arrested and shackled under fetus 'Personhood' law http:\/\/t.co\/1CeivrZEQ0 #StandWithWomen #WomenVote http:\/\/t.co\/8iApcDLjTx",
    "id" : 398164193821880321,
    "created_at" : "2013-11-06 19:05:15 +0000",
    "user" : {
      "name" : "Paul Stewart",
      "screen_name" : "PaulStewartII",
      "protected" : false,
      "id_str" : "291336460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000768760515\/cd560f78716c44254bfbb607e515bfc4_normal.png",
      "id" : 291336460,
      "verified" : false
    }
  },
  "id" : 398185098753110016,
  "created_at" : "2013-11-06 20:28:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RiPPa",
      "screen_name" : "RippDemUp",
      "indices" : [ 3, 13 ],
      "id_str" : "16254215",
      "id" : 16254215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398183222481518592",
  "text" : "RT @RippDemUp: Detroit: Black Woman Shot and Killed Seeking Help After Car Wreck: Okay, so here we go again with anot... http:\/\/t.co\/5Q1293\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TIOMAR",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/5Q1293uXvt",
        "expanded_url" : "http:\/\/bit.ly\/1b6CBmo",
        "display_url" : "bit.ly\/1b6CBmo"
      } ]
    },
    "geo" : { },
    "id_str" : "398181788402479104",
    "text" : "Detroit: Black Woman Shot and Killed Seeking Help After Car Wreck: Okay, so here we go again with anot... http:\/\/t.co\/5Q1293uXvt #TIOMAR",
    "id" : 398181788402479104,
    "created_at" : "2013-11-06 20:15:10 +0000",
    "user" : {
      "name" : "RiPPa",
      "screen_name" : "RippDemUp",
      "protected" : false,
      "id_str" : "16254215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3039245373\/0ccbd6180b0c810069fbab633c598950_normal.jpeg",
      "id" : 16254215,
      "verified" : false
    }
  },
  "id" : 398183222481518592,
  "created_at" : "2013-11-06 20:20:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398168914506444800",
  "geo" : { },
  "id_str" : "398170868137746433",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos : )",
  "id" : 398170868137746433,
  "in_reply_to_status_id" : 398168914506444800,
  "created_at" : "2013-11-06 19:31:47 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398166182944972800",
  "geo" : { },
  "id_str" : "398168467527856129",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos (((hugs))) he missed out on a wonderful young lady.",
  "id" : 398168467527856129,
  "in_reply_to_status_id" : 398166182944972800,
  "created_at" : "2013-11-06 19:22:14 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RIP Molly \uD83D\uDC94 Lilly",
      "screen_name" : "rlhminnie",
      "indices" : [ 3, 13 ],
      "id_str" : "613629898",
      "id" : 613629898
    }, {
      "name" : "kannzaki_xSEI_",
      "screen_name" : "dogbook",
      "indices" : [ 16, 24 ],
      "id_str" : "2560967760",
      "id" : 2560967760
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dogbook\/status\/398157040679284736\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/OaCjDvUKgh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYaJuA7CcAAvbqe.jpg",
      "id_str" : "398157040683479040",
      "id" : 398157040683479040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYaJuA7CcAAvbqe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OaCjDvUKgh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398164508130439168",
  "text" : "RT @rlhminnie: \u201C@dogbook: Some angels choose fur instead of wings. http:\/\/t.co\/OaCjDvUKgh\u201D so true!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kannzaki_xSEI_",
        "screen_name" : "dogbook",
        "indices" : [ 1, 9 ],
        "id_str" : "2560967760",
        "id" : 2560967760
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dogbook\/status\/398157040679284736\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/OaCjDvUKgh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYaJuA7CcAAvbqe.jpg",
        "id_str" : "398157040683479040",
        "id" : 398157040683479040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYaJuA7CcAAvbqe.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OaCjDvUKgh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "398157040679284736",
    "geo" : { },
    "id_str" : "398159904281997312",
    "in_reply_to_user_id" : 1140101490,
    "text" : "\u201C@dogbook: Some angels choose fur instead of wings. http:\/\/t.co\/OaCjDvUKgh\u201D so true!!",
    "id" : 398159904281997312,
    "in_reply_to_status_id" : 398157040679284736,
    "created_at" : "2013-11-06 18:48:13 +0000",
    "in_reply_to_screen_name" : "3MillionDogs",
    "in_reply_to_user_id_str" : "1140101490",
    "user" : {
      "name" : "RIP Molly \uD83D\uDC94 Lilly",
      "screen_name" : "rlhminnie",
      "protected" : false,
      "id_str" : "613629898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797177803531841537\/FXIXCltH_normal.jpg",
      "id" : 613629898,
      "verified" : false
    }
  },
  "id" : 398164508130439168,
  "created_at" : "2013-11-06 19:06:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398152913992048640",
  "text" : "RT @mbekezm: If We Can Bury Carbon Dioxide, Why Not Use It to Make Electricity?: A startup is trying to demonstrate that ca... http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/wiEmZGi4XQ",
        "expanded_url" : "http:\/\/bit.ly\/1b9OIx5",
        "display_url" : "bit.ly\/1b9OIx5"
      } ]
    },
    "geo" : { },
    "id_str" : "398152249785868288",
    "text" : "If We Can Bury Carbon Dioxide, Why Not Use It to Make Electricity?: A startup is trying to demonstrate that ca... http:\/\/t.co\/wiEmZGi4XQ",
    "id" : 398152249785868288,
    "created_at" : "2013-11-06 18:17:48 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 398152913992048640,
  "created_at" : "2013-11-06 18:20:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "barry malin",
      "screen_name" : "b4zzam",
      "indices" : [ 17, 24 ],
      "id_str" : "221517559",
      "id" : 221517559
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/b4zzam\/status\/397053974806667264\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/Y5OzzDxrY0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYKefIWCIAAF1UW.jpg",
      "id_str" : "397053974815055872",
      "id" : 397053974815055872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYKefIWCIAAF1UW.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Y5OzzDxrY0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398150523486228480",
  "text" : "RT @KerriFar: RT @b4zzam: Please share with me: http:\/\/t.co\/Y5OzzDxrY0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "barry malin",
        "screen_name" : "b4zzam",
        "indices" : [ 3, 10 ],
        "id_str" : "221517559",
        "id" : 221517559
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/b4zzam\/status\/397053974806667264\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/Y5OzzDxrY0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYKefIWCIAAF1UW.jpg",
        "id_str" : "397053974815055872",
        "id" : 397053974815055872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYKefIWCIAAF1UW.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Y5OzzDxrY0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398149129496698880",
    "text" : "RT @b4zzam: Please share with me: http:\/\/t.co\/Y5OzzDxrY0",
    "id" : 398149129496698880,
    "created_at" : "2013-11-06 18:05:24 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 398150523486228480,
  "created_at" : "2013-11-06 18:10:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398147032395051009",
  "geo" : { },
  "id_str" : "398148399452536832",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields she's beautiful! congratulations dad! : )",
  "id" : 398148399452536832,
  "in_reply_to_status_id" : 398147032395051009,
  "created_at" : "2013-11-06 18:02:30 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "montag",
      "screen_name" : "buffaloon",
      "indices" : [ 18, 28 ],
      "id_str" : "133793696",
      "id" : 133793696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398147544993501184",
  "text" : "RT @Jamiastar: RT @buffaloon: Police Taser And Arrest Man For Trying To Save His Child From House Fire. The Child Died.  http:\/\/t.co\/y6KWKE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "montag",
        "screen_name" : "buffaloon",
        "indices" : [ 3, 13 ],
        "id_str" : "133793696",
        "id" : 133793696
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/y6KWKEhifQ",
        "expanded_url" : "http:\/\/www.addictinginfo.org\/2013\/11\/06\/police-taser-man-son-fire-died\/",
        "display_url" : "addictinginfo.org\/2013\/11\/06\/pol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398145224217620480",
    "text" : "RT @buffaloon: Police Taser And Arrest Man For Trying To Save His Child From House Fire. The Child Died.  http:\/\/t.co\/y6KWKEhifQ",
    "id" : 398145224217620480,
    "created_at" : "2013-11-06 17:49:53 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 398147544993501184,
  "created_at" : "2013-11-06 17:59:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ziztur",
      "screen_name" : "Ziztur",
      "indices" : [ 0, 7 ],
      "id_str" : "17474206",
      "id" : 17474206
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 23, 38 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398143092903014400",
  "geo" : { },
  "id_str" : "398146903012933632",
  "in_reply_to_user_id" : 17474206,
  "text" : "@Ziztur ohh, good one! @AnnotatedBible",
  "id" : 398146903012933632,
  "in_reply_to_status_id" : 398143092903014400,
  "created_at" : "2013-11-06 17:56:33 +0000",
  "in_reply_to_screen_name" : "Ziztur",
  "in_reply_to_user_id_str" : "17474206",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irish Alcoholic",
      "screen_name" : "Total_Irishness",
      "indices" : [ 0, 16 ],
      "id_str" : "1135132369",
      "id" : 1135132369
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 17, 32 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398142878364745728",
  "geo" : { },
  "id_str" : "398146389277818880",
  "in_reply_to_user_id" : 1135132369,
  "text" : "@Total_Irishness @AnnotatedBible great question for both \"sides\"",
  "id" : 398146389277818880,
  "in_reply_to_status_id" : 398142878364745728,
  "created_at" : "2013-11-06 17:54:31 +0000",
  "in_reply_to_screen_name" : "Total_Irishness",
  "in_reply_to_user_id_str" : "1135132369",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Irish Alcoholic",
      "screen_name" : "Total_Irishness",
      "indices" : [ 20, 36 ],
      "id_str" : "1135132369",
      "id" : 1135132369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398146132981055488",
  "text" : "RT @AnnotatedBible: @Total_Irishness Great point. Things we do in this life can appear pointless no matter what we believe depending on how\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Irish Alcoholic",
        "screen_name" : "Total_Irishness",
        "indices" : [ 0, 16 ],
        "id_str" : "1135132369",
        "id" : 1135132369
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "398142878364745728",
    "geo" : { },
    "id_str" : "398144203751817216",
    "in_reply_to_user_id" : 1135132369,
    "text" : "@Total_Irishness Great point. Things we do in this life can appear pointless no matter what we believe depending on how we view it.",
    "id" : 398144203751817216,
    "in_reply_to_status_id" : 398142878364745728,
    "created_at" : "2013-11-06 17:45:49 +0000",
    "in_reply_to_screen_name" : "Total_Irishness",
    "in_reply_to_user_id_str" : "1135132369",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 398146132981055488,
  "created_at" : "2013-11-06 17:53:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inerrancy",
      "indices" : [ 98, 108 ]
    }, {
      "text" : "Bible",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/dd4uULOGgR",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-lE",
      "display_url" : "wp.me\/p372Ye-lE"
    } ]
  },
  "geo" : { },
  "id_str" : "398139821241405440",
  "text" : "RT @virtusetveritas: new post: I have no idea what I think about the Bible http:\/\/t.co\/dd4uULOGgR #inerrancy #Bible",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inerrancy",
        "indices" : [ 77, 87 ]
      }, {
        "text" : "Bible",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/dd4uULOGgR",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-lE",
        "display_url" : "wp.me\/p372Ye-lE"
      } ]
    },
    "geo" : { },
    "id_str" : "398135782658936832",
    "text" : "new post: I have no idea what I think about the Bible http:\/\/t.co\/dd4uULOGgR #inerrancy #Bible",
    "id" : 398135782658936832,
    "created_at" : "2013-11-06 17:12:22 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 398139821241405440,
  "created_at" : "2013-11-06 17:28:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "indices" : [ 12, 28 ],
      "id_str" : "829603410",
      "id" : 829603410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398121855917101056",
  "text" : "@weakSquare @Fifthcolumnblue since everything in life is subjective, everything is cherry-picked :P",
  "id" : 398121855917101056,
  "created_at" : "2013-11-06 16:17:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "indices" : [ 12, 28 ],
      "id_str" : "829603410",
      "id" : 829603410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398121577557938176",
  "text" : "@weakSquare @Fifthcolumnblue im very skeptical of anything pharma-related. when big profit involved, ethics out the window.",
  "id" : 398121577557938176,
  "created_at" : "2013-11-06 16:15:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Fifthcolumnblue))",
      "screen_name" : "Fifthcolumnblue",
      "indices" : [ 0, 16 ],
      "id_str" : "829603410",
      "id" : 829603410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398118867152547840",
  "geo" : { },
  "id_str" : "398120016941314048",
  "in_reply_to_user_id" : 829603410,
  "text" : "@Fifthcolumnblue yup @weakSquare",
  "id" : 398120016941314048,
  "in_reply_to_status_id" : 398118867152547840,
  "created_at" : "2013-11-06 16:09:43 +0000",
  "in_reply_to_screen_name" : "Fifthcolumnblue",
  "in_reply_to_user_id_str" : "829603410",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/398116001708904448\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/jmakEVopmz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZkZOMCEAAKnrf.jpg",
      "id_str" : "398116001536937984",
      "id" : 398116001536937984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZkZOMCEAAKnrf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 506
      } ],
      "display_url" : "pic.twitter.com\/jmakEVopmz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398117832032288768",
  "text" : "RT @Chickypoo333: Know your Abdominal Pain http:\/\/t.co\/jmakEVopmz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/398116001708904448\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/jmakEVopmz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZkZOMCEAAKnrf.jpg",
        "id_str" : "398116001536937984",
        "id" : 398116001536937984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZkZOMCEAAKnrf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 506
        } ],
        "display_url" : "pic.twitter.com\/jmakEVopmz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398116001708904448",
    "text" : "Know your Abdominal Pain http:\/\/t.co\/jmakEVopmz",
    "id" : 398116001708904448,
    "created_at" : "2013-11-06 15:53:46 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 398117832032288768,
  "created_at" : "2013-11-06 16:01:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398104505775972353",
  "geo" : { },
  "id_str" : "398108434735714304",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter LOL",
  "id" : 398108434735714304,
  "in_reply_to_status_id" : 398104505775972353,
  "created_at" : "2013-11-06 15:23:42 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "indices" : [ 3, 14 ],
      "id_str" : "200405814",
      "id" : 200405814
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/398103417081835520\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/S5jjgklm2R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZY8szIYAATsEl.jpg",
      "id_str" : "398103416909881344",
      "id" : 398103416909881344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZY8szIYAATsEl.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/S5jjgklm2R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398104318576197632",
  "text" : "RT @ftcreature: Fishy kissies! http:\/\/t.co\/S5jjgklm2R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/398103417081835520\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/S5jjgklm2R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZY8szIYAATsEl.jpg",
        "id_str" : "398103416909881344",
        "id" : 398103416909881344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZY8szIYAATsEl.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/S5jjgklm2R"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398103417081835520",
    "text" : "Fishy kissies! http:\/\/t.co\/S5jjgklm2R",
    "id" : 398103417081835520,
    "created_at" : "2013-11-06 15:03:45 +0000",
    "user" : {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "protected" : false,
      "id_str" : "200405814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551555671250849792\/OfxvQB_p_normal.png",
      "id" : 200405814,
      "verified" : false
    }
  },
  "id" : 398104318576197632,
  "created_at" : "2013-11-06 15:07:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Kelly Flanagan",
      "screen_name" : "DrKellyFlanagan",
      "indices" : [ 82, 98 ],
      "id_str" : "410293500",
      "id" : 410293500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/wwrzmYtVAB",
      "expanded_url" : "http:\/\/wp.me\/p2MVTa-Ak",
      "display_url" : "wp.me\/p2MVTa-Ak"
    } ]
  },
  "geo" : { },
  "id_str" : "398104082142875648",
  "text" : "The Reason Every Kid Should Talk Back to Their Parents http:\/\/t.co\/wwrzmYtVAB via @DrKellyFlanagan",
  "id" : 398104082142875648,
  "created_at" : "2013-11-06 15:06:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HPGoodNews",
      "screen_name" : "HPGoodNews",
      "indices" : [ 115, 126 ],
      "id_str" : "2243011218",
      "id" : 2243011218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/0W7PuEijtq",
      "expanded_url" : "http:\/\/huff.to\/1aJA3Zr",
      "display_url" : "huff.to\/1aJA3Zr"
    } ]
  },
  "geo" : { },
  "id_str" : "398097153790201856",
  "text" : "Olivet Middle School Football Players Create Secret Play For Teammate With Disabilities http:\/\/t.co\/0W7PuEijtq via @HPGoodNews",
  "id" : 398097153790201856,
  "created_at" : "2013-11-06 14:38:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "YellowMustard19",
      "indices" : [ 3, 19 ],
      "id_str" : "1024999375",
      "id" : 1024999375
    }, {
      "name" : "Emma & Ariane",
      "screen_name" : "EmmasHopeBook",
      "indices" : [ 109, 123 ],
      "id_str" : "585620743",
      "id" : 585620743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aba",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397866458702950401",
  "text" : "RT @YellowMustard19: We had a happier kid when we ditched #aba. Just our experience. Really liked this post.\u201C@EmmasHopeBook: More On ABA ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emma & Ariane",
        "screen_name" : "EmmasHopeBook",
        "indices" : [ 88, 102 ],
        "id_str" : "585620743",
        "id" : 585620743
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aba",
        "indices" : [ 37, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/kNFIBmTLzj",
        "expanded_url" : "http:\/\/wp.me\/p2rNat-1O5",
        "display_url" : "wp.me\/p2rNat-1O5"
      } ]
    },
    "in_reply_to_status_id_str" : "397753307906977793",
    "geo" : { },
    "id_str" : "397836786384515073",
    "in_reply_to_user_id" : 585620743,
    "text" : "We had a happier kid when we ditched #aba. Just our experience. Really liked this post.\u201C@EmmasHopeBook: More On ABA http:\/\/t.co\/kNFIBmTLzj\u201D",
    "id" : 397836786384515073,
    "in_reply_to_status_id" : 397753307906977793,
    "created_at" : "2013-11-05 21:24:15 +0000",
    "in_reply_to_screen_name" : "EmmasHopeBook",
    "in_reply_to_user_id_str" : "585620743",
    "user" : {
      "name" : "Jen",
      "screen_name" : "YellowMustard19",
      "protected" : false,
      "id_str" : "1024999375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770707729795153920\/McXOA02B_normal.jpg",
      "id" : 1024999375,
      "verified" : false
    }
  },
  "id" : 397866458702950401,
  "created_at" : "2013-11-05 23:22:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shower Thoughts",
      "screen_name" : "TheWeirdWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "487736815",
      "id" : 487736815
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheWeirdWorld\/status\/396474772269572096\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/gCM5xqRMWE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYCPtGLIAAAe1yc.jpg",
      "id_str" : "396474772122763264",
      "id" : 396474772122763264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYCPtGLIAAAe1yc.jpg",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/gCM5xqRMWE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397773656946143232",
  "text" : "RT @TheWeirdWorld: Words that don't exist.. http:\/\/t.co\/gCM5xqRMWE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheWeirdWorld\/status\/396474772269572096\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/gCM5xqRMWE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYCPtGLIAAAe1yc.jpg",
        "id_str" : "396474772122763264",
        "id" : 396474772122763264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYCPtGLIAAAe1yc.jpg",
        "sizes" : [ {
          "h" : 565,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/gCM5xqRMWE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396474772269572096",
    "text" : "Words that don't exist.. http:\/\/t.co\/gCM5xqRMWE",
    "id" : 396474772269572096,
    "created_at" : "2013-11-02 03:12:06 +0000",
    "user" : {
      "name" : "Shower Thoughts",
      "screen_name" : "TheWeirdWorld",
      "protected" : false,
      "id_str" : "487736815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755109975790350336\/8hHO0Yr4_normal.jpg",
      "id" : 487736815,
      "verified" : false
    }
  },
  "id" : 397773656946143232,
  "created_at" : "2013-11-05 17:13:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shower Thoughts",
      "screen_name" : "TheWeirdWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "487736815",
      "id" : 487736815
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheWeirdWorld\/status\/397053244348043264\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8r9OUXx1k6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYKd0myIUAAlnz3.jpg",
      "id_str" : "397053244251590656",
      "id" : 397053244251590656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYKd0myIUAAlnz3.jpg",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8r9OUXx1k6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397769262078898176",
  "text" : "RT @TheWeirdWorld: Five ways to take real college courses for free.. http:\/\/t.co\/8r9OUXx1k6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheWeirdWorld\/status\/397053244348043264\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/8r9OUXx1k6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYKd0myIUAAlnz3.jpg",
        "id_str" : "397053244251590656",
        "id" : 397053244251590656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYKd0myIUAAlnz3.jpg",
        "sizes" : [ {
          "h" : 437,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8r9OUXx1k6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397053244348043264",
    "text" : "Five ways to take real college courses for free.. http:\/\/t.co\/8r9OUXx1k6",
    "id" : 397053244348043264,
    "created_at" : "2013-11-03 17:30:45 +0000",
    "user" : {
      "name" : "Shower Thoughts",
      "screen_name" : "TheWeirdWorld",
      "protected" : false,
      "id_str" : "487736815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755109975790350336\/8hHO0Yr4_normal.jpg",
      "id" : 487736815,
      "verified" : false
    }
  },
  "id" : 397769262078898176,
  "created_at" : "2013-11-05 16:55:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 0, 13 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397766896985989120",
  "geo" : { },
  "id_str" : "397768511247749120",
  "in_reply_to_user_id" : 33427866,
  "text" : "@Chickypoo333 squee! too cute!",
  "id" : 397768511247749120,
  "in_reply_to_status_id" : 397766896985989120,
  "created_at" : "2013-11-05 16:52:57 +0000",
  "in_reply_to_screen_name" : "Chickypoo333",
  "in_reply_to_user_id_str" : "33427866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397762988427341825",
  "text" : "@KevinRDaugherty oh no.. feel better. tea w honey, lemon. no milk products. and rest.",
  "id" : 397762988427341825,
  "created_at" : "2013-11-05 16:31:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397755384871387136",
  "geo" : { },
  "id_str" : "397762348577853440",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter i love to see the critters in our yard.. deer, turkey, crows, etc. makes me happy. : )",
  "id" : 397762348577853440,
  "in_reply_to_status_id" : 397755384871387136,
  "created_at" : "2013-11-05 16:28:28 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397750255627669504",
  "geo" : { },
  "id_str" : "397752120926941185",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter beautiful!",
  "id" : 397752120926941185,
  "in_reply_to_status_id" : 397750255627669504,
  "created_at" : "2013-11-05 15:47:50 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adela Metcalfe",
      "screen_name" : "AdelaGingeree",
      "indices" : [ 3, 17 ],
      "id_str" : "1301048509",
      "id" : 1301048509
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AdelaGingeree\/status\/397641279020228608\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/BIhnrzl6Ef",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYS0ot3IMAAnFgW.jpg",
      "id_str" : "397641278714032128",
      "id" : 397641278714032128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYS0ot3IMAAnFgW.jpg",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/BIhnrzl6Ef"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397745196848664576",
  "text" : "RT @AdelaGingeree: Good morning... http:\/\/t.co\/BIhnrzl6Ef",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AdelaGingeree\/status\/397641279020228608\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/BIhnrzl6Ef",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYS0ot3IMAAnFgW.jpg",
        "id_str" : "397641278714032128",
        "id" : 397641278714032128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYS0ot3IMAAnFgW.jpg",
        "sizes" : [ {
          "h" : 508,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/BIhnrzl6Ef"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397641279020228608",
    "text" : "Good morning... http:\/\/t.co\/BIhnrzl6Ef",
    "id" : 397641279020228608,
    "created_at" : "2013-11-05 08:27:23 +0000",
    "user" : {
      "name" : "Adela Metcalfe",
      "screen_name" : "AdelaGingeree",
      "protected" : false,
      "id_str" : "1301048509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767108963510910976\/z2cNrSaA_normal.jpg",
      "id" : 1301048509,
      "verified" : false
    }
  },
  "id" : 397745196848664576,
  "created_at" : "2013-11-05 15:20:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397740556878499840",
  "geo" : { },
  "id_str" : "397744885685420032",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 awww.. lol",
  "id" : 397744885685420032,
  "in_reply_to_status_id" : 397740556878499840,
  "created_at" : "2013-11-05 15:19:05 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Pat English",
      "screen_name" : "Squirrelbasket",
      "indices" : [ 17, 32 ],
      "id_str" : "40189152",
      "id" : 40189152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/5MfEirkbPF",
      "expanded_url" : "http:\/\/bit.ly\/1cFb9LR",
      "display_url" : "bit.ly\/1cFb9LR"
    } ]
  },
  "geo" : { },
  "id_str" : "397744231529607168",
  "text" : "RT @KerriFar: RT @squirrelbasket: Interesting idea - glow-in-the-dark paths instead of street lights? http:\/\/t.co\/5MfEirkbPF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pat English",
        "screen_name" : "Squirrelbasket",
        "indices" : [ 3, 18 ],
        "id_str" : "40189152",
        "id" : 40189152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/5MfEirkbPF",
        "expanded_url" : "http:\/\/bit.ly\/1cFb9LR",
        "display_url" : "bit.ly\/1cFb9LR"
      } ]
    },
    "geo" : { },
    "id_str" : "397741808031371264",
    "text" : "RT @squirrelbasket: Interesting idea - glow-in-the-dark paths instead of street lights? http:\/\/t.co\/5MfEirkbPF",
    "id" : 397741808031371264,
    "created_at" : "2013-11-05 15:06:51 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 397744231529607168,
  "created_at" : "2013-11-05 15:16:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397732427449511936",
  "geo" : { },
  "id_str" : "397742859140349952",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC thanks : )",
  "id" : 397742859140349952,
  "in_reply_to_status_id" : 397732427449511936,
  "created_at" : "2013-11-05 15:11:01 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397730225930268672",
  "text" : "no bible study for me today. felt off yesterday and this am. : (",
  "id" : 397730225930268672,
  "created_at" : "2013-11-05 14:20:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GenOpportunity",
      "screen_name" : "GenOpportunity",
      "indices" : [ 3, 18 ],
      "id_str" : "1418714336",
      "id" : 1418714336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397540425772580864",
  "text" : "RT @GenOpportunity: \"I had great cancer doctors &amp; health insurance. My plan was cancelled. Now I worry how long I'll live.\" #Obamacare http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/ZhyVlTYxz4",
        "expanded_url" : "http:\/\/on.wsj.com\/1aWd2o0",
        "display_url" : "on.wsj.com\/1aWd2o0"
      } ]
    },
    "geo" : { },
    "id_str" : "397365231367622656",
    "text" : "\"I had great cancer doctors &amp; health insurance. My plan was cancelled. Now I worry how long I'll live.\" #Obamacare http:\/\/t.co\/ZhyVlTYxz4",
    "id" : 397365231367622656,
    "created_at" : "2013-11-04 14:10:28 +0000",
    "user" : {
      "name" : "GenOpp",
      "screen_name" : "GenOpp",
      "protected" : false,
      "id_str" : "262970655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737723068890546176\/aeMYdP2i_normal.jpg",
      "id" : 262970655,
      "verified" : true
    }
  },
  "id" : 397540425772580864,
  "created_at" : "2013-11-05 01:46:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Public Integrity",
      "screen_name" : "Publici",
      "indices" : [ 3, 11 ],
      "id_str" : "19034656",
      "id" : 19034656
    }, {
      "name" : "Wendell Potter",
      "screen_name" : "wendellpotter",
      "indices" : [ 40, 54 ],
      "id_str" : "16950628",
      "id" : 16950628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397539606113312769",
  "text" : "RT @Publici: Frmr health insurance exec @wendellpotter recognizes tactics from his old job during congressional Obamacare hearing http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wendell Potter",
        "screen_name" : "wendellpotter",
        "indices" : [ 27, 41 ],
        "id_str" : "16950628",
        "id" : 16950628
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tEMTuo2alC",
        "expanded_url" : "http:\/\/bit.ly\/19u9GrP",
        "display_url" : "bit.ly\/19u9GrP"
      } ]
    },
    "geo" : { },
    "id_str" : "397463914004217857",
    "text" : "Frmr health insurance exec @wendellpotter recognizes tactics from his old job during congressional Obamacare hearing http:\/\/t.co\/tEMTuo2alC",
    "id" : 397463914004217857,
    "created_at" : "2013-11-04 20:42:36 +0000",
    "user" : {
      "name" : "Public Integrity",
      "screen_name" : "Publici",
      "protected" : false,
      "id_str" : "19034656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539523590702395392\/UksSDUqp_normal.png",
      "id" : 19034656,
      "verified" : true
    }
  },
  "id" : 397539606113312769,
  "created_at" : "2013-11-05 01:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    }, {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 108, 122 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LifeWise",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "Humana",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397537555606159360",
  "text" : "RT @KellyRek: Examples showing how #LifeWise and #Humana have been deceiving customers ... Link provided by @AllOnMedicare =&gt; [TPM] http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 94, 108 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LifeWise",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "Humana",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/O621FUSvmu",
        "expanded_url" : "http:\/\/bit.ly\/16BlIP5",
        "display_url" : "bit.ly\/16BlIP5"
      } ]
    },
    "geo" : { },
    "id_str" : "397536426696261632",
    "text" : "Examples showing how #LifeWise and #Humana have been deceiving customers ... Link provided by @AllOnMedicare =&gt; [TPM] http:\/\/t.co\/O621FUSvmu",
    "id" : 397536426696261632,
    "created_at" : "2013-11-05 01:30:44 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 397537555606159360,
  "created_at" : "2013-11-05 01:35:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stunning Pictures",
      "screen_name" : "PicturesEarth",
      "indices" : [ 3, 17 ],
      "id_str" : "1098364164",
      "id" : 1098364164
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PicturesEarth\/status\/396328883462471680\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FsmkBqxNlt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYALBPtCMAAGe6M.jpg",
      "id_str" : "396328883231797248",
      "id" : 396328883231797248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYALBPtCMAAGe6M.jpg",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/FsmkBqxNlt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397530875958923264",
  "text" : "RT @PicturesEarth: Solar Eclipse and Milky Way seen from ISS (International Space Station) http:\/\/t.co\/FsmkBqxNlt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PicturesEarth\/status\/396328883462471680\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/FsmkBqxNlt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYALBPtCMAAGe6M.jpg",
        "id_str" : "396328883231797248",
        "id" : 396328883231797248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYALBPtCMAAGe6M.jpg",
        "sizes" : [ {
          "h" : 324,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/FsmkBqxNlt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396328883462471680",
    "text" : "Solar Eclipse and Milky Way seen from ISS (International Space Station) http:\/\/t.co\/FsmkBqxNlt",
    "id" : 396328883462471680,
    "created_at" : "2013-11-01 17:32:23 +0000",
    "user" : {
      "name" : "Stunning Pictures",
      "screen_name" : "PicturesEarth",
      "protected" : false,
      "id_str" : "1098364164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000821899035\/3c54c23ddce812cef8c1a0e2141e4505_normal.jpeg",
      "id" : 1098364164,
      "verified" : false
    }
  },
  "id" : 397530875958923264,
  "created_at" : "2013-11-05 01:08:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 3, 15 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annoyed",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397443220814450688",
  "text" : "RT @Jeweldspear: Not sure how they can tell me what I can &amp; can't grow in my yard. Someone must be allergic to blackberries. #annoyed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "annoyed",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397440461624721408",
    "text" : "Not sure how they can tell me what I can &amp; can't grow in my yard. Someone must be allergic to blackberries. #annoyed",
    "id" : 397440461624721408,
    "created_at" : "2013-11-04 19:09:24 +0000",
    "user" : {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "protected" : false,
      "id_str" : "51846392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655444947940823041\/ORiamX3x_normal.jpg",
      "id" : 51846392,
      "verified" : false
    }
  },
  "id" : 397443220814450688,
  "created_at" : "2013-11-04 19:20:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397400535638495234",
  "text" : "RT @TheGoldenMirror: Seek out positive people instead of trying to change negative ones. Don't expect others to facilitate your change. Con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397398150908231682",
    "text" : "Seek out positive people instead of trying to change negative ones. Don't expect others to facilitate your change. Control your own fate.",
    "id" : 397398150908231682,
    "created_at" : "2013-11-04 16:21:17 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 397400535638495234,
  "created_at" : "2013-11-04 16:30:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shelf Pleasure",
      "screen_name" : "ShelfPleasure",
      "indices" : [ 3, 17 ],
      "id_str" : "555546155",
      "id" : 555546155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397400185409896448",
  "text" : "RT @ShelfPleasure: \"I always read. You know how sharks have to keep swimming or they die? I'm like that. If I stop reading, I die.\" - Patri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397396107896315904",
    "text" : "\"I always read. You know how sharks have to keep swimming or they die? I'm like that. If I stop reading, I die.\" - Patrick Rothfuss",
    "id" : 397396107896315904,
    "created_at" : "2013-11-04 16:13:10 +0000",
    "user" : {
      "name" : "Shelf Pleasure",
      "screen_name" : "ShelfPleasure",
      "protected" : false,
      "id_str" : "555546155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3253020788\/cb35d38e7f75d4f49dc192850d62fa09_normal.jpeg",
      "id" : 555546155,
      "verified" : false
    }
  },
  "id" : 397400185409896448,
  "created_at" : "2013-11-04 16:29:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 0, 13 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397393096591175680",
  "geo" : { },
  "id_str" : "397394333340405760",
  "in_reply_to_user_id" : 33427866,
  "text" : "@Chickypoo333 adorable!",
  "id" : 397394333340405760,
  "in_reply_to_status_id" : 397393096591175680,
  "created_at" : "2013-11-04 16:06:06 +0000",
  "in_reply_to_screen_name" : "Chickypoo333",
  "in_reply_to_user_id_str" : "33427866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/397393096591175680\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/1p4GFBvFYX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYPS6muCEAE5uYc.jpg",
      "id_str" : "397393096406601729",
      "id" : 397393096406601729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYPS6muCEAE5uYc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/1p4GFBvFYX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397394286628835328",
  "text" : "RT @Chickypoo333: Look what I found! Can we keep him? http:\/\/t.co\/1p4GFBvFYX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/397393096591175680\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/1p4GFBvFYX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYPS6muCEAE5uYc.jpg",
        "id_str" : "397393096406601729",
        "id" : 397393096406601729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYPS6muCEAE5uYc.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/1p4GFBvFYX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397393096591175680",
    "text" : "Look what I found! Can we keep him? http:\/\/t.co\/1p4GFBvFYX",
    "id" : 397393096591175680,
    "created_at" : "2013-11-04 16:01:12 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 397394286628835328,
  "created_at" : "2013-11-04 16:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/4VJc0pOMZD",
      "expanded_url" : "http:\/\/youtu.be\/chjHPSLapv8",
      "display_url" : "youtu.be\/chjHPSLapv8"
    } ]
  },
  "geo" : { },
  "id_str" : "397392203477024768",
  "text" : "i hope someday i can be as beautiful as mama hill. http:\/\/t.co\/4VJc0pOMZD",
  "id" : 397392203477024768,
  "created_at" : "2013-11-04 15:57:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ahamoment",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397391356017913856",
  "text" : "a moment of kindness or love can change someone's life.. that is the power we all have within us. #ahamoment",
  "id" : 397391356017913856,
  "created_at" : "2013-11-04 15:54:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 62, 71 ],
      "id_str" : "524396430",
      "id" : 524396430
    }, {
      "name" : "SoulPancake",
      "screen_name" : "soulpancake",
      "indices" : [ 73, 85 ],
      "id_str" : "19636959",
      "id" : 19636959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/cA2D2TENNG",
      "expanded_url" : "http:\/\/www.upworthy.com\/the-woman-who-has-as-close-to-a-super-power-as-we-can-get-2?g=2&c=ufb1",
      "display_url" : "upworthy.com\/the-woman-who-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397389948342370304",
  "text" : "The woman who has as close to a superpower as we can get (via @Upworthy) @soulpancake  http:\/\/t.co\/cA2D2TENNG",
  "id" : 397389948342370304,
  "created_at" : "2013-11-04 15:48:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397165747790962688",
  "geo" : { },
  "id_str" : "397170685157470208",
  "in_reply_to_user_id" : 140291463,
  "text" : "@SkypilotOfHope aww.. she does look sorry... lol",
  "id" : 397170685157470208,
  "in_reply_to_status_id" : 397165747790962688,
  "created_at" : "2013-11-04 01:17:25 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397112105205121027",
  "geo" : { },
  "id_str" : "397113342629654528",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell dh would love to live in scotland. he has scotch in him and loves the land.",
  "id" : 397113342629654528,
  "in_reply_to_status_id" : 397112105205121027,
  "created_at" : "2013-11-03 21:29:33 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 3, 15 ],
      "id_str" : "17004618",
      "id" : 17004618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ny30xTR90X",
      "expanded_url" : "http:\/\/nyti.ms\/1iDcpAp",
      "display_url" : "nyti.ms\/1iDcpAp"
    } ]
  },
  "geo" : { },
  "id_str" : "397102107733815296",
  "text" : "RT @NickKristof: Meet Rich Streeter, the subject of my column today about why we need Obamacare: http:\/\/t.co\/ny30xTR90X http:\/\/t.co\/hvJvxnP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NickKristof\/status\/397038115497340929\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/hvJvxnPT5v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYKQD9QCUAAkrwh.jpg",
        "id_str" : "397038114817855488",
        "id" : 397038114817855488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYKQD9QCUAAkrwh.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3000,
          "resize" : "fit",
          "w" : 4000
        } ],
        "display_url" : "pic.twitter.com\/hvJvxnPT5v"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/ny30xTR90X",
        "expanded_url" : "http:\/\/nyti.ms\/1iDcpAp",
        "display_url" : "nyti.ms\/1iDcpAp"
      } ]
    },
    "geo" : { },
    "id_str" : "397038115497340929",
    "text" : "Meet Rich Streeter, the subject of my column today about why we need Obamacare: http:\/\/t.co\/ny30xTR90X http:\/\/t.co\/hvJvxnPT5v",
    "id" : 397038115497340929,
    "created_at" : "2013-11-03 16:30:38 +0000",
    "user" : {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "protected" : false,
      "id_str" : "17004618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680936862387589120\/DfkrlW27_normal.jpg",
      "id" : 17004618,
      "verified" : true
    }
  },
  "id" : 397102107733815296,
  "created_at" : "2013-11-03 20:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/NsFjS41qTZ",
      "expanded_url" : "http:\/\/www.takepart.com\/article\/2013\/10\/30\/starpath-glow-in-the-dark-roads-provide-energy-free-illumination",
      "display_url" : "takepart.com\/article\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397062797957558272",
  "text" : "RT @MWM4444: This is cool -- stuff you spray on pavement to glow in the dark, so you need fewer street lights: http:\/\/t.co\/NsFjS41qTZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/NsFjS41qTZ",
        "expanded_url" : "http:\/\/www.takepart.com\/article\/2013\/10\/30\/starpath-glow-in-the-dark-roads-provide-energy-free-illumination",
        "display_url" : "takepart.com\/article\/2013\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397060980330344449",
    "text" : "This is cool -- stuff you spray on pavement to glow in the dark, so you need fewer street lights: http:\/\/t.co\/NsFjS41qTZ",
    "id" : 397060980330344449,
    "created_at" : "2013-11-03 18:01:29 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 397062797957558272,
  "created_at" : "2013-11-03 18:08:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397055729661526016",
  "geo" : { },
  "id_str" : "397060328606806016",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses oh pretty!",
  "id" : 397060328606806016,
  "in_reply_to_status_id" : 397055729661526016,
  "created_at" : "2013-11-03 17:58:54 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397059039902724096",
  "text" : "there was a shiba inu in the other room who wasnt having any of it. let out some screams..lol. our dog was like WTH?..lol",
  "id" : 397059039902724096,
  "created_at" : "2013-11-03 17:53:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397058643201245185",
  "text" : "tried out the self-serve doggie wash today.",
  "id" : 397058643201245185,
  "created_at" : "2013-11-03 17:52:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/TOr61y6ono",
      "expanded_url" : "http:\/\/wp.me\/p1ML21-wL",
      "display_url" : "wp.me\/p1ML21-wL"
    } ]
  },
  "geo" : { },
  "id_str" : "397001207526752257",
  "text" : "RT @CrystalLewis: Who Are You? (A thought-provoking video...) http:\/\/t.co\/TOr61y6ono",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/TOr61y6ono",
        "expanded_url" : "http:\/\/wp.me\/p1ML21-wL",
        "display_url" : "wp.me\/p1ML21-wL"
      } ]
    },
    "geo" : { },
    "id_str" : "396851789989158912",
    "text" : "Who Are You? (A thought-provoking video...) http:\/\/t.co\/TOr61y6ono",
    "id" : 396851789989158912,
    "created_at" : "2013-11-03 04:10:14 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 397001207526752257,
  "created_at" : "2013-11-03 14:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396799607025704961",
  "text" : "RT @TimGreaton: Interviewer, \"Did Under-Heaven make some religions mad?\" My answer,  \"I was telling a story not building a religion.\" http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/mmbapJwMGO",
        "expanded_url" : "http:\/\/amzn.to\/10YCxwm",
        "display_url" : "amzn.to\/10YCxwm"
      } ]
    },
    "geo" : { },
    "id_str" : "396798158392807424",
    "text" : "Interviewer, \"Did Under-Heaven make some religions mad?\" My answer,  \"I was telling a story not building a religion.\" http:\/\/t.co\/mmbapJwMGO",
    "id" : 396798158392807424,
    "created_at" : "2013-11-03 00:37:07 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 396799607025704961,
  "created_at" : "2013-11-03 00:42:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/pressgr.am\/\" rel=\"nofollow\"\u003EPressgram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/396749262132092928\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/AzEWY9dbKi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYGJWgRIYAAPL87.jpg",
      "id_str" : "396749261897228288",
      "id" : 396749261897228288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYGJWgRIYAAPL87.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AzEWY9dbKi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/wj1gkh1xj5",
      "expanded_url" : "http:\/\/moosebegab.com\/photos\/?p=66",
      "display_url" : "moosebegab.com\/photos\/?p=66"
    }, {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/zynG1TGoSu",
      "expanded_url" : "http:\/\/i.pressgr.am\/photo\/44234",
      "display_url" : "i.pressgr.am\/photo\/44234"
    } ]
  },
  "geo" : { },
  "id_str" : "396749262132092928",
  "text" : "Sunset through curtain http:\/\/t.co\/wj1gkh1xj5 http:\/\/t.co\/zynG1TGoSu http:\/\/t.co\/AzEWY9dbKi",
  "id" : 396749262132092928,
  "created_at" : "2013-11-02 21:22:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396729729220632576",
  "text" : "RT @richarddoetsch: Who decided the path we are expected to follow and why do we follow it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396728213768257537",
    "text" : "Who decided the path we are expected to follow and why do we follow it?",
    "id" : 396728213768257537,
    "created_at" : "2013-11-02 19:59:11 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 396729729220632576,
  "created_at" : "2013-11-02 20:05:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396726279304908800",
  "text" : "RT @TheOracle13: Love is expansion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396716952506216448",
    "text" : "Love is expansion.",
    "id" : 396716952506216448,
    "created_at" : "2013-11-02 19:14:26 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 396726279304908800,
  "created_at" : "2013-11-02 19:51:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackthorne",
      "screen_name" : "_Blackth0rne_",
      "indices" : [ 3, 17 ],
      "id_str" : "719268756",
      "id" : 719268756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/K701cB2QOi",
      "expanded_url" : "http:\/\/shar.es\/IkFuB",
      "display_url" : "shar.es\/IkFuB"
    } ]
  },
  "geo" : { },
  "id_str" : "396725849547751424",
  "text" : "RT @_Blackth0rne_: North Carolina Mother of 4: Food stamps cut from $500 to $16 per month http:\/\/t.co\/K701cB2QOi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/K701cB2QOi",
        "expanded_url" : "http:\/\/shar.es\/IkFuB",
        "display_url" : "shar.es\/IkFuB"
      } ]
    },
    "geo" : { },
    "id_str" : "396717939002318849",
    "text" : "North Carolina Mother of 4: Food stamps cut from $500 to $16 per month http:\/\/t.co\/K701cB2QOi",
    "id" : 396717939002318849,
    "created_at" : "2013-11-02 19:18:21 +0000",
    "user" : {
      "name" : "Blackthorne",
      "screen_name" : "_Blackth0rne_",
      "protected" : false,
      "id_str" : "719268756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3180215388\/db90a0ae68d708f0d314318405655dd7_normal.png",
      "id" : 719268756,
      "verified" : false
    }
  },
  "id" : 396725849547751424,
  "created_at" : "2013-11-02 19:49:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396721414147158016",
  "text" : "RT @alanhdawe: As you believe, so it comes into reality for you. You need to take care about what you believe in as that does become real f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396108340482539520",
    "text" : "As you believe, so it comes into reality for you. You need to take care about what you believe in as that does become real for you. #TGFBook",
    "id" : 396108340482539520,
    "created_at" : "2013-11-01 02:56:02 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 396721414147158016,
  "created_at" : "2013-11-02 19:32:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ McAninch",
      "screen_name" : "jmcaninch68",
      "indices" : [ 3, 15 ],
      "id_str" : "45142252",
      "id" : 45142252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396721008700579841",
  "text" : "RT @jmcaninch68: Horses are companion animals who have served humans 1000s of yrs. Slaughtering them for dilettante palettes is horrific.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396396267661578240",
    "text" : "Horses are companion animals who have served humans 1000s of yrs. Slaughtering them for dilettante palettes is horrific.",
    "id" : 396396267661578240,
    "created_at" : "2013-11-01 22:00:09 +0000",
    "user" : {
      "name" : "AJ McAninch",
      "screen_name" : "jmcaninch68",
      "protected" : false,
      "id_str" : "45142252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797528363674062848\/pTmN8ygU_normal.jpg",
      "id" : 45142252,
      "verified" : false
    }
  },
  "id" : 396721008700579841,
  "created_at" : "2013-11-02 19:30:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396720875443322881",
  "text" : "RT @HoodedMan: The herd praises militarism like a moth praises the flame",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396711482517250048",
    "text" : "The herd praises militarism like a moth praises the flame",
    "id" : 396711482517250048,
    "created_at" : "2013-11-02 18:52:42 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 396720875443322881,
  "created_at" : "2013-11-02 19:30:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/t9Doddf1bH",
      "expanded_url" : "http:\/\/www.soulseeds.com\/seed-exchange\/2012\/10\/drugging-einstein-an-article-on-add-and-dislexia-by-stacy-conde\/",
      "display_url" : "soulseeds.com\/seed-exchange\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396720552301166592",
  "text" : "RT @Soulseedzforall: ADD and dyslexia are not disabilities, the are different abilities http:\/\/t.co\/t9Doddf1bH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/t9Doddf1bH",
        "expanded_url" : "http:\/\/www.soulseeds.com\/seed-exchange\/2012\/10\/drugging-einstein-an-article-on-add-and-dislexia-by-stacy-conde\/",
        "display_url" : "soulseeds.com\/seed-exchange\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396712334959181824",
    "text" : "ADD and dyslexia are not disabilities, the are different abilities http:\/\/t.co\/t9Doddf1bH",
    "id" : 396712334959181824,
    "created_at" : "2013-11-02 18:56:05 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 396720552301166592,
  "created_at" : "2013-11-02 19:28:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396677515760390145",
  "text" : "RT @ChrisCapparell: Not all those who wander are lost, but all those who are lost are blind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396665171583983616",
    "text" : "Not all those who wander are lost, but all those who are lost are blind.",
    "id" : 396665171583983616,
    "created_at" : "2013-11-02 15:48:41 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 396677515760390145,
  "created_at" : "2013-11-02 16:37:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 0, 6 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396667180860719105",
  "geo" : { },
  "id_str" : "396677096656748544",
  "in_reply_to_user_id" : 33033233,
  "text" : "@Oshum bless you : )",
  "id" : 396677096656748544,
  "in_reply_to_status_id" : 396667180860719105,
  "created_at" : "2013-11-02 16:36:04 +0000",
  "in_reply_to_screen_name" : "Oshum",
  "in_reply_to_user_id_str" : "33033233",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396676679852359680",
  "text" : "RT @ChrisCapparell: Whatever captures and keeps our attention captures and keeps us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396669006549352449",
    "text" : "Whatever captures and keeps our attention captures and keeps us.",
    "id" : 396669006549352449,
    "created_at" : "2013-11-02 16:03:55 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 396676679852359680,
  "created_at" : "2013-11-02 16:34:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fear",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "Angel",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "love",
      "indices" : [ 63, 68 ]
    }, {
      "text" : "Min",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396676005865467904",
  "text" : "RT @InvisCollege: #Fear is an #Angel that inspires you to find #love. #Min",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fear",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "Angel",
        "indices" : [ 12, 18 ]
      }, {
        "text" : "love",
        "indices" : [ 45, 50 ]
      }, {
        "text" : "Min",
        "indices" : [ 52, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396671594380414976",
    "text" : "#Fear is an #Angel that inspires you to find #love. #Min",
    "id" : 396671594380414976,
    "created_at" : "2013-11-02 16:14:12 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 396676005865467904,
  "created_at" : "2013-11-02 16:31:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396675958302048257",
  "text" : "RT @angelaharms: I cannot fly without putting the seat back. Shall I not fly? or shall I put the seat back?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396671652181725184",
    "text" : "I cannot fly without putting the seat back. Shall I not fly? or shall I put the seat back?",
    "id" : 396671652181725184,
    "created_at" : "2013-11-02 16:14:26 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 396675958302048257,
  "created_at" : "2013-11-02 16:31:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396675883835985921",
  "text" : "@1stCitizenKane \"We're pieces of it, not the other way around.\" &lt;&lt; YES",
  "id" : 396675883835985921,
  "created_at" : "2013-11-02 16:31:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396675397107998721",
  "text" : "@1stCitizenKane im not sure i agree w 1st part but i like the 2nd part.",
  "id" : 396675397107998721,
  "created_at" : "2013-11-02 16:29:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "indices" : [ 3, 12 ],
      "id_str" : "800652126",
      "id" : 800652126
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/396667948720345088\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/8J54nXC0Cj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYE_ZdGCUAEiVrE.jpg",
      "id_str" : "396667948724539393",
      "id" : 396667948724539393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYE_ZdGCUAEiVrE.jpg",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8J54nXC0Cj"
    } ],
    "hashtags" : [ {
      "text" : "Raturday",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396675091041628160",
  "text" : "RT @MrRat395: Happy #Raturday!!!! http:\/\/t.co\/8J54nXC0Cj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/396667948720345088\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/8J54nXC0Cj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYE_ZdGCUAEiVrE.jpg",
        "id_str" : "396667948724539393",
        "id" : 396667948724539393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYE_ZdGCUAEiVrE.jpg",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8J54nXC0Cj"
      } ],
      "hashtags" : [ {
        "text" : "Raturday",
        "indices" : [ 6, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396667948720345088",
    "text" : "Happy #Raturday!!!! http:\/\/t.co\/8J54nXC0Cj",
    "id" : 396667948720345088,
    "created_at" : "2013-11-02 15:59:43 +0000",
    "user" : {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "protected" : false,
      "id_str" : "800652126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779503692802240512\/iVwM-mwl_normal.jpg",
      "id" : 800652126,
      "verified" : false
    }
  },
  "id" : 396675091041628160,
  "created_at" : "2013-11-02 16:28:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396674023913828352",
  "text" : "dear Universe, thank you for the blessings you have sent my way. : )",
  "id" : 396674023913828352,
  "created_at" : "2013-11-02 16:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7ndrQOM7W7",
      "expanded_url" : "http:\/\/youtu.be\/1CLCOvZOh1o",
      "display_url" : "youtu.be\/1CLCOvZOh1o"
    } ]
  },
  "geo" : { },
  "id_str" : "396661090437705729",
  "text" : "books are always better! lol &gt;&gt; The Axis of Awesome - Rage of Thrones: http:\/\/t.co\/7ndrQOM7W7",
  "id" : 396661090437705729,
  "created_at" : "2013-11-02 15:32:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/IREt3lfoBM",
      "expanded_url" : "http:\/\/AlchemyLoveJoy.com\/scary-thoughts\/",
      "display_url" : "AlchemyLoveJoy.com\/scary-thoughts\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396660166067617792",
  "text" : "Scary Thoughts http:\/\/t.co\/IREt3lfoBM \"it\u2019s not what happens that hurts, but the thought you believe about what happens that hurts.\"",
  "id" : 396660166067617792,
  "created_at" : "2013-11-02 15:28:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396656444436541440",
  "text" : "amuse me, twitter. hubby has left me.. for the day.",
  "id" : 396656444436541440,
  "created_at" : "2013-11-02 15:14:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396655937978925056",
  "text" : "RT @micahjmurray: The inability to transfer, change, or combine Google accounts is one of the greatest annoyances of the 21st century.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396644843281072129",
    "text" : "The inability to transfer, change, or combine Google accounts is one of the greatest annoyances of the 21st century.",
    "id" : 396644843281072129,
    "created_at" : "2013-11-02 14:27:54 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 396655937978925056,
  "created_at" : "2013-11-02 15:11:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396394924385394688",
  "geo" : { },
  "id_str" : "396419383263641600",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter nice!",
  "id" : 396419383263641600,
  "in_reply_to_status_id" : 396394924385394688,
  "created_at" : "2013-11-01 23:32:00 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "indices" : [ 3, 14 ],
      "id_str" : "1132090693",
      "id" : 1132090693
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/396397014784954368\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/xryUfsko1m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYBI_AyIUAAKtRs.jpg",
      "id_str" : "396397014587822080",
      "id" : 396397014587822080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYBI_AyIUAAKtRs.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/xryUfsko1m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396418741510369280",
  "text" : "RT @Globe_Pics: 2 young Norwegian men risk their lives to save a lamb which is about to drown!! http:\/\/t.co\/xryUfsko1m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/396397014784954368\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/xryUfsko1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYBI_AyIUAAKtRs.jpg",
        "id_str" : "396397014587822080",
        "id" : 396397014587822080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYBI_AyIUAAKtRs.jpg",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/xryUfsko1m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396397014784954368",
    "text" : "2 young Norwegian men risk their lives to save a lamb which is about to drown!! http:\/\/t.co\/xryUfsko1m",
    "id" : 396397014784954368,
    "created_at" : "2013-11-01 22:03:07 +0000",
    "user" : {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "protected" : false,
      "id_str" : "1132090693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538457900281126912\/tMIRoIp7_normal.jpeg",
      "id" : 1132090693,
      "verified" : false
    }
  },
  "id" : 396418741510369280,
  "created_at" : "2013-11-01 23:29:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 0, 13 ],
      "id_str" : "88882302",
      "id" : 88882302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396397773412921344",
  "geo" : { },
  "id_str" : "396418366191058945",
  "in_reply_to_user_id" : 88882302,
  "text" : "@TweetTheBook Yes",
  "id" : 396418366191058945,
  "in_reply_to_status_id" : 396397773412921344,
  "created_at" : "2013-11-01 23:27:58 +0000",
  "in_reply_to_screen_name" : "TweetTheBook",
  "in_reply_to_user_id_str" : "88882302",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 73, 79 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Yi8VHBoA7P",
      "expanded_url" : "http:\/\/on.msnbc.com\/16P1Yo7",
      "display_url" : "on.msnbc.com\/16P1Yo7"
    } ]
  },
  "geo" : { },
  "id_str" : "396358064557010944",
  "text" : "RT @atheistlady76: 'I'm showing my son mercy' http:\/\/t.co\/Yi8VHBoA7P via @msnbc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 54, 60 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/Yi8VHBoA7P",
        "expanded_url" : "http:\/\/on.msnbc.com\/16P1Yo7",
        "display_url" : "on.msnbc.com\/16P1Yo7"
      } ]
    },
    "geo" : { },
    "id_str" : "396347586258276352",
    "text" : "'I'm showing my son mercy' http:\/\/t.co\/Yi8VHBoA7P via @msnbc",
    "id" : 396347586258276352,
    "created_at" : "2013-11-01 18:46:43 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 396358064557010944,
  "created_at" : "2013-11-01 19:28:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396355583919394818",
  "text" : "just finished The Room by Fireproof Games on my #KindleFire .. excellent puzzle game!!! Looking forward to The Room 2.",
  "id" : 396355583919394818,
  "created_at" : "2013-11-01 19:18:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396344863811047424",
  "text" : "me: i dont wanna watch this DD: ((turns off tv)) there, problem solved.",
  "id" : 396344863811047424,
  "created_at" : "2013-11-01 18:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396329278662803456",
  "text" : "RT @stream_enterer: Twitter is like the reality I never had.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396328290568245248",
    "text" : "Twitter is like the reality I never had.",
    "id" : 396328290568245248,
    "created_at" : "2013-11-01 17:30:02 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 396329278662803456,
  "created_at" : "2013-11-01 17:33:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396328244091174912",
  "text" : "@weakSquare haha.. yeah.. i keep them separate :D",
  "id" : 396328244091174912,
  "created_at" : "2013-11-01 17:29:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396280312566923264",
  "text" : "RT @micahjmurray: A lot of bros like to say \u201CRespect yourself, girls; don\u2019t dress sexy\u201D Maybe we should just respect women enough to let th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396276762427928576",
    "text" : "A lot of bros like to say \u201CRespect yourself, girls; don\u2019t dress sexy\u201D Maybe we should just respect women enough to let them dress themselves",
    "id" : 396276762427928576,
    "created_at" : "2013-11-01 14:05:17 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 396280312566923264,
  "created_at" : "2013-11-01 14:19:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396278806211997696",
  "text" : "RT @DoreenVirtue444: I ask my angels to help me express myself with love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396260440956612608",
    "text" : "I ask my angels to help me express myself with love.",
    "id" : 396260440956612608,
    "created_at" : "2013-11-01 13:00:25 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 396278806211997696,
  "created_at" : "2013-11-01 14:13:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396268590065651712",
  "geo" : { },
  "id_str" : "396275990508208128",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell hmm.. never thought of it that way..",
  "id" : 396275990508208128,
  "in_reply_to_status_id" : 396268590065651712,
  "created_at" : "2013-11-01 14:02:13 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396273602779037696",
  "geo" : { },
  "id_str" : "396274568047767552",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg lovely. i think i could like living in it.. : )",
  "id" : 396274568047767552,
  "in_reply_to_status_id" : 396273602779037696,
  "created_at" : "2013-11-01 13:56:34 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]