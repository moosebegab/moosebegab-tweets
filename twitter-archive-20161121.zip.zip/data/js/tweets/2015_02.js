Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Hhn32pKLTx",
      "expanded_url" : "http:\/\/micahjmurray.com\/after-three-beers\/",
      "display_url" : "micahjmurray.com\/after-three-be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571868771977203712",
  "text" : "RT @micahjmurray: what would you do if you weren't afraid? http:\/\/t.co\/Hhn32pKLTx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/Hhn32pKLTx",
        "expanded_url" : "http:\/\/micahjmurray.com\/after-three-beers\/",
        "display_url" : "micahjmurray.com\/after-three-be\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571863708000911360",
    "text" : "what would you do if you weren't afraid? http:\/\/t.co\/Hhn32pKLTx",
    "id" : 571863708000911360,
    "created_at" : "2015-03-01 02:45:07 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 571868771977203712,
  "created_at" : "2015-03-01 03:05:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "The Dodo",
      "screen_name" : "dodo",
      "indices" : [ 20, 25 ],
      "id_str" : "1604444052",
      "id" : 1604444052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/89F85emsbL",
      "expanded_url" : "http:\/\/thedo.do\/1akla5A",
      "display_url" : "thedo.do\/1akla5A"
    } ]
  },
  "geo" : { },
  "id_str" : "571860619621765120",
  "text" : "RT @oceanshaman: Rt @dodo: 60-year-old blind elephant forced to beg on the streets gets the love she needs http:\/\/t.co\/89F85emsbL http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Dodo",
        "screen_name" : "dodo",
        "indices" : [ 3, 8 ],
        "id_str" : "1604444052",
        "id" : 1604444052
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dodo\/status\/571853153877934080\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Z2F7FEBB3t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3g9MZUIAAFpRM.jpg",
        "id_str" : "571360069649965056",
        "id" : 571360069649965056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3g9MZUIAAFpRM.jpg",
        "sizes" : [ {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/Z2F7FEBB3t"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/89F85emsbL",
        "expanded_url" : "http:\/\/thedo.do\/1akla5A",
        "display_url" : "thedo.do\/1akla5A"
      } ]
    },
    "geo" : { },
    "id_str" : "571856204848185344",
    "text" : "Rt @dodo: 60-year-old blind elephant forced to beg on the streets gets the love she needs http:\/\/t.co\/89F85emsbL http:\/\/t.co\/Z2F7FEBB3t",
    "id" : 571856204848185344,
    "created_at" : "2015-03-01 02:15:18 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 571860619621765120,
  "created_at" : "2015-03-01 02:32:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571859050171932672",
  "text" : "RT @davidpakmanshow: If you've ever had trouble affording medications, submit your story to help make medications more affordable: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/wZcRYErvdZ",
        "expanded_url" : "http:\/\/ow.ly\/JEnNx",
        "display_url" : "ow.ly\/JEnNx"
      } ]
    },
    "geo" : { },
    "id_str" : "571856210338705408",
    "text" : "If you've ever had trouble affording medications, submit your story to help make medications more affordable: http:\/\/t.co\/wZcRYErvdZ",
    "id" : 571856210338705408,
    "created_at" : "2015-03-01 02:15:19 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 571859050171932672,
  "created_at" : "2015-03-01 02:26:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 0, 13 ],
      "id_str" : "256540769",
      "id" : 256540769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571856156840226816",
  "geo" : { },
  "id_str" : "571857817998643201",
  "in_reply_to_user_id" : 256540769,
  "text" : "@HarryShannon that word popped in my head, too.",
  "id" : 571857817998643201,
  "in_reply_to_status_id" : 571856156840226816,
  "created_at" : "2015-03-01 02:21:43 +0000",
  "in_reply_to_screen_name" : "HarryShannon",
  "in_reply_to_user_id_str" : "256540769",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 0, 13 ],
      "id_str" : "256540769",
      "id" : 256540769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571846297566638080",
  "geo" : { },
  "id_str" : "571851832642961408",
  "in_reply_to_user_id" : 256540769,
  "text" : "@HarryShannon I think she's the mentally ill one. Very sad.",
  "id" : 571851832642961408,
  "in_reply_to_status_id" : 571846297566638080,
  "created_at" : "2015-03-01 01:57:56 +0000",
  "in_reply_to_screen_name" : "HarryShannon",
  "in_reply_to_user_id_str" : "256540769",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 3, 16 ],
      "id_str" : "256540769",
      "id" : 256540769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FYqliH8KPI",
      "expanded_url" : "http:\/\/thebea.st\/1DlBUQW",
      "display_url" : "thebea.st\/1DlBUQW"
    } ]
  },
  "geo" : { },
  "id_str" : "571851626060890112",
  "text" : "RT @HarryShannon: Heartless? Teen girl has been charged with involuntary manslaughter for encouraging a suicide. http:\/\/t.co\/FYqliH8KPI htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thedailybeast\/status\/571845017733603328\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/M0JsGIOjIq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B--aA4nW4AAyZeb.jpg",
        "id_str" : "571845017687482368",
        "id" : 571845017687482368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B--aA4nW4AAyZeb.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/M0JsGIOjIq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/FYqliH8KPI",
        "expanded_url" : "http:\/\/thebea.st\/1DlBUQW",
        "display_url" : "thebea.st\/1DlBUQW"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.19660459953967, -118.4249664000935 ]
    },
    "id_str" : "571846297566638080",
    "text" : "Heartless? Teen girl has been charged with involuntary manslaughter for encouraging a suicide. http:\/\/t.co\/FYqliH8KPI http:\/\/t.co\/M0JsGIOjIq",
    "id" : 571846297566638080,
    "created_at" : "2015-03-01 01:35:56 +0000",
    "user" : {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "protected" : false,
      "id_str" : "256540769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798645625289965568\/8ai82ECm_normal.jpg",
      "id" : 256540769,
      "verified" : false
    }
  },
  "id" : 571851626060890112,
  "created_at" : "2015-03-01 01:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/520865689381257217\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4eSla86M3L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzp8la4CYAEG2By.jpg",
      "id_str" : "520865689226076161",
      "id" : 520865689226076161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzp8la4CYAEG2By.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/4eSla86M3L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571850015502680064",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/4eSla86M3L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/520865689381257217\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/4eSla86M3L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzp8la4CYAEG2By.jpg",
        "id_str" : "520865689226076161",
        "id" : 520865689226076161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzp8la4CYAEG2By.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/4eSla86M3L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571847343978516481",
    "text" : "http:\/\/t.co\/4eSla86M3L",
    "id" : 571847343978516481,
    "created_at" : "2015-03-01 01:40:05 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 571850015502680064,
  "created_at" : "2015-03-01 01:50:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571849301766348801",
  "text" : "@Lluminous_ or is it? Hmm..",
  "id" : 571849301766348801,
  "created_at" : "2015-03-01 01:47:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "indices" : [ 3, 13 ],
      "id_str" : "21124068",
      "id" : 21124068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ryQV7xckkp",
      "expanded_url" : "http:\/\/www.historiceveretttheatre.org\/tickets\/steam-powered-giraffe",
      "display_url" : "historiceveretttheatre.org\/tickets\/steam-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571709046694256640",
  "text" : "RT @SPGiraffe: It's time for round two, Everett! Tickets still available for tonight's show! http:\/\/t.co\/ryQV7xckkp See you there! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/571706964767481856\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/FTqC3wWsbN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8cdHLUsAAoYMZ.jpg",
        "id_str" : "571706964167667712",
        "id" : 571706964167667712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8cdHLUsAAoYMZ.jpg",
        "sizes" : [ {
          "h" : 920,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 997,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 997,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/FTqC3wWsbN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/ryQV7xckkp",
        "expanded_url" : "http:\/\/www.historiceveretttheatre.org\/tickets\/steam-powered-giraffe",
        "display_url" : "historiceveretttheatre.org\/tickets\/steam-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571706964767481856",
    "text" : "It's time for round two, Everett! Tickets still available for tonight's show! http:\/\/t.co\/ryQV7xckkp See you there! http:\/\/t.co\/FTqC3wWsbN",
    "id" : 571706964767481856,
    "created_at" : "2015-02-28 16:22:16 +0000",
    "user" : {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "protected" : false,
      "id_str" : "21124068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827378909601793\/4oJPYDlb_normal.jpg",
      "id" : 21124068,
      "verified" : false
    }
  },
  "id" : 571709046694256640,
  "created_at" : "2015-02-28 16:30:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "indices" : [ 3, 14 ],
      "id_str" : "2700353103",
      "id" : 2700353103
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/570343202005233665\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/6iOpBNiug3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-pEG-DW4AAtLlw.jpg",
      "id_str" : "570343189342773248",
      "id" : 570343189342773248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-pEG-DW4AAtLlw.jpg",
      "sizes" : [ {
        "h" : 514,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6iOpBNiug3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571708467746115584",
  "text" : "RT @jabinks846: Cute little turnstone at fairhaven lake . First one I've ever seen \u263A\uFE0F http:\/\/t.co\/6iOpBNiug3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/570343202005233665\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/6iOpBNiug3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-pEG-DW4AAtLlw.jpg",
        "id_str" : "570343189342773248",
        "id" : 570343189342773248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-pEG-DW4AAtLlw.jpg",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 878,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 878,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6iOpBNiug3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570343202005233665",
    "text" : "Cute little turnstone at fairhaven lake . First one I've ever seen \u263A\uFE0F http:\/\/t.co\/6iOpBNiug3",
    "id" : 570343202005233665,
    "created_at" : "2015-02-24 22:03:10 +0000",
    "user" : {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "protected" : false,
      "id_str" : "2700353103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735826657391595521\/n3KBNey9_normal.jpg",
      "id" : 2700353103,
      "verified" : false
    }
  },
  "id" : 571708467746115584,
  "created_at" : "2015-02-28 16:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrinceRupert",
      "indices" : [ 59, 72 ]
    }, {
      "text" : "Sunset",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "Moon",
      "indices" : [ 115, 120 ]
    }, {
      "text" : "photoswithmyphone",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571705789909508096",
  "text" : "RT @ScarlettWulf: Out &amp; about just caught this Amazing #PrinceRupert #Sunset with my Phone. Off to capture the #Moon #photoswithmyphone htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/571504237349232640\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/Fzff14kWlD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-5kEeTVIAAvYbG.jpg",
        "id_str" : "571504230739025920",
        "id" : 571504230739025920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-5kEeTVIAAvYbG.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Fzff14kWlD"
      } ],
      "hashtags" : [ {
        "text" : "PrinceRupert",
        "indices" : [ 41, 54 ]
      }, {
        "text" : "Sunset",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "Moon",
        "indices" : [ 97, 102 ]
      }, {
        "text" : "photoswithmyphone",
        "indices" : [ 103, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.3125011, -130.321743 ]
    },
    "id_str" : "571504237349232640",
    "text" : "Out &amp; about just caught this Amazing #PrinceRupert #Sunset with my Phone. Off to capture the #Moon #photoswithmyphone http:\/\/t.co\/Fzff14kWlD",
    "id" : 571504237349232640,
    "created_at" : "2015-02-28 02:56:42 +0000",
    "user" : {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "protected" : false,
      "id_str" : "1348108910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741919775668867072\/yzqHRx03_normal.jpg",
      "id" : 1348108910,
      "verified" : false
    }
  },
  "id" : 571705789909508096,
  "created_at" : "2015-02-28 16:17:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/504838898162597888\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/fgfKTAyXlI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwGMTY6IgAAFXsI.jpg",
      "id_str" : "504838897973886976",
      "id" : 504838897973886976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwGMTY6IgAAFXsI.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fgfKTAyXlI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571705648620171264",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/fgfKTAyXlI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/504838898162597888\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/fgfKTAyXlI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwGMTY6IgAAFXsI.jpg",
        "id_str" : "504838897973886976",
        "id" : 504838897973886976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwGMTY6IgAAFXsI.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fgfKTAyXlI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571691297574141952",
    "text" : "http:\/\/t.co\/fgfKTAyXlI",
    "id" : 571691297574141952,
    "created_at" : "2015-02-28 15:20:01 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 571705648620171264,
  "created_at" : "2015-02-28 16:17:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571705284252598273",
  "text" : "RT @JohnCali: You\u2019re never in the wrong place. Sometimes you\u2019re in the right place looking at things in the wrong way. ~ Abraham-Hicks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571692340152156160",
    "text" : "You\u2019re never in the wrong place. Sometimes you\u2019re in the right place looking at things in the wrong way. ~ Abraham-Hicks",
    "id" : 571692340152156160,
    "created_at" : "2015-02-28 15:24:10 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 571705284252598273,
  "created_at" : "2015-02-28 16:15:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571692447769604096",
  "geo" : { },
  "id_str" : "571705211158454272",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg not mine, either (or mine, neither?)",
  "id" : 571705211158454272,
  "in_reply_to_status_id" : 571692447769604096,
  "created_at" : "2015-02-28 16:15:18 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "indices" : [ 3, 12 ],
      "id_str" : "2375492109",
      "id" : 2375492109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/571693889075187714\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/bEL69DlGX6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8QkBqXEAADMVp.jpg",
      "id_str" : "571693888806785024",
      "id" : 571693888806785024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8QkBqXEAADMVp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/bEL69DlGX6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571698911909425152",
  "text" : "RT @cw_mills: Was going to be a scenic photo, but someone had other ideas http:\/\/t.co\/bEL69DlGX6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/571693889075187714\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/bEL69DlGX6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8QkBqXEAADMVp.jpg",
        "id_str" : "571693888806785024",
        "id" : 571693888806785024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8QkBqXEAADMVp.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/bEL69DlGX6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571693889075187714",
    "text" : "Was going to be a scenic photo, but someone had other ideas http:\/\/t.co\/bEL69DlGX6",
    "id" : 571693889075187714,
    "created_at" : "2015-02-28 15:30:19 +0000",
    "user" : {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "protected" : false,
      "id_str" : "2375492109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648076476613533696\/1aq5VLpS_normal.jpg",
      "id" : 2375492109,
      "verified" : false
    }
  },
  "id" : 571698911909425152,
  "created_at" : "2015-02-28 15:50:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Chantall",
      "screen_name" : "danchantall9",
      "indices" : [ 3, 16 ],
      "id_str" : "2763786177",
      "id" : 2763786177
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/danchantall9\/status\/571042482571644928\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ztTaUkq6rl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zAHL_WoAAbXZ6.jpg",
      "id_str" : "571042482479341568",
      "id" : 571042482479341568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zAHL_WoAAbXZ6.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/ztTaUkq6rl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571689997105037312",
  "text" : "RT @danchantall9: http:\/\/t.co\/ztTaUkq6rl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/danchantall9\/status\/571042482571644928\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/ztTaUkq6rl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zAHL_WoAAbXZ6.jpg",
        "id_str" : "571042482479341568",
        "id" : 571042482479341568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zAHL_WoAAbXZ6.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/ztTaUkq6rl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571042482571644928",
    "text" : "http:\/\/t.co\/ztTaUkq6rl",
    "id" : 571042482571644928,
    "created_at" : "2015-02-26 20:21:51 +0000",
    "user" : {
      "name" : "Danielle Chantall",
      "screen_name" : "danchantall9",
      "protected" : false,
      "id_str" : "2763786177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793514674193063936\/pC9T5OAA_normal.jpg",
      "id" : 2763786177,
      "verified" : false
    }
  },
  "id" : 571689997105037312,
  "created_at" : "2015-02-28 15:14:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gautam Trivedi",
      "screen_name" : "Gotham3",
      "indices" : [ 3, 11 ],
      "id_str" : "126903716",
      "id" : 126903716
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gotham3\/status\/571684042975780864\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/8Eqqxis4DO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8Hmz4UsAAe2_p.jpg",
      "id_str" : "571684041042210816",
      "id" : 571684041042210816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8Hmz4UsAAe2_p.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/8Eqqxis4DO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571689908705865728",
  "text" : "RT @Gotham3: 300-year-old Chinese abacus ring was used during the Qing Dynasty to help traders. http:\/\/t.co\/8Eqqxis4DO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gotham3\/status\/571684042975780864\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/8Eqqxis4DO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8Hmz4UsAAe2_p.jpg",
        "id_str" : "571684041042210816",
        "id" : 571684041042210816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8Hmz4UsAAe2_p.jpg",
        "sizes" : [ {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/8Eqqxis4DO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571684042975780864",
    "text" : "300-year-old Chinese abacus ring was used during the Qing Dynasty to help traders. http:\/\/t.co\/8Eqqxis4DO",
    "id" : 571684042975780864,
    "created_at" : "2015-02-28 14:51:11 +0000",
    "user" : {
      "name" : "Gautam Trivedi",
      "screen_name" : "Gotham3",
      "protected" : false,
      "id_str" : "126903716",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800890810950524928\/hr9wo4dv_normal.jpg",
      "id" : 126903716,
      "verified" : false
    }
  },
  "id" : 571689908705865728,
  "created_at" : "2015-02-28 15:14:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571476629295403008",
  "text" : "RT @TheChristianLft: Evangelical Christianity has become a cult. Does that sound like a game changing statement? It is, and it should... ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/WR2jKQB9qB",
        "expanded_url" : "http:\/\/fb.me\/3DsBxF1jK",
        "display_url" : "fb.me\/3DsBxF1jK"
      } ]
    },
    "geo" : { },
    "id_str" : "570399272862142464",
    "text" : "Evangelical Christianity has become a cult. Does that sound like a game changing statement? It is, and it should... http:\/\/t.co\/WR2jKQB9qB",
    "id" : 570399272862142464,
    "created_at" : "2015-02-25 01:45:58 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 571476629295403008,
  "created_at" : "2015-02-28 01:07:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/RYTAbIEBsJ",
      "expanded_url" : "http:\/\/qvotr.com\/quote\/2478",
      "display_url" : "qvotr.com\/quote\/2478"
    } ]
  },
  "geo" : { },
  "id_str" : "571468470556209152",
  "text" : "\"As for WHY some students choose not to say the pledge, I can only speak for myse...\" http:\/\/t.co\/RYTAbIEBsJ",
  "id" : 571468470556209152,
  "created_at" : "2015-02-28 00:34:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "indices" : [ 3, 15 ],
      "id_str" : "23034673",
      "id" : 23034673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571459593232097280",
  "text" : "RT @hemantmehta: Controversy Erupts at Maine High School After Students Are Told They Don\u2019t Have to Stand for the Pledge http:\/\/t.co\/cN1ziU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/cN1ziUZGmy",
        "expanded_url" : "http:\/\/tinyurl.com\/qzthg66",
        "display_url" : "tinyurl.com\/qzthg66"
      } ]
    },
    "geo" : { },
    "id_str" : "571314298066055168",
    "text" : "Controversy Erupts at Maine High School After Students Are Told They Don\u2019t Have to Stand for the Pledge http:\/\/t.co\/cN1ziUZGmy",
    "id" : 571314298066055168,
    "created_at" : "2015-02-27 14:21:57 +0000",
    "user" : {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "protected" : false,
      "id_str" : "23034673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3393754882\/07184fa9526af00257538d818b6f72f7_normal.jpeg",
      "id" : 23034673,
      "verified" : true
    }
  },
  "id" : 571459593232097280,
  "created_at" : "2015-02-27 23:59:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Enterprise",
      "screen_name" : "vida_ying_yang",
      "indices" : [ 3, 18 ],
      "id_str" : "2763786195",
      "id" : 2763786195
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vida_ying_yang\/status\/571445151522021376\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/34yB7UDmPn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4uVmfWkAAYVy0.jpg",
      "id_str" : "571445151366811648",
      "id" : 571445151366811648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4uVmfWkAAYVy0.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/34yB7UDmPn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571452556809015296",
  "text" : "RT @vida_ying_yang: \uD83C\uDF3B\u2764\uFE0F\uD83D\uDE0A http:\/\/t.co\/34yB7UDmPn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vida_ying_yang\/status\/571445151522021376\/photo\/1",
        "indices" : [ 5, 27 ],
        "url" : "http:\/\/t.co\/34yB7UDmPn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4uVmfWkAAYVy0.jpg",
        "id_str" : "571445151366811648",
        "id" : 571445151366811648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4uVmfWkAAYVy0.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/34yB7UDmPn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571445151522021376",
    "text" : "\uD83C\uDF3B\u2764\uFE0F\uD83D\uDE0A http:\/\/t.co\/34yB7UDmPn",
    "id" : 571445151522021376,
    "created_at" : "2015-02-27 23:01:55 +0000",
    "user" : {
      "name" : "Ela Enterprise",
      "screen_name" : "vida_ying_yang",
      "protected" : false,
      "id_str" : "2763786195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508542917431291905\/r5yrbBYi_normal.jpeg",
      "id" : 2763786195,
      "verified" : false
    }
  },
  "id" : 571452556809015296,
  "created_at" : "2015-02-27 23:31:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "indices" : [ 3, 14 ],
      "id_str" : "20016044",
      "id" : 20016044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/TcLSswmyOL",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/02\/27\/man-gets-life-in-prison-for-se.html",
      "display_url" : "boingboing.net\/2015\/02\/27\/man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571442049616109568",
  "text" : "RT @annihilist: Man gets life in prison for selling $20 worth of weed to undercover\u00A0cop http:\/\/t.co\/TcLSswmyOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/TcLSswmyOL",
        "expanded_url" : "http:\/\/boingboing.net\/2015\/02\/27\/man-gets-life-in-prison-for-se.html",
        "display_url" : "boingboing.net\/2015\/02\/27\/man\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571438085529075712",
    "text" : "Man gets life in prison for selling $20 worth of weed to undercover\u00A0cop http:\/\/t.co\/TcLSswmyOL",
    "id" : 571438085529075712,
    "created_at" : "2015-02-27 22:33:51 +0000",
    "user" : {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "protected" : false,
      "id_str" : "20016044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2698857060\/e2abd719f5fec793b3818cdff078c44b_normal.jpeg",
      "id" : 20016044,
      "verified" : false
    }
  },
  "id" : 571442049616109568,
  "created_at" : "2015-02-27 22:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571430019593076736",
  "geo" : { },
  "id_str" : "571441436383707138",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley : ((",
  "id" : 571441436383707138,
  "in_reply_to_status_id" : 571430019593076736,
  "created_at" : "2015-02-27 22:47:09 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Maddison",
      "screen_name" : "GlenOrioleglen",
      "indices" : [ 3, 18 ],
      "id_str" : "636188998",
      "id" : 636188998
    }, {
      "name" : "Jan Freedman",
      "screen_name" : "JanFreedman",
      "indices" : [ 20, 32 ],
      "id_str" : "351566257",
      "id" : 351566257
    }, {
      "name" : "Amy Schwartz",
      "screen_name" : "lizardschwartz",
      "indices" : [ 33, 48 ],
      "id_str" : "283185031",
      "id" : 283185031
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GlenOrioleglen\/status\/567704191196733440\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Mva3euMeck",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Dj8DJIIAAgwOI.jpg",
      "id_str" : "567704173823926272",
      "id" : 567704173823926272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Dj8DJIIAAgwOI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 758
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 758
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 811,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Mva3euMeck"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571383572713631745",
  "text" : "RT @GlenOrioleglen: @JanFreedman @lizardschwartz thought I'd re-tweet my capture from last summer...:-) http:\/\/t.co\/Mva3euMeck",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jan Freedman",
        "screen_name" : "JanFreedman",
        "indices" : [ 0, 12 ],
        "id_str" : "351566257",
        "id" : 351566257
      }, {
        "name" : "Amy Schwartz",
        "screen_name" : "lizardschwartz",
        "indices" : [ 13, 28 ],
        "id_str" : "283185031",
        "id" : 283185031
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GlenOrioleglen\/status\/567704191196733440\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/Mva3euMeck",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Dj8DJIIAAgwOI.jpg",
        "id_str" : "567704173823926272",
        "id" : 567704173823926272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Dj8DJIIAAgwOI.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 758
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 758
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 811,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Mva3euMeck"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "567683483460714496",
    "geo" : { },
    "id_str" : "567704191196733440",
    "in_reply_to_user_id" : 351566257,
    "text" : "@JanFreedman @lizardschwartz thought I'd re-tweet my capture from last summer...:-) http:\/\/t.co\/Mva3euMeck",
    "id" : 567704191196733440,
    "in_reply_to_status_id" : 567683483460714496,
    "created_at" : "2015-02-17 15:16:41 +0000",
    "in_reply_to_screen_name" : "JanFreedman",
    "in_reply_to_user_id_str" : "351566257",
    "user" : {
      "name" : "Glen Maddison",
      "screen_name" : "GlenOrioleglen",
      "protected" : false,
      "id_str" : "636188998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747177513256947714\/gW6HS5tC_normal.jpg",
      "id" : 636188998,
      "verified" : false
    }
  },
  "id" : 571383572713631745,
  "created_at" : "2015-02-27 18:57:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B&N Sci-Fi & Fantasy",
      "screen_name" : "BNSciFi",
      "indices" : [ 3, 11 ],
      "id_str" : "2912819783",
      "id" : 2912819783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571383392408883201",
  "text" : "RT @BNSciFi: Need a little real tech in your technobabble? 5 SF novels that resist \"The Handwave\" &amp; take science seriously: http:\/\/t.co\/xJ2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xJ2ZBrlclo",
        "expanded_url" : "http:\/\/bit.ly\/1AhNydd",
        "display_url" : "bit.ly\/1AhNydd"
      } ]
    },
    "geo" : { },
    "id_str" : "571381157603844096",
    "text" : "Need a little real tech in your technobabble? 5 SF novels that resist \"The Handwave\" &amp; take science seriously: http:\/\/t.co\/xJ2ZBrlclo",
    "id" : 571381157603844096,
    "created_at" : "2015-02-27 18:47:38 +0000",
    "user" : {
      "name" : "B&N Sci-Fi & Fantasy",
      "screen_name" : "BNSciFi",
      "protected" : false,
      "id_str" : "2912819783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555433300248899585\/kvUKhBRT_normal.jpeg",
      "id" : 2912819783,
      "verified" : true
    }
  },
  "id" : 571383392408883201,
  "created_at" : "2015-02-27 18:56:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Wallace",
      "screen_name" : "MattFnWallace",
      "indices" : [ 3, 17 ],
      "id_str" : "15409985",
      "id" : 15409985
    }, {
      "name" : "Redrum Lafferty",
      "screen_name" : "mightymur",
      "indices" : [ 114, 124 ],
      "id_str" : "3025261",
      "id" : 3025261
    }, {
      "name" : "Asymptotic Binary",
      "screen_name" : "asymbina",
      "indices" : [ 125, 134 ],
      "id_str" : "93638430",
      "id" : 93638430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/583owibrLF",
      "expanded_url" : "http:\/\/www.matt-wallace.com\/gender-as-asymptotically-binary-a-different-way-of-looking-at-things\/",
      "display_url" : "matt-wallace.com\/gender-as-asym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571382562540658688",
  "text" : "RT @MattFnWallace: Gender as Asymptotically Binary: A Different Way of Looking at Things http:\/\/t.co\/583owibrLF \u2026 @mightymur @asymbina",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Redrum Lafferty",
        "screen_name" : "mightymur",
        "indices" : [ 95, 105 ],
        "id_str" : "3025261",
        "id" : 3025261
      }, {
        "name" : "Asymptotic Binary",
        "screen_name" : "asymbina",
        "indices" : [ 106, 115 ],
        "id_str" : "93638430",
        "id" : 93638430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/583owibrLF",
        "expanded_url" : "http:\/\/www.matt-wallace.com\/gender-as-asymptotically-binary-a-different-way-of-looking-at-things\/",
        "display_url" : "matt-wallace.com\/gender-as-asym\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571352907259359232",
    "text" : "Gender as Asymptotically Binary: A Different Way of Looking at Things http:\/\/t.co\/583owibrLF \u2026 @mightymur @asymbina",
    "id" : 571352907259359232,
    "created_at" : "2015-02-27 16:55:22 +0000",
    "user" : {
      "name" : "Matt Wallace",
      "screen_name" : "MattFnWallace",
      "protected" : false,
      "id_str" : "15409985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769779157437775874\/0yx0tutm_normal.jpg",
      "id" : 15409985,
      "verified" : false
    }
  },
  "id" : 571382562540658688,
  "created_at" : "2015-02-27 18:53:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chrisitsstillme\/status\/571360351985541121\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/THkaGXaNUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3hNn6XIAEFrpm.jpg",
      "id_str" : "571360351914237953",
      "id" : 571360351914237953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3hNn6XIAEFrpm.jpg",
      "sizes" : [ {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1035
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/THkaGXaNUK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571368629327007744",
  "text" : "RT @chrisitsstillme: Lovely setting sun over Brownsea Island tonight. Cold though! Brrrr http:\/\/t.co\/THkaGXaNUK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chrisitsstillme\/status\/571360351985541121\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/THkaGXaNUK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3hNn6XIAEFrpm.jpg",
        "id_str" : "571360351914237953",
        "id" : 571360351914237953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3hNn6XIAEFrpm.jpg",
        "sizes" : [ {
          "h" : 164,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1035
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/THkaGXaNUK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571360351985541121",
    "text" : "Lovely setting sun over Brownsea Island tonight. Cold though! Brrrr http:\/\/t.co\/THkaGXaNUK",
    "id" : 571360351985541121,
    "created_at" : "2015-02-27 17:24:57 +0000",
    "user" : {
      "name" : "Chris Charles",
      "screen_name" : "chris4nature",
      "protected" : false,
      "id_str" : "704814349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665744044308434944\/Vu-YwfAu_normal.jpg",
      "id" : 704814349,
      "verified" : false
    }
  },
  "id" : 571368629327007744,
  "created_at" : "2015-02-27 17:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Witt",
      "screen_name" : "chriswitt1966",
      "indices" : [ 3, 17 ],
      "id_str" : "1430955528",
      "id" : 1430955528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chriswitt1966\/status\/571204207879069696\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/FGO2aAQzMA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-1TMwyWkAALUXr.jpg",
      "id_str" : "571204206465552384",
      "id" : 571204206465552384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-1TMwyWkAALUXr.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/FGO2aAQzMA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571368446182735874",
  "text" : "RT @chriswitt1966: My first sunrise, I have seen from my flat since autumn. http:\/\/t.co\/FGO2aAQzMA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chriswitt1966\/status\/571204207879069696\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/FGO2aAQzMA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-1TMwyWkAALUXr.jpg",
        "id_str" : "571204206465552384",
        "id" : 571204206465552384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-1TMwyWkAALUXr.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/FGO2aAQzMA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571204207879069696",
    "text" : "My first sunrise, I have seen from my flat since autumn. http:\/\/t.co\/FGO2aAQzMA",
    "id" : 571204207879069696,
    "created_at" : "2015-02-27 07:04:30 +0000",
    "user" : {
      "name" : "Christopher Witt",
      "screen_name" : "chriswitt1966",
      "protected" : false,
      "id_str" : "1430955528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3733114920\/3357d2379aff0c8ce10cad4c4198c709_normal.jpeg",
      "id" : 1430955528,
      "verified" : false
    }
  },
  "id" : 571368446182735874,
  "created_at" : "2015-02-27 17:57:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/570001540607389696\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FPBGQaI4q8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kNX47CQAAnpLS.jpg",
      "id_str" : "570001531907227648",
      "id" : 570001531907227648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kNX47CQAAnpLS.jpg",
      "sizes" : [ {
        "h" : 753,
        "resize" : "fit",
        "w" : 753
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 753
      } ],
      "display_url" : "pic.twitter.com\/FPBGQaI4q8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/570001540607389696\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FPBGQaI4q8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kNYXUCAAAE-f0.jpg",
      "id_str" : "570001540065132544",
      "id" : 570001540065132544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kNYXUCAAAE-f0.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/FPBGQaI4q8"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 88, 94 ]
    }, {
      "text" : "nature",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571331698912321536",
  "text" : "RT @AWrobley: Western Bluebird, male; not real clear...but I don't see bluebirds often. #birds #nature #wildlife http:\/\/t.co\/FPBGQaI4q8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/570001540607389696\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/FPBGQaI4q8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kNX47CQAAnpLS.jpg",
        "id_str" : "570001531907227648",
        "id" : 570001531907227648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kNX47CQAAnpLS.jpg",
        "sizes" : [ {
          "h" : 753,
          "resize" : "fit",
          "w" : 753
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 753
        } ],
        "display_url" : "pic.twitter.com\/FPBGQaI4q8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/570001540607389696\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/FPBGQaI4q8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kNYXUCAAAE-f0.jpg",
        "id_str" : "570001540065132544",
        "id" : 570001540065132544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kNYXUCAAAE-f0.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/FPBGQaI4q8"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 74, 80 ]
      }, {
        "text" : "nature",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570001540607389696",
    "text" : "Western Bluebird, male; not real clear...but I don't see bluebirds often. #birds #nature #wildlife http:\/\/t.co\/FPBGQaI4q8",
    "id" : 570001540607389696,
    "created_at" : "2015-02-23 23:25:32 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 571331698912321536,
  "created_at" : "2015-02-27 15:31:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571323669739376640",
  "text" : "RT @JacksonPearce: I am in this library's super cool Relaxation Station. There are treats. There is tea. There are...hands. http:\/\/t.co\/6m0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JacksonPearce\/status\/571323487312154624\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/6m0B7wb0Hx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-2_qUoVEAAeeSi.jpg",
        "id_str" : "571323461559193600",
        "id" : 571323461559193600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-2_qUoVEAAeeSi.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6m0B7wb0Hx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571323487312154624",
    "text" : "I am in this library's super cool Relaxation Station. There are treats. There is tea. There are...hands. http:\/\/t.co\/6m0B7wb0Hx",
    "id" : 571323487312154624,
    "created_at" : "2015-02-27 14:58:28 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 571323669739376640,
  "created_at" : "2015-02-27 14:59:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webs",
      "screen_name" : "webs",
      "indices" : [ 3, 8 ],
      "id_str" : "17473289",
      "id" : 17473289
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/webs\/status\/571318481674743808\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/5UbDDMmGD9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-27IcqW4AABL8-.jpg",
      "id_str" : "571318481553121280",
      "id" : 571318481553121280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-27IcqW4AABL8-.jpg",
      "sizes" : [ {
        "h" : 707,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5UbDDMmGD9"
    } ],
    "hashtags" : [ {
      "text" : "Typographic",
      "indices" : [ 10, 22 ]
    }, {
      "text" : "Kindness",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/T0kefmIAWP",
      "expanded_url" : "http:\/\/bit.ly\/18uaikK",
      "display_url" : "bit.ly\/18uaikK"
    } ]
  },
  "geo" : { },
  "id_str" : "571322600946864128",
  "text" : "RT @webs: #Typographic Posters Featuring \u2018Random Words Of #Kindness\u2019 - http:\/\/t.co\/T0kefmIAWP http:\/\/t.co\/5UbDDMmGD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pagemodo.com\" rel=\"nofollow\"\u003EPagemodo.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/webs\/status\/571318481674743808\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/5UbDDMmGD9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-27IcqW4AABL8-.jpg",
        "id_str" : "571318481553121280",
        "id" : 571318481553121280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-27IcqW4AABL8-.jpg",
        "sizes" : [ {
          "h" : 707,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 707,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 707,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/5UbDDMmGD9"
      } ],
      "hashtags" : [ {
        "text" : "Typographic",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "Kindness",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/T0kefmIAWP",
        "expanded_url" : "http:\/\/bit.ly\/18uaikK",
        "display_url" : "bit.ly\/18uaikK"
      } ]
    },
    "geo" : { },
    "id_str" : "571318481674743808",
    "text" : "#Typographic Posters Featuring \u2018Random Words Of #Kindness\u2019 - http:\/\/t.co\/T0kefmIAWP http:\/\/t.co\/5UbDDMmGD9",
    "id" : 571318481674743808,
    "created_at" : "2015-02-27 14:38:35 +0000",
    "user" : {
      "name" : "Webs",
      "screen_name" : "webs",
      "protected" : false,
      "id_str" : "17473289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684823130347573248\/Xj0Kq180_normal.png",
      "id" : 17473289,
      "verified" : false
    }
  },
  "id" : 571322600946864128,
  "created_at" : "2015-02-27 14:54:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Snyder",
      "screen_name" : "noteon",
      "indices" : [ 3, 10 ],
      "id_str" : "16065917",
      "id" : 16065917
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dress",
      "indices" : [ 50, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571317029334069248",
  "text" : "RT @noteon: It's not arguing about the color of a #dress. It's being fascinated by a technological\/neurological puzzle. The Twitter IQ is U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dress",
        "indices" : [ 38, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571316867240828928",
    "text" : "It's not arguing about the color of a #dress. It's being fascinated by a technological\/neurological puzzle. The Twitter IQ is UP, not DOWN.",
    "id" : 571316867240828928,
    "created_at" : "2015-02-27 14:32:10 +0000",
    "user" : {
      "name" : "Keith Snyder",
      "screen_name" : "noteon",
      "protected" : false,
      "id_str" : "16065917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734735503069585408\/AmMDryty_normal.jpg",
      "id" : 16065917,
      "verified" : false
    }
  },
  "id" : 571317029334069248,
  "created_at" : "2015-02-27 14:32:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/503072321863942144\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/bqkYHJpN2S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvtFnHeIYAADSbi.jpg",
      "id_str" : "503072321704583168",
      "id" : 503072321704583168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvtFnHeIYAADSbi.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/bqkYHJpN2S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571314975567941632",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/bqkYHJpN2S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/503072321863942144\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/bqkYHJpN2S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvtFnHeIYAADSbi.jpg",
        "id_str" : "503072321704583168",
        "id" : 503072321704583168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvtFnHeIYAADSbi.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/bqkYHJpN2S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571313865524449281",
    "text" : "http:\/\/t.co\/bqkYHJpN2S",
    "id" : 571313865524449281,
    "created_at" : "2015-02-27 14:20:14 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 571314975567941632,
  "created_at" : "2015-02-27 14:24:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Bx7twMukhs",
      "expanded_url" : "http:\/\/thechive.com\/2015\/01\/12\/animal-expression-both-before-and-after-the-were-adopted-24-photos\/",
      "display_url" : "thechive.com\/2015\/01\/12\/ani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571313431749521408",
  "text" : "RT @bend_time: oh they KNOW wht rescue means: Love. http:\/\/t.co\/Bx7twMukhs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/Bx7twMukhs",
        "expanded_url" : "http:\/\/thechive.com\/2015\/01\/12\/animal-expression-both-before-and-after-the-were-adopted-24-photos\/",
        "display_url" : "thechive.com\/2015\/01\/12\/ani\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571305798908846080",
    "text" : "oh they KNOW wht rescue means: Love. http:\/\/t.co\/Bx7twMukhs",
    "id" : 571305798908846080,
    "created_at" : "2015-02-27 13:48:11 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 571313431749521408,
  "created_at" : "2015-02-27 14:18:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571306460048715777",
  "geo" : { },
  "id_str" : "571311029495463936",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl (((hugs)))",
  "id" : 571311029495463936,
  "in_reply_to_status_id" : 571306460048715777,
  "created_at" : "2015-02-27 14:08:58 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571140729562669056",
  "text" : "RT @TheChristianLft: Duggar daughter casts judgment against liberal Christians: You\u2019re going to Hell \u2014 but I\u2019m not\n\n[TCL: After you... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UNAElPsEil",
        "expanded_url" : "http:\/\/fb.me\/2TqcOgpDx",
        "display_url" : "fb.me\/2TqcOgpDx"
      } ]
    },
    "geo" : { },
    "id_str" : "571139578033254400",
    "text" : "Duggar daughter casts judgment against liberal Christians: You\u2019re going to Hell \u2014 but I\u2019m not\n\n[TCL: After you... http:\/\/t.co\/UNAElPsEil",
    "id" : 571139578033254400,
    "created_at" : "2015-02-27 02:47:41 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 571140729562669056,
  "created_at" : "2015-02-27 02:52:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "indices" : [ 3, 19 ],
      "id_str" : "624392588",
      "id" : 624392588
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rfttblgo",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "ftflaot",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571137006874570752",
  "text" : "RT @IvanMor79062729: From now on I'll realize every pain I feel is helping me learn the pain you feel \n\n#rfttblgo\n#ftflaot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rfttblgo",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "ftflaot",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571135567737397248",
    "text" : "From now on I'll realize every pain I feel is helping me learn the pain you feel \n\n#rfttblgo\n#ftflaot",
    "id" : 571135567737397248,
    "created_at" : "2015-02-27 02:31:45 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "protected" : false,
      "id_str" : "624392588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507966772410974208\/so1kO-9u_normal.jpeg",
      "id" : 624392588,
      "verified" : false
    }
  },
  "id" : 571137006874570752,
  "created_at" : "2015-02-27 02:37:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TenDraftsDeep\u2122",
      "screen_name" : "Tendraftsdeep",
      "indices" : [ 3, 17 ],
      "id_str" : "25071732",
      "id" : 25071732
    }, {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "indices" : [ 20, 34 ],
      "id_str" : "255780065",
      "id" : 255780065
    }, {
      "name" : "New York Magazine",
      "screen_name" : "NYMag",
      "indices" : [ 36, 42 ],
      "id_str" : "45564482",
      "id" : 45564482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NYMag\/status\/571133287831359490\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RjNDDMBDAm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-0Ssv9XEAAmDzM.jpg",
      "id_str" : "571133287743295488",
      "id" : 571133287743295488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-0Ssv9XEAAmDzM.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RjNDDMBDAm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/m0YoYuncWz",
      "expanded_url" : "http:\/\/nym.ag\/1JSzlP2",
      "display_url" : "nym.ag\/1JSzlP2"
    } ]
  },
  "geo" : { },
  "id_str" : "571136685515399169",
  "text" : "RT @Tendraftsdeep: .@Crowtographer \"@NYMag: Mystical 8-year-old is worshipped by wild crows: http:\/\/t.co\/m0YoYuncWz http:\/\/t.co\/RjNDDMBDAm\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Crowtographer",
        "screen_name" : "Crowtographer",
        "indices" : [ 1, 15 ],
        "id_str" : "255780065",
        "id" : 255780065
      }, {
        "name" : "New York Magazine",
        "screen_name" : "NYMag",
        "indices" : [ 17, 23 ],
        "id_str" : "45564482",
        "id" : 45564482
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NYMag\/status\/571133287831359490\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/RjNDDMBDAm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-0Ssv9XEAAmDzM.jpg",
        "id_str" : "571133287743295488",
        "id" : 571133287743295488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-0Ssv9XEAAmDzM.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RjNDDMBDAm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/m0YoYuncWz",
        "expanded_url" : "http:\/\/nym.ag\/1JSzlP2",
        "display_url" : "nym.ag\/1JSzlP2"
      } ]
    },
    "geo" : { },
    "id_str" : "571134054197792769",
    "text" : ".@Crowtographer \"@NYMag: Mystical 8-year-old is worshipped by wild crows: http:\/\/t.co\/m0YoYuncWz http:\/\/t.co\/RjNDDMBDAm\"",
    "id" : 571134054197792769,
    "created_at" : "2015-02-27 02:25:44 +0000",
    "user" : {
      "name" : "TenDraftsDeep\u2122",
      "screen_name" : "Tendraftsdeep",
      "protected" : false,
      "id_str" : "25071732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799051088972365825\/e9KEvnr9_normal.jpg",
      "id" : 25071732,
      "verified" : false
    }
  },
  "id" : 571136685515399169,
  "created_at" : "2015-02-27 02:36:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Alex Minor",
      "screen_name" : "pen_named",
      "indices" : [ 14, 24 ],
      "id_str" : "706979129422286848",
      "id" : 706979129422286848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571129324624945152",
  "geo" : { },
  "id_str" : "571133320148471808",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms @pen_named I'd like to know, too",
  "id" : 571133320148471808,
  "in_reply_to_status_id" : 571129324624945152,
  "created_at" : "2015-02-27 02:22:49 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Walsh",
      "screen_name" : "BradWalsh",
      "indices" : [ 3, 13 ],
      "id_str" : "15173253",
      "id" : 15173253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571129913811578880",
  "text" : "RT @BradWalsh: Having successfully distracted the human race with llamas and a cheap dress, the aliens were able to overtake all government\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571127905792749570",
    "text" : "Having successfully distracted the human race with llamas and a cheap dress, the aliens were able to overtake all governments with ease",
    "id" : 571127905792749570,
    "created_at" : "2015-02-27 02:01:18 +0000",
    "user" : {
      "name" : "Brad Walsh",
      "screen_name" : "BradWalsh",
      "protected" : false,
      "id_str" : "15173253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758412235601506305\/yLpHQeTZ_normal.jpg",
      "id" : 15173253,
      "verified" : true
    }
  },
  "id" : 571129913811578880,
  "created_at" : "2015-02-27 02:09:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Minor",
      "screen_name" : "pen_named",
      "indices" : [ 3, 13 ],
      "id_str" : "706979129422286848",
      "id" : 706979129422286848
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pen_named\/status\/563009289900793856\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/dnzwPlYmrt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9A19glIQAEUpIy.jpg",
      "id_str" : "563009284255268865",
      "id" : 563009284255268865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9A19glIQAEUpIy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dnzwPlYmrt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571128368088911873",
  "text" : "RT @pen_named: http:\/\/t.co\/dnzwPlYmrt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pen_named\/status\/563009289900793856\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/dnzwPlYmrt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9A19glIQAEUpIy.jpg",
        "id_str" : "563009284255268865",
        "id" : 563009284255268865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9A19glIQAEUpIy.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dnzwPlYmrt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563009289900793856",
    "text" : "http:\/\/t.co\/dnzwPlYmrt",
    "id" : 563009289900793856,
    "created_at" : "2015-02-04 16:20:49 +0000",
    "user" : {
      "name" : "\u26A1\uFE0F",
      "screen_name" : "seekflight",
      "protected" : false,
      "id_str" : "2285738774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775862060404002816\/EXFixZiz_normal.jpg",
      "id" : 2285738774,
      "verified" : false
    }
  },
  "id" : 571128368088911873,
  "created_at" : "2015-02-27 02:03:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571113205193433088",
  "geo" : { },
  "id_str" : "571119930126573571",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist I had a feeling that you were a good egg...",
  "id" : 571119930126573571,
  "in_reply_to_status_id" : 571113205193433088,
  "created_at" : "2015-02-27 01:29:36 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MVHCA",
      "screen_name" : "MVHCA",
      "indices" : [ 3, 9 ],
      "id_str" : "1528109156",
      "id" : 1528109156
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MVHCA\/status\/571021999067172864\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/MpeZRRX1Cl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yRsubVIAEVf5C.jpg",
      "id_str" : "570991450332143617",
      "id" : 570991450332143617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yRsubVIAEVf5C.jpg",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/MpeZRRX1Cl"
    } ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "Medicare4ALL",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/fCxVjYThVU",
      "expanded_url" : "http:\/\/for.tn\/1JQUER9",
      "display_url" : "for.tn\/1JQUER9"
    } ]
  },
  "geo" : { },
  "id_str" : "571077980497301504",
  "text" : "RT @MVHCA: Why health insurance companies are doomed. http:\/\/t.co\/fCxVjYThVU #SinglePayer #Medicare4ALL http:\/\/t.co\/MpeZRRX1Cl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MVHCA\/status\/571021999067172864\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/MpeZRRX1Cl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yRsubVIAEVf5C.jpg",
        "id_str" : "570991450332143617",
        "id" : 570991450332143617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yRsubVIAEVf5C.jpg",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/MpeZRRX1Cl"
      } ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 66, 78 ]
      }, {
        "text" : "Medicare4ALL",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/fCxVjYThVU",
        "expanded_url" : "http:\/\/for.tn\/1JQUER9",
        "display_url" : "for.tn\/1JQUER9"
      } ]
    },
    "geo" : { },
    "id_str" : "571021999067172864",
    "text" : "Why health insurance companies are doomed. http:\/\/t.co\/fCxVjYThVU #SinglePayer #Medicare4ALL http:\/\/t.co\/MpeZRRX1Cl",
    "id" : 571021999067172864,
    "created_at" : "2015-02-26 19:00:28 +0000",
    "user" : {
      "name" : "MVHCA",
      "screen_name" : "MVHCA",
      "protected" : false,
      "id_str" : "1528109156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756266586369953792\/HYPcHIle_normal.jpg",
      "id" : 1528109156,
      "verified" : false
    }
  },
  "id" : 571077980497301504,
  "created_at" : "2015-02-26 22:42:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom",
      "screen_name" : "TomEcho6",
      "indices" : [ 3, 12 ],
      "id_str" : "37208927",
      "id" : 37208927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571057695178010625",
  "text" : "RT @TomEcho6: I can't wait for a flock of cows to run wild somewhere.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571056218262904832",
    "text" : "I can't wait for a flock of cows to run wild somewhere.",
    "id" : 571056218262904832,
    "created_at" : "2015-02-26 21:16:26 +0000",
    "user" : {
      "name" : "Tom",
      "screen_name" : "TomEcho6",
      "protected" : false,
      "id_str" : "37208927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459872898002731008\/c7ugEWtt_normal.jpeg",
      "id" : 37208927,
      "verified" : false
    }
  },
  "id" : 571057695178010625,
  "created_at" : "2015-02-26 21:22:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571047467799564288",
  "geo" : { },
  "id_str" : "571055953140965376",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time Instagram is cool. I don't post just follow for animal videos and pretty nature pics.",
  "id" : 571055953140965376,
  "in_reply_to_status_id" : 571047467799564288,
  "created_at" : "2015-02-26 21:15:23 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SHEREDWOLF\/status\/571029475481272320\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/pSwA4CTI0w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y0SAmUIAA1-ZO.jpg",
      "id_str" : "571029474260557824",
      "id" : 571029474260557824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y0SAmUIAA1-ZO.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/pSwA4CTI0w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571030602276855808",
  "text" : "RT @SHEREDWOLF: http:\/\/t.co\/pSwA4CTI0w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SHEREDWOLF\/status\/571029475481272320\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/pSwA4CTI0w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y0SAmUIAA1-ZO.jpg",
        "id_str" : "571029474260557824",
        "id" : 571029474260557824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y0SAmUIAA1-ZO.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/pSwA4CTI0w"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571029475481272320",
    "text" : "http:\/\/t.co\/pSwA4CTI0w",
    "id" : 571029475481272320,
    "created_at" : "2015-02-26 19:30:10 +0000",
    "user" : {
      "name" : "\uADF8\uB140 - \uB291\uB300",
      "screen_name" : "wolves_my_love",
      "protected" : false,
      "id_str" : "560545385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752248927899021313\/APaMam9p_normal.jpg",
      "id" : 560545385,
      "verified" : false
    }
  },
  "id" : 571030602276855808,
  "created_at" : "2015-02-26 19:34:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571030011509137408",
  "text" : "RT @FreeRangeKids: Are teens who sext \"child pornographers?\" In some states, yes. Because prison will solve problem of horny teens.  http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/A47Qn0rWYZ",
        "expanded_url" : "http:\/\/bit.ly\/1BhFCOH",
        "display_url" : "bit.ly\/1BhFCOH"
      } ]
    },
    "geo" : { },
    "id_str" : "571024887185342465",
    "text" : "Are teens who sext \"child pornographers?\" In some states, yes. Because prison will solve problem of horny teens.  http:\/\/t.co\/A47Qn0rWYZ",
    "id" : 571024887185342465,
    "created_at" : "2015-02-26 19:11:56 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 571030011509137408,
  "created_at" : "2015-02-26 19:32:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Webster",
      "screen_name" : "webster_cat",
      "indices" : [ 3, 15 ],
      "id_str" : "582185111",
      "id" : 582185111
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/webster_cat\/status\/570906271437729792\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ZRNUpIHu2m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-xEOj7W0AEiXYi.jpg",
      "id_str" : "570906269722267649",
      "id" : 570906269722267649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-xEOj7W0AEiXYi.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 565
      } ],
      "display_url" : "pic.twitter.com\/ZRNUpIHu2m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571028669600301056",
  "text" : "RT @webster_cat: You bring my food? http:\/\/t.co\/ZRNUpIHu2m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/webster_cat\/status\/570906271437729792\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ZRNUpIHu2m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-xEOj7W0AEiXYi.jpg",
        "id_str" : "570906269722267649",
        "id" : 570906269722267649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-xEOj7W0AEiXYi.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 565
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 565
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 565
        } ],
        "display_url" : "pic.twitter.com\/ZRNUpIHu2m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570906271437729792",
    "text" : "You bring my food? http:\/\/t.co\/ZRNUpIHu2m",
    "id" : 570906271437729792,
    "created_at" : "2015-02-26 11:20:36 +0000",
    "user" : {
      "name" : "Catherine Webster",
      "screen_name" : "webster_cat",
      "protected" : false,
      "id_str" : "582185111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3747254117\/59cb71367f94ed73359a1746529a52b8_normal.jpeg",
      "id" : 582185111,
      "verified" : false
    }
  },
  "id" : 571028669600301056,
  "created_at" : "2015-02-26 19:26:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 0, 14 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571004515941548038",
  "geo" : { },
  "id_str" : "571010702007246848",
  "in_reply_to_user_id" : 272369448,
  "text" : "@Swanwhisperer oh no... : (",
  "id" : 571010702007246848,
  "in_reply_to_status_id" : 571004515941548038,
  "created_at" : "2015-02-26 18:15:34 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "The Dodo",
      "screen_name" : "dodo",
      "indices" : [ 20, 25 ],
      "id_str" : "1604444052",
      "id" : 1604444052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/3F8PXAfBN7",
      "expanded_url" : "http:\/\/thedo.do\/1MRJr1J",
      "display_url" : "thedo.do\/1MRJr1J"
    } ]
  },
  "geo" : { },
  "id_str" : "571009989009121281",
  "text" : "RT @oceanshaman: Mt @dodo:Heartbreaking: mother cow hides newborn baby in attempts to keep farmer fr taking her http:\/\/t.co\/3F8PXAfBN7 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Dodo",
        "screen_name" : "dodo",
        "indices" : [ 3, 8 ],
        "id_str" : "1604444052",
        "id" : 1604444052
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dodo\/status\/570871690663587843\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hS1bJYPKF4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-uW9iKWkAAEN6r.jpg",
        "id_str" : "570715761678913536",
        "id" : 570715761678913536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-uW9iKWkAAEN6r.jpg",
        "sizes" : [ {
          "h" : 1470,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1470,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hS1bJYPKF4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/3F8PXAfBN7",
        "expanded_url" : "http:\/\/thedo.do\/1MRJr1J",
        "display_url" : "thedo.do\/1MRJr1J"
      } ]
    },
    "geo" : { },
    "id_str" : "571005111369142272",
    "text" : "Mt @dodo:Heartbreaking: mother cow hides newborn baby in attempts to keep farmer fr taking her http:\/\/t.co\/3F8PXAfBN7 http:\/\/t.co\/hS1bJYPKF4",
    "id" : 571005111369142272,
    "created_at" : "2015-02-26 17:53:21 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 571009989009121281,
  "created_at" : "2015-02-26 18:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/571005297273106432\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/gLvCFaZLau",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yeRVzUIAAnSgR.jpg",
      "id_str" : "571005273516548096",
      "id" : 571005273516548096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yeRVzUIAAnSgR.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gLvCFaZLau"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "Nebraska",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571009897711730688",
  "text" : "RT @rm123077: We saw this cute little Pygmy Nuthatch in the Wildcat Hills. #birds #Nebraska http:\/\/t.co\/gLvCFaZLau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/571005297273106432\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/gLvCFaZLau",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yeRVzUIAAnSgR.jpg",
        "id_str" : "571005273516548096",
        "id" : 571005273516548096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yeRVzUIAAnSgR.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gLvCFaZLau"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 61, 67 ]
      }, {
        "text" : "Nebraska",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571005297273106432",
    "text" : "We saw this cute little Pygmy Nuthatch in the Wildcat Hills. #birds #Nebraska http:\/\/t.co\/gLvCFaZLau",
    "id" : 571005297273106432,
    "created_at" : "2015-02-26 17:54:06 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 571009897711730688,
  "created_at" : "2015-02-26 18:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/571005791265812480\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/YRwKLqb30v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yeu7oWoAAQDF8.jpg",
      "id_str" : "571005781887328256",
      "id" : 571005781887328256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yeu7oWoAAQDF8.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YRwKLqb30v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571009723933323264",
  "text" : "RT @zacaplus: http:\/\/t.co\/YRwKLqb30v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/571005791265812480\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/YRwKLqb30v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yeu7oWoAAQDF8.jpg",
        "id_str" : "571005781887328256",
        "id" : 571005781887328256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yeu7oWoAAQDF8.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YRwKLqb30v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571005791265812480",
    "text" : "http:\/\/t.co\/YRwKLqb30v",
    "id" : 571005791265812480,
    "created_at" : "2015-02-26 17:56:04 +0000",
    "user" : {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "protected" : false,
      "id_str" : "1316959200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711110597593702400\/FL6-Tb30_normal.jpg",
      "id" : 1316959200,
      "verified" : false
    }
  },
  "id" : 571009723933323264,
  "created_at" : "2015-02-26 18:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blair roberts",
      "screen_name" : "btotherock",
      "indices" : [ 3, 14 ],
      "id_str" : "174870242",
      "id" : 174870242
    }, {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 38, 51 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571008988512460801",
  "text" : "RT @btotherock: Science Mike podcast (@mikemchargue) told me I'm a \"finely tuned sexual machine.\" I always knew it. Adding that to my bio\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science Mike",
        "screen_name" : "mikemchargue",
        "indices" : [ 22, 35 ],
        "id_str" : "6091632",
        "id" : 6091632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571001687986479104",
    "text" : "Science Mike podcast (@mikemchargue) told me I'm a \"finely tuned sexual machine.\" I always knew it. Adding that to my bio\/business cards.",
    "id" : 571001687986479104,
    "created_at" : "2015-02-26 17:39:45 +0000",
    "user" : {
      "name" : "blair roberts",
      "screen_name" : "btotherock",
      "protected" : false,
      "id_str" : "174870242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584918615704481793\/I14dD_Qn_normal.jpg",
      "id" : 174870242,
      "verified" : false
    }
  },
  "id" : 571008988512460801,
  "created_at" : "2015-02-26 18:08:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Green",
      "screen_name" : "HuffPostGreen",
      "indices" : [ 3, 17 ],
      "id_str" : "45577446",
      "id" : 45577446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/A3gAJqyJ74",
      "expanded_url" : "http:\/\/huff.to\/1AbVjRT",
      "display_url" : "huff.to\/1AbVjRT"
    } ]
  },
  "geo" : { },
  "id_str" : "571008213186957312",
  "text" : "RT @HuffPostGreen: Oregon's gray wolf population is rebounding http:\/\/t.co\/A3gAJqyJ74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/A3gAJqyJ74",
        "expanded_url" : "http:\/\/huff.to\/1AbVjRT",
        "display_url" : "huff.to\/1AbVjRT"
      } ]
    },
    "geo" : { },
    "id_str" : "571004298777243651",
    "text" : "Oregon's gray wolf population is rebounding http:\/\/t.co\/A3gAJqyJ74",
    "id" : 571004298777243651,
    "created_at" : "2015-02-26 17:50:08 +0000",
    "user" : {
      "name" : "HuffPost Green",
      "screen_name" : "HuffPostGreen",
      "protected" : false,
      "id_str" : "45577446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496305708153843712\/WXbN5Gam_normal.jpeg",
      "id" : 45577446,
      "verified" : true
    }
  },
  "id" : 571008213186957312,
  "created_at" : "2015-02-26 18:05:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yankeluh",
      "screen_name" : "Yankeluh",
      "indices" : [ 3, 12 ],
      "id_str" : "20792672",
      "id" : 20792672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theView",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570988193056735233",
  "text" : "RT @Yankeluh: #theView note prisons are now being run by for profit corporations - we lock up people so they make a profit!! where's the ju\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theView",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570985106585681920",
    "text" : "#theView note prisons are now being run by for profit corporations - we lock up people so they make a profit!! where's the justice in that?",
    "id" : 570985106585681920,
    "created_at" : "2015-02-26 16:33:52 +0000",
    "user" : {
      "name" : "Yankeluh",
      "screen_name" : "Yankeluh",
      "protected" : false,
      "id_str" : "20792672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/201778335\/counter_normal.jpg",
      "id" : 20792672,
      "verified" : false
    }
  },
  "id" : 570988193056735233,
  "created_at" : "2015-02-26 16:46:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Random House",
      "screen_name" : "penguinrandom",
      "indices" : [ 3, 17 ],
      "id_str" : "14360757",
      "id" : 14360757
    }, {
      "name" : "Holly Pearson",
      "screen_name" : "HollyPearson",
      "indices" : [ 28, 41 ],
      "id_str" : "19644856",
      "id" : 19644856
    }, {
      "name" : "Irvine Welsh",
      "screen_name" : "IrvineWelsh",
      "indices" : [ 44, 56 ],
      "id_str" : "501825960",
      "id" : 501825960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VintageLive",
      "indices" : [ 107, 119 ]
    }, {
      "text" : "PenguinRHUK15",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570987939582361600",
  "text" : "RT @penguinrandom: Want! RT @hollypearson: .@IrvineWelsh wins the prize for best outfit of the conference. #VintageLive #PenguinRHUK15 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Holly Pearson",
        "screen_name" : "HollyPearson",
        "indices" : [ 9, 22 ],
        "id_str" : "19644856",
        "id" : 19644856
      }, {
        "name" : "Irvine Welsh",
        "screen_name" : "IrvineWelsh",
        "indices" : [ 25, 37 ],
        "id_str" : "501825960",
        "id" : 501825960
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HollyPearson\/status\/570967920953692161\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/eWMWMJj3TL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-x8S-iXEAA_Ln2.jpg",
        "id_str" : "570967918235815936",
        "id" : 570967918235815936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-x8S-iXEAA_Ln2.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eWMWMJj3TL"
      } ],
      "hashtags" : [ {
        "text" : "VintageLive",
        "indices" : [ 88, 100 ]
      }, {
        "text" : "PenguinRHUK15",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570985470466887680",
    "text" : "Want! RT @hollypearson: .@IrvineWelsh wins the prize for best outfit of the conference. #VintageLive #PenguinRHUK15 http:\/\/t.co\/eWMWMJj3TL",
    "id" : 570985470466887680,
    "created_at" : "2015-02-26 16:35:19 +0000",
    "user" : {
      "name" : "Penguin Random House",
      "screen_name" : "penguinrandom",
      "protected" : false,
      "id_str" : "14360757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734897030154326016\/ZW3LbfsZ_normal.jpg",
      "id" : 14360757,
      "verified" : true
    }
  },
  "id" : 570987939582361600,
  "created_at" : "2015-02-26 16:45:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jena C.",
      "screen_name" : "JenaC2",
      "indices" : [ 3, 10 ],
      "id_str" : "2430564295",
      "id" : 2430564295
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JenaC2\/status\/570734112664784896\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/JwWvKMaKGK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-uno8DUAAAmtgP.jpg",
      "id_str" : "570734099549126656",
      "id" : 570734099549126656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-uno8DUAAAmtgP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 907
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 907
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JwWvKMaKGK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570987520923701251",
  "text" : "RT @JenaC2: Scotland http:\/\/t.co\/JwWvKMaKGK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenaC2\/status\/570734112664784896\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/JwWvKMaKGK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-uno8DUAAAmtgP.jpg",
        "id_str" : "570734099549126656",
        "id" : 570734099549126656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-uno8DUAAAmtgP.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 907
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 907
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JwWvKMaKGK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570734112664784896",
    "text" : "Scotland http:\/\/t.co\/JwWvKMaKGK",
    "id" : 570734112664784896,
    "created_at" : "2015-02-25 23:56:30 +0000",
    "user" : {
      "name" : "Jena C.",
      "screen_name" : "JenaC2",
      "protected" : false,
      "id_str" : "2430564295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486298165872558080\/iIbifN84_normal.jpeg",
      "id" : 2430564295,
      "verified" : false
    }
  },
  "id" : 570987520923701251,
  "created_at" : "2015-02-26 16:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMAgulag",
      "screen_name" : "FEMAgulag",
      "indices" : [ 3, 13 ],
      "id_str" : "2612937380",
      "id" : 2612937380
    }, {
      "name" : "Eileen",
      "screen_name" : "rayann2320",
      "indices" : [ 17, 28 ],
      "id_str" : "2539848682",
      "id" : 2539848682
    }, {
      "name" : "Emergency Kittens",
      "screen_name" : "EmrgencyKittens",
      "indices" : [ 31, 47 ],
      "id_str" : "1041346340",
      "id" : 1041346340
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 65, 72 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FEMAgulag\/status\/570983234395357184\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/OfmVv4Kc9L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yKOdKUYAARV8o.jpg",
      "id_str" : "570983233719918592",
      "id" : 570983233719918592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yKOdKUYAARV8o.jpg",
      "sizes" : [ {
        "h" : 273,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/OfmVv4Kc9L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570987358948069377",
  "text" : "RT @FEMAgulag: RT@rayann2320 RT@EmrgencyKittens Is this found on @Amazon? http:\/\/t.co\/OfmVv4Kc9L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eileen",
        "screen_name" : "rayann2320",
        "indices" : [ 2, 13 ],
        "id_str" : "2539848682",
        "id" : 2539848682
      }, {
        "name" : "Emergency Kittens",
        "screen_name" : "EmrgencyKittens",
        "indices" : [ 16, 32 ],
        "id_str" : "1041346340",
        "id" : 1041346340
      }, {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 50, 57 ],
        "id_str" : "20793816",
        "id" : 20793816
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FEMAgulag\/status\/570983234395357184\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/OfmVv4Kc9L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-yKOdKUYAARV8o.jpg",
        "id_str" : "570983233719918592",
        "id" : 570983233719918592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-yKOdKUYAARV8o.jpg",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/OfmVv4Kc9L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570983234395357184",
    "text" : "RT@rayann2320 RT@EmrgencyKittens Is this found on @Amazon? http:\/\/t.co\/OfmVv4Kc9L",
    "id" : 570983234395357184,
    "created_at" : "2015-02-26 16:26:26 +0000",
    "user" : {
      "name" : "FEMAgulag",
      "screen_name" : "FEMAgulag",
      "protected" : false,
      "id_str" : "2612937380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486733719684665344\/d0h-19br_normal.jpeg",
      "id" : 2612937380,
      "verified" : false
    }
  },
  "id" : 570987358948069377,
  "created_at" : "2015-02-26 16:42:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trans",
      "indices" : [ 79, 85 ]
    }, {
      "text" : "LGBTQ",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/f7uwMoodwv",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=irQClUTaWJA",
      "display_url" : "m.youtube.com\/watch?v=irQClU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570661585015988224",
  "text" : "Transform by Isabella Bennett of Steam Powered Giraffe https:\/\/t.co\/f7uwMoodwv #trans #LGBTQ",
  "id" : 570661585015988224,
  "created_at" : "2015-02-25 19:08:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/570581447007977472\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/6gDXYoE6Lx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-scy7cWwAIMpi2.jpg",
      "id_str" : "570581439068160002",
      "id" : 570581439068160002,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-scy7cWwAIMpi2.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6gDXYoE6Lx"
    } ],
    "hashtags" : [ {
      "text" : "RobinCam",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570634226560839681",
  "text" : "RT @WildlifeGadgets: Checking #RobinCam on my phone. Pleased to see Mrs R is sitting tight. http:\/\/t.co\/6gDXYoE6Lx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/570581447007977472\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/6gDXYoE6Lx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-scy7cWwAIMpi2.jpg",
        "id_str" : "570581439068160002",
        "id" : 570581439068160002,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-scy7cWwAIMpi2.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6gDXYoE6Lx"
      } ],
      "hashtags" : [ {
        "text" : "RobinCam",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570581447007977472",
    "text" : "Checking #RobinCam on my phone. Pleased to see Mrs R is sitting tight. http:\/\/t.co\/6gDXYoE6Lx",
    "id" : 570581447007977472,
    "created_at" : "2015-02-25 13:49:52 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 570634226560839681,
  "created_at" : "2015-02-25 17:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00A9 #fakenews",
      "screen_name" : "theUKtoday",
      "indices" : [ 3, 14 ],
      "id_str" : "100337625",
      "id" : 100337625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ghandi",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570416428081397761",
  "text" : "RT @theUKtoday: #Ghandi changed an entire continent &amp; never went to war",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ghandi",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570411094486990849",
    "text" : "#Ghandi changed an entire continent &amp; never went to war",
    "id" : 570411094486990849,
    "created_at" : "2015-02-25 02:32:57 +0000",
    "user" : {
      "name" : "\u00A9 #fakenews",
      "screen_name" : "theUKtoday",
      "protected" : false,
      "id_str" : "100337625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800115796815003648\/u9QKu1P__normal.jpg",
      "id" : 100337625,
      "verified" : false
    }
  },
  "id" : 570416428081397761,
  "created_at" : "2015-02-25 02:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/qXLDqrG5N8",
      "expanded_url" : "http:\/\/www.boredpanda.com\/ingo-poldi-dog-owl-friendship-tanja-brandt\/",
      "display_url" : "boredpanda.com\/ingo-poldi-dog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570372067381645312",
  "text" : "RT @VirgoJohnny: The Unlikely Friendship Of A Dog And An Owl - http:\/\/t.co\/qXLDqrG5N8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/qXLDqrG5N8",
        "expanded_url" : "http:\/\/www.boredpanda.com\/ingo-poldi-dog-owl-friendship-tanja-brandt\/",
        "display_url" : "boredpanda.com\/ingo-poldi-dog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570356635702468608",
    "text" : "The Unlikely Friendship Of A Dog And An Owl - http:\/\/t.co\/qXLDqrG5N8",
    "id" : 570356635702468608,
    "created_at" : "2015-02-24 22:56:33 +0000",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 570372067381645312,
  "created_at" : "2015-02-24 23:57:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Moore",
      "screen_name" : "Wexcoastbirds",
      "indices" : [ 3, 17 ],
      "id_str" : "158135344",
      "id" : 158135344
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Wexcoastbirds\/status\/569942291886055424\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/KDILiZ4i9S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jXfmEIcAAq6UD.jpg",
      "id_str" : "569942290656161792",
      "id" : 569942290656161792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jXfmEIcAAq6UD.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 594
      } ],
      "display_url" : "pic.twitter.com\/KDILiZ4i9S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570320998039457792",
  "text" : "RT @Wexcoastbirds: Irish hares , Slade , Co Wexford..... http:\/\/t.co\/KDILiZ4i9S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wexcoastbirds\/status\/569942291886055424\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/KDILiZ4i9S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jXfmEIcAAq6UD.jpg",
        "id_str" : "569942290656161792",
        "id" : 569942290656161792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jXfmEIcAAq6UD.jpg",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 594
        } ],
        "display_url" : "pic.twitter.com\/KDILiZ4i9S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569942291886055424",
    "text" : "Irish hares , Slade , Co Wexford..... http:\/\/t.co\/KDILiZ4i9S",
    "id" : 569942291886055424,
    "created_at" : "2015-02-23 19:30:06 +0000",
    "user" : {
      "name" : "Tom Moore",
      "screen_name" : "Wexcoastbirds",
      "protected" : false,
      "id_str" : "158135344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715834878428884992\/HqTCcBty_normal.jpg",
      "id" : 158135344,
      "verified" : false
    }
  },
  "id" : 570320998039457792,
  "created_at" : "2015-02-24 20:34:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570303463910998016",
  "text" : "RT @AnAmericanMonk: \"Ignore those that make you fearful and sad, that degrade you back towards disease and death.\" \u2015 Rumi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570303103376986112",
    "text" : "\"Ignore those that make you fearful and sad, that degrade you back towards disease and death.\" \u2015 Rumi",
    "id" : 570303103376986112,
    "created_at" : "2015-02-24 19:23:50 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 570303463910998016,
  "created_at" : "2015-02-24 19:25:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE YORKSHIRE",
      "screen_name" : "OneYorkshire",
      "indices" : [ 3, 16 ],
      "id_str" : "1230298436",
      "id" : 1230298436
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OneYorkshire\/status\/570289646388813825\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Ix0xKOZ9H0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oTaWEXAAIigPE.png",
      "id_str" : "570289646137180162",
      "id" : 570289646137180162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oTaWEXAAIigPE.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ix0xKOZ9H0"
    } ],
    "hashtags" : [ {
      "text" : "Yorkshire",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570293673767936003",
  "text" : "RT @OneYorkshire: Coverham Church &amp; Churchyard #Yorkshire Photo by Rick Harrision http:\/\/t.co\/Ix0xKOZ9H0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OneYorkshire\/status\/570289646388813825\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/Ix0xKOZ9H0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oTaWEXAAIigPE.png",
        "id_str" : "570289646137180162",
        "id" : 570289646137180162,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oTaWEXAAIigPE.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ix0xKOZ9H0"
      } ],
      "hashtags" : [ {
        "text" : "Yorkshire",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570289646388813825",
    "text" : "Coverham Church &amp; Churchyard #Yorkshire Photo by Rick Harrision http:\/\/t.co\/Ix0xKOZ9H0",
    "id" : 570289646388813825,
    "created_at" : "2015-02-24 18:30:21 +0000",
    "user" : {
      "name" : "ONE YORKSHIRE",
      "screen_name" : "OneYorkshire",
      "protected" : false,
      "id_str" : "1230298436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734680354624294912\/7il0cicV_normal.jpg",
      "id" : 1230298436,
      "verified" : false
    }
  },
  "id" : 570293673767936003,
  "created_at" : "2015-02-24 18:46:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bette Midler",
      "screen_name" : "BetteMidler",
      "indices" : [ 3, 15 ],
      "id_str" : "139823781",
      "id" : 139823781
    }, {
      "name" : "Syngenta",
      "screen_name" : "Syngenta",
      "indices" : [ 36, 45 ],
      "id_str" : "17488526",
      "id" : 17488526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Atrazine",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570291451227189248",
  "text" : "RT @BetteMidler: Here's a good one: @Syngenta, which makes the BANNED-IN-EUROPE pesticide #Atrazine sells 77.3 MILLION pounds of it to US! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Syngenta",
        "screen_name" : "Syngenta",
        "indices" : [ 19, 28 ],
        "id_str" : "17488526",
        "id" : 17488526
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Atrazine",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.0983708008234, -118.4046185582637 ]
    },
    "id_str" : "570283683602542593",
    "text" : "Here's a good one: @Syngenta, which makes the BANNED-IN-EUROPE pesticide #Atrazine sells 77.3 MILLION pounds of it to US! How stupid are we?",
    "id" : 570283683602542593,
    "created_at" : "2015-02-24 18:06:40 +0000",
    "user" : {
      "name" : "Bette Midler",
      "screen_name" : "BetteMidler",
      "protected" : false,
      "id_str" : "139823781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793394076787757056\/Fnx0wN6Q_normal.jpg",
      "id" : 139823781,
      "verified" : true
    }
  },
  "id" : 570291451227189248,
  "created_at" : "2015-02-24 18:37:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Cambridgeshire",
      "screen_name" : "BBCCambs",
      "indices" : [ 3, 12 ],
      "id_str" : "48400758",
      "id" : 48400758
    }, {
      "name" : "Anglesey Abbey NT",
      "screen_name" : "AngleseyAbbeyNT",
      "indices" : [ 89, 105 ],
      "id_str" : "271931236",
      "id" : 271931236
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BBCCambs\/status\/563712625641816066\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ppabMRv3DC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K1pUXIMAASgAQ.jpg",
      "id_str" : "563712624819712000",
      "id" : 563712624819712000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K1pUXIMAASgAQ.jpg",
      "sizes" : [ {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ppabMRv3DC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570290902310264833",
  "text" : "RT @BBCCambs: Is Spring on its way back to Cambridgeshire already? The snowdrops are out @AngleseyAbbeyNT http:\/\/t.co\/ppabMRv3DC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anglesey Abbey NT",
        "screen_name" : "AngleseyAbbeyNT",
        "indices" : [ 75, 91 ],
        "id_str" : "271931236",
        "id" : 271931236
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BBCCambs\/status\/563712625641816066\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/ppabMRv3DC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K1pUXIMAASgAQ.jpg",
        "id_str" : "563712624819712000",
        "id" : 563712624819712000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K1pUXIMAASgAQ.jpg",
        "sizes" : [ {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ppabMRv3DC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563712625641816066",
    "text" : "Is Spring on its way back to Cambridgeshire already? The snowdrops are out @AngleseyAbbeyNT http:\/\/t.co\/ppabMRv3DC",
    "id" : 563712625641816066,
    "created_at" : "2015-02-06 14:55:37 +0000",
    "user" : {
      "name" : "BBC Cambridgeshire",
      "screen_name" : "BBCCambs",
      "protected" : false,
      "id_str" : "48400758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1307974658\/twitter_cambridgeshire73x73_normal.gif",
      "id" : 48400758,
      "verified" : true
    }
  },
  "id" : 570290902310264833,
  "created_at" : "2015-02-24 18:35:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CaroleODell\/status\/570283460054503424\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/iXJ5ZRToZ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oNx4UUEAE-NaQ.jpg",
      "id_str" : "570283453398126593",
      "id" : 570283453398126593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oNx4UUEAE-NaQ.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iXJ5ZRToZ4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570284630982717440",
  "text" : "RT @CaroleODell: http:\/\/t.co\/iXJ5ZRToZ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CaroleODell\/status\/570283460054503424\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/iXJ5ZRToZ4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oNx4UUEAE-NaQ.jpg",
        "id_str" : "570283453398126593",
        "id" : 570283453398126593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oNx4UUEAE-NaQ.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iXJ5ZRToZ4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570283460054503424",
    "text" : "http:\/\/t.co\/iXJ5ZRToZ4",
    "id" : 570283460054503424,
    "created_at" : "2015-02-24 18:05:46 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 570284630982717440,
  "created_at" : "2015-02-24 18:10:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. \u0394. \u0126UN\u0166",
      "screen_name" : "authorsahunt",
      "indices" : [ 3, 16 ],
      "id_str" : "119038924",
      "id" : 119038924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570284174525001728",
  "text" : "RT @authorsahunt: Does burning bridges count when the bridge doesn\u2019t go all the way over the river?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570282760906137600",
    "text" : "Does burning bridges count when the bridge doesn\u2019t go all the way over the river?",
    "id" : 570282760906137600,
    "created_at" : "2015-02-24 18:03:00 +0000",
    "user" : {
      "name" : "S. \u0394. \u0126UN\u0166",
      "screen_name" : "authorsahunt",
      "protected" : false,
      "id_str" : "119038924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757970884804116480\/GbzKF8qR_normal.jpg",
      "id" : 119038924,
      "verified" : false
    }
  },
  "id" : 570284174525001728,
  "created_at" : "2015-02-24 18:08:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570279698699292672",
  "text" : "Weather kept me from bible study few weeks. Good to get back w my gals!",
  "id" : 570279698699292672,
  "created_at" : "2015-02-24 17:50:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/503580125389398016\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4JSoX78bee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv0TdLBIcAAY5I_.jpg",
      "id_str" : "503580125230034944",
      "id" : 503580125230034944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv0TdLBIcAAY5I_.jpg",
      "sizes" : [ {
        "h" : 475,
        "resize" : "fit",
        "w" : 334
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 334
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 334
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 334
      } ],
      "display_url" : "pic.twitter.com\/4JSoX78bee"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570038936405450752",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/4JSoX78bee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/503580125389398016\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/4JSoX78bee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv0TdLBIcAAY5I_.jpg",
        "id_str" : "503580125230034944",
        "id" : 503580125230034944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv0TdLBIcAAY5I_.jpg",
        "sizes" : [ {
          "h" : 475,
          "resize" : "fit",
          "w" : 334
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 334
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 334
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 334
        } ],
        "display_url" : "pic.twitter.com\/4JSoX78bee"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570037915247611904",
    "text" : "http:\/\/t.co\/4JSoX78bee",
    "id" : 570037915247611904,
    "created_at" : "2015-02-24 01:50:04 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 570038936405450752,
  "created_at" : "2015-02-24 01:54:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570020629161885697",
  "text" : "RT @sarahnmoon: \"By redefining marriage to allow a union between two persons of the same sex...a kind of alchemy is performed\" WHICH IS AWE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570018170532171776",
    "text" : "\"By redefining marriage to allow a union between two persons of the same sex...a kind of alchemy is performed\" WHICH IS AWESOME.",
    "id" : 570018170532171776,
    "created_at" : "2015-02-24 00:31:36 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 570020629161885697,
  "created_at" : "2015-02-24 00:41:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570018170532171776",
  "geo" : { },
  "id_str" : "570020483757948929",
  "in_reply_to_user_id" : 24254537,
  "text" : "RT @sarahnmoon: \"By redefining marriage to allow a union between two persons of the same sex...a kind of alchemy is performed\" (1\/2)",
  "id" : 570020483757948929,
  "in_reply_to_status_id" : 570018170532171776,
  "created_at" : "2015-02-24 00:40:48 +0000",
  "in_reply_to_screen_name" : "GrumpyTheology",
  "in_reply_to_user_id_str" : "24254537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570020484538085376",
  "text" : "WHICH IS AWESOME. (2\/2)",
  "id" : 570020484538085376,
  "created_at" : "2015-02-24 00:40:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael matu",
      "screen_name" : "mycohcloud",
      "indices" : [ 3, 14 ],
      "id_str" : "2816481943",
      "id" : 2816481943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whyilivehere",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "tembeakenya",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569987658304380928",
  "text" : "RT @mycohcloud: Bird watching close and personal helmeted guinea fowl having a great moment .#whyilivehere,#tembeakenya. http:\/\/t.co\/hxN7v4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mycohcloud\/status\/568064368287428608\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/hxN7v4PtkU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-IrguAIUAADjIu.jpg",
        "id_str" : "568064344106487808",
        "id" : 568064344106487808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-IrguAIUAADjIu.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hxN7v4PtkU"
      } ],
      "hashtags" : [ {
        "text" : "whyilivehere",
        "indices" : [ 77, 90 ]
      }, {
        "text" : "tembeakenya",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568064368287428608",
    "text" : "Bird watching close and personal helmeted guinea fowl having a great moment .#whyilivehere,#tembeakenya. http:\/\/t.co\/hxN7v4PtkU",
    "id" : 568064368287428608,
    "created_at" : "2015-02-18 15:07:54 +0000",
    "user" : {
      "name" : "michael matu",
      "screen_name" : "mycohcloud",
      "protected" : false,
      "id_str" : "2816481943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732258261768998912\/g1BebOpM_normal.jpg",
      "id" : 2816481943,
      "verified" : false
    }
  },
  "id" : 569987658304380928,
  "created_at" : "2015-02-23 22:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Munn",
      "screen_name" : "DebbieMunn",
      "indices" : [ 3, 14 ],
      "id_str" : "773478521117274112",
      "id" : 773478521117274112
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birdingnb",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "nbbirds",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "birds",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569986961852788736",
  "text" : "RT @DebbieMunn: The American Tree Sparrows decided to come out of hiding today. Such a sweet bird...  #birdingnb #nbbirds #birds http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DebbieMunn\/status\/565246377031385090\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/mTQxoN3u0D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9golWrIYAAY7H9.jpg",
        "id_str" : "565246375441752064",
        "id" : 565246375441752064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9golWrIYAAY7H9.jpg",
        "sizes" : [ {
          "h" : 839,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1249,
          "resize" : "fit",
          "w" : 893
        }, {
          "h" : 1249,
          "resize" : "fit",
          "w" : 893
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/mTQxoN3u0D"
      } ],
      "hashtags" : [ {
        "text" : "birdingnb",
        "indices" : [ 86, 96 ]
      }, {
        "text" : "nbbirds",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "birds",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565246377031385090",
    "text" : "The American Tree Sparrows decided to come out of hiding today. Such a sweet bird...  #birdingnb #nbbirds #birds http:\/\/t.co\/mTQxoN3u0D",
    "id" : 565246377031385090,
    "created_at" : "2015-02-10 20:30:12 +0000",
    "user" : {
      "name" : "Deb Corey-Munn",
      "screen_name" : "DebCoreyMunn",
      "protected" : false,
      "id_str" : "120597280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728592353372585984\/zcBWBRpq_normal.jpg",
      "id" : 120597280,
      "verified" : false
    }
  },
  "id" : 569986961852788736,
  "created_at" : "2015-02-23 22:27:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bimmerella\uD83D\uDCCE",
      "screen_name" : "bimmerella",
      "indices" : [ 3, 14 ],
      "id_str" : "41984111",
      "id" : 41984111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAFUQ",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569979314109689856",
  "geo" : { },
  "id_str" : "569985755185082368",
  "in_reply_to_user_id" : 41984111,
  "text" : "RT @bimmerella: #DAFUQ???  \nIdaho lawmaker asks if woman can swallow camera for gynecological exam before medical abortion (1\/2)",
  "id" : 569985755185082368,
  "in_reply_to_status_id" : 569979314109689856,
  "created_at" : "2015-02-23 22:22:48 +0000",
  "in_reply_to_screen_name" : "bimmerella",
  "in_reply_to_user_id_str" : "41984111",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vQb9nR1AYx",
      "expanded_url" : "http:\/\/www.startribune.com\/lifestyle\/health\/293718211.html",
      "display_url" : "startribune.com\/lifestyle\/heal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569985756074270720",
  "text" : "http:\/\/t.co\/vQb9nR1AYx (2\/2)",
  "id" : 569985756074270720,
  "created_at" : "2015-02-23 22:22:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMAgulag",
      "screen_name" : "FEMAgulag",
      "indices" : [ 3, 13 ],
      "id_str" : "2612937380",
      "id" : 2612937380
    }, {
      "name" : "ruth takahashi",
      "screen_name" : "ruthtaka",
      "indices" : [ 17, 26 ],
      "id_str" : "629711211",
      "id" : 629711211
    }, {
      "name" : "..",
      "screen_name" : "AbdullahSaylam",
      "indices" : [ 29, 44 ],
      "id_str" : "736085280143200256",
      "id" : 736085280143200256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FEMAgulag\/status\/569984199773577216\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/2OpVejfXe1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-j9m-hCUAAT5tS.jpg",
      "id_str" : "569984198920785920",
      "id" : 569984198920785920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-j9m-hCUAAT5tS.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2OpVejfXe1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569984199773577216",
  "geo" : { },
  "id_str" : "569984998184509440",
  "in_reply_to_user_id" : 2612937380,
  "text" : "RT @FEMAgulag: RT@ruthtaka RT@AbdullahSaylam Meeting Friends. http:\/\/t.co\/2OpVejfXe1",
  "id" : 569984998184509440,
  "in_reply_to_status_id" : 569984199773577216,
  "created_at" : "2015-02-23 22:19:48 +0000",
  "in_reply_to_screen_name" : "FEMAgulag",
  "in_reply_to_user_id_str" : "2612937380",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One-Legged Sandpiper",
      "screen_name" : "OneLegSandpiper",
      "indices" : [ 3, 19 ],
      "id_str" : "81434158",
      "id" : 81434158
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OneLegSandpiper\/status\/569923004953698304\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/cgq54jGMbp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jF7x1CAAAlsy_.jpg",
      "id_str" : "569922983641088000",
      "id" : 569922983641088000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jF7x1CAAAlsy_.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/cgq54jGMbp"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/OneLegSandpiper\/status\/569923004953698304\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/cgq54jGMbp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jF6PeCcAAFXAU.jpg",
      "id_str" : "569922957237972992",
      "id" : 569922957237972992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jF6PeCcAAFXAU.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/cgq54jGMbp"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/OneLegSandpiper\/status\/569923004953698304\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/cgq54jGMbp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jF81yCcAArTzD.jpg",
      "id_str" : "569923001882144768",
      "id" : 569923001882144768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jF81yCcAArTzD.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cgq54jGMbp"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/OneLegSandpiper\/status\/569923004953698304\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/cgq54jGMbp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jF8-UCcAAj3kC.jpg",
      "id_str" : "569923004172234752",
      "id" : 569923004172234752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jF8-UCcAAj3kC.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/cgq54jGMbp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569923004953698304",
  "geo" : { },
  "id_str" : "569948615780777985",
  "in_reply_to_user_id" : 81434158,
  "text" : "RT @OneLegSandpiper: We slowed down for a beautiful female fox that seemed sure we were going to feed her. http:\/\/t.co\/cgq54jGMbp",
  "id" : 569948615780777985,
  "in_reply_to_status_id" : 569923004953698304,
  "created_at" : "2015-02-23 19:55:13 +0000",
  "in_reply_to_screen_name" : "OneLegSandpiper",
  "in_reply_to_user_id_str" : "81434158",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harbinger of meals",
      "screen_name" : "tittenkits",
      "indices" : [ 3, 14 ],
      "id_str" : "1393028870",
      "id" : 1393028870
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tittenkits\/status\/569946164616933376\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/M90yeN5bYK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jbA6SCYAAa7B_.jpg",
      "id_str" : "569946161553760256",
      "id" : 569946161553760256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jbA6SCYAAa7B_.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1004,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 1004,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/M90yeN5bYK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569946164616933376",
  "geo" : { },
  "id_str" : "569948228373893120",
  "in_reply_to_user_id" : 1393028870,
  "text" : "RT @tittenkits: this came from a private account but it needs to be shared. on body positivity: http:\/\/t.co\/M90yeN5bYK",
  "id" : 569948228373893120,
  "in_reply_to_status_id" : 569946164616933376,
  "created_at" : "2015-02-23 19:53:41 +0000",
  "in_reply_to_screen_name" : "tittenkits",
  "in_reply_to_user_id_str" : "1393028870",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569937685638463489",
  "geo" : { },
  "id_str" : "569938401069297664",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides lol.. Not me. It's a RT. This app I'm using RTs funny when long.",
  "id" : 569938401069297664,
  "in_reply_to_status_id" : 569937685638463489,
  "created_at" : "2015-02-23 19:14:38 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natknit",
      "screen_name" : "cloudynatknit",
      "indices" : [ 3, 17 ],
      "id_str" : "209233881",
      "id" : 209233881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569867272438751232",
  "geo" : { },
  "id_str" : "569937376497303552",
  "in_reply_to_user_id" : 209233881,
  "text" : "RT @cloudynatknit: I need to write a beginning to knit book for men. Specifically young men. Need to find young\/old guy knitters (1\/2)",
  "id" : 569937376497303552,
  "in_reply_to_status_id" : 569867272438751232,
  "created_at" : "2015-02-23 19:10:34 +0000",
  "in_reply_to_screen_name" : "cloudynatknit",
  "in_reply_to_user_id_str" : "209233881",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569937377550053378",
  "text" : "who would give input. (2\/2)",
  "id" : 569937377550053378,
  "created_at" : "2015-02-23 19:10:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cri Pitto",
      "screen_name" : "CrawliesWithCri",
      "indices" : [ 3, 19 ],
      "id_str" : "935332760",
      "id" : 935332760
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CrawliesWithCri\/status\/569528572961894401\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QFCvmLkSFA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dfOAgCcAAV_uV.jpg",
      "id_str" : "569528572142841856",
      "id" : 569528572142841856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dfOAgCcAAV_uV.jpg",
      "sizes" : [ {
        "h" : 1668,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 834,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QFCvmLkSFA"
    } ],
    "hashtags" : [ {
      "text" : "StellersJay",
      "indices" : [ 79, 91 ]
    }, {
      "text" : "BeCurious",
      "indices" : [ 92, 102 ]
    }, {
      "text" : "BeKind",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569528572961894401",
  "geo" : { },
  "id_str" : "569933519272722432",
  "in_reply_to_user_id" : 935332760,
  "text" : "RT @CrawliesWithCri: ...and the Oscar for Best Costume Design goes to? Nature! #StellersJay #BeCurious #BeKind http:\/\/t.co\/QFCvmLkSFA",
  "id" : 569933519272722432,
  "in_reply_to_status_id" : 569528572961894401,
  "created_at" : "2015-02-23 18:55:14 +0000",
  "in_reply_to_screen_name" : "CrawliesWithCri",
  "in_reply_to_user_id_str" : "935332760",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.windowsphone.com\/en-us\/apps\/75067abc-c9d1-47b7-8ace-76aede3911b2\" rel=\"nofollow\"\u003EPeregrine\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/569924663125659648\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Ts6h6VU7fE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jHdcVIUAAvR-w.jpg",
      "id_str" : "569924661497319424",
      "id" : 569924661497319424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jHdcVIUAAvR-w.jpg",
      "sizes" : [ {
        "h" : 443,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 570
      } ],
      "display_url" : "pic.twitter.com\/Ts6h6VU7fE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569925807507972100",
  "text" : "RT @jacqueduncalf: \"It's a fine spread you've but on ere Ned\"\"nothing but the best for my friends Pinky\" http:\/\/t.co\/Ts6h6VU7fE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/569924663125659648\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Ts6h6VU7fE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jHdcVIUAAvR-w.jpg",
        "id_str" : "569924661497319424",
        "id" : 569924661497319424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jHdcVIUAAvR-w.jpg",
        "sizes" : [ {
          "h" : 443,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 570
        } ],
        "display_url" : "pic.twitter.com\/Ts6h6VU7fE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569924663125659648",
    "text" : "\"It's a fine spread you've but on ere Ned\"\"nothing but the best for my friends Pinky\" http:\/\/t.co\/Ts6h6VU7fE",
    "id" : 569924663125659648,
    "created_at" : "2015-02-23 18:20:03 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 569925807507972100,
  "created_at" : "2015-02-23 18:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PoetsLoveBirds\/status\/569919681714380800\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/0qikegQH95",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jC7iPIIAAMrLq.jpg",
      "id_str" : "569919680920690688",
      "id" : 569919680920690688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jC7iPIIAAMrLq.jpg",
      "sizes" : [ {
        "h" : 1085,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0qikegQH95"
    } ],
    "hashtags" : [ {
      "text" : "BirdBuffet",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569922037650747392",
  "text" : "#BirdBuffet http:\/\/t.co\/0qikegQH95 (2\/2)",
  "id" : 569922037650747392,
  "created_at" : "2015-02-23 18:09:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 3, 18 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrel",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569919681714380800",
  "geo" : { },
  "id_str" : "569922035822043137",
  "in_reply_to_user_id" : 818814906,
  "text" : "RT @PoetsLoveBirds: He finally figured it out. No longer content with peanuts on the ground, he prefers a table. #squirrel (1\/2)",
  "id" : 569922035822043137,
  "in_reply_to_status_id" : 569919681714380800,
  "created_at" : "2015-02-23 18:09:36 +0000",
  "in_reply_to_screen_name" : "PoetsLoveBirds",
  "in_reply_to_user_id_str" : "818814906",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "indices" : [ 13, 28 ],
      "id_str" : "1972360812",
      "id" : 1972360812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569909656363139072",
  "geo" : { },
  "id_str" : "569921723535130624",
  "in_reply_to_user_id" : 1972360812,
  "text" : "@ErinEFarley @CityStitchette lovely colors!",
  "id" : 569921723535130624,
  "in_reply_to_status_id" : 569909656363139072,
  "created_at" : "2015-02-23 18:08:22 +0000",
  "in_reply_to_screen_name" : "CityStitchette",
  "in_reply_to_user_id_str" : "1972360812",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enesco Limited",
      "screen_name" : "EnescoLimited",
      "indices" : [ 22, 36 ],
      "id_str" : "377281546",
      "id" : 377281546
    }, {
      "name" : "Highland Cow Society",
      "screen_name" : "highlandsociety",
      "indices" : [ 38, 54 ],
      "id_str" : "463889444",
      "id" : 463889444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/q8uE529w6O",
      "expanded_url" : "http:\/\/www.enesco.co.uk\/our_collections\/hairy_coos\/",
      "display_url" : "enesco.co.uk\/our_collection\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569898618162954241",
  "geo" : { },
  "id_str" : "569919480542990337",
  "in_reply_to_user_id" : 3019569893,
  "text" : "RT @cullcowregister: \u201C@EnescoLimited: @highlandsociety New for 2015 ... available 5th March :) http:\/\/t.co\/q8uE529w6O (1\/2)",
  "id" : 569919480542990337,
  "in_reply_to_status_id" : 569898618162954241,
  "created_at" : "2015-02-23 17:59:27 +0000",
  "in_reply_to_screen_name" : "livestockvision",
  "in_reply_to_user_id_str" : "3019569893",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EnescoLimited\/status\/569890433985323008\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2nM6pOSMIU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ioUw2IIAAyhIw.jpg",
      "id_str" : "569890427525144576",
      "id" : 569890427525144576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ioUw2IIAAyhIw.jpg",
      "sizes" : [ {
        "h" : 279,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1680,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/2nM6pOSMIU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EnescoLimited\/status\/569890433985323008\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2nM6pOSMIU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ioU_NIcAAvhWA.jpg",
      "id_str" : "569890431379730432",
      "id" : 569890431379730432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ioU_NIcAAvhWA.jpg",
      "sizes" : [ {
        "h" : 1753,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2nM6pOSMIU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EnescoLimited\/status\/569890433985323008\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2nM6pOSMIU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ioVDaIQAAG5_6.jpg",
      "id_str" : "569890432507985920",
      "id" : 569890432507985920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ioVDaIQAAG5_6.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2nM6pOSMIU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EnescoLimited\/status\/569890433985323008\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2nM6pOSMIU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ioVEsIQAAjcUF.jpg",
      "id_str" : "569890432851918848",
      "id" : 569890432851918848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ioVEsIQAAjcUF.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2nM6pOSMIU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569919481352486912",
  "text" : "http:\/\/t.co\/2nM6pOSMIU\u201D\nCUTE! (2\/2)",
  "id" : 569919481352486912,
  "created_at" : "2015-02-23 17:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "indices" : [ 3, 18 ],
      "id_str" : "25056239",
      "id" : 25056239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dumpGMOs",
      "indices" : [ 105, 114 ]
    }, {
      "text" : "realfoodsells",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/E6itk1qz5C",
      "expanded_url" : "http:\/\/www.confectionerynews.com\/Ingredients\/Hershey-in-non-GMO-and-no-high-fructose-corn-syrup-pledge?utm_source=AddThis_twitter&utm_medium=twitter&utm_campaign=SocialMedia#.VOtmqQhAt78.twitter",
      "display_url" : "confectionerynews.com\/Ingredients\/He\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569915449439166464",
  "geo" : { },
  "id_str" : "569919056893095938",
  "in_reply_to_user_id" : 25056239,
  "text" : "RT @foodawakenings: HUGE NEWS!  Hershey's Milk Chocolate and Kisses to go non-GMO http:\/\/t.co\/E6itk1qz5C #dumpGMOs #realfoodsells",
  "id" : 569919056893095938,
  "in_reply_to_status_id" : 569915449439166464,
  "created_at" : "2015-02-23 17:57:46 +0000",
  "in_reply_to_screen_name" : "foodawakenings",
  "in_reply_to_user_id_str" : "25056239",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/MFuEb8oX1l",
      "expanded_url" : "https:\/\/twitter.com\/thesirenofangel\/status\/569908955570446337\/photo\/1",
      "display_url" : "pic.twitter.com\/MFuEb8oX1l"
    } ]
  },
  "geo" : { },
  "id_str" : "569918260122152960",
  "text" : "RT @thesirenofangel: http:\/\/t.co\/MFuEb8oX1l",
  "id" : 569918260122152960,
  "created_at" : "2015-02-23 17:54:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/5xI4mtrR7P",
      "expanded_url" : "http:\/\/fb.me\/2y1kEpquV",
      "display_url" : "fb.me\/2y1kEpquV"
    } ]
  },
  "geo" : { },
  "id_str" : "569917663734075392",
  "text" : "do.... http:\/\/t.co\/5xI4mtrR7P (2\/2)",
  "id" : 569917663734075392,
  "created_at" : "2015-02-23 17:52:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wallace 'J' Nichols",
      "screen_name" : "wallacejnichols",
      "indices" : [ 3, 19 ],
      "id_str" : "15575625",
      "id" : 15575625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569884542129086464",
  "geo" : { },
  "id_str" : "569917662375100417",
  "in_reply_to_user_id" : 15575625,
  "text" : "RT @wallacejnichols: \"I would like for this moment to be for that kid out there who feels like she doesn\u2019t fit in anywhere. You (1\/2)",
  "id" : 569917662375100417,
  "in_reply_to_status_id" : 569884542129086464,
  "created_at" : "2015-02-23 17:52:13 +0000",
  "in_reply_to_screen_name" : "wallacejnichols",
  "in_reply_to_user_id_str" : "15575625",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 3, 14 ],
      "id_str" : "76225852",
      "id" : 76225852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/eHkAej5f0F",
      "expanded_url" : "http:\/\/fb.me\/3Fl7aABZv",
      "display_url" : "fb.me\/3Fl7aABZv"
    } ]
  },
  "geo" : { },
  "id_str" : "569909752802754560",
  "text" : "RT @TraLeeFitz: The United States of War. http:\/\/t.co\/eHkAej5f0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/eHkAej5f0F",
        "expanded_url" : "http:\/\/fb.me\/3Fl7aABZv",
        "display_url" : "fb.me\/3Fl7aABZv"
      } ]
    },
    "geo" : { },
    "id_str" : "569707363034398721",
    "text" : "The United States of War. http:\/\/t.co\/eHkAej5f0F",
    "id" : 569707363034398721,
    "created_at" : "2015-02-23 03:56:34 +0000",
    "user" : {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "protected" : false,
      "id_str" : "76225852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798982593702023168\/XfVHvWY7_normal.jpg",
      "id" : 76225852,
      "verified" : false
    }
  },
  "id" : 569909752802754560,
  "created_at" : "2015-02-23 17:20:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568945831295864833",
  "geo" : { },
  "id_str" : "569875377071493120",
  "in_reply_to_user_id" : 1348108910,
  "text" : "RT @ScarlettWulf: She is such a Beautiful Girl. Recognizes my call and comes. Here asking for more Apples after this mornings feed. (1\/2)",
  "id" : 569875377071493120,
  "in_reply_to_status_id" : 568945831295864833,
  "created_at" : "2015-02-23 15:04:12 +0000",
  "in_reply_to_screen_name" : "ScarlettWulf",
  "in_reply_to_user_id_str" : "1348108910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/568945831295864833\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/oRRrMLqJmc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-VNNWBCQAAcb-_.jpg",
      "id_str" : "568945819575795712",
      "id" : 568945819575795712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-VNNWBCQAAcb-_.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oRRrMLqJmc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569875377931337730",
  "text" : "http:\/\/t.co\/oRRrMLqJmc (2\/2)",
  "id" : 569875377931337730,
  "created_at" : "2015-02-23 15:04:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/569671342192242688\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/NnrxpiSPrL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-fhDwMCMAA7zm6.jpg",
      "id_str" : "569671332476891136",
      "id" : 569671332476891136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-fhDwMCMAA7zm6.jpg",
      "sizes" : [ {
        "h" : 697,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 882
      } ],
      "display_url" : "pic.twitter.com\/NnrxpiSPrL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569671342192242688",
  "geo" : { },
  "id_str" : "569675562442207232",
  "in_reply_to_user_id" : 1305052615,
  "text" : "RT @ErinEFarley: Totally looking like a bear now. A freaky alien faceless bear... http:\/\/t.co\/NnrxpiSPrL",
  "id" : 569675562442207232,
  "in_reply_to_status_id" : 569671342192242688,
  "created_at" : "2015-02-23 01:50:12 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 107, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569674177445298176",
  "text" : "RT @JimBrownBooks: I don't understand why people need to do drugs to have fun.  Have they never had pizza? #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 88, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569673072317468672",
    "text" : "I don't understand why people need to do drugs to have fun.  Have they never had pizza? #fb",
    "id" : 569673072317468672,
    "created_at" : "2015-02-23 01:40:19 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 569674177445298176,
  "created_at" : "2015-02-23 01:44:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.dreamdevelopment.be\" rel=\"nofollow\"\u003EMeTweets for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/569576103226052608\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/qNFdyCMTNQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-eKcIXIQAAqbLO.jpg",
      "id_str" : "569576093771120640",
      "id" : 569576093771120640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-eKcIXIQAAqbLO.jpg",
      "sizes" : [ {
        "h" : 517,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 421
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 421
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 421
      } ],
      "display_url" : "pic.twitter.com\/qNFdyCMTNQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569576103226052608",
  "geo" : { },
  "id_str" : "569577553465376768",
  "in_reply_to_user_id" : 1316959200,
  "text" : "RT @zacaplus: http:\/\/t.co\/qNFdyCMTNQ",
  "id" : 569577553465376768,
  "in_reply_to_status_id" : 569576103226052608,
  "created_at" : "2015-02-22 19:20:45 +0000",
  "in_reply_to_screen_name" : "zacaplus",
  "in_reply_to_user_id_str" : "1316959200",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569513685003198464",
  "text" : "RT @CoyoteSings: Oh, and by the way, everybody's got a little crazy in 'em. We all do something that makes absolutely no sense except to us\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "truth",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569513106138750976",
    "text" : "Oh, and by the way, everybody's got a little crazy in 'em. We all do something that makes absolutely no sense except to us. #truth",
    "id" : 569513106138750976,
    "created_at" : "2015-02-22 15:04:40 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 569513685003198464,
  "created_at" : "2015-02-22 15:06:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 3, 19 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/569513321403174912\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/pqzbkz3D8h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dRJ4yIcAAI_f_.jpg",
      "id_str" : "569513108188983296",
      "id" : 569513108188983296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dRJ4yIcAAI_f_.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pqzbkz3D8h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569513620100554752",
  "text" : "RT @hilltopfarmgirl: A couple of beltie bullocks enjoy a bite of silo on a murky day. http:\/\/t.co\/pqzbkz3D8h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/569513321403174912\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/pqzbkz3D8h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dRJ4yIcAAI_f_.jpg",
        "id_str" : "569513108188983296",
        "id" : 569513108188983296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dRJ4yIcAAI_f_.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pqzbkz3D8h"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569513321403174912",
    "text" : "A couple of beltie bullocks enjoy a bite of silo on a murky day. http:\/\/t.co\/pqzbkz3D8h",
    "id" : 569513321403174912,
    "created_at" : "2015-02-22 15:05:31 +0000",
    "user" : {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "protected" : false,
      "id_str" : "457436503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3491566457\/61244b7682c638ad4b0a097321ae762e_normal.jpeg",
      "id" : 457436503,
      "verified" : false
    }
  },
  "id" : 569513620100554752,
  "created_at" : "2015-02-22 15:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/569503828678197251\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/9pC71OFMX3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dItqgIMAA8dy2.jpg",
      "id_str" : "569503827226013696",
      "id" : 569503827226013696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dItqgIMAA8dy2.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9pC71OFMX3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569509246833991680",
  "text" : "RT @zacaplus: http:\/\/t.co\/9pC71OFMX3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/569503828678197251\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/9pC71OFMX3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-dItqgIMAA8dy2.jpg",
        "id_str" : "569503827226013696",
        "id" : 569503827226013696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-dItqgIMAA8dy2.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9pC71OFMX3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569503828678197251",
    "text" : "http:\/\/t.co\/9pC71OFMX3",
    "id" : 569503828678197251,
    "created_at" : "2015-02-22 14:27:48 +0000",
    "user" : {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "protected" : false,
      "id_str" : "1316959200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711110597593702400\/FL6-Tb30_normal.jpg",
      "id" : 1316959200,
      "verified" : false
    }
  },
  "id" : 569509246833991680,
  "created_at" : "2015-02-22 14:49:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helaine Olen",
      "screen_name" : "helaineolen",
      "indices" : [ 3, 15 ],
      "id_str" : "54731136",
      "id" : 54731136
    }, {
      "name" : "Susan G. Komen",
      "screen_name" : "SusanGKomen",
      "indices" : [ 111, 123 ],
      "id_str" : "16244789",
      "id" : 16244789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569319878324301824",
  "text" : "RT @helaineolen: In her final piece Laurie Becklund urges us to use Big Data to take on cancer. And she kicked @SusanGKomen --hard. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan G. Komen",
        "screen_name" : "SusanGKomen",
        "indices" : [ 94, 106 ],
        "id_str" : "16244789",
        "id" : 16244789
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/fEzl5pibAL",
        "expanded_url" : "http:\/\/www.latimes.com\/opinion\/op-ed\/la-oe-becklund-breast-cancer-komen-20150222-story.html#page=1",
        "display_url" : "latimes.com\/opinion\/op-ed\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569259202046251008",
    "text" : "In her final piece Laurie Becklund urges us to use Big Data to take on cancer. And she kicked @SusanGKomen --hard. http:\/\/t.co\/fEzl5pibAL",
    "id" : 569259202046251008,
    "created_at" : "2015-02-21 22:15:44 +0000",
    "user" : {
      "name" : "Helaine Olen",
      "screen_name" : "helaineolen",
      "protected" : false,
      "id_str" : "54731136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738548002034421760\/zU2NBmt__normal.jpg",
      "id" : 54731136,
      "verified" : true
    }
  },
  "id" : 569319878324301824,
  "created_at" : "2015-02-22 02:16:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 3, 16 ],
      "id_str" : "256540769",
      "id" : 256540769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/3OswgwVCEf",
      "expanded_url" : "http:\/\/bzfd.it\/1EdPCtd",
      "display_url" : "bzfd.it\/1EdPCtd"
    } ]
  },
  "geo" : { },
  "id_str" : "569317793390317568",
  "text" : "RT @HarryShannon: Via BuzzFeed Fostering Profits: Death, Sex Abuse At The Largest For-Profit Foster Care In U.S. http:\/\/t.co\/3OswgwVCEf htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/569308907253792769\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/E4dvB6yrKE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Yux6TIYAAu3AD.png",
        "id_str" : "569193837906911232",
        "id" : 569193837906911232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Yux6TIYAAu3AD.png",
        "sizes" : [ {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 676
        } ],
        "display_url" : "pic.twitter.com\/E4dvB6yrKE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/3OswgwVCEf",
        "expanded_url" : "http:\/\/bzfd.it\/1EdPCtd",
        "display_url" : "bzfd.it\/1EdPCtd"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.19654605913367, -118.4249370173723 ]
    },
    "id_str" : "569310386375168000",
    "text" : "Via BuzzFeed Fostering Profits: Death, Sex Abuse At The Largest For-Profit Foster Care In U.S. http:\/\/t.co\/3OswgwVCEf http:\/\/t.co\/E4dvB6yrKE",
    "id" : 569310386375168000,
    "created_at" : "2015-02-22 01:39:08 +0000",
    "user" : {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "protected" : false,
      "id_str" : "256540769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798645625289965568\/8ai82ECm_normal.jpg",
      "id" : 256540769,
      "verified" : false
    }
  },
  "id" : 569317793390317568,
  "created_at" : "2015-02-22 02:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Scott",
      "screen_name" : "DScottwrites",
      "indices" : [ 3, 16 ],
      "id_str" : "2458051544",
      "id" : 2458051544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569300011135180802",
  "text" : "RT @DScottwrites: \"Be a lamp, or a lifeboat, or a ladder. \nHelp someone's soul heal. \nWalk out of your house like a shepherd.\"\n-Rumi http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DScottwrites\/status\/569297955745873920\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/eCOfJ8fwQm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-aNeU5CAAA_S9r.png",
        "id_str" : "569297955052453888",
        "id" : 569297955052453888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-aNeU5CAAA_S9r.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eCOfJ8fwQm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569297955745873920",
    "text" : "\"Be a lamp, or a lifeboat, or a ladder. \nHelp someone's soul heal. \nWalk out of your house like a shepherd.\"\n-Rumi http:\/\/t.co\/eCOfJ8fwQm",
    "id" : 569297955745873920,
    "created_at" : "2015-02-22 00:49:44 +0000",
    "user" : {
      "name" : "David Scott",
      "screen_name" : "DScottwrites",
      "protected" : false,
      "id_str" : "2458051544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624806581863976960\/a6Lu6bET_normal.jpg",
      "id" : 2458051544,
      "verified" : false
    }
  },
  "id" : 569300011135180802,
  "created_at" : "2015-02-22 00:57:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nichols",
      "screen_name" : "NicholsUprising",
      "indices" : [ 3, 19 ],
      "id_str" : "466519303",
      "id" : 466519303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569245715974791168",
  "text" : "RT @NicholsUprising: National Review: \"Walker believes his stance against unions in WI would be a signal of toughness to Islamic jihadists \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569243017258905601",
    "text" : "National Review: \"Walker believes his stance against unions in WI would be a signal of toughness to Islamic jihadists (and) Vladimir Putin.\"",
    "id" : 569243017258905601,
    "created_at" : "2015-02-21 21:11:25 +0000",
    "user" : {
      "name" : "John Nichols",
      "screen_name" : "NicholsUprising",
      "protected" : false,
      "id_str" : "466519303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441901473299853312\/KQn3SLti_normal.jpeg",
      "id" : 466519303,
      "verified" : false
    }
  },
  "id" : 569245715974791168,
  "created_at" : "2015-02-21 21:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 3, 18 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Courtship",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "HGTVDreamHome",
      "indices" : [ 88, 102 ]
    }, {
      "text" : "birds",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Mg78WbpT2n",
      "expanded_url" : "http:\/\/www.poetslovebirds.com\/lightkeepersjournal\/2015\/02\/eastern-bluebird-courtship.html",
      "display_url" : "poetslovebirds.com\/lightkeepersjo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569224082891382785",
  "text" : "RT @PoetsLoveBirds: Eastern Bluebird #Courtship Story\n....including photos of their new #HGTVDreamHome.\nhttp:\/\/t.co\/Mg78WbpT2n\n#birds #bird\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Courtship",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "HGTVDreamHome",
        "indices" : [ 68, 82 ]
      }, {
        "text" : "birds",
        "indices" : [ 107, 113 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 114, 127 ]
      }, {
        "text" : "RealEstate",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/Mg78WbpT2n",
        "expanded_url" : "http:\/\/www.poetslovebirds.com\/lightkeepersjournal\/2015\/02\/eastern-bluebird-courtship.html",
        "display_url" : "poetslovebirds.com\/lightkeepersjo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569223563309400065",
    "text" : "Eastern Bluebird #Courtship Story\n....including photos of their new #HGTVDreamHome.\nhttp:\/\/t.co\/Mg78WbpT2n\n#birds #birdwatching #RealEstate",
    "id" : 569223563309400065,
    "created_at" : "2015-02-21 19:54:07 +0000",
    "user" : {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "protected" : false,
      "id_str" : "818814906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153554844\/2f757111dc3eedb25debd1db4e264f85_normal.jpeg",
      "id" : 818814906,
      "verified" : false
    }
  },
  "id" : 569224082891382785,
  "created_at" : "2015-02-21 19:56:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExploreAmazing",
      "screen_name" : "ExploreAmazing_",
      "indices" : [ 3, 19 ],
      "id_str" : "2847566643",
      "id" : 2847566643
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ExploreAmazing_\/status\/568967728683286529\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/yjShtbHwF5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-VhIC8CMAANOml.jpg",
      "id_str" : "568967718787756032",
      "id" : 568967718787756032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-VhIC8CMAANOml.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/yjShtbHwF5"
    } ],
    "hashtags" : [ {
      "text" : "Wildlife",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "ExploreAmazing",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569161049057992705",
  "text" : "RT @ExploreAmazing_: I fit in perfectly! \uD83D\uDC4C #Wildlife #ExploreAmazing http:\/\/t.co\/yjShtbHwF5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ExploreAmazing_\/status\/568967728683286529\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/yjShtbHwF5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-VhIC8CMAANOml.jpg",
        "id_str" : "568967718787756032",
        "id" : 568967718787756032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-VhIC8CMAANOml.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/yjShtbHwF5"
      } ],
      "hashtags" : [ {
        "text" : "Wildlife",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "ExploreAmazing",
        "indices" : [ 32, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568967728683286529",
    "text" : "I fit in perfectly! \uD83D\uDC4C #Wildlife #ExploreAmazing http:\/\/t.co\/yjShtbHwF5",
    "id" : 568967728683286529,
    "created_at" : "2015-02-21 02:57:32 +0000",
    "user" : {
      "name" : "ExploreAmazing",
      "screen_name" : "ExploreAmazing_",
      "protected" : false,
      "id_str" : "2847566643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551133582912012289\/PPUYTO3-_normal.jpeg",
      "id" : 2847566643,
      "verified" : false
    }
  },
  "id" : 569161049057992705,
  "created_at" : "2015-02-21 15:45:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki NB Miner Bill",
      "screen_name" : "BoaterNikki",
      "indices" : [ 3, 15 ],
      "id_str" : "636266522",
      "id" : 636266522
    }, {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 76, 90 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/567335045699211264\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mfEndVK9jB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-ULEXIgAA7Mrm.jpg",
      "id_str" : "567334995942211584",
      "id" : 567334995942211584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-ULEXIgAA7Mrm.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mfEndVK9jB"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/567335045699211264\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mfEndVK9jB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-UMOUIgAAydoA.jpg",
      "id_str" : "567335015793852416",
      "id" : 567335015793852416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-UMOUIgAAydoA.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 854,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 854,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mfEndVK9jB"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/567335045699211264\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mfEndVK9jB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-UNarIQAAcDlG.jpg",
      "id_str" : "567335036291399680",
      "id" : 567335036291399680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-UNarIQAAcDlG.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 958,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 958,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mfEndVK9jB"
    } ],
    "hashtags" : [ {
      "text" : "AshbyCanal",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569160608815448065",
  "text" : "RT @BoaterNikki: This mornings visitors.. Hope your all having a good day! \n@Swanwhisperer Stoke Golding #AshbyCanal http:\/\/t.co\/mfEndVK9jB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 59, 73 ],
        "id_str" : "272369448",
        "id" : 272369448
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/567335045699211264\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/mfEndVK9jB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-ULEXIgAA7Mrm.jpg",
        "id_str" : "567334995942211584",
        "id" : 567334995942211584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-ULEXIgAA7Mrm.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mfEndVK9jB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/567335045699211264\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/mfEndVK9jB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-UMOUIgAAydoA.jpg",
        "id_str" : "567335015793852416",
        "id" : 567335015793852416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-UMOUIgAAydoA.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 854,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 854,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mfEndVK9jB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/567335045699211264\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/mfEndVK9jB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-UNarIQAAcDlG.jpg",
        "id_str" : "567335036291399680",
        "id" : 567335036291399680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-UNarIQAAcDlG.jpg",
        "sizes" : [ {
          "h" : 561,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 958,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 958,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mfEndVK9jB"
      } ],
      "hashtags" : [ {
        "text" : "AshbyCanal",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567335045699211264",
    "text" : "This mornings visitors.. Hope your all having a good day! \n@Swanwhisperer Stoke Golding #AshbyCanal http:\/\/t.co\/mfEndVK9jB",
    "id" : 567335045699211264,
    "created_at" : "2015-02-16 14:49:50 +0000",
    "user" : {
      "name" : "Nikki NB Miner Bill",
      "screen_name" : "BoaterNikki",
      "protected" : false,
      "id_str" : "636266522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741687568840982529\/gMJEotN6_normal.jpg",
      "id" : 636266522,
      "verified" : false
    }
  },
  "id" : 569160608815448065,
  "created_at" : "2015-02-21 15:43:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "indices" : [ 3, 13 ],
      "id_str" : "1244239765",
      "id" : 1244239765
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/569091535389790208\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/3dEL5WncpW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-XRvFwIEAA4oia.jpg",
      "id_str" : "569091534860324864",
      "id" : 569091534860324864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-XRvFwIEAA4oia.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3dEL5WncpW"
    } ],
    "hashtags" : [ {
      "text" : "ellesmere",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "mere",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "geese",
      "indices" : [ 32, 38 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "nature",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569150596407808000",
  "text" : "RT @Siberia61: #ellesmere #mere #geese #wildlife #nature http:\/\/t.co\/3dEL5WncpW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/569091535389790208\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/3dEL5WncpW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-XRvFwIEAA4oia.jpg",
        "id_str" : "569091534860324864",
        "id" : 569091534860324864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-XRvFwIEAA4oia.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3dEL5WncpW"
      } ],
      "hashtags" : [ {
        "text" : "ellesmere",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "mere",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "geese",
        "indices" : [ 17, 23 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 24, 33 ]
      }, {
        "text" : "nature",
        "indices" : [ 34, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569091535389790208",
    "text" : "#ellesmere #mere #geese #wildlife #nature http:\/\/t.co\/3dEL5WncpW",
    "id" : 569091535389790208,
    "created_at" : "2015-02-21 11:09:29 +0000",
    "user" : {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "protected" : false,
      "id_str" : "1244239765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667649979863969792\/DP8gQLi6_normal.jpg",
      "id" : 1244239765,
      "verified" : false
    }
  },
  "id" : 569150596407808000,
  "created_at" : "2015-02-21 15:04:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Quirke",
      "screen_name" : "patquirke",
      "indices" : [ 3, 13 ],
      "id_str" : "20155325",
      "id" : 20155325
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/569066904410845184\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OVEFhbYtzV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-W7UK-IEAARLfY.jpg",
      "id_str" : "569066883148943360",
      "id" : 569066883148943360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-W7UK-IEAARLfY.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OVEFhbYtzV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/569066904410845184\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OVEFhbYtzV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-W7ULZIIAAEqKA.jpg",
      "id_str" : "569066883262193664",
      "id" : 569066883262193664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-W7ULZIIAAEqKA.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OVEFhbYtzV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569149663540088832",
  "text" : "RT @patquirke: Found Percy asleep in the hay feeder, while Kitty basked in the sun, admiring the view:) http:\/\/t.co\/OVEFhbYtzV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/569066904410845184\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/OVEFhbYtzV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-W7UK-IEAARLfY.jpg",
        "id_str" : "569066883148943360",
        "id" : 569066883148943360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-W7UK-IEAARLfY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OVEFhbYtzV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/569066904410845184\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/OVEFhbYtzV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-W7ULZIIAAEqKA.jpg",
        "id_str" : "569066883262193664",
        "id" : 569066883262193664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-W7ULZIIAAEqKA.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OVEFhbYtzV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569066904410845184",
    "text" : "Found Percy asleep in the hay feeder, while Kitty basked in the sun, admiring the view:) http:\/\/t.co\/OVEFhbYtzV",
    "id" : 569066904410845184,
    "created_at" : "2015-02-21 09:31:37 +0000",
    "user" : {
      "name" : "Pat Quirke",
      "screen_name" : "patquirke",
      "protected" : false,
      "id_str" : "20155325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2298721913\/jbjszykzpkp3kc1egu0v_normal.jpeg",
      "id" : 20155325,
      "verified" : false
    }
  },
  "id" : 569149663540088832,
  "created_at" : "2015-02-21 15:00:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Madame of Content",
      "screen_name" : "brokepimpstyles",
      "indices" : [ 17, 33 ],
      "id_str" : "29674668",
      "id" : 29674668
    }, {
      "name" : "Earth Pics",
      "screen_name" : "Earthlmages",
      "indices" : [ 36, 48 ],
      "id_str" : "153629442",
      "id" : 153629442
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Earthlmages\/status\/568922301737111553\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/E9TInYuxXA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-U30bEIgAAy5Kp.jpg",
      "id_str" : "568922301690052608",
      "id" : 568922301690052608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-U30bEIgAAy5Kp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E9TInYuxXA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568946298021416960",
  "text" : "RT @gemswinc: RT @brokepimpstyles: \"@Earthlmages: Baby Reindeer http:\/\/t.co\/E9TInYuxXA\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Madame of Content",
        "screen_name" : "brokepimpstyles",
        "indices" : [ 3, 19 ],
        "id_str" : "29674668",
        "id" : 29674668
      }, {
        "name" : "Earth Pics",
        "screen_name" : "Earthlmages",
        "indices" : [ 22, 34 ],
        "id_str" : "153629442",
        "id" : 153629442
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Earthlmages\/status\/568922301737111553\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/E9TInYuxXA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-U30bEIgAAy5Kp.jpg",
        "id_str" : "568922301690052608",
        "id" : 568922301690052608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-U30bEIgAAy5Kp.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/E9TInYuxXA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568944834456752128",
    "text" : "RT @brokepimpstyles: \"@Earthlmages: Baby Reindeer http:\/\/t.co\/E9TInYuxXA\"",
    "id" : 568944834456752128,
    "created_at" : "2015-02-21 01:26:33 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 568946298021416960,
  "created_at" : "2015-02-21 01:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil A. Buster",
      "screen_name" : "onekade",
      "indices" : [ 3, 11 ],
      "id_str" : "15982292",
      "id" : 15982292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568883728736493568",
  "text" : "RT @onekade: 90% of criminal cases plead out. If more people rejected plea deals the judicial system would grind to a halt. http:\/\/t.co\/2uc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/2ucZ4fRpGx",
        "expanded_url" : "http:\/\/www.handsupunited.org\/blog\/2015\/2\/11\/go-to-trial-crash-the-justice-system-by-michelle-alexander",
        "display_url" : "handsupunited.org\/blog\/2015\/2\/11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568787741703417856",
    "text" : "90% of criminal cases plead out. If more people rejected plea deals the judicial system would grind to a halt. http:\/\/t.co\/2ucZ4fRpGx",
    "id" : 568787741703417856,
    "created_at" : "2015-02-20 15:02:19 +0000",
    "user" : {
      "name" : "Phil A. Buster",
      "screen_name" : "onekade",
      "protected" : false,
      "id_str" : "15982292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799292623307632640\/w8u2JKYW_normal.jpg",
      "id" : 15982292,
      "verified" : false
    }
  },
  "id" : 568883728736493568,
  "created_at" : "2015-02-20 21:23:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil A. Buster",
      "screen_name" : "onekade",
      "indices" : [ 3, 11 ],
      "id_str" : "15982292",
      "id" : 15982292
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/onekade\/status\/568787911417548800\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/7DMHBwgHxL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-S9kU9CYAAXj4o.jpg",
      "id_str" : "568787884753182720",
      "id" : 568787884753182720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-S9kU9CYAAXj4o.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/7DMHBwgHxL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568883707228114944",
  "text" : "RT @onekade: Disturbing http:\/\/t.co\/7DMHBwgHxL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/onekade\/status\/568787911417548800\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/7DMHBwgHxL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-S9kU9CYAAXj4o.jpg",
        "id_str" : "568787884753182720",
        "id" : 568787884753182720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-S9kU9CYAAXj4o.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/7DMHBwgHxL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "568787741703417856",
    "geo" : { },
    "id_str" : "568787911417548800",
    "in_reply_to_user_id" : 15982292,
    "text" : "Disturbing http:\/\/t.co\/7DMHBwgHxL",
    "id" : 568787911417548800,
    "in_reply_to_status_id" : 568787741703417856,
    "created_at" : "2015-02-20 15:03:00 +0000",
    "in_reply_to_screen_name" : "onekade",
    "in_reply_to_user_id_str" : "15982292",
    "user" : {
      "name" : "Phil A. Buster",
      "screen_name" : "onekade",
      "protected" : false,
      "id_str" : "15982292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799292623307632640\/w8u2JKYW_normal.jpg",
      "id" : 15982292,
      "verified" : false
    }
  },
  "id" : 568883707228114944,
  "created_at" : "2015-02-20 21:23:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 3, 18 ],
      "id_str" : "582993732",
      "id" : 582993732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/E5QTzHClRT",
      "expanded_url" : "http:\/\/buff.ly\/1AsesCU",
      "display_url" : "buff.ly\/1AsesCU"
    } ]
  },
  "geo" : { },
  "id_str" : "568830016273952769",
  "text" : "RT @DefendTheSheep: \"What is the church\u2019s response to Christians who are married to unbelievers?\" http:\/\/t.co\/E5QTzHClRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/E5QTzHClRT",
        "expanded_url" : "http:\/\/buff.ly\/1AsesCU",
        "display_url" : "buff.ly\/1AsesCU"
      } ]
    },
    "geo" : { },
    "id_str" : "568824781010837504",
    "text" : "\"What is the church\u2019s response to Christians who are married to unbelievers?\" http:\/\/t.co\/E5QTzHClRT",
    "id" : 568824781010837504,
    "created_at" : "2015-02-20 17:29:30 +0000",
    "user" : {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "protected" : false,
      "id_str" : "582993732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719282831931781120\/BB0VrKyw_normal.jpg",
      "id" : 582993732,
      "verified" : false
    }
  },
  "id" : 568830016273952769,
  "created_at" : "2015-02-20 17:50:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Look at Nature",
      "screen_name" : "ALookatNature",
      "indices" : [ 3, 17 ],
      "id_str" : "2955602219",
      "id" : 2955602219
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GBBC",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/no91PGG450",
      "expanded_url" : "http:\/\/gbbc.birdcount.org\/",
      "display_url" : "gbbc.birdcount.org"
    } ]
  },
  "geo" : { },
  "id_str" : "568828741054566400",
  "text" : "RT @ALookatNature: Last day4 the Great Backyard Bird Count. Be citizen scientist &amp; submit sightings here http:\/\/t.co\/no91PGG450 #GBBC http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ALookatNature\/status\/567311404743819264\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/BMgkR3HFS4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B99-t1cCMAAEBY2.jpg",
        "id_str" : "567311403975847936",
        "id" : 567311403975847936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B99-t1cCMAAEBY2.jpg",
        "sizes" : [ {
          "h" : 354,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BMgkR3HFS4"
      } ],
      "hashtags" : [ {
        "text" : "GBBC",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/no91PGG450",
        "expanded_url" : "http:\/\/gbbc.birdcount.org\/",
        "display_url" : "gbbc.birdcount.org"
      } ]
    },
    "geo" : { },
    "id_str" : "567311404743819264",
    "text" : "Last day4 the Great Backyard Bird Count. Be citizen scientist &amp; submit sightings here http:\/\/t.co\/no91PGG450 #GBBC http:\/\/t.co\/BMgkR3HFS4",
    "id" : 567311404743819264,
    "created_at" : "2015-02-16 13:15:53 +0000",
    "user" : {
      "name" : "A Look at Nature",
      "screen_name" : "ALookatNature",
      "protected" : false,
      "id_str" : "2955602219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550776123781443584\/r6dXxLBd_normal.jpeg",
      "id" : 2955602219,
      "verified" : false
    }
  },
  "id" : 568828741054566400,
  "created_at" : "2015-02-20 17:45:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 0, 15 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568825048183791616",
  "geo" : { },
  "id_str" : "568828684481769473",
  "in_reply_to_user_id" : 818814906,
  "text" : "@PoetsLoveBirds squeee! precious!",
  "id" : 568828684481769473,
  "in_reply_to_status_id" : 568825048183791616,
  "created_at" : "2015-02-20 17:45:01 +0000",
  "in_reply_to_screen_name" : "PoetsLoveBirds",
  "in_reply_to_user_id_str" : "818814906",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 3, 18 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RealEstate",
      "indices" : [ 37, 48 ]
    }, {
      "text" : "birds",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568828597009559553",
  "text" : "RT @PoetsLoveBirds: Eastern Bluebird #RealEstate\nIt looks as though someone has claimed his new home!  \nNo mortgage payments! #birds http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PoetsLoveBirds\/status\/568825048183791616\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/b44srOcXpl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TfXY0IcAATxJd.jpg",
        "id_str" : "568825045846618112",
        "id" : 568825045846618112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TfXY0IcAATxJd.jpg",
        "sizes" : [ {
          "h" : 1306,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1306,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/b44srOcXpl"
      } ],
      "hashtags" : [ {
        "text" : "RealEstate",
        "indices" : [ 17, 28 ]
      }, {
        "text" : "birds",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568825048183791616",
    "text" : "Eastern Bluebird #RealEstate\nIt looks as though someone has claimed his new home!  \nNo mortgage payments! #birds http:\/\/t.co\/b44srOcXpl",
    "id" : 568825048183791616,
    "created_at" : "2015-02-20 17:30:34 +0000",
    "user" : {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "protected" : false,
      "id_str" : "818814906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153554844\/2f757111dc3eedb25debd1db4e264f85_normal.jpeg",
      "id" : 818814906,
      "verified" : false
    }
  },
  "id" : 568828597009559553,
  "created_at" : "2015-02-20 17:44:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "Caerwynt_Loops",
      "indices" : [ 3, 18 ],
      "id_str" : "33176865",
      "id" : 33176865
    }, {
      "name" : "Supercosmic",
      "screen_name" : "superc0smic",
      "indices" : [ 20, 32 ],
      "id_str" : "112828824",
      "id" : 112828824
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Caerwynt_Loops\/status\/568548247524003840\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/6uJYT6hBAm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PjlYpIUAAVe9k.jpg",
      "id_str" : "568548209388441600",
      "id" : 568548209388441600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PjlYpIUAAVe9k.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 758
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 758
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 811,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6uJYT6hBAm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568827689672568832",
  "text" : "RT @Caerwynt_Loops: @superc0smic black ears, nose, knees and hoofs! http:\/\/t.co\/6uJYT6hBAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Supercosmic",
        "screen_name" : "superc0smic",
        "indices" : [ 0, 12 ],
        "id_str" : "112828824",
        "id" : 112828824
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Caerwynt_Loops\/status\/568548247524003840\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/6uJYT6hBAm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PjlYpIUAAVe9k.jpg",
        "id_str" : "568548209388441600",
        "id" : 568548209388441600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PjlYpIUAAVe9k.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 758
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 758
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 811,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6uJYT6hBAm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "568547759139246080",
    "geo" : { },
    "id_str" : "568548247524003840",
    "in_reply_to_user_id" : 112828824,
    "text" : "@superc0smic black ears, nose, knees and hoofs! http:\/\/t.co\/6uJYT6hBAm",
    "id" : 568548247524003840,
    "in_reply_to_status_id" : 568547759139246080,
    "created_at" : "2015-02-19 23:10:39 +0000",
    "in_reply_to_screen_name" : "superc0smic",
    "in_reply_to_user_id_str" : "112828824",
    "user" : {
      "name" : "David Rice",
      "screen_name" : "Caerwynt_Loops",
      "protected" : false,
      "id_str" : "33176865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792075019736219649\/eSGcUv-o_normal.jpg",
      "id" : 33176865,
      "verified" : false
    }
  },
  "id" : 568827689672568832,
  "created_at" : "2015-02-20 17:41:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568814719177498624",
  "text" : "dh is so good. if i go to bed B4 our stray comes round.. he'll put out the goodies for him.",
  "id" : 568814719177498624,
  "created_at" : "2015-02-20 16:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/568812284862189568\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/EQJdgP07Os",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TTwUTIgAAxisk.jpg",
      "id_str" : "568812279991664640",
      "id" : 568812279991664640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TTwUTIgAAxisk.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/EQJdgP07Os"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568813437477888000",
  "text" : "RT @jacqueduncalf: \"Excuse me but do you realise that when we ordered our meal it was sunny and light out ere\" http:\/\/t.co\/EQJdgP07Os",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/568812284862189568\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/EQJdgP07Os",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TTwUTIgAAxisk.jpg",
        "id_str" : "568812279991664640",
        "id" : 568812279991664640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TTwUTIgAAxisk.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/EQJdgP07Os"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568812284862189568",
    "text" : "\"Excuse me but do you realise that when we ordered our meal it was sunny and light out ere\" http:\/\/t.co\/EQJdgP07Os",
    "id" : 568812284862189568,
    "created_at" : "2015-02-20 16:39:51 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 568813437477888000,
  "created_at" : "2015-02-20 16:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Broad Side",
      "screen_name" : "The_Broad_Side",
      "indices" : [ 106, 121 ],
      "id_str" : "279687441",
      "id" : 279687441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/rBzXLAEAiw",
      "expanded_url" : "http:\/\/www.the-broad-side.com\/my-daughter-is-in-jail-and-im-second-guessing-my-choices",
      "display_url" : "the-broad-side.com\/my-daughter-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568812910723661824",
  "text" : "My 18 Year Old Daughter Is In Jail And I'm Second Guessing Every Choice I Made http:\/\/t.co\/rBzXLAEAiw via @the_broad_side",
  "id" : 568812910723661824,
  "created_at" : "2015-02-20 16:42:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/568481881236348928\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/sqolYLI7Ph",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OnQixCYAAB7lO.jpg",
      "id_str" : "568481880631042048",
      "id" : 568481880631042048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OnQixCYAAB7lO.jpg",
      "sizes" : [ {
        "h" : 780,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sqolYLI7Ph"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 91, 97 ]
    }, {
      "text" : "nature",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568806500510126081",
  "text" : "RT @AWrobley: I heard a rustling in tree...spotted this Spotted Towhee staring down at me. #birds #nature http:\/\/t.co\/sqolYLI7Ph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/568481881236348928\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/sqolYLI7Ph",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OnQixCYAAB7lO.jpg",
        "id_str" : "568481880631042048",
        "id" : 568481880631042048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OnQixCYAAB7lO.jpg",
        "sizes" : [ {
          "h" : 780,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/sqolYLI7Ph"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 77, 83 ]
      }, {
        "text" : "nature",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568481881236348928",
    "text" : "I heard a rustling in tree...spotted this Spotted Towhee staring down at me. #birds #nature http:\/\/t.co\/sqolYLI7Ph",
    "id" : 568481881236348928,
    "created_at" : "2015-02-19 18:46:57 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 568806500510126081,
  "created_at" : "2015-02-20 16:16:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/518859503912382466\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/TXdf5r5eNM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzNb-DxIQAAgJAn.jpg",
      "id_str" : "518859503799123968",
      "id" : 518859503799123968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzNb-DxIQAAgJAn.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/TXdf5r5eNM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568806223174356992",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/TXdf5r5eNM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/518859503912382466\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/TXdf5r5eNM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzNb-DxIQAAgJAn.jpg",
        "id_str" : "518859503799123968",
        "id" : 518859503799123968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzNb-DxIQAAgJAn.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/TXdf5r5eNM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568804805524791297",
    "text" : "http:\/\/t.co\/TXdf5r5eNM",
    "id" : 568804805524791297,
    "created_at" : "2015-02-20 16:10:08 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 568806223174356992,
  "created_at" : "2015-02-20 16:15:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568806012335099904",
  "text" : "@Lluminous_ wouldn't that be so cool?",
  "id" : 568806012335099904,
  "created_at" : "2015-02-20 16:14:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568805476449816576",
  "text" : "wonder if ted dekker will be the next heretic...",
  "id" : 568805476449816576,
  "created_at" : "2015-02-20 16:12:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 16, 32 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568804691334844416",
  "text" : "RT @BlueDuPage: @aliceinthewater Heart attacks w\/o prior written notice are a violation of policy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "aliceinthewater",
        "screen_name" : "aliceinthewater",
        "indices" : [ 0, 16 ],
        "id_str" : "17489079",
        "id" : 17489079
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "568802980390006784",
    "geo" : { },
    "id_str" : "568803375233540096",
    "in_reply_to_user_id" : 17489079,
    "text" : "@aliceinthewater Heart attacks w\/o prior written notice are a violation of policy.",
    "id" : 568803375233540096,
    "in_reply_to_status_id" : 568802980390006784,
    "created_at" : "2015-02-20 16:04:27 +0000",
    "in_reply_to_screen_name" : "aliceinthewater",
    "in_reply_to_user_id_str" : "17489079",
    "user" : {
      "name" : "Muslim Green Dupage",
      "screen_name" : "HDGregg",
      "protected" : false,
      "id_str" : "41186732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649063875397185536\/ifPnhYz4_normal.jpg",
      "id" : 41186732,
      "verified" : false
    }
  },
  "id" : 568804691334844416,
  "created_at" : "2015-02-20 16:09:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568803799076376577",
  "text" : "our souls start as seedlings and innately we reach for the light above. some of us get sidetracked by obstacles.",
  "id" : 568803799076376577,
  "created_at" : "2015-02-20 16:06:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568803162989182976",
  "text" : "diff frequencies.. thats why i cant grasp some ppls views (or they mine) but thats ok. just keep reaching for the light.",
  "id" : 568803162989182976,
  "created_at" : "2015-02-20 16:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568802452738318336",
  "text" : "yesterday late afternoon driving home, i saw 10 or more either turkeys or vultures roosting in trees. very cool sight.",
  "id" : 568802452738318336,
  "created_at" : "2015-02-20 16:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Michela",
      "screen_name" : "Video_Matt",
      "indices" : [ 3, 14 ],
      "id_str" : "68765628",
      "id" : 68765628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Video_Matt\/status\/568541741676015616\/video\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/QRE5tAVWSN",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/568541568315846656\/pu\/img\/DO74jUbemtUK_-7i.jpg",
      "id_str" : "568541568315846656",
      "id" : 568541568315846656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/568541568315846656\/pu\/img\/DO74jUbemtUK_-7i.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QRE5tAVWSN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568543146424057856",
  "text" : "RT @Video_Matt: Sherman is up! http:\/\/t.co\/QRE5tAVWSN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Video_Matt\/status\/568541741676015616\/video\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/QRE5tAVWSN",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/568541568315846656\/pu\/img\/DO74jUbemtUK_-7i.jpg",
        "id_str" : "568541568315846656",
        "id" : 568541568315846656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/568541568315846656\/pu\/img\/DO74jUbemtUK_-7i.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QRE5tAVWSN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568541741676015616",
    "text" : "Sherman is up! http:\/\/t.co\/QRE5tAVWSN",
    "id" : 568541741676015616,
    "created_at" : "2015-02-19 22:44:48 +0000",
    "user" : {
      "name" : "Matthew Michela",
      "screen_name" : "Video_Matt",
      "protected" : false,
      "id_str" : "68765628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694312852211937281\/n_lHZ8oP_normal.jpg",
      "id" : 68765628,
      "verified" : true
    }
  },
  "id" : 568543146424057856,
  "created_at" : "2015-02-19 22:50:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Michela",
      "screen_name" : "Video_Matt",
      "indices" : [ 3, 14 ],
      "id_str" : "68765628",
      "id" : 68765628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Video_Matt\/status\/568517354360954880\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/27GDWvA3CA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PHgxWCMAANZxK.jpg",
      "id_str" : "568517343794311168",
      "id" : 568517343794311168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PHgxWCMAANZxK.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/27GDWvA3CA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568542880018640897",
  "text" : "RT @Video_Matt: \"Sherman\" the duck shot by pellets in Orem is starting his surgery. He hasn't eaten in over a week. http:\/\/t.co\/27GDWvA3CA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Video_Matt\/status\/568517354360954880\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/27GDWvA3CA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PHgxWCMAANZxK.jpg",
        "id_str" : "568517343794311168",
        "id" : 568517343794311168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PHgxWCMAANZxK.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/27GDWvA3CA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568517354360954880",
    "text" : "\"Sherman\" the duck shot by pellets in Orem is starting his surgery. He hasn't eaten in over a week. http:\/\/t.co\/27GDWvA3CA",
    "id" : 568517354360954880,
    "created_at" : "2015-02-19 21:07:54 +0000",
    "user" : {
      "name" : "Matthew Michela",
      "screen_name" : "Video_Matt",
      "protected" : false,
      "id_str" : "68765628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694312852211937281\/n_lHZ8oP_normal.jpg",
      "id" : 68765628,
      "verified" : true
    }
  },
  "id" : 568542880018640897,
  "created_at" : "2015-02-19 22:49:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 51, 63 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/568443916841836544\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/pw89kQSjFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OEt2hIQAAajA3.jpg",
      "id_str" : "568443901242261504",
      "id" : 568443901242261504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OEt2hIQAAajA3.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pw89kQSjFI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/568443916841836544\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/pw89kQSjFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OEuanIAAAr0fB.jpg",
      "id_str" : "568443910931087360",
      "id" : 568443910931087360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OEuanIAAAr0fB.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pw89kQSjFI"
    } ],
    "hashtags" : [ {
      "text" : "muteswans",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "London",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568486245707464704",
  "text" : "RT @missmuckyduck: Swan love. \uD83D\uDC96\n#muteswans #London @wildlife_uk http:\/\/t.co\/pw89kQSjFI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 32, 44 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/568443916841836544\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/pw89kQSjFI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OEt2hIQAAajA3.jpg",
        "id_str" : "568443901242261504",
        "id" : 568443901242261504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OEt2hIQAAajA3.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pw89kQSjFI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/568443916841836544\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/pw89kQSjFI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OEuanIAAAr0fB.jpg",
        "id_str" : "568443910931087360",
        "id" : 568443910931087360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OEuanIAAAr0fB.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pw89kQSjFI"
      } ],
      "hashtags" : [ {
        "text" : "muteswans",
        "indices" : [ 13, 23 ]
      }, {
        "text" : "London",
        "indices" : [ 24, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568443916841836544",
    "text" : "Swan love. \uD83D\uDC96\n#muteswans #London @wildlife_uk http:\/\/t.co\/pw89kQSjFI",
    "id" : 568443916841836544,
    "created_at" : "2015-02-19 16:16:05 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 568486245707464704,
  "created_at" : "2015-02-19 19:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568481529057427458",
  "text" : "RT @mikemchargue: I just realized that despite being open\/affirming, I'm also intrinsically heteronormative.\n\nChange is hard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568467813196832768",
    "text" : "I just realized that despite being open\/affirming, I'm also intrinsically heteronormative.\n\nChange is hard.",
    "id" : 568467813196832768,
    "created_at" : "2015-02-19 17:51:02 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 568481529057427458,
  "created_at" : "2015-02-19 18:45:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568481306725781504",
  "text" : "RT @mikemchargue: My faith leads me to love LGBT persons\u2013and people who believe that LGBT relationships are sinful. The easy thing is to wr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568478060380602369",
    "text" : "My faith leads me to love LGBT persons\u2013and people who believe that LGBT relationships are sinful. The easy thing is to write people off.",
    "id" : 568478060380602369,
    "created_at" : "2015-02-19 18:31:46 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 568481306725781504,
  "created_at" : "2015-02-19 18:44:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568481255806918656",
  "text" : "RT @mikemchargue: The narrow road is patience, gentleness, and self-control. God, help me practice what I preach.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568478350924259328",
    "text" : "The narrow road is patience, gentleness, and self-control. God, help me practice what I preach.",
    "id" : 568478350924259328,
    "created_at" : "2015-02-19 18:32:55 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 568481255806918656,
  "created_at" : "2015-02-19 18:44:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568481016534437889",
  "text" : "RT @mikemchargue: If I err, let me err on the side of grace, compassion, and forgiveness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568480076582535168",
    "text" : "If I err, let me err on the side of grace, compassion, and forgiveness.",
    "id" : 568480076582535168,
    "created_at" : "2015-02-19 18:39:46 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 568481016534437889,
  "created_at" : "2015-02-19 18:43:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568479929266003970",
  "text" : "advil congestion relief is king!",
  "id" : 568479929266003970,
  "created_at" : "2015-02-19 18:39:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 89, 102 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deep",
      "indices" : [ 103, 108 ]
    }, {
      "text" : "philosophy",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/bH5HnJnlXC",
      "expanded_url" : "http:\/\/micahjmurray.com\/ash-wednesday\/",
      "display_url" : "micahjmurray.com\/ash-wednesday\/"
    } ]
  },
  "geo" : { },
  "id_str" : "568459812297674752",
  "text" : "\"But the truth is \u2014 I was unwilling to die.\" On Ash Wednesday http:\/\/t.co\/bH5HnJnlXC via @micahjmurray #deep #philosophy",
  "id" : 568459812297674752,
  "created_at" : "2015-02-19 17:19:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568440295400087552",
  "text" : "RT @Irish_Atheist: Christians can say any damn horrible thing they please as long as they specify that it's 'in love.'\n\nMust be nice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568439745585541121",
    "text" : "Christians can say any damn horrible thing they please as long as they specify that it's 'in love.'\n\nMust be nice.",
    "id" : 568439745585541121,
    "created_at" : "2015-02-19 15:59:31 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 568440295400087552,
  "created_at" : "2015-02-19 16:01:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DuckDuckHack",
      "screen_name" : "duckduckhack",
      "indices" : [ 3, 16 ],
      "id_str" : "551247481",
      "id" : 551247481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/puldpPcUR9",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/9475a1\/blyt",
      "display_url" : "cards.twitter.com\/cards\/9475a1\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568440074708377601",
  "text" : "RT @duckduckhack: Create the next generation of search results on the next generation search engine!  https:\/\/t.co\/puldpPcUR9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/puldpPcUR9",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/9475a1\/blyt",
        "display_url" : "cards.twitter.com\/cards\/9475a1\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "561568594094325760",
    "text" : "Create the next generation of search results on the next generation search engine!  https:\/\/t.co\/puldpPcUR9",
    "id" : 561568594094325760,
    "created_at" : "2015-01-31 16:56:00 +0000",
    "user" : {
      "name" : "DuckDuckHack",
      "screen_name" : "duckduckhack",
      "protected" : false,
      "id_str" : "551247481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542062260600840192\/nK5NSKBY_normal.png",
      "id" : 551247481,
      "verified" : false
    }
  },
  "id" : 568440074708377601,
  "created_at" : "2015-02-19 16:00:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568184090102538241",
  "text" : "RT @jonlieffmd: With tiny brain pigeons categorize &amp; name both natural and manmade objects - 128 photographs in16 categories  http:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brain",
        "indices" : [ 137, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/aeXpg2s3d4",
        "expanded_url" : "http:\/\/bit.ly\/16w41n8",
        "display_url" : "bit.ly\/16w41n8"
      } ]
    },
    "geo" : { },
    "id_str" : "568183248632868864",
    "text" : "With tiny brain pigeons categorize &amp; name both natural and manmade objects - 128 photographs in16 categories  http:\/\/t.co\/aeXpg2s3d4 #brain",
    "id" : 568183248632868864,
    "created_at" : "2015-02-18 23:00:17 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 568184090102538241,
  "created_at" : "2015-02-18 23:03:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568181505610149888",
  "text" : "RT @fearfuldogs: We do not reinforce fear in our dogs when do anything that makes them feel safer or more comfortable. http:\/\/t.co\/GAYEdQtn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fearfuldogs\/status\/568178142118068224\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/GAYEdQtnTN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-KTAkSCQAA8Luf.jpg",
        "id_str" : "568178140950708224",
        "id" : 568178140950708224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-KTAkSCQAA8Luf.jpg",
        "sizes" : [ {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GAYEdQtnTN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568178142118068224",
    "text" : "We do not reinforce fear in our dogs when do anything that makes them feel safer or more comfortable. http:\/\/t.co\/GAYEdQtnTN",
    "id" : 568178142118068224,
    "created_at" : "2015-02-18 22:39:59 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 568181505610149888,
  "created_at" : "2015-02-18 22:53:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/zivuZsOjMR",
      "expanded_url" : "http:\/\/qvotr.com\/quote\/2343",
      "display_url" : "qvotr.com\/quote\/2343"
    } ]
  },
  "geo" : { },
  "id_str" : "568151636302012416",
  "text" : "\"Do you think the moon landing is real or do you think NASA faked it?\n\nI think it...\" http:\/\/t.co\/zivuZsOjMR",
  "id" : 568151636302012416,
  "created_at" : "2015-02-18 20:54:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Mi0IEo4xTk",
      "expanded_url" : "http:\/\/www.papermag.com\/2015\/02\/tom_delonge_ufo_interview.php",
      "display_url" : "papermag.com\/2015\/02\/tom_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568148935119732737",
  "text" : "Blink-182 Co-Founder Tom DeLonge Goes Deep on UFOs, Government Coverups and Why Aliens are Bigger than Jesus http:\/\/t.co\/Mi0IEo4xTk",
  "id" : 568148935119732737,
  "created_at" : "2015-02-18 20:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/519115247630950400\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/BHc2MdbH2k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzREkTRIgAAPbTH.jpg",
      "id_str" : "519115247492562944",
      "id" : 519115247492562944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzREkTRIgAAPbTH.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/BHc2MdbH2k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568140930445922304",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/BHc2MdbH2k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/519115247630950400\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/BHc2MdbH2k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzREkTRIgAAPbTH.jpg",
        "id_str" : "519115247492562944",
        "id" : 519115247492562944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzREkTRIgAAPbTH.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/BHc2MdbH2k"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568139179688927232",
    "text" : "http:\/\/t.co\/BHc2MdbH2k",
    "id" : 568139179688927232,
    "created_at" : "2015-02-18 20:05:10 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 568140930445922304,
  "created_at" : "2015-02-18 20:12:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/568126325623525378\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/wjnKvRcmcP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Jj4g4IQAABHOI.jpg",
      "id_str" : "568126325551284224",
      "id" : 568126325551284224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Jj4g4IQAABHOI.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wjnKvRcmcP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568127155282038785",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/wjnKvRcmcP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/568126325623525378\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/wjnKvRcmcP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Jj4g4IQAABHOI.jpg",
        "id_str" : "568126325551284224",
        "id" : 568126325551284224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Jj4g4IQAABHOI.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wjnKvRcmcP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568126325623525378",
    "text" : "\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/wjnKvRcmcP",
    "id" : 568126325623525378,
    "created_at" : "2015-02-18 19:14:05 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 568127155282038785,
  "created_at" : "2015-02-18 19:17:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "NESASK",
      "indices" : [ 3, 10 ],
      "id_str" : "20373494",
      "id" : 20373494
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NESASK\/status\/568123565117014016\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/w22LsBouSx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-JhXyOCIAEDddX.jpg",
      "id_str" : "568123564247621633",
      "id" : 568123564247621633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-JhXyOCIAEDddX.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1121,
        "resize" : "fit",
        "w" : 1680
      } ],
      "display_url" : "pic.twitter.com\/w22LsBouSx"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 81, 87 ]
    }, {
      "text" : "nature",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568124156597948416",
  "text" : "RT @NESASK: A Eurasian Collared-Dove. A first for me, and far out of range here. #birds #nature http:\/\/t.co\/w22LsBouSx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NESASK\/status\/568123565117014016\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/w22LsBouSx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-JhXyOCIAEDddX.jpg",
        "id_str" : "568123564247621633",
        "id" : 568123564247621633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-JhXyOCIAEDddX.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1121,
          "resize" : "fit",
          "w" : 1680
        } ],
        "display_url" : "pic.twitter.com\/w22LsBouSx"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 69, 75 ]
      }, {
        "text" : "nature",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568123565117014016",
    "text" : "A Eurasian Collared-Dove. A first for me, and far out of range here. #birds #nature http:\/\/t.co\/w22LsBouSx",
    "id" : 568123565117014016,
    "created_at" : "2015-02-18 19:03:07 +0000",
    "user" : {
      "name" : "Scott",
      "screen_name" : "NESASK",
      "protected" : false,
      "id_str" : "20373494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1289050399\/oldimg_normal.jpg",
      "id" : 20373494,
      "verified" : false
    }
  },
  "id" : 568124156597948416,
  "created_at" : "2015-02-18 19:05:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568080465871163392",
  "text" : "dreamed about a crow size bird attacking my face last night. weird.",
  "id" : 568080465871163392,
  "created_at" : "2015-02-18 16:11:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/JnPkQMTVPH",
      "expanded_url" : "http:\/\/themeowpost.com\/dog-and-cat-in-love-in-the-window\/",
      "display_url" : "themeowpost.com\/dog-and-cat-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568061970345279488",
  "text" : "Their Dog Was In Love With A Cat, Then It All Ended...But What She Did Next Is Pure GOLD http:\/\/t.co\/JnPkQMTVPH",
  "id" : 568061970345279488,
  "created_at" : "2015-02-18 14:58:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Root",
      "screen_name" : "TheRoot",
      "indices" : [ 109, 117 ],
      "id_str" : "23995748",
      "id" : 23995748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/siAonBNn0H",
      "expanded_url" : "http:\/\/www.theroot.com\/articles\/culture\/2015\/02\/amber_rose_vs_the_kardashians_how_race_and_class_reshapes_this_slut_shaming.html",
      "display_url" : "theroot.com\/articles\/cultu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567863435343560704",
  "text" : "Amber Rose vs. the Kardashians: How Race and Class Reshape This Slut-Shaming Beef http:\/\/t.co\/siAonBNn0H via @TheRoot",
  "id" : 567863435343560704,
  "created_at" : "2015-02-18 01:49:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/kBfxL5irZA",
      "expanded_url" : "http:\/\/www.addictinginfo.org\/2015\/02\/16\/sinister-law-brings-theocracy-to-tennessee-the-christian-right-are-coming-for-your-state-next\/",
      "display_url" : "addictinginfo.org\/2015\/02\/16\/sin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567855624341622784",
  "text" : "Sinister Law Brings Theocracy To Tennessee: The Christian Right Are Coming For Your State Next\nhttp:\/\/t.co\/kBfxL5irZA",
  "id" : 567855624341622784,
  "created_at" : "2015-02-18 01:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 3, 18 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fibromyalgia",
      "indices" : [ 79, 92 ]
    }, {
      "text" : "depression",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "depressionawareness",
      "indices" : [ 105, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/HVFsmKZloU",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/depression-its-the-little-things\/",
      "display_url" : "brucegerencser.net\/2015\/02\/depres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567824493139402752",
  "text" : "RT @BruceGerencser: Depression: It's the Little Things http:\/\/t.co\/HVFsmKZloU  #fibromyalgia #depression #depressionawareness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fibromyalgia",
        "indices" : [ 59, 72 ]
      }, {
        "text" : "depression",
        "indices" : [ 73, 84 ]
      }, {
        "text" : "depressionawareness",
        "indices" : [ 85, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/HVFsmKZloU",
        "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/depression-its-the-little-things\/",
        "display_url" : "brucegerencser.net\/2015\/02\/depres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567812641311330304",
    "text" : "Depression: It's the Little Things http:\/\/t.co\/HVFsmKZloU  #fibromyalgia #depression #depressionawareness",
    "id" : 567812641311330304,
    "created_at" : "2015-02-17 22:27:37 +0000",
    "user" : {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "protected" : false,
      "id_str" : "2954308119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708165822007480320\/bzYNwh2A_normal.jpg",
      "id" : 2954308119,
      "verified" : false
    }
  },
  "id" : 567824493139402752,
  "created_at" : "2015-02-17 23:14:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juha Auvinen",
      "screen_name" : "Zehov",
      "indices" : [ 3, 9 ],
      "id_str" : "32802744",
      "id" : 32802744
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Zehov\/status\/567556389032443904\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/NxHcFKrcbu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-BdhxYIQAA58L-.jpg",
      "id_str" : "567556387820290048",
      "id" : 567556387820290048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-BdhxYIQAA58L-.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NxHcFKrcbu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567768279541100545",
  "text" : "RT @Zehov: http:\/\/t.co\/NxHcFKrcbu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Zehov\/status\/567556389032443904\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/NxHcFKrcbu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-BdhxYIQAA58L-.jpg",
        "id_str" : "567556387820290048",
        "id" : 567556387820290048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-BdhxYIQAA58L-.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NxHcFKrcbu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567556389032443904",
    "text" : "http:\/\/t.co\/NxHcFKrcbu",
    "id" : 567556389032443904,
    "created_at" : "2015-02-17 05:29:22 +0000",
    "user" : {
      "name" : "Juha Auvinen",
      "screen_name" : "Zehov",
      "protected" : false,
      "id_str" : "32802744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609642694961336321\/ZHn-eye3_normal.jpg",
      "id" : 32802744,
      "verified" : false
    }
  },
  "id" : 567768279541100545,
  "created_at" : "2015-02-17 19:31:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev",
      "screen_name" : "TopkitKev",
      "indices" : [ 3, 13 ],
      "id_str" : "1312920337",
      "id" : 1312920337
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TopkitKev\/status\/567759712662208513\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/yy36yzUyA2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EWcw5IUAA5Zmq.jpg",
      "id_str" : "567759711442063360",
      "id" : 567759711442063360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EWcw5IUAA5Zmq.jpg",
      "sizes" : [ {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 884,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 982,
        "resize" : "fit",
        "w" : 1138
      } ],
      "display_url" : "pic.twitter.com\/yy36yzUyA2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567768214604886017",
  "text" : "RT @TopkitKev: Gorgeous fluffy Chiffy... http:\/\/t.co\/yy36yzUyA2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TopkitKev\/status\/567759712662208513\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/yy36yzUyA2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EWcw5IUAA5Zmq.jpg",
        "id_str" : "567759711442063360",
        "id" : 567759711442063360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EWcw5IUAA5Zmq.jpg",
        "sizes" : [ {
          "h" : 518,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 884,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 982,
          "resize" : "fit",
          "w" : 1138
        } ],
        "display_url" : "pic.twitter.com\/yy36yzUyA2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567759712662208513",
    "text" : "Gorgeous fluffy Chiffy... http:\/\/t.co\/yy36yzUyA2",
    "id" : 567759712662208513,
    "created_at" : "2015-02-17 18:57:18 +0000",
    "user" : {
      "name" : "Kev",
      "screen_name" : "TopkitKev",
      "protected" : false,
      "id_str" : "1312920337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687578720102645760\/tHQLXHAq_normal.jpg",
      "id" : 1312920337,
      "verified" : false
    }
  },
  "id" : 567768214604886017,
  "created_at" : "2015-02-17 19:31:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "...herbie",
      "screen_name" : "herbertmatteie",
      "indices" : [ 3, 18 ],
      "id_str" : "759411782",
      "id" : 759411782
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/herbertmatteie\/status\/567744899509125121\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/fdoiNM0nM6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EI-dsCAAAampw.jpg",
      "id_str" : "567744897239613440",
      "id" : 567744897239613440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EI-dsCAAAampw.jpg",
      "sizes" : [ {
        "h" : 367,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fdoiNM0nM6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567755902850457600",
  "text" : "RT @herbertmatteie: http:\/\/t.co\/fdoiNM0nM6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/herbertmatteie\/status\/567744899509125121\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/fdoiNM0nM6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EI-dsCAAAampw.jpg",
        "id_str" : "567744897239613440",
        "id" : 567744897239613440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EI-dsCAAAampw.jpg",
        "sizes" : [ {
          "h" : 367,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fdoiNM0nM6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.3816473, -111.7498221 ]
    },
    "id_str" : "567744899509125121",
    "text" : "http:\/\/t.co\/fdoiNM0nM6",
    "id" : 567744899509125121,
    "created_at" : "2015-02-17 17:58:26 +0000",
    "user" : {
      "name" : "...herbie",
      "screen_name" : "herbertmatteie",
      "protected" : false,
      "id_str" : "759411782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796076305859178497\/COhFckAM_normal.jpg",
      "id" : 759411782,
      "verified" : false
    }
  },
  "id" : 567755902850457600,
  "created_at" : "2015-02-17 18:42:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567742689224175616",
  "text" : "my sinuses are burning.",
  "id" : 567742689224175616,
  "created_at" : "2015-02-17 17:49:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567741872836444160",
  "text" : "RT @sarahnmoon: Interviewer at this scholarship competition: \"I read your essay. The Trinity as divine orgy? I...I have to admit I've never\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567740539840516096",
    "text" : "Interviewer at this scholarship competition: \"I read your essay. The Trinity as divine orgy? I...I have to admit I've never heard that one.\"",
    "id" : 567740539840516096,
    "created_at" : "2015-02-17 17:41:07 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 567741872836444160,
  "created_at" : "2015-02-17 17:46:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ModernFamily",
      "indices" : [ 38, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/qj4fcyh1bc",
      "expanded_url" : "http:\/\/abc.go.com\/shows\/modern-family\/episode-guide\/season-05\/515-the-feud",
      "display_url" : "abc.go.com\/shows\/modern-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567480815471570944",
  "text" : "the possum stole the show! : ) heehee #ModernFamily http:\/\/t.co\/qj4fcyh1bc",
  "id" : 567480815471570944,
  "created_at" : "2015-02-17 00:29:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meja Baeck",
      "screen_name" : "MayaBaeck",
      "indices" : [ 3, 13 ],
      "id_str" : "2558595289",
      "id" : 2558595289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567438417450237953",
  "text" : "RT @MayaBaeck: Maybe God himself is lost and needs help.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567436386492764160",
    "text" : "Maybe God himself is lost and needs help.",
    "id" : 567436386492764160,
    "created_at" : "2015-02-16 21:32:31 +0000",
    "user" : {
      "name" : "Meja Baeck",
      "screen_name" : "MayaBaeck",
      "protected" : true,
      "id_str" : "2558595289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508381628641452032\/GxjvEttg_normal.jpeg",
      "id" : 2558595289,
      "verified" : false
    }
  },
  "id" : 567438417450237953,
  "created_at" : "2015-02-16 21:40:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kane Brides",
      "screen_name" : "KaneBrides",
      "indices" : [ 3, 14 ],
      "id_str" : "374627781",
      "id" : 374627781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567408499563700224",
  "text" : "RT @KaneBrides: Clear night sky and favourable winds this week, I think it'll be time to say good bye to these for another season! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KaneBrides\/status\/567407958905344002\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/FGS8n1Czwr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9_Wh-FIUAEiTLT.jpg",
        "id_str" : "567407957160513537",
        "id" : 567407957160513537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9_Wh-FIUAEiTLT.jpg",
        "sizes" : [ {
          "h" : 631,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1078,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1946
        } ],
        "display_url" : "pic.twitter.com\/FGS8n1Czwr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567407958905344002",
    "text" : "Clear night sky and favourable winds this week, I think it'll be time to say good bye to these for another season! http:\/\/t.co\/FGS8n1Czwr",
    "id" : 567407958905344002,
    "created_at" : "2015-02-16 19:39:33 +0000",
    "user" : {
      "name" : "Kane Brides",
      "screen_name" : "KaneBrides",
      "protected" : false,
      "id_str" : "374627781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754765137983209474\/ZXg7SRCq_normal.jpg",
      "id" : 374627781,
      "verified" : false
    }
  },
  "id" : 567408499563700224,
  "created_at" : "2015-02-16 19:41:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/539868924155019264\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/BMlEyJ8CYZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B33_60zIIAEODGe.jpg",
      "id_str" : "539868916424908801",
      "id" : 539868916424908801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B33_60zIIAEODGe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/BMlEyJ8CYZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567408445830463489",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/BMlEyJ8CYZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/539868924155019264\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/BMlEyJ8CYZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B33_60zIIAEODGe.jpg",
        "id_str" : "539868916424908801",
        "id" : 539868916424908801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B33_60zIIAEODGe.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/BMlEyJ8CYZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567408100463104000",
    "text" : "http:\/\/t.co\/BMlEyJ8CYZ",
    "id" : 567408100463104000,
    "created_at" : "2015-02-16 19:40:07 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 567408445830463489,
  "created_at" : "2015-02-16 19:41:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/567386572790980608\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/iBPOBfEMDX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9_DBf7CcAAmjA7.jpg",
      "id_str" : "567386508588380160",
      "id" : 567386508588380160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9_DBf7CcAAmjA7.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iBPOBfEMDX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567387291648528385",
  "text" : "RT @marseelee: The principle of Consciousness... http:\/\/t.co\/iBPOBfEMDX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/567386572790980608\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/iBPOBfEMDX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9_DBf7CcAAmjA7.jpg",
        "id_str" : "567386508588380160",
        "id" : 567386508588380160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9_DBf7CcAAmjA7.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iBPOBfEMDX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567386572790980608",
    "text" : "The principle of Consciousness... http:\/\/t.co\/iBPOBfEMDX",
    "id" : 567386572790980608,
    "created_at" : "2015-02-16 18:14:35 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 567387291648528385,
  "created_at" : "2015-02-16 18:17:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 54, 70 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/vbFVZy7Js7",
      "expanded_url" : "http:\/\/helensmithbooks.com\/giveaways\/kindle-paperwhite-giveaway\/?lucky=13356",
      "display_url" : "helensmithbooks.com\/giveaways\/kind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567373080243474433",
  "text" : "Kindle Paperwhite Giveaway http:\/\/t.co\/vbFVZy7Js7 via @emperorsclothes",
  "id" : 567373080243474433,
  "created_at" : "2015-02-16 17:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567370015306178560",
  "text" : "about point 75%, story about man and his kids made me cry... The Robcast",
  "id" : 567370015306178560,
  "created_at" : "2015-02-16 17:08:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/567360214102732800\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/OnUjKOQgIz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-rG9GIgAAU682.jpg",
      "id_str" : "567360214039822336",
      "id" : 567360214039822336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-rG9GIgAAU682.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OnUjKOQgIz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567366860845625344",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/OnUjKOQgIz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/567360214102732800\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/OnUjKOQgIz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-rG9GIgAAU682.jpg",
        "id_str" : "567360214039822336",
        "id" : 567360214039822336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-rG9GIgAAU682.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OnUjKOQgIz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567360214102732800",
    "text" : "\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/OnUjKOQgIz",
    "id" : 567360214102732800,
    "created_at" : "2015-02-16 16:29:50 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 567366860845625344,
  "created_at" : "2015-02-16 16:56:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523147286033879040\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/7MBfz01d82",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0KXr0rCIAABlZv.jpg",
      "id_str" : "523147285857705984",
      "id" : 523147285857705984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0KXr0rCIAABlZv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7MBfz01d82"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567366828599824385",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/7MBfz01d82",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523147286033879040\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/7MBfz01d82",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0KXr0rCIAABlZv.jpg",
        "id_str" : "523147285857705984",
        "id" : 523147285857705984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0KXr0rCIAABlZv.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7MBfz01d82"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567360282897682432",
    "text" : "http:\/\/t.co\/7MBfz01d82",
    "id" : 567360282897682432,
    "created_at" : "2015-02-16 16:30:07 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 567366828599824385,
  "created_at" : "2015-02-16 16:56:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/567360357279469568\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/qClyEcMsxQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-rPSiIQAAIbc5.jpg",
      "id_str" : "567360357233344512",
      "id" : 567360357233344512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-rPSiIQAAIbc5.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/qClyEcMsxQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567366655018545153",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/qClyEcMsxQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/567360357279469568\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/qClyEcMsxQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-rPSiIQAAIbc5.jpg",
        "id_str" : "567360357233344512",
        "id" : 567360357233344512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-rPSiIQAAIbc5.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/qClyEcMsxQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567360357279469568",
    "text" : "\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/qClyEcMsxQ",
    "id" : 567360357279469568,
    "created_at" : "2015-02-16 16:30:24 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 567366655018545153,
  "created_at" : "2015-02-16 16:55:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC00Fedya Rat\uD83D\uDC01",
      "screen_name" : "Fedya_Rat",
      "indices" : [ 3, 13 ],
      "id_str" : "362376702",
      "id" : 362376702
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Fedya_Rat\/status\/567359614636027904\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/b0EbW5t1Yy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-qj__CQAEZnZS.jpg",
      "id_str" : "567359613519937537",
      "id" : 567359613519937537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-qj__CQAEZnZS.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/b0EbW5t1Yy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567366403729399809",
  "text" : "RT @Fedya_Rat: Find the rattie ;-) http:\/\/t.co\/b0EbW5t1Yy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fedya_Rat\/status\/567359614636027904\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/b0EbW5t1Yy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-qj__CQAEZnZS.jpg",
        "id_str" : "567359613519937537",
        "id" : 567359613519937537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-qj__CQAEZnZS.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/b0EbW5t1Yy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567359614636027904",
    "text" : "Find the rattie ;-) http:\/\/t.co\/b0EbW5t1Yy",
    "id" : 567359614636027904,
    "created_at" : "2015-02-16 16:27:27 +0000",
    "user" : {
      "name" : "\uD83D\uDC00Fedya Rat\uD83D\uDC01",
      "screen_name" : "Fedya_Rat",
      "protected" : false,
      "id_str" : "362376702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718539758519980032\/upkxjoo6_normal.jpg",
      "id" : 362376702,
      "verified" : false
    }
  },
  "id" : 567366403729399809,
  "created_at" : "2015-02-16 16:54:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/567363550386323458\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/entOlAGAyt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-uJIEIAAAFl0H.jpg",
      "id_str" : "567363549878812672",
      "id" : 567363549878812672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-uJIEIAAAFl0H.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/entOlAGAyt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567365165004640257",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/entOlAGAyt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/567363550386323458\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/entOlAGAyt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-uJIEIAAAFl0H.jpg",
        "id_str" : "567363549878812672",
        "id" : 567363549878812672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-uJIEIAAAFl0H.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 760,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 760,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 760,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/entOlAGAyt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567363550386323458",
    "text" : "\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/entOlAGAyt",
    "id" : 567363550386323458,
    "created_at" : "2015-02-16 16:43:06 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 567365165004640257,
  "created_at" : "2015-02-16 16:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeannie Hartley",
      "screen_name" : "Jeannie_Hartley",
      "indices" : [ 3, 19 ],
      "id_str" : "192477353",
      "id" : 192477353
    }, {
      "name" : "The Illuminati",
      "screen_name" : "iIllumiinati",
      "indices" : [ 22, 35 ],
      "id_str" : "268613555",
      "id" : 268613555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Education",
      "indices" : [ 119, 129 ]
    }, {
      "text" : "children",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/DJqTlfzy9t",
      "expanded_url" : "https:\/\/twitter.com\/iIllumiinati\/status\/566728659965603840\/photo\/1",
      "display_url" : "pic.twitter.com\/DJqTlfzy9t"
    } ]
  },
  "geo" : { },
  "id_str" : "567365023975370752",
  "text" : "RT @Jeannie_Hartley: \"@iIllumiinati: you know theres a problem with our education system when\u2026 http:\/\/t.co\/DJqTlfzy9t\" #Education #children\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Illuminati",
        "screen_name" : "iIllumiinati",
        "indices" : [ 1, 14 ],
        "id_str" : "268613555",
        "id" : 268613555
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Education",
        "indices" : [ 98, 108 ]
      }, {
        "text" : "children",
        "indices" : [ 109, 118 ]
      }, {
        "text" : "suicideprevention",
        "indices" : [ 119, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/DJqTlfzy9t",
        "expanded_url" : "https:\/\/twitter.com\/iIllumiinati\/status\/566728659965603840\/photo\/1",
        "display_url" : "pic.twitter.com\/DJqTlfzy9t"
      } ]
    },
    "geo" : { },
    "id_str" : "567362545812385792",
    "text" : "\"@iIllumiinati: you know theres a problem with our education system when\u2026 http:\/\/t.co\/DJqTlfzy9t\" #Education #children #suicideprevention",
    "id" : 567362545812385792,
    "created_at" : "2015-02-16 16:39:06 +0000",
    "user" : {
      "name" : "Jeannie Hartley",
      "screen_name" : "Jeannie_Hartley",
      "protected" : false,
      "id_str" : "192477353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800816051093172224\/EUAJo_d3_normal.jpg",
      "id" : 192477353,
      "verified" : false
    }
  },
  "id" : 567365023975370752,
  "created_at" : "2015-02-16 16:48:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Bell",
      "screen_name" : "realrobbell",
      "indices" : [ 22, 34 ],
      "id_str" : "65167734",
      "id" : 65167734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/SWnpOEnHo8",
      "expanded_url" : "http:\/\/robbell.podbean.com",
      "display_url" : "robbell.podbean.com"
    } ]
  },
  "in_reply_to_status_id_str" : "567356080422809601",
  "geo" : { },
  "id_str" : "567364674325610496",
  "in_reply_to_user_id" : 65167734,
  "text" : "listening now &gt; RT @realrobbell The RobCast\nEpisode 5 | Atoms and Interiors \nhttp:\/\/t.co\/SWnpOEnHo8",
  "id" : 567364674325610496,
  "in_reply_to_status_id" : 567356080422809601,
  "created_at" : "2015-02-16 16:47:34 +0000",
  "in_reply_to_screen_name" : "realrobbell",
  "in_reply_to_user_id_str" : "65167734",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/567356464332042240\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/aJhug5frP7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-nssHIcAAWTa4.jpg",
      "id_str" : "567356464269127680",
      "id" : 567356464269127680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-nssHIcAAWTa4.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/aJhug5frP7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/PE49c9w4Lt",
      "expanded_url" : "http:\/\/trib.al\/djTYz3k",
      "display_url" : "trib.al\/djTYz3k"
    } ]
  },
  "geo" : { },
  "id_str" : "567357733222240257",
  "text" : "RT @guardian: Woolly boobs: laughable, sobering and surprisingly useful http:\/\/t.co\/PE49c9w4Lt http:\/\/t.co\/aJhug5frP7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/567356464332042240\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/aJhug5frP7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-nssHIcAAWTa4.jpg",
        "id_str" : "567356464269127680",
        "id" : 567356464269127680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-nssHIcAAWTa4.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/aJhug5frP7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/PE49c9w4Lt",
        "expanded_url" : "http:\/\/trib.al\/djTYz3k",
        "display_url" : "trib.al\/djTYz3k"
      } ]
    },
    "geo" : { },
    "id_str" : "567356464332042240",
    "text" : "Woolly boobs: laughable, sobering and surprisingly useful http:\/\/t.co\/PE49c9w4Lt http:\/\/t.co\/aJhug5frP7",
    "id" : 567356464332042240,
    "created_at" : "2015-02-16 16:14:56 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774191274391965696\/Tulf7lwN_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 567357733222240257,
  "created_at" : "2015-02-16 16:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/micahjmurray\/status\/567310634556358657\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/knHyVK5hTi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B99-A83CUAArY5o.jpg",
      "id_str" : "567310632874037248",
      "id" : 567310632874037248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B99-A83CUAArY5o.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/knHyVK5hTi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/0FR6wXvtmo",
      "expanded_url" : "http:\/\/micahjmurray.com\/confessions-of-an-impatient-seedling\/",
      "display_url" : "micahjmurray.com\/confessions-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567334349142781952",
  "text" : "RT @micahjmurray: NEW POST: \u201CConfessions of an Impatient Seedling\u201D http:\/\/t.co\/0FR6wXvtmo http:\/\/t.co\/knHyVK5hTi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/micahjmurray\/status\/567310634556358657\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/knHyVK5hTi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B99-A83CUAArY5o.jpg",
        "id_str" : "567310632874037248",
        "id" : 567310632874037248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B99-A83CUAArY5o.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 153,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/knHyVK5hTi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/0FR6wXvtmo",
        "expanded_url" : "http:\/\/micahjmurray.com\/confessions-of-an-impatient-seedling\/",
        "display_url" : "micahjmurray.com\/confessions-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567310634556358657",
    "text" : "NEW POST: \u201CConfessions of an Impatient Seedling\u201D http:\/\/t.co\/0FR6wXvtmo http:\/\/t.co\/knHyVK5hTi",
    "id" : 567310634556358657,
    "created_at" : "2015-02-16 13:12:50 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 567334349142781952,
  "created_at" : "2015-02-16 14:47:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501790447736737792\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/LwgVJBQWfg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bva3wOFIUAAiPTs.jpg",
      "id_str" : "501790447539605504",
      "id" : 501790447539605504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bva3wOFIUAAiPTs.jpg",
      "sizes" : [ {
        "h" : 691,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/LwgVJBQWfg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567135858617483264",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/LwgVJBQWfg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501790447736737792\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/LwgVJBQWfg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bva3wOFIUAAiPTs.jpg",
        "id_str" : "501790447539605504",
        "id" : 501790447539605504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bva3wOFIUAAiPTs.jpg",
        "sizes" : [ {
          "h" : 691,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 806,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 806,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/LwgVJBQWfg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567131276772405250",
    "text" : "http:\/\/t.co\/LwgVJBQWfg",
    "id" : 567131276772405250,
    "created_at" : "2015-02-16 01:20:07 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 567135858617483264,
  "created_at" : "2015-02-16 01:38:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/MlMEJsorDf",
      "expanded_url" : "http:\/\/instagram.com\/p\/zJLjTphH_c\/",
      "display_url" : "instagram.com\/p\/zJLjTphH_c\/"
    } ]
  },
  "geo" : { },
  "id_str" : "567135208328409088",
  "text" : "RT @ducksandclucks: \"I will watch over and protect you now.\" - Romeo goose http:\/\/t.co\/MlMEJsorDf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/MlMEJsorDf",
        "expanded_url" : "http:\/\/instagram.com\/p\/zJLjTphH_c\/",
        "display_url" : "instagram.com\/p\/zJLjTphH_c\/"
      } ]
    },
    "geo" : { },
    "id_str" : "567131807045648384",
    "text" : "\"I will watch over and protect you now.\" - Romeo goose http:\/\/t.co\/MlMEJsorDf",
    "id" : 567131807045648384,
    "created_at" : "2015-02-16 01:22:14 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 567135208328409088,
  "created_at" : "2015-02-16 01:35:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bobjem",
      "screen_name" : "Kam11Bbc",
      "indices" : [ 3, 12 ],
      "id_str" : "569127372",
      "id" : 569127372
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kam11Bbc\/status\/567079381386809345\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/OYMncviJ5J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96rsPpCYAApcWr.jpg",
      "id_str" : "567079379696508928",
      "id" : 567079379696508928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96rsPpCYAApcWr.jpg",
      "sizes" : [ {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/OYMncviJ5J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567134847123357696",
  "text" : "RT @Kam11Bbc: http:\/\/t.co\/OYMncviJ5J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kam11Bbc\/status\/567079381386809345\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/OYMncviJ5J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B96rsPpCYAApcWr.jpg",
        "id_str" : "567079379696508928",
        "id" : 567079379696508928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96rsPpCYAApcWr.jpg",
        "sizes" : [ {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/OYMncviJ5J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567079381386809345",
    "text" : "http:\/\/t.co\/OYMncviJ5J",
    "id" : 567079381386809345,
    "created_at" : "2015-02-15 21:53:55 +0000",
    "user" : {
      "name" : "bobjem",
      "screen_name" : "Kam11Bbc",
      "protected" : false,
      "id_str" : "569127372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000060617738\/bf2811000fd78c3c65e3b4b4ab9bc11e_normal.jpeg",
      "id" : 569127372,
      "verified" : false
    }
  },
  "id" : 567134847123357696,
  "created_at" : "2015-02-16 01:34:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Palermo",
      "screen_name" : "tigresaa",
      "indices" : [ 3, 12 ],
      "id_str" : "18826638",
      "id" : 18826638
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tigresaa\/status\/567113644538753024\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/dStm2Rncfr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B97K2qnCUAA1Bg1.jpg",
      "id_str" : "567113643595026432",
      "id" : 567113643595026432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B97K2qnCUAA1Bg1.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dStm2Rncfr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567118508816101376",
  "text" : "RT @tigresaa: Saw a freaking bald eagle today up close. We named him Doug. He looks like a Doug. http:\/\/t.co\/dStm2Rncfr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tigresaa\/status\/567113644538753024\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/dStm2Rncfr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B97K2qnCUAA1Bg1.jpg",
        "id_str" : "567113643595026432",
        "id" : 567113643595026432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B97K2qnCUAA1Bg1.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dStm2Rncfr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567113644538753024",
    "text" : "Saw a freaking bald eagle today up close. We named him Doug. He looks like a Doug. http:\/\/t.co\/dStm2Rncfr",
    "id" : 567113644538753024,
    "created_at" : "2015-02-16 00:10:03 +0000",
    "user" : {
      "name" : "Stephanie Palermo",
      "screen_name" : "tigresaa",
      "protected" : false,
      "id_str" : "18826638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753089461156732928\/DlDzHOfI_normal.jpg",
      "id" : 18826638,
      "verified" : false
    }
  },
  "id" : 567118508816101376,
  "created_at" : "2015-02-16 00:29:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567076225127297024",
  "text" : "RT @RustBeltRebel: why are people boycotting 50 shades and calling it abusive, but duggars are still on the air?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567075758250934272",
    "text" : "why are people boycotting 50 shades and calling it abusive, but duggars are still on the air?",
    "id" : 567075758250934272,
    "created_at" : "2015-02-15 21:39:31 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 567076225127297024,
  "created_at" : "2015-02-15 21:41:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567028452231241728",
  "text" : "i think the stinkbug is my totem animal...",
  "id" : 567028452231241728,
  "created_at" : "2015-02-15 18:31:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/1L1XWrFjHz",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/110585962532856059731\/posts\/2Uqo5bAPNHp",
      "display_url" : "plus.google.com\/u\/0\/1105859625\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567028025267879936",
  "text" : "A vacuum was created characteristic of an implosion https:\/\/t.co\/1L1XWrFjHz",
  "id" : 567028025267879936,
  "created_at" : "2015-02-15 18:29:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.",
      "screen_name" : "wonderosa",
      "indices" : [ 3, 13 ],
      "id_str" : "14154188",
      "id" : 14154188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567025954191839232",
  "text" : "RT @wonderosa: I'm an introvert I have to mentally prepare myself to be around a group of people. I prefer one on one interaction \uD83D\uDE16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567021564500008960",
    "text" : "I'm an introvert I have to mentally prepare myself to be around a group of people. I prefer one on one interaction \uD83D\uDE16",
    "id" : 567021564500008960,
    "created_at" : "2015-02-15 18:04:10 +0000",
    "user" : {
      "name" : "A.",
      "screen_name" : "wonderosa",
      "protected" : false,
      "id_str" : "14154188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760502327308525568\/kRLIEZXa_normal.jpg",
      "id" : 14154188,
      "verified" : false
    }
  },
  "id" : 567025954191839232,
  "created_at" : "2015-02-15 18:21:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea",
      "screen_name" : "andrea_4520",
      "indices" : [ 3, 15 ],
      "id_str" : "2935453127",
      "id" : 2935453127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/andrea_4520\/status\/567015983513370624\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Zo95BCYXG4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B95yCF0IQAAa8ti.jpg",
      "id_str" : "567015983341387776",
      "id" : 567015983341387776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B95yCF0IQAAa8ti.jpg",
      "sizes" : [ {
        "h" : 1387,
        "resize" : "fit",
        "w" : 2046
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Zo95BCYXG4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567025851100041216",
  "text" : "RT @andrea_4520: http:\/\/t.co\/Zo95BCYXG4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andrea_4520\/status\/567015983513370624\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/Zo95BCYXG4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B95yCF0IQAAa8ti.jpg",
        "id_str" : "567015983341387776",
        "id" : 567015983341387776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B95yCF0IQAAa8ti.jpg",
        "sizes" : [ {
          "h" : 1387,
          "resize" : "fit",
          "w" : 2046
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Zo95BCYXG4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567015983513370624",
    "text" : "http:\/\/t.co\/Zo95BCYXG4",
    "id" : 567015983513370624,
    "created_at" : "2015-02-15 17:41:59 +0000",
    "user" : {
      "name" : "Andrea",
      "screen_name" : "andrea_4520",
      "protected" : false,
      "id_str" : "2935453127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765236763707248640\/YBHv4gev_normal.jpg",
      "id" : 2935453127,
      "verified" : false
    }
  },
  "id" : 567025851100041216,
  "created_at" : "2015-02-15 18:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Big Sigh",
      "screen_name" : "e1ais",
      "indices" : [ 74, 80 ],
      "id_str" : "794810444",
      "id" : 794810444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567022191221682178",
  "text" : "RT @ZachsMind: i been saying this for years! LOL No one listens to me! RT @e1ais: What science tells us about Adam and Eve.. http:\/\/t.co\/oF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Big Sigh",
        "screen_name" : "e1ais",
        "indices" : [ 59, 65 ],
        "id_str" : "794810444",
        "id" : 794810444
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/oFZVE5dbAN",
        "expanded_url" : "http:\/\/whyevolutionistrue.wordpress.com\/2011\/06\/02\/adam-and-eve-the-ultimate-standoff-between-science-and-faith-and-a-contest\/",
        "display_url" : "whyevolutionistrue.wordpress.com\/2011\/06\/02\/ada\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567018977369411584",
    "text" : "i been saying this for years! LOL No one listens to me! RT @e1ais: What science tells us about Adam and Eve.. http:\/\/t.co\/oFZVE5dbAN",
    "id" : 567018977369411584,
    "created_at" : "2015-02-15 17:53:53 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 567022191221682178,
  "created_at" : "2015-02-15 18:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567021878171430915",
  "text" : "RT @ZachsMind: sometimes i scan someone else's TL and I'm like \"this person is fucked up in the head\" then I realize this is how others may\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567020333807333376",
    "text" : "sometimes i scan someone else's TL and I'm like \"this person is fucked up in the head\" then I realize this is how others may feel about mine",
    "id" : 567020333807333376,
    "created_at" : "2015-02-15 17:59:16 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 567021878171430915,
  "created_at" : "2015-02-15 18:05:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 2, 12 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567020333807333376",
  "geo" : { },
  "id_str" : "567021636877295616",
  "in_reply_to_user_id" : 16181537,
  "text" : ". @ZachsMind lol.. i know many ppl think that about me. i need to accept that and follow my own path anyway.",
  "id" : 567021636877295616,
  "in_reply_to_status_id" : 567020333807333376,
  "created_at" : "2015-02-15 18:04:27 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Simon R R Atkins",
      "screen_name" : "DrSimonAtkins",
      "indices" : [ 3, 17 ],
      "id_str" : "262418358",
      "id" : 262418358
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Journalists",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "Dead",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "banker",
      "indices" : [ 113, 120 ]
    }, {
      "text" : "deaths",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/hUDQMnDt8x",
      "expanded_url" : "http:\/\/beforeitsnews.com\/alternative\/2015\/02\/four-american-journalists-dead-inside-the-us-within-24-hours-3107944.html?utm_source=direct-b4in.info&utm_medium=verticalresponse&utm_content=beforeit39snews-verticalresponse&utm_term=http%3A%2F%2Fb4in.info%2Fhk6R&utm_campaign=",
      "display_url" : "beforeitsnews.com\/alternative\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567001500434849792",
  "text" : "RT @DrSimonAtkins: Four American #Journalists #Dead Inside US Within 24 Hrs http:\/\/t.co\/hUDQMnDt8x Like the many #banker #deaths, it's more\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Journalists",
        "indices" : [ 14, 26 ]
      }, {
        "text" : "Dead",
        "indices" : [ 27, 32 ]
      }, {
        "text" : "banker",
        "indices" : [ 94, 101 ]
      }, {
        "text" : "deaths",
        "indices" : [ 102, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/hUDQMnDt8x",
        "expanded_url" : "http:\/\/beforeitsnews.com\/alternative\/2015\/02\/four-american-journalists-dead-inside-the-us-within-24-hours-3107944.html?utm_source=direct-b4in.info&utm_medium=verticalresponse&utm_content=beforeit39snews-verticalresponse&utm_term=http%3A%2F%2Fb4in.info%2Fhk6R&utm_campaign=",
        "display_url" : "beforeitsnews.com\/alternative\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566993823545696256",
    "text" : "Four American #Journalists #Dead Inside US Within 24 Hrs http:\/\/t.co\/hUDQMnDt8x Like the many #banker #deaths, it's more than a coincidence!",
    "id" : 566993823545696256,
    "created_at" : "2015-02-15 16:13:56 +0000",
    "user" : {
      "name" : "Dr Simon R R Atkins",
      "screen_name" : "DrSimonAtkins",
      "protected" : false,
      "id_str" : "262418358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727308573668171776\/GWfZTWm2_normal.jpg",
      "id" : 262418358,
      "verified" : false
    }
  },
  "id" : 567001500434849792,
  "created_at" : "2015-02-15 16:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "indices" : [ 3, 17 ],
      "id_str" : "487600344",
      "id" : 487600344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeaParty",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "UniteBlue",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566995374108573698",
  "text" : "RT @Bipartisanism: This #TeaParty patriot has both a pro life bumper sticker &amp; one saying honk and I'll kill you. #UniteBlue http:\/\/t.co\/SF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bipartisanism\/status\/566692694160728066\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/SFf07flVhl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B91MAAWCEAAvq0S.jpg",
        "id_str" : "566692691094671360",
        "id" : 566692691094671360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B91MAAWCEAAvq0S.jpg",
        "sizes" : [ {
          "h" : 854,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 854,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/SFf07flVhl"
      } ],
      "hashtags" : [ {
        "text" : "TeaParty",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "UniteBlue",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566692694160728066",
    "text" : "This #TeaParty patriot has both a pro life bumper sticker &amp; one saying honk and I'll kill you. #UniteBlue http:\/\/t.co\/SFf07flVhl",
    "id" : 566692694160728066,
    "created_at" : "2015-02-14 20:17:21 +0000",
    "user" : {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "protected" : false,
      "id_str" : "487600344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762863803138662408\/N3c5gIyD_normal.jpg",
      "id" : 487600344,
      "verified" : true
    }
  },
  "id" : 566995374108573698,
  "created_at" : "2015-02-15 16:20:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF77Denise\uD83C\uDF42",
      "screen_name" : "Dionysius1",
      "indices" : [ 3, 14 ],
      "id_str" : "47805845",
      "id" : 47805845
    }, {
      "name" : "Cineplex",
      "screen_name" : "CineplexMovies",
      "indices" : [ 21, 36 ],
      "id_str" : "13251272",
      "id" : 13251272
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CineplexMovies\/status\/566976542111457280\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lUeQjOR6bx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B95OKSCIQAEY0CM.png",
      "id_str" : "566976541641687041",
      "id" : 566976541641687041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B95OKSCIQAEY0CM.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lUeQjOR6bx"
    } ],
    "hashtags" : [ {
      "text" : "TheBreakfastClub",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BOAHIvKMiO",
      "expanded_url" : "http:\/\/cinplx.co\/1755CQG",
      "display_url" : "cinplx.co\/1755CQG"
    } ]
  },
  "geo" : { },
  "id_str" : "566985036105515009",
  "text" : "RT @Dionysius1: \uD83D\uDE0D RT @CineplexMovies: 30 years ago today, #TheBreakfastClub served detention http:\/\/t.co\/BOAHIvKMiO http:\/\/t.co\/lUeQjOR6bx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cineplex",
        "screen_name" : "CineplexMovies",
        "indices" : [ 5, 20 ],
        "id_str" : "13251272",
        "id" : 13251272
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CineplexMovies\/status\/566976542111457280\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/lUeQjOR6bx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B95OKSCIQAEY0CM.png",
        "id_str" : "566976541641687041",
        "id" : 566976541641687041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B95OKSCIQAEY0CM.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lUeQjOR6bx"
      } ],
      "hashtags" : [ {
        "text" : "TheBreakfastClub",
        "indices" : [ 42, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/BOAHIvKMiO",
        "expanded_url" : "http:\/\/cinplx.co\/1755CQG",
        "display_url" : "cinplx.co\/1755CQG"
      } ]
    },
    "geo" : { },
    "id_str" : "566977605534875648",
    "text" : "\uD83D\uDE0D RT @CineplexMovies: 30 years ago today, #TheBreakfastClub served detention http:\/\/t.co\/BOAHIvKMiO http:\/\/t.co\/lUeQjOR6bx",
    "id" : 566977605534875648,
    "created_at" : "2015-02-15 15:09:29 +0000",
    "user" : {
      "name" : "\uD83C\uDF77Denise\uD83C\uDF42",
      "screen_name" : "Dionysius1",
      "protected" : false,
      "id_str" : "47805845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794330819242299392\/JtEMMmQm_normal.jpg",
      "id" : 47805845,
      "verified" : false
    }
  },
  "id" : 566985036105515009,
  "created_at" : "2015-02-15 15:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/O4hW5pNwuO",
      "expanded_url" : "http:\/\/youtu.be\/BxKCX-UvPrI",
      "display_url" : "youtu.be\/BxKCX-UvPrI"
    } ]
  },
  "geo" : { },
  "id_str" : "566762274770399232",
  "text" : "just watched this &gt; The Trail to Oregon!: http:\/\/t.co\/O4hW5pNwuO",
  "id" : 566762274770399232,
  "created_at" : "2015-02-15 00:53:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/566642341784477696\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/UmbIbdXNJe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B90eLYXCYAAq2wy.jpg",
      "id_str" : "566642308985020416",
      "id" : 566642308985020416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90eLYXCYAAq2wy.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UmbIbdXNJe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/566642341784477696\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/UmbIbdXNJe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B90eLYXCcAAYtYS.jpg",
      "id_str" : "566642308985024512",
      "id" : 566642308985024512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90eLYXCcAAYtYS.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UmbIbdXNJe"
    } ],
    "hashtags" : [ {
      "text" : "Nebraska",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566678161837264898",
  "text" : "RT @rm123077: Wild Turkeys-Wildcat Hills #Nebraska http:\/\/t.co\/UmbIbdXNJe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/566642341784477696\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/UmbIbdXNJe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B90eLYXCYAAq2wy.jpg",
        "id_str" : "566642308985020416",
        "id" : 566642308985020416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90eLYXCYAAq2wy.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UmbIbdXNJe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/566642341784477696\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/UmbIbdXNJe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B90eLYXCcAAYtYS.jpg",
        "id_str" : "566642308985024512",
        "id" : 566642308985024512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90eLYXCcAAYtYS.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UmbIbdXNJe"
      } ],
      "hashtags" : [ {
        "text" : "Nebraska",
        "indices" : [ 27, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566642341784477696",
    "text" : "Wild Turkeys-Wildcat Hills #Nebraska http:\/\/t.co\/UmbIbdXNJe",
    "id" : 566642341784477696,
    "created_at" : "2015-02-14 16:57:16 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 566678161837264898,
  "created_at" : "2015-02-14 19:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Illuminated Slave",
      "screen_name" : "LuminatedSlave",
      "indices" : [ 3, 18 ],
      "id_str" : "552367548",
      "id" : 552367548
    }, {
      "name" : "GRTV\/GlobalResearch",
      "screen_name" : "GRTVnews",
      "indices" : [ 110, 119 ],
      "id_str" : "128636277",
      "id" : 128636277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Ql4WRXt72W",
      "expanded_url" : "http:\/\/shar.es\/1oSYGu",
      "display_url" : "shar.es\/1oSYGu"
    } ]
  },
  "geo" : { },
  "id_str" : "566666045965221890",
  "text" : "RT @LuminatedSlave: HSBC Documents Reveal Criminal Conspiracy of Banks and Governments http:\/\/t.co\/Ql4WRXt72W @grtvnews http:\/\/t.co\/30ODelD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GRTV\/GlobalResearch",
        "screen_name" : "GRTVnews",
        "indices" : [ 90, 99 ],
        "id_str" : "128636277",
        "id" : 128636277
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LuminatedSlave\/status\/566361814527524864\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/30ODelDAUa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wfEc2CIAAsGwF.jpg",
        "id_str" : "566361814464602112",
        "id" : 566361814464602112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wfEc2CIAAsGwF.jpg",
        "sizes" : [ {
          "h" : 468,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 469
        } ],
        "display_url" : "pic.twitter.com\/30ODelDAUa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Ql4WRXt72W",
        "expanded_url" : "http:\/\/shar.es\/1oSYGu",
        "display_url" : "shar.es\/1oSYGu"
      } ]
    },
    "geo" : { },
    "id_str" : "566361814527524864",
    "text" : "HSBC Documents Reveal Criminal Conspiracy of Banks and Governments http:\/\/t.co\/Ql4WRXt72W @grtvnews http:\/\/t.co\/30ODelDAUa",
    "id" : 566361814527524864,
    "created_at" : "2015-02-13 22:22:33 +0000",
    "user" : {
      "name" : "Illuminated Slave",
      "screen_name" : "LuminatedSlave",
      "protected" : false,
      "id_str" : "552367548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2165629783\/libertyavatar2fs0_normal.jpg",
      "id" : 552367548,
      "verified" : false
    }
  },
  "id" : 566666045965221890,
  "created_at" : "2015-02-14 18:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566472233271705600",
  "geo" : { },
  "id_str" : "566638724063461377",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous : ((( (from what you've posted before, i bet mom was involved) ((hugs))",
  "id" : 566638724063461377,
  "in_reply_to_status_id" : 566472233271705600,
  "created_at" : "2015-02-14 16:42:54 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566633497541234688",
  "geo" : { },
  "id_str" : "566637096883224576",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe did his phone finally make it to your house?",
  "id" : 566637096883224576,
  "in_reply_to_status_id" : 566633497541234688,
  "created_at" : "2015-02-14 16:36:26 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/566617167693893632\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/hWKpQZ16LJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B90HT6YIMAEHUUg.jpg",
      "id_str" : "566617166787915777",
      "id" : 566617166787915777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90HT6YIMAEHUUg.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 236
      } ],
      "display_url" : "pic.twitter.com\/hWKpQZ16LJ"
    } ],
    "hashtags" : [ {
      "text" : "HappyValentinesDay",
      "indices" : [ 44, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566636004501913600",
  "text" : "RT @CatFoodBreath: It's a bed AND a snack.  #HappyValentinesDay http:\/\/t.co\/hWKpQZ16LJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/566617167693893632\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/hWKpQZ16LJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B90HT6YIMAEHUUg.jpg",
        "id_str" : "566617166787915777",
        "id" : 566617166787915777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90HT6YIMAEHUUg.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 236
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 236
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 236
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 236
        } ],
        "display_url" : "pic.twitter.com\/hWKpQZ16LJ"
      } ],
      "hashtags" : [ {
        "text" : "HappyValentinesDay",
        "indices" : [ 25, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566617167693893632",
    "text" : "It's a bed AND a snack.  #HappyValentinesDay http:\/\/t.co\/hWKpQZ16LJ",
    "id" : 566617167693893632,
    "created_at" : "2015-02-14 15:17:14 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 566636004501913600,
  "created_at" : "2015-02-14 16:32:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moose Allain",
      "screen_name" : "MooseAllain",
      "indices" : [ 3, 15 ],
      "id_str" : "23993642",
      "id" : 23993642
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MooseAllain\/status\/566543689213022209\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/U0oF76wLe5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9zEe2tIAAAqOhS.jpg",
      "id_str" : "566543687501742080",
      "id" : 566543687501742080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9zEe2tIAAAqOhS.jpg",
      "sizes" : [ {
        "h" : 1408,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/U0oF76wLe5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566631716534894592",
  "text" : "RT @MooseAllain: The first sign\u2026 http:\/\/t.co\/U0oF76wLe5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MooseAllain\/status\/566543689213022209\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/U0oF76wLe5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9zEe2tIAAAqOhS.jpg",
        "id_str" : "566543687501742080",
        "id" : 566543687501742080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9zEe2tIAAAqOhS.jpg",
        "sizes" : [ {
          "h" : 1408,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/U0oF76wLe5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566543689213022209",
    "text" : "The first sign\u2026 http:\/\/t.co\/U0oF76wLe5",
    "id" : 566543689213022209,
    "created_at" : "2015-02-14 10:25:16 +0000",
    "user" : {
      "name" : "Moose Allain",
      "screen_name" : "MooseAllain",
      "protected" : false,
      "id_str" : "23993642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614716316906311680\/z2KRCmeV_normal.jpg",
      "id" : 23993642,
      "verified" : false
    }
  },
  "id" : 566631716534894592,
  "created_at" : "2015-02-14 16:15:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566397397224652800",
  "text" : "you're talking apples and they're thinking in oranges. there is no communication going on.",
  "id" : 566397397224652800,
  "created_at" : "2015-02-14 00:43:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred O'Donnell",
      "screen_name" : "fred_od_photo",
      "indices" : [ 3, 17 ],
      "id_str" : "490232734",
      "id" : 490232734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "nature",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "photography",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566387488739328001",
  "text" : "RT @fred_od_photo: You would think this pair knew it was Valentine's Day.\nSuperb Fairy-wrens\n#birds #nature #photography http:\/\/t.co\/yFd9FE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fred_od_photo\/status\/566334677586178048\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/yFd9FEN9Yy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wGXzsCEAAydCJ.jpg",
        "id_str" : "566334659223490560",
        "id" : 566334659223490560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wGXzsCEAAydCJ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yFd9FEN9Yy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/fred_od_photo\/status\/566334677586178048\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/yFd9FEN9Yy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wGX0-CIAAoM1R.jpg",
        "id_str" : "566334659567427584",
        "id" : 566334659567427584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wGX0-CIAAoM1R.jpg",
        "sizes" : [ {
          "h" : 1581,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 791,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yFd9FEN9Yy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/fred_od_photo\/status\/566334677586178048\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/yFd9FEN9Yy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wGYtlCAAEmhb9.jpg",
        "id_str" : "566334674763382785",
        "id" : 566334674763382785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wGYtlCAAEmhb9.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yFd9FEN9Yy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/fred_od_photo\/status\/566334677586178048\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/yFd9FEN9Yy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wGYwCCUAEHvRW.jpg",
        "id_str" : "566334675421908993",
        "id" : 566334675421908993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wGYwCCUAEHvRW.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yFd9FEN9Yy"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 74, 80 ]
      }, {
        "text" : "nature",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "photography",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566334677586178048",
    "text" : "You would think this pair knew it was Valentine's Day.\nSuperb Fairy-wrens\n#birds #nature #photography http:\/\/t.co\/yFd9FEN9Yy",
    "id" : 566334677586178048,
    "created_at" : "2015-02-13 20:34:43 +0000",
    "user" : {
      "name" : "Fred O'Donnell",
      "screen_name" : "fred_od_photo",
      "protected" : false,
      "id_str" : "490232734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000414226331\/32364109846fcd2fd06e4f4f76321bfd_normal.jpeg",
      "id" : 490232734,
      "verified" : false
    }
  },
  "id" : 566387488739328001,
  "created_at" : "2015-02-14 00:04:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 0, 15 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566019592523632640",
  "geo" : { },
  "id_str" : "566375183926427648",
  "in_reply_to_user_id" : 2954308119,
  "text" : "@BruceGerencser you're new \"cat\" is adorable. we feed our wildlife, too. i love it when possum stops by.",
  "id" : 566375183926427648,
  "in_reply_to_status_id" : 566019592523632640,
  "created_at" : "2015-02-13 23:15:41 +0000",
  "in_reply_to_screen_name" : "BruceGerencser",
  "in_reply_to_user_id_str" : "2954308119",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566315774588223488",
  "text" : "9 doves at the feeder! watched for a minute or 2 then thought: take a pic. get cam.. they're gone. arggh.",
  "id" : 566315774588223488,
  "created_at" : "2015-02-13 19:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/564459661626056704\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/OBfOhmEwFH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9VdElBCAAEetKx.png",
      "id_str" : "564459661542162433",
      "id" : 564459661542162433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9VdElBCAAEetKx.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 483
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 483
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 483
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/OBfOhmEwFH"
    } ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/JqUrgxkR4A",
      "expanded_url" : "http:\/\/bit.ly\/1zloJgc",
      "display_url" : "bit.ly\/1zloJgc"
    } ]
  },
  "geo" : { },
  "id_str" : "566310686624845824",
  "text" : "RT @BooksOnTheKnob: http:\/\/t.co\/JqUrgxkR4A Valentine's Day #Kindle Sale http:\/\/t.co\/OBfOhmEwFH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blog.booksontheknob.org\/\" rel=\"nofollow\"\u003EBooksOnTheKnob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/564459661626056704\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/OBfOhmEwFH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9VdElBCAAEetKx.png",
        "id_str" : "564459661542162433",
        "id" : 564459661542162433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9VdElBCAAEetKx.png",
        "sizes" : [ {
          "h" : 334,
          "resize" : "fit",
          "w" : 483
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 483
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 483
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/OBfOhmEwFH"
      } ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/JqUrgxkR4A",
        "expanded_url" : "http:\/\/bit.ly\/1zloJgc",
        "display_url" : "bit.ly\/1zloJgc"
      } ]
    },
    "geo" : { },
    "id_str" : "564459661626056704",
    "text" : "http:\/\/t.co\/JqUrgxkR4A Valentine's Day #Kindle Sale http:\/\/t.co\/OBfOhmEwFH",
    "id" : 564459661626056704,
    "created_at" : "2015-02-08 16:24:05 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 566310686624845824,
  "created_at" : "2015-02-13 18:59:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CG",
      "screen_name" : "acuriousgal1",
      "indices" : [ 3, 16 ],
      "id_str" : "2293715275",
      "id" : 2293715275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 120, 126 ]
    }, {
      "text" : "nature",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566309643849592832",
  "text" : "RT @acuriousgal1: Doesn't matter how close you get, Mr. Nuthatch, you're not going to hear anything from this Cardinal\uD83D\uDE02 #birds, #nature htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/acuriousgal1\/status\/566308565598494720\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3HAu99Zr8B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vuottIcAAB9jB.jpg",
        "id_str" : "566308561396199424",
        "id" : 566308561396199424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vuottIcAAB9jB.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3HAu99Zr8B"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "nature",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566308565598494720",
    "text" : "Doesn't matter how close you get, Mr. Nuthatch, you're not going to hear anything from this Cardinal\uD83D\uDE02 #birds, #nature http:\/\/t.co\/3HAu99Zr8B",
    "id" : 566308565598494720,
    "created_at" : "2015-02-13 18:50:58 +0000",
    "user" : {
      "name" : "CG",
      "screen_name" : "acuriousgal1",
      "protected" : false,
      "id_str" : "2293715275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676589567500095488\/jI9wzTBE_normal.jpg",
      "id" : 2293715275,
      "verified" : false
    }
  },
  "id" : 566309643849592832,
  "created_at" : "2015-02-13 18:55:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Darnell",
      "screen_name" : "andydarnell",
      "indices" : [ 3, 15 ],
      "id_str" : "16982281",
      "id" : 16982281
    }, {
      "name" : "Jonathan Nesbitt",
      "screen_name" : "jonnynezbo",
      "indices" : [ 20, 31 ],
      "id_str" : "17156174",
      "id" : 17156174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/1I69JuHVfT",
      "expanded_url" : "http:\/\/pockettokindle.slingput.com",
      "display_url" : "pockettokindle.slingput.com"
    } ]
  },
  "geo" : { },
  "id_str" : "566308402885038085",
  "text" : "RT @andydarnell: RT @jonnynezbo: You can sign up here to stay informed about my new product Pocket to Kindle http:\/\/t.co\/1I69JuHVfT (cc:@ad\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Nesbitt",
        "screen_name" : "jonnynezbo",
        "indices" : [ 3, 14 ],
        "id_str" : "17156174",
        "id" : 17156174
      }, {
        "name" : "Adam Shields",
        "screen_name" : "adamrshields",
        "indices" : [ 119, 132 ],
        "id_str" : "14835882",
        "id" : 14835882
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/1I69JuHVfT",
        "expanded_url" : "http:\/\/pockettokindle.slingput.com",
        "display_url" : "pockettokindle.slingput.com"
      } ]
    },
    "geo" : { },
    "id_str" : "562279842910339072",
    "text" : "RT @jonnynezbo: You can sign up here to stay informed about my new product Pocket to Kindle http:\/\/t.co\/1I69JuHVfT (cc:@adamrshields)",
    "id" : 562279842910339072,
    "created_at" : "2015-02-02 16:02:15 +0000",
    "user" : {
      "name" : "Andy Darnell",
      "screen_name" : "andydarnell",
      "protected" : false,
      "id_str" : "16982281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775518187928576000\/mrFKLant_normal.jpg",
      "id" : 16982281,
      "verified" : false
    }
  },
  "id" : 566308402885038085,
  "created_at" : "2015-02-13 18:50:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "indices" : [ 3, 15 ],
      "id_str" : "60642052",
      "id" : 60642052
    }, {
      "name" : "Emil Protalinski",
      "screen_name" : "EPro",
      "indices" : [ 95, 100 ],
      "id_str" : "46709686",
      "id" : 46709686
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VentureBeat\/status\/566303299876696064\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FxxoJ5iGZF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vp2ceIUAEsQXy.png",
      "id_str" : "566303299729903617",
      "id" : 566303299729903617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vp2ceIUAEsQXy.png",
      "sizes" : [ {
        "h" : 309,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FxxoJ5iGZF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/5KpLCKE6Uh",
      "expanded_url" : "http:\/\/wp.me\/p5hvhT-6YdG",
      "display_url" : "wp.me\/p5hvhT-6YdG"
    } ]
  },
  "geo" : { },
  "id_str" : "566307810489929728",
  "text" : "RT @VentureBeat: Microsoft makes OneNote for Windows completely free http:\/\/t.co\/5KpLCKE6Uh by @EPro http:\/\/t.co\/FxxoJ5iGZF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/venturebeat.com\" rel=\"nofollow\"\u003EVentureBeat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emil Protalinski",
        "screen_name" : "EPro",
        "indices" : [ 78, 83 ],
        "id_str" : "46709686",
        "id" : 46709686
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VentureBeat\/status\/566303299876696064\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/FxxoJ5iGZF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vp2ceIUAEsQXy.png",
        "id_str" : "566303299729903617",
        "id" : 566303299729903617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vp2ceIUAEsQXy.png",
        "sizes" : [ {
          "h" : 309,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 135,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FxxoJ5iGZF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5KpLCKE6Uh",
        "expanded_url" : "http:\/\/wp.me\/p5hvhT-6YdG",
        "display_url" : "wp.me\/p5hvhT-6YdG"
      } ]
    },
    "geo" : { },
    "id_str" : "566303299876696064",
    "text" : "Microsoft makes OneNote for Windows completely free http:\/\/t.co\/5KpLCKE6Uh by @EPro http:\/\/t.co\/FxxoJ5iGZF",
    "id" : 566303299876696064,
    "created_at" : "2015-02-13 18:30:02 +0000",
    "user" : {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "protected" : false,
      "id_str" : "60642052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615577992815882240\/Iap3Di46_normal.png",
      "id" : 60642052,
      "verified" : true
    }
  },
  "id" : 566307810489929728,
  "created_at" : "2015-02-13 18:47:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom McFarlin",
      "screen_name" : "tommcfarlin",
      "indices" : [ 3, 15 ],
      "id_str" : "85808180",
      "id" : 85808180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566307787173814272",
  "text" : "RT @tommcfarlin: mayer for #wordpress is now open source and available on github. here's *all* the rationale as to why: https:\/\/t.co\/08XJtg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wordpress",
        "indices" : [ 10, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/08XJtgk3t9",
        "expanded_url" : "https:\/\/tommcfarlin.com\/mayer-for-wordpress-now-on-github\/",
        "display_url" : "tommcfarlin.com\/mayer-for-word\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566305616814436353",
    "text" : "mayer for #wordpress is now open source and available on github. here's *all* the rationale as to why: https:\/\/t.co\/08XJtgk3t9",
    "id" : 566305616814436353,
    "created_at" : "2015-02-13 18:39:15 +0000",
    "user" : {
      "name" : "Tom McFarlin",
      "screen_name" : "tommcfarlin",
      "protected" : false,
      "id_str" : "85808180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798595840478740480\/G_qKCCao_normal.jpg",
      "id" : 85808180,
      "verified" : true
    }
  },
  "id" : 566307787173814272,
  "created_at" : "2015-02-13 18:47:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566296944243662849",
  "text" : "RT @Swanwhisperer: SwanWatch Needs Your Help - If you have seen any Mute Swan  Courtship\/Mating or even Building Nests, or Chasing Swans ou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566296406546079744",
    "text" : "SwanWatch Needs Your Help - If you have seen any Mute Swan  Courtship\/Mating or even Building Nests, or Chasing Swans out , tweet me!",
    "id" : 566296406546079744,
    "created_at" : "2015-02-13 18:02:39 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 566296944243662849,
  "created_at" : "2015-02-13 18:04:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566280068805427201",
  "text" : "RT @mikemchargue: Love your enemies is one thing, but what about those close-minded conservatives? Or those Godless liberals? http:\/\/t.co\/p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/pwmpbnLni8",
        "expanded_url" : "http:\/\/mikemchargue.com\/blog\/2015\/2\/13\/brother-against-brother",
        "display_url" : "mikemchargue.com\/blog\/2015\/2\/13\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566259097369313280",
    "text" : "Love your enemies is one thing, but what about those close-minded conservatives? Or those Godless liberals? http:\/\/t.co\/pwmpbnLni8",
    "id" : 566259097369313280,
    "created_at" : "2015-02-13 15:34:24 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 566280068805427201,
  "created_at" : "2015-02-13 16:57:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566280031048327168",
  "text" : "RT @mikemchargue: 2 to the 5.65th power shades of grey. All this fuss over less than 8 bit grayscale.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566007019757633538",
    "text" : "2 to the 5.65th power shades of grey. All this fuss over less than 8 bit grayscale.",
    "id" : 566007019757633538,
    "created_at" : "2015-02-12 22:52:44 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 566280031048327168,
  "created_at" : "2015-02-13 16:57:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/6nAssKxAZd",
      "expanded_url" : "http:\/\/qvotr.com\/quote\/2314",
      "display_url" : "qvotr.com\/quote\/2314"
    } ]
  },
  "geo" : { },
  "id_str" : "566279648838160384",
  "text" : "\"No matter how enlightened I (or anyone) may feel, no matter how careful I've con...\" http:\/\/t.co\/6nAssKxAZd",
  "id" : 566279648838160384,
  "created_at" : "2015-02-13 16:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/540236143582011392\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/WtaFG8yGxY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B39N6L0CUAA2u98.jpg",
      "id_str" : "540236142306545664",
      "id" : 540236142306545664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B39N6L0CUAA2u98.jpg",
      "sizes" : [ {
        "h" : 367,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WtaFG8yGxY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566061115000778752",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/WtaFG8yGxY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/540236143582011392\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/WtaFG8yGxY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B39N6L0CUAA2u98.jpg",
        "id_str" : "540236142306545664",
        "id" : 540236142306545664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B39N6L0CUAA2u98.jpg",
        "sizes" : [ {
          "h" : 367,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WtaFG8yGxY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566049131006009344",
    "text" : "http:\/\/t.co\/WtaFG8yGxY",
    "id" : 566049131006009344,
    "created_at" : "2015-02-13 01:40:04 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 566061115000778752,
  "created_at" : "2015-02-13 02:27:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565971519629950977",
  "text" : "RT @mikemchargue: If you launch a podcast about science &amp; faith, expect to get a lot of questions about sex and marijuana.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565969523657158657",
    "text" : "If you launch a podcast about science &amp; faith, expect to get a lot of questions about sex and marijuana.",
    "id" : 565969523657158657,
    "created_at" : "2015-02-12 20:23:44 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 565971519629950977,
  "created_at" : "2015-02-12 20:31:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birdwatch Mayo",
      "screen_name" : "BirdwatchMayo",
      "indices" : [ 3, 17 ],
      "id_str" : "211879296",
      "id" : 211879296
    }, {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 57, 73 ],
      "id_str" : "175204121",
      "id" : 175204121
    }, {
      "name" : "iCatcher Wildlife",
      "screen_name" : "iCatcherWild",
      "indices" : [ 123, 136 ],
      "id_str" : "282050528",
      "id" : 282050528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/1GqUNdv2VR",
      "expanded_url" : "http:\/\/wildlifegadgetman.com\/live-cams\/live-stream-1\/",
      "display_url" : "wildlifegadgetman.com\/live-cams\/live\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565971446246408192",
  "text" : "RT @BirdwatchMayo: Better than watching TV &amp; so cute @WildlifeGadgets : FIVE squirrels sleeping http:\/\/t.co\/1GqUNdv2VR @iCatcherWild http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Gadget Man",
        "screen_name" : "WildlifeGadgets",
        "indices" : [ 38, 54 ],
        "id_str" : "175204121",
        "id" : 175204121
      }, {
        "name" : "iCatcher Wildlife",
        "screen_name" : "iCatcherWild",
        "indices" : [ 104, 117 ],
        "id_str" : "282050528",
        "id" : 282050528
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/565926943229755393\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jtU9PSETrr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9qTflUIIAEm0Oj.jpg",
        "id_str" : "565926873990176769",
        "id" : 565926873990176769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9qTflUIIAEm0Oj.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/jtU9PSETrr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/1GqUNdv2VR",
        "expanded_url" : "http:\/\/wildlifegadgetman.com\/live-cams\/live-stream-1\/",
        "display_url" : "wildlifegadgetman.com\/live-cams\/live\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565960693950992384",
    "text" : "Better than watching TV &amp; so cute @WildlifeGadgets : FIVE squirrels sleeping http:\/\/t.co\/1GqUNdv2VR @iCatcherWild http:\/\/t.co\/jtU9PSETrr\"",
    "id" : 565960693950992384,
    "created_at" : "2015-02-12 19:48:39 +0000",
    "user" : {
      "name" : "Birdwatch Mayo",
      "screen_name" : "BirdwatchMayo",
      "protected" : false,
      "id_str" : "211879296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2199130543\/MayoLogo_TF_normal.jpg",
      "id" : 211879296,
      "verified" : false
    }
  },
  "id" : 565971446246408192,
  "created_at" : "2015-02-12 20:31:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 3, 15 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "Bram Kanstein \u270C\uFE0F\uFE0F",
      "screen_name" : "bramk",
      "indices" : [ 102, 108 ],
      "id_str" : "45139007",
      "id" : 45139007
    }, {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 112, 124 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/1utIL9iCxA",
      "expanded_url" : "http:\/\/www.producthunt.com\/posts\/revue",
      "display_url" : "producthunt.com\/posts\/revue"
    } ]
  },
  "geo" : { },
  "id_str" : "565916042166554624",
  "text" : "RT @ProductHunt: Revue: Easily create an engaging, gorgeous, weekly digest http:\/\/t.co\/1utIL9iCxA via @bramk on @producthunt http:\/\/t.co\/WG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bram Kanstein \u270C\uFE0F\uFE0F",
        "screen_name" : "bramk",
        "indices" : [ 85, 91 ],
        "id_str" : "45139007",
        "id" : 45139007
      }, {
        "name" : "Product Hunt",
        "screen_name" : "ProductHunt",
        "indices" : [ 95, 107 ],
        "id_str" : "2208027565",
        "id" : 2208027565
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ProductHunt\/status\/565837915876769792\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/WGxUeu44Kc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9pCliDIIAAbQgc.png",
        "id_str" : "565837915750932480",
        "id" : 565837915750932480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9pCliDIIAAbQgc.png",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1037,
          "resize" : "fit",
          "w" : 1480
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WGxUeu44Kc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/1utIL9iCxA",
        "expanded_url" : "http:\/\/www.producthunt.com\/posts\/revue",
        "display_url" : "producthunt.com\/posts\/revue"
      } ]
    },
    "geo" : { },
    "id_str" : "565837915876769792",
    "text" : "Revue: Easily create an engaging, gorgeous, weekly digest http:\/\/t.co\/1utIL9iCxA via @bramk on @producthunt http:\/\/t.co\/WGxUeu44Kc",
    "id" : 565837915876769792,
    "created_at" : "2015-02-12 11:40:46 +0000",
    "user" : {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "protected" : false,
      "id_str" : "2208027565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783677864831021057\/fNU8i_FW_normal.jpg",
      "id" : 2208027565,
      "verified" : true
    }
  },
  "id" : 565916042166554624,
  "created_at" : "2015-02-12 16:51:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gramma@Gladys Hamnet",
      "screen_name" : "GladysHamnett",
      "indices" : [ 3, 17 ],
      "id_str" : "2914932391",
      "id" : 2914932391
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GladysHamnett\/status\/565892706086289409\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/BA28eA3UJY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p0arICIAExaFu.jpg",
      "id_str" : "565892704790257665",
      "id" : 565892704790257665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p0arICIAExaFu.jpg",
      "sizes" : [ {
        "h" : 325,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 425
      } ],
      "display_url" : "pic.twitter.com\/BA28eA3UJY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565900853765484544",
  "text" : "RT @GladysHamnett: http:\/\/t.co\/BA28eA3UJY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GladysHamnett\/status\/565892706086289409\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/BA28eA3UJY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p0arICIAExaFu.jpg",
        "id_str" : "565892704790257665",
        "id" : 565892704790257665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p0arICIAExaFu.jpg",
        "sizes" : [ {
          "h" : 325,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 425
        } ],
        "display_url" : "pic.twitter.com\/BA28eA3UJY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565892706086289409",
    "text" : "http:\/\/t.co\/BA28eA3UJY",
    "id" : 565892706086289409,
    "created_at" : "2015-02-12 15:18:29 +0000",
    "user" : {
      "name" : "Gramma@Gladys Hamnet",
      "screen_name" : "GladysHamnett",
      "protected" : false,
      "id_str" : "2914932391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570588322013138944\/6hoEPXMx_normal.jpeg",
      "id" : 2914932391,
      "verified" : false
    }
  },
  "id" : 565900853765484544,
  "created_at" : "2015-02-12 15:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Lorber",
      "screen_name" : "LorberAmit",
      "indices" : [ 3, 14 ],
      "id_str" : "2748856046",
      "id" : 2748856046
    }, {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "indices" : [ 81, 91 ],
      "id_str" : "194209267",
      "id" : 194209267
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LorberAmit\/status\/565894374530105345\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Yhy9CmJxwO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p16NNCAAAsCHV.jpg",
      "id_str" : "565894346025598976",
      "id" : 565894346025598976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p16NNCAAAsCHV.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Yhy9CmJxwO"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/LorberAmit\/status\/565894374530105345\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Yhy9CmJxwO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p16NkCQAEhxu9.jpg",
      "id_str" : "565894346122084353",
      "id" : 565894346122084353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p16NkCQAEhxu9.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Yhy9CmJxwO"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/LorberAmit\/status\/565894374530105345\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Yhy9CmJxwO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p16NVCQAAocjY.jpg",
      "id_str" : "565894346059169792",
      "id" : 565894346059169792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p16NVCQAAocjY.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Yhy9CmJxwO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565900465209348096",
  "text" : "RT @LorberAmit: I got a little crazy last night and made some 'Heart Bookmarks'! @EpicReads http:\/\/t.co\/Yhy9CmJxwO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Epic Reads",
        "screen_name" : "EpicReads",
        "indices" : [ 65, 75 ],
        "id_str" : "194209267",
        "id" : 194209267
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LorberAmit\/status\/565894374530105345\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/Yhy9CmJxwO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p16NNCAAAsCHV.jpg",
        "id_str" : "565894346025598976",
        "id" : 565894346025598976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p16NNCAAAsCHV.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Yhy9CmJxwO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/LorberAmit\/status\/565894374530105345\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/Yhy9CmJxwO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p16NkCQAEhxu9.jpg",
        "id_str" : "565894346122084353",
        "id" : 565894346122084353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p16NkCQAEhxu9.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Yhy9CmJxwO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/LorberAmit\/status\/565894374530105345\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/Yhy9CmJxwO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p16NVCQAAocjY.jpg",
        "id_str" : "565894346059169792",
        "id" : 565894346059169792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p16NVCQAAocjY.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Yhy9CmJxwO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565894374530105345",
    "text" : "I got a little crazy last night and made some 'Heart Bookmarks'! @EpicReads http:\/\/t.co\/Yhy9CmJxwO",
    "id" : 565894374530105345,
    "created_at" : "2015-02-12 15:25:07 +0000",
    "user" : {
      "name" : "Amit Lorber",
      "screen_name" : "LorberAmit",
      "protected" : false,
      "id_str" : "2748856046",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502065485303648256\/xubeUq7X_normal.jpeg",
      "id" : 2748856046,
      "verified" : false
    }
  },
  "id" : 565900465209348096,
  "created_at" : "2015-02-12 15:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrinceRupert",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565900310670245888",
  "text" : "RT @ScarlettWulf: They go around eating the Nuts and Seeds. Even saw one trying to nibble a Bird cake this morning! #PrinceRupert http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/565198309682196482\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/to6Qdl4mt9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9f814MCMAEMAiY.jpg",
        "id_str" : "565198280804413441",
        "id" : 565198280804413441,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9f814MCMAEMAiY.jpg",
        "sizes" : [ {
          "h" : 607,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/to6Qdl4mt9"
      } ],
      "hashtags" : [ {
        "text" : "PrinceRupert",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565198309682196482",
    "text" : "They go around eating the Nuts and Seeds. Even saw one trying to nibble a Bird cake this morning! #PrinceRupert http:\/\/t.co\/to6Qdl4mt9",
    "id" : 565198309682196482,
    "created_at" : "2015-02-10 17:19:12 +0000",
    "user" : {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "protected" : false,
      "id_str" : "1348108910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741919775668867072\/yzqHRx03_normal.jpg",
      "id" : 1348108910,
      "verified" : false
    }
  },
  "id" : 565900310670245888,
  "created_at" : "2015-02-12 15:48:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/BBVsrfRUuE",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/wash-twice-using-entire-sanctification\/",
      "display_url" : "brucegerencser.net\/2015\/02\/wash-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565649347799678976",
  "text" : "Wash Twice Before Using: Entire Sanctification http:\/\/t.co\/BBVsrfRUuE",
  "id" : 565649347799678976,
  "created_at" : "2015-02-11 23:11:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Frei",
      "screen_name" : "AdamFrei",
      "indices" : [ 3, 12 ],
      "id_str" : "539367154",
      "id" : 539367154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565635031138590720",
  "text" : "RT @AdamFrei: The highest wisdom\nis kindness.\n~Brakhot 17a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565618890529837057",
    "text" : "The highest wisdom\nis kindness.\n~Brakhot 17a",
    "id" : 565618890529837057,
    "created_at" : "2015-02-11 21:10:26 +0000",
    "user" : {
      "name" : "Adam Frei",
      "screen_name" : "AdamFrei",
      "protected" : false,
      "id_str" : "539367154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000087054789\/ac654eb6ceacfb872f3ff9d1f9187777_normal.jpeg",
      "id" : 539367154,
      "verified" : false
    }
  },
  "id" : 565635031138590720,
  "created_at" : "2015-02-11 22:14:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ificouldtellu\/status\/565591056792973313\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/z4ff5m9Ehy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9liEbsIAAIYd2x.jpg",
      "id_str" : "565591056503537666",
      "id" : 565591056503537666,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9liEbsIAAIYd2x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/z4ff5m9Ehy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565592986726461440",
  "text" : "RT @ificouldtellu: http:\/\/t.co\/z4ff5m9Ehy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ificouldtellu\/status\/565591056792973313\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/z4ff5m9Ehy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9liEbsIAAIYd2x.jpg",
        "id_str" : "565591056503537666",
        "id" : 565591056503537666,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9liEbsIAAIYd2x.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/z4ff5m9Ehy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565591056792973313",
    "text" : "http:\/\/t.co\/z4ff5m9Ehy",
    "id" : 565591056792973313,
    "created_at" : "2015-02-11 19:19:50 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 565592986726461440,
  "created_at" : "2015-02-11 19:27:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fearfuldogs\/status\/565591131141201922\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/hOp5fdjH2e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9liIt1CIAADfJL.jpg",
      "id_str" : "565591130092216320",
      "id" : 565591130092216320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9liIt1CIAADfJL.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hOp5fdjH2e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565592913405808641",
  "text" : "RT @fearfuldogs: We do not reinforce fear in dogs when we do something that makes them feel better. http:\/\/t.co\/hOp5fdjH2e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fearfuldogs\/status\/565591131141201922\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/hOp5fdjH2e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9liIt1CIAADfJL.jpg",
        "id_str" : "565591130092216320",
        "id" : 565591130092216320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9liIt1CIAADfJL.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hOp5fdjH2e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565591131141201922",
    "text" : "We do not reinforce fear in dogs when we do something that makes them feel better. http:\/\/t.co\/hOp5fdjH2e",
    "id" : 565591131141201922,
    "created_at" : "2015-02-11 19:20:08 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 565592913405808641,
  "created_at" : "2015-02-11 19:27:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irin Carmon",
      "screen_name" : "irin",
      "indices" : [ 3, 8 ],
      "id_str" : "20800328",
      "id" : 20800328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/BeffWjlA1j",
      "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2014\/10\/jon-stewart-rosewater-in-conversation.html",
      "display_url" : "nymag.com\/daily\/intellig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565587833248030721",
  "text" : "RT @irin: I appreciated this from Jon Stewart a few years after \u201CJezebel thinks I\u2019m a sexist prick.\u201D http:\/\/t.co\/BeffWjlA1j http:\/\/t.co\/as8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/irin\/status\/565580527491887104\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/as81PKyUeR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9lYfi0IMAEJhdi.png",
        "id_str" : "565580527156342785",
        "id" : 565580527156342785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9lYfi0IMAEJhdi.png",
        "sizes" : [ {
          "h" : 172,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/as81PKyUeR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/BeffWjlA1j",
        "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2014\/10\/jon-stewart-rosewater-in-conversation.html",
        "display_url" : "nymag.com\/daily\/intellig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565580527491887104",
    "text" : "I appreciated this from Jon Stewart a few years after \u201CJezebel thinks I\u2019m a sexist prick.\u201D http:\/\/t.co\/BeffWjlA1j http:\/\/t.co\/as81PKyUeR",
    "id" : 565580527491887104,
    "created_at" : "2015-02-11 18:38:00 +0000",
    "user" : {
      "name" : "Irin Carmon",
      "screen_name" : "irin",
      "protected" : false,
      "id_str" : "20800328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787036552279056384\/HZ4b_iXe_normal.jpg",
      "id" : 20800328,
      "verified" : true
    }
  },
  "id" : 565587833248030721,
  "created_at" : "2015-02-11 19:07:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 36, 40 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/9P3BL3YasF",
      "expanded_url" : "http:\/\/abcn.ws\/1Amrovy",
      "display_url" : "abcn.ws\/1Amrovy"
    } ]
  },
  "geo" : { },
  "id_str" : "565587542205284353",
  "text" : "RT @scottsigler: Oh, come on ... RT @ABC: Oldest man in Australia knits tiny wool sweaters 4 injured penguins: http:\/\/t.co\/9P3BL3YasF http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 19, 23 ],
        "id_str" : "28785486",
        "id" : 28785486
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/565544515562643456\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/GK7ib75tXR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9k3vX-IAAA0oMo.png",
        "id_str" : "565544515239673856",
        "id" : 565544515239673856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9k3vX-IAAA0oMo.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 992
        } ],
        "display_url" : "pic.twitter.com\/GK7ib75tXR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/9P3BL3YasF",
        "expanded_url" : "http:\/\/abcn.ws\/1Amrovy",
        "display_url" : "abcn.ws\/1Amrovy"
      } ]
    },
    "geo" : { },
    "id_str" : "565582221130891265",
    "text" : "Oh, come on ... RT @ABC: Oldest man in Australia knits tiny wool sweaters 4 injured penguins: http:\/\/t.co\/9P3BL3YasF http:\/\/t.co\/GK7ib75tXR",
    "id" : 565582221130891265,
    "created_at" : "2015-02-11 18:44:44 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 565587542205284353,
  "created_at" : "2015-02-11 19:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/a9Y0095rI5",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2015\/02\/11\/1363770\/-Montana-representative-wants-to-outlaw-yoga-pants-in-public",
      "display_url" : "dailykos.com\/story\/2015\/02\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565585909320785921",
  "text" : "o-O &gt; Montana state representative wants to outlaw yoga pants in public http:\/\/t.co\/a9Y0095rI5",
  "id" : 565585909320785921,
  "created_at" : "2015-02-11 18:59:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565563989825159170",
  "text" : "yes, i'm liberal. i try not to put conservative in a box. we all have our own view of the world.",
  "id" : 565563989825159170,
  "created_at" : "2015-02-11 17:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/HRtQJmS5LG",
      "expanded_url" : "http:\/\/www.liberalamerica.org\/2015\/02\/11\/28-reasons-im-done-talking-to-most-of-my-conservative-friends-and-family-members\/",
      "display_url" : "liberalamerica.org\/2015\/02\/11\/28-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565562313596747777",
  "text" : "28 Reasons I'm DONE Talking To Most Of My Conservative Friends And Family Members http:\/\/t.co\/HRtQJmS5LG",
  "id" : 565562313596747777,
  "created_at" : "2015-02-11 17:25:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 56, 68 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/555753435673657346\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/XgEpAPpVtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7ZuyC4IAAAWLYo.jpg",
      "id_str" : "555753410071625728",
      "id" : 555753410071625728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7ZuyC4IAAAWLYo.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XgEpAPpVtJ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/555753435673657346\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/XgEpAPpVtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7Zuy_8IAAEXxh2.jpg",
      "id_str" : "555753426462965761",
      "id" : 555753426462965761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7Zuy_8IAAEXxh2.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XgEpAPpVtJ"
    } ],
    "hashtags" : [ {
      "text" : "London",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565537647737966592",
  "text" : "RT @missmuckyduck: Beautiful Mrs Mandarin duck.\n#London @wildlife_uk http:\/\/t.co\/XgEpAPpVtJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 37, 49 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/555753435673657346\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/XgEpAPpVtJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7ZuyC4IAAAWLYo.jpg",
        "id_str" : "555753410071625728",
        "id" : 555753410071625728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7ZuyC4IAAAWLYo.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XgEpAPpVtJ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/555753435673657346\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/XgEpAPpVtJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7Zuy_8IAAEXxh2.jpg",
        "id_str" : "555753426462965761",
        "id" : 555753426462965761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7Zuy_8IAAEXxh2.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XgEpAPpVtJ"
      } ],
      "hashtags" : [ {
        "text" : "London",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "555753435673657346",
    "text" : "Beautiful Mrs Mandarin duck.\n#London @wildlife_uk http:\/\/t.co\/XgEpAPpVtJ",
    "id" : 555753435673657346,
    "created_at" : "2015-01-15 15:48:39 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 565537647737966592,
  "created_at" : "2015-02-11 15:47:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H",
      "screen_name" : "countrymousie",
      "indices" : [ 3, 17 ],
      "id_str" : "112481274",
      "id" : 112481274
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 83, 95 ],
      "id_str" : "298992506",
      "id" : 298992506
    }, {
      "name" : "RSPB",
      "screen_name" : "Natures_Voice",
      "indices" : [ 96, 110 ],
      "id_str" : "19255050",
      "id" : 19255050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suffolk",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "photography",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565537548173582336",
  "text" : "RT @countrymousie: \"Could you be quick with the bird food, even my tail is frozen\" @wildlife_uk @Natures_Voice #suffolk #photography http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 64, 76 ],
        "id_str" : "298992506",
        "id" : 298992506
      }, {
        "name" : "RSPB",
        "screen_name" : "Natures_Voice",
        "indices" : [ 77, 91 ],
        "id_str" : "19255050",
        "id" : 19255050
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/countrymousie\/status\/557136098884083712\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/JaG3WEQfF0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7tYVDqIMAA3D_n.jpg",
        "id_str" : "557136097692889088",
        "id" : 557136097692889088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7tYVDqIMAA3D_n.jpg",
        "sizes" : [ {
          "h" : 392,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JaG3WEQfF0"
      } ],
      "hashtags" : [ {
        "text" : "suffolk",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "photography",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "557136098884083712",
    "text" : "\"Could you be quick with the bird food, even my tail is frozen\" @wildlife_uk @Natures_Voice #suffolk #photography http:\/\/t.co\/JaG3WEQfF0",
    "id" : 557136098884083712,
    "created_at" : "2015-01-19 11:22:51 +0000",
    "user" : {
      "name" : "H",
      "screen_name" : "countrymousie",
      "protected" : false,
      "id_str" : "112481274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781439858053087232\/Dq3N5hbi_normal.jpg",
      "id" : 112481274,
      "verified" : false
    }
  },
  "id" : 565537548173582336,
  "created_at" : "2015-02-11 15:47:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "steampunk",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/aB8TCBmrTh",
      "expanded_url" : "http:\/\/youtu.be\/kLNgD5vsZsM",
      "display_url" : "youtu.be\/kLNgD5vsZsM"
    } ]
  },
  "geo" : { },
  "id_str" : "565279929747902465",
  "text" : "Steam Powered Giraffe - Fire Fire (Live at the La Jolla Playhouse)  http:\/\/t.co\/aB8TCBmrTh #steampunk",
  "id" : 565279929747902465,
  "created_at" : "2015-02-10 22:43:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b\u0252\u0258\u029C\u03F1\u0258m\u01A7\u01A8\u01A8\u0258lbo\u04D8@",
      "screen_name" : "GodlessSmeghead",
      "indices" : [ 3, 19 ],
      "id_str" : "776069070",
      "id" : 776069070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReplaceAMovieTitleWithGoat",
      "indices" : [ 21, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565231165997871104",
  "text" : "RT @GodlessSmeghead: #ReplaceAMovieTitleWithGoat \n\nGoat Is Not Dead",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReplaceAMovieTitleWithGoat",
        "indices" : [ 0, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565230456686518272",
    "text" : "#ReplaceAMovieTitleWithGoat \n\nGoat Is Not Dead",
    "id" : 565230456686518272,
    "created_at" : "2015-02-10 19:26:57 +0000",
    "user" : {
      "name" : "b\u0252\u0258\u029C\u03F1\u0258m\u01A7\u01A8\u01A8\u0258lbo\u04D8@",
      "screen_name" : "GodlessSmeghead",
      "protected" : false,
      "id_str" : "776069070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744083510634356736\/cOh0tfXX_normal.jpg",
      "id" : 776069070,
      "verified" : false
    }
  },
  "id" : 565231165997871104,
  "created_at" : "2015-02-10 19:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vlad",
      "screen_name" : "Hierophant1985",
      "indices" : [ 3, 18 ],
      "id_str" : "596805883",
      "id" : 596805883
    }, {
      "name" : "Dr Simon R R Atkins",
      "screen_name" : "DrSimonAtkins",
      "indices" : [ 123, 137 ],
      "id_str" : "262418358",
      "id" : 262418358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564970031063531521",
  "text" : "RT @Hierophant1985: Merck Created Hit List to \"Destroy,\" \"Neutralize\" or \"Discredit\" Dissenting Doctors - CBS News@drbloem @DrSimonAtkins h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Simon R R Atkins",
        "screen_name" : "DrSimonAtkins",
        "indices" : [ 103, 117 ],
        "id_str" : "262418358",
        "id" : 262418358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/aiK0eKBQdH",
        "expanded_url" : "http:\/\/www.cbsnews.com\/news\/merck-created-hit-list-to-destroy-neutralize-or-discredit-dissenting-doctors\/",
        "display_url" : "cbsnews.com\/news\/merck-cre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564960902496415745",
    "text" : "Merck Created Hit List to \"Destroy,\" \"Neutralize\" or \"Discredit\" Dissenting Doctors - CBS News@drbloem @DrSimonAtkins http:\/\/t.co\/aiK0eKBQdH",
    "id" : 564960902496415745,
    "created_at" : "2015-02-10 01:35:50 +0000",
    "user" : {
      "name" : "Vlad",
      "screen_name" : "Hierophant1985",
      "protected" : false,
      "id_str" : "596805883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758779459398959104\/6iklW_uA_normal.jpg",
      "id" : 596805883,
      "verified" : false
    }
  },
  "id" : 564970031063531521,
  "created_at" : "2015-02-10 02:12:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Crooks and Liars",
      "screen_name" : "crooksandliars",
      "indices" : [ 23, 38 ],
      "id_str" : "14513611",
      "id" : 14513611
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/crooksandliars\/status\/564933031702454272\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/hQFCuoe9xH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9cLmWBCEAA_7e4.jpg",
      "id_str" : "564933031631130624",
      "id" : 564933031631130624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9cLmWBCEAA_7e4.jpg",
      "sizes" : [ {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hQFCuoe9xH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UspXuhHHk8",
      "expanded_url" : "http:\/\/dlvr.it\/8TD3jQ",
      "display_url" : "dlvr.it\/8TD3jQ"
    } ]
  },
  "geo" : { },
  "id_str" : "564955147822825473",
  "text" : "RT @JamiaStarheart: RT @crooksandliars: Jeb Bush Hires CTO Who Calls Women 'Sluts' http:\/\/t.co\/UspXuhHHk8 http:\/\/t.co\/hQFCuoe9xH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Crooks and Liars",
        "screen_name" : "crooksandliars",
        "indices" : [ 3, 18 ],
        "id_str" : "14513611",
        "id" : 14513611
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crooksandliars\/status\/564933031702454272\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/hQFCuoe9xH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9cLmWBCEAA_7e4.jpg",
        "id_str" : "564933031631130624",
        "id" : 564933031631130624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9cLmWBCEAA_7e4.jpg",
        "sizes" : [ {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/hQFCuoe9xH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/UspXuhHHk8",
        "expanded_url" : "http:\/\/dlvr.it\/8TD3jQ",
        "display_url" : "dlvr.it\/8TD3jQ"
      } ]
    },
    "geo" : { },
    "id_str" : "564953743159197696",
    "text" : "RT @crooksandliars: Jeb Bush Hires CTO Who Calls Women 'Sluts' http:\/\/t.co\/UspXuhHHk8 http:\/\/t.co\/hQFCuoe9xH",
    "id" : 564953743159197696,
    "created_at" : "2015-02-10 01:07:23 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 564955147822825473,
  "created_at" : "2015-02-10 01:12:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/naZuvE5ysW",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/sarahoverthemoon\/2015\/02\/creation-museum\/",
      "display_url" : "patheos.com\/blogs\/sarahove\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564935375173713921",
  "text" : "RT @sarahnmoon: NEW POST: I went to the Creation Museum so you wouldn't have to http:\/\/t.co\/naZuvE5ysW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/naZuvE5ysW",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/sarahoverthemoon\/2015\/02\/creation-museum\/",
        "display_url" : "patheos.com\/blogs\/sarahove\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564929384428371968",
    "text" : "NEW POST: I went to the Creation Museum so you wouldn't have to http:\/\/t.co\/naZuvE5ysW",
    "id" : 564929384428371968,
    "created_at" : "2015-02-09 23:30:35 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 564935375173713921,
  "created_at" : "2015-02-09 23:54:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BirdWatch Ireland",
      "screen_name" : "BirdWatchIE",
      "indices" : [ 3, 15 ],
      "id_str" : "123211971",
      "id" : 123211971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BWIWhoami",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564907633715314690",
  "text" : "RT @BirdWatchIE: Here, at long last, is a new #BWIWhoami photo for you all, taken by Dick Coombes during ringing. What bird is this? http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdWatchIE\/status\/564777593988071424\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Wq6BbzhBfW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Z-OrMCAAANKc0.jpg",
        "id_str" : "564777593858031616",
        "id" : 564777593858031616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Z-OrMCAAANKc0.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Wq6BbzhBfW"
      } ],
      "hashtags" : [ {
        "text" : "BWIWhoami",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564777593988071424",
    "text" : "Here, at long last, is a new #BWIWhoami photo for you all, taken by Dick Coombes during ringing. What bird is this? http:\/\/t.co\/Wq6BbzhBfW",
    "id" : 564777593988071424,
    "created_at" : "2015-02-09 13:27:26 +0000",
    "user" : {
      "name" : "BirdWatch Ireland",
      "screen_name" : "BirdWatchIE",
      "protected" : false,
      "id_str" : "123211971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3461049894\/cb2296948d056f4d56dd8f6408ac5ed5_normal.jpeg",
      "id" : 123211971,
      "verified" : false
    }
  },
  "id" : 564907633715314690,
  "created_at" : "2015-02-09 22:04:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/52cdOg3eYx",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/02\/09\/i_underestimated_the_kochs_how_medicaid_expansion_was_killed_in_tennessee_for_no_reason\/",
      "display_url" : "salon.com\/2015\/02\/09\/i_u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564888494636793856",
  "text" : "RT @knittingknots: I underestimated the Kochs: How Medicaid expansion was killed in Tennessee for no reason http:\/\/t.co\/52cdOg3eYx via @Sal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salon",
        "screen_name" : "Salon",
        "indices" : [ 116, 122 ],
        "id_str" : "16955991",
        "id" : 16955991
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/52cdOg3eYx",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/02\/09\/i_underestimated_the_kochs_how_medicaid_expansion_was_killed_in_tennessee_for_no_reason\/",
        "display_url" : "salon.com\/2015\/02\/09\/i_u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564878935985356800",
    "text" : "I underestimated the Kochs: How Medicaid expansion was killed in Tennessee for no reason http:\/\/t.co\/52cdOg3eYx via @Salon",
    "id" : 564878935985356800,
    "created_at" : "2015-02-09 20:10:07 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 564888494636793856,
  "created_at" : "2015-02-09 20:48:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Moore",
      "screen_name" : "Wexcoastbirds",
      "indices" : [ 3, 17 ],
      "id_str" : "158135344",
      "id" : 158135344
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Wexcoastbirds\/status\/564835568014864384\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ctVdVeFwM8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ay8ukIAAA9mGZ.jpg",
      "id_str" : "564835559643021312",
      "id" : 564835559643021312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ay8ukIAAA9mGZ.jpg",
      "sizes" : [ {
        "h" : 649,
        "resize" : "fit",
        "w" : 781
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 781
      } ],
      "display_url" : "pic.twitter.com\/ctVdVeFwM8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564849178988527617",
  "text" : "RT @Wexcoastbirds: Male Bully in the Ivy this morning....... http:\/\/t.co\/ctVdVeFwM8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wexcoastbirds\/status\/564835568014864384\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/ctVdVeFwM8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ay8ukIAAA9mGZ.jpg",
        "id_str" : "564835559643021312",
        "id" : 564835559643021312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ay8ukIAAA9mGZ.jpg",
        "sizes" : [ {
          "h" : 649,
          "resize" : "fit",
          "w" : 781
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 649,
          "resize" : "fit",
          "w" : 781
        } ],
        "display_url" : "pic.twitter.com\/ctVdVeFwM8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564835568014864384",
    "text" : "Male Bully in the Ivy this morning....... http:\/\/t.co\/ctVdVeFwM8",
    "id" : 564835568014864384,
    "created_at" : "2015-02-09 17:17:48 +0000",
    "user" : {
      "name" : "Tom Moore",
      "screen_name" : "Wexcoastbirds",
      "protected" : false,
      "id_str" : "158135344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715834878428884992\/HqTCcBty_normal.jpg",
      "id" : 158135344,
      "verified" : false
    }
  },
  "id" : 564849178988527617,
  "created_at" : "2015-02-09 18:11:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikey The Brat",
      "screen_name" : "Mikeythebrat",
      "indices" : [ 3, 16 ],
      "id_str" : "146708985",
      "id" : 146708985
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Mikeythebrat\/status\/564833981904875521\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/v2QF4Rns8v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9axKZICUAAL_8j.jpg",
      "id_str" : "564833595382976512",
      "id" : 564833595382976512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9axKZICUAAL_8j.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/v2QF4Rns8v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564835515334393856",
  "text" : "RT @Mikeythebrat: I think I'll try this with real goldfish. Or maybe piranhas. http:\/\/t.co\/v2QF4Rns8v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mikeythebrat\/status\/564833981904875521\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/v2QF4Rns8v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9axKZICUAAL_8j.jpg",
        "id_str" : "564833595382976512",
        "id" : 564833595382976512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9axKZICUAAL_8j.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/v2QF4Rns8v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564833981904875521",
    "text" : "I think I'll try this with real goldfish. Or maybe piranhas. http:\/\/t.co\/v2QF4Rns8v",
    "id" : 564833981904875521,
    "created_at" : "2015-02-09 17:11:30 +0000",
    "user" : {
      "name" : "Mikey The Brat",
      "screen_name" : "Mikeythebrat",
      "protected" : false,
      "id_str" : "146708985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2814498333\/bc7f54bf5fe6f72b6ca9bf409afb8983_normal.jpeg",
      "id" : 146708985,
      "verified" : false
    }
  },
  "id" : 564835515334393856,
  "created_at" : "2015-02-09 17:17:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lombard",
      "screen_name" : "tutticontenti",
      "indices" : [ 3, 17 ],
      "id_str" : "35862271",
      "id" : 35862271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Israel",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "America",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564834670710636545",
  "text" : "RT @tutticontenti: If the land that #Israel is on belongs to them because they were there 2000 years ago, who does #America belong to?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Israel",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "America",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564834127942135808",
    "text" : "If the land that #Israel is on belongs to them because they were there 2000 years ago, who does #America belong to?",
    "id" : 564834127942135808,
    "created_at" : "2015-02-09 17:12:04 +0000",
    "user" : {
      "name" : "Peter Lombard",
      "screen_name" : "tutticontenti",
      "protected" : false,
      "id_str" : "35862271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459923555455492096\/lx0_VzuN_normal.jpeg",
      "id" : 35862271,
      "verified" : false
    }
  },
  "id" : 564834670710636545,
  "created_at" : "2015-02-09 17:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "indices" : [ 3, 15 ],
      "id_str" : "16126957",
      "id" : 16126957
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/563984811132715009\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/bdArqUUVQz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9OtMMaIAAAO3JJ.jpg",
      "id_str" : "563984803352281088",
      "id" : 563984803352281088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9OtMMaIAAAO3JJ.jpg",
      "sizes" : [ {
        "h" : 536,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 914,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 914,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bdArqUUVQz"
    } ],
    "hashtags" : [ {
      "text" : "GoPro",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564800146144526336",
  "text" : "RT @paul_steele: This week on the garden cam.. Who's the boss!? :D\n#GoPro http:\/\/t.co\/bdArqUUVQz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/563984811132715009\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/bdArqUUVQz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9OtMMaIAAAO3JJ.jpg",
        "id_str" : "563984803352281088",
        "id" : 563984803352281088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9OtMMaIAAAO3JJ.jpg",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bdArqUUVQz"
      } ],
      "hashtags" : [ {
        "text" : "GoPro",
        "indices" : [ 50, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563984811132715009",
    "text" : "This week on the garden cam.. Who's the boss!? :D\n#GoPro http:\/\/t.co\/bdArqUUVQz",
    "id" : 563984811132715009,
    "created_at" : "2015-02-07 08:57:11 +0000",
    "user" : {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "protected" : false,
      "id_str" : "16126957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788690057599283200\/-_rph72s_normal.jpg",
      "id" : 16126957,
      "verified" : true
    }
  },
  "id" : 564800146144526336,
  "created_at" : "2015-02-09 14:57:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Scott",
      "screen_name" : "matttockington",
      "indices" : [ 3, 18 ],
      "id_str" : "2710934836",
      "id" : 2710934836
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/matttockington\/status\/564198328146350080\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/kSmKDutiar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RvY92IcAERM3p.jpg",
      "id_str" : "564198328037306369",
      "id" : 564198328037306369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RvY92IcAERM3p.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 863,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/kSmKDutiar"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564798784887349251",
  "text" : "RT @matttockington: Ptarmigan in the snowy Cairngorms http:\/\/t.co\/kSmKDutiar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/matttockington\/status\/564198328146350080\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/kSmKDutiar",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RvY92IcAERM3p.jpg",
        "id_str" : "564198328037306369",
        "id" : 564198328037306369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RvY92IcAERM3p.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 863,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/kSmKDutiar"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564198328146350080",
    "text" : "Ptarmigan in the snowy Cairngorms http:\/\/t.co\/kSmKDutiar",
    "id" : 564198328146350080,
    "created_at" : "2015-02-07 23:05:38 +0000",
    "user" : {
      "name" : "Matt Scott",
      "screen_name" : "matttockington",
      "protected" : false,
      "id_str" : "2710934836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743097522781061120\/PgXnzqnT_normal.jpg",
      "id" : 2710934836,
      "verified" : false
    }
  },
  "id" : 564798784887349251,
  "created_at" : "2015-02-09 14:51:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Thinking Atheist",
      "screen_name" : "ThinkingAtheist",
      "indices" : [ 3, 19 ],
      "id_str" : "124439683",
      "id" : 124439683
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThinkingAtheist\/status\/564791734593277952\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/xWlvqWfDq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aLFvXCcAA_jnl.jpg",
      "id_str" : "564791734010277888",
      "id" : 564791734010277888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aLFvXCcAA_jnl.jpg",
      "sizes" : [ {
        "h" : 496,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 539
      } ],
      "display_url" : "pic.twitter.com\/xWlvqWfDq6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564797119681548288",
  "text" : "RT @ThinkingAtheist: If Puritans celebrated Valentine's Day. http:\/\/t.co\/xWlvqWfDq6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThinkingAtheist\/status\/564791734593277952\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/xWlvqWfDq6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aLFvXCcAA_jnl.jpg",
        "id_str" : "564791734010277888",
        "id" : 564791734010277888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aLFvXCcAA_jnl.jpg",
        "sizes" : [ {
          "h" : 496,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 539
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 539
        } ],
        "display_url" : "pic.twitter.com\/xWlvqWfDq6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564791734593277952",
    "text" : "If Puritans celebrated Valentine's Day. http:\/\/t.co\/xWlvqWfDq6",
    "id" : 564791734593277952,
    "created_at" : "2015-02-09 14:23:37 +0000",
    "user" : {
      "name" : "The Thinking Atheist",
      "screen_name" : "ThinkingAtheist",
      "protected" : false,
      "id_str" : "124439683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1655434886\/TTA-LOGO-2011_no_text_normal.jpg",
      "id" : 124439683,
      "verified" : false
    }
  },
  "id" : 564797119681548288,
  "created_at" : "2015-02-09 14:45:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "indices" : [ 3, 15 ],
      "id_str" : "16126957",
      "id" : 16126957
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/564790390075981824\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/4bd42oC4N4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aJ3gdIIAALkR3.jpg",
      "id_str" : "564790389979488256",
      "id" : 564790389979488256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aJ3gdIIAALkR3.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/4bd42oC4N4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/NIp9OoQshs",
      "expanded_url" : "http:\/\/bit.ly\/1DcbfcE",
      "display_url" : "bit.ly\/1DcbfcE"
    } ]
  },
  "geo" : { },
  "id_str" : "564796849216036864",
  "text" : "RT @paul_steele: Horses in the frame -- http:\/\/t.co\/NIp9OoQshs http:\/\/t.co\/4bd42oC4N4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/564790390075981824\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/4bd42oC4N4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aJ3gdIIAALkR3.jpg",
        "id_str" : "564790389979488256",
        "id" : 564790389979488256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aJ3gdIIAALkR3.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/4bd42oC4N4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/NIp9OoQshs",
        "expanded_url" : "http:\/\/bit.ly\/1DcbfcE",
        "display_url" : "bit.ly\/1DcbfcE"
      } ]
    },
    "geo" : { },
    "id_str" : "564790390075981824",
    "text" : "Horses in the frame -- http:\/\/t.co\/NIp9OoQshs http:\/\/t.co\/4bd42oC4N4",
    "id" : 564790390075981824,
    "created_at" : "2015-02-09 14:18:16 +0000",
    "user" : {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "protected" : false,
      "id_str" : "16126957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788690057599283200\/-_rph72s_normal.jpg",
      "id" : 16126957,
      "verified" : true
    }
  },
  "id" : 564796849216036864,
  "created_at" : "2015-02-09 14:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564792317123776514",
  "geo" : { },
  "id_str" : "564796777787060224",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist you definitely need a big squishy (((hug)))",
  "id" : 564796777787060224,
  "in_reply_to_status_id" : 564792317123776514,
  "created_at" : "2015-02-09 14:43:39 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheryl Rofer",
      "screen_name" : "CherylRofer",
      "indices" : [ 3, 15 ],
      "id_str" : "32232539",
      "id" : 32232539
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cherylrofer\/status\/564588658376724480\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/6lEu7V7Ve3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XSZIJCYAAtoiB.jpg",
      "id_str" : "564588657428815872",
      "id" : 564588657428815872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XSZIJCYAAtoiB.jpg",
      "sizes" : [ {
        "h" : 688,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1174,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1191
      } ],
      "display_url" : "pic.twitter.com\/6lEu7V7Ve3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564598293209300992",
  "text" : "RT @cherylrofer: I knew ravens were eating the suet, but this pose is worth sharing! http:\/\/t.co\/6lEu7V7Ve3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cherylrofer\/status\/564588658376724480\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/6lEu7V7Ve3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XSZIJCYAAtoiB.jpg",
        "id_str" : "564588657428815872",
        "id" : 564588657428815872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XSZIJCYAAtoiB.jpg",
        "sizes" : [ {
          "h" : 688,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1174,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1191
        } ],
        "display_url" : "pic.twitter.com\/6lEu7V7Ve3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564588658376724480",
    "text" : "I knew ravens were eating the suet, but this pose is worth sharing! http:\/\/t.co\/6lEu7V7Ve3",
    "id" : 564588658376724480,
    "created_at" : "2015-02-09 00:56:40 +0000",
    "user" : {
      "name" : "Cheryl Rofer",
      "screen_name" : "CherylRofer",
      "protected" : false,
      "id_str" : "32232539",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663900359090266112\/NYtwIoOr_normal.jpg",
      "id" : 32232539,
      "verified" : false
    }
  },
  "id" : 564598293209300992,
  "created_at" : "2015-02-09 01:34:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/564587177624223745\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/JOUbS9mMP8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XRCgQIUAAkxsA.jpg",
      "id_str" : "564587169252397056",
      "id" : 564587169252397056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XRCgQIUAAkxsA.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/JOUbS9mMP8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564590951184994304",
  "text" : "RT @zacaplus: http:\/\/t.co\/JOUbS9mMP8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/564587177624223745\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/JOUbS9mMP8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9XRCgQIUAAkxsA.jpg",
        "id_str" : "564587169252397056",
        "id" : 564587169252397056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9XRCgQIUAAkxsA.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/JOUbS9mMP8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564587177624223745",
    "text" : "http:\/\/t.co\/JOUbS9mMP8",
    "id" : 564587177624223745,
    "created_at" : "2015-02-09 00:50:47 +0000",
    "user" : {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "protected" : false,
      "id_str" : "1316959200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711110597593702400\/FL6-Tb30_normal.jpg",
      "id" : 1316959200,
      "verified" : false
    }
  },
  "id" : 564590951184994304,
  "created_at" : "2015-02-09 01:05:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STOP-Homophobia.com",
      "screen_name" : "WipeHomophobia",
      "indices" : [ 3, 18 ],
      "id_str" : "606412878",
      "id" : 606412878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NOH8",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "LoveIsLove",
      "indices" : [ 32, 43 ]
    }, {
      "text" : "homophobia",
      "indices" : [ 44, 55 ]
    }, {
      "text" : "LoveWins",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "FixSociety",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "equality",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "homophobes",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "queer",
      "indices" : [ 100, 106 ]
    }, {
      "text" : "MarriageEquality",
      "indices" : [ 107, 124 ]
    }, {
      "text" : "EqualRights",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564568121319890944",
  "text" : "RT @WipeHomophobia: #NOH8 #LGBT #LoveIsLove #homophobia #LoveWins #FixSociety #equality #homophobes #queer #MarriageEquality #EqualRights h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WipeHomophobia\/status\/564536934404739075\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/653FNODM0G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9WjWWvIAAAAqjz.jpg",
        "id_str" : "564536932760551424",
        "id" : 564536932760551424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9WjWWvIAAAAqjz.jpg",
        "sizes" : [ {
          "h" : 642,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/653FNODM0G"
      } ],
      "hashtags" : [ {
        "text" : "NOH8",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "LoveIsLove",
        "indices" : [ 12, 23 ]
      }, {
        "text" : "homophobia",
        "indices" : [ 24, 35 ]
      }, {
        "text" : "LoveWins",
        "indices" : [ 36, 45 ]
      }, {
        "text" : "FixSociety",
        "indices" : [ 46, 57 ]
      }, {
        "text" : "equality",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "homophobes",
        "indices" : [ 68, 79 ]
      }, {
        "text" : "queer",
        "indices" : [ 80, 86 ]
      }, {
        "text" : "MarriageEquality",
        "indices" : [ 87, 104 ]
      }, {
        "text" : "EqualRights",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564536934404739075",
    "text" : "#NOH8 #LGBT #LoveIsLove #homophobia #LoveWins #FixSociety #equality #homophobes #queer #MarriageEquality #EqualRights http:\/\/t.co\/653FNODM0G",
    "id" : 564536934404739075,
    "created_at" : "2015-02-08 21:31:08 +0000",
    "user" : {
      "name" : "STOP-Homophobia.com",
      "screen_name" : "WipeHomophobia",
      "protected" : false,
      "id_str" : "606412878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797944842533949440\/KISbHEca_normal.jpg",
      "id" : 606412878,
      "verified" : true
    }
  },
  "id" : 564568121319890944,
  "created_at" : "2015-02-08 23:35:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sybil Baldwin",
      "screen_name" : "Sybalan",
      "indices" : [ 3, 11 ],
      "id_str" : "235816732",
      "id" : 235816732
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/zczBQlXZFe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-e-SIQAA-s16.jpg",
      "id_str" : "564144555164188672",
      "id" : 564144555164188672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-e-SIQAA-s16.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 723,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 723,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zczBQlXZFe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/zczBQlXZFe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-fLfIgAEI0OZ.jpg",
      "id_str" : "564144558708391937",
      "id" : 564144558708391937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-fLfIgAEI0OZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zczBQlXZFe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/zczBQlXZFe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-fE1IYAEUzNX.jpg",
      "id_str" : "564144556921610241",
      "id" : 564144556921610241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-fE1IYAEUzNX.jpg",
      "sizes" : [ {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zczBQlXZFe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/zczBQlXZFe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-fKHIcAEccxe.jpg",
      "id_str" : "564144558339289089",
      "id" : 564144558339289089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-fKHIcAEccxe.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 893
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 893
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zczBQlXZFe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564563873714692097",
  "text" : "RT @Sybalan: Robin getting ready his photo to be taken http:\/\/t.co\/zczBQlXZFe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/zczBQlXZFe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-e-SIQAA-s16.jpg",
        "id_str" : "564144555164188672",
        "id" : 564144555164188672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-e-SIQAA-s16.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zczBQlXZFe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/zczBQlXZFe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-fLfIgAEI0OZ.jpg",
        "id_str" : "564144558708391937",
        "id" : 564144558708391937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-fLfIgAEI0OZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1018
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1018
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/zczBQlXZFe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/zczBQlXZFe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-fE1IYAEUzNX.jpg",
        "id_str" : "564144556921610241",
        "id" : 564144556921610241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-fE1IYAEUzNX.jpg",
        "sizes" : [ {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zczBQlXZFe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Sybalan\/status\/564144559928930304\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/zczBQlXZFe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Q-fKHIcAEccxe.jpg",
        "id_str" : "564144558339289089",
        "id" : 564144558339289089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Q-fKHIcAEccxe.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 893
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 893
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zczBQlXZFe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564144559928930304",
    "text" : "Robin getting ready his photo to be taken http:\/\/t.co\/zczBQlXZFe",
    "id" : 564144559928930304,
    "created_at" : "2015-02-07 19:31:59 +0000",
    "user" : {
      "name" : "Sybil Baldwin",
      "screen_name" : "Sybalan",
      "protected" : false,
      "id_str" : "235816732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797891397290434560\/lJ_9t3Ge_normal.jpg",
      "id" : 235816732,
      "verified" : false
    }
  },
  "id" : 564563873714692097,
  "created_at" : "2015-02-08 23:18:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet Stanley",
      "screen_name" : "JanetStanley1",
      "indices" : [ 3, 17 ],
      "id_str" : "314669623",
      "id" : 314669623
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JanetStanley1\/status\/527576237997568001\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/lWNRcakLMv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1JTywaIEAAewJM.jpg",
      "id_str" : "527576237808816128",
      "id" : 527576237808816128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1JTywaIEAAewJM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 619
      } ],
      "display_url" : "pic.twitter.com\/lWNRcakLMv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564563101929197568",
  "text" : "RT @JanetStanley1: Sleepy Sicilian cats, Kinky, Footsie &amp; Ginger http:\/\/t.co\/lWNRcakLMv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JanetStanley1\/status\/527576237997568001\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/lWNRcakLMv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1JTywaIEAAewJM.jpg",
        "id_str" : "527576237808816128",
        "id" : 527576237808816128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1JTywaIEAAewJM.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 619
        } ],
        "display_url" : "pic.twitter.com\/lWNRcakLMv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527576237997568001",
    "text" : "Sleepy Sicilian cats, Kinky, Footsie &amp; Ginger http:\/\/t.co\/lWNRcakLMv",
    "id" : 527576237997568001,
    "created_at" : "2014-10-29 21:42:31 +0000",
    "user" : {
      "name" : "Janet Stanley",
      "screen_name" : "JanetStanley1",
      "protected" : false,
      "id_str" : "314669623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743552121396682753\/J0z2ygma_normal.jpg",
      "id" : 314669623,
      "verified" : false
    }
  },
  "id" : 564563101929197568,
  "created_at" : "2015-02-08 23:15:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 3, 16 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/occupythemob\/status\/564507860730908672\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/ldmMi4PUlD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9WI6IqIEAE5nPG.jpg",
      "id_str" : "564507860642828289",
      "id" : 564507860642828289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9WI6IqIEAE5nPG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ldmMi4PUlD"
    } ],
    "hashtags" : [ {
      "text" : "Anonymous",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564562222656286720",
  "text" : "RT @occupythemob: #Anonymous http:\/\/t.co\/ldmMi4PUlD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.GroupTweet.com\" rel=\"nofollow\"\u003EGroupTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/occupythemob\/status\/564507860730908672\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/ldmMi4PUlD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9WI6IqIEAE5nPG.jpg",
        "id_str" : "564507860642828289",
        "id" : 564507860642828289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9WI6IqIEAE5nPG.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ldmMi4PUlD"
      } ],
      "hashtags" : [ {
        "text" : "Anonymous",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564507860730908672",
    "text" : "#Anonymous http:\/\/t.co\/ldmMi4PUlD",
    "id" : 564507860730908672,
    "created_at" : "2015-02-08 19:35:36 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "AnonyMobLive",
      "protected" : false,
      "id_str" : "341908197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773760837555134464\/CB7QyXCf_normal.jpg",
      "id" : 341908197,
      "verified" : false
    }
  },
  "id" : 564562222656286720,
  "created_at" : "2015-02-08 23:11:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SHElLONELYWOLF\/status\/564558897718239232\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/t2fxRbDLxe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3U0gCIAAjijf.jpg",
      "id_str" : "564558896623132672",
      "id" : 564558896623132672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3U0gCIAAjijf.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/t2fxRbDLxe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564561644026859520",
  "text" : "RT @SHElLONELYWOLF: http:\/\/t.co\/t2fxRbDLxe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SHElLONELYWOLF\/status\/564558897718239232\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/t2fxRbDLxe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3U0gCIAAjijf.jpg",
        "id_str" : "564558896623132672",
        "id" : 564558896623132672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3U0gCIAAjijf.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/t2fxRbDLxe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564558897718239232",
    "text" : "http:\/\/t.co\/t2fxRbDLxe",
    "id" : 564558897718239232,
    "created_at" : "2015-02-08 22:58:24 +0000",
    "user" : {
      "name" : "\uADF8\uB140 - \uB291\uB300",
      "screen_name" : "wolves_my_love",
      "protected" : false,
      "id_str" : "560545385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752248927899021313\/APaMam9p_normal.jpg",
      "id" : 560545385,
      "verified" : false
    }
  },
  "id" : 564561644026859520,
  "created_at" : "2015-02-08 23:09:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shelley",
      "screen_name" : "vettechicbaby",
      "indices" : [ 3, 17 ],
      "id_str" : "27834641",
      "id" : 27834641
    }, {
      "name" : "tim cornwell",
      "screen_name" : "247razz",
      "indices" : [ 20, 28 ],
      "id_str" : "272175633",
      "id" : 272175633
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/247razz\/status\/557920384994254849\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Eo8HqctYI8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B74hoXqCQAAAHOo.jpg",
      "id_str" : "557920381269327872",
      "id" : 557920381269327872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B74hoXqCQAAAHOo.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Eo8HqctYI8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564560857238368257",
  "text" : "RT @vettechicbaby: \"@247razz: Too cool. http:\/\/t.co\/Eo8HqctYI8\" I've seen this pic before. It's beautifully haunting!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "tim cornwell",
        "screen_name" : "247razz",
        "indices" : [ 1, 9 ],
        "id_str" : "272175633",
        "id" : 272175633
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/247razz\/status\/557920384994254849\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/Eo8HqctYI8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B74hoXqCQAAAHOo.jpg",
        "id_str" : "557920381269327872",
        "id" : 557920381269327872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B74hoXqCQAAAHOo.jpg",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Eo8HqctYI8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563624908534472705",
    "text" : "\"@247razz: Too cool. http:\/\/t.co\/Eo8HqctYI8\" I've seen this pic before. It's beautifully haunting!",
    "id" : 563624908534472705,
    "created_at" : "2015-02-06 09:07:04 +0000",
    "user" : {
      "name" : "Shelley",
      "screen_name" : "vettechicbaby",
      "protected" : false,
      "id_str" : "27834641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753452052445999104\/iR_nZMku_normal.jpg",
      "id" : 27834641,
      "verified" : false
    }
  },
  "id" : 564560857238368257,
  "created_at" : "2015-02-08 23:06:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 0, 11 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564559228925669376",
  "geo" : { },
  "id_str" : "564560777743695872",
  "in_reply_to_user_id" : 24254537,
  "text" : "@sarahnmoon cute!!",
  "id" : 564560777743695872,
  "in_reply_to_status_id" : 564559228925669376,
  "created_at" : "2015-02-08 23:05:53 +0000",
  "in_reply_to_screen_name" : "GrumpyTheology",
  "in_reply_to_user_id_str" : "24254537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/LG4njCtHyf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nowIEAA4g3Q.jpg",
      "id_str" : "564559219886919680",
      "id" : 564559219886919680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nowIEAA4g3Q.jpg",
      "sizes" : [ {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LG4njCtHyf"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/LG4njCtHyf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nozIQAMBgMr.jpg",
      "id_str" : "564559219899514883",
      "id" : 564559219899514883,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nozIQAMBgMr.jpg",
      "sizes" : [ {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LG4njCtHyf"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/LG4njCtHyf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nozIQAQWrOW.jpg",
      "id_str" : "564559219899514884",
      "id" : 564559219899514884,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nozIQAQWrOW.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LG4njCtHyf"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/LG4njCtHyf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nqTIIAAp--2.jpg",
      "id_str" : "564559220302159872",
      "id" : 564559220302159872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nqTIIAAp--2.jpg",
      "sizes" : [ {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LG4njCtHyf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564560736907960321",
  "text" : "RT @sarahnmoon: LOOK at what my mom in law made us!!! \uD83D\uDE3B\uD83D\uDC96\uD83D\uDC97 http:\/\/t.co\/LG4njCtHyf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LG4njCtHyf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nowIEAA4g3Q.jpg",
        "id_str" : "564559219886919680",
        "id" : 564559219886919680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nowIEAA4g3Q.jpg",
        "sizes" : [ {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LG4njCtHyf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LG4njCtHyf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nozIQAMBgMr.jpg",
        "id_str" : "564559219899514883",
        "id" : 564559219899514883,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nozIQAMBgMr.jpg",
        "sizes" : [ {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LG4njCtHyf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LG4njCtHyf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nozIQAQWrOW.jpg",
        "id_str" : "564559219899514884",
        "id" : 564559219899514884,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nozIQAQWrOW.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LG4njCtHyf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/sarahnmoon\/status\/564559228925669376\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LG4njCtHyf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9W3nqTIIAAp--2.jpg",
        "id_str" : "564559220302159872",
        "id" : 564559220302159872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9W3nqTIIAAp--2.jpg",
        "sizes" : [ {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LG4njCtHyf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564559228925669376",
    "text" : "LOOK at what my mom in law made us!!! \uD83D\uDE3B\uD83D\uDC96\uD83D\uDC97 http:\/\/t.co\/LG4njCtHyf",
    "id" : 564559228925669376,
    "created_at" : "2015-02-08 22:59:43 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 564560736907960321,
  "created_at" : "2015-02-08 23:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564560370594238464",
  "text" : "RT @forestberkeley: another year and i'm still not a drug addict so i still have that going 4 me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564559357028089858",
    "text" : "another year and i'm still not a drug addict so i still have that going 4 me",
    "id" : 564559357028089858,
    "created_at" : "2015-02-08 23:00:14 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 564560370594238464,
  "created_at" : "2015-02-08 23:04:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564560102431408128",
  "text" : "RT @Atheist_Eh: God loves us so much he gave us several contradictory books, written so poorly even our brightest scholars can't agree on w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564557484002537472",
    "text" : "God loves us so much he gave us several contradictory books, written so poorly even our brightest scholars can't agree on what they say.",
    "id" : 564557484002537472,
    "created_at" : "2015-02-08 22:52:47 +0000",
    "user" : {
      "name" : "The Cult of Eh",
      "screen_name" : "CultOfEh",
      "protected" : false,
      "id_str" : "1407762570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782439704679452672\/b51dB_0h_normal.jpg",
      "id" : 1407762570,
      "verified" : false
    }
  },
  "id" : 564560102431408128,
  "created_at" : "2015-02-08 23:03:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hell",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/YNRXLISzCA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/110585962532856059731\/posts\/jUY6UNKusRZ",
      "display_url" : "plus.google.com\/u\/0\/1105859625\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564532390656487424",
  "text" : "This is just sad if she really believes this. https:\/\/t.co\/YNRXLISzCA #hell",
  "id" : 564532390656487424,
  "created_at" : "2015-02-08 21:13:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SHElLONELYWOLF\/status\/564499045864181760\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/zkfCne9yJq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9WA4-tIUAAJmkV.jpg",
      "id_str" : "564499044698181632",
      "id" : 564499044698181632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9WA4-tIUAAJmkV.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 386
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 386
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 386
      } ],
      "display_url" : "pic.twitter.com\/zkfCne9yJq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564502172927557632",
  "text" : "RT @SHElLONELYWOLF: http:\/\/t.co\/zkfCne9yJq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SHElLONELYWOLF\/status\/564499045864181760\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/zkfCne9yJq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9WA4-tIUAAJmkV.jpg",
        "id_str" : "564499044698181632",
        "id" : 564499044698181632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9WA4-tIUAAJmkV.jpg",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 386
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 386
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 386
        } ],
        "display_url" : "pic.twitter.com\/zkfCne9yJq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564499045864181760",
    "text" : "http:\/\/t.co\/zkfCne9yJq",
    "id" : 564499045864181760,
    "created_at" : "2015-02-08 19:00:35 +0000",
    "user" : {
      "name" : "\uADF8\uB140 - \uB291\uB300",
      "screen_name" : "wolves_my_love",
      "protected" : false,
      "id_str" : "560545385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752248927899021313\/APaMam9p_normal.jpg",
      "id" : 560545385,
      "verified" : false
    }
  },
  "id" : 564502172927557632,
  "created_at" : "2015-02-08 19:13:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Scott",
      "screen_name" : "DScottwrites",
      "indices" : [ 3, 16 ],
      "id_str" : "2458051544",
      "id" : 2458051544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "intention",
      "indices" : [ 81, 91 ]
    }, {
      "text" : "quote",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "QOTD",
      "indices" : [ 114, 119 ]
    }, {
      "text" : "OscarWilde",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564493046096883712",
  "text" : "RT @DScottwrites: \"The smallest act of #kindness is worth more than the grandest #intention.\" -Oscar Wilde #quote #QOTD #OscarWilde http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DScottwrites\/status\/564486326503112704\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UX3QNNwdVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9V1UVUCAAEOsex.jpg",
        "id_str" : "564486320483860481",
        "id" : 564486320483860481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9V1UVUCAAEOsex.jpg",
        "sizes" : [ {
          "h" : 444,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 592
        } ],
        "display_url" : "pic.twitter.com\/UX3QNNwdVd"
      } ],
      "hashtags" : [ {
        "text" : "kindness",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "intention",
        "indices" : [ 63, 73 ]
      }, {
        "text" : "quote",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "QOTD",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "OscarWilde",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564486326503112704",
    "text" : "\"The smallest act of #kindness is worth more than the grandest #intention.\" -Oscar Wilde #quote #QOTD #OscarWilde http:\/\/t.co\/UX3QNNwdVd",
    "id" : 564486326503112704,
    "created_at" : "2015-02-08 18:10:02 +0000",
    "user" : {
      "name" : "David Scott",
      "screen_name" : "DScottwrites",
      "protected" : false,
      "id_str" : "2458051544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624806581863976960\/a6Lu6bET_normal.jpg",
      "id" : 2458051544,
      "verified" : false
    }
  },
  "id" : 564493046096883712,
  "created_at" : "2015-02-08 18:36:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Yoriko Todd",
      "screen_name" : "DrYorikoTodd",
      "indices" : [ 3, 16 ],
      "id_str" : "86283370",
      "id" : 86283370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564488817089183746",
  "text" : "RT @DrYorikoTodd: When I was young, I admired clever people.  Now that I am old, I admire kind people.  ~Abraham Heschel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/smqueue.com\" rel=\"nofollow\"\u003Esmqueue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564487740897501184",
    "text" : "When I was young, I admired clever people.  Now that I am old, I admire kind people.  ~Abraham Heschel",
    "id" : 564487740897501184,
    "created_at" : "2015-02-08 18:15:39 +0000",
    "user" : {
      "name" : "Dr Yoriko Todd",
      "screen_name" : "DrYorikoTodd",
      "protected" : false,
      "id_str" : "86283370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495078887353634816\/5BW3wdbb_normal.jpeg",
      "id" : 86283370,
      "verified" : false
    }
  },
  "id" : 564488817089183746,
  "created_at" : "2015-02-08 18:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    }, {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "indices" : [ 21, 33 ],
      "id_str" : "1370358499",
      "id" : 1370358499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564488747379884032",
  "text" : "RT @CatskillCritter: @lisasardini Amazing, as one ages, so many things once important don't matter. Ultimately, we are left with one import\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "lisa sardini",
        "screen_name" : "lisasardini",
        "indices" : [ 0, 12 ],
        "id_str" : "1370358499",
        "id" : 1370358499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "564472709732917248",
    "geo" : { },
    "id_str" : "564487470663081985",
    "in_reply_to_user_id" : 1370358499,
    "text" : "@lisasardini Amazing, as one ages, so many things once important don't matter. Ultimately, we are left with one important thing--kindness.",
    "id" : 564487470663081985,
    "in_reply_to_status_id" : 564472709732917248,
    "created_at" : "2015-02-08 18:14:35 +0000",
    "in_reply_to_screen_name" : "lisasardini",
    "in_reply_to_user_id_str" : "1370358499",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 564488747379884032,
  "created_at" : "2015-02-08 18:19:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Baur",
      "screen_name" : "genebaur",
      "indices" : [ 3, 12 ],
      "id_str" : "31766093",
      "id" : 31766093
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/genebaur\/status\/550346267466145792\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/wfZPQtShNq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6M5A30CUAEiwIZ.jpg",
      "id_str" : "550346266614321153",
      "id" : 550346266614321153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6M5A30CUAEiwIZ.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 1125
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wfZPQtShNq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564451731103555584",
  "text" : "RT @genebaur: With the new day comes new strength and new thoughts.\nEleanor Roosevelt http:\/\/t.co\/wfZPQtShNq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/genebaur\/status\/550346267466145792\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/wfZPQtShNq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6M5A30CUAEiwIZ.jpg",
        "id_str" : "550346266614321153",
        "id" : 550346266614321153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6M5A30CUAEiwIZ.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wfZPQtShNq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "550346267466145792",
    "text" : "With the new day comes new strength and new thoughts.\nEleanor Roosevelt http:\/\/t.co\/wfZPQtShNq",
    "id" : 550346267466145792,
    "created_at" : "2014-12-31 17:42:29 +0000",
    "user" : {
      "name" : "Gene Baur",
      "screen_name" : "genebaur",
      "protected" : false,
      "id_str" : "31766093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688079082433548288\/TJLCmSkK_normal.jpg",
      "id" : 31766093,
      "verified" : false
    }
  },
  "id" : 564451731103555584,
  "created_at" : "2015-02-08 15:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawna",
      "screen_name" : "onecaliberal",
      "indices" : [ 0, 13 ],
      "id_str" : "757739089",
      "id" : 757739089
    }, {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 14, 30 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    }, {
      "name" : "DemUnderground",
      "screen_name" : "demunderground",
      "indices" : [ 31, 46 ],
      "id_str" : "577407017",
      "id" : 577407017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564231278967279616",
  "geo" : { },
  "id_str" : "564245499579236352",
  "in_reply_to_user_id" : 757739089,
  "text" : "@onecaliberal @AWorldOutOfMind @demunderground kids need to be kids. this trend makes me so sad.",
  "id" : 564245499579236352,
  "in_reply_to_status_id" : 564231278967279616,
  "created_at" : "2015-02-08 02:13:04 +0000",
  "in_reply_to_screen_name" : "onecaliberal",
  "in_reply_to_user_id_str" : "757739089",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawna",
      "screen_name" : "onecaliberal",
      "indices" : [ 3, 16 ],
      "id_str" : "757739089",
      "id" : 757739089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/dAVW0yuuy2",
      "expanded_url" : "http:\/\/demu.gr\/10026194847",
      "display_url" : "demu.gr\/10026194847"
    } ]
  },
  "geo" : { },
  "id_str" : "564244669186736129",
  "text" : "RT @onecaliberal: Mom gets note. Her 6 yr old daughter plays with blocks on desk meant only for math problems. -http:\/\/t.co\/dAVW0yuuy2 via \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DemUnderground",
        "screen_name" : "demunderground",
        "indices" : [ 121, 136 ],
        "id_str" : "577407017",
        "id" : 577407017
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/dAVW0yuuy2",
        "expanded_url" : "http:\/\/demu.gr\/10026194847",
        "display_url" : "demu.gr\/10026194847"
      } ]
    },
    "geo" : { },
    "id_str" : "564231278967279616",
    "text" : "Mom gets note. Her 6 yr old daughter plays with blocks on desk meant only for math problems. -http:\/\/t.co\/dAVW0yuuy2 via @demunderground",
    "id" : 564231278967279616,
    "created_at" : "2015-02-08 01:16:34 +0000",
    "user" : {
      "name" : "Dawna",
      "screen_name" : "onecaliberal",
      "protected" : false,
      "id_str" : "757739089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796798990708674560\/njyPTqhj_normal.jpg",
      "id" : 757739089,
      "verified" : false
    }
  },
  "id" : 564244669186736129,
  "created_at" : "2015-02-08 02:09:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "indices" : [ 3, 12 ],
      "id_str" : "800652126",
      "id" : 800652126
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/564232516366643200\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/SIqxL9tZQS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9SOe8JCIAEzZ2U.jpg",
      "id_str" : "564232515519389697",
      "id" : 564232515519389697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9SOe8JCIAEzZ2U.jpg",
      "sizes" : [ {
        "h" : 1172,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SIqxL9tZQS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564235035151454208",
  "text" : "RT @MrRat395: Love is in the air:-) http:\/\/t.co\/SIqxL9tZQS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/564232516366643200\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/SIqxL9tZQS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9SOe8JCIAEzZ2U.jpg",
        "id_str" : "564232515519389697",
        "id" : 564232515519389697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9SOe8JCIAEzZ2U.jpg",
        "sizes" : [ {
          "h" : 1172,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/SIqxL9tZQS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564232516366643200",
    "text" : "Love is in the air:-) http:\/\/t.co\/SIqxL9tZQS",
    "id" : 564232516366643200,
    "created_at" : "2015-02-08 01:21:29 +0000",
    "user" : {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "protected" : false,
      "id_str" : "800652126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779503692802240512\/iVwM-mwl_normal.jpg",
      "id" : 800652126,
      "verified" : false
    }
  },
  "id" : 564235035151454208,
  "created_at" : "2015-02-08 01:31:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Brazile",
      "screen_name" : "donnabrazile",
      "indices" : [ 3, 16 ],
      "id_str" : "60919240",
      "id" : 60919240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shameful",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/hfwE0660MX",
      "expanded_url" : "http:\/\/zite.to\/1KqjW5p",
      "display_url" : "zite.to\/1KqjW5p"
    } ]
  },
  "geo" : { },
  "id_str" : "564227821581901824",
  "text" : "RT @donnabrazile: When a state blocks Obamacare, ERs close: The lesson of Louisiana. #shameful http:\/\/t.co\/hfwE0660MX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shameful",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/hfwE0660MX",
        "expanded_url" : "http:\/\/zite.to\/1KqjW5p",
        "display_url" : "zite.to\/1KqjW5p"
      } ]
    },
    "geo" : { },
    "id_str" : "563919066508054528",
    "text" : "When a state blocks Obamacare, ERs close: The lesson of Louisiana. #shameful http:\/\/t.co\/hfwE0660MX",
    "id" : 563919066508054528,
    "created_at" : "2015-02-07 04:35:57 +0000",
    "user" : {
      "name" : "Donna Brazile",
      "screen_name" : "donnabrazile",
      "protected" : false,
      "id_str" : "60919240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792920005226528768\/8rrDuJco_normal.jpg",
      "id" : 60919240,
      "verified" : true
    }
  },
  "id" : 564227821581901824,
  "created_at" : "2015-02-08 01:02:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564227547266052096",
  "text" : "RT @Floridaline: \"Religious freedom is not under attack in this country\" - Pastor of the First Baptist Church of Salt Lake City.\nhttp:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/YJ8j7zfKVv",
        "expanded_url" : "http:\/\/www.sltrib.com\/opinion\/2145432-155\/op-ed-religious-freedom-is-not-under",
        "display_url" : "sltrib.com\/opinion\/214543\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564221327834234880",
    "text" : "\"Religious freedom is not under attack in this country\" - Pastor of the First Baptist Church of Salt Lake City.\nhttp:\/\/t.co\/YJ8j7zfKVv",
    "id" : 564221327834234880,
    "created_at" : "2015-02-08 00:37:01 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 564227547266052096,
  "created_at" : "2015-02-08 01:01:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564221327834234880",
  "geo" : { },
  "id_str" : "564227521848549377",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline a baptist?? well, i'll be darned...",
  "id" : 564227521848549377,
  "in_reply_to_status_id" : 564221327834234880,
  "created_at" : "2015-02-08 01:01:38 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arrogantpplannoyme",
      "indices" : [ 62, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564218801731174401",
  "text" : "apparently I will never learn to NOT READ THE COMMENTS!! ugh. #arrogantpplannoyme",
  "id" : 564218801731174401,
  "created_at" : "2015-02-08 00:26:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Enterprise",
      "screen_name" : "vida_ying_yang",
      "indices" : [ 3, 18 ],
      "id_str" : "2763786195",
      "id" : 2763786195
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vida_ying_yang\/status\/563473332335808512\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/z2eYt67qn5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HcAp8IEAAMu5U.jpg",
      "id_str" : "563473332214173696",
      "id" : 563473332214173696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HcAp8IEAAMu5U.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 970
      } ],
      "display_url" : "pic.twitter.com\/z2eYt67qn5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564213370799534083",
  "text" : "RT @vida_ying_yang: \uD83C\uDF3B\u2764\uFE0F\uD83D\uDE0A http:\/\/t.co\/z2eYt67qn5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vida_ying_yang\/status\/563473332335808512\/photo\/1",
        "indices" : [ 5, 27 ],
        "url" : "http:\/\/t.co\/z2eYt67qn5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HcAp8IEAAMu5U.jpg",
        "id_str" : "563473332214173696",
        "id" : 563473332214173696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HcAp8IEAAMu5U.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 970
        } ],
        "display_url" : "pic.twitter.com\/z2eYt67qn5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563473332335808512",
    "text" : "\uD83C\uDF3B\u2764\uFE0F\uD83D\uDE0A http:\/\/t.co\/z2eYt67qn5",
    "id" : 563473332335808512,
    "created_at" : "2015-02-05 23:04:45 +0000",
    "user" : {
      "name" : "Ela Enterprise",
      "screen_name" : "vida_ying_yang",
      "protected" : false,
      "id_str" : "2763786195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508542917431291905\/r5yrbBYi_normal.jpeg",
      "id" : 2763786195,
      "verified" : false
    }
  },
  "id" : 564213370799534083,
  "created_at" : "2015-02-08 00:05:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564208507688607747",
  "geo" : { },
  "id_str" : "564209390711238657",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist do you need a hug?",
  "id" : 564209390711238657,
  "in_reply_to_status_id" : 564208507688607747,
  "created_at" : "2015-02-07 23:49:35 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564137897901965313",
  "geo" : { },
  "id_str" : "564143471070826496",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe for the kiddo's phone?",
  "id" : 564143471070826496,
  "in_reply_to_status_id" : 564137897901965313,
  "created_at" : "2015-02-07 19:27:39 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serdar",
      "screen_name" : "serdargoknur",
      "indices" : [ 3, 16 ],
      "id_str" : "1962422936",
      "id" : 1962422936
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/serdargoknur\/status\/563992024354156544\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/8N51awiigk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9OzwdPIIAA2Xz7.jpg",
      "id_str" : "563992023414611968",
      "id" : 563992023414611968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9OzwdPIIAA2Xz7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8N51awiigk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564063916612136962",
  "text" : "RT @serdargoknur: So pretty... http:\/\/t.co\/8N51awiigk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/serdargoknur\/status\/563992024354156544\/photo\/1",
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/8N51awiigk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9OzwdPIIAA2Xz7.jpg",
        "id_str" : "563992023414611968",
        "id" : 563992023414611968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9OzwdPIIAA2Xz7.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8N51awiigk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563992024354156544",
    "text" : "So pretty... http:\/\/t.co\/8N51awiigk",
    "id" : 563992024354156544,
    "created_at" : "2015-02-07 09:25:51 +0000",
    "user" : {
      "name" : "Serdar",
      "screen_name" : "serdargoknur",
      "protected" : false,
      "id_str" : "1962422936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800959262621134848\/rJ4QkSEr_normal.jpg",
      "id" : 1962422936,
      "verified" : false
    }
  },
  "id" : 564063916612136962,
  "created_at" : "2015-02-07 14:11:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563710328245334016",
  "geo" : { },
  "id_str" : "563716354906128384",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe argh!",
  "id" : 563716354906128384,
  "in_reply_to_status_id" : 563710328245334016,
  "created_at" : "2015-02-06 15:10:27 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "Marie93544129",
      "indices" : [ 3, 17 ],
      "id_str" : "1611736848",
      "id" : 1611736848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photocontest",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Jzx3pYw5l4",
      "expanded_url" : "http:\/\/bit.ly\/16lIrS1",
      "display_url" : "bit.ly\/16lIrS1"
    } ]
  },
  "geo" : { },
  "id_str" : "563715591643860992",
  "text" : "RT @Marie93544129: I need YOU! to VOTE, tell your fiends, Retweet .. National #photocontest link - http:\/\/t.co\/Jzx3pYw5l4 http:\/\/t.co\/unHwH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Marie93544129\/status\/563455260992499714\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/unHwHqSM17",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HLktJCYAAZtHx.jpg",
        "id_str" : "563455259851251712",
        "id" : 563455259851251712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HLktJCYAAZtHx.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/unHwHqSM17"
      } ],
      "hashtags" : [ {
        "text" : "photocontest",
        "indices" : [ 59, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Jzx3pYw5l4",
        "expanded_url" : "http:\/\/bit.ly\/16lIrS1",
        "display_url" : "bit.ly\/16lIrS1"
      } ]
    },
    "geo" : { },
    "id_str" : "563622935924334592",
    "text" : "I need YOU! to VOTE, tell your fiends, Retweet .. National #photocontest link - http:\/\/t.co\/Jzx3pYw5l4 http:\/\/t.co\/unHwHqSM17",
    "id" : 563622935924334592,
    "created_at" : "2015-02-06 08:59:14 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "Marie93544129",
      "protected" : false,
      "id_str" : "1611736848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459338178092998657\/NHULL_iV_normal.jpeg",
      "id" : 1611736848,
      "verified" : false
    }
  },
  "id" : 563715591643860992,
  "created_at" : "2015-02-06 15:07:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bate",
      "screen_name" : "imagejournal",
      "indices" : [ 3, 16 ],
      "id_str" : "152132466",
      "id" : 152132466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greeting",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "cards",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "RETWEEET",
      "indices" : [ 58, 67 ]
    }, {
      "text" : "photography",
      "indices" : [ 68, 80 ]
    }, {
      "text" : "landscape",
      "indices" : [ 81, 91 ]
    }, {
      "text" : "London",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "beautiful",
      "indices" : [ 100, 110 ]
    }, {
      "text" : "socialmedia",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/3GJY7osQe1",
      "expanded_url" : "http:\/\/imagejournal-photography.com\/blog\/new-landscape-greeting-cards",
      "display_url" : "imagejournal-photography.com\/blog\/new-lands\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563714758848024577",
  "text" : "RT @imagejournal: #greeting #cards http:\/\/t.co\/3GJY7osQe1 #RETWEEET #photography #landscape #London #beautiful #socialmedia http:\/\/t.co\/2H2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/imagejournal\/status\/552060768041304064\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/2H2TFFCHBM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6lQUzCCYAIG6a_.jpg",
        "id_str" : "552060747555954690",
        "id" : 552060747555954690,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6lQUzCCYAIG6a_.jpg",
        "sizes" : [ {
          "h" : 1114,
          "resize" : "fit",
          "w" : 1575
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2H2TFFCHBM"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/imagejournal\/status\/552060768041304064\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/2H2TFFCHBM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6lQV72CMAE5YKo.jpg",
        "id_str" : "552060767101399041",
        "id" : 552060767101399041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6lQV72CMAE5YKo.jpg",
        "sizes" : [ {
          "h" : 1114,
          "resize" : "fit",
          "w" : 1575
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2H2TFFCHBM"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/imagejournal\/status\/552060768041304064\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/2H2TFFCHBM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6lQVd_CQAA9Qd5.jpg",
        "id_str" : "552060759086088192",
        "id" : 552060759086088192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6lQVd_CQAA9Qd5.jpg",
        "sizes" : [ {
          "h" : 1114,
          "resize" : "fit",
          "w" : 1575
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2H2TFFCHBM"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/imagejournal\/status\/552060768041304064\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/2H2TFFCHBM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6lQVjKCMAIwDQR.jpg",
        "id_str" : "552060760474398722",
        "id" : 552060760474398722,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6lQVjKCMAIwDQR.jpg",
        "sizes" : [ {
          "h" : 1114,
          "resize" : "fit",
          "w" : 1575
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2H2TFFCHBM"
      } ],
      "hashtags" : [ {
        "text" : "greeting",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "cards",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "RETWEEET",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "photography",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "landscape",
        "indices" : [ 63, 73 ]
      }, {
        "text" : "London",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "beautiful",
        "indices" : [ 82, 92 ]
      }, {
        "text" : "socialmedia",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/3GJY7osQe1",
        "expanded_url" : "http:\/\/imagejournal-photography.com\/blog\/new-landscape-greeting-cards",
        "display_url" : "imagejournal-photography.com\/blog\/new-lands\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563711313713823744",
    "text" : "#greeting #cards http:\/\/t.co\/3GJY7osQe1 #RETWEEET #photography #landscape #London #beautiful #socialmedia http:\/\/t.co\/2H2TFFCHBM",
    "id" : 563711313713823744,
    "created_at" : "2015-02-06 14:50:25 +0000",
    "user" : {
      "name" : "Paul Bate",
      "screen_name" : "imagejournal",
      "protected" : false,
      "id_str" : "152132466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788801672680210432\/FXg0YmBE_normal.jpg",
      "id" : 152132466,
      "verified" : false
    }
  },
  "id" : 563714758848024577,
  "created_at" : "2015-02-06 15:04:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "indices" : [ 3, 13 ],
      "id_str" : "1244239765",
      "id" : 1244239765
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/563712381273260032\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wliVgSmaQ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K1bIyIgAAr-Ki.jpg",
      "id_str" : "563712381193584640",
      "id" : 563712381193584640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K1bIyIgAAr-Ki.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wliVgSmaQ6"
    } ],
    "hashtags" : [ {
      "text" : "robin",
      "indices" : [ 15, 21 ]
    }, {
      "text" : "titanic",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563714460469436416",
  "text" : "RT @Siberia61: #robin doing  a Kate winslet Impression #titanic :-) http:\/\/t.co\/wliVgSmaQ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/563712381273260032\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/wliVgSmaQ6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K1bIyIgAAr-Ki.jpg",
        "id_str" : "563712381193584640",
        "id" : 563712381193584640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K1bIyIgAAr-Ki.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wliVgSmaQ6"
      } ],
      "hashtags" : [ {
        "text" : "robin",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "titanic",
        "indices" : [ 40, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563712381273260032",
    "text" : "#robin doing  a Kate winslet Impression #titanic :-) http:\/\/t.co\/wliVgSmaQ6",
    "id" : 563712381273260032,
    "created_at" : "2015-02-06 14:54:39 +0000",
    "user" : {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "protected" : false,
      "id_str" : "1244239765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667649979863969792\/DP8gQLi6_normal.jpg",
      "id" : 1244239765,
      "verified" : false
    }
  },
  "id" : 563714460469436416,
  "created_at" : "2015-02-06 15:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "indices" : [ 3, 18 ],
      "id_str" : "17621549",
      "id" : 17621549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563491330597609472",
  "text" : "RT @ReikiAwakening: How did you add more light to the world today? Every bit counts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563481657916030976",
    "text" : "How did you add more light to the world today? Every bit counts.",
    "id" : 563481657916030976,
    "created_at" : "2015-02-05 23:37:50 +0000",
    "user" : {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "protected" : false,
      "id_str" : "17621549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487076852842778625\/uKEYUGdu_normal.jpeg",
      "id" : 17621549,
      "verified" : false
    }
  },
  "id" : 563491330597609472,
  "created_at" : "2015-02-06 00:16:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/oDij1u94RI",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/02\/05\/scott_walker_budgeted_250000_to_figure_out_if_wind_turbines_are_making_people_sick\/",
      "display_url" : "salon.com\/2015\/02\/05\/sco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563483856930885632",
  "text" : "RT @BlueDuPage: Scott Walker budgeted $250,000 to figure out if wind turbines are making people sick  http:\/\/t.co\/oDij1u94RI http:\/\/t.co\/6G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BlueDuPage\/status\/563471464964558848\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/6GV9cBzAU1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HaRaOCYAEiBjk.jpg",
        "id_str" : "563471421028851713",
        "id" : 563471421028851713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HaRaOCYAEiBjk.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/6GV9cBzAU1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/oDij1u94RI",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/02\/05\/scott_walker_budgeted_250000_to_figure_out_if_wind_turbines_are_making_people_sick\/",
        "display_url" : "salon.com\/2015\/02\/05\/sco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563471464964558848",
    "text" : "Scott Walker budgeted $250,000 to figure out if wind turbines are making people sick  http:\/\/t.co\/oDij1u94RI http:\/\/t.co\/6GV9cBzAU1",
    "id" : 563471464964558848,
    "created_at" : "2015-02-05 22:57:20 +0000",
    "user" : {
      "name" : "Muslim Green Dupage",
      "screen_name" : "HDGregg",
      "protected" : false,
      "id_str" : "41186732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649063875397185536\/ifPnhYz4_normal.jpg",
      "id" : 41186732,
      "verified" : false
    }
  },
  "id" : 563483856930885632,
  "created_at" : "2015-02-05 23:46:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563476041214476288",
  "text" : "RT @_NealeDWalsch: I am an individuation of Divinity, an expression of God, a singularization of The Singularity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563472164930981890",
    "text" : "I am an individuation of Divinity, an expression of God, a singularization of The Singularity.",
    "id" : 563472164930981890,
    "created_at" : "2015-02-05 23:00:07 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 563476041214476288,
  "created_at" : "2015-02-05 23:15:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563409875334864896",
  "text" : "is there an easy way to see who im following by earliest date? i want to clean up my following list starting from beginning.",
  "id" : 563409875334864896,
  "created_at" : "2015-02-05 18:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florent Crivello",
      "screen_name" : "Altimor",
      "indices" : [ 3, 11 ],
      "id_str" : "21125274",
      "id" : 21125274
    }, {
      "name" : "clippings.io",
      "screen_name" : "clippingsio",
      "indices" : [ 13, 25 ],
      "id_str" : "2646484009",
      "id" : 2646484009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563398789722275841",
  "text" : "RT @Altimor: @clippingsio wow! awesome product guys!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "clippings.io",
        "screen_name" : "clippingsio",
        "indices" : [ 0, 12 ],
        "id_str" : "2646484009",
        "id" : 2646484009
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563394688934510592",
    "in_reply_to_user_id" : 2646484009,
    "text" : "@clippingsio wow! awesome product guys!",
    "id" : 563394688934510592,
    "created_at" : "2015-02-05 17:52:15 +0000",
    "in_reply_to_screen_name" : "clippingsio",
    "in_reply_to_user_id_str" : "2646484009",
    "user" : {
      "name" : "Florent Crivello",
      "screen_name" : "Altimor",
      "protected" : false,
      "id_str" : "21125274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693369422476541953\/SVKxRKUN_normal.jpg",
      "id" : 21125274,
      "verified" : false
    }
  },
  "id" : 563398789722275841,
  "created_at" : "2015-02-05 18:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerry sowells",
      "screen_name" : "1pooplechicken",
      "indices" : [ 3, 18 ],
      "id_str" : "221876099",
      "id" : 221876099
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1pooplechicken\/status\/563398498104901632\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/r8h7oM7atj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9GX8SUIMAESe0l.jpg",
      "id_str" : "563398490362228737",
      "id" : 563398490362228737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9GX8SUIMAESe0l.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/r8h7oM7atj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563398725180325888",
  "text" : "RT @1pooplechicken: Just waiting for breakfast! http:\/\/t.co\/r8h7oM7atj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1pooplechicken\/status\/563398498104901632\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/r8h7oM7atj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9GX8SUIMAESe0l.jpg",
        "id_str" : "563398490362228737",
        "id" : 563398490362228737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9GX8SUIMAESe0l.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/r8h7oM7atj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563398498104901632",
    "text" : "Just waiting for breakfast! http:\/\/t.co\/r8h7oM7atj",
    "id" : 563398498104901632,
    "created_at" : "2015-02-05 18:07:24 +0000",
    "user" : {
      "name" : "Kerry sowells",
      "screen_name" : "1pooplechicken",
      "protected" : false,
      "id_str" : "221876099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2181729579\/image_normal.jpg",
      "id" : 221876099,
      "verified" : false
    }
  },
  "id" : 563398725180325888,
  "created_at" : "2015-02-05 18:08:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/wNgGXCRCJb",
      "expanded_url" : "http:\/\/hookedonhouses.net\/2014\/06\/05\/an-english-country-style-cottage-in-carmel-by-the-sea\/",
      "display_url" : "hookedonhouses.net\/2014\/06\/05\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563391776825024512",
  "text" : "I want! lol &gt; An English Country Style Cottage in Carmel-by-the-Sea http:\/\/t.co\/wNgGXCRCJb",
  "id" : 563391776825024512,
  "created_at" : "2015-02-05 17:40:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Defenders Wildlife",
      "screen_name" : "Defenders",
      "indices" : [ 3, 13 ],
      "id_str" : "15309072",
      "id" : 15309072
    }, {
      "name" : "Learn Something",
      "screen_name" : "Iearnsomething",
      "indices" : [ 18, 33 ],
      "id_str" : "2192030256",
      "id" : 2192030256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Iearnsomething\/status\/562310772270043136\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/zJZvp55cCz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B826qwCIMAAqzYY.jpg",
      "id_str" : "562310772102279168",
      "id" : 562310772102279168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B826qwCIMAAqzYY.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/zJZvp55cCz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563369695529934848",
  "text" : "RT @Defenders: RT @Iearnsomething: This is what an eagle looks like from below. http:\/\/t.co\/zJZvp55cCz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Learn Something",
        "screen_name" : "Iearnsomething",
        "indices" : [ 3, 18 ],
        "id_str" : "2192030256",
        "id" : 2192030256
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Iearnsomething\/status\/562310772270043136\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/zJZvp55cCz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B826qwCIMAAqzYY.jpg",
        "id_str" : "562310772102279168",
        "id" : 562310772102279168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B826qwCIMAAqzYY.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/zJZvp55cCz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563366895077048320",
    "text" : "RT @Iearnsomething: This is what an eagle looks like from below. http:\/\/t.co\/zJZvp55cCz",
    "id" : 563366895077048320,
    "created_at" : "2015-02-05 16:01:49 +0000",
    "user" : {
      "name" : "Defenders Wildlife",
      "screen_name" : "Defenders",
      "protected" : false,
      "id_str" : "15309072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1152365714\/DOW-color-logo_twitter_normal.jpg",
      "id" : 15309072,
      "verified" : false
    }
  },
  "id" : 563369695529934848,
  "created_at" : "2015-02-05 16:12:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 118, 130 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mallards",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563140934586863617",
  "text" : "RT @missmuckyduck: If ducks don't want their pic taken by me they stick their head in a hole obviously. Lol\n#mallards @wildlife_uk http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 99, 111 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/562942676212121600\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/Bjmx3F7WRe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8_5Xk7IUAIjdFW.jpg",
        "id_str" : "562942661888593922",
        "id" : 562942661888593922,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8_5Xk7IUAIjdFW.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Bjmx3F7WRe"
      } ],
      "hashtags" : [ {
        "text" : "mallards",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562942676212121600",
    "text" : "If ducks don't want their pic taken by me they stick their head in a hole obviously. Lol\n#mallards @wildlife_uk http:\/\/t.co\/Bjmx3F7WRe",
    "id" : 562942676212121600,
    "created_at" : "2015-02-04 11:56:07 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 563140934586863617,
  "created_at" : "2015-02-05 01:03:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dottie",
      "screen_name" : "countrygalDot",
      "indices" : [ 3, 17 ],
      "id_str" : "1212475675",
      "id" : 1212475675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/countrygalDot\/status\/562992530196008960\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ne3CtzlZ6w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Amt-1IEAITk18.jpg",
      "id_str" : "562992524823105538",
      "id" : 562992524823105538,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Amt-1IEAITk18.jpg",
      "sizes" : [ {
        "h" : 554,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ne3CtzlZ6w"
    } ],
    "hashtags" : [ {
      "text" : "awesomeidea",
      "indices" : [ 47, 59 ]
    }, {
      "text" : "lookscooltoo",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563140452489367553",
  "text" : "RT @countrygalDot: For the avid outdoorsman! ! #awesomeidea #lookscooltoo http:\/\/t.co\/ne3CtzlZ6w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/countrygalDot\/status\/562992530196008960\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/ne3CtzlZ6w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Amt-1IEAITk18.jpg",
        "id_str" : "562992524823105538",
        "id" : 562992524823105538,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Amt-1IEAITk18.jpg",
        "sizes" : [ {
          "h" : 554,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ne3CtzlZ6w"
      } ],
      "hashtags" : [ {
        "text" : "awesomeidea",
        "indices" : [ 28, 40 ]
      }, {
        "text" : "lookscooltoo",
        "indices" : [ 41, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562992530196008960",
    "text" : "For the avid outdoorsman! ! #awesomeidea #lookscooltoo http:\/\/t.co\/ne3CtzlZ6w",
    "id" : 562992530196008960,
    "created_at" : "2015-02-04 15:14:13 +0000",
    "user" : {
      "name" : "Dottie",
      "screen_name" : "countrygalDot",
      "protected" : false,
      "id_str" : "1212475675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796022033406722048\/d6ZfWdHR_normal.jpg",
      "id" : 1212475675,
      "verified" : false
    }
  },
  "id" : 563140452489367553,
  "created_at" : "2015-02-05 01:02:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "indices" : [ 3, 19 ],
      "id_str" : "492604254",
      "id" : 492604254
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClackamettePark",
      "indices" : [ 21, 37 ]
    }, {
      "text" : "ducks",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "mallard",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "drake",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "hen",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "winter",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563140291017060352",
  "text" : "RT @naturechronicle: #ClackamettePark is a haven for #ducks &amp; geese. Here a #mallard #drake and #hen bask in a patch of #winter sunlight. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/naturechronicle\/status\/562995580654583809\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/5X7WwpEVq0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ApfzWIcAQg5Dz.jpg",
        "id_str" : "562995579757031428",
        "id" : 562995579757031428,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ApfzWIcAQg5Dz.jpg",
        "sizes" : [ {
          "h" : 1333,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5X7WwpEVq0"
      } ],
      "hashtags" : [ {
        "text" : "ClackamettePark",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "ducks",
        "indices" : [ 32, 38 ]
      }, {
        "text" : "mallard",
        "indices" : [ 59, 67 ]
      }, {
        "text" : "drake",
        "indices" : [ 68, 74 ]
      }, {
        "text" : "hen",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "winter",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562995580654583809",
    "text" : "#ClackamettePark is a haven for #ducks &amp; geese. Here a #mallard #drake and #hen bask in a patch of #winter sunlight. http:\/\/t.co\/5X7WwpEVq0",
    "id" : 562995580654583809,
    "created_at" : "2015-02-04 15:26:21 +0000",
    "user" : {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "protected" : false,
      "id_str" : "492604254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3166619966\/e7f8777d0fc93299ea6002d3e754aca8_normal.jpeg",
      "id" : 492604254,
      "verified" : false
    }
  },
  "id" : 563140291017060352,
  "created_at" : "2015-02-05 01:01:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/563138643163090946\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/G0B2B3bbVS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CrnCcIAAABiG3.jpg",
      "id_str" : "563138640579395584",
      "id" : 563138640579395584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CrnCcIAAABiG3.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 463
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 463
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 463
      } ],
      "display_url" : "pic.twitter.com\/G0B2B3bbVS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563139882286333952",
  "text" : "RT @parkstepp: Birds of a feather\u2026. http:\/\/t.co\/G0B2B3bbVS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/563138643163090946\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/G0B2B3bbVS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CrnCcIAAABiG3.jpg",
        "id_str" : "563138640579395584",
        "id" : 563138640579395584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CrnCcIAAABiG3.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 463
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 463
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 463
        } ],
        "display_url" : "pic.twitter.com\/G0B2B3bbVS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563138643163090946",
    "text" : "Birds of a feather\u2026. http:\/\/t.co\/G0B2B3bbVS",
    "id" : 563138643163090946,
    "created_at" : "2015-02-05 00:54:49 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 563139882286333952,
  "created_at" : "2015-02-05 00:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 3, 18 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BruceGerencser\/status\/563128211840983040\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VMgYQOTLTm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CiH-1IYAAWvnw.jpg",
      "id_str" : "563128211429941248",
      "id" : 563128211429941248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CiH-1IYAAWvnw.jpg",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 595
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 595
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 595
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VMgYQOTLTm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KHfTjSeaN0",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/danger-box-makes-sense\/",
      "display_url" : "brucegerencser.net\/2015\/02\/danger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563132371336433664",
  "text" : "RT @BruceGerencser: The Danger of Being in a Box and Why it Makes Sense When You are in it http:\/\/t.co\/KHfTjSeaN0 http:\/\/t.co\/VMgYQOTLTm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BruceGerencser\/status\/563128211840983040\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/VMgYQOTLTm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CiH-1IYAAWvnw.jpg",
        "id_str" : "563128211429941248",
        "id" : 563128211429941248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CiH-1IYAAWvnw.jpg",
        "sizes" : [ {
          "h" : 397,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VMgYQOTLTm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/KHfTjSeaN0",
        "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/danger-box-makes-sense\/",
        "display_url" : "brucegerencser.net\/2015\/02\/danger\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563128211840983040",
    "text" : "The Danger of Being in a Box and Why it Makes Sense When You are in it http:\/\/t.co\/KHfTjSeaN0 http:\/\/t.co\/VMgYQOTLTm",
    "id" : 563128211840983040,
    "created_at" : "2015-02-05 00:13:22 +0000",
    "user" : {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "protected" : false,
      "id_str" : "2954308119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708165822007480320\/bzYNwh2A_normal.jpg",
      "id" : 2954308119,
      "verified" : false
    }
  },
  "id" : 563132371336433664,
  "created_at" : "2015-02-05 00:29:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563131788504358913",
  "text" : "some of these tweets im reading are really bugging my aura... oy!",
  "id" : 563131788504358913,
  "created_at" : "2015-02-05 00:27:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 0, 15 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563122414322987008",
  "geo" : { },
  "id_str" : "563130742495260672",
  "in_reply_to_user_id" : 2954308119,
  "text" : "@BruceGerencser abortion is legal yet woman are being prosecuted for miscarriage in USA! ugh",
  "id" : 563130742495260672,
  "in_reply_to_status_id" : 563122414322987008,
  "created_at" : "2015-02-05 00:23:26 +0000",
  "in_reply_to_screen_name" : "BruceGerencser",
  "in_reply_to_user_id_str" : "2954308119",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PennyLHowe",
      "screen_name" : "pennycoho",
      "indices" : [ 3, 13 ],
      "id_str" : "504864774",
      "id" : 504864774
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pennycoho\/status\/562819036804030464\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/SJ8vAD0ocj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8-IxICIQAEEQso.jpg",
      "id_str" : "562818855995981825",
      "id" : 562818855995981825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8-IxICIQAEEQso.jpg",
      "sizes" : [ {
        "h" : 303,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 486
      } ],
      "display_url" : "pic.twitter.com\/SJ8vAD0ocj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563109807000125441",
  "text" : "RT @pennycoho: The moons reflection on the placid lake so gorgeous. http:\/\/t.co\/SJ8vAD0ocj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pennycoho\/status\/562819036804030464\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/SJ8vAD0ocj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8-IxICIQAEEQso.jpg",
        "id_str" : "562818855995981825",
        "id" : 562818855995981825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8-IxICIQAEEQso.jpg",
        "sizes" : [ {
          "h" : 303,
          "resize" : "fit",
          "w" : 486
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 486
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 486
        } ],
        "display_url" : "pic.twitter.com\/SJ8vAD0ocj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562819036804030464",
    "text" : "The moons reflection on the placid lake so gorgeous. http:\/\/t.co\/SJ8vAD0ocj",
    "id" : 562819036804030464,
    "created_at" : "2015-02-04 03:44:49 +0000",
    "user" : {
      "name" : "PennyLHowe",
      "screen_name" : "pennycoho",
      "protected" : false,
      "id_str" : "504864774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743844504122208257\/t27UGSJu_normal.jpg",
      "id" : 504864774,
      "verified" : false
    }
  },
  "id" : 563109807000125441,
  "created_at" : "2015-02-04 23:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563109288152141825",
  "text" : "RT @TheGoldenMirror: Acceptance and letting go are keys to unlock a state of inner peace.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563100226459021313",
    "text" : "Acceptance and letting go are keys to unlock a state of inner peace.",
    "id" : 563100226459021313,
    "created_at" : "2015-02-04 22:22:10 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 563109288152141825,
  "created_at" : "2015-02-04 22:58:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben A.",
      "screen_name" : "politicallyme",
      "indices" : [ 3, 17 ],
      "id_str" : "47772403",
      "id" : 47772403
    }, {
      "name" : "Judge Carter",
      "screen_name" : "JudgeCarter",
      "indices" : [ 49, 61 ],
      "id_str" : "18030431",
      "id" : 18030431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563109123974529024",
  "text" : "RT @politicallyme: No repeal without replacement @JudgeCarter How do you feel about #SinglePayer ? I would go for that. Cut out the #middle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Judge Carter",
        "screen_name" : "JudgeCarter",
        "indices" : [ 30, 42 ],
        "id_str" : "18030431",
        "id" : 18030431
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 65, 77 ]
      }, {
        "text" : "middlemen",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "563060042015178752",
    "geo" : { },
    "id_str" : "563061325056991232",
    "in_reply_to_user_id" : 18030431,
    "text" : "No repeal without replacement @JudgeCarter How do you feel about #SinglePayer ? I would go for that. Cut out the #middlemen, save $$",
    "id" : 563061325056991232,
    "in_reply_to_status_id" : 563060042015178752,
    "created_at" : "2015-02-04 19:47:35 +0000",
    "in_reply_to_screen_name" : "JudgeCarter",
    "in_reply_to_user_id_str" : "18030431",
    "user" : {
      "name" : "Ben A.",
      "screen_name" : "politicallyme",
      "protected" : false,
      "id_str" : "47772403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/337881496\/pcgraphpng_normal.png",
      "id" : 47772403,
      "verified" : false
    }
  },
  "id" : 563109123974529024,
  "created_at" : "2015-02-04 22:57:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Drevikovsque\u00F1a",
      "screen_name" : "adrevikovsky",
      "indices" : [ 3, 16 ],
      "id_str" : "420591043",
      "id" : 420591043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563109022224891905",
  "text" : "RT @adrevikovsky: Most heartening eavesdrop ever: Two trainers at the gym this morning having a chat about their goals. \n\"I want to be more\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563099981209686018",
    "text" : "Most heartening eavesdrop ever: Two trainers at the gym this morning having a chat about their goals. \n\"I want to be more open-hearted.\"",
    "id" : 563099981209686018,
    "created_at" : "2015-02-04 22:21:12 +0000",
    "user" : {
      "name" : "La Drevikovsque\u00F1a",
      "screen_name" : "adrevikovsky",
      "protected" : false,
      "id_str" : "420591043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731312663708372992\/xg2ivvFM_normal.jpg",
      "id" : 420591043,
      "verified" : false
    }
  },
  "id" : 563109022224891905,
  "created_at" : "2015-02-04 22:57:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 3, 9 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/zY5DZb2hle",
      "expanded_url" : "http:\/\/slate.me\/1zalJmA",
      "display_url" : "slate.me\/1zalJmA"
    } ]
  },
  "geo" : { },
  "id_str" : "563104682022027265",
  "text" : "RT @Slate: An Indiana woman was convicted of fetal homicide and child neglect--which makes no sense: http:\/\/t.co\/zY5DZb2hle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/zY5DZb2hle",
        "expanded_url" : "http:\/\/slate.me\/1zalJmA",
        "display_url" : "slate.me\/1zalJmA"
      } ]
    },
    "geo" : { },
    "id_str" : "563100468017364992",
    "text" : "An Indiana woman was convicted of fetal homicide and child neglect--which makes no sense: http:\/\/t.co\/zY5DZb2hle",
    "id" : 563100468017364992,
    "created_at" : "2015-02-04 22:23:08 +0000",
    "user" : {
      "name" : "Slate",
      "screen_name" : "Slate",
      "protected" : false,
      "id_str" : "15164565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785838392336678913\/UP9SKq0X_normal.jpg",
      "id" : 15164565,
      "verified" : true
    }
  },
  "id" : 563104682022027265,
  "created_at" : "2015-02-04 22:39:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "indices" : [ 0, 16 ],
      "id_str" : "624392588",
      "id" : 624392588
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ponders",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563078070186545153",
  "geo" : { },
  "id_str" : "563080447048298498",
  "in_reply_to_user_id" : 624392588,
  "text" : "@IvanMor79062729 hmmm.. #ponders",
  "id" : 563080447048298498,
  "in_reply_to_status_id" : 563078070186545153,
  "created_at" : "2015-02-04 21:03:34 +0000",
  "in_reply_to_screen_name" : "IvanMor79062729",
  "in_reply_to_user_id_str" : "624392588",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monty\u2764\uFE0Fpoppylongtail",
      "screen_name" : "thegingermonty",
      "indices" : [ 3, 18 ],
      "id_str" : "1391579966",
      "id" : 1391579966
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thegingermonty\/status\/563069580936220672\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/xmjFCR1dKM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BszO7IQAEfDXg.jpg",
      "id_str" : "563069580856541185",
      "id" : 563069580856541185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BszO7IQAEfDXg.jpg",
      "sizes" : [ {
        "h" : 547,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 547
      } ],
      "display_url" : "pic.twitter.com\/xmjFCR1dKM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563073018898178048",
  "text" : "RT @thegingermonty: Hoomins bought a small litter tray to assist my elderly sisfur... But if i fits, i sits! http:\/\/t.co\/xmjFCR1dKM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thegingermonty\/status\/563069580936220672\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/xmjFCR1dKM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BszO7IQAEfDXg.jpg",
        "id_str" : "563069580856541185",
        "id" : 563069580856541185,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BszO7IQAEfDXg.jpg",
        "sizes" : [ {
          "h" : 547,
          "resize" : "fit",
          "w" : 547
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 547
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 547
        } ],
        "display_url" : "pic.twitter.com\/xmjFCR1dKM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563069580936220672",
    "text" : "Hoomins bought a small litter tray to assist my elderly sisfur... But if i fits, i sits! http:\/\/t.co\/xmjFCR1dKM",
    "id" : 563069580936220672,
    "created_at" : "2015-02-04 20:20:24 +0000",
    "user" : {
      "name" : "Monty\u2764\uFE0Fpoppylongtail",
      "screen_name" : "thegingermonty",
      "protected" : false,
      "id_str" : "1391579966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800423958361362432\/zCdFUur3_normal.jpg",
      "id" : 1391579966,
      "verified" : false
    }
  },
  "id" : 563073018898178048,
  "created_at" : "2015-02-04 20:34:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glennon Doyle Melton",
      "screen_name" : "Momastery",
      "indices" : [ 3, 13 ],
      "id_str" : "67647597",
      "id" : 67647597
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Momastery\/status\/563062211187576832\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ds2tTP40Ux",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BmGA_IEAELuLR.jpg",
      "id_str" : "563062206951329793",
      "id" : 563062206951329793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BmGA_IEAELuLR.jpg",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ds2tTP40Ux"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563062746116530176",
  "text" : "RT @Momastery: There is really only one way to deal gracefully with being human, and that is this: Forgive Yourself. http:\/\/t.co\/Ds2tTP40Ux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Momastery\/status\/563062211187576832\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/Ds2tTP40Ux",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BmGA_IEAELuLR.jpg",
        "id_str" : "563062206951329793",
        "id" : 563062206951329793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BmGA_IEAELuLR.jpg",
        "sizes" : [ {
          "h" : 469,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ds2tTP40Ux"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563062211187576832",
    "text" : "There is really only one way to deal gracefully with being human, and that is this: Forgive Yourself. http:\/\/t.co\/Ds2tTP40Ux",
    "id" : 563062211187576832,
    "created_at" : "2015-02-04 19:51:06 +0000",
    "user" : {
      "name" : "Glennon Doyle Melton",
      "screen_name" : "Momastery",
      "protected" : false,
      "id_str" : "67647597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665203657223204864\/XrxSp5ss_normal.jpg",
      "id" : 67647597,
      "verified" : true
    }
  },
  "id" : 563062746116530176,
  "created_at" : "2015-02-04 19:53:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563056928797245441",
  "text" : "being pulled in different directions. not sure what to think.",
  "id" : 563056928797245441,
  "created_at" : "2015-02-04 19:30:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laureen",
      "screen_name" : "loirspiritual",
      "indices" : [ 3, 17 ],
      "id_str" : "2241638064",
      "id" : 2241638064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563056074644000768",
  "text" : "RT @loirspiritual: When the doors of perception are cleansed man will see things as they truly are, infinite. ~William Blake@Carlolight htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/loirspiritual\/status\/561494181076795393\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aOT7W2ZSAg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8rT-3KIYAI_0HM.jpg",
        "id_str" : "561494180472840194",
        "id" : 561494180472840194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8rT-3KIYAI_0HM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 788,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1248
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/aOT7W2ZSAg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561494181076795393",
    "text" : "When the doors of perception are cleansed man will see things as they truly are, infinite. ~William Blake@Carlolight http:\/\/t.co\/aOT7W2ZSAg",
    "id" : 561494181076795393,
    "created_at" : "2015-01-31 12:00:19 +0000",
    "user" : {
      "name" : "laureen",
      "screen_name" : "loirspiritual",
      "protected" : false,
      "id_str" : "2241638064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413688348704636929\/IeTUsvSQ_normal.png",
      "id" : 2241638064,
      "verified" : false
    }
  },
  "id" : 563056074644000768,
  "created_at" : "2015-02-04 19:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563055204384657409",
  "text" : "sigh. ppl. so much.. name-calling.",
  "id" : 563055204384657409,
  "created_at" : "2015-02-04 19:23:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/563048054321074177\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ODJfYcvdP6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BZOJdIMAEAyjb.jpg",
      "id_str" : "563048053012443137",
      "id" : 563048053012443137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BZOJdIMAEAyjb.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 913
      } ],
      "display_url" : "pic.twitter.com\/ODJfYcvdP6"
    } ],
    "hashtags" : [ {
      "text" : "Blueskies",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "MuteSwan",
      "indices" : [ 46, 55 ]
    }, {
      "text" : "Waterfowl",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563054201614647301",
  "text" : "RT @Swanwhisperer: Perfect Flight! #Blueskies #MuteSwan #Waterfowl http:\/\/t.co\/ODJfYcvdP6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/563048054321074177\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/ODJfYcvdP6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BZOJdIMAEAyjb.jpg",
        "id_str" : "563048053012443137",
        "id" : 563048053012443137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BZOJdIMAEAyjb.jpg",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 913
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 913
        } ],
        "display_url" : "pic.twitter.com\/ODJfYcvdP6"
      } ],
      "hashtags" : [ {
        "text" : "Blueskies",
        "indices" : [ 16, 26 ]
      }, {
        "text" : "MuteSwan",
        "indices" : [ 27, 36 ]
      }, {
        "text" : "Waterfowl",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563048054321074177",
    "text" : "Perfect Flight! #Blueskies #MuteSwan #Waterfowl http:\/\/t.co\/ODJfYcvdP6",
    "id" : 563048054321074177,
    "created_at" : "2015-02-04 18:54:51 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 563054201614647301,
  "created_at" : "2015-02-04 19:19:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Dr. Sanjay Gupta",
      "screen_name" : "drsanjaygupta",
      "indices" : [ 63, 77 ],
      "id_str" : "18170896",
      "id" : 18170896
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 82, 86 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/YSpYrDNWyN",
      "expanded_url" : "http:\/\/cnn.it\/1yIx4vf",
      "display_url" : "cnn.it\/1yIx4vf"
    } ]
  },
  "geo" : { },
  "id_str" : "563053338653368322",
  "text" : "RT @DeepakChopra: Supporting: Vaccines are a matter of fact by @drsanjaygupta via @CNN http:\/\/t.co\/YSpYrDNWyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Sanjay Gupta",
        "screen_name" : "drsanjaygupta",
        "indices" : [ 45, 59 ],
        "id_str" : "18170896",
        "id" : 18170896
      }, {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 64, 68 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/YSpYrDNWyN",
        "expanded_url" : "http:\/\/cnn.it\/1yIx4vf",
        "display_url" : "cnn.it\/1yIx4vf"
      } ]
    },
    "geo" : { },
    "id_str" : "563051824828403712",
    "text" : "Supporting: Vaccines are a matter of fact by @drsanjaygupta via @CNN http:\/\/t.co\/YSpYrDNWyN",
    "id" : 563051824828403712,
    "created_at" : "2015-02-04 19:09:50 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 563053338653368322,
  "created_at" : "2015-02-04 19:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563035552501755904",
  "geo" : { },
  "id_str" : "563047471103102976",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible not all of them are strictly anti-vax. some are leery of big pharma.",
  "id" : 563047471103102976,
  "in_reply_to_status_id" : 563035552501755904,
  "created_at" : "2015-02-04 18:52:32 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myke Cole",
      "screen_name" : "MykeCole",
      "indices" : [ 3, 12 ],
      "id_str" : "206631462",
      "id" : 206631462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563005513483698177",
  "text" : "RT @MykeCole: If you are a student who would like to read a book your school has banned, email me and I'll send it to you. Setting aside mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562993896150810625",
    "text" : "If you are a student who would like to read a book your school has banned, email me and I'll send it to you. Setting aside money for this.",
    "id" : 562993896150810625,
    "created_at" : "2015-02-04 15:19:39 +0000",
    "user" : {
      "name" : "Myke Cole",
      "screen_name" : "MykeCole",
      "protected" : false,
      "id_str" : "206631462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797791923973062657\/nbdmSxyp_normal.jpg",
      "id" : 206631462,
      "verified" : false
    }
  },
  "id" : 563005513483698177,
  "created_at" : "2015-02-04 16:05:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "Hanhwt",
      "indices" : [ 3, 10 ],
      "id_str" : "253016805",
      "id" : 253016805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563005027611328513",
  "text" : "RT @Hanhwt: No such thing as a complete guide to Buddhism. See your motives, and live as harmless a life as possible. Being aware helps.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ahmetada.com\" rel=\"nofollow\"\u003Eqwertyuuuuuuu_appp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562970626454192129",
    "text" : "No such thing as a complete guide to Buddhism. See your motives, and live as harmless a life as possible. Being aware helps.",
    "id" : 562970626454192129,
    "created_at" : "2015-02-04 13:47:11 +0000",
    "user" : {
      "name" : "Dalai Lama",
      "screen_name" : "Hanhwt",
      "protected" : false,
      "id_str" : "253016805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444615662019674112\/uVAHLoHN_normal.jpeg",
      "id" : 253016805,
      "verified" : false
    }
  },
  "id" : 563005027611328513,
  "created_at" : "2015-02-04 16:03:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563004531865550849",
  "text" : "RT @vaxen_var: \u201CEverything we call real is made of things that cannot be regarded as real\u201D \u2013 Niels Bohr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563000347221065729",
    "text" : "\u201CEverything we call real is made of things that cannot be regarded as real\u201D \u2013 Niels Bohr",
    "id" : 563000347221065729,
    "created_at" : "2015-02-04 15:45:17 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 563004531865550849,
  "created_at" : "2015-02-04 16:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562790760488394752",
  "text" : "RT @bunnybuddhism: As the sun causes ice to melt, a kind bunny causes hostility to fade.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562788648773758979",
    "text" : "As the sun causes ice to melt, a kind bunny causes hostility to fade.",
    "id" : 562788648773758979,
    "created_at" : "2015-02-04 01:44:04 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 562790760488394752,
  "created_at" : "2015-02-04 01:52:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ou",
      "screen_name" : "Ou_Prg",
      "indices" : [ 3, 10 ],
      "id_str" : "1092188078",
      "id" : 1092188078
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Ou_Prg\/status\/562689158330990594\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/wHGlUNt5m7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88SzqDIMAMyLwi.jpg",
      "id_str" : "562689157114638339",
      "id" : 562689157114638339,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88SzqDIMAMyLwi.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/wHGlUNt5m7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562751212031066114",
  "text" : "RT @Ou_Prg: Mark Bridger http:\/\/t.co\/wHGlUNt5m7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Ou_Prg\/status\/562689158330990594\/photo\/1",
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/wHGlUNt5m7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88SzqDIMAMyLwi.jpg",
        "id_str" : "562689157114638339",
        "id" : 562689157114638339,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88SzqDIMAMyLwi.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/wHGlUNt5m7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562689158330990594",
    "text" : "Mark Bridger http:\/\/t.co\/wHGlUNt5m7",
    "id" : 562689158330990594,
    "created_at" : "2015-02-03 19:08:44 +0000",
    "user" : {
      "name" : "Ou",
      "screen_name" : "Ou_Prg",
      "protected" : false,
      "id_str" : "1092188078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779391145692495872\/DKzi59jD_normal.jpg",
      "id" : 1092188078,
      "verified" : false
    }
  },
  "id" : 562751212031066114,
  "created_at" : "2015-02-03 23:15:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ou",
      "screen_name" : "Ou_Prg",
      "indices" : [ 3, 10 ],
      "id_str" : "1092188078",
      "id" : 1092188078
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Ou_Prg\/status\/562688739089342465\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/pawU5DXZTJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88SbO2IQAMsI5f.jpg",
      "id_str" : "562688737495498755",
      "id" : 562688737495498755,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88SbO2IQAMsI5f.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/pawU5DXZTJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562750890743185408",
  "text" : "RT @Ou_Prg: Carlos De Azevedo http:\/\/t.co\/pawU5DXZTJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Ou_Prg\/status\/562688739089342465\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/pawU5DXZTJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88SbO2IQAMsI5f.jpg",
        "id_str" : "562688737495498755",
        "id" : 562688737495498755,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88SbO2IQAMsI5f.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/pawU5DXZTJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562688739089342465",
    "text" : "Carlos De Azevedo http:\/\/t.co\/pawU5DXZTJ",
    "id" : 562688739089342465,
    "created_at" : "2015-02-03 19:07:04 +0000",
    "user" : {
      "name" : "Ou",
      "screen_name" : "Ou_Prg",
      "protected" : false,
      "id_str" : "1092188078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779391145692495872\/DKzi59jD_normal.jpg",
      "id" : 1092188078,
      "verified" : false
    }
  },
  "id" : 562750890743185408,
  "created_at" : "2015-02-03 23:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie B.",
      "screen_name" : "RosieB_London",
      "indices" : [ 3, 17 ],
      "id_str" : "247941286",
      "id" : 247941286
    }, {
      "name" : "Teresa Cooper Author",
      "screen_name" : "Teresacooper",
      "indices" : [ 34, 47 ],
      "id_str" : "27935881",
      "id" : 27935881
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RosieB_London\/status\/558622619285860352\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/yMpztgeaI7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8CgT9HIAAEITdo.jpg",
      "id_str" : "558622618476347393",
      "id" : 558622618476347393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8CgT9HIAAEITdo.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 531
      } ],
      "display_url" : "pic.twitter.com\/yMpztgeaI7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562750011398979584",
  "text" : "RT @RosieB_London: Like this one? @Teresacooper http:\/\/t.co\/yMpztgeaI7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Teresa Cooper Author",
        "screen_name" : "Teresacooper",
        "indices" : [ 15, 28 ],
        "id_str" : "27935881",
        "id" : 27935881
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RosieB_London\/status\/558622619285860352\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/yMpztgeaI7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8CgT9HIAAEITdo.jpg",
        "id_str" : "558622618476347393",
        "id" : 558622618476347393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8CgT9HIAAEITdo.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 531
        } ],
        "display_url" : "pic.twitter.com\/yMpztgeaI7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "558622012877574144",
    "geo" : { },
    "id_str" : "558622619285860352",
    "in_reply_to_user_id" : 27935881,
    "text" : "Like this one? @Teresacooper http:\/\/t.co\/yMpztgeaI7",
    "id" : 558622619285860352,
    "in_reply_to_status_id" : 558622012877574144,
    "created_at" : "2015-01-23 13:49:45 +0000",
    "in_reply_to_screen_name" : "Teresacooper",
    "in_reply_to_user_id_str" : "27935881",
    "user" : {
      "name" : "Rosie B.",
      "screen_name" : "RosieB_London",
      "protected" : false,
      "id_str" : "247941286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782687280079200256\/rPTJIsOb_normal.jpg",
      "id" : 247941286,
      "verified" : false
    }
  },
  "id" : 562750011398979584,
  "created_at" : "2015-02-03 23:10:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Emilio Cogliani",
      "screen_name" : "Emils72",
      "indices" : [ 23, 31 ],
      "id_str" : "269926686",
      "id" : 269926686
    }, {
      "name" : "500px",
      "screen_name" : "500px",
      "indices" : [ 70, 76 ],
      "id_str" : "20431922",
      "id" : 20431922
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Emils72\/status\/562542369372123136\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SiBJdpU2sp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B86NTerIIAAjUDY.jpg",
      "id_str" : "562542369258872832",
      "id" : 562542369258872832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B86NTerIIAAjUDY.jpg",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SiBJdpU2sp"
    } ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "landscape",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "image",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562749554840592384",
  "text" : "RT @JamiaStarheart: RT @Emils72: Early Morning Light by HelgeAndersen @500px #photo #landscape #image http:\/\/t.co\/SiBJdpU2sp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emilio Cogliani",
        "screen_name" : "Emils72",
        "indices" : [ 3, 11 ],
        "id_str" : "269926686",
        "id" : 269926686
      }, {
        "name" : "500px",
        "screen_name" : "500px",
        "indices" : [ 50, 56 ],
        "id_str" : "20431922",
        "id" : 20431922
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Emils72\/status\/562542369372123136\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/SiBJdpU2sp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B86NTerIIAAjUDY.jpg",
        "id_str" : "562542369258872832",
        "id" : 562542369258872832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B86NTerIIAAjUDY.jpg",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SiBJdpU2sp"
      } ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "landscape",
        "indices" : [ 64, 74 ]
      }, {
        "text" : "image",
        "indices" : [ 75, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562740590975401984",
    "text" : "RT @Emils72: Early Morning Light by HelgeAndersen @500px #photo #landscape #image http:\/\/t.co\/SiBJdpU2sp",
    "id" : 562740590975401984,
    "created_at" : "2015-02-03 22:33:06 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 562749554840592384,
  "created_at" : "2015-02-03 23:08:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandra Solomides",
      "screen_name" : "northdevonmum",
      "indices" : [ 3, 17 ],
      "id_str" : "65181274",
      "id" : 65181274
    }, {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 34, 50 ],
      "id_str" : "95607516",
      "id" : 95607516
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/northdevonmum\/status\/562741073651707906\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/3qUINW7DkX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B89CBlzIcAESPEe.jpg",
      "id_str" : "562741073538478081",
      "id" : 562741073538478081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B89CBlzIcAESPEe.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/3qUINW7DkX"
    } ],
    "hashtags" : [ {
      "text" : "sidmouth",
      "indices" : [ 51, 60 ]
    }, {
      "text" : "devonlife",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562746798268497920",
  "text" : "RT @northdevonmum: Meet and tweet @donkeysanctuary #sidmouth #devonlife http:\/\/t.co\/3qUINW7DkX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Donkey Sanctuary",
        "screen_name" : "DonkeySanctuary",
        "indices" : [ 15, 31 ],
        "id_str" : "95607516",
        "id" : 95607516
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/northdevonmum\/status\/562741073651707906\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/3qUINW7DkX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B89CBlzIcAESPEe.jpg",
        "id_str" : "562741073538478081",
        "id" : 562741073538478081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B89CBlzIcAESPEe.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/3qUINW7DkX"
      } ],
      "hashtags" : [ {
        "text" : "sidmouth",
        "indices" : [ 32, 41 ]
      }, {
        "text" : "devonlife",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562741073651707906",
    "text" : "Meet and tweet @donkeysanctuary #sidmouth #devonlife http:\/\/t.co\/3qUINW7DkX",
    "id" : 562741073651707906,
    "created_at" : "2015-02-03 22:35:01 +0000",
    "user" : {
      "name" : "Sandra Solomides",
      "screen_name" : "northdevonmum",
      "protected" : false,
      "id_str" : "65181274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486383745529028608\/RScaGrAr_normal.jpeg",
      "id" : 65181274,
      "verified" : false
    }
  },
  "id" : 562746798268497920,
  "created_at" : "2015-02-03 22:57:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Elverojaguar\/status\/502371853319827456\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/M1g7lIvYOv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvjIierIAAAMFp7.jpg",
      "id_str" : "502371853126860800",
      "id" : 502371853126860800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvjIierIAAAMFp7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/M1g7lIvYOv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562734803204997124",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/M1g7lIvYOv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Elverojaguar\/status\/502371853319827456\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/M1g7lIvYOv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvjIierIAAAMFp7.jpg",
        "id_str" : "502371853126860800",
        "id" : 502371853126860800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvjIierIAAAMFp7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/M1g7lIvYOv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562729791699574786",
    "text" : "http:\/\/t.co\/M1g7lIvYOv",
    "id" : 562729791699574786,
    "created_at" : "2015-02-03 21:50:12 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 562734803204997124,
  "created_at" : "2015-02-03 22:10:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562725790677495808",
  "text" : "RT @Joshua_St_John: Well...isn't Twitter a lovely place today?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562725639196000256",
    "text" : "Well...isn't Twitter a lovely place today?",
    "id" : 562725639196000256,
    "created_at" : "2015-02-03 21:33:41 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 562725790677495808,
  "created_at" : "2015-02-03 21:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562688899278200832",
  "text" : "RT @JohnFugelsang: If any of these politicians actually believed in a free market we'd all be too busy buying cheap Canadian drugs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562686615232217089",
    "text" : "If any of these politicians actually believed in a free market we'd all be too busy buying cheap Canadian drugs.",
    "id" : 562686615232217089,
    "created_at" : "2015-02-03 18:58:37 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 562688899278200832,
  "created_at" : "2015-02-03 19:07:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/562686850801098754\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/BIyvsjVA0Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88Qs8TIYAAQoqt.jpg",
      "id_str" : "562686842731257856",
      "id" : 562686842731257856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88Qs8TIYAAQoqt.jpg",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 674
      } ],
      "display_url" : "pic.twitter.com\/BIyvsjVA0Y"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/562686850801098754\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/BIyvsjVA0Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88QtMxIEAI_DMo.jpg",
      "id_str" : "562686847152033794",
      "id" : 562686847152033794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88QtMxIEAI_DMo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BIyvsjVA0Y"
    } ],
    "hashtags" : [ {
      "text" : "MyPatch",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "MyWildlifeWalk",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562688713025921025",
  "text" : "RT @CamoDave_: Buzzard from #MyPatch Saltersford Locks, Cheshire #MyWildlifeWalk 2\/2\/2015 http:\/\/t.co\/BIyvsjVA0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/562686850801098754\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/BIyvsjVA0Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88Qs8TIYAAQoqt.jpg",
        "id_str" : "562686842731257856",
        "id" : 562686842731257856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88Qs8TIYAAQoqt.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 674
        } ],
        "display_url" : "pic.twitter.com\/BIyvsjVA0Y"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/562686850801098754\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/BIyvsjVA0Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88QtMxIEAI_DMo.jpg",
        "id_str" : "562686847152033794",
        "id" : 562686847152033794,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88QtMxIEAI_DMo.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BIyvsjVA0Y"
      } ],
      "hashtags" : [ {
        "text" : "MyPatch",
        "indices" : [ 13, 21 ]
      }, {
        "text" : "MyWildlifeWalk",
        "indices" : [ 50, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562686850801098754",
    "text" : "Buzzard from #MyPatch Saltersford Locks, Cheshire #MyWildlifeWalk 2\/2\/2015 http:\/\/t.co\/BIyvsjVA0Y",
    "id" : 562686850801098754,
    "created_at" : "2015-02-03 18:59:34 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 562688713025921025,
  "created_at" : "2015-02-03 19:06:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scarlet Imprint",
      "screen_name" : "scarletimprint",
      "indices" : [ 3, 18 ],
      "id_str" : "378094621",
      "id" : 378094621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scarletimprint\/status\/562672919432945667\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/63h6GbIxxq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88ECcgCAAATAT3.jpg",
      "id_str" : "562672918501392384",
      "id" : 562672918501392384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88ECcgCAAATAT3.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/63h6GbIxxq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562682895870210049",
  "text" : "RT @scarletimprint: We have plans. http:\/\/t.co\/63h6GbIxxq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scarletimprint\/status\/562672919432945667\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/63h6GbIxxq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88ECcgCAAATAT3.jpg",
        "id_str" : "562672918501392384",
        "id" : 562672918501392384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88ECcgCAAATAT3.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/63h6GbIxxq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562672919432945667",
    "text" : "We have plans. http:\/\/t.co\/63h6GbIxxq",
    "id" : 562672919432945667,
    "created_at" : "2015-02-03 18:04:12 +0000",
    "user" : {
      "name" : "Scarlet Imprint",
      "screen_name" : "scarletimprint",
      "protected" : false,
      "id_str" : "378094621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1556328029\/si_facebook_normal.jpg",
      "id" : 378094621,
      "verified" : false
    }
  },
  "id" : 562682895870210049,
  "created_at" : "2015-02-03 18:43:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Malone",
      "screen_name" : "bylukemalone",
      "indices" : [ 87, 100 ],
      "id_str" : "400090964",
      "id" : 400090964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/L3vNRwdOtt",
      "expanded_url" : "https:\/\/medium.com\/matter\/youre-16-youre-a-pedophile-you-dont-want-to-hurt-anyone-what-do-you-do-now-e11ce4b88bdb?source=tw-lo_f88563526772-1422988224985",
      "display_url" : "medium.com\/matter\/youre-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562679611407208448",
  "text" : "\u201CYou\u2019re 16. You\u2019re a Pedophile. You Don\u2019t Want to Hurt Anyone. What Do You Do Now?\u201D by @bylukemalone https:\/\/t.co\/L3vNRwdOtt",
  "id" : 562679611407208448,
  "created_at" : "2015-02-03 18:30:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 0, 9 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562674191636647936",
  "geo" : { },
  "id_str" : "562675292100362240",
  "in_reply_to_user_id" : 290187508,
  "text" : "@rjmedwed Gay hell? now that sounds like a fun place to be! : )",
  "id" : 562675292100362240,
  "in_reply_to_status_id" : 562674191636647936,
  "created_at" : "2015-02-03 18:13:38 +0000",
  "in_reply_to_screen_name" : "rjmedwed",
  "in_reply_to_user_id_str" : "290187508",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Scanlon",
      "screen_name" : "scanlon_kate",
      "indices" : [ 3, 16 ],
      "id_str" : "4472376981",
      "id" : 4472376981
    }, {
      "name" : "Yeonmi, Park. ( \uBC15\uC5F0\uBBF8)",
      "screen_name" : "YeonmiParkNK",
      "indices" : [ 88, 101 ],
      "id_str" : "400525494",
      "id" : 400525494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackThemBack",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PXRBnTRVVZ",
      "expanded_url" : "http:\/\/dailysign.al\/1tK51PB",
      "display_url" : "dailysign.al\/1tK51PB"
    } ]
  },
  "geo" : { },
  "id_str" : "562663194427416576",
  "text" : "RT @scanlon_kate: \"'Titanic' made me realize that I was controlled by the regime,\u201D said @YeonmiParkNK. #HackThemBack http:\/\/t.co\/PXRBnTRVVZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yeonmi, Park. ( \uBC15\uC5F0\uBBF8)",
        "screen_name" : "YeonmiParkNK",
        "indices" : [ 70, 83 ],
        "id_str" : "400525494",
        "id" : 400525494
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HackThemBack",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/PXRBnTRVVZ",
        "expanded_url" : "http:\/\/dailysign.al\/1tK51PB",
        "display_url" : "dailysign.al\/1tK51PB"
      } ]
    },
    "geo" : { },
    "id_str" : "552194902356815872",
    "text" : "\"'Titanic' made me realize that I was controlled by the regime,\u201D said @YeonmiParkNK. #HackThemBack http:\/\/t.co\/PXRBnTRVVZ",
    "id" : 552194902356815872,
    "created_at" : "2015-01-05 20:08:18 +0000",
    "user" : {
      "name" : "Kate Scanlon",
      "screen_name" : "kgscanlon",
      "protected" : false,
      "id_str" : "844401067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544867689949585408\/aEgjIpxJ_normal.jpeg",
      "id" : 844401067,
      "verified" : true
    }
  },
  "id" : 562663194427416576,
  "created_at" : "2015-02-03 17:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/562609297021231104\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/q6gT8rFeDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B87KLIkIMAA1hwd.jpg",
      "id_str" : "562609296094277632",
      "id" : 562609296094277632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B87KLIkIMAA1hwd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q6gT8rFeDA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562614596436254721",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/q6gT8rFeDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/562609297021231104\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/q6gT8rFeDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B87KLIkIMAA1hwd.jpg",
        "id_str" : "562609296094277632",
        "id" : 562609296094277632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B87KLIkIMAA1hwd.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q6gT8rFeDA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562609297021231104",
    "text" : "\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E\uD83D\uDC3E http:\/\/t.co\/q6gT8rFeDA",
    "id" : 562609297021231104,
    "created_at" : "2015-02-03 13:51:23 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 562614596436254721,
  "created_at" : "2015-02-03 14:12:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/513929085685608448\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/DCAjinEVQr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByHXx8fIUAEY-Q3.jpg",
      "id_str" : "513929085547204609",
      "id" : 513929085547204609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByHXx8fIUAEY-Q3.jpg",
      "sizes" : [ {
        "h" : 514,
        "resize" : "fit",
        "w" : 775
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 775
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DCAjinEVQr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562425349943083008",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/DCAjinEVQr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/513929085685608448\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/DCAjinEVQr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByHXx8fIUAEY-Q3.jpg",
        "id_str" : "513929085547204609",
        "id" : 513929085547204609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByHXx8fIUAEY-Q3.jpg",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 775
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 775
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DCAjinEVQr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562422722559737856",
    "text" : "http:\/\/t.co\/DCAjinEVQr",
    "id" : 562422722559737856,
    "created_at" : "2015-02-03 01:30:01 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 562425349943083008,
  "created_at" : "2015-02-03 01:40:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@cute",
      "screen_name" : "cute",
      "indices" : [ 3, 8 ],
      "id_str" : "1606738363",
      "id" : 1606738363
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cute\/status\/562411493548101632\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/pFb8YEw1Al",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B84WReyIgAAFTXT.jpg",
      "id_str" : "562411493044813824",
      "id" : 562411493044813824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84WReyIgAAFTXT.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pFb8YEw1Al"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562415296666144768",
  "text" : "RT @cute: That is one fat raccoon http:\/\/t.co\/pFb8YEw1Al",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cute\/status\/562411493548101632\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/pFb8YEw1Al",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B84WReyIgAAFTXT.jpg",
        "id_str" : "562411493044813824",
        "id" : 562411493044813824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84WReyIgAAFTXT.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pFb8YEw1Al"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562411493548101632",
    "text" : "That is one fat raccoon http:\/\/t.co\/pFb8YEw1Al",
    "id" : 562411493548101632,
    "created_at" : "2015-02-03 00:45:23 +0000",
    "user" : {
      "name" : "@cute",
      "screen_name" : "cute",
      "protected" : false,
      "id_str" : "1606738363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526252799139381248\/4iMw21C4_normal.jpeg",
      "id" : 1606738363,
      "verified" : false
    }
  },
  "id" : 562415296666144768,
  "created_at" : "2015-02-03 01:00:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 3, 18 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BruceGerencser\/status\/562412352789032961\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/qko4yER1iq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B84XDf5IEAEgeMS.jpg",
      "id_str" : "562412352336039937",
      "id" : 562412352336039937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84XDf5IEAEgeMS.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qko4yER1iq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/XDVjMdXw9n",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/bruce-love-respect-position\/",
      "display_url" : "brucegerencser.net\/2015\/02\/bruce-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562415207671431168",
  "text" : "RT @BruceGerencser: Bruce, I Love and Respect Your Position http:\/\/t.co\/XDVjMdXw9n http:\/\/t.co\/qko4yER1iq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BruceGerencser\/status\/562412352789032961\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/qko4yER1iq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B84XDf5IEAEgeMS.jpg",
        "id_str" : "562412352336039937",
        "id" : 562412352336039937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84XDf5IEAEgeMS.jpg",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qko4yER1iq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/XDVjMdXw9n",
        "expanded_url" : "http:\/\/brucegerencser.net\/2015\/02\/bruce-love-respect-position\/",
        "display_url" : "brucegerencser.net\/2015\/02\/bruce-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562412352789032961",
    "text" : "Bruce, I Love and Respect Your Position http:\/\/t.co\/XDVjMdXw9n http:\/\/t.co\/qko4yER1iq",
    "id" : 562412352789032961,
    "created_at" : "2015-02-03 00:48:48 +0000",
    "user" : {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "protected" : false,
      "id_str" : "2954308119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708165822007480320\/bzYNwh2A_normal.jpg",
      "id" : 2954308119,
      "verified" : false
    }
  },
  "id" : 562415207671431168,
  "created_at" : "2015-02-03 01:00:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vijil C",
      "screen_name" : "vijilkumarc10",
      "indices" : [ 3, 17 ],
      "id_str" : "2739462943",
      "id" : 2739462943
    }, {
      "name" : "Joanna",
      "screen_name" : "me5205203732",
      "indices" : [ 20, 33 ],
      "id_str" : "2794415206",
      "id" : 2794415206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/me5205203732\/status\/561117822311350273\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/FOb4X8xVyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8l9rdQCAAE8liF.jpg",
      "id_str" : "561117814124052481",
      "id" : 561117814124052481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8l9rdQCAAE8liF.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/FOb4X8xVyc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562413909106515969",
  "text" : "RT @vijilkumarc10: \"@me5205203732: http:\/\/t.co\/FOb4X8xVyc\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joanna",
        "screen_name" : "me5205203732",
        "indices" : [ 1, 14 ],
        "id_str" : "2794415206",
        "id" : 2794415206
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/me5205203732\/status\/561117822311350273\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/FOb4X8xVyc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8l9rdQCAAE8liF.jpg",
        "id_str" : "561117814124052481",
        "id" : 561117814124052481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8l9rdQCAAE8liF.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/FOb4X8xVyc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561201643681619968",
    "text" : "\"@me5205203732: http:\/\/t.co\/FOb4X8xVyc\"",
    "id" : 561201643681619968,
    "created_at" : "2015-01-30 16:37:53 +0000",
    "user" : {
      "name" : "Vijil C",
      "screen_name" : "vijilkumarc10",
      "protected" : false,
      "id_str" : "2739462943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799676008290983937\/ECaRvWh4_normal.jpg",
      "id" : 2739462943,
      "verified" : false
    }
  },
  "id" : 562413909106515969,
  "created_at" : "2015-02-03 00:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/CWNwZpxTR3",
      "expanded_url" : "http:\/\/etsy.me\/16bICiH",
      "display_url" : "etsy.me\/16bICiH"
    } ]
  },
  "geo" : { },
  "id_str" : "562408374319714305",
  "text" : "a friend recycles jeans and more into bags &gt; TheOldBagHP http:\/\/t.co\/CWNwZpxTR3",
  "id" : 562408374319714305,
  "created_at" : "2015-02-03 00:33:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/2wraA7ZIUx",
      "expanded_url" : "https:\/\/www.facebook.com\/lotterdj\/posts\/10204823472180395",
      "display_url" : "facebook.com\/lotterdj\/posts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562391947525238784",
  "text" : "Is it inappropriate? \"Then much of classic and modern art will be inappropriate for you too.\" https:\/\/t.co\/2wraA7ZIUx",
  "id" : 562391947525238784,
  "created_at" : "2015-02-02 23:27:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ificouldtellu\/status\/562295992267968512\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/JNMzl7gZsH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82tOcGCMAAYpti.png",
      "id_str" : "562295992062455808",
      "id" : 562295992062455808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82tOcGCMAAYpti.png",
      "sizes" : [ {
        "h" : 149,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 79,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 149,
        "resize" : "crop",
        "w" : 149
      } ],
      "display_url" : "pic.twitter.com\/JNMzl7gZsH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562299404959629312",
  "text" : "RT @ificouldtellu: http:\/\/t.co\/JNMzl7gZsH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ificouldtellu\/status\/562295992267968512\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/JNMzl7gZsH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B82tOcGCMAAYpti.png",
        "id_str" : "562295992062455808",
        "id" : 562295992062455808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82tOcGCMAAYpti.png",
        "sizes" : [ {
          "h" : 149,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 140,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 79,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 149,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 149,
          "resize" : "crop",
          "w" : 149
        } ],
        "display_url" : "pic.twitter.com\/JNMzl7gZsH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562295992267968512",
    "text" : "http:\/\/t.co\/JNMzl7gZsH",
    "id" : 562295992267968512,
    "created_at" : "2015-02-02 17:06:26 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 562299404959629312,
  "created_at" : "2015-02-02 17:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Reza Aslan)))",
      "screen_name" : "rezaaslan",
      "indices" : [ 3, 13 ],
      "id_str" : "262856460",
      "id" : 262856460
    }, {
      "name" : "TheDean'sReport",
      "screen_name" : "TheDeansreport",
      "indices" : [ 79, 94 ],
      "id_str" : "495211603",
      "id" : 495211603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Qyf1DQjfRT",
      "expanded_url" : "http:\/\/thebea.st\/1HHkgi5",
      "display_url" : "thebea.st\/1HHkgi5"
    } ]
  },
  "geo" : { },
  "id_str" : "562299336240144384",
  "text" : "RT @rezaaslan: Mike Huckabee\u2019s Christian Sharia Law http:\/\/t.co\/Qyf1DQjfRT via @TheDeansreport",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheDean'sReport",
        "screen_name" : "TheDeansreport",
        "indices" : [ 64, 79 ],
        "id_str" : "495211603",
        "id" : 495211603
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/Qyf1DQjfRT",
        "expanded_url" : "http:\/\/thebea.st\/1HHkgi5",
        "display_url" : "thebea.st\/1HHkgi5"
      } ]
    },
    "geo" : { },
    "id_str" : "562293149972709377",
    "text" : "Mike Huckabee\u2019s Christian Sharia Law http:\/\/t.co\/Qyf1DQjfRT via @TheDeansreport",
    "id" : 562293149972709377,
    "created_at" : "2015-02-02 16:55:08 +0000",
    "user" : {
      "name" : "(((Reza Aslan)))",
      "screen_name" : "rezaaslan",
      "protected" : false,
      "id_str" : "262856460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777370323062779904\/K3tzVCOV_normal.jpg",
      "id" : 262856460,
      "verified" : true
    }
  },
  "id" : 562299336240144384,
  "created_at" : "2015-02-02 17:19:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "indices" : [ 3, 19 ],
      "id_str" : "492604254",
      "id" : 492604254
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanadaGoose",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562298510595592192",
  "text" : "RT @naturechronicle: A #CanadaGoose walks towards me, hoping I have a treat, hears the shutter release, and gives me a quizzical look. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/naturechronicle\/status\/561544239020908544\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/rIEikcRWaR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8sBgTICEAAPgl_.jpg",
        "id_str" : "561544232939163648",
        "id" : 561544232939163648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8sBgTICEAAPgl_.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/rIEikcRWaR"
      } ],
      "hashtags" : [ {
        "text" : "CanadaGoose",
        "indices" : [ 2, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561544239020908544",
    "text" : "A #CanadaGoose walks towards me, hoping I have a treat, hears the shutter release, and gives me a quizzical look. http:\/\/t.co\/rIEikcRWaR",
    "id" : 561544239020908544,
    "created_at" : "2015-01-31 15:19:14 +0000",
    "user" : {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "protected" : false,
      "id_str" : "492604254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3166619966\/e7f8777d0fc93299ea6002d3e754aca8_normal.jpeg",
      "id" : 492604254,
      "verified" : false
    }
  },
  "id" : 562298510595592192,
  "created_at" : "2015-02-02 17:16:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Parks",
      "screen_name" : "AlpacaBook",
      "indices" : [ 3, 14 ],
      "id_str" : "863069328",
      "id" : 863069328
    }, {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 68, 84 ],
      "id_str" : "95607516",
      "id" : 95607516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DiveforDonkeys",
      "indices" : [ 16, 31 ]
    }, {
      "text" : "doitfordonkeys",
      "indices" : [ 86, 101 ]
    }, {
      "text" : "donkeys",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PLIIEfKlXv",
      "expanded_url" : "http:\/\/smarturl.it\/NewDonkey",
      "display_url" : "smarturl.it\/NewDonkey"
    } ]
  },
  "geo" : { },
  "id_str" : "562289573192302592",
  "text" : "RT @AlpacaBook: #DiveforDonkeys fundraising Royalties in February 2 @DonkeySanctuary! #doitfordonkeys #donkeys http:\/\/t.co\/PLIIEfKlXv http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Donkey Sanctuary",
        "screen_name" : "DonkeySanctuary",
        "indices" : [ 52, 68 ],
        "id_str" : "95607516",
        "id" : 95607516
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlpacaBook\/status\/562006722873937920\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/C3M8wkr9Zc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8ymIgsIUAINkSp.jpg",
        "id_str" : "562006718658662402",
        "id" : 562006718658662402,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8ymIgsIUAINkSp.jpg",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 176
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 176
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 176
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 176
        } ],
        "display_url" : "pic.twitter.com\/C3M8wkr9Zc"
      } ],
      "hashtags" : [ {
        "text" : "DiveforDonkeys",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "doitfordonkeys",
        "indices" : [ 70, 85 ]
      }, {
        "text" : "donkeys",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/PLIIEfKlXv",
        "expanded_url" : "http:\/\/smarturl.it\/NewDonkey",
        "display_url" : "smarturl.it\/NewDonkey"
      } ]
    },
    "geo" : { },
    "id_str" : "562006722873937920",
    "text" : "#DiveforDonkeys fundraising Royalties in February 2 @DonkeySanctuary! #doitfordonkeys #donkeys http:\/\/t.co\/PLIIEfKlXv http:\/\/t.co\/C3M8wkr9Zc",
    "id" : 562006722873937920,
    "created_at" : "2015-02-01 21:56:58 +0000",
    "user" : {
      "name" : "Alan Parks",
      "screen_name" : "AlpacaBook",
      "protected" : false,
      "id_str" : "863069328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669496134310764544\/GY0T-g-m_normal.jpg",
      "id" : 863069328,
      "verified" : false
    }
  },
  "id" : 562289573192302592,
  "created_at" : "2015-02-02 16:40:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Woody",
      "screen_name" : "spottyscope",
      "indices" : [ 3, 15 ],
      "id_str" : "235636443",
      "id" : 235636443
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bison",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/FaMLAeYVKm",
      "expanded_url" : "http:\/\/flic.kr\/p\/iVfrWd",
      "display_url" : "flic.kr\/p\/iVfrWd"
    } ]
  },
  "geo" : { },
  "id_str" : "562276993816080384",
  "text" : "RT @spottyscope: Bison silhouette :-) #bison http:\/\/t.co\/FaMLAeYVKm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bison",
        "indices" : [ 21, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/FaMLAeYVKm",
        "expanded_url" : "http:\/\/flic.kr\/p\/iVfrWd",
        "display_url" : "flic.kr\/p\/iVfrWd"
      } ]
    },
    "geo" : { },
    "id_str" : "419574826874200064",
    "text" : "Bison silhouette :-) #bison http:\/\/t.co\/FaMLAeYVKm",
    "id" : 419574826874200064,
    "created_at" : "2014-01-04 21:03:28 +0000",
    "user" : {
      "name" : "Woody",
      "screen_name" : "spottyscope",
      "protected" : false,
      "id_str" : "235636443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1210299352\/040_normal.JPG",
      "id" : 235636443,
      "verified" : false
    }
  },
  "id" : 562276993816080384,
  "created_at" : "2015-02-02 15:50:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sofia Resnick",
      "screen_name" : "SofiaResnick",
      "indices" : [ 3, 16 ],
      "id_str" : "231546220",
      "id" : 231546220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562276848064036865",
  "text" : "RT @SofiaResnick: Not just about abortion: Lawyers of fetuses can override pregnant women's medical decisions or even send them to jail htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/HBOWrwCWrv",
        "expanded_url" : "http:\/\/rhrc.us\/1Ev3lwH",
        "display_url" : "rhrc.us\/1Ev3lwH"
      } ]
    },
    "geo" : { },
    "id_str" : "562267334392700928",
    "text" : "Not just about abortion: Lawyers of fetuses can override pregnant women's medical decisions or even send them to jail http:\/\/t.co\/HBOWrwCWrv",
    "id" : 562267334392700928,
    "created_at" : "2015-02-02 15:12:33 +0000",
    "user" : {
      "name" : "Sofia Resnick",
      "screen_name" : "SofiaResnick",
      "protected" : false,
      "id_str" : "231546220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515130634964971522\/FQojavtl_normal.jpeg",
      "id" : 231546220,
      "verified" : false
    }
  },
  "id" : 562276848064036865,
  "created_at" : "2015-02-02 15:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JUNE",
      "screen_name" : "JUNESOBIE",
      "indices" : [ 3, 13 ],
      "id_str" : "238574643",
      "id" : 238574643
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JUNESOBIE\/status\/562270951136452609\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/HhuPR0i2CG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82WczPCcAEdhoS.jpg",
      "id_str" : "562270950024966145",
      "id" : 562270950024966145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82WczPCcAEdhoS.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HhuPR0i2CG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562273506873069568",
  "text" : "RT @JUNESOBIE: can you see me now lol http:\/\/t.co\/HhuPR0i2CG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JUNESOBIE\/status\/562270951136452609\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/HhuPR0i2CG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B82WczPCcAEdhoS.jpg",
        "id_str" : "562270950024966145",
        "id" : 562270950024966145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82WczPCcAEdhoS.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HhuPR0i2CG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562270951136452609",
    "text" : "can you see me now lol http:\/\/t.co\/HhuPR0i2CG",
    "id" : 562270951136452609,
    "created_at" : "2015-02-02 15:26:55 +0000",
    "user" : {
      "name" : "JUNE",
      "screen_name" : "JUNESOBIE",
      "protected" : false,
      "id_str" : "238574643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800372418418188288\/ai5eG9ig_normal.jpg",
      "id" : 238574643,
      "verified" : false
    }
  },
  "id" : 562273506873069568,
  "created_at" : "2015-02-02 15:37:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "indices" : [ 3, 16 ],
      "id_str" : "1413936181",
      "id" : 1413936181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Snow",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "farm365",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562260908249219072",
  "text" : "RT @FionaJDavies: Just love the hens reaction to #Snow first lot run to the door, brake, 100 hen pile up at the back... #farm365 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FionaJDavies\/status\/562170640208510976\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/S1Zv45vafE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B807MTcIMAAyzFM.jpg",
        "id_str" : "562170611053899776",
        "id" : 562170611053899776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B807MTcIMAAyzFM.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/S1Zv45vafE"
      } ],
      "hashtags" : [ {
        "text" : "Snow",
        "indices" : [ 31, 36 ]
      }, {
        "text" : "farm365",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562170640208510976",
    "text" : "Just love the hens reaction to #Snow first lot run to the door, brake, 100 hen pile up at the back... #farm365 http:\/\/t.co\/S1Zv45vafE",
    "id" : 562170640208510976,
    "created_at" : "2015-02-02 08:48:19 +0000",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "protected" : false,
      "id_str" : "1413936181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456679350880829440\/z2YfOoH2_normal.jpeg",
      "id" : 1413936181,
      "verified" : false
    }
  },
  "id" : 562260908249219072,
  "created_at" : "2015-02-02 14:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "nprnews",
      "indices" : [ 3, 11 ],
      "id_str" : "3386439610",
      "id" : 3386439610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562036401035034624",
  "text" : "RT @nprnews: Or, if you're avoiding the Super Bowl altogether, here are some cows being rescued from an icy pond in Colorado: http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/iYxsgh6jzi",
        "expanded_url" : "http:\/\/n.pr\/1ztehH1",
        "display_url" : "n.pr\/1ztehH1"
      } ]
    },
    "geo" : { },
    "id_str" : "562030853724065793",
    "text" : "Or, if you're avoiding the Super Bowl altogether, here are some cows being rescued from an icy pond in Colorado: http:\/\/t.co\/iYxsgh6jzi",
    "id" : 562030853724065793,
    "created_at" : "2015-02-01 23:32:52 +0000",
    "user" : {
      "name" : "NPR",
      "screen_name" : "NPR",
      "protected" : false,
      "id_str" : "5392522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722199003845304320\/s2zwEoao_normal.jpg",
      "id" : 5392522,
      "verified" : true
    }
  },
  "id" : 562036401035034624,
  "created_at" : "2015-02-01 23:54:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gideon Knight",
      "screen_name" : "Earlywormbirder",
      "indices" : [ 3, 19 ],
      "id_str" : "890970674",
      "id" : 890970674
    }, {
      "name" : "Rare Bird Network",
      "screen_name" : "rbnUK",
      "indices" : [ 115, 121 ],
      "id_str" : "579091796",
      "id" : 579091796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rbnESS",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562021015631716353",
  "text" : "RT @Earlywormbirder: Took three hours to find, but well worth it! One of two Serins at Gunners Park this afternoon @rbnUK #rbnESS http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rare Bird Network",
        "screen_name" : "rbnUK",
        "indices" : [ 94, 100 ],
        "id_str" : "579091796",
        "id" : 579091796
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Earlywormbirder\/status\/561975047242252288\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/UWe0DX7KYc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8yJU75IQAI7jht.jpg",
        "id_str" : "561975046282166274",
        "id" : 561975046282166274,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8yJU75IQAI7jht.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/UWe0DX7KYc"
      } ],
      "hashtags" : [ {
        "text" : "rbnESS",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561975047242252288",
    "text" : "Took three hours to find, but well worth it! One of two Serins at Gunners Park this afternoon @rbnUK #rbnESS http:\/\/t.co\/UWe0DX7KYc",
    "id" : 561975047242252288,
    "created_at" : "2015-02-01 19:51:06 +0000",
    "user" : {
      "name" : "Gideon Knight",
      "screen_name" : "Earlywormbirder",
      "protected" : false,
      "id_str" : "890970674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699897012943192064\/RwlCzV2u_normal.jpg",
      "id" : 890970674,
      "verified" : false
    }
  },
  "id" : 562021015631716353,
  "created_at" : "2015-02-01 22:53:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Pritt",
      "screen_name" : "jwpfarming",
      "indices" : [ 3, 14 ],
      "id_str" : "421998278",
      "id" : 421998278
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jwpfarming\/status\/561953164388478978\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/otctGFhhw0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x1aY0IQAAo0OQ.jpg",
      "id_str" : "561953149712613376",
      "id" : 561953149712613376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x1aY0IQAAo0OQ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/otctGFhhw0"
    } ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561973247521345536",
  "text" : "RT @jwpfarming: Heavy traffic on the Cumbrian fells #farm365 http:\/\/t.co\/otctGFhhw0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jwpfarming\/status\/561953164388478978\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/otctGFhhw0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x1aY0IQAAo0OQ.jpg",
        "id_str" : "561953149712613376",
        "id" : 561953149712613376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x1aY0IQAAo0OQ.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/otctGFhhw0"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 36, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561953164388478978",
    "text" : "Heavy traffic on the Cumbrian fells #farm365 http:\/\/t.co\/otctGFhhw0",
    "id" : 561953164388478978,
    "created_at" : "2015-02-01 18:24:09 +0000",
    "user" : {
      "name" : "Jimmy Pritt",
      "screen_name" : "jwpfarming",
      "protected" : false,
      "id_str" : "421998278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609862798672306176\/lcmXzUZi_normal.jpg",
      "id" : 421998278,
      "verified" : false
    }
  },
  "id" : 561973247521345536,
  "created_at" : "2015-02-01 19:43:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JLazyS Chyenne",
      "screen_name" : "JLazySAngus",
      "indices" : [ 3, 15 ],
      "id_str" : "2192900514",
      "id" : 2192900514
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JLazySAngus\/status\/561722692269641728\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QDUsSGtz5L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8ujxD-CQAEeAeC.jpg",
      "id_str" : "561722641812176897",
      "id" : 561722641812176897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8ujxD-CQAEeAeC.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QDUsSGtz5L"
    } ],
    "hashtags" : [ {
      "text" : "RanchLife",
      "indices" : [ 96, 106 ]
    }, {
      "text" : "farm365",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561973170778148864",
  "text" : "RT @JLazySAngus: When everyone else's mom has picked them up but yours is nowhere in sight  ... #RanchLife #farm365 http:\/\/t.co\/QDUsSGtz5L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JLazySAngus\/status\/561722692269641728\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/QDUsSGtz5L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8ujxD-CQAEeAeC.jpg",
        "id_str" : "561722641812176897",
        "id" : 561722641812176897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8ujxD-CQAEeAeC.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QDUsSGtz5L"
      } ],
      "hashtags" : [ {
        "text" : "RanchLife",
        "indices" : [ 79, 89 ]
      }, {
        "text" : "farm365",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561722692269641728",
    "text" : "When everyone else's mom has picked them up but yours is nowhere in sight  ... #RanchLife #farm365 http:\/\/t.co\/QDUsSGtz5L",
    "id" : 561722692269641728,
    "created_at" : "2015-02-01 03:08:20 +0000",
    "user" : {
      "name" : "JLazyS Chyenne",
      "screen_name" : "JLazySAngus",
      "protected" : false,
      "id_str" : "2192900514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439079417361338368\/luOBa6gw_normal.jpeg",
      "id" : 2192900514,
      "verified" : false
    }
  },
  "id" : 561973170778148864,
  "created_at" : "2015-02-01 19:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geraint Evans",
      "screen_name" : "foxyfarmer79",
      "indices" : [ 3, 16 ],
      "id_str" : "479843876",
      "id" : 479843876
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/foxyfarmer79\/status\/561954799592427521\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/E4LvANXZqm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x258xCAAA3V6P.jpg",
      "id_str" : "561954791450869760",
      "id" : 561954791450869760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x258xCAAA3V6P.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/E4LvANXZqm"
    } ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561971948180496384",
  "text" : "RT @foxyfarmer79: The highlanders out at grass,from when I worked up in Scotland.#farm365 http:\/\/t.co\/E4LvANXZqm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/foxyfarmer79\/status\/561954799592427521\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/E4LvANXZqm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x258xCAAA3V6P.jpg",
        "id_str" : "561954791450869760",
        "id" : 561954791450869760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x258xCAAA3V6P.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/E4LvANXZqm"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561954799592427521",
    "text" : "The highlanders out at grass,from when I worked up in Scotland.#farm365 http:\/\/t.co\/E4LvANXZqm",
    "id" : 561954799592427521,
    "created_at" : "2015-02-01 18:30:39 +0000",
    "user" : {
      "name" : "Geraint Evans",
      "screen_name" : "foxyfarmer79",
      "protected" : false,
      "id_str" : "479843876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2673941750\/c70a5a4d945771e7a8538c18b97f421b_normal.jpeg",
      "id" : 479843876,
      "verified" : false
    }
  },
  "id" : 561971948180496384,
  "created_at" : "2015-02-01 19:38:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "indices" : [ 3, 18 ],
      "id_str" : "2285980750",
      "id" : 2285980750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561971823685165058",
  "text" : "RT @ariastarbright: Accepting and loving those dark parts of yourself is the first step in healing humanity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561970915391864833",
    "text" : "Accepting and loving those dark parts of yourself is the first step in healing humanity",
    "id" : 561970915391864833,
    "created_at" : "2015-02-01 19:34:41 +0000",
    "user" : {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "protected" : false,
      "id_str" : "2285980750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486310212891340800\/3EUl8sBZ_normal.jpeg",
      "id" : 2285980750,
      "verified" : false
    }
  },
  "id" : 561971823685165058,
  "created_at" : "2015-02-01 19:38:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capt. Cris Moore",
      "screen_name" : "Pilot0360",
      "indices" : [ 3, 13 ],
      "id_str" : "2610970957",
      "id" : 2610970957
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Pilot0360\/status\/561942885809922048\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/lav2SFRO8J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xsDWjCUAAJpsw.jpg",
      "id_str" : "561942858362408960",
      "id" : 561942858362408960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xsDWjCUAAJpsw.jpg",
      "sizes" : [ {
        "h" : 749,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lav2SFRO8J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561971712301232129",
  "text" : "RT @Pilot0360: Very powerful animals. Yellowstone NP http:\/\/t.co\/lav2SFRO8J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Pilot0360\/status\/561942885809922048\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/lav2SFRO8J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xsDWjCUAAJpsw.jpg",
        "id_str" : "561942858362408960",
        "id" : 561942858362408960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xsDWjCUAAJpsw.jpg",
        "sizes" : [ {
          "h" : 749,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lav2SFRO8J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561942885809922048",
    "text" : "Very powerful animals. Yellowstone NP http:\/\/t.co\/lav2SFRO8J",
    "id" : 561942885809922048,
    "created_at" : "2015-02-01 17:43:19 +0000",
    "user" : {
      "name" : "Capt. Cris Moore",
      "screen_name" : "Pilot0360",
      "protected" : false,
      "id_str" : "2610970957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556697940928901122\/EuJjryvX_normal.jpeg",
      "id" : 2610970957,
      "verified" : false
    }
  },
  "id" : 561971712301232129,
  "created_at" : "2015-02-01 19:37:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weed Porn",
      "screen_name" : "BudPictures",
      "indices" : [ 3, 15 ],
      "id_str" : "329737792",
      "id" : 329737792
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BudPictures\/status\/439126605131419649\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/l9t1Wsflbt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhgXUgTIgAEAPAd.png",
      "id_str" : "439126604703629313",
      "id" : 439126604703629313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhgXUgTIgAEAPAd.png",
      "sizes" : [ {
        "h" : 692,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/l9t1Wsflbt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561966338923831296",
  "text" : "RT @BudPictures: Truth http:\/\/t.co\/l9t1Wsflbt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BudPictures\/status\/439126605131419649\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/l9t1Wsflbt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhgXUgTIgAEAPAd.png",
        "id_str" : "439126604703629313",
        "id" : 439126604703629313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhgXUgTIgAEAPAd.png",
        "sizes" : [ {
          "h" : 692,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/l9t1Wsflbt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439126605131419649",
    "text" : "Truth http:\/\/t.co\/l9t1Wsflbt",
    "id" : 439126605131419649,
    "created_at" : "2014-02-27 19:55:15 +0000",
    "user" : {
      "name" : "Weed Porn",
      "screen_name" : "BudPictures",
      "protected" : false,
      "id_str" : "329737792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685484812614922242\/WiDKlERi_normal.jpg",
      "id" : 329737792,
      "verified" : false
    }
  },
  "id" : 561966338923831296,
  "created_at" : "2015-02-01 19:16:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weed Porn",
      "screen_name" : "BudPictures",
      "indices" : [ 3, 15 ],
      "id_str" : "329737792",
      "id" : 329737792
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BudPictures\/status\/436222607793598465\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/32BZC8XTrh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg3GJoKIEAAZR_0.jpg",
      "id_str" : "436222607625818112",
      "id" : 436222607625818112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg3GJoKIEAAZR_0.jpg",
      "sizes" : [ {
        "h" : 221,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 125,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/32BZC8XTrh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561965840791519232",
  "text" : "RT @BudPictures: http:\/\/t.co\/32BZC8XTrh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BudPictures\/status\/436222607793598465\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/32BZC8XTrh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg3GJoKIEAAZR_0.jpg",
        "id_str" : "436222607625818112",
        "id" : 436222607625818112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg3GJoKIEAAZR_0.jpg",
        "sizes" : [ {
          "h" : 221,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 125,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/32BZC8XTrh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436222607793598465",
    "text" : "http:\/\/t.co\/32BZC8XTrh",
    "id" : 436222607793598465,
    "created_at" : "2014-02-19 19:35:48 +0000",
    "user" : {
      "name" : "Weed Porn",
      "screen_name" : "BudPictures",
      "protected" : false,
      "id_str" : "329737792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685484812614922242\/WiDKlERi_normal.jpg",
      "id" : 329737792,
      "verified" : false
    }
  },
  "id" : 561965840791519232,
  "created_at" : "2015-02-01 19:14:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "animalsinlove",
      "indices" : [ 19, 33 ]
    }, {
      "text" : "SwanWatch",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561965344517263361",
  "text" : "RT @Swanwhisperer: #animalsinlove Flash (18yrs) Whisper (15yrs)  Knightly(3yrs) Barbarossa (4yrs) they Trust and Fall In Love #SwanWatch ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/561962200492175360\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BZAiT1a7e4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x9pIRCMAEn7iZ.jpg",
        "id_str" : "561962199061508097",
        "id" : 561962199061508097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x9pIRCMAEn7iZ.jpg",
        "sizes" : [ {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 945
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 945
        } ],
        "display_url" : "pic.twitter.com\/BZAiT1a7e4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/561962200492175360\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BZAiT1a7e4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x9ny_CYAAYyju.jpg",
        "id_str" : "561962176169009152",
        "id" : 561962176169009152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x9ny_CYAAYyju.jpg",
        "sizes" : [ {
          "h" : 316,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 669
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 669
        } ],
        "display_url" : "pic.twitter.com\/BZAiT1a7e4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/561962200492175360\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BZAiT1a7e4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8x9mtlCMAAn8Fz.jpg",
        "id_str" : "561962157537898496",
        "id" : 561962157537898496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8x9mtlCMAAn8Fz.jpg",
        "sizes" : [ {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 936
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 936
        } ],
        "display_url" : "pic.twitter.com\/BZAiT1a7e4"
      } ],
      "hashtags" : [ {
        "text" : "animalsinlove",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "SwanWatch",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561962200492175360",
    "text" : "#animalsinlove Flash (18yrs) Whisper (15yrs)  Knightly(3yrs) Barbarossa (4yrs) they Trust and Fall In Love #SwanWatch http:\/\/t.co\/BZAiT1a7e4",
    "id" : 561962200492175360,
    "created_at" : "2015-02-01 19:00:04 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 561965344517263361,
  "created_at" : "2015-02-01 19:12:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Evans",
      "screen_name" : "willpenrievans",
      "indices" : [ 3, 18 ],
      "id_str" : "208699437",
      "id" : 208699437
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/willpenrievans\/status\/561941098307026944\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/2CmrhXnohr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xqZMyIIAEsajK.jpg",
      "id_str" : "561941034675216385",
      "id" : 561941034675216385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xqZMyIIAEsajK.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2CmrhXnohr"
    } ],
    "hashtags" : [ {
      "text" : "Farm365",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561964934473736194",
  "text" : "RT @willpenrievans: We also have a few woolly lodgers here over the Winter.. #Farm365 http:\/\/t.co\/2CmrhXnohr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/willpenrievans\/status\/561941098307026944\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/2CmrhXnohr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xqZMyIIAEsajK.jpg",
        "id_str" : "561941034675216385",
        "id" : 561941034675216385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xqZMyIIAEsajK.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2CmrhXnohr"
      } ],
      "hashtags" : [ {
        "text" : "Farm365",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561941098307026944",
    "text" : "We also have a few woolly lodgers here over the Winter.. #Farm365 http:\/\/t.co\/2CmrhXnohr",
    "id" : 561941098307026944,
    "created_at" : "2015-02-01 17:36:12 +0000",
    "user" : {
      "name" : "Will Evans",
      "screen_name" : "willpenrievans",
      "protected" : false,
      "id_str" : "208699437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799870294076887040\/jpz5FHGA_normal.jpg",
      "id" : 208699437,
      "verified" : false
    }
  },
  "id" : 561964934473736194,
  "created_at" : "2015-02-01 19:10:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodney Lipscomb",
      "screen_name" : "LeedsDonkeys",
      "indices" : [ 3, 16 ],
      "id_str" : "4663334055",
      "id" : 4663334055
    }, {
      "name" : "Adopt a Donkey",
      "screen_name" : "AdoptADonkey",
      "indices" : [ 18, 31 ],
      "id_str" : "1527563096",
      "id" : 1527563096
    }, {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 104, 120 ],
      "id_str" : "95607516",
      "id" : 95607516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Leeds",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561941961733853184",
  "text" : "RT @LeedsDonkeys: @AdoptADonkey Ripple, you're such a softie! Hands up, who would like a donkey cuddle? @DonkeySanctuary #Leeds http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adopt a Donkey",
        "screen_name" : "AdoptADonkey",
        "indices" : [ 0, 13 ],
        "id_str" : "1527563096",
        "id" : 1527563096
      }, {
        "name" : "The Donkey Sanctuary",
        "screen_name" : "DonkeySanctuary",
        "indices" : [ 86, 102 ],
        "id_str" : "95607516",
        "id" : 95607516
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LeedsDonkeys\/status\/561934098999279616\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/260SMbLTQk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xkFCtCIAA9QdE.jpg",
        "id_str" : "561934091302346752",
        "id" : 561934091302346752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xkFCtCIAA9QdE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/260SMbLTQk"
      } ],
      "hashtags" : [ {
        "text" : "Leeds",
        "indices" : [ 103, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561934098999279616",
    "in_reply_to_user_id" : 1527563096,
    "text" : "@AdoptADonkey Ripple, you're such a softie! Hands up, who would like a donkey cuddle? @DonkeySanctuary #Leeds http:\/\/t.co\/260SMbLTQk",
    "id" : 561934098999279616,
    "created_at" : "2015-02-01 17:08:24 +0000",
    "in_reply_to_screen_name" : "AdoptADonkey",
    "in_reply_to_user_id_str" : "1527563096",
    "user" : {
      "name" : "Donkey Community",
      "screen_name" : "TDS_North",
      "protected" : false,
      "id_str" : "284555205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658975178752458753\/v0WgsBYi_normal.png",
      "id" : 284555205,
      "verified" : false
    }
  },
  "id" : 561941961733853184,
  "created_at" : "2015-02-01 17:39:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dave melia",
      "screen_name" : "dpmelia63",
      "indices" : [ 3, 13 ],
      "id_str" : "244237363",
      "id" : 244237363
    }, {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "indices" : [ 15, 26 ],
      "id_str" : "2700353103",
      "id" : 2700353103
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dpmelia63\/status\/561882924161978368\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ffrvdySMN5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8w1iDRCcAAR0u-.jpg",
      "id_str" : "561882912623063040",
      "id" : 561882912623063040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8w1iDRCcAAR0u-.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ffrvdySMN5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561941680119906304",
  "text" : "RT @dpmelia63: @jabinks846 Sefton park , Canadian show of http:\/\/t.co\/ffrvdySMN5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Binksy \/ Jackie",
        "screen_name" : "jabinks846",
        "indices" : [ 0, 11 ],
        "id_str" : "2700353103",
        "id" : 2700353103
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dpmelia63\/status\/561882924161978368\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/ffrvdySMN5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8w1iDRCcAAR0u-.jpg",
        "id_str" : "561882912623063040",
        "id" : 561882912623063040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8w1iDRCcAAR0u-.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ffrvdySMN5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.3895331, -2.8432984 ]
    },
    "id_str" : "561882924161978368",
    "in_reply_to_user_id" : 2700353103,
    "text" : "@jabinks846 Sefton park , Canadian show of http:\/\/t.co\/ffrvdySMN5",
    "id" : 561882924161978368,
    "created_at" : "2015-02-01 13:45:03 +0000",
    "in_reply_to_screen_name" : "jabinks846",
    "in_reply_to_user_id_str" : "2700353103",
    "user" : {
      "name" : "dave melia",
      "screen_name" : "dpmelia63",
      "protected" : false,
      "id_str" : "244237363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767094668123340801\/VWZyQ6MA_normal.jpg",
      "id" : 244237363,
      "verified" : false
    }
  },
  "id" : 561941680119906304,
  "created_at" : "2015-02-01 17:38:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/561915062475325442\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/w3nZlMSf1x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xSxYSCQAAVkQp.jpg",
      "id_str" : "561915061799632896",
      "id" : 561915061799632896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xSxYSCQAAVkQp.jpg",
      "sizes" : [ {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1089
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w3nZlMSf1x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561925535199408128",
  "text" : "RT @ChippyCMunk: Little Chickadee busy working on a seed http:\/\/t.co\/w3nZlMSf1x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/561915062475325442\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/w3nZlMSf1x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xSxYSCQAAVkQp.jpg",
        "id_str" : "561915061799632896",
        "id" : 561915061799632896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xSxYSCQAAVkQp.jpg",
        "sizes" : [ {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 1089
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/w3nZlMSf1x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561915062475325442",
    "text" : "Little Chickadee busy working on a seed http:\/\/t.co\/w3nZlMSf1x",
    "id" : 561915062475325442,
    "created_at" : "2015-02-01 15:52:45 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 561925535199408128,
  "created_at" : "2015-02-01 16:34:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sincerely Tumblr",
      "screen_name" : "SincerelyTumblr",
      "indices" : [ 3, 19 ],
      "id_str" : "226690054",
      "id" : 226690054
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SincerelyTumblr\/status\/561902351997739008\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/FXWMCP0MrR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xHNkAIUAAf_00.jpg",
      "id_str" : "561902351842562048",
      "id" : 561902351842562048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xHNkAIUAAf_00.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FXWMCP0MrR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561915220604780544",
  "text" : "RT @SincerelyTumblr: Panoramic picture taken while rolling down a hill \uD83D\uDE0D \uD83D\uDE33 http:\/\/t.co\/FXWMCP0MrR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SincerelyTumblr\/status\/561902351997739008\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/FXWMCP0MrR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8xHNkAIUAAf_00.jpg",
        "id_str" : "561902351842562048",
        "id" : 561902351842562048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8xHNkAIUAAf_00.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FXWMCP0MrR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561902351997739008",
    "text" : "Panoramic picture taken while rolling down a hill \uD83D\uDE0D \uD83D\uDE33 http:\/\/t.co\/FXWMCP0MrR",
    "id" : 561902351997739008,
    "created_at" : "2015-02-01 15:02:15 +0000",
    "user" : {
      "name" : "Sincerely Tumblr",
      "screen_name" : "SincerelyTumblr",
      "protected" : false,
      "id_str" : "226690054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726467869031030784\/fR83Tu2w_normal.jpg",
      "id" : 226690054,
      "verified" : false
    }
  },
  "id" : 561915220604780544,
  "created_at" : "2015-02-01 15:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail",
      "screen_name" : "BirdAndGarden",
      "indices" : [ 3, 17 ],
      "id_str" : "465570280",
      "id" : 465570280
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BirdAndGarden\/status\/561508813363478528\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/PhDoqJMXdI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8rhSkPIYAA-PaT.jpg",
      "id_str" : "561508812642082816",
      "id" : 561508812642082816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8rhSkPIYAA-PaT.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/PhDoqJMXdI"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "birding",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "birders",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "winter",
      "indices" : [ 97, 104 ]
    }, {
      "text" : "nature",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561912654621843458",
  "text" : "RT @BirdAndGarden: Close up view of a tufted titmouse in window feeder. #birds #birding #birders #winter #nature http:\/\/t.co\/PhDoqJMXdI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdAndGarden\/status\/561508813363478528\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/PhDoqJMXdI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8rhSkPIYAA-PaT.jpg",
        "id_str" : "561508812642082816",
        "id" : 561508812642082816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8rhSkPIYAA-PaT.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/PhDoqJMXdI"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "birding",
        "indices" : [ 60, 68 ]
      }, {
        "text" : "birders",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "winter",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "nature",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "561508813363478528",
    "text" : "Close up view of a tufted titmouse in window feeder. #birds #birding #birders #winter #nature http:\/\/t.co\/PhDoqJMXdI",
    "id" : 561508813363478528,
    "created_at" : "2015-01-31 12:58:28 +0000",
    "user" : {
      "name" : "Gail",
      "screen_name" : "BirdAndGarden",
      "protected" : false,
      "id_str" : "465570280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634801624624398339\/s-72Q7qt_normal.jpg",
      "id" : 465570280,
      "verified" : false
    }
  },
  "id" : 561912654621843458,
  "created_at" : "2015-02-01 15:43:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]