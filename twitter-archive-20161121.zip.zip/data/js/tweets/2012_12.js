Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285771095360028673",
  "text" : "@ThePlushGourmet &lt;3 ..beautiful babies!!",
  "id" : 285771095360028673,
  "created_at" : "2012-12-31 15:35:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/h9cNbHBr",
      "expanded_url" : "http:\/\/fb.me\/2hZdXLxW1",
      "display_url" : "fb.me\/2hZdXLxW1"
    } ]
  },
  "geo" : { },
  "id_str" : "285748214622191616",
  "text" : "RT @introvertmeetup: If I am an introvert will society not accept me? http:\/\/t.co\/h9cNbHBr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/h9cNbHBr",
        "expanded_url" : "http:\/\/fb.me\/2hZdXLxW1",
        "display_url" : "fb.me\/2hZdXLxW1"
      } ]
    },
    "geo" : { },
    "id_str" : "285744135418302464",
    "text" : "If I am an introvert will society not accept me? http:\/\/t.co\/h9cNbHBr",
    "id" : 285744135418302464,
    "created_at" : "2012-12-31 13:48:05 +0000",
    "user" : {
      "name" : "Social Introverts",
      "screen_name" : "proudintroverts",
      "protected" : false,
      "id_str" : "741558997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625876596486877184\/WZGimc1S_normal.png",
      "id" : 741558997,
      "verified" : false
    }
  },
  "id" : 285748214622191616,
  "created_at" : "2012-12-31 14:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muscovy",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "seattle",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "wedgwood",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/gnWpOtOi",
      "expanded_url" : "http:\/\/ducksandclucks.com\/blog\/2012\/12\/30\/duck-needs-safe-home\/",
      "display_url" : "ducksandclucks.com\/blog\/2012\/12\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285551747135582209",
  "text" : "RT @ducksandclucks: PLEASE RT SEATTLE: Meadowbook Pond duck needs safe forever home. http:\/\/t.co\/gnWpOtOi #muscovy #seattle #wedgwood #m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "muscovy",
        "indices" : [ 86, 94 ]
      }, {
        "text" : "seattle",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "wedgwood",
        "indices" : [ 104, 113 ]
      }, {
        "text" : "meadowbrook",
        "indices" : [ 114, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/gnWpOtOi",
        "expanded_url" : "http:\/\/ducksandclucks.com\/blog\/2012\/12\/30\/duck-needs-safe-home\/",
        "display_url" : "ducksandclucks.com\/blog\/2012\/12\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285550848740818944",
    "text" : "PLEASE RT SEATTLE: Meadowbook Pond duck needs safe forever home. http:\/\/t.co\/gnWpOtOi #muscovy #seattle #wedgwood #meadowbrook",
    "id" : 285550848740818944,
    "created_at" : "2012-12-31 01:00:02 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 285551747135582209,
  "created_at" : "2012-12-31 01:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285549801888698368",
  "text" : "RT @Master_Synaps: Whether you like it or not, we are a collective. #compassion is needed to make it work efficiently and humanely",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compassion",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285110616526565377",
    "text" : "Whether you like it or not, we are a collective. #compassion is needed to make it work efficiently and humanely",
    "id" : 285110616526565377,
    "created_at" : "2012-12-29 19:50:42 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 285549801888698368,
  "created_at" : "2012-12-31 00:55:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285546048636731392",
  "geo" : { },
  "id_str" : "285549428943757314",
  "in_reply_to_user_id" : 241662602,
  "text" : "RT @Master_Synaps If I was required to define god, it would be The Sum Total of all Things. Proof? All things exist.",
  "id" : 285549428943757314,
  "in_reply_to_status_id" : 285546048636731392,
  "created_at" : "2012-12-31 00:54:23 +0000",
  "in_reply_to_screen_name" : "Master_Synaps",
  "in_reply_to_user_id_str" : "241662602",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285549202816266242",
  "text" : "RT @Master_Synaps: When we assume an attitude of #compassion we create a positive feedback loop.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compassion",
        "indices" : [ 30, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285541965792165889",
    "text" : "When we assume an attitude of #compassion we create a positive feedback loop.",
    "id" : 285541965792165889,
    "created_at" : "2012-12-31 00:24:44 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 285549202816266242,
  "created_at" : "2012-12-31 00:53:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u044E\u0448\u0430 \u0410\u043D\u0433\u0435\u043B",
      "screen_name" : "Tomthunkit",
      "indices" : [ 3, 14 ],
      "id_str" : "2371889310",
      "id" : 2371889310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285548470557896704",
  "text" : "RT @Tomthunkit: NRA uses the 2nd Amd. to arm criminals thru gun shows, online sales. Then uses armed criminals to scare people to buy mo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285534729258803200",
    "text" : "NRA uses the 2nd Amd. to arm criminals thru gun shows, online sales. Then uses armed criminals to scare people to buy more guns.",
    "id" : 285534729258803200,
    "created_at" : "2012-12-30 23:55:59 +0000",
    "user" : {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "protected" : false,
      "id_str" : "289118612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720292487898783746\/B736BdgO_normal.jpg",
      "id" : 289118612,
      "verified" : false
    }
  },
  "id" : 285548470557896704,
  "created_at" : "2012-12-31 00:50:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "indices" : [ 3, 13 ],
      "id_str" : "18812572",
      "id" : 18812572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285548182455328768",
  "text" : "RT @60Minutes: The next generation of robotic limbs is being developed to help the 1,300+ U.S. veteran who have lost limbs in the last d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "60Minutes",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285545024769372160",
    "text" : "The next generation of robotic limbs is being developed to help the 1,300+ U.S. veteran who have lost limbs in the last decade #60Minutes",
    "id" : 285545024769372160,
    "created_at" : "2012-12-31 00:36:53 +0000",
    "user" : {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "protected" : false,
      "id_str" : "18812572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463397772071165953\/n_-jHyIO_normal.jpeg",
      "id" : 18812572,
      "verified" : true
    }
  },
  "id" : 285548182455328768,
  "created_at" : "2012-12-31 00:49:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "NRA",
      "screen_name" : "NRA",
      "indices" : [ 27, 31 ],
      "id_str" : "21829541",
      "id" : 21829541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285548145478365184",
  "text" : "RT @PisseArtiste: Why does @nra merit tax exemption? It's not a charity, it's an industry marketing and lobbying group. It should be pay ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NRA",
        "screen_name" : "NRA",
        "indices" : [ 9, 13 ],
        "id_str" : "21829541",
        "id" : 21829541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285547024055685121",
    "text" : "Why does @nra merit tax exemption? It's not a charity, it's an industry marketing and lobbying group. It should be paying tax.",
    "id" : 285547024055685121,
    "created_at" : "2012-12-31 00:44:50 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 285548145478365184,
  "created_at" : "2012-12-31 00:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/6iXZHYGf",
      "expanded_url" : "http:\/\/TwitPic.com",
      "display_url" : "TwitPic.com"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/LQDEJlbR",
      "expanded_url" : "http:\/\/tnw.co\/VQgJA4",
      "display_url" : "tnw.co\/VQgJA4"
    } ]
  },
  "geo" : { },
  "id_str" : "285538096412520448",
  "text" : "RT @Floridaline: Google\u2019s malware checker on Sunday has for some reason detected http:\/\/t.co\/6iXZHYGf as a threat. http:\/\/t.co\/LQDEJlbR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/6iXZHYGf",
        "expanded_url" : "http:\/\/TwitPic.com",
        "display_url" : "TwitPic.com"
      }, {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/LQDEJlbR",
        "expanded_url" : "http:\/\/tnw.co\/VQgJA4",
        "display_url" : "tnw.co\/VQgJA4"
      } ]
    },
    "geo" : { },
    "id_str" : "285518506458505216",
    "text" : "Google\u2019s malware checker on Sunday has for some reason detected http:\/\/t.co\/6iXZHYGf as a threat. http:\/\/t.co\/LQDEJlbR",
    "id" : 285518506458505216,
    "created_at" : "2012-12-30 22:51:31 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 285538096412520448,
  "created_at" : "2012-12-31 00:09:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Affirmations",
      "screen_name" : "Life_Affirming",
      "indices" : [ 3, 18 ],
      "id_str" : "361007600",
      "id" : 361007600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285537735001899008",
  "text" : "RT @Life_Affirming: I attract positive people &amp; events into my life NOW. I choose to see beauty &amp; joy everywhere I look. #affirm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "affirmation",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285536172736913408",
    "text" : "I attract positive people &amp; events into my life NOW. I choose to see beauty &amp; joy everywhere I look. #affirmation",
    "id" : 285536172736913408,
    "created_at" : "2012-12-31 00:01:43 +0000",
    "user" : {
      "name" : "Daily Affirmations",
      "screen_name" : "Life_Affirming",
      "protected" : false,
      "id_str" : "361007600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1900308534\/PositiveAffirmation_normal.jpg",
      "id" : 361007600,
      "verified" : false
    }
  },
  "id" : 285537735001899008,
  "created_at" : "2012-12-31 00:07:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285509270202634242",
  "geo" : { },
  "id_str" : "285510124871757825",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny : )",
  "id" : 285510124871757825,
  "in_reply_to_status_id" : 285509270202634242,
  "created_at" : "2012-12-30 22:18:12 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arroia",
      "screen_name" : "Arroia",
      "indices" : [ 3, 10 ],
      "id_str" : "343940865",
      "id" : 343940865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285435861833764865",
  "text" : "RT @Arroia: Telling kids that babies are made when a vagina suffocates a penis until it starts vomiting, greatly reduces chances of teen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236447760314945537",
    "text" : "Telling kids that babies are made when a vagina suffocates a penis until it starts vomiting, greatly reduces chances of teenage pregnancies.",
    "id" : 236447760314945537,
    "created_at" : "2012-08-17 13:01:53 +0000",
    "user" : {
      "name" : "Arroia",
      "screen_name" : "Arroia",
      "protected" : false,
      "id_str" : "343940865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435498909448691712\/gMnmxHVU_normal.jpeg",
      "id" : 343940865,
      "verified" : false
    }
  },
  "id" : 285435861833764865,
  "created_at" : "2012-12-30 17:23:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jamie",
      "screen_name" : "gnuman1979",
      "indices" : [ 3, 14 ],
      "id_str" : "257715213",
      "id" : 257715213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/ICi7trhX",
      "expanded_url" : "http:\/\/egbertowillies.com\/2012\/12\/29\/government-healthcare-delivery-more-efficient-than-private-sector\/",
      "display_url" : "egbertowillies.com\/2012\/12\/29\/gov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285435509046648832",
  "text" : "RT @gnuman1979: Government Healthcare Delivery More Efficient Than Private Sector http:\/\/t.co\/ICi7trhX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/ICi7trhX",
        "expanded_url" : "http:\/\/egbertowillies.com\/2012\/12\/29\/government-healthcare-delivery-more-efficient-than-private-sector\/",
        "display_url" : "egbertowillies.com\/2012\/12\/29\/gov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285431790825512961",
    "text" : "Government Healthcare Delivery More Efficient Than Private Sector http:\/\/t.co\/ICi7trhX",
    "id" : 285431790825512961,
    "created_at" : "2012-12-30 17:06:56 +0000",
    "user" : {
      "name" : "jamie",
      "screen_name" : "gnuman1979",
      "protected" : false,
      "id_str" : "257715213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780073557132914693\/JpcA0EwC_normal.jpg",
      "id" : 257715213,
      "verified" : false
    }
  },
  "id" : 285435509046648832,
  "created_at" : "2012-12-30 17:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "nature",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "photo",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/f6rEiVLe",
      "expanded_url" : "http:\/\/ow.ly\/gmfdy",
      "display_url" : "ow.ly\/gmfdy"
    } ]
  },
  "geo" : { },
  "id_str" : "285426596100333568",
  "text" : "RT @KerriFar: Downy in the Pines ~ http:\/\/t.co\/f6rEiVLe  ~ #birds #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "nature",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "photo",
        "indices" : [ 60, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/f6rEiVLe",
        "expanded_url" : "http:\/\/ow.ly\/gmfdy",
        "display_url" : "ow.ly\/gmfdy"
      } ]
    },
    "geo" : { },
    "id_str" : "285426332677070848",
    "text" : "Downy in the Pines ~ http:\/\/t.co\/f6rEiVLe  ~ #birds #nature #photo",
    "id" : 285426332677070848,
    "created_at" : "2012-12-30 16:45:15 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 285426596100333568,
  "created_at" : "2012-12-30 16:46:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285416850249109504",
  "geo" : { },
  "id_str" : "285423489131888640",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields i got michael wallace righteous series ebooks.. didnt get audio, tho.  but they were each 1.99 audio. good price!",
  "id" : 285423489131888640,
  "in_reply_to_status_id" : 285416850249109504,
  "created_at" : "2012-12-30 16:33:57 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285422817518944256",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX hey kindle lady..lol. is new fire diff than fire 1 (i have.) looking at fire 2 and fire 2 hd (7in) .. worth upgrade? faster?",
  "id" : 285422817518944256,
  "created_at" : "2012-12-30 16:31:17 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 12, 25 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285400069161766914",
  "text" : "interesting @adamrshields bought some kindle books and notice they offer big discount to get audible version (1.99)",
  "id" : 285400069161766914,
  "created_at" : "2012-12-30 15:00:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 80, 93 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/KHfRQETo",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B005J61E96\/ref=cm_sw_r_tw_ask_MI3sE.1B4R3VK",
      "display_url" : "amazon.com\/dp\/B005J61E96\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285398368837070848",
  "text" : "I just bought: 'Mighty and Strong (Righteous Series #2)' by Michael Wallace via @amazonkindle http:\/\/t.co\/KHfRQETo",
  "id" : 285398368837070848,
  "created_at" : "2012-12-30 14:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285395969745489920",
  "text" : "RT @bookwiseblog: Kindle Daily Deal-50 Kindle Mysteries and Thrillers for $1.99 or less: Today only, 50 acclaimed mysteries and th... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/kSkFule3",
        "expanded_url" : "http:\/\/bit.ly\/VP0ovi",
        "display_url" : "bit.ly\/VP0ovi"
      } ]
    },
    "geo" : { },
    "id_str" : "285389768114712576",
    "text" : "Kindle Daily Deal-50 Kindle Mysteries and Thrillers for $1.99 or less: Today only, 50 acclaimed mysteries and th... http:\/\/t.co\/kSkFule3",
    "id" : 285389768114712576,
    "created_at" : "2012-12-30 14:19:57 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 285395969745489920,
  "created_at" : "2012-12-30 14:44:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/zXqRWA7l",
      "expanded_url" : "http:\/\/amzn.to\/YxBy5r",
      "display_url" : "amzn.to\/YxBy5r"
    } ]
  },
  "geo" : { },
  "id_str" : "285209096314036224",
  "text" : "finished See You at the End of Time by Katharine Osborne http:\/\/t.co\/zXqRWA7l",
  "id" : 285209096314036224,
  "created_at" : "2012-12-30 02:22:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 0, 12 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 44, 57 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285168280610668546",
  "geo" : { },
  "id_str" : "285171850521243648",
  "in_reply_to_user_id" : 45674330,
  "text" : "@oceanshaman yay! a new kindle convert..lol @AmazonKindle",
  "id" : 285171850521243648,
  "in_reply_to_status_id" : 285168280610668546,
  "created_at" : "2012-12-29 23:54:02 +0000",
  "in_reply_to_screen_name" : "oceanshaman",
  "in_reply_to_user_id_str" : "45674330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inspired Kathy",
      "screen_name" : "toobusyreading",
      "indices" : [ 3, 18 ],
      "id_str" : "163219408",
      "id" : 163219408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285156790277140481",
  "text" : "RT @toobusyreading: 2012 End of the Year Book Survey: Hosted by The Perpetual Page-Turner\nBest In Books 2012\n\n1. Best Book You Rea...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/D0Ipyn3n",
        "expanded_url" : "http:\/\/bit.ly\/YYAxbF",
        "display_url" : "bit.ly\/YYAxbF"
      } ]
    },
    "geo" : { },
    "id_str" : "285152328733048832",
    "text" : "2012 End of the Year Book Survey: Hosted by The Perpetual Page-Turner\nBest In Books 2012\n\n1. Best Book You Rea... http:\/\/t.co\/D0Ipyn3n",
    "id" : 285152328733048832,
    "created_at" : "2012-12-29 22:36:27 +0000",
    "user" : {
      "name" : "Inspired Kathy",
      "screen_name" : "toobusyreading",
      "protected" : false,
      "id_str" : "163219408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179328670\/profile_normal.jpg",
      "id" : 163219408,
      "verified" : false
    }
  },
  "id" : 285156790277140481,
  "created_at" : "2012-12-29 22:54:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 34, 46 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CBLDF",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/5nqB8H3E",
      "expanded_url" : "http:\/\/j.mp\/VM7T6a",
      "display_url" : "j.mp\/VM7T6a"
    } ]
  },
  "geo" : { },
  "id_str" : "285138396903534593",
  "text" : "RT @Matth3ous: This is insane. RT @neilhimself: Student Arrested for Doodling In His Notebook: http:\/\/t.co\/5nqB8H3E #CBLDF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Gaiman",
        "screen_name" : "neilhimself",
        "indices" : [ 19, 31 ],
        "id_str" : "18393773",
        "id" : 18393773
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CBLDF",
        "indices" : [ 101, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/5nqB8H3E",
        "expanded_url" : "http:\/\/j.mp\/VM7T6a",
        "display_url" : "j.mp\/VM7T6a"
      } ]
    },
    "geo" : { },
    "id_str" : "285134939819745280",
    "text" : "This is insane. RT @neilhimself: Student Arrested for Doodling In His Notebook: http:\/\/t.co\/5nqB8H3E #CBLDF",
    "id" : 285134939819745280,
    "created_at" : "2012-12-29 21:27:21 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 285138396903534593,
  "created_at" : "2012-12-29 21:41:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/GfRDBqg1",
      "expanded_url" : "http:\/\/www.knowords.com",
      "display_url" : "knowords.com"
    } ]
  },
  "geo" : { },
  "id_str" : "285116892874674176",
  "text" : "RT @Wylieknowords: \"Twitter--Messages In Bottles Thrown Into the Social Sea With Hope.\" N. Wylie Jones http:\/\/t.co\/GfRDBqg1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/GfRDBqg1",
        "expanded_url" : "http:\/\/www.knowords.com",
        "display_url" : "knowords.com"
      } ]
    },
    "geo" : { },
    "id_str" : "285112140384313344",
    "text" : "\"Twitter--Messages In Bottles Thrown Into the Social Sea With Hope.\" N. Wylie Jones http:\/\/t.co\/GfRDBqg1",
    "id" : 285112140384313344,
    "created_at" : "2012-12-29 19:56:46 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 285116892874674176,
  "created_at" : "2012-12-29 20:15:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285114870033166336",
  "text" : "RT @petersonguides: You can also get county lists of birds \u2014 with Peterson illustrations \u2014 from the Peterson Guides Bird Finder... http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/EoGQD1sQ",
        "expanded_url" : "http:\/\/fb.me\/27evCn9cR",
        "display_url" : "fb.me\/27evCn9cR"
      } ]
    },
    "geo" : { },
    "id_str" : "285111626435276802",
    "text" : "You can also get county lists of birds \u2014 with Peterson illustrations \u2014 from the Peterson Guides Bird Finder... http:\/\/t.co\/EoGQD1sQ",
    "id" : 285111626435276802,
    "created_at" : "2012-12-29 19:54:43 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 285114870033166336,
  "created_at" : "2012-12-29 20:07:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/zDYNXGdg",
      "expanded_url" : "http:\/\/via.me\/-8a4sizs",
      "display_url" : "via.me\/-8a4sizs"
    } ]
  },
  "geo" : { },
  "id_str" : "285111040948178945",
  "text" : "It's snowing! (Front yard and road below) http:\/\/t.co\/zDYNXGdg",
  "id" : 285111040948178945,
  "created_at" : "2012-12-29 19:52:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/qwHlXPiN",
      "expanded_url" : "http:\/\/via.me\/-8a4r4wy",
      "display_url" : "via.me\/-8a4r4wy"
    } ]
  },
  "geo" : { },
  "id_str" : "285110483785232384",
  "text" : "This mug always made me giggle!!! http:\/\/t.co\/qwHlXPiN",
  "id" : 285110483785232384,
  "created_at" : "2012-12-29 19:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/Iv2avKil",
      "expanded_url" : "http:\/\/via.me\/-8a4pq9e",
      "display_url" : "via.me\/-8a4pq9e"
    } ]
  },
  "geo" : { },
  "id_str" : "285109900873461760",
  "text" : "Casualty of my shortness. Mug I got for hubby years ago. http:\/\/t.co\/Iv2avKil",
  "id" : 285109900873461760,
  "created_at" : "2012-12-29 19:47:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285107931781951489",
  "geo" : { },
  "id_str" : "285108657232961536",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 ahh.. ive always been moody. effexor evened it out so i noticed the extra moodiness this year.",
  "id" : 285108657232961536,
  "in_reply_to_status_id" : 285107931781951489,
  "created_at" : "2012-12-29 19:42:55 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corvid",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/bHudwiEz",
      "expanded_url" : "http:\/\/instagr.am\/p\/T1PpO6hH9M\/",
      "display_url" : "instagr.am\/p\/T1PpO6hH9M\/"
    } ]
  },
  "geo" : { },
  "id_str" : "285107360433836032",
  "text" : "RT @ducksandclucks: \"Fanks fer da treafs.\" \nDon't talk with your mouth full, crow. And you're welcome.\n#corvid http:\/\/t.co\/bHudwiEz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corvid",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/bHudwiEz",
        "expanded_url" : "http:\/\/instagr.am\/p\/T1PpO6hH9M\/",
        "display_url" : "instagr.am\/p\/T1PpO6hH9M\/"
      } ]
    },
    "geo" : { },
    "id_str" : "285103101625651200",
    "text" : "\"Fanks fer da treafs.\" \nDon't talk with your mouth full, crow. And you're welcome.\n#corvid http:\/\/t.co\/bHudwiEz",
    "id" : 285103101625651200,
    "created_at" : "2012-12-29 19:20:51 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 285107360433836032,
  "created_at" : "2012-12-29 19:37:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285107280469434369",
  "text" : "RT @neiltyson: FYI: Earth is larger &amp; more reflective than the Moon, so full Earth on the Moon is about 40x brighter than full Moon  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284876650305429505",
    "text" : "FYI: Earth is larger &amp; more reflective than the Moon, so full Earth on the Moon is about 40x brighter than full Moon on Earth",
    "id" : 284876650305429505,
    "created_at" : "2012-12-29 04:21:00 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 285107280469434369,
  "created_at" : "2012-12-29 19:37:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "menopause",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285102686431502336",
  "geo" : { },
  "id_str" : "285106865677946881",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 this past year i have found my emotions really all over the place.. and the weird weepiness sometimes, too. UGH #menopause",
  "id" : 285106865677946881,
  "in_reply_to_status_id" : 285102686431502336,
  "created_at" : "2012-12-29 19:35:48 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285093218490658817",
  "text" : "@SamsaricWarrior awwww..lol",
  "id" : 285093218490658817,
  "created_at" : "2012-12-29 18:41:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HVMarket",
      "screen_name" : "hvmarket",
      "indices" : [ 54, 63 ],
      "id_str" : "493572992",
      "id" : 493572992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hudsonvalley",
      "indices" : [ 101, 114 ]
    }, {
      "text" : "handcrafted",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/pzrCMsfK",
      "expanded_url" : "http:\/\/po.st\/5rUAcv",
      "display_url" : "po.st\/5rUAcv"
    } ]
  },
  "geo" : { },
  "id_str" : "285078882892275712",
  "text" : "handmade wood pen hubby got for me from Trees2Pens at @hvmarket in Poughkeepsie http:\/\/t.co\/pzrCMsfK #hudsonvalley #handcrafted",
  "id" : 285078882892275712,
  "created_at" : "2012-12-29 17:44:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 41, 53 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/JfZz3DuL",
      "expanded_url" : "http:\/\/tl.gd\/khil3l",
      "display_url" : "tl.gd\/khil3l"
    } ]
  },
  "geo" : { },
  "id_str" : "285058660625956865",
  "text" : "RT @VirgoJohnny: What could go wrong? RT @Floridaline Sheriff Arpaio plans to use armed volunteer \u2018posse\u2019 to (cont) http:\/\/t.co\/JfZz3DuL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FloridaLine",
        "screen_name" : "Floridaline",
        "indices" : [ 24, 36 ],
        "id_str" : "229428507",
        "id" : 229428507
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/JfZz3DuL",
        "expanded_url" : "http:\/\/tl.gd\/khil3l",
        "display_url" : "tl.gd\/khil3l"
      } ]
    },
    "in_reply_to_status_id_str" : "285027528027033600",
    "geo" : { },
    "id_str" : "285057947770429440",
    "in_reply_to_user_id" : 229428507,
    "text" : "What could go wrong? RT @Floridaline Sheriff Arpaio plans to use armed volunteer \u2018posse\u2019 to (cont) http:\/\/t.co\/JfZz3DuL",
    "id" : 285057947770429440,
    "in_reply_to_status_id" : 285027528027033600,
    "created_at" : "2012-12-29 16:21:25 +0000",
    "in_reply_to_screen_name" : "Floridaline",
    "in_reply_to_user_id_str" : "229428507",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 285058660625956865,
  "created_at" : "2012-12-29 16:24:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285053337307590656",
  "geo" : { },
  "id_str" : "285054230648201217",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska YUM!! : )",
  "id" : 285054230648201217,
  "in_reply_to_status_id" : 285053337307590656,
  "created_at" : "2012-12-29 16:06:39 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285051691546591232",
  "text" : "hubby decided to clean coffee machine B4 my 2nd cup.. im not happy here!!",
  "id" : 285051691546591232,
  "created_at" : "2012-12-29 15:56:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285045497100640256",
  "geo" : { },
  "id_str" : "285051223399346176",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos Happy Birthday, Hillary! ((confettifalling))",
  "id" : 285051223399346176,
  "in_reply_to_status_id" : 285045497100640256,
  "created_at" : "2012-12-29 15:54:42 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 7, 19 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285048796281454593",
  "geo" : { },
  "id_str" : "285050822365179904",
  "in_reply_to_user_id" : 71118021,
  "text" : "LOL RT @CaroleODell Resolutions? Can I make some for *other* people? :-P",
  "id" : 285050822365179904,
  "in_reply_to_status_id" : 285048796281454593,
  "created_at" : "2012-12-29 15:53:06 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 50, 62 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Urq4nG8B",
      "expanded_url" : "http:\/\/tl.gd\/kh8dt9",
      "display_url" : "tl.gd\/kh8dt9"
    } ]
  },
  "geo" : { },
  "id_str" : "284819611097133056",
  "text" : "dunno if i should feel good or be horrified.. LOL @VirgoJohnny \"If I followed you back, i think we have enough (cont) http:\/\/t.co\/Urq4nG8B",
  "id" : 284819611097133056,
  "created_at" : "2012-12-29 00:34:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 52, 65 ],
      "id_str" : "84249568",
      "id" : 84249568
    }, {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 74, 87 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/aFN2CedQ",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B0030H7UIU\/ref=cm_sw_r_tw_ask_59VrE.1PXNGXP",
      "display_url" : "amazon.com\/dp\/B0030H7UIU\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284777408404549633",
  "text" : "I just bought: 'Under the Dome' by Stephen King via @amazonkindle because @bookwiseblog told me about sale at $1.99 : ) http:\/\/t.co\/aFN2CedQ",
  "id" : 284777408404549633,
  "created_at" : "2012-12-28 21:46:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Veronica Coffin",
      "screen_name" : "VeronicaCoffin",
      "indices" : [ 77, 92 ],
      "id_str" : "264422645",
      "id" : 264422645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayor",
      "indices" : [ 45, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284772880603037696",
  "geo" : { },
  "id_str" : "284773765420822528",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny thats right, it should. we need #singlepayor like canada or uk! @VeronicaCoffin",
  "id" : 284773765420822528,
  "in_reply_to_status_id" : 284772880603037696,
  "created_at" : "2012-12-28 21:32:11 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    }, {
      "name" : "Fay Hart",
      "screen_name" : "fayhart101",
      "indices" : [ 20, 31 ],
      "id_str" : "16545730",
      "id" : 16545730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284772730950279168",
  "text" : "RT @TheOracle13: RT @fayhart101 Instead of thinking outside of the box, get rid of the box ~ Deepak Chopra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fay Hart",
        "screen_name" : "fayhart101",
        "indices" : [ 3, 14 ],
        "id_str" : "16545730",
        "id" : 16545730
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "284767066173612032",
    "geo" : { },
    "id_str" : "284771971940630528",
    "in_reply_to_user_id" : 16545730,
    "text" : "RT @fayhart101 Instead of thinking outside of the box, get rid of the box ~ Deepak Chopra",
    "id" : 284771971940630528,
    "in_reply_to_status_id" : 284767066173612032,
    "created_at" : "2012-12-28 21:25:03 +0000",
    "in_reply_to_screen_name" : "fayhart101",
    "in_reply_to_user_id_str" : "16545730",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 284772730950279168,
  "created_at" : "2012-12-28 21:28:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/6OdsgYOe",
      "expanded_url" : "http:\/\/healthwarehouse.com",
      "display_url" : "healthwarehouse.com"
    } ]
  },
  "geo" : { },
  "id_str" : "284772563433971713",
  "text" : "i get my effexor from http:\/\/t.co\/6OdsgYOe \/ affordable and wonderful customer service",
  "id" : 284772563433971713,
  "created_at" : "2012-12-28 21:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284769562828865537",
  "geo" : { },
  "id_str" : "284771393940365312",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides we just lost our home town pharmacy a few months ago. their customer list went to nearest cvs.",
  "id" : 284771393940365312,
  "in_reply_to_status_id" : 284769562828865537,
  "created_at" : "2012-12-28 21:22:45 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284768575414218752",
  "text" : "i cannot get effexor in a local pharmacy.. too expensive. i get them online (add processing\/shipping time) ticktockticktock",
  "id" : 284768575414218752,
  "created_at" : "2012-12-28 21:11:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284768221133934592",
  "text" : "all i frickin need is a damn prescription for pills ive been taking for 13 years. i dont need no MF mammo!!!",
  "id" : 284768221133934592,
  "created_at" : "2012-12-28 21:10:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284768044948008961",
  "text" : "if i dont get my pills, i could be on the news... #justsayin",
  "id" : 284768044948008961,
  "created_at" : "2012-12-28 21:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 79, 93 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Homunculus aka #Hom",
      "screen_name" : "HomunculusLoikm",
      "indices" : [ 94, 110 ],
      "id_str" : "233933230",
      "id" : 233933230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284742114561114112",
  "geo" : { },
  "id_str" : "284745260926660609",
  "in_reply_to_user_id" : 34221188,
  "text" : "@diane_welburn same here and like you, my kid is free to find her own path : ) @atheistlady76 @HomunculusLoikm",
  "id" : 284745260926660609,
  "in_reply_to_status_id" : 284742114561114112,
  "created_at" : "2012-12-28 19:38:55 +0000",
  "in_reply_to_screen_name" : "CountryMomma0",
  "in_reply_to_user_id_str" : "34221188",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284734935057707010",
  "text" : "RT @TyrusBooks: I want to pick up the airfare for somebody's New Year adventure. Are you ready to leave on the 31st\/1st? Details here. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/uyoOw0Hq",
        "expanded_url" : "http:\/\/www.benjaminleroy.com\/new-yearnew-adventure-your-turn\/",
        "display_url" : "benjaminleroy.com\/new-yearnew-ad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "284730812367265792",
    "text" : "I want to pick up the airfare for somebody's New Year adventure. Are you ready to leave on the 31st\/1st? Details here. http:\/\/t.co\/uyoOw0Hq",
    "id" : 284730812367265792,
    "created_at" : "2012-12-28 18:41:30 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 284734935057707010,
  "created_at" : "2012-12-28 18:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Roller",
      "screen_name" : "rolldiggity",
      "indices" : [ 3, 15 ],
      "id_str" : "157526840",
      "id" : 157526840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284734797438402562",
  "text" : "RT @rolldiggity: 1. Hide babies all over house.\n2. If a kid asks, \"Where do babies come from?\" laugh, \"Where DON'T they come from!\" and  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254660079930970112",
    "text" : "1. Hide babies all over house.\n2. If a kid asks, \"Where do babies come from?\" laugh, \"Where DON'T they come from!\" and open every cabinet.",
    "id" : 254660079930970112,
    "created_at" : "2012-10-06 19:11:09 +0000",
    "user" : {
      "name" : "Matt Roller",
      "screen_name" : "rolldiggity",
      "protected" : false,
      "id_str" : "157526840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1590038887\/IMG_0423_normal.JPG",
      "id" : 157526840,
      "verified" : false
    }
  },
  "id" : 284734797438402562,
  "created_at" : "2012-12-28 18:57:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "indices" : [ 3, 11 ],
      "id_str" : "124176955",
      "id" : 124176955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/FKwzBGQK",
      "expanded_url" : "http:\/\/eepurl.com\/tr-F1",
      "display_url" : "eepurl.com\/tr-F1"
    } ]
  },
  "geo" : { },
  "id_str" : "284718977152847875",
  "text" : "RT @G5games: Your free gift - Special Enquiry Detail! - http:\/\/t.co\/FKwzBGQK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.mailchimp.com\" rel=\"nofollow\"\u003EMailChimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/FKwzBGQK",
        "expanded_url" : "http:\/\/eepurl.com\/tr-F1",
        "display_url" : "eepurl.com\/tr-F1"
      } ]
    },
    "geo" : { },
    "id_str" : "284717367920058369",
    "text" : "Your free gift - Special Enquiry Detail! - http:\/\/t.co\/FKwzBGQK",
    "id" : 284717367920058369,
    "created_at" : "2012-12-28 17:48:04 +0000",
    "user" : {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "protected" : false,
      "id_str" : "124176955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554687863338438656\/TlbHHhe4_normal.png",
      "id" : 124176955,
      "verified" : false
    }
  },
  "id" : 284718977152847875,
  "created_at" : "2012-12-28 17:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omg",
      "indices" : [ 54, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284714561431543808",
  "text" : "FINALLY figured out how to get audiobook onto ipod .. #omg",
  "id" : 284714561431543808,
  "created_at" : "2012-12-28 17:36:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 2, 16 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284713037347319808",
  "geo" : { },
  "id_str" : "284714367788912641",
  "in_reply_to_user_id" : 265007259,
  "text" : ". @atheistlady76 a big AMEN! to your last few tweets.. thank you!! #compassion",
  "id" : 284714367788912641,
  "in_reply_to_status_id" : 284713037347319808,
  "created_at" : "2012-12-28 17:36:09 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "indices" : [ 3, 13 ],
      "id_str" : "17052345",
      "id" : 17052345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Ppnv6qaD",
      "expanded_url" : "http:\/\/fb.me\/zadfbU2p",
      "display_url" : "fb.me\/zadfbU2p"
    } ]
  },
  "geo" : { },
  "id_str" : "284713638005198851",
  "text" : "RT @TedDekker: Today is FREE day! Identity, Book one of Eyes Wide Open, is out now and free. Just click here--&gt;... http:\/\/t.co\/Ppnv6qaD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/Ppnv6qaD",
        "expanded_url" : "http:\/\/fb.me\/zadfbU2p",
        "display_url" : "fb.me\/zadfbU2p"
      } ]
    },
    "geo" : { },
    "id_str" : "284710113460252672",
    "text" : "Today is FREE day! Identity, Book one of Eyes Wide Open, is out now and free. Just click here--&gt;... http:\/\/t.co\/Ppnv6qaD",
    "id" : 284710113460252672,
    "created_at" : "2012-12-28 17:19:15 +0000",
    "user" : {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "protected" : false,
      "id_str" : "17052345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742685559\/Picture_2_normal.png",
      "id" : 17052345,
      "verified" : false
    }
  },
  "id" : 284713638005198851,
  "created_at" : "2012-12-28 17:33:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284713348233314304",
  "text" : "RT @atheistlady76: People lose their jobs, and they work at whatever they can but its not enough and insurance isn't there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284712299078500353",
    "text" : "People lose their jobs, and they work at whatever they can but its not enough and insurance isn't there.",
    "id" : 284712299078500353,
    "created_at" : "2012-12-28 17:27:56 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 284713348233314304,
  "created_at" : "2012-12-28 17:32:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284713272123465728",
  "text" : "RT @atheistlady76: They need to eat, they need healthcare. Get a grip people and find your compassion, your empathy, your humanity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284712637693050881",
    "text" : "They need to eat, they need healthcare. Get a grip people and find your compassion, your empathy, your humanity.",
    "id" : 284712637693050881,
    "created_at" : "2012-12-28 17:29:17 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 284713272123465728,
  "created_at" : "2012-12-28 17:31:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284690293108916225",
  "text" : "@Skeptical_Lady aww.. he's beautiful!",
  "id" : 284690293108916225,
  "created_at" : "2012-12-28 16:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Business",
      "screen_name" : "HuffPostBiz",
      "indices" : [ 108, 120 ],
      "id_str" : "27073265",
      "id" : 27073265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/RpMwKTE3",
      "expanded_url" : "http:\/\/huff.to\/YoYy6y",
      "display_url" : "huff.to\/YoYy6y"
    } ]
  },
  "geo" : { },
  "id_str" : "284681217662652416",
  "text" : "GOP Governors Deny The Poor Health Care In Opposing Obamacare's Medicaid Expansion http:\/\/t.co\/RpMwKTE3 via @HuffPostBiz",
  "id" : 284681217662652416,
  "created_at" : "2012-12-28 15:24:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284678193514946561",
  "text" : "Tablets are NOT ereaders!!! #justsayin",
  "id" : 284678193514946561,
  "created_at" : "2012-12-28 15:12:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 25, 38 ],
      "id_str" : "361815486",
      "id" : 361815486
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 39, 50 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "book",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284649138061197312",
  "text" : "#FF super nice #book ppl @bookwiseblog @TyrusBooks",
  "id" : 284649138061197312,
  "created_at" : "2012-12-28 13:16:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284443007854448640",
  "text" : "why does the #kindlefire not have audiobooks category??",
  "id" : 284443007854448640,
  "created_at" : "2012-12-27 23:37:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284431745246437376",
  "geo" : { },
  "id_str" : "284441396906164224",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields thanks.. just tried app.. has option for ipod books. didnt show. got files on my fire but mixed in w music.. bleh.",
  "id" : 284441396906164224,
  "in_reply_to_status_id" : 284431745246437376,
  "created_at" : "2012-12-27 23:31:28 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284429894799224832",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields ugh after i disconnect from pc, its not on ipod...",
  "id" : 284429894799224832,
  "created_at" : "2012-12-27 22:45:46 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284417872682442753",
  "geo" : { },
  "id_str" : "284425011329118209",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields got mb4 and mp3. finally getting it on ipod. had to switch sharing under music (on ipod)",
  "id" : 284425011329118209,
  "in_reply_to_status_id" : 284417872682442753,
  "created_at" : "2012-12-27 22:26:21 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284052086730133504",
  "geo" : { },
  "id_str" : "284416657353486337",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields which device did you D\/L to? trying to get on my fire or ipod wirelessly but not working. will have to resort to using wires.",
  "id" : 284416657353486337,
  "in_reply_to_status_id" : 284052086730133504,
  "created_at" : "2012-12-27 21:53:09 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 2, 10 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284385890351083520",
  "text" : ". @twitter needs to work on their rules. too many get suspended for no good reason...",
  "id" : 284385890351083520,
  "created_at" : "2012-12-27 19:50:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ling",
      "screen_name" : "YoungLordLing",
      "indices" : [ 0, 14 ],
      "id_str" : "606911417",
      "id" : 606911417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284384268287877120",
  "text" : "@YoungLordLing both atheistlady76 and i were sorry 2 see U were suspended. no reason 4 it from yr TL. hope U get it back. take care.",
  "id" : 284384268287877120,
  "created_at" : "2012-12-27 19:44:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284365352605978624",
  "text" : "RT @CoryBooker: Love witnessing people, who amidst the airport stress, cancellations &amp; frustrations, still keep their peace and exhi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284364674387034113",
    "text" : "Love witnessing people, who amidst the airport stress, cancellations &amp; frustrations, still keep their peace and exhibit kindness to others",
    "id" : 284364674387034113,
    "created_at" : "2012-12-27 18:26:36 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 284365352605978624,
  "created_at" : "2012-12-27 18:29:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NaTRASHa",
      "screen_name" : "ShesAllNat",
      "indices" : [ 3, 14 ],
      "id_str" : "31246637",
      "id" : 31246637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284364733908402176",
  "text" : "RT @ShesAllNat: It's a proven fact that women dress for other women. If we dressed for men we would probably just walk around nude holdi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253266030846173184",
    "text" : "It's a proven fact that women dress for other women. If we dressed for men we would probably just walk around nude holding a tray of bacon.",
    "id" : 253266030846173184,
    "created_at" : "2012-10-02 22:51:41 +0000",
    "user" : {
      "name" : "NaTRASHa",
      "screen_name" : "ShesAllNat",
      "protected" : false,
      "id_str" : "31246637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416385292854394880\/X0BxhqjH_normal.jpeg",
      "id" : 31246637,
      "verified" : false
    }
  },
  "id" : 284364733908402176,
  "created_at" : "2012-12-27 18:26:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 3, 12 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BCBerrie\/status\/284355505537814529\/photo\/1",
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/GQOZwx8s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_I702HCEAEasTf.jpg",
      "id_str" : "284355505542008833",
      "id" : 284355505542008833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_I702HCEAEasTf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GQOZwx8s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284362246413508608",
  "text" : "RT @BCBerrie: Just so you know.... ( I would so do this too!! ) http:\/\/t.co\/GQOZwx8s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BCBerrie\/status\/284355505537814529\/photo\/1",
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/GQOZwx8s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_I702HCEAEasTf.jpg",
        "id_str" : "284355505542008833",
        "id" : 284355505542008833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_I702HCEAEasTf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GQOZwx8s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284355505537814529",
    "text" : "Just so you know.... ( I would so do this too!! ) http:\/\/t.co\/GQOZwx8s",
    "id" : 284355505537814529,
    "created_at" : "2012-12-27 17:50:10 +0000",
    "user" : {
      "name" : "\uD83C\uDF3A\u026E\u0105w~\u0273\u00E9e\uD83C\uDF3A",
      "screen_name" : "BCBawnee",
      "protected" : false,
      "id_str" : "24500414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707344203278200833\/yTRgqHSe_normal.jpg",
      "id" : 24500414,
      "verified" : false
    }
  },
  "id" : 284362246413508608,
  "created_at" : "2012-12-27 18:16:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284354760075784194",
  "text" : "RT @AnAmericanMonk: Dwell not on the faults and shortcomings of others; instead, seek clarity about your own. Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284354260433510401",
    "text" : "Dwell not on the faults and shortcomings of others; instead, seek clarity about your own. Buddha",
    "id" : 284354260433510401,
    "created_at" : "2012-12-27 17:45:13 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 284354760075784194,
  "created_at" : "2012-12-27 17:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake the Dog(Jailed)",
      "screen_name" : "DragonW1ng",
      "indices" : [ 0, 11 ],
      "id_str" : "830188838",
      "id" : 830188838
    }, {
      "name" : "Ling",
      "screen_name" : "YoungLordLing",
      "indices" : [ 29, 43 ],
      "id_str" : "606911417",
      "id" : 606911417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284181126434680833",
  "geo" : { },
  "id_str" : "284344544873553921",
  "in_reply_to_user_id" : 830188838,
  "text" : "@DragonW1ng @JakeDaLumpinDog @YoungLordLing no, she didnt. i hope Jake reads convo between me and atheistlady76. blessings, MBG.",
  "id" : 284344544873553921,
  "in_reply_to_status_id" : 284181126434680833,
  "created_at" : "2012-12-27 17:06:37 +0000",
  "in_reply_to_screen_name" : "DragonW1ng",
  "in_reply_to_user_id_str" : "830188838",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284324155137073152",
  "text" : "@Skeptical_Lady Matthew 6:6 : )",
  "id" : 284324155137073152,
  "created_at" : "2012-12-27 15:45:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miley Ray Cyrus",
      "screen_name" : "MileyCyrus",
      "indices" : [ 3, 14 ],
      "id_str" : "268414482",
      "id" : 268414482
    }, {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 16, 26 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284318474241728512",
  "text" : "RT @MileyCyrus: @petsalive my prayers go out to all the friends Sally made here on this earth and send peace to little Sally as she make ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pets Alive",
        "screen_name" : "petsalive",
        "indices" : [ 0, 10 ],
        "id_str" : "29738127",
        "id" : 29738127
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "284105702711119875",
    "geo" : { },
    "id_str" : "284109487680401409",
    "in_reply_to_user_id" : 29738127,
    "text" : "@petsalive my prayers go out to all the friends Sally made here on this earth and send peace to little Sally as she makes it up to heaven. \u2764",
    "id" : 284109487680401409,
    "in_reply_to_status_id" : 284105702711119875,
    "created_at" : "2012-12-27 01:32:35 +0000",
    "in_reply_to_screen_name" : "petsalive",
    "in_reply_to_user_id_str" : "29738127",
    "user" : {
      "name" : "Miley Ray Cyrus",
      "screen_name" : "MileyCyrus",
      "protected" : false,
      "id_str" : "268414482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785898039013548033\/q1cxZPEP_normal.jpg",
      "id" : 268414482,
      "verified" : true
    }
  },
  "id" : 284318474241728512,
  "created_at" : "2012-12-27 15:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Sibley",
      "screen_name" : "jbsibley",
      "indices" : [ 3, 12 ],
      "id_str" : "14085981",
      "id" : 14085981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/x3IYLeUM",
      "expanded_url" : "http:\/\/jbsib.ly\/VfmZ5c",
      "display_url" : "jbsib.ly\/VfmZ5c"
    } ]
  },
  "geo" : { },
  "id_str" : "284318412937768961",
  "text" : "RT @jbsibley: Waggin' Train set to kill Nikki the Shepherd today. They have refused a professional evaluation. http:\/\/t.co\/x3IYLeUM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/x3IYLeUM",
        "expanded_url" : "http:\/\/jbsib.ly\/VfmZ5c",
        "display_url" : "jbsib.ly\/VfmZ5c"
      } ]
    },
    "geo" : { },
    "id_str" : "284264617130221568",
    "text" : "Waggin' Train set to kill Nikki the Shepherd today. They have refused a professional evaluation. http:\/\/t.co\/x3IYLeUM",
    "id" : 284264617130221568,
    "created_at" : "2012-12-27 11:49:00 +0000",
    "user" : {
      "name" : "John Sibley",
      "screen_name" : "jbsibley",
      "protected" : false,
      "id_str" : "14085981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748878782514200576\/igw5XSkw_normal.jpg",
      "id" : 14085981,
      "verified" : false
    }
  },
  "id" : 284318412937768961,
  "created_at" : "2012-12-27 15:22:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/CswZFvnV",
      "expanded_url" : "http:\/\/amzn.to\/wu25pf",
      "display_url" : "amzn.to\/wu25pf"
    } ]
  },
  "geo" : { },
  "id_str" : "284125514971619328",
  "text" : "finished i2 by James Bannon http:\/\/t.co\/CswZFvnV",
  "id" : 284125514971619328,
  "created_at" : "2012-12-27 02:36:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/kHUzIY53",
      "expanded_url" : "http:\/\/twitpic.com\/bpok8s",
      "display_url" : "twitpic.com\/bpok8s"
    } ]
  },
  "geo" : { },
  "id_str" : "284089095980978176",
  "text" : "RT @ChrisGroove1: There's a little mouse in my beard. http:\/\/t.co\/kHUzIY53",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/kHUzIY53",
        "expanded_url" : "http:\/\/twitpic.com\/bpok8s",
        "display_url" : "twitpic.com\/bpok8s"
      } ]
    },
    "geo" : { },
    "id_str" : "284088628286730240",
    "text" : "There's a little mouse in my beard. http:\/\/t.co\/kHUzIY53",
    "id" : 284088628286730240,
    "created_at" : "2012-12-27 00:09:41 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 284089095980978176,
  "created_at" : "2012-12-27 00:11:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/F6yqbQXk",
      "expanded_url" : "http:\/\/readerswin.com\/2012\/12\/26\/best-books-of-2012-giveaway\/",
      "display_url" : "readerswin.com\/2012\/12\/26\/bes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284056731674353664",
  "text" : "Best Books of 2012 Giveaway http:\/\/t.co\/F6yqbQXk",
  "id" : 284056731674353664,
  "created_at" : "2012-12-26 22:02:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 2, 15 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284041179220291584",
  "geo" : { },
  "id_str" : "284051822199599104",
  "in_reply_to_user_id" : 14835882,
  "text" : ". @adamrshields Nice! Im D\/L Matterhorn read by Bronson Pinchot : )",
  "id" : 284051822199599104,
  "in_reply_to_status_id" : 284041179220291584,
  "created_at" : "2012-12-26 21:43:26 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/nnqd8lC1",
      "expanded_url" : "http:\/\/Downpour.com",
      "display_url" : "Downpour.com"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/EwMM0ik1",
      "expanded_url" : "http:\/\/bookwi.se\/a-free-audiobook-from-downpour-com\/",
      "display_url" : "bookwi.se\/a-free-audiobo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284049572756615171",
  "text" : "RT @adamrshields: A Free Audiobook from http:\/\/t.co\/nnqd8lC1 - Downpour is a new audiobook store from Blackstone Audio. http:\/\/t.co\/EwMM0ik1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/nnqd8lC1",
        "expanded_url" : "http:\/\/Downpour.com",
        "display_url" : "Downpour.com"
      }, {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/EwMM0ik1",
        "expanded_url" : "http:\/\/bookwi.se\/a-free-audiobook-from-downpour-com\/",
        "display_url" : "bookwi.se\/a-free-audiobo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "284041179220291584",
    "text" : "A Free Audiobook from http:\/\/t.co\/nnqd8lC1 - Downpour is a new audiobook store from Blackstone Audio. http:\/\/t.co\/EwMM0ik1",
    "id" : 284041179220291584,
    "created_at" : "2012-12-26 21:01:09 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 284049572756615171,
  "created_at" : "2012-12-26 21:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283999452837056512",
  "text" : "RT @SenSanders: 93% of all new income generated between 2009 &amp; 2010 went to the top 1% while the bottom 99% split the remaining 7%.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "fiscalcliff",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283998154981011456",
    "text" : "93% of all new income generated between 2009 &amp; 2010 went to the top 1% while the bottom 99% split the remaining 7%. #budget #fiscalcliff",
    "id" : 283998154981011456,
    "created_at" : "2012-12-26 18:10:11 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 283999452837056512,
  "created_at" : "2012-12-26 18:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283997223098920962",
  "geo" : { },
  "id_str" : "283999237421801472",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 @JakeDaLumpinDog got a 17yo girl here. we learn from each other. although, 12 to 15yo was tough..lol",
  "id" : 283999237421801472,
  "in_reply_to_status_id" : 283997223098920962,
  "created_at" : "2012-12-26 18:14:29 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283997184981073920",
  "text" : "RT @abandontheherd: The art of being wise is knowing what to overlook.\rWilliam James",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283997078965866499",
    "text" : "The art of being wise is knowing what to overlook.\rWilliam James",
    "id" : 283997078965866499,
    "created_at" : "2012-12-26 18:05:54 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 283997184981073920,
  "created_at" : "2012-12-26 18:06:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283996122555494400",
  "geo" : { },
  "id_str" : "283996964373274624",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 @JakeDaLumpinDog aww..hehe.. i remember being 16 and thinking \"what more could i know\" (or similar idea) LOLOL",
  "id" : 283996964373274624,
  "in_reply_to_status_id" : 283996122555494400,
  "created_at" : "2012-12-26 18:05:27 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283994426139877379",
  "geo" : { },
  "id_str" : "283995409179881472",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 @JakeDaLumpinDog oh no.. i didnt see anything controversial in TL. feel bad for him.",
  "id" : 283995409179881472,
  "in_reply_to_status_id" : 283994426139877379,
  "created_at" : "2012-12-26 17:59:16 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283963154986323968",
  "geo" : { },
  "id_str" : "283991678241603584",
  "in_reply_to_user_id" : 968537478,
  "text" : "@JakeDaLumpinDog i dont know the guy w flowers...",
  "id" : 283991678241603584,
  "in_reply_to_status_id" : 283963154986323968,
  "created_at" : "2012-12-26 17:44:27 +0000",
  "in_reply_to_screen_name" : "NihilistHorse",
  "in_reply_to_user_id_str" : "968537478",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 21, 35 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283963154986323968",
  "geo" : { },
  "id_str" : "283991252939177986",
  "in_reply_to_user_id" : 968537478,
  "text" : "fyi @JakeDaLumpinDog @atheistlady76 says \"blocking is diff from blocking for spam. Nobody blocked him for spam\"",
  "id" : 283991252939177986,
  "in_reply_to_status_id" : 283963154986323968,
  "created_at" : "2012-12-26 17:42:45 +0000",
  "in_reply_to_screen_name" : "NihilistHorse",
  "in_reply_to_user_id_str" : "968537478",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283615805332127745",
  "geo" : { },
  "id_str" : "283990859811282946",
  "in_reply_to_user_id" : 968537478,
  "text" : "@JakeDaLumpinDog im not thrilled w that either but i let it go. i focus on the positive things. makes life easier. : )",
  "id" : 283990859811282946,
  "in_reply_to_status_id" : 283615805332127745,
  "created_at" : "2012-12-26 17:41:11 +0000",
  "in_reply_to_screen_name" : "NihilistHorse",
  "in_reply_to_user_id_str" : "968537478",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283970523283734528",
  "geo" : { },
  "id_str" : "283972770575036416",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 not my friend.. just was reading the convo between you two and then his TL...",
  "id" : 283972770575036416,
  "in_reply_to_status_id" : 283970523283734528,
  "created_at" : "2012-12-26 16:29:19 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/och7RSIi",
      "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyaCviSw",
      "display_url" : "tmblr.co\/ZwrrNyaCviSw"
    } ]
  },
  "geo" : { },
  "id_str" : "283964300396228609",
  "text" : "RT @parkstepp: \u201CYou\u2019re a different human being to everybody you meet.\u201D - Chuck Palahniuk (via mysticmementos) http:\/\/t.co\/och7RSIi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/och7RSIi",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyaCviSw",
        "display_url" : "tmblr.co\/ZwrrNyaCviSw"
      } ]
    },
    "geo" : { },
    "id_str" : "283963514555617280",
    "text" : "\u201CYou\u2019re a different human being to everybody you meet.\u201D - Chuck Palahniuk (via mysticmementos) http:\/\/t.co\/och7RSIi",
    "id" : 283963514555617280,
    "created_at" : "2012-12-26 15:52:32 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 283964300396228609,
  "created_at" : "2012-12-26 15:55:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 39, 53 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283784763872010242",
  "geo" : { },
  "id_str" : "283960202829651969",
  "in_reply_to_user_id" : 968537478,
  "text" : "@JakeDaLumpinDog did Twitter say that? @atheistlady76 wouldnt report you for spam. ive seen lots of ppl get suspended for no good reason.",
  "id" : 283960202829651969,
  "in_reply_to_status_id" : 283784763872010242,
  "created_at" : "2012-12-26 15:39:22 +0000",
  "in_reply_to_screen_name" : "NihilistHorse",
  "in_reply_to_user_id_str" : "968537478",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/YRaBKgCw",
      "expanded_url" : "http:\/\/getapp.cc\/app\/570850843",
      "display_url" : "getapp.cc\/app\/570850843"
    } ]
  },
  "geo" : { },
  "id_str" : "283953227387523072",
  "text" : "RT @AppAdvice: Retweet now for a chance to win picture mystery app Crime &amp; Puzzlement (http:\/\/t.co\/YRaBKgCw).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/YRaBKgCw",
        "expanded_url" : "http:\/\/getapp.cc\/app\/570850843",
        "display_url" : "getapp.cc\/app\/570850843"
      } ]
    },
    "geo" : { },
    "id_str" : "283952620459147265",
    "text" : "Retweet now for a chance to win picture mystery app Crime &amp; Puzzlement (http:\/\/t.co\/YRaBKgCw).",
    "id" : 283952620459147265,
    "created_at" : "2012-12-26 15:09:14 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 283953227387523072,
  "created_at" : "2012-12-26 15:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 3, 18 ],
      "id_str" : "17134268",
      "id" : 17134268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283946290520412162",
  "text" : "RT @CBSThisMorning: Mobile privacy expert Jason Hong says: If you read each policy on every app or website you used this year, it would  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283914186113814529",
    "text" : "Mobile privacy expert Jason Hong says: If you read each policy on every app or website you used this year, it would take 3 months",
    "id" : 283914186113814529,
    "created_at" : "2012-12-26 12:36:31 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 283946290520412162,
  "created_at" : "2012-12-26 14:44:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/HIacDpCt",
      "expanded_url" : "http:\/\/amzn.to\/zbWRgZ",
      "display_url" : "amzn.to\/zbWRgZ"
    } ]
  },
  "geo" : { },
  "id_str" : "283764269600886784",
  "text" : "finished The Harbor by Al Lamanda http:\/\/t.co\/HIacDpCt",
  "id" : 283764269600886784,
  "created_at" : "2012-12-26 02:40:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/igYTSZ5V",
      "expanded_url" : "http:\/\/via.me\/-85n0k5k",
      "display_url" : "via.me\/-85n0k5k"
    } ]
  },
  "geo" : { },
  "id_str" : "283698269371125760",
  "text" : "My new Crocs.. Yes, I asked for them..LOL. They are quite warm! http:\/\/t.co\/igYTSZ5V",
  "id" : 283698269371125760,
  "created_at" : "2012-12-25 22:18:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Er Spirit",
      "screen_name" : "makarovv_",
      "indices" : [ 19, 29 ],
      "id_str" : "1363074878",
      "id" : 1363074878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283614665190305793",
  "text" : "RT @DwayneReaves: \"@makarovv_: Maybe sometimes you have to lose who you were to find out who you are.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Er Spirit",
        "screen_name" : "makarovv_",
        "indices" : [ 1, 11 ],
        "id_str" : "1363074878",
        "id" : 1363074878
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283606353954619392",
    "text" : "\"@makarovv_: Maybe sometimes you have to lose who you were to find out who you are.\"",
    "id" : 283606353954619392,
    "created_at" : "2012-12-25 16:13:18 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 283614665190305793,
  "created_at" : "2012-12-25 16:46:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283598460635193344",
  "geo" : { },
  "id_str" : "283599349773135874",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 told hubby \"i will die with this pen!\" man at marketplace makes them, fell in love w this one.. the red is gorgeous. : )",
  "id" : 283599349773135874,
  "in_reply_to_status_id" : 283598460635193344,
  "created_at" : "2012-12-25 15:45:28 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anime",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "pokemon",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283598894468845568",
  "text" : "DD got manga studio debut 4 along w bamboo tablet. taking graphic arts in school and loves it! #anime #pokemon",
  "id" : 283598894468845568,
  "created_at" : "2012-12-25 15:43:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/AfRIf9HO",
      "expanded_url" : "http:\/\/via.me\/-85eg4hw",
      "display_url" : "via.me\/-85eg4hw"
    } ]
  },
  "geo" : { },
  "id_str" : "283598230535688193",
  "text" : "My new handmade wood pen hubby got for me! http:\/\/t.co\/AfRIf9HO",
  "id" : 283598230535688193,
  "created_at" : "2012-12-25 15:41:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celtic MoonDance",
      "screen_name" : "CelticMoonDance",
      "indices" : [ 3, 19 ],
      "id_str" : "503129866",
      "id" : 503129866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283596430453649408",
  "text" : "RT @CelticMoonDance: It doesn't matter who, what or how you are. Some will find a reason to hate you. Don't worry, some will love you fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "206443167497715712",
    "text" : "It doesn't matter who, what or how you are. Some will find a reason to hate you. Don't worry, some will love you for those same reasons.",
    "id" : 206443167497715712,
    "created_at" : "2012-05-26 17:54:21 +0000",
    "user" : {
      "name" : "Celtic MoonDance",
      "screen_name" : "CelticMoonDance",
      "protected" : false,
      "id_str" : "503129866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791308686685773824\/MLUz0Ypc_normal.jpg",
      "id" : 503129866,
      "verified" : false
    }
  },
  "id" : 283596430453649408,
  "created_at" : "2012-12-25 15:33:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283596240728494080",
  "text" : "RT @wilw: I bet Edward Scissorhands was a fucking ninja master with the wrapping paper.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283467434894184448",
    "text" : "I bet Edward Scissorhands was a fucking ninja master with the wrapping paper.",
    "id" : 283467434894184448,
    "created_at" : "2012-12-25 07:01:17 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503013851631616\/55p1uw70_normal.jpg",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 283596240728494080,
  "created_at" : "2012-12-25 15:33:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283418477979631616",
  "text" : "i love all my peeps... you are all a part of me &lt;3",
  "id" : 283418477979631616,
  "created_at" : "2012-12-25 03:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283418275533176832",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny Merry Christmas, Johnny. Thanks for following me. Hope I dont bore you : )",
  "id" : 283418275533176832,
  "created_at" : "2012-12-25 03:45:57 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283417275804024832",
  "geo" : { },
  "id_str" : "283417898230378496",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves i would love to read it. Merry Christmas, Dwayne.",
  "id" : 283417898230378496,
  "in_reply_to_status_id" : 283417275804024832,
  "created_at" : "2012-12-25 03:44:27 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/r7utGfID",
      "expanded_url" : "http:\/\/www.imdb.com\/title\/tt0039502\/",
      "display_url" : "imdb.com\/title\/tt003950\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283417443588784128",
  "text" : "saw a really good movie tonight.. It Happened on Fifth Avenue http:\/\/t.co\/r7utGfID",
  "id" : 283417443588784128,
  "created_at" : "2012-12-25 03:42:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 13, 23 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283416466202714113",
  "geo" : { },
  "id_str" : "283416989874126848",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms @CubeMelon you two are so cute.. i love it!",
  "id" : 283416989874126848,
  "in_reply_to_status_id" : 283416466202714113,
  "created_at" : "2012-12-25 03:40:50 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283416301572067328",
  "geo" : { },
  "id_str" : "283416853378904066",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 big christmas (((hugs))) muah!",
  "id" : 283416853378904066,
  "in_reply_to_status_id" : 283416301572067328,
  "created_at" : "2012-12-25 03:40:18 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283413064919945217",
  "geo" : { },
  "id_str" : "283414003525505025",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon LOLOL",
  "id" : 283414003525505025,
  "in_reply_to_status_id" : 283413064919945217,
  "created_at" : "2012-12-25 03:28:58 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283413114882506752",
  "geo" : { },
  "id_str" : "283413936706052097",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ouch! : (",
  "id" : 283413936706052097,
  "in_reply_to_status_id" : 283413114882506752,
  "created_at" : "2012-12-25 03:28:42 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283413184013012993",
  "geo" : { },
  "id_str" : "283413848592109568",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 aww.. sweet!",
  "id" : 283413848592109568,
  "in_reply_to_status_id" : 283413184013012993,
  "created_at" : "2012-12-25 03:28:21 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "indices" : [ 3, 16 ],
      "id_str" : "16744783",
      "id" : 16744783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283304546296549376",
  "text" : "RT @LisaTBergren: Christian book bloggers, if you have a Kindle and would like to review THE BRIDGE, please email me. Lisa @ BergrenCrea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283303389075488768",
    "text" : "Christian book bloggers, if you have a Kindle and would like to review THE BRIDGE, please email me. Lisa @ BergrenCreativeGroup dot com",
    "id" : 283303389075488768,
    "created_at" : "2012-12-24 20:09:26 +0000",
    "user" : {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "protected" : false,
      "id_str" : "16744783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694980555096457216\/ApJGMyxi_normal.jpg",
      "id" : 16744783,
      "verified" : false
    }
  },
  "id" : 283304546296549376,
  "created_at" : "2012-12-24 20:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283269434561417217",
  "text" : "RT @neiltyson: Random Santa Fact: Longitude lines border Time Zones. So at the North Pole, where all lines meet, clock time has no meaning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283269058416238592",
    "text" : "Random Santa Fact: Longitude lines border Time Zones. So at the North Pole, where all lines meet, clock time has no meaning.",
    "id" : 283269058416238592,
    "created_at" : "2012-12-24 17:53:01 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 283269434561417217,
  "created_at" : "2012-12-24 17:54:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "Realaqua",
      "screen_name" : "realaqua",
      "indices" : [ 97, 106 ],
      "id_str" : "157470755",
      "id" : 157470755
    }, {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 107, 115 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "isabella mori",
      "screen_name" : "moritherapy",
      "indices" : [ 116, 128 ],
      "id_str" : "814261",
      "id" : 814261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283268094397386754",
  "text" : "RT @CoyoteSings: I really believe everything we do boils down to compassion, to the golden rule. @realaqua @SangyeH @moritherapy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Realaqua",
        "screen_name" : "realaqua",
        "indices" : [ 80, 89 ],
        "id_str" : "157470755",
        "id" : 157470755
      }, {
        "name" : "Ani Sangye",
        "screen_name" : "SangyeH",
        "indices" : [ 90, 98 ],
        "id_str" : "54744689",
        "id" : 54744689
      }, {
        "name" : "isabella mori",
        "screen_name" : "moritherapy",
        "indices" : [ 99, 111 ],
        "id_str" : "814261",
        "id" : 814261
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283055463694745600",
    "text" : "I really believe everything we do boils down to compassion, to the golden rule. @realaqua @SangyeH @moritherapy",
    "id" : 283055463694745600,
    "created_at" : "2012-12-24 03:44:16 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 283268094397386754,
  "created_at" : "2012-12-24 17:49:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/3YZ15TtA",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/roK",
      "display_url" : "omgf.ac\/ts\/roK"
    } ]
  },
  "geo" : { },
  "id_str" : "283264281414348800",
  "text" : "RT @OMGFacts: Norway's income tax is HALVED in November to give everyone more money for the holidays! Details ---&gt; http:\/\/t.co\/3YZ15TtA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/3YZ15TtA",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/roK",
        "display_url" : "omgf.ac\/ts\/roK"
      } ]
    },
    "geo" : { },
    "id_str" : "283263382075887617",
    "text" : "Norway's income tax is HALVED in November to give everyone more money for the holidays! Details ---&gt; http:\/\/t.co\/3YZ15TtA",
    "id" : 283263382075887617,
    "created_at" : "2012-12-24 17:30:27 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 283264281414348800,
  "created_at" : "2012-12-24 17:34:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283252707534442496",
  "text" : "RT @abandontheherd: Try not to get caught up in the storyline of life. Just do the next thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283251823610064897",
    "text" : "Try not to get caught up in the storyline of life. Just do the next thing.",
    "id" : 283251823610064897,
    "created_at" : "2012-12-24 16:44:31 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 283252707534442496,
  "created_at" : "2012-12-24 16:48:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283237893621813249",
  "text" : "@Skeptical_Lady ouch! glad it wasnt worse! i swear our cat wants to kill me. she likes to stand right behind me, i turn and trip over her!",
  "id" : 283237893621813249,
  "created_at" : "2012-12-24 15:49:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nature",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "Kindness",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "birds",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "encourage",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "inspire",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "be_kind",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/lWrKbu4V",
      "expanded_url" : "http:\/\/ow.ly\/gkSHb",
      "display_url" : "ow.ly\/gkSHb"
    } ]
  },
  "geo" : { },
  "id_str" : "283237300257824769",
  "text" : "RT @KerriFar: The #Nature of #Kindness ~ http:\/\/t.co\/lWrKbu4V  ~ #birds #encourage #inspire #be_kind",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "Kindness",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "birds",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "encourage",
        "indices" : [ 58, 68 ]
      }, {
        "text" : "inspire",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "be_kind",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/lWrKbu4V",
        "expanded_url" : "http:\/\/ow.ly\/gkSHb",
        "display_url" : "ow.ly\/gkSHb"
      } ]
    },
    "geo" : { },
    "id_str" : "283236866596167680",
    "text" : "The #Nature of #Kindness ~ http:\/\/t.co\/lWrKbu4V  ~ #birds #encourage #inspire #be_kind",
    "id" : 283236866596167680,
    "created_at" : "2012-12-24 15:45:05 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 283237300257824769,
  "created_at" : "2012-12-24 15:46:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abraham Lincoln",
      "screen_name" : "Mr_Lincoln",
      "indices" : [ 3, 14 ],
      "id_str" : "33352787",
      "id" : 33352787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283224746181656578",
  "text" : "RT @Mr_Lincoln: Read one of Lincoln's most touching letters, written 150 yrs ago 12\/23\/1862 to girl who lost her dad in Civil War.  http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/6BUTzoAq",
        "expanded_url" : "http:\/\/showcase.netins.net\/web\/creative\/lincoln\/speeches\/mccull.htm",
        "display_url" : "showcase.netins.net\/web\/creative\/l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "283217933650505728",
    "text" : "Read one of Lincoln's most touching letters, written 150 yrs ago 12\/23\/1862 to girl who lost her dad in Civil War.  http:\/\/t.co\/6BUTzoAq",
    "id" : 283217933650505728,
    "created_at" : "2012-12-24 14:29:51 +0000",
    "user" : {
      "name" : "Abraham Lincoln",
      "screen_name" : "Mr_Lincoln",
      "protected" : false,
      "id_str" : "33352787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673881152936124416\/ytzED1Rj_normal.jpg",
      "id" : 33352787,
      "verified" : false
    }
  },
  "id" : 283224746181656578,
  "created_at" : "2012-12-24 14:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "DianeN56",
      "screen_name" : "DianeN56",
      "indices" : [ 54, 63 ],
      "id_str" : "30971909",
      "id" : 30971909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283027382691049472",
  "text" : "RT @oceanshaman: LOVE these reindeer! Atmospheric! RT @DianeN56 Nature Photo - Reindeer by Arne K Mala. Location: Norway http:\/\/t.co\/mqc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DianeN56",
        "screen_name" : "DianeN56",
        "indices" : [ 37, 46 ],
        "id_str" : "30971909",
        "id" : 30971909
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DianeN56\/status\/282552592150712321\/photo\/1",
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/mqc7dSIn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-vUFeYCUAAnoKi.jpg",
        "id_str" : "282552592159100928",
        "id" : 282552592159100928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-vUFeYCUAAnoKi.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/mqc7dSIn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "282552592150712321",
    "geo" : { },
    "id_str" : "283026544983670784",
    "in_reply_to_user_id" : 30971909,
    "text" : "LOVE these reindeer! Atmospheric! RT @DianeN56 Nature Photo - Reindeer by Arne K Mala. Location: Norway http:\/\/t.co\/mqc7dSIn `",
    "id" : 283026544983670784,
    "in_reply_to_status_id" : 282552592150712321,
    "created_at" : "2012-12-24 01:49:21 +0000",
    "in_reply_to_screen_name" : "DianeN56",
    "in_reply_to_user_id_str" : "30971909",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 283027382691049472,
  "created_at" : "2012-12-24 01:52:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sampson",
      "screen_name" : "MrRyanSampson",
      "indices" : [ 3, 17 ],
      "id_str" : "68146625",
      "id" : 68146625
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRyanSampson\/status\/282995517145903105\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/Sn5WwUae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-1m7GkCcAEzdyc.jpg",
      "id_str" : "282995517154291713",
      "id" : 282995517154291713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-1m7GkCcAEzdyc.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Sn5WwUae"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283026207455453186",
  "text" : "RT @MrRyanSampson: Wrapped my little cousins presents in this. I win, forever. http:\/\/t.co\/Sn5WwUae",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRyanSampson\/status\/282995517145903105\/photo\/1",
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/Sn5WwUae",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-1m7GkCcAEzdyc.jpg",
        "id_str" : "282995517154291713",
        "id" : 282995517154291713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-1m7GkCcAEzdyc.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Sn5WwUae"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282995517145903105",
    "text" : "Wrapped my little cousins presents in this. I win, forever. http:\/\/t.co\/Sn5WwUae",
    "id" : 282995517145903105,
    "created_at" : "2012-12-23 23:46:04 +0000",
    "user" : {
      "name" : "Ryan Sampson",
      "screen_name" : "MrRyanSampson",
      "protected" : false,
      "id_str" : "68146625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457983066686775296\/NHeSOgyW_normal.png",
      "id" : 68146625,
      "verified" : true
    }
  },
  "id" : 283026207455453186,
  "created_at" : "2012-12-24 01:48:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "milk",
      "screen_name" : "miilkkk",
      "indices" : [ 3, 11 ],
      "id_str" : "57838735",
      "id" : 57838735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/miilkkk\/status\/283024832684240899\/photo\/1",
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/MFxPFabd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-2BlfdCMAA40Ea.jpg",
      "id_str" : "283024832692629504",
      "id" : 283024832692629504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-2BlfdCMAA40Ea.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 398
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 398
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MFxPFabd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283025681594585088",
  "text" : "RT @miilkkk: Mom Where Are You? ...CRYING http:\/\/t.co\/MFxPFabd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/miilkkk\/status\/283024832684240899\/photo\/1",
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/MFxPFabd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-2BlfdCMAA40Ea.jpg",
        "id_str" : "283024832692629504",
        "id" : 283024832692629504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-2BlfdCMAA40Ea.jpg",
        "sizes" : [ {
          "h" : 333,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MFxPFabd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283024832684240899",
    "text" : "Mom Where Are You? ...CRYING http:\/\/t.co\/MFxPFabd",
    "id" : 283024832684240899,
    "created_at" : "2012-12-24 01:42:33 +0000",
    "user" : {
      "name" : "milk",
      "screen_name" : "miilkkk",
      "protected" : false,
      "id_str" : "57838735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601530736953327616\/E-8d68-4_normal.jpg",
      "id" : 57838735,
      "verified" : false
    }
  },
  "id" : 283025681594585088,
  "created_at" : "2012-12-24 01:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "indices" : [ 3, 12 ],
      "id_str" : "394134197",
      "id" : 394134197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/zarlF0CE",
      "expanded_url" : "http:\/\/ow.ly\/ghVT5",
      "display_url" : "ow.ly\/ghVT5"
    } ]
  },
  "geo" : { },
  "id_str" : "283009890652413954",
  "text" : "RT @mfpenney: What If All the World\u2019s Debt Just Went Away - http:\/\/t.co\/zarlF0CE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/zarlF0CE",
        "expanded_url" : "http:\/\/ow.ly\/ghVT5",
        "display_url" : "ow.ly\/ghVT5"
      } ]
    },
    "geo" : { },
    "id_str" : "283007933267193857",
    "text" : "What If All the World\u2019s Debt Just Went Away - http:\/\/t.co\/zarlF0CE",
    "id" : 283007933267193857,
    "created_at" : "2012-12-24 00:35:23 +0000",
    "user" : {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "protected" : false,
      "id_str" : "394134197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596470057\/DSCN0545_normal.jpg",
      "id" : 394134197,
      "verified" : false
    }
  },
  "id" : 283009890652413954,
  "created_at" : "2012-12-24 00:43:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drawsomething",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283005315589488641",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses my problem is im overthinking #drawsomething ugh...",
  "id" : 283005315589488641,
  "created_at" : "2012-12-24 00:24:59 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282999895303012353",
  "text" : "RT @petsalive: Welcome to Pets Alive Lilly. Even if THEY didn't...WE love you. And every one of us will focus on making u happy. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/282997207102275584\/photo\/1",
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/QI5zaLRh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-1odeJCQAE8fyP.jpg",
        "id_str" : "282997207110664193",
        "id" : 282997207110664193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-1odeJCQAE8fyP.jpg",
        "sizes" : [ {
          "h" : 1274,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 747,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1781,
          "resize" : "fit",
          "w" : 1431
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QI5zaLRh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282997207102275584",
    "text" : "Welcome to Pets Alive Lilly. Even if THEY didn't...WE love you. And every one of us will focus on making u happy. http:\/\/t.co\/QI5zaLRh",
    "id" : 282997207102275584,
    "created_at" : "2012-12-23 23:52:47 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 282999895303012353,
  "created_at" : "2012-12-24 00:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 92 ],
      "url" : "https:\/\/t.co\/dNQXSuPt",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=533303923348111&set=a.255779241100582.77234.155925874419253&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282984540828491776",
  "text" : "RT @ChrisGroove1: Is there no one in the NY area that can adopt Marky? https:\/\/t.co\/dNQXSuPt I have offered to send a big bag of food, b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 74 ],
        "url" : "https:\/\/t.co\/dNQXSuPt",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=533303923348111&set=a.255779241100582.77234.155925874419253&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "282977324260007937",
    "text" : "Is there no one in the NY area that can adopt Marky? https:\/\/t.co\/dNQXSuPt I have offered to send a big bag of food, bed, toys and kennel.",
    "id" : 282977324260007937,
    "created_at" : "2012-12-23 22:33:46 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 282984540828491776,
  "created_at" : "2012-12-23 23:02:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 3, 16 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/wMPX5p12",
      "expanded_url" : "http:\/\/bigfi.sh\/R9AzKa",
      "display_url" : "bigfi.sh\/R9AzKa"
    } ]
  },
  "geo" : { },
  "id_str" : "282941915211657216",
  "text" : "RT @bigfishgames: You know what would make a great gift? A FREE Nexus 7! Enter here to win one here: http:\/\/t.co\/wMPX5p12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/wMPX5p12",
        "expanded_url" : "http:\/\/bigfi.sh\/R9AzKa",
        "display_url" : "bigfi.sh\/R9AzKa"
      } ]
    },
    "geo" : { },
    "id_str" : "282941211034148864",
    "text" : "You know what would make a great gift? A FREE Nexus 7! Enter here to win one here: http:\/\/t.co\/wMPX5p12",
    "id" : 282941211034148864,
    "created_at" : "2012-12-23 20:10:16 +0000",
    "user" : {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "protected" : false,
      "id_str" : "14124789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676860668365029376\/hAOsWfK1_normal.jpg",
      "id" : 14124789,
      "verified" : false
    }
  },
  "id" : 282941915211657216,
  "created_at" : "2012-12-23 20:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282940316724629504",
  "text" : "RT @GeneDoucette: hhh8: TUMBLR GIVEAWAY\nI will be moving off to college soon and my mother won\u2019t be much use to me anymore, so \u2026 http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/99G2MN2C",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwZ-ceLX",
        "display_url" : "tmblr.co\/ZYrEZwZ-ceLX"
      } ]
    },
    "geo" : { },
    "id_str" : "282938978854912000",
    "text" : "hhh8: TUMBLR GIVEAWAY\nI will be moving off to college soon and my mother won\u2019t be much use to me anymore, so \u2026 http:\/\/t.co\/99G2MN2C",
    "id" : 282938978854912000,
    "created_at" : "2012-12-23 20:01:23 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 282940316724629504,
  "created_at" : "2012-12-23 20:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Free Script Installs",
      "screen_name" : "FreeScriptInsta",
      "indices" : [ 11, 27 ],
      "id_str" : "311115199",
      "id" : 311115199
    }, {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 37, 45 ],
      "id_str" : "61363491",
      "id" : 61363491
    }, {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 58, 67 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282919434329415682",
  "text" : "wishing my @FreeScriptInsta friends, @mbekezm @ryanholt94 @Mortenrb a merry christmas! : )",
  "id" : 282919434329415682,
  "created_at" : "2012-12-23 18:43:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282885715405185026",
  "text" : "RT @oshum: In the new year...let's not \"Do Business as usual\" ...let's do business according to the law of Love and Truth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282885365919002625",
    "text" : "In the new year...let's not \"Do Business as usual\" ...let's do business according to the law of Love and Truth.",
    "id" : 282885365919002625,
    "created_at" : "2012-12-23 16:28:21 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 282885715405185026,
  "created_at" : "2012-12-23 16:29:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    }, {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 21, 31 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282863076980695040",
  "geo" : { },
  "id_str" : "282870583027453952",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 I hope @petsalive sees this thread. i know they're not happy w nycacc.",
  "id" : 282870583027453952,
  "in_reply_to_status_id" : 282863076980695040,
  "created_at" : "2012-12-23 15:29:37 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 0, 13 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282616694516629504",
  "geo" : { },
  "id_str" : "282663643718496256",
  "in_reply_to_user_id" : 67346912,
  "text" : "@wildwitchyju thanks, hon. got it. my fave color, btw : )",
  "id" : 282663643718496256,
  "in_reply_to_status_id" : 282616694516629504,
  "created_at" : "2012-12-23 01:47:18 +0000",
  "in_reply_to_screen_name" : "wildwitchyju",
  "in_reply_to_user_id_str" : "67346912",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282644887248203776",
  "geo" : { },
  "id_str" : "282645221932662784",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin you can say that again...",
  "id" : 282645221932662784,
  "in_reply_to_status_id" : 282644887248203776,
  "created_at" : "2012-12-23 00:34:06 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish",
      "screen_name" : "4shish",
      "indices" : [ 3, 10 ],
      "id_str" : "61445515",
      "id" : 61445515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282645000825749504",
  "text" : "RT @4shish: After I drink my coffee at work I show my empty mug to the IT guy and tell him I've successfully installed Java. He hates me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271854216660791296",
    "text" : "After I drink my coffee at work I show my empty mug to the IT guy and tell him I've successfully installed Java. He hates me.",
    "id" : 271854216660791296,
    "created_at" : "2012-11-23 05:54:30 +0000",
    "user" : {
      "name" : "Ashish",
      "screen_name" : "4shish",
      "protected" : false,
      "id_str" : "61445515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777951096819953664\/ZdsFmTMp_normal.jpg",
      "id" : 61445515,
      "verified" : false
    }
  },
  "id" : 282645000825749504,
  "created_at" : "2012-12-23 00:33:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    }, {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 41, 51 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "philosophical",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282642189404737536",
  "text" : "@1stCitizenKane you might like to follow @alanhdawe #philosophical",
  "id" : 282642189404737536,
  "created_at" : "2012-12-23 00:22:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282618055647981569",
  "text" : "RT @neiltyson: In Walmart, America's largest gun seller, you can buy an assault rifle. But company policy bans pop music with curse words.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282576270536089600",
    "text" : "In Walmart, America's largest gun seller, you can buy an assault rifle. But company policy bans pop music with curse words.",
    "id" : 282576270536089600,
    "created_at" : "2012-12-22 20:00:07 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 282618055647981569,
  "created_at" : "2012-12-22 22:46:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patheos",
      "screen_name" : "Patheos",
      "indices" : [ 50, 58 ],
      "id_str" : "31743105",
      "id" : 31743105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282614259416961024",
  "text" : "RT @TomRapsasTweets: My most popular posts are at @Patheos Spirituality, incl: Three bible passages that may blow your mind (in a good w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patheos",
        "screen_name" : "Patheos",
        "indices" : [ 29, 37 ],
        "id_str" : "31743105",
        "id" : 31743105
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/lEAktRIM",
        "expanded_url" : "http:\/\/goo.gl\/jZxvq",
        "display_url" : "goo.gl\/jZxvq"
      } ]
    },
    "geo" : { },
    "id_str" : "282612852630618112",
    "text" : "My most popular posts are at @Patheos Spirituality, incl: Three bible passages that may blow your mind (in a good way) http:\/\/t.co\/lEAktRIM",
    "id" : 282612852630618112,
    "created_at" : "2012-12-22 22:25:29 +0000",
    "user" : {
      "name" : "Tom Rapsas",
      "screen_name" : "TomRapsas",
      "protected" : false,
      "id_str" : "84377368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459003600174206977\/OcjkrDsf_normal.jpeg",
      "id" : 84377368,
      "verified" : false
    }
  },
  "id" : 282614259416961024,
  "created_at" : "2012-12-22 22:31:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282607929734098945",
  "text" : "I need a drink...",
  "id" : 282607929734098945,
  "created_at" : "2012-12-22 22:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Nordby",
      "screen_name" : "JacobNordby",
      "indices" : [ 3, 15 ],
      "id_str" : "14443463",
      "id" : 14443463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAN1",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/HfgAc2qr",
      "expanded_url" : "http:\/\/yourawakenedself.com\/the-un-apocalypse-what-to-do-when-the-world-doesnt-end\/",
      "display_url" : "yourawakenedself.com\/the-un-apocaly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282599041295065088",
  "text" : "RT @JacobNordby: The Un-Apocalypse: What To Do When The World DOESN'T End (sort of funny article) &gt; http:\/\/t.co\/HfgAc2qr #IAN1 @Catal ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "maetsaliran198",
        "screen_name" : "Catalyst303",
        "indices" : [ 113, 125 ],
        "id_str" : "2982355377",
        "id" : 2982355377
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAN1",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/HfgAc2qr",
        "expanded_url" : "http:\/\/yourawakenedself.com\/the-un-apocalypse-what-to-do-when-the-world-doesnt-end\/",
        "display_url" : "yourawakenedself.com\/the-un-apocaly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "282584331225026560",
    "text" : "The Un-Apocalypse: What To Do When The World DOESN'T End (sort of funny article) &gt; http:\/\/t.co\/HfgAc2qr #IAN1 @Catalyst303",
    "id" : 282584331225026560,
    "created_at" : "2012-12-22 20:32:09 +0000",
    "user" : {
      "name" : "Jacob Nordby",
      "screen_name" : "JacobNordby",
      "protected" : false,
      "id_str" : "14443463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779852669250777088\/79-e7WnY_normal.jpg",
      "id" : 14443463,
      "verified" : false
    }
  },
  "id" : 282599041295065088,
  "created_at" : "2012-12-22 21:30:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282598330444439552",
  "text" : "@SamsaricWarrior white-breasted nuthatch",
  "id" : 282598330444439552,
  "created_at" : "2012-12-22 21:27:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 0, 13 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282594521848631296",
  "geo" : { },
  "id_str" : "282597591739428864",
  "in_reply_to_user_id" : 67346912,
  "text" : "@wildwitchyju me, please?",
  "id" : 282597591739428864,
  "in_reply_to_status_id" : 282594521848631296,
  "created_at" : "2012-12-22 21:24:50 +0000",
  "in_reply_to_screen_name" : "wildwitchyju",
  "in_reply_to_user_id_str" : "67346912",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282597041606103041",
  "text" : "RT @bengoldacre: Accidentally bought Xmas wraith. Everyone dead.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282596120646017025",
    "text" : "Accidentally bought Xmas wraith. Everyone dead.",
    "id" : 282596120646017025,
    "created_at" : "2012-12-22 21:19:00 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 282597041606103041,
  "created_at" : "2012-12-22 21:22:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    }, {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 17, 31 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282582775394078720",
  "geo" : { },
  "id_str" : "282585764192215040",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow @MelodyLeaLamb must have been mom..lol..just popped in my head : )",
  "id" : 282585764192215040,
  "in_reply_to_status_id" : 282582775394078720,
  "created_at" : "2012-12-22 20:37:51 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    }, {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 70, 84 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282561411069136896",
  "geo" : { },
  "id_str" : "282565173674377216",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow my mom flies w the stars now but I still have my MIL @MelodyLeaLamb",
  "id" : 282565173674377216,
  "in_reply_to_status_id" : 282561411069136896,
  "created_at" : "2012-12-22 19:16:01 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/SsRaVcEH",
      "expanded_url" : "http:\/\/www.zackvision.com\/projects\/wordpress\/now-watching\/",
      "display_url" : "zackvision.com\/projects\/wordp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "282560170209472512",
  "geo" : { },
  "id_str" : "282563220823232512",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses if you ever want to blog about the movies you watch.. : ) http:\/\/t.co\/SsRaVcEH",
  "id" : 282563220823232512,
  "in_reply_to_status_id" : 282560170209472512,
  "created_at" : "2012-12-22 19:08:16 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282554544062345216",
  "text" : "@BibleAlsoSays : (",
  "id" : 282554544062345216,
  "created_at" : "2012-12-22 18:33:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282543210209898498",
  "text" : "@BibleAlsoSays christmas.. bah humbug. christmas sucks.",
  "id" : 282543210209898498,
  "created_at" : "2012-12-22 17:48:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "indices" : [ 3, 16 ],
      "id_str" : "74399881",
      "id" : 74399881
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pamelamarie8\/status\/282303971656359936\/photo\/1",
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/k6urHAaK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-rx923CYAAwPoo.jpg",
      "id_str" : "282303971664748544",
      "id" : 282303971664748544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-rx923CYAAwPoo.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/k6urHAaK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282304586516164608",
  "text" : "RT @pamelamarie8: New York press 1909 on cancer &amp; vaccines ~&gt; http:\/\/t.co\/k6urHAaK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pamelamarie8\/status\/282303971656359936\/photo\/1",
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/k6urHAaK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-rx923CYAAwPoo.jpg",
        "id_str" : "282303971664748544",
        "id" : 282303971664748544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-rx923CYAAwPoo.jpg",
        "sizes" : [ {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/k6urHAaK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282303971656359936",
    "text" : "New York press 1909 on cancer &amp; vaccines ~&gt; http:\/\/t.co\/k6urHAaK",
    "id" : 282303971656359936,
    "created_at" : "2012-12-22 01:58:06 +0000",
    "user" : {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "protected" : false,
      "id_str" : "74399881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445924023600287744\/sh9pRUES_normal.jpeg",
      "id" : 74399881,
      "verified" : false
    }
  },
  "id" : 282304586516164608,
  "created_at" : "2012-12-22 02:00:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282212123394834432",
  "text" : ". @iEyeAyes nudity FTW! : )",
  "id" : 282212123394834432,
  "created_at" : "2012-12-21 19:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282175129495150592",
  "geo" : { },
  "id_str" : "282175604072259584",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings ((highfive)) : )",
  "id" : 282175604072259584,
  "in_reply_to_status_id" : 282175129495150592,
  "created_at" : "2012-12-21 17:28:01 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282175504499486720",
  "text" : "RT @CoyoteSings: The world has gone insane, and it wants me to go along with it. Well, I'm just not going to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282175129495150592",
    "text" : "The world has gone insane, and it wants me to go along with it. Well, I'm just not going to.",
    "id" : 282175129495150592,
    "created_at" : "2012-12-21 17:26:08 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 282175504499486720,
  "created_at" : "2012-12-21 17:27:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282173146432417793",
  "text" : "RT @Bashar_Contact: When you learn to love hell, you will be in heaven.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282172972456882177",
    "text" : "When you learn to love hell, you will be in heaven.",
    "id" : 282172972456882177,
    "created_at" : "2012-12-21 17:17:33 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 282173146432417793,
  "created_at" : "2012-12-21 17:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282170641027846146",
  "text" : "RT @CoyoteSings: Can anyone see that the more we teach our children they can't be safe anywhere, the more they'll accept that idea? Is t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282168441127976960",
    "text" : "Can anyone see that the more we teach our children they can't be safe anywhere, the more they'll accept that idea? Is that what we want?",
    "id" : 282168441127976960,
    "created_at" : "2012-12-21 16:59:33 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 282170641027846146,
  "created_at" : "2012-12-21 17:08:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 3, 15 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NRA",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282170505258213377",
  "text" : "RT @piersmorgan: This is your moment, America: The #NRA has 4 million members, your population is 311 million. Don't stand for this murd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NRA",
        "indices" : [ 34, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282161182960398336",
    "text" : "This is your moment, America: The #NRA has 4 million members, your population is 311 million. Don't stand for this murderous crap any more.",
    "id" : 282161182960398336,
    "created_at" : "2012-12-21 16:30:42 +0000",
    "user" : {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "protected" : false,
      "id_str" : "216299334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778941595164999680\/923GrEp1_normal.jpg",
      "id" : 216299334,
      "verified" : true
    }
  },
  "id" : 282170505258213377,
  "created_at" : "2012-12-21 17:07:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282170461205438464",
  "text" : "RT @CoyoteSings: How long before there's an armed guard in every theater, every school, every mall? Is that how we want to live our live ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NRA",
        "indices" : [ 122, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282168690538065921",
    "text" : "How long before there's an armed guard in every theater, every school, every mall? Is that how we want to live our lives? #NRA",
    "id" : 282168690538065921,
    "created_at" : "2012-12-21 17:00:32 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 282170461205438464,
  "created_at" : "2012-12-21 17:07:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A$AP VAMZ",
      "screen_name" : "kndiman",
      "indices" : [ 3, 11 ],
      "id_str" : "42839190",
      "id" : 42839190
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 13, 17 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282169873713467392",
  "text" : "RT @KNDIMAN: @WSJ Pathetic. Schools should be an open place for kids to feel comfortable, not a jail cell with armed guards.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 0, 4 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "282165455702081536",
    "geo" : { },
    "id_str" : "282168103113211904",
    "in_reply_to_user_id" : 3108351,
    "text" : "@WSJ Pathetic. Schools should be an open place for kids to feel comfortable, not a jail cell with armed guards.",
    "id" : 282168103113211904,
    "in_reply_to_status_id" : 282165455702081536,
    "created_at" : "2012-12-21 16:58:12 +0000",
    "in_reply_to_screen_name" : "WSJ",
    "in_reply_to_user_id_str" : "3108351",
    "user" : {
      "name" : "A$AP VAMZ",
      "screen_name" : "kndiman",
      "protected" : false,
      "id_str" : "42839190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662382716604710912\/dNm4O7KZ_normal.jpg",
      "id" : 42839190,
      "verified" : false
    }
  },
  "id" : 282169873713467392,
  "created_at" : "2012-12-21 17:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 51, 64 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YA",
      "indices" : [ 65, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/18JXVkYu",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B006AY9UGK\/ref=cm_sw_r_tw_ask_fe6pE.0R9A7S1",
      "display_url" : "amazon.com\/dp\/B006AY9UGK\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282157380828016640",
  "text" : "I just bought: 'Notes to Self' by Avery Sawyer via @amazonkindle #YA (free at time of purchase) http:\/\/t.co\/18JXVkYu",
  "id" : 282157380828016640,
  "created_at" : "2012-12-21 16:15:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/UhxFLiXn",
      "expanded_url" : "http:\/\/amzn.to\/wTlIBq",
      "display_url" : "amzn.to\/wTlIBq"
    } ]
  },
  "geo" : { },
  "id_str" : "281961458105991168",
  "text" : "finished The Divine Arsonist: A Tale of Awakening by Jacob Nordby http:\/\/t.co\/UhxFLiXn",
  "id" : 281961458105991168,
  "created_at" : "2012-12-21 03:17:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Weinstein",
      "screen_name" : "steveweinstein",
      "indices" : [ 3, 18 ],
      "id_str" : "47728859",
      "id" : 47728859
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 119, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281945110911004673",
  "text" : "RT @steveweinstein: Did the Founding Fathers say anything about what to do when the House turns into an insane asylum? #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 99, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281943307519684608",
    "text" : "Did the Founding Fathers say anything about what to do when the House turns into an insane asylum? #p2",
    "id" : 281943307519684608,
    "created_at" : "2012-12-21 02:04:57 +0000",
    "user" : {
      "name" : "Steve Weinstein",
      "screen_name" : "steveweinstein",
      "protected" : false,
      "id_str" : "47728859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2508405791\/jbioycasuuzyh45nej06_normal.jpeg",
      "id" : 47728859,
      "verified" : false
    }
  },
  "id" : 281945110911004673,
  "created_at" : "2012-12-21 02:12:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281926467540099072",
  "geo" : { },
  "id_str" : "281930181650829312",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater umm.. what did I miss?? lol",
  "id" : 281930181650829312,
  "in_reply_to_status_id" : 281926467540099072,
  "created_at" : "2012-12-21 01:12:47 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281888671555284992",
  "geo" : { },
  "id_str" : "281889380627529728",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen awww.. ((hugs))",
  "id" : 281889380627529728,
  "in_reply_to_status_id" : 281888671555284992,
  "created_at" : "2012-12-20 22:30:40 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "Susanna Lee",
      "screen_name" : "susannallee",
      "indices" : [ 38, 50 ],
      "id_str" : "19181602",
      "id" : 19181602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281887345584766976",
  "text" : "RT @CoyoteSings: I vote for naked. RT @susannallee: How does one dress for an Apocalypse?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susanna Lee",
        "screen_name" : "susannallee",
        "indices" : [ 21, 33 ],
        "id_str" : "19181602",
        "id" : 19181602
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281885516750807043",
    "text" : "I vote for naked. RT @susannallee: How does one dress for an Apocalypse?",
    "id" : 281885516750807043,
    "created_at" : "2012-12-20 22:15:19 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 281887345584766976,
  "created_at" : "2012-12-20 22:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281858028599398404",
  "text" : "RT @derekrootboy: Many physicists support parallel universes, coming from many different perspectives. But we can't communicate. What if ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281857150995808256",
    "text" : "Many physicists support parallel universes, coming from many different perspectives. But we can't communicate. What if consciousness could?",
    "id" : 281857150995808256,
    "created_at" : "2012-12-20 20:22:36 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 281858028599398404,
  "created_at" : "2012-12-20 20:26:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 24, 33 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bringnickhome",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281851838947540993",
  "geo" : { },
  "id_str" : "281856636082061313",
  "in_reply_to_user_id" : 184401626,
  "text" : "THIS! : ))) &gt;&gt; RT @AniKnits He's home!!!! #bringnickhome",
  "id" : 281856636082061313,
  "in_reply_to_status_id" : 281851838947540993,
  "created_at" : "2012-12-20 20:20:33 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281820190210150400",
  "text" : "RT @ToadHollowPhoto: A great shot to enjoy &amp; a terrific free eBook to download! Back at Nyhavn - and a free eBook for you! http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Nix",
        "screen_name" : "jimnixaustin",
        "indices" : [ 131, 144 ],
        "id_str" : "75063098",
        "id" : 75063098
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/Gkkx7K3m",
        "expanded_url" : "http:\/\/www.nomadicpursuits.com\/blog\/2012\/12\/18\/back-at-nyhavn-and-a-free-ebook-for-you.html\/",
        "display_url" : "nomadicpursuits.com\/blog\/2012\/12\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281817807962918912",
    "text" : "A great shot to enjoy &amp; a terrific free eBook to download! Back at Nyhavn - and a free eBook for you! http:\/\/t.co\/Gkkx7K3m via @jimnixaustin",
    "id" : 281817807962918912,
    "created_at" : "2012-12-20 17:46:16 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 281820190210150400,
  "created_at" : "2012-12-20 17:55:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/XxaltKJS",
      "expanded_url" : "http:\/\/familychristian.com",
      "display_url" : "familychristian.com"
    } ]
  },
  "geo" : { },
  "id_str" : "281819719009439745",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog btw.. when you buy kobo reader from http:\/\/t.co\/XxaltKJS, you get 3 free bibles",
  "id" : 281819719009439745,
  "created_at" : "2012-12-20 17:53:51 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RH Reality Check",
      "screen_name" : "rhrealitycheck",
      "indices" : [ 3, 18 ],
      "id_str" : "711267703403581440",
      "id" : 711267703403581440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birthcontrol",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "fem2",
      "indices" : [ 112, 117 ]
    }, {
      "text" : "contraception",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/E8SRU7CP",
      "expanded_url" : "http:\/\/ow.ly\/ggbty",
      "display_url" : "ow.ly\/ggbty"
    } ]
  },
  "geo" : { },
  "id_str" : "281806800272105473",
  "text" : "RT @rhrealitycheck: Not even condoms are safe when they are coming for your #birthcontrol. http:\/\/t.co\/E8SRU7CP #fem2 #contraception #pr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birthcontrol",
        "indices" : [ 56, 69 ]
      }, {
        "text" : "fem2",
        "indices" : [ 92, 97 ]
      }, {
        "text" : "contraception",
        "indices" : [ 98, 112 ]
      }, {
        "text" : "prochoice",
        "indices" : [ 113, 123 ]
      }, {
        "text" : "p2",
        "indices" : [ 124, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/E8SRU7CP",
        "expanded_url" : "http:\/\/ow.ly\/ggbty",
        "display_url" : "ow.ly\/ggbty"
      } ]
    },
    "geo" : { },
    "id_str" : "281799947358175232",
    "text" : "Not even condoms are safe when they are coming for your #birthcontrol. http:\/\/t.co\/E8SRU7CP #fem2 #contraception #prochoice #p2",
    "id" : 281799947358175232,
    "created_at" : "2012-12-20 16:35:17 +0000",
    "user" : {
      "name" : "Rewire",
      "screen_name" : "Rewire_News",
      "protected" : false,
      "id_str" : "14764240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711696395485323266\/R-B-2r6u_normal.jpg",
      "id" : 14764240,
      "verified" : true
    }
  },
  "id" : 281806800272105473,
  "created_at" : "2012-12-20 17:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheNewDeal",
      "screen_name" : "TheNewDeal",
      "indices" : [ 3, 14 ],
      "id_str" : "78569026",
      "id" : 78569026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281802430583300097",
  "text" : "RT @TheNewDeal: So Let Me Get This Straight... Everyone Having Guns Will Help Society but Everyone Having Healthcare Will Destroy it? #N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NRA",
        "indices" : [ 118, 122 ]
      }, {
        "text" : "p2",
        "indices" : [ 123, 126 ]
      }, {
        "text" : "tcot",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280018538394165248",
    "text" : "So Let Me Get This Straight... Everyone Having Guns Will Help Society but Everyone Having Healthcare Will Destroy it? #NRA #p2 #tcot",
    "id" : 280018538394165248,
    "created_at" : "2012-12-15 18:36:36 +0000",
    "user" : {
      "name" : "TheNewDeal",
      "screen_name" : "TheNewDeal",
      "protected" : false,
      "id_str" : "78569026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769416370\/fdr-smile_normal.jpg",
      "id" : 78569026,
      "verified" : false
    }
  },
  "id" : 281802430583300097,
  "created_at" : "2012-12-20 16:45:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/lmbU1Vdq",
      "expanded_url" : "http:\/\/ebookne.ws\/12Ck8Zr",
      "display_url" : "ebookne.ws\/12Ck8Zr"
    } ]
  },
  "geo" : { },
  "id_str" : "281798181291962368",
  "text" : "RT @thDigitalReader: B&amp;N Adds New In-Store eBook Gifting Options http:\/\/t.co\/lmbU1Vdq by Nate Hoffelder | The Digital Reader",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wordpress.org\/extend\/plugins\/twitter-publisher\/\" rel=\"nofollow\"\u003ETwitPublisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/lmbU1Vdq",
        "expanded_url" : "http:\/\/ebookne.ws\/12Ck8Zr",
        "display_url" : "ebookne.ws\/12Ck8Zr"
      } ]
    },
    "geo" : { },
    "id_str" : "281793809212375040",
    "text" : "B&amp;N Adds New In-Store eBook Gifting Options http:\/\/t.co\/lmbU1Vdq by Nate Hoffelder | The Digital Reader",
    "id" : 281793809212375040,
    "created_at" : "2012-12-20 16:10:54 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 281798181291962368,
  "created_at" : "2012-12-20 16:28:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281793057240776706",
  "geo" : { },
  "id_str" : "281797115313803264",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields originally didnt want built in light but it makes sense since i read in bed, need the light and going thru batteries..lol",
  "id" : 281797115313803264,
  "in_reply_to_status_id" : 281793057240776706,
  "created_at" : "2012-12-20 16:24:02 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281789099050938369",
  "geo" : { },
  "id_str" : "281795812885938176",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields it was in the set up stage (on the screen) so i couldnt really play with it",
  "id" : 281795812885938176,
  "in_reply_to_status_id" : 281789099050938369,
  "created_at" : "2012-12-20 16:18:51 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281789099050938369",
  "geo" : { },
  "id_str" : "281795557092126720",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields yeah.. unfortunately, we have to wait until after xmas when DH gets bonus money.",
  "id" : 281795557092126720,
  "in_reply_to_status_id" : 281789099050938369,
  "created_at" : "2012-12-20 16:17:50 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281784568246333440",
  "geo" : { },
  "id_str" : "281792485901078529",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOL",
  "id" : 281792485901078529,
  "in_reply_to_status_id" : 281784568246333440,
  "created_at" : "2012-12-20 16:05:38 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281792250319618048",
  "text" : "@zen_kitty DD and I LOVE the sugar bisquits! : )",
  "id" : 281792250319618048,
  "created_at" : "2012-12-20 16:04:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281779385344864256",
  "text" : "DD had to do shopping for us. she gets so anxious we wont like our pressies.",
  "id" : 281779385344864256,
  "created_at" : "2012-12-20 15:13:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281779028426379264",
  "text" : "also i checked out the paperwhite and liked it.",
  "id" : 281779028426379264,
  "created_at" : "2012-12-20 15:12:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281778857026150400",
  "text" : "i saw the kobo mini at best buy tues night.. it was adorable!",
  "id" : 281778857026150400,
  "created_at" : "2012-12-20 15:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inspired Kathy",
      "screen_name" : "toobusyreading",
      "indices" : [ 3, 18 ],
      "id_str" : "163219408",
      "id" : 163219408
    }, {
      "name" : "Karly Kirkpatrick",
      "screen_name" : "karlkirkpatrick",
      "indices" : [ 55, 71 ],
      "id_str" : "118883453",
      "id" : 118883453
    }, {
      "name" : "Megg Jensen",
      "screen_name" : "MeggJensen",
      "indices" : [ 78, 89 ],
      "id_str" : "90382720",
      "id" : 90382720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazon",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "yalit",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "free",
      "indices" : [ 107, 112 ]
    }, {
      "text" : "kindlefire",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281778407560331265",
  "text" : "RT @toobusyreading: Win $200 gift cert to #amazon from @karlkirkpatrick &amp; @meggjensen #yalit #giveaway #free #kindlefire http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karly Kirkpatrick",
        "screen_name" : "karlkirkpatrick",
        "indices" : [ 35, 51 ],
        "id_str" : "118883453",
        "id" : 118883453
      }, {
        "name" : "Megg Jensen",
        "screen_name" : "MeggJensen",
        "indices" : [ 58, 69 ],
        "id_str" : "90382720",
        "id" : 90382720
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amazon",
        "indices" : [ 22, 29 ]
      }, {
        "text" : "yalit",
        "indices" : [ 70, 76 ]
      }, {
        "text" : "giveaway",
        "indices" : [ 77, 86 ]
      }, {
        "text" : "free",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "kindlefire",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/SF6TrHci",
        "expanded_url" : "http:\/\/karlykirkpatrick.blogspot.com\/2012\/12\/mid-winters-eve-giveaway-hop-win-amazon.html",
        "display_url" : "karlykirkpatrick.blogspot.com\/2012\/12\/mid-wi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281777967431032832",
    "text" : "Win $200 gift cert to #amazon from @karlkirkpatrick &amp; @meggjensen #yalit #giveaway #free #kindlefire http:\/\/t.co\/SF6TrHci",
    "id" : 281777967431032832,
    "created_at" : "2012-12-20 15:07:57 +0000",
    "user" : {
      "name" : "Inspired Kathy",
      "screen_name" : "toobusyreading",
      "protected" : false,
      "id_str" : "163219408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179328670\/profile_normal.jpg",
      "id" : 163219408,
      "verified" : false
    }
  },
  "id" : 281778407560331265,
  "created_at" : "2012-12-20 15:09:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Eric Christensen",
      "screen_name" : "pianamon",
      "indices" : [ 63, 72 ],
      "id_str" : "28900756",
      "id" : 28900756
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "Peak_to_Peak_Scenic_Byway_CO",
      "indices" : [ 89, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/VoC8Nj7J",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/10987",
      "display_url" : "wildobs.com\/wo\/10987"
    } ]
  },
  "geo" : { },
  "id_str" : "281566534357381120",
  "text" : "RT @wildobs: For the late crowd: Moose http:\/\/t.co\/VoC8Nj7J by @pianamon #EOTD #wildlife #Peak_to_Peak_Scenic_Byway_CO Moose in the Back ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Christensen",
        "screen_name" : "pianamon",
        "indices" : [ 50, 59 ],
        "id_str" : "28900756",
        "id" : 28900756
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 60, 65 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "Peak_to_Peak_Scenic_Byway_CO",
        "indices" : [ 76, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/VoC8Nj7J",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/10987",
        "display_url" : "wildobs.com\/wo\/10987"
      } ]
    },
    "geo" : { },
    "id_str" : "281566020076982272",
    "text" : "For the late crowd: Moose http:\/\/t.co\/VoC8Nj7J by @pianamon #EOTD #wildlife #Peak_to_Peak_Scenic_Byway_CO Moose in the Back Yard",
    "id" : 281566020076982272,
    "created_at" : "2012-12-20 01:05:45 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 281566534357381120,
  "created_at" : "2012-12-20 01:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earthfire Institute",
      "screen_name" : "earthfireinst",
      "indices" : [ 3, 17 ],
      "id_str" : "92345960",
      "id" : 92345960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281562887208714240",
  "text" : "RT @earthfireinst: Elderly arctic wolf Northwind spends the afternoon out of the extreme cold in Earthfire Institute's office to... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/yCu5kKtL",
        "expanded_url" : "http:\/\/fb.me\/1snJydHL9",
        "display_url" : "fb.me\/1snJydHL9"
      } ]
    },
    "geo" : { },
    "id_str" : "281562294075400192",
    "text" : "Elderly arctic wolf Northwind spends the afternoon out of the extreme cold in Earthfire Institute's office to... http:\/\/t.co\/yCu5kKtL",
    "id" : 281562294075400192,
    "created_at" : "2012-12-20 00:50:56 +0000",
    "user" : {
      "name" : "Earthfire Institute",
      "screen_name" : "earthfireinst",
      "protected" : false,
      "id_str" : "92345960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555852354\/E-mail_wolf_eye_normal.jpg",
      "id" : 92345960,
      "verified" : false
    }
  },
  "id" : 281562887208714240,
  "created_at" : "2012-12-20 00:53:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281558816154320897",
  "geo" : { },
  "id_str" : "281559375372488705",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses aww.. he's got you wrapped around his little paw..lol",
  "id" : 281559375372488705,
  "in_reply_to_status_id" : 281558816154320897,
  "created_at" : "2012-12-20 00:39:20 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281553849125326848",
  "geo" : { },
  "id_str" : "281554212339470336",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes lol",
  "id" : 281554212339470336,
  "in_reply_to_status_id" : 281553849125326848,
  "created_at" : "2012-12-20 00:18:49 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281510037413826561",
  "geo" : { },
  "id_str" : "281536623718584320",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon ahh, i see..lol",
  "id" : 281536623718584320,
  "in_reply_to_status_id" : 281510037413826561,
  "created_at" : "2012-12-19 23:08:56 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281513348720381952",
  "text" : "i still dont see many facts... only assumptions.. and then more assumptions based on assumptions.. and blame.",
  "id" : 281513348720381952,
  "created_at" : "2012-12-19 21:36:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281508060848066561",
  "geo" : { },
  "id_str" : "281508667457687552",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon they are 2 different things...",
  "id" : 281508667457687552,
  "in_reply_to_status_id" : 281508060848066561,
  "created_at" : "2012-12-19 21:17:51 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281478906123542528",
  "text" : "RT @TyrusBooks: I'm doing it again - if you or somebody you know needs books for [fill in the holiday of your choice], I'm buying right  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281475623317299200",
    "text" : "I'm doing it again - if you or somebody you know needs books for [fill in the holiday of your choice], I'm buying right now. Let me know.",
    "id" : 281475623317299200,
    "created_at" : "2012-12-19 19:06:32 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 281478906123542528,
  "created_at" : "2012-12-19 19:19:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281463650827517952",
  "text" : "@zen_kitty how the \"F\" did i miss this?! OMG..thank you, dear universe!! big (((hugs))) (and get out of that state ASAP..lol)",
  "id" : 281463650827517952,
  "created_at" : "2012-12-19 18:18:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281462165876121600",
  "text" : "RT @ChrisGroove1: And stop talking mean, too. Words are weapons and we sometimes forget that. It's Christmas Season. Calm down and have  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281461152813305856",
    "text" : "And stop talking mean, too. Words are weapons and we sometimes forget that. It's Christmas Season. Calm down and have an eggnog.",
    "id" : 281461152813305856,
    "created_at" : "2012-12-19 18:09:02 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 281462165876121600,
  "created_at" : "2012-12-19 18:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Geoff Ninecow",
      "screen_name" : "geoff9cow",
      "indices" : [ 16, 26 ],
      "id_str" : "21717987",
      "id" : 21717987
    }, {
      "name" : "snipy",
      "screen_name" : "snipy",
      "indices" : [ 124, 130 ],
      "id_str" : "16594160",
      "id" : 16594160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/fj1oy0RT",
      "expanded_url" : "http:\/\/bit.ly\/T7r7W3",
      "display_url" : "bit.ly\/T7r7W3"
    } ]
  },
  "geo" : { },
  "id_str" : "281459684739780610",
  "text" : "RT @SangyeH: RT @geoff9cow: Missouri School District Busy Being Awesome at Being Horrible to Poor Kids http:\/\/t.co\/fj1oy0RT @snipy @Wonk ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoff Ninecow",
        "screen_name" : "geoff9cow",
        "indices" : [ 3, 13 ],
        "id_str" : "21717987",
        "id" : 21717987
      }, {
        "name" : "snipy",
        "screen_name" : "snipy",
        "indices" : [ 111, 117 ],
        "id_str" : "16594160",
        "id" : 16594160
      }, {
        "name" : "Wonkette",
        "screen_name" : "Wonkette",
        "indices" : [ 118, 127 ],
        "id_str" : "13215382",
        "id" : 13215382
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/fj1oy0RT",
        "expanded_url" : "http:\/\/bit.ly\/T7r7W3",
        "display_url" : "bit.ly\/T7r7W3"
      } ]
    },
    "geo" : { },
    "id_str" : "281458224761286657",
    "text" : "RT @geoff9cow: Missouri School District Busy Being Awesome at Being Horrible to Poor Kids http:\/\/t.co\/fj1oy0RT @snipy @Wonkette #tcot | OMG",
    "id" : 281458224761286657,
    "created_at" : "2012-12-19 17:57:24 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 281459684739780610,
  "created_at" : "2012-12-19 18:03:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/IphjQSnb",
      "expanded_url" : "http:\/\/www.theglobalconversation.com\/blog\/?p=3235#.UNH_KFLi4no.twitter",
      "display_url" : "theglobalconversation.com\/blog\/?p=3235#.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281457533258960896",
  "text" : "DO ALL SOULS ACT IN SERVICE TO THE WHOLE? http:\/\/t.co\/IphjQSnb",
  "id" : 281457533258960896,
  "created_at" : "2012-12-19 17:54:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281424522710765570",
  "text" : "RT @twitter: Your Twitter archive is being gradually rolled out to users. Learn more about how to revisit your old Tweets here: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/ONhrS4ix",
        "expanded_url" : "https:\/\/blog.twitter.com\/2012\/12\/your-twitter-archive.html",
        "display_url" : "blog.twitter.com\/2012\/12\/your-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281420991803039744",
    "text" : "Your Twitter archive is being gradually rolled out to users. Learn more about how to revisit your old Tweets here: http:\/\/t.co\/ONhrS4ix",
    "id" : 281420991803039744,
    "created_at" : "2012-12-19 15:29:27 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767879603977191425\/29zfZY6I_normal.jpg",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 281424522710765570,
  "created_at" : "2012-12-19 15:43:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281419514443345921",
  "text" : "sitting here waiting for the knock on the door. need a valium!",
  "id" : 281419514443345921,
  "created_at" : "2012-12-19 15:23:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/lajyNH6b",
      "expanded_url" : "http:\/\/wp.me\/p1xWjA-Av",
      "display_url" : "wp.me\/p1xWjA-Av"
    } ]
  },
  "geo" : { },
  "id_str" : "281404857972314112",
  "text" : "RT @DwayneReaves: Conundrum http:\/\/t.co\/lajyNH6b via @FrancesScottABC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 30 ],
        "url" : "http:\/\/t.co\/lajyNH6b",
        "expanded_url" : "http:\/\/wp.me\/p1xWjA-Av",
        "display_url" : "wp.me\/p1xWjA-Av"
      } ]
    },
    "geo" : { },
    "id_str" : "281397188851023872",
    "text" : "Conundrum http:\/\/t.co\/lajyNH6b via @FrancesScottABC",
    "id" : 281397188851023872,
    "created_at" : "2012-12-19 13:54:52 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 281404857972314112,
  "created_at" : "2012-12-19 14:25:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281212018747404288",
  "text" : "@iEyeAyes well, yeah..lol.. is universe extra stressing we are all one with that? lol",
  "id" : 281212018747404288,
  "created_at" : "2012-12-19 01:39:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281208678114287616",
  "geo" : { },
  "id_str" : "281210253402578945",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater this pleases me greatly. icky icky man.",
  "id" : 281210253402578945,
  "in_reply_to_status_id" : 281208678114287616,
  "created_at" : "2012-12-19 01:32:03 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281209705118957568",
  "text" : "universe sent me message of 111 today... translate, anyone?",
  "id" : 281209705118957568,
  "created_at" : "2012-12-19 01:29:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281121136593469440",
  "geo" : { },
  "id_str" : "281207670596329472",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awww... : )",
  "id" : 281207670596329472,
  "in_reply_to_status_id" : 281121136593469440,
  "created_at" : "2012-12-19 01:21:47 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 0, 15 ],
      "id_str" : "18538833",
      "id" : 18538833
    }, {
      "name" : "Heathen Heather",
      "screen_name" : "HeatherHastie",
      "indices" : [ 40, 54 ],
      "id_str" : "872343469",
      "id" : 872343469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281133321910616064",
  "geo" : { },
  "id_str" : "281137653552922625",
  "in_reply_to_user_id" : 18538833,
  "text" : "@ZeitgeistGhost yeah, what you said, ZG @HeatherHastie",
  "id" : 281137653552922625,
  "in_reply_to_status_id" : 281133321910616064,
  "created_at" : "2012-12-18 20:43:34 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heathen Heather",
      "screen_name" : "HeatherHastie",
      "indices" : [ 0, 14 ],
      "id_str" : "872343469",
      "id" : 872343469
    }, {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 69, 84 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281132805243670528",
  "geo" : { },
  "id_str" : "281137462628192256",
  "in_reply_to_user_id" : 872343469,
  "text" : "@HeatherHastie anger that has turned to rage.. a hatred of oneself.. @ZeitgeistGhost",
  "id" : 281137462628192256,
  "in_reply_to_status_id" : 281132805243670528,
  "created_at" : "2012-12-18 20:42:49 +0000",
  "in_reply_to_screen_name" : "HeatherHastie",
  "in_reply_to_user_id_str" : "872343469",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/MrU8STIG",
      "expanded_url" : "http:\/\/www.soulseeds.com\/fb-inspiration\/2012\/12\/seed-of-beautiful-imperfection\/",
      "display_url" : "soulseeds.com\/fb-inspiration\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281137134960795648",
  "text" : "RT @Soulseedzforall: \u201CStop trying to \"fix\" yourself; you're NOT broken!\u201D ~ Steve Maraboli http:\/\/t.co\/MrU8STIG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/MrU8STIG",
        "expanded_url" : "http:\/\/www.soulseeds.com\/fb-inspiration\/2012\/12\/seed-of-beautiful-imperfection\/",
        "display_url" : "soulseeds.com\/fb-inspiration\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281133385034891264",
    "text" : "\u201CStop trying to \"fix\" yourself; you're NOT broken!\u201D ~ Steve Maraboli http:\/\/t.co\/MrU8STIG",
    "id" : 281133385034891264,
    "created_at" : "2012-12-18 20:26:36 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 281137134960795648,
  "created_at" : "2012-12-18 20:41:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenda Kosky Deskin",
      "screen_name" : "AutismBeacon",
      "indices" : [ 3, 16 ],
      "id_str" : "339199404",
      "id" : 339199404
    }, {
      "name" : "John Elder Robison",
      "screen_name" : "johnrobison",
      "indices" : [ 18, 30 ],
      "id_str" : "16846327",
      "id" : 16846327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Autism",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281137098797490177",
  "text" : "RT @AutismBeacon: @johnrobison, who himself is on the spectrum, speaks out about Asperger\u2019s  #Autism &amp; Mass Murder. Read and SHARE.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Elder Robison",
        "screen_name" : "johnrobison",
        "indices" : [ 0, 12 ],
        "id_str" : "16846327",
        "id" : 16846327
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Autism",
        "indices" : [ 75, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/XgFZxEU9",
        "expanded_url" : "http:\/\/bit.ly\/ZK6PqN",
        "display_url" : "bit.ly\/ZK6PqN"
      } ]
    },
    "geo" : { },
    "id_str" : "281133178318630912",
    "in_reply_to_user_id" : 16846327,
    "text" : "@johnrobison, who himself is on the spectrum, speaks out about Asperger\u2019s  #Autism &amp; Mass Murder. Read and SHARE. http:\/\/t.co\/XgFZxEU9",
    "id" : 281133178318630912,
    "created_at" : "2012-12-18 20:25:47 +0000",
    "in_reply_to_screen_name" : "johnrobison",
    "in_reply_to_user_id_str" : "16846327",
    "user" : {
      "name" : "Brenda Kosky Deskin",
      "screen_name" : "AutismBeacon",
      "protected" : false,
      "id_str" : "339199404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2097490992\/SquareLogo_on_white_back_normal.jpg",
      "id" : 339199404,
      "verified" : false
    }
  },
  "id" : 281137098797490177,
  "created_at" : "2012-12-18 20:41:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281129496600526849",
  "text" : "RT @bookwiseblog: Win $100 Amazon Gift Card from Lendle.me: I am a fan of book lending sites like Lendle.me. \u00A0I reviewed Lendle.me... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/hieTKdsu",
        "expanded_url" : "http:\/\/bit.ly\/UA72Hf",
        "display_url" : "bit.ly\/UA72Hf"
      } ]
    },
    "geo" : { },
    "id_str" : "281129302475542528",
    "text" : "Win $100 Amazon Gift Card from Lendle.me: I am a fan of book lending sites like Lendle.me. \u00A0I reviewed Lendle.me... http:\/\/t.co\/hieTKdsu",
    "id" : 281129302475542528,
    "created_at" : "2012-12-18 20:10:23 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 281129496600526849,
  "created_at" : "2012-12-18 20:11:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281128227861307393",
  "text" : "i often felt i was evil.. imperfect. i hated being me.",
  "id" : 281128227861307393,
  "created_at" : "2012-12-18 20:06:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281127597587460096",
  "text" : "as a kid, teen, i had extremely low self esteem for reasons unknown. occasionally i hated my parents. often wished to die.",
  "id" : 281127597587460096,
  "created_at" : "2012-12-18 20:03:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281126885746954240",
  "text" : "i could have been a very different person. i could have EASILY been a drug addict had i gotten in w the right crowd.",
  "id" : 281126885746954240,
  "created_at" : "2012-12-18 20:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281125780656910336",
  "text" : "people are making many assumptions. there are not many facts out there yet. we don't know much, really.",
  "id" : 281125780656910336,
  "created_at" : "2012-12-18 19:56:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Lindsay",
      "screen_name" : "ColleenLindsay",
      "indices" : [ 3, 18 ],
      "id_str" : "14049120",
      "id" : 14049120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281041650074136577",
  "text" : "RT @ColleenLindsay: Please STOP equating autism-spectrum disorders with violence and\/or mental retardation. It's inaccurate &amp; danger ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281037569028935683",
    "text" : "Please STOP equating autism-spectrum disorders with violence and\/or mental retardation. It's inaccurate &amp; dangerous to perpetuate this idea.",
    "id" : 281037569028935683,
    "created_at" : "2012-12-18 14:05:52 +0000",
    "user" : {
      "name" : "Colleen Lindsay",
      "screen_name" : "ColleenLindsay",
      "protected" : false,
      "id_str" : "14049120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2061184707\/colleeninthevillage_normal.jpg",
      "id" : 14049120,
      "verified" : false
    }
  },
  "id" : 281041650074136577,
  "created_at" : "2012-12-18 14:22:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280867255422701569",
  "geo" : { },
  "id_str" : "281041039035346944",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell oh no... poor babe.",
  "id" : 281041039035346944,
  "in_reply_to_status_id" : 280867255422701569,
  "created_at" : "2012-12-18 14:19:39 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "donkeys",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/WiycmKI1",
      "expanded_url" : "http:\/\/youtu.be\/O4vB_4liXd0",
      "display_url" : "youtu.be\/O4vB_4liXd0"
    } ]
  },
  "geo" : { },
  "id_str" : "281037267236188160",
  "text" : "Bubba Earl's Christmas Party 2012: http:\/\/t.co\/WiycmKI1 includes very cute #donkeys",
  "id" : 281037267236188160,
  "created_at" : "2012-12-18 14:04:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Frank\u2122\u00A9",
      "screen_name" : "JustCallMeFrank",
      "indices" : [ 3, 19 ],
      "id_str" : "202192724",
      "id" : 202192724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280859830716088320",
  "text" : "RT @JustCallMeFrank: Let's not make demons of the \"quiet\", \"geeky\", those who don't fit into societies parameters.\nLove, accept, one ano ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280855987173326849",
    "text" : "Let's not make demons of the \"quiet\", \"geeky\", those who don't fit into societies parameters.\nLove, accept, one another.\n\nAs gross as it is.",
    "id" : 280855987173326849,
    "created_at" : "2012-12-18 02:04:20 +0000",
    "user" : {
      "name" : "Just Call Me Frank\u2122\u00A9",
      "screen_name" : "JustCallMeFrank",
      "protected" : false,
      "id_str" : "202192724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754446532192022529\/Xrj101Ob_normal.jpg",
      "id" : 202192724,
      "verified" : false
    }
  },
  "id" : 280859830716088320,
  "created_at" : "2012-12-18 02:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "indices" : [ 3, 14 ],
      "id_str" : "21497211",
      "id" : 21497211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280856839065841664",
  "text" : "RT @jedwards06: I am an evangelical Christian. I'm also gay. And a socialist. Time to let go of your assumptions",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280856115036684288",
    "text" : "I am an evangelical Christian. I'm also gay. And a socialist. Time to let go of your assumptions",
    "id" : 280856115036684288,
    "created_at" : "2012-12-18 02:04:50 +0000",
    "user" : {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "protected" : true,
      "id_str" : "21497211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000439787062\/5787c041baa171cae2de77bcf3d3a28e_normal.png",
      "id" : 21497211,
      "verified" : false
    }
  },
  "id" : 280856839065841664,
  "created_at" : "2012-12-18 02:07:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280843960925179904",
  "text" : "RT @brandonrofl: Peace doesn't seem possible when the mind is so closed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280842689568706561",
    "text" : "Peace doesn't seem possible when the mind is so closed",
    "id" : 280842689568706561,
    "created_at" : "2012-12-18 01:11:29 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 280843960925179904,
  "created_at" : "2012-12-18 01:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 110, 119 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 120, 128 ]
    }, {
      "text" : "children",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Les7LY4T",
      "expanded_url" : "http:\/\/mashable.com\/2012\/12\/17\/jetblue-vdog-letter\/",
      "display_url" : "mashable.com\/2012\/12\/17\/jet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280843312489967616",
  "text" : "RT @ReverendSue: JetBlue Delivers Cousin's Goodbye Letter to Newtown Child's Funeral http:\/\/t.co\/Les7LY4T via @mashable #Newtown #children",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 93, 102 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Newtown",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "children",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/Les7LY4T",
        "expanded_url" : "http:\/\/mashable.com\/2012\/12\/17\/jetblue-vdog-letter\/",
        "display_url" : "mashable.com\/2012\/12\/17\/jet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280839774024110080",
    "text" : "JetBlue Delivers Cousin's Goodbye Letter to Newtown Child's Funeral http:\/\/t.co\/Les7LY4T via @mashable #Newtown #children",
    "id" : 280839774024110080,
    "created_at" : "2012-12-18 00:59:54 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 280843312489967616,
  "created_at" : "2012-12-18 01:13:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280838777721720832",
  "text" : "yeah.. like pointing fingers and condemning to hell makes it all better... NOT!!!",
  "id" : 280838777721720832,
  "created_at" : "2012-12-18 00:55:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280831201172918272",
  "geo" : { },
  "id_str" : "280836053420630016",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny actually not a matter of where cuz we're already there!",
  "id" : 280836053420630016,
  "in_reply_to_status_id" : 280831201172918272,
  "created_at" : "2012-12-18 00:45:07 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280802310500802561",
  "geo" : { },
  "id_str" : "280808010505388032",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind free drugs for everyone!",
  "id" : 280808010505388032,
  "in_reply_to_status_id" : 280802310500802561,
  "created_at" : "2012-12-17 22:53:41 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280740970780311554",
  "text" : "RT @TyrusBooks: Especially looking to hook up folks who might have a thin collection of presents this year AND kids who are learning to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280446595697344512",
    "text" : "Especially looking to hook up folks who might have a thin collection of presents this year AND kids who are learning to love reading.",
    "id" : 280446595697344512,
    "created_at" : "2012-12-16 22:57:33 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 280740970780311554,
  "created_at" : "2012-12-17 18:27:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280740072880496640",
  "text" : "RT @bookwiseblog: If you read Bookwi.se, would you mind taking a minute to fill out the reader survey? (Only 8 questions) http:\/\/t.co\/vF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/vFYx0DTk",
        "expanded_url" : "http:\/\/bookwi.se\/bookwi-se-reader-survey\/",
        "display_url" : "bookwi.se\/bookwi-se-read\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280738113419100160",
    "text" : "If you read Bookwi.se, would you mind taking a minute to fill out the reader survey? (Only 8 questions) http:\/\/t.co\/vFYx0DTk",
    "id" : 280738113419100160,
    "created_at" : "2012-12-17 18:15:56 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 280740072880496640,
  "created_at" : "2012-12-17 18:23:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 3, 10 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "women",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/0myxK8jr",
      "expanded_url" : "http:\/\/via.me\/-7wulkn8",
      "display_url" : "via.me\/-7wulkn8"
    } ]
  },
  "geo" : { },
  "id_str" : "280739862049615875",
  "text" : "RT @SsmDad: One can only imagine! #women \n:-) http:\/\/t.co\/0myxK8jr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "women",
        "indices" : [ 22, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/0myxK8jr",
        "expanded_url" : "http:\/\/via.me\/-7wulkn8",
        "display_url" : "via.me\/-7wulkn8"
      } ]
    },
    "geo" : { },
    "id_str" : "280738168049905664",
    "text" : "One can only imagine! #women \n:-) http:\/\/t.co\/0myxK8jr",
    "id" : 280738168049905664,
    "created_at" : "2012-12-17 18:16:09 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "protected" : false,
      "id_str" : "122393631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649760376880525312\/faJeQ4K3_normal.jpg",
      "id" : 122393631,
      "verified" : false
    }
  },
  "id" : 280739862049615875,
  "created_at" : "2012-12-17 18:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280726380608618496",
  "text" : "i have a webpage that uses short code to show links by category. \"page updated\" plugins dont work. any ideas?",
  "id" : 280726380608618496,
  "created_at" : "2012-12-17 17:29:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "indices" : [ 3, 13 ],
      "id_str" : "21636840",
      "id" : 21636840
    }, {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "indices" : [ 38, 48 ],
      "id_str" : "21636840",
      "id" : 21636840
    }, {
      "name" : "App Store",
      "screen_name" : "AppStore",
      "indices" : [ 61, 70 ],
      "id_str" : "74594552",
      "id" : 74594552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280720824040837120",
  "text" : "RT @Halfbrick: You heard right! Every @Halfbrick game on the @AppStore is FREE for 24 hours! RT now and spread the word! http:\/\/t.co\/wJx ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Halfbrick",
        "screen_name" : "Halfbrick",
        "indices" : [ 23, 33 ],
        "id_str" : "21636840",
        "id" : 21636840
      }, {
        "name" : "App Store",
        "screen_name" : "AppStore",
        "indices" : [ 46, 55 ],
        "id_str" : "74594552",
        "id" : 74594552
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/wJx7HVoc",
        "expanded_url" : "http:\/\/bit.ly\/Tq64xZ",
        "display_url" : "bit.ly\/Tq64xZ"
      } ]
    },
    "geo" : { },
    "id_str" : "280720326348926976",
    "text" : "You heard right! Every @Halfbrick game on the @AppStore is FREE for 24 hours! RT now and spread the word! http:\/\/t.co\/wJx7HVoc",
    "id" : 280720326348926976,
    "created_at" : "2012-12-17 17:05:15 +0000",
    "user" : {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "protected" : false,
      "id_str" : "21636840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780664592758247424\/SkdeHP5x_normal.jpg",
      "id" : 21636840,
      "verified" : true
    }
  },
  "id" : 280720824040837120,
  "created_at" : "2012-12-17 17:07:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280719758679236609",
  "text" : "RT @luminanceriver: We all need each other and everyone has piece of the puzzle.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280717676693815297",
    "text" : "We all need each other and everyone has piece of the puzzle.",
    "id" : 280717676693815297,
    "created_at" : "2012-12-17 16:54:44 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 280719758679236609,
  "created_at" : "2012-12-17 17:03:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280713612471971841",
  "text" : "if we dont make the right choice now, the aliens will zap us and we gotta go thru the whole thing all over again...",
  "id" : 280713612471971841,
  "created_at" : "2012-12-17 16:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280707786457878528",
  "text" : "@1stCitizenKane LOL",
  "id" : 280707786457878528,
  "created_at" : "2012-12-17 16:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280702770502324225",
  "geo" : { },
  "id_str" : "280706394339020800",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny perfect murder weapon for DH.. he's allergic..lol",
  "id" : 280706394339020800,
  "in_reply_to_status_id" : 280702770502324225,
  "created_at" : "2012-12-17 16:09:54 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "North Point Online",
      "screen_name" : "NPOnline",
      "indices" : [ 87, 96 ],
      "id_str" : "47389875",
      "id" : 47389875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280705487266267136",
  "text" : "RT @adamrshields: Today the basic Roku box is on sale for $39. Good for Netflix, Hulu, @nponline, Amazon Instant video &amp; more. Love  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "North Point Online",
        "screen_name" : "NPOnline",
        "indices" : [ 69, 78 ],
        "id_str" : "47389875",
        "id" : 47389875
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/LKxxhThf",
        "expanded_url" : "http:\/\/www.amazon.com\/gp\/goldbox?ie=UTF8&camp=213733&creative=393193&linkCode=shr&tag=mrshiecom-20&ef_=pe_36900_27262360",
        "display_url" : "amazon.com\/gp\/goldbox?ie=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280703634088554497",
    "text" : "Today the basic Roku box is on sale for $39. Good for Netflix, Hulu, @nponline, Amazon Instant video &amp; more. Love mine http:\/\/t.co\/LKxxhThf",
    "id" : 280703634088554497,
    "created_at" : "2012-12-17 15:58:56 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 280705487266267136,
  "created_at" : "2012-12-17 16:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enigma4ever",
      "screen_name" : "watergatesummer",
      "indices" : [ 3, 19 ],
      "id_str" : "48112717",
      "id" : 48112717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/TcMKt4Qm",
      "expanded_url" : "http:\/\/www.chicagotribune.com\/news\/local\/breaking\/chi-local-comfort-dogs-taken-to-connecticut-after-school-massacre-20121216,0,7533873.story",
      "display_url" : "chicagotribune.com\/news\/local\/bre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280475862317555713",
  "text" : "RT @watergatesummer: Local comfort dogs taken to Connecticut after school massacre http:\/\/t.co\/TcMKt4Qm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/TcMKt4Qm",
        "expanded_url" : "http:\/\/www.chicagotribune.com\/news\/local\/breaking\/chi-local-comfort-dogs-taken-to-connecticut-after-school-massacre-20121216,0,7533873.story",
        "display_url" : "chicagotribune.com\/news\/local\/bre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280473448034205696",
    "text" : "Local comfort dogs taken to Connecticut after school massacre http:\/\/t.co\/TcMKt4Qm",
    "id" : 280473448034205696,
    "created_at" : "2012-12-17 00:44:15 +0000",
    "user" : {
      "name" : "enigma4ever",
      "screen_name" : "watergatesummer",
      "protected" : false,
      "id_str" : "48112717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1778779395\/18502599839_3M4bj_normal.jpg",
      "id" : 48112717,
      "verified" : false
    }
  },
  "id" : 280475862317555713,
  "created_at" : "2012-12-17 00:53:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebirds",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "nature",
      "indices" : [ 76, 83 ]
    }, {
      "text" : "photo",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/rxJyPrys",
      "expanded_url" : "http:\/\/ow.ly\/fi7bM",
      "display_url" : "ow.ly\/fi7bM"
    } ]
  },
  "geo" : { },
  "id_str" : "280473897357434883",
  "text" : "RT @KerriFar: Three spotted at once! ~ #Bluebirds ~ http:\/\/t.co\/rxJyPrys  ~ #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebirds",
        "indices" : [ 25, 35 ]
      }, {
        "text" : "nature",
        "indices" : [ 62, 69 ]
      }, {
        "text" : "photo",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/rxJyPrys",
        "expanded_url" : "http:\/\/ow.ly\/fi7bM",
        "display_url" : "ow.ly\/fi7bM"
      } ]
    },
    "geo" : { },
    "id_str" : "280473712657051650",
    "text" : "Three spotted at once! ~ #Bluebirds ~ http:\/\/t.co\/rxJyPrys  ~ #nature #photo",
    "id" : 280473712657051650,
    "created_at" : "2012-12-17 00:45:18 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 280473897357434883,
  "created_at" : "2012-12-17 00:46:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "Michelle9647",
      "indices" : [ 3, 16 ],
      "id_str" : "75630518",
      "id" : 75630518
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 21, 34 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280472724810379264",
  "text" : "RT @Michelle9647: RT @YourAnonNews: \"'Did we just kill a kid?' he asked. 'Yeah, I guess that was a kid.'\" The life of drone operators |  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 3, 16 ],
        "id_str" : "279390084",
        "id" : 279390084
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/XcDehQ6D",
        "expanded_url" : "http:\/\/ow.ly\/g92m0",
        "display_url" : "ow.ly\/g92m0"
      } ]
    },
    "geo" : { },
    "id_str" : "280468136824811524",
    "text" : "RT @YourAnonNews: \"'Did we just kill a kid?' he asked. 'Yeah, I guess that was a kid.'\" The life of drone operators | http:\/\/t.co\/XcDehQ6D\"",
    "id" : 280468136824811524,
    "created_at" : "2012-12-17 00:23:09 +0000",
    "user" : {
      "name" : "Michelle",
      "screen_name" : "Michelle9647",
      "protected" : false,
      "id_str" : "75630518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519174269511954432\/CnsXIjCo_normal.jpeg",
      "id" : 75630518,
      "verified" : false
    }
  },
  "id" : 280472724810379264,
  "created_at" : "2012-12-17 00:41:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280358131303854080",
  "text" : "i hate itunes!",
  "id" : 280358131303854080,
  "created_at" : "2012-12-16 17:06:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280348613824086017",
  "text" : "we are all in this together.. every single one of us...",
  "id" : 280348613824086017,
  "created_at" : "2012-12-16 16:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280337108856614913",
  "geo" : { },
  "id_str" : "280348121517670400",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 oh my..lol",
  "id" : 280348121517670400,
  "in_reply_to_status_id" : 280337108856614913,
  "created_at" : "2012-12-16 16:26:15 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280337223956697088",
  "geo" : { },
  "id_str" : "280348006732161026",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl beautiful : )",
  "id" : 280348006732161026,
  "in_reply_to_status_id" : 280337223956697088,
  "created_at" : "2012-12-16 16:25:48 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280337783397175296",
  "geo" : { },
  "id_str" : "280347758437728256",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona kindle (readers not fires) use e ink, no backlight.. easier on eyes.",
  "id" : 280347758437728256,
  "in_reply_to_status_id" : 280337783397175296,
  "created_at" : "2012-12-16 16:24:48 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J. Leonard",
      "screen_name" : "drdavidjleonard",
      "indices" : [ 3, 19 ],
      "id_str" : "352779756",
      "id" : 352779756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Tuq7LG15",
      "expanded_url" : "http:\/\/gawker.com\/5968818?utm_campaign=socialflow_gawker_facebook&utm_source=gawker_facebook&utm_medium=socialflow&post=55295186",
      "display_url" : "gawker.com\/5968818?utm_ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280344587690721280",
  "text" : "RT @drdavidjleonard: I Am Adam Lanza's Mother http:\/\/t.co\/Tuq7LG15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/Tuq7LG15",
        "expanded_url" : "http:\/\/gawker.com\/5968818?utm_campaign=socialflow_gawker_facebook&utm_source=gawker_facebook&utm_medium=socialflow&post=55295186",
        "display_url" : "gawker.com\/5968818?utm_ca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280341441031573504",
    "text" : "I Am Adam Lanza's Mother http:\/\/t.co\/Tuq7LG15",
    "id" : 280341441031573504,
    "created_at" : "2012-12-16 15:59:42 +0000",
    "user" : {
      "name" : "David J. Leonard",
      "screen_name" : "drdavidjleonard",
      "protected" : false,
      "id_str" : "352779756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771773910446518272\/0MxNlPQB_normal.jpg",
      "id" : 352779756,
      "verified" : false
    }
  },
  "id" : 280344587690721280,
  "created_at" : "2012-12-16 16:12:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/JpHNELSv",
      "expanded_url" : "http:\/\/amzn.to\/S8kcis",
      "display_url" : "amzn.to\/S8kcis"
    } ]
  },
  "geo" : { },
  "id_str" : "280151167521157121",
  "text" : "finished The Twelve Pathways to Christmas (The Twelve Joys of Christmas) by Andy Wood http:\/\/t.co\/JpHNELSv",
  "id" : 280151167521157121,
  "created_at" : "2012-12-16 03:23:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/ttjFeaK5",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/MgR",
      "display_url" : "omgf.ac\/ts\/MgR"
    } ]
  },
  "geo" : { },
  "id_str" : "280125322605776896",
  "text" : "RT @OMGFacts: A Farmer Seceded from Australia and Created his OWN COUNTRY where he is King! Learn more --&gt; http:\/\/t.co\/ttjFeaK5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/ttjFeaK5",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/MgR",
        "display_url" : "omgf.ac\/ts\/MgR"
      } ]
    },
    "geo" : { },
    "id_str" : "280122654336380928",
    "text" : "A Farmer Seceded from Australia and Created his OWN COUNTRY where he is King! Learn more --&gt; http:\/\/t.co\/ttjFeaK5",
    "id" : 280122654336380928,
    "created_at" : "2012-12-16 01:30:19 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 280125322605776896,
  "created_at" : "2012-12-16 01:40:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 69, 82 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280109834685267968",
  "text" : "finished reading The Traveler's Gift by Andy Andrews that I got from @bookwiseblog",
  "id" : 280109834685267968,
  "created_at" : "2012-12-16 00:39:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iFans.com",
      "screen_name" : "touchfans",
      "indices" : [ 3, 13 ],
      "id_str" : "18342200",
      "id" : 18342200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280087089494773761",
  "text" : "RT @touchfans: Enter to Win a $20 iTunes Gift Card to Celebrate DoodleBook\u2019s Launch: DoodleBook is the latest social drawing ga... http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/bQaL5qos",
        "expanded_url" : "http:\/\/bit.ly\/Zw4C21",
        "display_url" : "bit.ly\/Zw4C21"
      } ]
    },
    "geo" : { },
    "id_str" : "280081490266689536",
    "text" : "Enter to Win a $20 iTunes Gift Card to Celebrate DoodleBook\u2019s Launch: DoodleBook is the latest social drawing ga... http:\/\/t.co\/bQaL5qos",
    "id" : 280081490266689536,
    "created_at" : "2012-12-15 22:46:45 +0000",
    "user" : {
      "name" : "iFans.com",
      "screen_name" : "touchfans",
      "protected" : false,
      "id_str" : "18342200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2983864446\/9459b3ea5de259a4b11b82d1b599547c_normal.png",
      "id" : 18342200,
      "verified" : false
    }
  },
  "id" : 280087089494773761,
  "created_at" : "2012-12-15 23:09:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "indices" : [ 3, 11 ],
      "id_str" : "20479813",
      "id" : 20479813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/EVzN1ori",
      "expanded_url" : "http:\/\/mmflint.me\/UZUoE8",
      "display_url" : "mmflint.me\/UZUoE8"
    } ]
  },
  "geo" : { },
  "id_str" : "280074582998786048",
  "text" : "RT @MMFlint: Pakistani children hold candlelight vigil for CT schoolkids: http:\/\/t.co\/EVzN1ori Ouch.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/EVzN1ori",
        "expanded_url" : "http:\/\/mmflint.me\/UZUoE8",
        "display_url" : "mmflint.me\/UZUoE8"
      } ]
    },
    "geo" : { },
    "id_str" : "280072909995782144",
    "text" : "Pakistani children hold candlelight vigil for CT schoolkids: http:\/\/t.co\/EVzN1ori Ouch.",
    "id" : 280072909995782144,
    "created_at" : "2012-12-15 22:12:39 +0000",
    "user" : {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "protected" : false,
      "id_str" : "20479813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440557378027520000\/DTvD2bbr_normal.jpeg",
      "id" : 20479813,
      "verified" : true
    }
  },
  "id" : 280074582998786048,
  "created_at" : "2012-12-15 22:19:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Fake CNN",
      "screen_name" : "TheFakeCNN",
      "indices" : [ 3, 14 ],
      "id_str" : "276843589",
      "id" : 276843589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279977811803009024",
  "text" : "RT @TheFakeCNN: Breaking: If you turn on the news, you're going to get really fucking depressed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279976057824763904",
    "text" : "Breaking: If you turn on the news, you're going to get really fucking depressed.",
    "id" : 279976057824763904,
    "created_at" : "2012-12-15 15:47:48 +0000",
    "user" : {
      "name" : "The Fake CNN",
      "screen_name" : "TheFakeCNN",
      "protected" : false,
      "id_str" : "276843589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533029733\/fake_cnnfinal_normal.jpeg",
      "id" : 276843589,
      "verified" : false
    }
  },
  "id" : 279977811803009024,
  "created_at" : "2012-12-15 15:54:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicronon",
      "screen_name" : "Nicronon",
      "indices" : [ 3, 12 ],
      "id_str" : "292044729",
      "id" : 292044729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279977739543511040",
  "text" : "RT @Nicronon: According to Mike Huckabee, God is a terrorist who targets children when public schools refrain from worshiping him. Prett ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279777592029114368",
    "text" : "According to Mike Huckabee, God is a terrorist who targets children when public schools refrain from worshiping him. Pretty sick.",
    "id" : 279777592029114368,
    "created_at" : "2012-12-15 02:39:10 +0000",
    "user" : {
      "name" : "Dorian",
      "screen_name" : "DorianStaten",
      "protected" : false,
      "id_str" : "267454085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760934461051580416\/u1xIvOQl_normal.jpg",
      "id" : 267454085,
      "verified" : false
    }
  },
  "id" : 279977739543511040,
  "created_at" : "2012-12-15 15:54:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicki",
      "screen_name" : "NurseAgita",
      "indices" : [ 3, 14 ],
      "id_str" : "104824264",
      "id" : 104824264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedicareForAll",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279975127314202625",
  "text" : "RT @NurseAgita: We need 810 sigs\/day until 1\/13\/13 to reach 25K at which point PBO responds. Pls push this petition #MedicareForAll http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedicareForAll",
        "indices" : [ 100, 115 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/6HYheFXl",
        "expanded_url" : "http:\/\/tinyurl.com\/b272v26",
        "display_url" : "tinyurl.com\/b272v26"
      } ]
    },
    "geo" : { },
    "id_str" : "279819710034493440",
    "text" : "We need 810 sigs\/day until 1\/13\/13 to reach 25K at which point PBO responds. Pls push this petition #MedicareForAll http:\/\/t.co\/6HYheFXl #p2",
    "id" : 279819710034493440,
    "created_at" : "2012-12-15 05:26:32 +0000",
    "user" : {
      "name" : "Vicki",
      "screen_name" : "NurseAgita",
      "protected" : false,
      "id_str" : "104824264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2862648052\/331687c1095e351ed89d426829f66631_normal.png",
      "id" : 104824264,
      "verified" : false
    }
  },
  "id" : 279975127314202625,
  "created_at" : "2012-12-15 15:44:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279774707677544448",
  "text" : "RT @ificouldtellu: Life is an enormous cycle of improvements where we progress at our own rate to reach the light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279774337261785088",
    "text" : "Life is an enormous cycle of improvements where we progress at our own rate to reach the light.",
    "id" : 279774337261785088,
    "created_at" : "2012-12-15 02:26:14 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 279774707677544448,
  "created_at" : "2012-12-15 02:27:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Miles\uD83D\uDCCE",
      "screen_name" : "CSheehanMiles",
      "indices" : [ 3, 17 ],
      "id_str" : "10016742",
      "id" : 10016742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279769707664535553",
  "text" : "RT @CSheehanMiles: Ok. There\u2019s going to be a lot of arguments about gun control, this and that. I\u2019m not getting into that. But I... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/IFKCBEnS",
        "expanded_url" : "http:\/\/fb.me\/1PAqKm4Sd",
        "display_url" : "fb.me\/1PAqKm4Sd"
      } ]
    },
    "geo" : { },
    "id_str" : "279765690083319808",
    "text" : "Ok. There\u2019s going to be a lot of arguments about gun control, this and that. I\u2019m not getting into that. But I... http:\/\/t.co\/IFKCBEnS",
    "id" : 279765690083319808,
    "created_at" : "2012-12-15 01:51:52 +0000",
    "user" : {
      "name" : "Charles Miles\uD83D\uDCCE",
      "screen_name" : "CSheehanMiles",
      "protected" : false,
      "id_str" : "10016742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796451568254062592\/_SobZEUj_normal.jpg",
      "id" : 10016742,
      "verified" : false
    }
  },
  "id" : 279769707664535553,
  "created_at" : "2012-12-15 02:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279755010827501568",
  "text" : "RT @bunnybuddhism: A bunny describing another bunny often reveals more of himself than of the other bunny.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279753728528101377",
    "text" : "A bunny describing another bunny often reveals more of himself than of the other bunny.",
    "id" : 279753728528101377,
    "created_at" : "2012-12-15 01:04:21 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 279755010827501568,
  "created_at" : "2012-12-15 01:09:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279744599268941824",
  "text" : "RT @CoyoteSings: You can write laws, bully and mandate people, but unless you change their hearts, none of it matters. You have to chang ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279737046933843968",
    "text" : "You can write laws, bully and mandate people, but unless you change their hearts, none of it matters. You have to change people's hearts.",
    "id" : 279737046933843968,
    "created_at" : "2012-12-14 23:58:03 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 279744599268941824,
  "created_at" : "2012-12-15 00:28:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279738131446644736",
  "text" : "RT @CoyoteSings: Yes, I know.. the apocalypse is coming. We all need guns to shoot people trying to steal our food, right? Good lord, we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279729042305978368",
    "text" : "Yes, I know.. the apocalypse is coming. We all need guns to shoot people trying to steal our food, right? Good lord, we've gone bonkers...",
    "id" : 279729042305978368,
    "created_at" : "2012-12-14 23:26:15 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 279738131446644736,
  "created_at" : "2012-12-15 00:02:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "indices" : [ 72, 80 ],
      "id_str" : "8192222",
      "id" : 8192222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/UfpF9EMj",
      "expanded_url" : "http:\/\/jezebel.com\/5967939\/michigan-senate-passes-gigantic-monster-of-an-anti+abortion-bill",
      "display_url" : "jezebel.com\/5967939\/michig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279735421666217984",
  "text" : "Roe V World: Michigan Senate Passes Gigantic Monster Anti-Choice Bill - @Jezebel http:\/\/t.co\/UfpF9EMj",
  "id" : 279735421666217984,
  "created_at" : "2012-12-14 23:51:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Bradstreet",
      "screen_name" : "OnBradstreet",
      "indices" : [ 3, 16 ],
      "id_str" : "72554903",
      "id" : 72554903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279718164932202498",
  "text" : "RT @OnBradstreet: The school as an institution is a place of violence: young people are corralled, controlled, forced, denied rights, fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279673447896981504",
    "text" : "The school as an institution is a place of violence: young people are corralled, controlled, forced, denied rights, for 13+ years.",
    "id" : 279673447896981504,
    "created_at" : "2012-12-14 19:45:20 +0000",
    "user" : {
      "name" : "Amy Bradstreet",
      "screen_name" : "OnBradstreet",
      "protected" : false,
      "id_str" : "72554903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796821206490054656\/wCuRbNwG_normal.jpg",
      "id" : 72554903,
      "verified" : false
    }
  },
  "id" : 279718164932202498,
  "created_at" : "2012-12-14 22:43:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Bradstreet",
      "screen_name" : "OnBradstreet",
      "indices" : [ 3, 16 ],
      "id_str" : "72554903",
      "id" : 72554903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279718147509063680",
  "text" : "RT @OnBradstreet: There's a reason the institutionalized person, perhaps bullied, victimized, otherwise abused, returns to target the in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279672943263485952",
    "text" : "There's a reason the institutionalized person, perhaps bullied, victimized, otherwise abused, returns to target the institution.",
    "id" : 279672943263485952,
    "created_at" : "2012-12-14 19:43:20 +0000",
    "user" : {
      "name" : "Amy Bradstreet",
      "screen_name" : "OnBradstreet",
      "protected" : false,
      "id_str" : "72554903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796821206490054656\/wCuRbNwG_normal.jpg",
      "id" : 72554903,
      "verified" : false
    }
  },
  "id" : 279718147509063680,
  "created_at" : "2012-12-14 22:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Bradstreet",
      "screen_name" : "OnBradstreet",
      "indices" : [ 3, 16 ],
      "id_str" : "72554903",
      "id" : 72554903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279718102617436160",
  "text" : "RT @OnBradstreet: It's not only gun control we should be discussing. We should be discussing the impact of institutionalizing &amp; ware ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279672700119699456",
    "text" : "It's not only gun control we should be discussing. We should be discussing the impact of institutionalizing &amp; warehousing people in schools.",
    "id" : 279672700119699456,
    "created_at" : "2012-12-14 19:42:22 +0000",
    "user" : {
      "name" : "Amy Bradstreet",
      "screen_name" : "OnBradstreet",
      "protected" : false,
      "id_str" : "72554903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796821206490054656\/wCuRbNwG_normal.jpg",
      "id" : 72554903,
      "verified" : false
    }
  },
  "id" : 279718102617436160,
  "created_at" : "2012-12-14 22:42:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/wGSTnvoW",
      "expanded_url" : "http:\/\/youtu.be\/WM8bTdBs-cw",
      "display_url" : "youtu.be\/WM8bTdBs-cw"
    } ]
  },
  "geo" : { },
  "id_str" : "279713020509302785",
  "text" : "RT @Wylieknowords: Metallica - One [Official Music Video]: http:\/\/t.co\/wGSTnvoW via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 65, 73 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/wGSTnvoW",
        "expanded_url" : "http:\/\/youtu.be\/WM8bTdBs-cw",
        "display_url" : "youtu.be\/WM8bTdBs-cw"
      } ]
    },
    "geo" : { },
    "id_str" : "279711268825354240",
    "text" : "Metallica - One [Official Music Video]: http:\/\/t.co\/wGSTnvoW via @youtube",
    "id" : 279711268825354240,
    "created_at" : "2012-12-14 22:15:37 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 279713020509302785,
  "created_at" : "2012-12-14 22:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279697195467436033",
  "geo" : { },
  "id_str" : "279712364226560000",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOL",
  "id" : 279712364226560000,
  "in_reply_to_status_id" : 279697195467436033,
  "created_at" : "2012-12-14 22:19:59 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279693600609157120",
  "geo" : { },
  "id_str" : "279695068850442240",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses or a pulled muscle while sleeping, maybe.",
  "id" : 279695068850442240,
  "in_reply_to_status_id" : 279693600609157120,
  "created_at" : "2012-12-14 21:11:15 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279688901977849857",
  "geo" : { },
  "id_str" : "279690138584481792",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses maybe a bruised rib?",
  "id" : 279690138584481792,
  "in_reply_to_status_id" : 279688901977849857,
  "created_at" : "2012-12-14 20:51:40 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279673869743321088",
  "text" : "@1stCitizenKane hmmmm...",
  "id" : 279673869743321088,
  "created_at" : "2012-12-14 19:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279670818261331968",
  "text" : "RT @CoyoteSings: I think we need more than gun control. This country is stressed to the point that lunatics are breaking down left and r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279669306260873216",
    "text" : "I think we need more than gun control. This country is stressed to the point that lunatics are breaking down left and right.",
    "id" : 279669306260873216,
    "created_at" : "2012-12-14 19:28:53 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 279670818261331968,
  "created_at" : "2012-12-14 19:34:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 79, 85 ]
    }, {
      "text" : "nature",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/csshuIhC",
      "expanded_url" : "http:\/\/ow.ly\/g5osE",
      "display_url" : "ow.ly\/g5osE"
    } ]
  },
  "geo" : { },
  "id_str" : "279646838930427904",
  "text" : "RT @KerriFar: Mr Red \"fluffed\" - trying to stay warm ~ http:\/\/t.co\/csshuIhC  ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 65, 71 ]
      }, {
        "text" : "nature",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/csshuIhC",
        "expanded_url" : "http:\/\/ow.ly\/g5osE",
        "display_url" : "ow.ly\/g5osE"
      } ]
    },
    "geo" : { },
    "id_str" : "279643265765097473",
    "text" : "Mr Red \"fluffed\" - trying to stay warm ~ http:\/\/t.co\/csshuIhC  ~ #birds #nature",
    "id" : 279643265765097473,
    "created_at" : "2012-12-14 17:45:24 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 279646838930427904,
  "created_at" : "2012-12-14 17:59:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Words",
      "screen_name" : "funnyortruth",
      "indices" : [ 3, 16 ],
      "id_str" : "3385838413",
      "id" : 3385838413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279646455629766658",
  "text" : "RT @FunnyOrTruth: I once exercised, but I found i was allergic. My skin flushed and my heart raced. I got sweaty and out of breath. Very ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279096047618371584",
    "text" : "I once exercised, but I found i was allergic. My skin flushed and my heart raced. I got sweaty and out of breath. Very dangerous.",
    "id" : 279096047618371584,
    "created_at" : "2012-12-13 05:30:57 +0000",
    "user" : {
      "name" : "Quotes",
      "screen_name" : "wordstionary",
      "protected" : false,
      "id_str" : "127245578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779343576916496384\/kp3Di-1V_normal.jpg",
      "id" : 127245578,
      "verified" : false
    }
  },
  "id" : 279646455629766658,
  "created_at" : "2012-12-14 17:58:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279636779684990976",
  "text" : "RT @richarddoetsch: Why do we insist on forcing kids to learn what they are not good at, yet ignore nurturing their true talents?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279636251919921154",
    "text" : "Why do we insist on forcing kids to learn what they are not good at, yet ignore nurturing their true talents?",
    "id" : 279636251919921154,
    "created_at" : "2012-12-14 17:17:32 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 279636779684990976,
  "created_at" : "2012-12-14 17:19:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279635931705778177",
  "text" : "@ThePlushGourmet im so sorry... ((hugs))",
  "id" : 279635931705778177,
  "created_at" : "2012-12-14 17:16:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279632572340912128",
  "text" : "RT @petsalive: Thank you Purina Dog Chow - just donated 44 pallets of food to Pets Alive!!  We will be splitting it with pets Alive West ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279632059557896192",
    "text" : "Thank you Purina Dog Chow - just donated 44 pallets of food to Pets Alive!!  We will be splitting it with pets Alive Westchester! TY PURINA!",
    "id" : 279632059557896192,
    "created_at" : "2012-12-14 17:00:52 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 279632572340912128,
  "created_at" : "2012-12-14 17:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279628570282848256",
  "text" : "\"get a mammo.. you need one every year\" blahblahblah...",
  "id" : 279628570282848256,
  "created_at" : "2012-12-14 16:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279628111736356864",
  "text" : "just going to DR can kill you. \"lose weight\" \"eat right\" \"move more\" &lt;&lt; stress! and stress kills.. GAH!!",
  "id" : 279628111736356864,
  "created_at" : "2012-12-14 16:45:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279626252376215552",
  "text" : "@1stCitizenKane so this is you, again?",
  "id" : 279626252376215552,
  "created_at" : "2012-12-14 16:37:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279625868777775104",
  "text" : "gun control... what does that mean? crazy ppl will find a way to get guns. need to go further.. to reason for behaviour, start there.",
  "id" : 279625868777775104,
  "created_at" : "2012-12-14 16:36:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279622824249942016",
  "text" : "RT @bookwiseblog: Random House is Giving $5000 Bonus to All Employees: The drum beat of the news in regard to publishers is that t... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/upspzPNq",
        "expanded_url" : "http:\/\/bit.ly\/UhauGD",
        "display_url" : "bit.ly\/UhauGD"
      } ]
    },
    "geo" : { },
    "id_str" : "279622250255237120",
    "text" : "Random House is Giving $5000 Bonus to All Employees: The drum beat of the news in regard to publishers is that t... http:\/\/t.co\/upspzPNq",
    "id" : 279622250255237120,
    "created_at" : "2012-12-14 16:21:54 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 279622824249942016,
  "created_at" : "2012-12-14 16:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "indices" : [ 3, 16 ],
      "id_str" : "16744783",
      "id" : 16744783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/GnFqYKSi",
      "expanded_url" : "http:\/\/amzn.to\/TQCpwj",
      "display_url" : "amzn.to\/TQCpwj"
    }, {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/TsBsJm0m",
      "expanded_url" : "http:\/\/bit.ly\/qXtnUz",
      "display_url" : "bit.ly\/qXtnUz"
    } ]
  },
  "geo" : { },
  "id_str" : "279615589138452480",
  "text" : "RT @LisaTBergren: WATERFALL 4 FREE on ALL e-platforms 12\/14: Kindle http:\/\/t.co\/GnFqYKSi Nook http:\/\/t.co\/TsBsJm0m CBD http:\/\/t.co\/QJHjE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/GnFqYKSi",
        "expanded_url" : "http:\/\/amzn.to\/TQCpwj",
        "display_url" : "amzn.to\/TQCpwj"
      }, {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/TsBsJm0m",
        "expanded_url" : "http:\/\/bit.ly\/qXtnUz",
        "display_url" : "bit.ly\/qXtnUz"
      }, {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/QJHjEsUZ",
        "expanded_url" : "http:\/\/bit.ly\/TQCwrR",
        "display_url" : "bit.ly\/TQCwrR"
      } ]
    },
    "geo" : { },
    "id_str" : "279613717728075776",
    "text" : "WATERFALL 4 FREE on ALL e-platforms 12\/14: Kindle http:\/\/t.co\/GnFqYKSi Nook http:\/\/t.co\/TsBsJm0m CBD http:\/\/t.co\/QJHjEsUZ ++",
    "id" : 279613717728075776,
    "created_at" : "2012-12-14 15:47:59 +0000",
    "user" : {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "protected" : false,
      "id_str" : "16744783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694980555096457216\/ApJGMyxi_normal.jpg",
      "id" : 16744783,
      "verified" : false
    }
  },
  "id" : 279615589138452480,
  "created_at" : "2012-12-14 15:55:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Lori",
      "screen_name" : "TheResident",
      "indices" : [ 22, 34 ],
      "id_str" : "16380690",
      "id" : 16380690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Anonymous",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Tmoz86EY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9qFOfg3tKdM",
      "display_url" : "youtube.com\/watch?v=9qFOfg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279608696538025984",
  "text" : "RT @CharlesBivona: RT @TheResident: My holiday video is here : All I want for Christmas is some anarchy! http:\/\/t.co\/Tmoz86EY #Anonymous ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lori",
        "screen_name" : "TheResident",
        "indices" : [ 3, 15 ],
        "id_str" : "16380690",
        "id" : 16380690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Anonymous",
        "indices" : [ 107, 117 ]
      }, {
        "text" : "OWS",
        "indices" : [ 128, 132 ]
      }, {
        "text" : "occupy",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/Tmoz86EY",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9qFOfg3tKdM",
        "display_url" : "youtube.com\/watch?v=9qFOfg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "279607927747248129",
    "text" : "RT @TheResident: My holiday video is here : All I want for Christmas is some anarchy! http:\/\/t.co\/Tmoz86EY #Anonymous Christmas #OWS #occupy",
    "id" : 279607927747248129,
    "created_at" : "2012-12-14 15:24:59 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 279608696538025984,
  "created_at" : "2012-12-14 15:28:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "indices" : [ 3, 14 ],
      "id_str" : "417189310",
      "id" : 417189310
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DianeJReed\/status\/279569912299663361\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/dDfT9vjS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-E7WqDCMAAqyBx.jpg",
      "id_str" : "279569912303857664",
      "id" : 279569912303857664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-E7WqDCMAAqyBx.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/dDfT9vjS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279594716687896576",
  "text" : "RT @DianeJReed: Wintry sunrise, rays sifting through the trees--may your day shine like never before... http:\/\/t.co\/dDfT9vjS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DianeJReed\/status\/279569912299663361\/photo\/1",
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/dDfT9vjS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-E7WqDCMAAqyBx.jpg",
        "id_str" : "279569912303857664",
        "id" : 279569912303857664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-E7WqDCMAAqyBx.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/dDfT9vjS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279569912299663361",
    "text" : "Wintry sunrise, rays sifting through the trees--may your day shine like never before... http:\/\/t.co\/dDfT9vjS",
    "id" : 279569912299663361,
    "created_at" : "2012-12-14 12:53:57 +0000",
    "user" : {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "protected" : false,
      "id_str" : "417189310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695055759181160448\/du6nVVbQ_normal.jpg",
      "id" : 417189310,
      "verified" : false
    }
  },
  "id" : 279594716687896576,
  "created_at" : "2012-12-14 14:32:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279374188446359552",
  "text" : "watching jail shows. breaks my heart.",
  "id" : 279374188446359552,
  "created_at" : "2012-12-13 23:56:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279371644441620480",
  "geo" : { },
  "id_str" : "279372521017593856",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny damn you, johnny.. i was looking forward to it!!",
  "id" : 279372521017593856,
  "in_reply_to_status_id" : 279371644441620480,
  "created_at" : "2012-12-13 23:49:34 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deirdre Winsman",
      "screen_name" : "langtry_girl",
      "indices" : [ 3, 16 ],
      "id_str" : "4377442395",
      "id" : 4377442395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbcqt",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279368814993477632",
  "text" : "RT @langtry_girl: WHY do people take drugs? If you want to stop drug abuse, you need to ask this question and NO-ONE EVER DOES. #bbcqt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bbcqt",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279365908634431488",
    "text" : "WHY do people take drugs? If you want to stop drug abuse, you need to ask this question and NO-ONE EVER DOES. #bbcqt",
    "id" : 279365908634431488,
    "created_at" : "2012-12-13 23:23:17 +0000",
    "user" : {
      "name" : "(((Langtry Ghoul)))",
      "screen_name" : "drlangtry_girl",
      "protected" : false,
      "id_str" : "123974837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639872063990206464\/dXnICghJ_normal.png",
      "id" : 123974837,
      "verified" : false
    }
  },
  "id" : 279368814993477632,
  "created_at" : "2012-12-13 23:34:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/d5eSeVMi",
      "expanded_url" : "http:\/\/youtu.be\/21XBFaG5zGY",
      "display_url" : "youtu.be\/21XBFaG5zGY"
    } ]
  },
  "geo" : { },
  "id_str" : "279367920767868929",
  "text" : "Ratatouille The Snowboarding Opossum: http:\/\/t.co\/d5eSeVMi",
  "id" : 279367920767868929,
  "created_at" : "2012-12-13 23:31:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faith in Fiction",
      "screen_name" : "FictionFaith",
      "indices" : [ 0, 13 ],
      "id_str" : "494383730",
      "id" : 494383730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279363331414949889",
  "geo" : { },
  "id_str" : "279364550938218497",
  "in_reply_to_user_id" : 494383730,
  "text" : "@FictionFaith zapped! lol",
  "id" : 279364550938218497,
  "in_reply_to_status_id" : 279363331414949889,
  "created_at" : "2012-12-13 23:17:53 +0000",
  "in_reply_to_screen_name" : "FictionFaith",
  "in_reply_to_user_id_str" : "494383730",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279341612449034241",
  "text" : "@1stCitizenKane dislike",
  "id" : 279341612449034241,
  "created_at" : "2012-12-13 21:46:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "indices" : [ 3, 14 ],
      "id_str" : "417189310",
      "id" : 417189310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279341092233687040",
  "text" : "RT @DianeJReed: Saw bluebirds on my jog in the woods today\u2014in December? Felt like an angels' blessing. May your day bring happiness too  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/ZVnRjXo9",
        "expanded_url" : "http:\/\/pinterest.com\/pin\/239113061437644790\/",
        "display_url" : "pinterest.com\/pin\/2391130614\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "279322784923004928",
    "text" : "Saw bluebirds on my jog in the woods today\u2014in December? Felt like an angels' blessing. May your day bring happiness too http:\/\/t.co\/ZVnRjXo9",
    "id" : 279322784923004928,
    "created_at" : "2012-12-13 20:31:56 +0000",
    "user" : {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "protected" : false,
      "id_str" : "417189310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695055759181160448\/du6nVVbQ_normal.jpg",
      "id" : 417189310,
      "verified" : false
    }
  },
  "id" : 279341092233687040,
  "created_at" : "2012-12-13 21:44:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279337908064894977",
  "geo" : { },
  "id_str" : "279338925078765568",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog excellent news! ((clapclapclap)) : )",
  "id" : 279338925078765568,
  "in_reply_to_status_id" : 279337908064894977,
  "created_at" : "2012-12-13 21:36:04 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279338691720278016",
  "text" : "LOL",
  "id" : 279338691720278016,
  "created_at" : "2012-12-13 21:35:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279326996318810112",
  "geo" : { },
  "id_str" : "279337355763122176",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog no, no, no.. i love e ink.. and dedicated ereader!",
  "id" : 279337355763122176,
  "in_reply_to_status_id" : 279326996318810112,
  "created_at" : "2012-12-13 21:29:50 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279314661692809217",
  "text" : "RT @ificouldtellu: God is awareness aware of itself",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279314286361325568",
    "text" : "God is awareness aware of itself",
    "id" : 279314286361325568,
    "created_at" : "2012-12-13 19:58:09 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 279314661692809217,
  "created_at" : "2012-12-13 19:59:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279308745576689665",
  "geo" : { },
  "id_str" : "279309529076879361",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses awwww.. sweet baby! : )",
  "id" : 279309529076879361,
  "in_reply_to_status_id" : 279308745576689665,
  "created_at" : "2012-12-13 19:39:15 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279302980958822400",
  "geo" : { },
  "id_str" : "279308959167442944",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny you got it! lol",
  "id" : 279308959167442944,
  "in_reply_to_status_id" : 279302980958822400,
  "created_at" : "2012-12-13 19:36:59 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279304795184062465",
  "geo" : { },
  "id_str" : "279308636541566976",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie im not that cuddly...lol",
  "id" : 279308636541566976,
  "in_reply_to_status_id" : 279304795184062465,
  "created_at" : "2012-12-13 19:35:42 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279260803423686657",
  "text" : "RT @ShhDragon: \"Excuse me, your hope is showing.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279256266340179968",
    "text" : "\"Excuse me, your hope is showing.\"",
    "id" : 279256266340179968,
    "created_at" : "2012-12-13 16:07:36 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 279260803423686657,
  "created_at" : "2012-12-13 16:25:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/M8QuJP3A",
      "expanded_url" : "http:\/\/bit.ly\/VS9LRn",
      "display_url" : "bit.ly\/VS9LRn"
    } ]
  },
  "geo" : { },
  "id_str" : "279260734570000384",
  "text" : "RT @aliceinthewater: Scott Lively Endorses Uganda's \"Revised\" Plan To Imprison Homosexuals For Life.\nhttp:\/\/t.co\/M8QuJP3A #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/M8QuJP3A",
        "expanded_url" : "http:\/\/bit.ly\/VS9LRn",
        "display_url" : "bit.ly\/VS9LRn"
      } ]
    },
    "geo" : { },
    "id_str" : "279257058799390720",
    "text" : "Scott Lively Endorses Uganda's \"Revised\" Plan To Imprison Homosexuals For Life.\nhttp:\/\/t.co\/M8QuJP3A #lam",
    "id" : 279257058799390720,
    "created_at" : "2012-12-13 16:10:45 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 279260734570000384,
  "created_at" : "2012-12-13 16:25:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279259756701548544",
  "text" : "RT @DuttonBooks: It's 12 Days of Dutton! Each day we'll tweet a clue about 1 of\nour authors. Send a guess &amp; enter to win their new b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/MfP4By98",
        "expanded_url" : "http:\/\/ow.ly\/g4xaM",
        "display_url" : "ow.ly\/g4xaM"
      } ]
    },
    "geo" : { },
    "id_str" : "279254387715604482",
    "text" : "It's 12 Days of Dutton! Each day we'll tweet a clue about 1 of\nour authors. Send a guess &amp; enter to win their new book http:\/\/t.co\/MfP4By98",
    "id" : 279254387715604482,
    "created_at" : "2012-12-13 16:00:08 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 279259756701548544,
  "created_at" : "2012-12-13 16:21:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "indices" : [ 3, 16 ],
      "id_str" : "16744783",
      "id" : 16744783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/GnFqYKSi",
      "expanded_url" : "http:\/\/amzn.to\/TQCpwj",
      "display_url" : "amzn.to\/TQCpwj"
    }, {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/TsBsJm0m",
      "expanded_url" : "http:\/\/bit.ly\/qXtnUz",
      "display_url" : "bit.ly\/qXtnUz"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/QJHjEsUZ",
      "expanded_url" : "http:\/\/bit.ly\/TQCwrR",
      "display_url" : "bit.ly\/TQCwrR"
    } ]
  },
  "geo" : { },
  "id_str" : "279254595304312832",
  "text" : "RT @LisaTBergren: WATERFALL is FREE on ALL platforms: Kindle http:\/\/t.co\/GnFqYKSi Nook http:\/\/t.co\/TsBsJm0m CBD http:\/\/t.co\/QJHjEsUZ ++",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/GnFqYKSi",
        "expanded_url" : "http:\/\/amzn.to\/TQCpwj",
        "display_url" : "amzn.to\/TQCpwj"
      }, {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/TsBsJm0m",
        "expanded_url" : "http:\/\/bit.ly\/qXtnUz",
        "display_url" : "bit.ly\/qXtnUz"
      }, {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/QJHjEsUZ",
        "expanded_url" : "http:\/\/bit.ly\/TQCwrR",
        "display_url" : "bit.ly\/TQCwrR"
      } ]
    },
    "geo" : { },
    "id_str" : "279253184411738112",
    "text" : "WATERFALL is FREE on ALL platforms: Kindle http:\/\/t.co\/GnFqYKSi Nook http:\/\/t.co\/TsBsJm0m CBD http:\/\/t.co\/QJHjEsUZ ++",
    "id" : 279253184411738112,
    "created_at" : "2012-12-13 15:55:22 +0000",
    "user" : {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "protected" : false,
      "id_str" : "16744783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694980555096457216\/ApJGMyxi_normal.jpg",
      "id" : 16744783,
      "verified" : false
    }
  },
  "id" : 279254595304312832,
  "created_at" : "2012-12-13 16:00:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 0, 5 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279247647028686848",
  "geo" : { },
  "id_str" : "279251684545417216",
  "in_reply_to_user_id" : 355689205,
  "text" : "@EInk Yota",
  "id" : 279251684545417216,
  "in_reply_to_status_id" : 279247647028686848,
  "created_at" : "2012-12-13 15:49:24 +0000",
  "in_reply_to_screen_name" : "EInk",
  "in_reply_to_user_id_str" : "355689205",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/0r9d4h4e",
      "expanded_url" : "http:\/\/amzn.to\/qDukAm",
      "display_url" : "amzn.to\/qDukAm"
    } ]
  },
  "geo" : { },
  "id_str" : "279050994711666688",
  "text" : "finished The Hole by Aaron Ross Powell http:\/\/t.co\/0r9d4h4e",
  "id" : 279050994711666688,
  "created_at" : "2012-12-13 02:31:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zen",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279007100741484544",
  "text" : "RT @CoyoteSings: I cannot believe God is an angry god. He created trees that stand patiently in the storm and say nothing at all. #zen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zen",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279005347748909056",
    "text" : "I cannot believe God is an angry god. He created trees that stand patiently in the storm and say nothing at all. #zen",
    "id" : 279005347748909056,
    "created_at" : "2012-12-12 23:30:33 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 279007100741484544,
  "created_at" : "2012-12-12 23:37:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicki",
      "screen_name" : "NurseAgita",
      "indices" : [ 3, 14 ],
      "id_str" : "104824264",
      "id" : 104824264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedicareForAll",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279004088107163649",
  "text" : "RT @NurseAgita: #MedicareForAll (US single-payer &amp; universal) wld dilute risk pool, reduce heath costs, allow ppl to leave dead-end  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedicareForAll",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278982164417236992",
    "text" : "#MedicareForAll (US single-payer &amp; universal) wld dilute risk pool, reduce heath costs, allow ppl to leave dead-end jobs, towns, rela'ships",
    "id" : 278982164417236992,
    "created_at" : "2012-12-12 21:58:25 +0000",
    "user" : {
      "name" : "Vicki",
      "screen_name" : "NurseAgita",
      "protected" : false,
      "id_str" : "104824264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2862648052\/331687c1095e351ed89d426829f66631_normal.png",
      "id" : 104824264,
      "verified" : false
    }
  },
  "id" : 279004088107163649,
  "created_at" : "2012-12-12 23:25:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ZZohhxV6",
      "expanded_url" : "http:\/\/pulse.me\/s\/gcuGp",
      "display_url" : "pulse.me\/s\/gcuGp"
    } ]
  },
  "geo" : { },
  "id_str" : "278979829267853312",
  "text" : "RT @Silvercrone: No Teachers, No Class, No Homework. Would You Send Your Kids Here? http:\/\/t.co\/ZZohhxV6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/ZZohhxV6",
        "expanded_url" : "http:\/\/pulse.me\/s\/gcuGp",
        "display_url" : "pulse.me\/s\/gcuGp"
      } ]
    },
    "geo" : { },
    "id_str" : "278978692565311488",
    "text" : "No Teachers, No Class, No Homework. Would You Send Your Kids Here? http:\/\/t.co\/ZZohhxV6",
    "id" : 278978692565311488,
    "created_at" : "2012-12-12 21:44:38 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 278979829267853312,
  "created_at" : "2012-12-12 21:49:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 15, 31 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/s4qKQbcM",
      "expanded_url" : "http:\/\/tiny.cc\/kq17ow",
      "display_url" : "tiny.cc\/kq17ow"
    } ]
  },
  "in_reply_to_status_id_str" : "278967489059246081",
  "geo" : { },
  "id_str" : "278974307491799040",
  "in_reply_to_user_id" : 116009507,
  "text" : "nudity FTW! RT @ChristnNitemare From the archives: Footage of a nudist church service http:\/\/t.co\/s4qKQbcM",
  "id" : 278974307491799040,
  "in_reply_to_status_id" : 278967489059246081,
  "created_at" : "2012-12-12 21:27:12 +0000",
  "in_reply_to_screen_name" : "ChristnNitemare",
  "in_reply_to_user_id_str" : "116009507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278935212170289152",
  "text" : "RT @mindymayhem: You just don't get it until you work your ass off for 8 hours, can barely stand at the end of your shift, and don't eve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278930241261539328",
    "text" : "You just don't get it until you work your ass off for 8 hours, can barely stand at the end of your shift, and don't even make $50, that day.",
    "id" : 278930241261539328,
    "created_at" : "2012-12-12 18:32:06 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 278935212170289152,
  "created_at" : "2012-12-12 18:51:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F\u2764WOLVES\u2764\uFE0F\u2764 \u24CB",
      "screen_name" : "proudvegan",
      "indices" : [ 3, 14 ],
      "id_str" : "64746727",
      "id" : 64746727
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wolf",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/Bxx690Iy",
      "expanded_url" : "http:\/\/www.whitewolfpack.com\/2012\/12\/heartbreak-and-anger-abound-as.html",
      "display_url" : "whitewolfpack.com\/2012\/12\/heartb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278664108033847296",
  "text" : "RT @proudvegan: Heartbreak and anger abound as Yellowstone's most famous #wolf is killed by a hunter\nhttp:\/\/t.co\/Bxx690Iy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wolf",
        "indices" : [ 57, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/Bxx690Iy",
        "expanded_url" : "http:\/\/www.whitewolfpack.com\/2012\/12\/heartbreak-and-anger-abound-as.html",
        "display_url" : "whitewolfpack.com\/2012\/12\/heartb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "278378353235476480",
    "text" : "Heartbreak and anger abound as Yellowstone's most famous #wolf is killed by a hunter\nhttp:\/\/t.co\/Bxx690Iy",
    "id" : 278378353235476480,
    "created_at" : "2012-12-11 05:59:06 +0000",
    "user" : {
      "name" : "\u2764\uFE0F\u2764WOLVES\u2764\uFE0F\u2764 \u24CB",
      "screen_name" : "proudvegan",
      "protected" : false,
      "id_str" : "64746727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749171368697040898\/YvsBnLjn_normal.jpg",
      "id" : 64746727,
      "verified" : false
    }
  },
  "id" : 278664108033847296,
  "created_at" : "2012-12-12 00:54:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 27, 35 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278663752709197825",
  "text" : "Happy Birthday Dear Ani La @SangyeH a beautiful soul ((hugs))",
  "id" : 278663752709197825,
  "created_at" : "2012-12-12 00:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TGFBook",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278632966031298560",
  "text" : "RT @alanhdawe: Perhaps your beliefs can soften and broaden so you are able to reach out and meet others halfway. #TGFBook (Follow The Go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278628427236515842",
    "text" : "Perhaps your beliefs can soften and broaden so you are able to reach out and meet others halfway. #TGFBook (Follow The God Franchise serial)",
    "id" : 278628427236515842,
    "created_at" : "2012-12-11 22:32:48 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 278632966031298560,
  "created_at" : "2012-12-11 22:50:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278500305488982016",
  "text" : "i sent my sister a card. it made her cry. i knew she'd like it..lol",
  "id" : 278500305488982016,
  "created_at" : "2012-12-11 14:03:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278294684063916032",
  "text" : "DH thinks i have arthritis in my sore shoulder..",
  "id" : 278294684063916032,
  "created_at" : "2012-12-11 00:26:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278275863110381568",
  "geo" : { },
  "id_str" : "278277179501060097",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie oh yeah. ppl have always hated shopping w me. pure torture..lol. ive gotten better w age, tho.",
  "id" : 278277179501060097,
  "in_reply_to_status_id" : 278275863110381568,
  "created_at" : "2012-12-10 23:17:04 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drawsomething",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278272545936007170",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses sorry.. sometimes my brain totally fails! back to #1... #drawsomething",
  "id" : 278272545936007170,
  "created_at" : "2012-12-10 22:58:39 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278270647476576256",
  "geo" : { },
  "id_str" : "278272263588020226",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie oh, YES.. lol",
  "id" : 278272263588020226,
  "in_reply_to_status_id" : 278270647476576256,
  "created_at" : "2012-12-10 22:57:32 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faith in Fiction",
      "screen_name" : "FictionFaith",
      "indices" : [ 0, 13 ],
      "id_str" : "494383730",
      "id" : 494383730
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 62, 77 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278261706671656961",
  "geo" : { },
  "id_str" : "278264016697163776",
  "in_reply_to_user_id" : 494383730,
  "text" : "@FictionFaith i dunno.. #1 seems to be only one makes sense.. @AnnotatedBible",
  "id" : 278264016697163776,
  "in_reply_to_status_id" : 278261706671656961,
  "created_at" : "2012-12-10 22:24:46 +0000",
  "in_reply_to_screen_name" : "FictionFaith",
  "in_reply_to_user_id_str" : "494383730",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tuts+ Code",
      "screen_name" : "nettuts",
      "indices" : [ 3, 11 ],
      "id_str" : "2646886861",
      "id" : 2646886861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/PpU2D6ki",
      "expanded_url" : "http:\/\/net.tutsplus.com\/articles\/news\/how-to-make-nettuts-your-full-time-job\/",
      "display_url" : "net.tutsplus.com\/articles\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278220442924380160",
  "text" : "RT @nettuts: Want to earn $62k a year, learning how to be a better developer, and teaching others in the process? http:\/\/t.co\/PpU2D6ki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/PpU2D6ki",
        "expanded_url" : "http:\/\/net.tutsplus.com\/articles\/news\/how-to-make-nettuts-your-full-time-job\/",
        "display_url" : "net.tutsplus.com\/articles\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "278219697579761664",
    "text" : "Want to earn $62k a year, learning how to be a better developer, and teaching others in the process? http:\/\/t.co\/PpU2D6ki",
    "id" : 278219697579761664,
    "created_at" : "2012-12-10 19:28:39 +0000",
    "user" : {
      "name" : "Envato Tuts+ Code",
      "screen_name" : "TutsPlusCode",
      "protected" : false,
      "id_str" : "14490962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440360139866910721\/CSiOk6MT_normal.png",
      "id" : 14490962,
      "verified" : false
    }
  },
  "id" : 278220442924380160,
  "created_at" : "2012-12-10 19:31:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna White Glaser",
      "screen_name" : "readdonnaglaser",
      "indices" : [ 3, 19 ],
      "id_str" : "174919515",
      "id" : 174919515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/s8uS0yRv",
      "expanded_url" : "http:\/\/fb.me\/DnLJxKsZ",
      "display_url" : "fb.me\/DnLJxKsZ"
    } ]
  },
  "geo" : { },
  "id_str" : "278220179912134656",
  "text" : "RT @readdonnaglaser: I love Jack Reacher, but Tom Cruze as him? Are you kidding me? http:\/\/t.co\/s8uS0yRv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/s8uS0yRv",
        "expanded_url" : "http:\/\/fb.me\/DnLJxKsZ",
        "display_url" : "fb.me\/DnLJxKsZ"
      } ]
    },
    "geo" : { },
    "id_str" : "278216913438527490",
    "text" : "I love Jack Reacher, but Tom Cruze as him? Are you kidding me? http:\/\/t.co\/s8uS0yRv",
    "id" : 278216913438527490,
    "created_at" : "2012-12-10 19:17:35 +0000",
    "user" : {
      "name" : "Donna White Glaser",
      "screen_name" : "readdonnaglaser",
      "protected" : false,
      "id_str" : "174919515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1493489633\/D06F9042ret-comp_normal.jpg",
      "id" : 174919515,
      "verified" : false
    }
  },
  "id" : 278220179912134656,
  "created_at" : "2012-12-10 19:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 0, 10 ],
      "id_str" : "529048622",
      "id" : 529048622
    }, {
      "name" : "eReaderIQ",
      "screen_name" : "eReaderIQ",
      "indices" : [ 31, 41 ],
      "id_str" : "153435359",
      "id" : 153435359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278215074047479808",
  "geo" : { },
  "id_str" : "278218955087290369",
  "in_reply_to_user_id" : 529048622,
  "text" : "@alanhdawe I got a notice from @eReaderIQ that it was finally available on Kindle. It was on my list! : )",
  "id" : 278218955087290369,
  "in_reply_to_status_id" : 278215074047479808,
  "created_at" : "2012-12-10 19:25:42 +0000",
  "in_reply_to_screen_name" : "alanhdawe",
  "in_reply_to_user_id_str" : "529048622",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278183996435881984",
  "text" : "so mp3's dont have bass\/treble functions? why not? my walkmans did...",
  "id" : 278183996435881984,
  "created_at" : "2012-12-10 17:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 3, 8 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278176312085061632",
  "text" : "RT @EInk: Today begins 25 Days of E Ink. We will be giving gifts with E Ink displays to our followers. Tweet us the answer to the daily  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274938968343195648",
    "text" : "Today begins 25 Days of E Ink. We will be giving gifts with E Ink displays to our followers. Tweet us the answer to the daily question.",
    "id" : 274938968343195648,
    "created_at" : "2012-12-01 18:12:12 +0000",
    "user" : {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "protected" : false,
      "id_str" : "355689205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1909407234\/twitter_prof_icon_normal.png",
      "id" : 355689205,
      "verified" : false
    }
  },
  "id" : 278176312085061632,
  "created_at" : "2012-12-10 16:36:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 72, 82 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278168478828068865",
  "text" : "Now available on #kindle \"The God Franchise: A Theory of Everything\" by @alanhdawe",
  "id" : 278168478828068865,
  "created_at" : "2012-12-10 16:05:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277952738749452289",
  "text" : "RT @MimiMadeira1: I used to think twitter could help me change the world...now I know twitter allows the world to change me...thanks guy ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277950786246422528",
    "text" : "I used to think twitter could help me change the world...now I know twitter allows the world to change me...thanks guys,\nMimi",
    "id" : 277950786246422528,
    "created_at" : "2012-12-10 01:40:06 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 277952738749452289,
  "created_at" : "2012-12-10 01:47:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifeellikecrapnow",
      "indices" : [ 94, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277925542009917440",
  "text" : "found the source of the dead smell. the sound i heard was them. but i didnt go looking. sigh. #ifeellikecrapnow",
  "id" : 277925542009917440,
  "created_at" : "2012-12-09 23:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277880808042270721",
  "geo" : { },
  "id_str" : "277882611001610240",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver cool beans!",
  "id" : 277882611001610240,
  "in_reply_to_status_id" : 277880808042270721,
  "created_at" : "2012-12-09 21:09:11 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yes Joseph Ushie",
      "screen_name" : "UshieYes",
      "indices" : [ 12, 21 ],
      "id_str" : "780514346493358080",
      "id" : 780514346493358080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/UHurVze7",
      "expanded_url" : "https:\/\/twitter.com\/UshiEyes\/status\/277785785846071296\/photo\/1",
      "display_url" : "pic.twitter.com\/UHurVze7"
    } ]
  },
  "geo" : { },
  "id_str" : "277817939430883329",
  "text" : "wow..lol RT @UshiEyes Crazy pic of 'Nature takes over' Driving in rain while it freezes. http:\/\/t.co\/UHurVze7 cc: @WarriorBanker",
  "id" : 277817939430883329,
  "created_at" : "2012-12-09 16:52:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliott Teters",
      "screen_name" : "Elliott_Teters",
      "indices" : [ 3, 18 ],
      "id_str" : "46923217",
      "id" : 46923217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277807674349998080",
  "text" : "RT @Elliott_Teters: Hatred only exists in those who have never learned who and what they are. Those who know find Love the only true state.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277807124019564544",
    "text" : "Hatred only exists in those who have never learned who and what they are. Those who know find Love the only true state.",
    "id" : 277807124019564544,
    "created_at" : "2012-12-09 16:09:14 +0000",
    "user" : {
      "name" : "Elliott Teters",
      "screen_name" : "Elliott_Teters",
      "protected" : false,
      "id_str" : "46923217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774089006678093825\/yzGaGcF5_normal.jpg",
      "id" : 46923217,
      "verified" : false
    }
  },
  "id" : 277807674349998080,
  "created_at" : "2012-12-09 16:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/HklSVb1d",
      "expanded_url" : "http:\/\/www.gaystarnews.com\/article\/quackers-gay-marriage-means-ducks-will-rule-world131012",
      "display_url" : "gaystarnews.com\/article\/quacke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277807439762575360",
  "text" : "@1stCitizenKane not pigeons.. ducks. &gt;&gt; http:\/\/t.co\/HklSVb1d",
  "id" : 277807439762575360,
  "created_at" : "2012-12-09 16:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277803203687505920",
  "text" : "RT @TheGoldenMirror: Progress is seldom seen as it is made, but often shows in hindsight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277801873107451904",
    "text" : "Progress is seldom seen as it is made, but often shows in hindsight.",
    "id" : 277801873107451904,
    "created_at" : "2012-12-09 15:48:22 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 277803203687505920,
  "created_at" : "2012-12-09 15:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277798837622558721",
  "geo" : { },
  "id_str" : "277801618089574400",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i dunno about that.. i think you're pretty nice actually.",
  "id" : 277801618089574400,
  "in_reply_to_status_id" : 277798837622558721,
  "created_at" : "2012-12-09 15:47:21 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Garden",
      "screen_name" : "WildlifeGarden",
      "indices" : [ 3, 18 ],
      "id_str" : "171979247",
      "id" : 171979247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WildlifeGarden",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/XFRLJvpN",
      "expanded_url" : "http:\/\/bit.ly\/bDZyGH",
      "display_url" : "bit.ly\/bDZyGH"
    } ]
  },
  "geo" : { },
  "id_str" : "277797579255861248",
  "text" : "RT @WildlifeGarden: Toad-ily Cool! http:\/\/t.co\/XFRLJvpN\n #WildlifeGarden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WildlifeGarden",
        "indices" : [ 37, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/XFRLJvpN",
        "expanded_url" : "http:\/\/bit.ly\/bDZyGH",
        "display_url" : "bit.ly\/bDZyGH"
      } ]
    },
    "geo" : { },
    "id_str" : "277796335984467968",
    "text" : "Toad-ily Cool! http:\/\/t.co\/XFRLJvpN\n #WildlifeGarden",
    "id" : 277796335984467968,
    "created_at" : "2012-12-09 15:26:22 +0000",
    "user" : {
      "name" : "Wildlife Garden",
      "screen_name" : "WildlifeGarden",
      "protected" : false,
      "id_str" : "171979247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000044473348\/a554cca187a67fb5dbddb776da62ce0e_normal.jpeg",
      "id" : 171979247,
      "verified" : false
    }
  },
  "id" : 277797579255861248,
  "created_at" : "2012-12-09 15:31:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277794838085246976",
  "text" : "well, tree is up and i am in a new corner. i have a window and all my gadgets so its all good..lol",
  "id" : 277794838085246976,
  "created_at" : "2012-12-09 15:20:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/6uuBHerm",
      "expanded_url" : "http:\/\/amzn.to\/SOOxR3",
      "display_url" : "amzn.to\/SOOxR3"
    } ]
  },
  "geo" : { },
  "id_str" : "277613957970276353",
  "text" : "finished The Knowing: Awake in the Dark by Nita Lapinski http:\/\/t.co\/6uuBHerm",
  "id" : 277613957970276353,
  "created_at" : "2012-12-09 03:21:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277566686364839936",
  "text" : "RT @TheGodLight: You must rise to meet every challenge, you must not expect defeat, for he who tries with all his heart usually succeeds.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277566441488805888",
    "text" : "You must rise to meet every challenge, you must not expect defeat, for he who tries with all his heart usually succeeds.",
    "id" : 277566441488805888,
    "created_at" : "2012-12-09 00:12:51 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 277566686364839936,
  "created_at" : "2012-12-09 00:13:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277566604399751168",
  "text" : "i believe in the fire of the human spirit",
  "id" : 277566604399751168,
  "created_at" : "2012-12-09 00:13:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277550738639568896",
  "text" : "@1stCitizenKane love quantum stuff.. fascinating!",
  "id" : 277550738639568896,
  "created_at" : "2012-12-08 23:10:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277550213252669441",
  "text" : "@1stCitizenKane then end of the world as we know it... thank god, its about time!",
  "id" : 277550213252669441,
  "created_at" : "2012-12-08 23:08:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277543525678186496",
  "text" : "RT @LOLGOP: About 26,000 Americans die each year for lack of insurance. Hundreds of thousands go bankrupt because of medical bills http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/XeEzHIBA",
        "expanded_url" : "http:\/\/www.nationalmemo.com\/the-states-turning-down-heath-insurance-expansion-need-it-the-most\/",
        "display_url" : "nationalmemo.com\/the-states-tur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "277510365074575361",
    "text" : "About 26,000 Americans die each year for lack of insurance. Hundreds of thousands go bankrupt because of medical bills http:\/\/t.co\/XeEzHIBA",
    "id" : 277510365074575361,
    "created_at" : "2012-12-08 20:30:01 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 277543525678186496,
  "created_at" : "2012-12-08 22:41:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277496186708049921",
  "geo" : { },
  "id_str" : "277496834577031168",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker I dont even want a phone. i just want my ipod touch to have 24\/7 internet access..lol. hubby answers the phone in this house.",
  "id" : 277496834577031168,
  "in_reply_to_status_id" : 277496186708049921,
  "created_at" : "2012-12-08 19:36:15 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Laube",
      "screen_name" : "TheAncientBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "155754927",
      "id" : 155754927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277496456443723776",
  "text" : "RT @TheAncientBooks: Later on today I'll be giving away two digital copies of Ancient Revelations.  Keep an eye out for them here: https ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 131 ],
        "url" : "https:\/\/t.co\/QI3CHJni",
        "expanded_url" : "https:\/\/www.facebook.com\/TheAncientBooks",
        "display_url" : "facebook.com\/TheAncientBooks"
      } ]
    },
    "geo" : { },
    "id_str" : "277496169956012032",
    "text" : "Later on today I'll be giving away two digital copies of Ancient Revelations.  Keep an eye out for them here: https:\/\/t.co\/QI3CHJni",
    "id" : 277496169956012032,
    "created_at" : "2012-12-08 19:33:37 +0000",
    "user" : {
      "name" : "Matthew Laube",
      "screen_name" : "TheAncientBooks",
      "protected" : false,
      "id_str" : "155754927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2374550641\/isswkigc6yzrowrlrh4d_normal.jpeg",
      "id" : 155754927,
      "verified" : false
    }
  },
  "id" : 277496456443723776,
  "created_at" : "2012-12-08 19:34:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/qMINTkDz",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/axI",
      "display_url" : "omgf.ac\/ts\/axI"
    } ]
  },
  "geo" : { },
  "id_str" : "277471795571990528",
  "text" : "RT @OMGFacts: NASA forced bees to hold their pee\u2026for a week! Why? Learn here ---&gt; http:\/\/t.co\/qMINTkDz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/qMINTkDz",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/axI",
        "display_url" : "omgf.ac\/ts\/axI"
      } ]
    },
    "geo" : { },
    "id_str" : "277457788601524225",
    "text" : "NASA forced bees to hold their pee\u2026for a week! Why? Learn here ---&gt; http:\/\/t.co\/qMINTkDz",
    "id" : 277457788601524225,
    "created_at" : "2012-12-08 17:01:06 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 277471795571990528,
  "created_at" : "2012-12-08 17:56:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276677778848501760",
  "geo" : { },
  "id_str" : "277468115166703616",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem what an awesome sentence! i love it! lol",
  "id" : 277468115166703616,
  "in_reply_to_status_id" : 276677778848501760,
  "created_at" : "2012-12-08 17:42:08 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277466993517539328",
  "text" : "RT @adamrshields: Quiet: The Power of Introverts in a World that Can't Stop Talking is on sale for $3.99 (hardcover) till stock runs out ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/8ZX9Oend",
        "expanded_url" : "http:\/\/www.amazon.com\/gp\/b\/\/?ie=UTF8&camp=213733&creative=393193&linkCode=shr&tag=mrshiecom-20&ode=3666021",
        "display_url" : "amazon.com\/gp\/b\/\/?ie=UTF8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "277460740779175937",
    "text" : "Quiet: The Power of Introverts in a World that Can't Stop Talking is on sale for $3.99 (hardcover) till stock runs out. http:\/\/t.co\/8ZX9Oend",
    "id" : 277460740779175937,
    "created_at" : "2012-12-08 17:12:50 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 277466993517539328,
  "created_at" : "2012-12-08 17:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277466667720798208",
  "text" : "RT @SalimRaza2050: Some people come into your life as blessings, others come into your life as lessons\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277462259641495552",
    "text" : "Some people come into your life as blessings, others come into your life as lessons\"",
    "id" : 277462259641495552,
    "created_at" : "2012-12-08 17:18:52 +0000",
    "user" : {
      "name" : "Horeb07",
      "screen_name" : "Horeb07",
      "protected" : false,
      "id_str" : "893745704",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_5_normal.png",
      "id" : 893745704,
      "verified" : false
    }
  },
  "id" : 277466667720798208,
  "created_at" : "2012-12-08 17:36:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "indices" : [ 3, 15 ],
      "id_str" : "4207961",
      "id" : 4207961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277453060823990272",
  "text" : "RT @chrislhayes: I lack the words to describe how democratically perverse a deal that raises the Medicare eligibility age would be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277194532997718017",
    "text" : "I lack the words to describe how democratically perverse a deal that raises the Medicare eligibility age would be.",
    "id" : 277194532997718017,
    "created_at" : "2012-12-07 23:35:01 +0000",
    "user" : {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "protected" : false,
      "id_str" : "4207961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499446228\/MSNBC_Headshot_normal.jpg",
      "id" : 4207961,
      "verified" : true
    }
  },
  "id" : 277453060823990272,
  "created_at" : "2012-12-08 16:42:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277452800781344768",
  "text" : "RT @angelaharms: I wonder how many people out there have chronic pain &amp; nobody knows it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277452525215563776",
    "text" : "I wonder how many people out there have chronic pain &amp; nobody knows it?",
    "id" : 277452525215563776,
    "created_at" : "2012-12-08 16:40:11 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 277452800781344768,
  "created_at" : "2012-12-08 16:41:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/3rc0DJlY",
      "expanded_url" : "http:\/\/youtu.be\/kACSd-yTEnA",
      "display_url" : "youtu.be\/kACSd-yTEnA"
    } ]
  },
  "geo" : { },
  "id_str" : "277437044110798848",
  "text" : "***MUST WATCH*** courts rule schools can vaccinate a child without paren...: http:\/\/t.co\/3rc0DJlY",
  "id" : 277437044110798848,
  "created_at" : "2012-12-08 15:38:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 79, 92 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/X8AN39W2",
      "expanded_url" : "http:\/\/www.facebook.com\/rebecca.bryson\/posts\/179639992177237",
      "display_url" : "facebook.com\/rebecca.bryson\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277219670858280961",
  "text" : "Airline Mechanic Blows the Whistle on Chemtrail Operation http:\/\/t.co\/X8AN39W2 @MimiMadeira1",
  "id" : 277219670858280961,
  "created_at" : "2012-12-08 01:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277211563033767936",
  "text" : "RT @Buddhaworld: one day, you give up trying to become somebody. thats the day you realise you have always been somebody. been all there is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277210987646578688",
    "text" : "one day, you give up trying to become somebody. thats the day you realise you have always been somebody. been all there is.",
    "id" : 277210987646578688,
    "created_at" : "2012-12-08 00:40:24 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 277211563033767936,
  "created_at" : "2012-12-08 00:42:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277115763364593664",
  "text" : "had a dream last night where my mommy swam me to safety in big waves.",
  "id" : 277115763364593664,
  "created_at" : "2012-12-07 18:22:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alien",
      "screen_name" : "TwistedSciFi",
      "indices" : [ 73, 86 ],
      "id_str" : "354520236",
      "id" : 354520236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/FLda9hp9",
      "expanded_url" : "http:\/\/www.twistedscifi.com\/read-this-before-purchasing-a-kindle-paperwhite\/",
      "display_url" : "twistedscifi.com\/read-this-befo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277086318465519617",
  "text" : "Read This Before Purchasing a Kindle Paperwhite http:\/\/t.co\/FLda9hp9 via @TwistedSciFi",
  "id" : 277086318465519617,
  "created_at" : "2012-12-07 16:25:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 16, 30 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277071244405391361",
  "geo" : { },
  "id_str" : "277077618061357058",
  "in_reply_to_user_id" : 204832963,
  "text" : "clapclapclap RT @TheTweetOfGod If you're happy it's the end of the world as you know it and you know it clap your hands!",
  "id" : 277077618061357058,
  "in_reply_to_status_id" : 277071244405391361,
  "created_at" : "2012-12-07 15:50:26 +0000",
  "in_reply_to_screen_name" : "TheTweetOfGod",
  "in_reply_to_user_id_str" : "204832963",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Nelson Bibles",
      "screen_name" : "NelsonBibles",
      "indices" : [ 3, 16 ],
      "id_str" : "164329173",
      "id" : 164329173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/WkurXbA2",
      "expanded_url" : "http:\/\/ow.ly\/fUkJS",
      "display_url" : "ow.ly\/fUkJS"
    } ]
  },
  "geo" : { },
  "id_str" : "277068843812257792",
  "text" : "RT @NelsonBibles: 18 days until Christmas! Enter for your chance to win today's giveaway, the Barnes and Noble Nook HD http:\/\/t.co\/WkurXbA2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/WkurXbA2",
        "expanded_url" : "http:\/\/ow.ly\/fUkJS",
        "display_url" : "ow.ly\/fUkJS"
      } ]
    },
    "geo" : { },
    "id_str" : "277067480353095681",
    "text" : "18 days until Christmas! Enter for your chance to win today's giveaway, the Barnes and Noble Nook HD http:\/\/t.co\/WkurXbA2",
    "id" : 277067480353095681,
    "created_at" : "2012-12-07 15:10:09 +0000",
    "user" : {
      "name" : "Thomas Nelson Bibles",
      "screen_name" : "NelsonBibles",
      "protected" : false,
      "id_str" : "164329173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776461650849370114\/ChOuJrek_normal.jpg",
      "id" : 164329173,
      "verified" : false
    }
  },
  "id" : 277068843812257792,
  "created_at" : "2012-12-07 15:15:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277068335575879680",
  "text" : "@SamsaricWarrior this yrs model supposed 2B faster and better memory I think.. im always running out of mem 4 apps. i dislike bookshelf.",
  "id" : 277068335575879680,
  "created_at" : "2012-12-07 15:13:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277067859312656384",
  "text" : "@SamsaricWarrior i have the 1st KFire (last year) .. use it 4 apps, no reading, some browsing. tempted to get nexus 7 instead.",
  "id" : 277067859312656384,
  "created_at" : "2012-12-07 15:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277064273874800641",
  "text" : "a xmas card in the mail for my sister. will make her happy : )",
  "id" : 277064273874800641,
  "created_at" : "2012-12-07 14:57:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277063964565856256",
  "text" : "RT @DarciaHelle: If: Small word, big possibilities",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277063825335934977",
    "text" : "If: Small word, big possibilities",
    "id" : 277063825335934977,
    "created_at" : "2012-12-07 14:55:38 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 277063964565856256,
  "created_at" : "2012-12-07 14:56:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 3, 16 ],
      "id_str" : "88882302",
      "id" : 88882302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277063711779348483",
  "text" : "RT @TweetTheBook: #FREE 12\/7-12\/9 ~The lives of 12 ordinary people are changed forever. =&gt;&gt;The Twelve Pathways to Christmas by And ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FREE",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ {
        "indices" : [ 125, 145 ],
        "url" : "http:\/\/t.co\/OcpeHOcZ",
        "expanded_url" : "http:\/\/ow.ly\/fTzjI",
        "display_url" : "ow.ly\/fTzjI"
      } ]
    },
    "geo" : { },
    "id_str" : "277039880352182274",
    "text" : "#FREE 12\/7-12\/9 ~The lives of 12 ordinary people are changed forever. =&gt;&gt;The Twelve Pathways to Christmas by Andy Wood http:\/\/t.co\/OcpeHOcZ",
    "id" : 277039880352182274,
    "created_at" : "2012-12-07 13:20:29 +0000",
    "user" : {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "protected" : false,
      "id_str" : "88882302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723538520174780416\/myOVJeXG_normal.jpg",
      "id" : 88882302,
      "verified" : false
    }
  },
  "id" : 277063711779348483,
  "created_at" : "2012-12-07 14:55:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277060329035415552",
  "text" : "@iEyeAyes thanks.. but didnt seem to work..",
  "id" : 277060329035415552,
  "created_at" : "2012-12-07 14:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 22, 32 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 9, 18 ]
    }, {
      "text" : "muoscopeglasses",
      "indices" : [ 89, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Sf3x8YmR",
      "expanded_url" : "http:\/\/makeuseof.com\/tag\/steelseries-scope-glasses-review-and-giveaway",
      "display_url" : "makeuseof.com\/tag\/steelserie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277044948417789952",
  "text" : "Join the #giveaway at @makeuseof to win a FREE pair of Gunnar Steelseries Scope glasses! #muoscopeglasses http:\/\/t.co\/Sf3x8YmR",
  "id" : 277044948417789952,
  "created_at" : "2012-12-07 13:40:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277044492618575872",
  "text" : "it's a lot of work changing identities..LOL .. but good, tho. like cleaning out a messy closet!",
  "id" : 277044492618575872,
  "created_at" : "2012-12-07 13:38:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277042481135230978",
  "geo" : { },
  "id_str" : "277043458009595905",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields ahh.. yes.. thanks. i wasnt sure if i needed to update domain in wp file or what.",
  "id" : 277043458009595905,
  "in_reply_to_status_id" : 277042481135230978,
  "created_at" : "2012-12-07 13:34:42 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277041690357936129",
  "geo" : { },
  "id_str" : "277042850540175360",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin they should send teachers to ATA Leadership. about leading TaeKwonDo classes but works for any group.",
  "id" : 277042850540175360,
  "in_reply_to_status_id" : 277041690357936129,
  "created_at" : "2012-12-07 13:32:17 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277042024346161152",
  "text" : "i changed my domain and now i cant get into my wordpress admin. it tries to go to old domain. anyone?",
  "id" : 277042024346161152,
  "created_at" : "2012-12-07 13:29:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/QzXiDxpT",
      "expanded_url" : "http:\/\/shar.es\/6zklT",
      "display_url" : "shar.es\/6zklT"
    } ]
  },
  "geo" : { },
  "id_str" : "276770988614635520",
  "text" : "Cute! &gt;&gt; Om Nom Nom Bird http:\/\/t.co\/QzXiDxpT",
  "id" : 276770988614635520,
  "created_at" : "2012-12-06 19:32:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276714059653591041",
  "text" : "RT @adamrshields: Kindle Paperwhite in Stock for Christmas-after being listed as backordered for Christmas last week, now in stock again ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/fKz24hVV",
        "expanded_url" : "http:\/\/bookwi.se\/kindle-paperwhite-in-stock-for-christmas\/",
        "display_url" : "bookwi.se\/kindle-paperwh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276697225680277505",
    "text" : "Kindle Paperwhite in Stock for Christmas-after being listed as backordered for Christmas last week, now in stock again http:\/\/t.co\/fKz24hVV",
    "id" : 276697225680277505,
    "created_at" : "2012-12-06 14:38:54 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 276714059653591041,
  "created_at" : "2012-12-06 15:45:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276374314440351745",
  "geo" : { },
  "id_str" : "276379634436825088",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth LOLOL... cats...",
  "id" : 276379634436825088,
  "in_reply_to_status_id" : 276374314440351745,
  "created_at" : "2012-12-05 17:36:54 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/BZjHCRvm",
      "expanded_url" : "http:\/\/stevecreek.com\/opossum-out-for-a-daytime-stroll\/",
      "display_url" : "stevecreek.com\/opossum-out-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276362987403636736",
  "text" : "RT @screek: Opossum Out For A Daytime Stroll http:\/\/t.co\/BZjHCRvm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/BZjHCRvm",
        "expanded_url" : "http:\/\/stevecreek.com\/opossum-out-for-a-daytime-stroll\/",
        "display_url" : "stevecreek.com\/opossum-out-fo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276350660369334272",
    "text" : "Opossum Out For A Daytime Stroll http:\/\/t.co\/BZjHCRvm",
    "id" : 276350660369334272,
    "created_at" : "2012-12-05 15:41:46 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 276362987403636736,
  "created_at" : "2012-12-05 16:30:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276362181799444480",
  "text" : "carrots and potatoes chopped for soup. this will please DH : )",
  "id" : 276362181799444480,
  "created_at" : "2012-12-05 16:27:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/q2PiAqoY",
      "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
      "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276344478585999360",
  "text" : "RT @PeggySueCusses: For those of you not sure what to get your kid's teacher for Christmas... Here's an idea. http:\/\/t.co\/q2PiAqoY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/q2PiAqoY",
        "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
        "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276338917878411264",
    "text" : "For those of you not sure what to get your kid's teacher for Christmas... Here's an idea. http:\/\/t.co\/q2PiAqoY",
    "id" : 276338917878411264,
    "created_at" : "2012-12-05 14:55:06 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 276344478585999360,
  "created_at" : "2012-12-05 15:17:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276116848133677056",
  "geo" : { },
  "id_str" : "276120003760254976",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous DON'T BLINK!!!",
  "id" : 276120003760254976,
  "in_reply_to_status_id" : 276116848133677056,
  "created_at" : "2012-12-05 00:25:13 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276102431773954048",
  "text" : "@1stCitizenKane im a boring lime tree... bleh.",
  "id" : 276102431773954048,
  "created_at" : "2012-12-04 23:15:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "indices" : [ 3, 18 ],
      "id_str" : "7622122",
      "id" : 7622122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/SEIa2KE7",
      "expanded_url" : "http:\/\/ow.ly\/fOKEU",
      "display_url" : "ow.ly\/fOKEU"
    } ]
  },
  "geo" : { },
  "id_str" : "276039661347033088",
  "text" : "RT @indiebizchicks: Promote your craft biz w\/ $5 Vendor Spots In The Virtual Indie Craft Fair http:\/\/t.co\/SEIa2KE7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/SEIa2KE7",
        "expanded_url" : "http:\/\/ow.ly\/fOKEU",
        "display_url" : "ow.ly\/fOKEU"
      } ]
    },
    "geo" : { },
    "id_str" : "276038398110728192",
    "text" : "Promote your craft biz w\/ $5 Vendor Spots In The Virtual Indie Craft Fair http:\/\/t.co\/SEIa2KE7",
    "id" : 276038398110728192,
    "created_at" : "2012-12-04 19:00:57 +0000",
    "user" : {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "protected" : false,
      "id_str" : "7622122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653393257959936001\/6VMDqhz3_normal.jpg",
      "id" : 7622122,
      "verified" : false
    }
  },
  "id" : 276039661347033088,
  "created_at" : "2012-12-04 19:05:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276037113030537216",
  "geo" : { },
  "id_str" : "276038355798618112",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog that would work! (might want to bold \"support bookwise\" or title it in widget?)",
  "id" : 276038355798618112,
  "in_reply_to_status_id" : 276037113030537216,
  "created_at" : "2012-12-04 19:00:47 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/kmxubbaH",
      "expanded_url" : "http:\/\/www.davidpakman.com\/",
      "display_url" : "davidpakman.com"
    } ]
  },
  "geo" : { },
  "id_str" : "276034865395269632",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog look at http:\/\/t.co\/kmxubbaH and see their amazon ad on right side.. you should do similar ad on your site. : )",
  "id" : 276034865395269632,
  "created_at" : "2012-12-04 18:46:55 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276033402241691649",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog if i go thru amazon ad link on your page.. then search for book, you still get credit, right?",
  "id" : 276033402241691649,
  "created_at" : "2012-12-04 18:41:06 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276031247132815362",
  "text" : "@zen_kitty ppl want to believe it was justified.. because then they dont have to worry it could happen to them...",
  "id" : 276031247132815362,
  "created_at" : "2012-12-04 18:32:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    }, {
      "name" : "Quinnan Stone",
      "screen_name" : "QuinnanStone",
      "indices" : [ 125, 138 ],
      "id_str" : "376722094",
      "id" : 376722094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276030019673927680",
  "text" : "@zen_kitty THIS! strangely (or not?) reading Natural Cures They Don't Want You To Know About by Kevin Trudeau opened my eyes @QuinnanStone",
  "id" : 276030019673927680,
  "created_at" : "2012-12-04 18:27:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/TucoeXl5",
      "expanded_url" : "http:\/\/amzn.to\/y9tNsu",
      "display_url" : "amzn.to\/y9tNsu"
    } ]
  },
  "geo" : { },
  "id_str" : "275801014819491840",
  "text" : "finished The Volunteer by Barbara  Taylor Sissel http:\/\/t.co\/TucoeXl5",
  "id" : 275801014819491840,
  "created_at" : "2012-12-04 03:17:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275694784092467200",
  "text" : "im not a fan of longer school days. should get rid of stuff and have shorter days.",
  "id" : 275694784092467200,
  "created_at" : "2012-12-03 20:15:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "indices" : [ 3, 15 ],
      "id_str" : "95431448",
      "id" : 95431448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/6Sw0Lb3Q",
      "expanded_url" : "http:\/\/b.globe.com\/YoH1B5",
      "display_url" : "b.globe.com\/YoH1B5"
    } ]
  },
  "geo" : { },
  "id_str" : "275694152405106690",
  "text" : "RT @BostonGlobe: 5,000 students in Mass. will have longer school days come September as part of a national program. http:\/\/t.co\/6Sw0Lb3Q ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "school",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "education",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/6Sw0Lb3Q",
        "expanded_url" : "http:\/\/b.globe.com\/YoH1B5",
        "display_url" : "b.globe.com\/YoH1B5"
      } ]
    },
    "geo" : { },
    "id_str" : "275684030198992896",
    "text" : "5,000 students in Mass. will have longer school days come September as part of a national program. http:\/\/t.co\/6Sw0Lb3Q #school #education",
    "id" : 275684030198992896,
    "created_at" : "2012-12-03 19:32:49 +0000",
    "user" : {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "protected" : false,
      "id_str" : "95431448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586570157734019072\/Qxz1LIIM_normal.png",
      "id" : 95431448,
      "verified" : true
    }
  },
  "id" : 275694152405106690,
  "created_at" : "2012-12-03 20:13:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275693585498783744",
  "text" : "RT @oshum: The Universe speaks.....through each one of us....we are the characters of its ongoing story.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275688772102942720",
    "text" : "The Universe speaks.....through each one of us....we are the characters of its ongoing story.",
    "id" : 275688772102942720,
    "created_at" : "2012-12-03 19:51:39 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 275693585498783744,
  "created_at" : "2012-12-03 20:10:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275674842089549828",
  "geo" : { },
  "id_str" : "275676585938522112",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hmm.. i'll have to get DH to check it all out. DD loves anime, paranormal, watches lots of youtube on her ipod, etc.",
  "id" : 275676585938522112,
  "in_reply_to_status_id" : 275674842089549828,
  "created_at" : "2012-12-03 19:03:14 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275674315289153537",
  "text" : "i think the ghosts put up their christmas tree.. i keep smelling pine tree..",
  "id" : 275674315289153537,
  "created_at" : "2012-12-03 18:54:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275668745035317249",
  "geo" : { },
  "id_str" : "275673818150871041",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses is it all \"pay\" channels?",
  "id" : 275673818150871041,
  "in_reply_to_status_id" : 275668745035317249,
  "created_at" : "2012-12-03 18:52:14 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275668528777011200",
  "geo" : { },
  "id_str" : "275673365891645440",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses DD has tv in her room. Roku might be nice to watch netflix.. i see they have anime channel (she'd LOVE)",
  "id" : 275673365891645440,
  "in_reply_to_status_id" : 275668528777011200,
  "created_at" : "2012-12-03 18:50:26 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275667880371187713",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses do you have a roku? (looks like something DD would like)",
  "id" : 275667880371187713,
  "created_at" : "2012-12-03 18:28:39 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/63tJU9QG",
      "expanded_url" : "http:\/\/fb.me\/2267CRu6t",
      "display_url" : "fb.me\/2267CRu6t"
    } ]
  },
  "geo" : { },
  "id_str" : "275651637761163264",
  "text" : "RT @introvertmeetup: Free Range Introverts http:\/\/t.co\/63tJU9QG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/63tJU9QG",
        "expanded_url" : "http:\/\/fb.me\/2267CRu6t",
        "display_url" : "fb.me\/2267CRu6t"
      } ]
    },
    "geo" : { },
    "id_str" : "275649613694918656",
    "text" : "Free Range Introverts http:\/\/t.co\/63tJU9QG",
    "id" : 275649613694918656,
    "created_at" : "2012-12-03 17:16:03 +0000",
    "user" : {
      "name" : "Social Introverts",
      "screen_name" : "proudintroverts",
      "protected" : false,
      "id_str" : "741558997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625876596486877184\/WZGimc1S_normal.png",
      "id" : 741558997,
      "verified" : false
    }
  },
  "id" : 275651637761163264,
  "created_at" : "2012-12-03 17:24:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275639149132922880",
  "text" : "RT @CoyoteSings: Why do women say they are expecting a baby? Would they ever be expecting something else?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275638656608370688",
    "text" : "Why do women say they are expecting a baby? Would they ever be expecting something else?",
    "id" : 275638656608370688,
    "created_at" : "2012-12-03 16:32:31 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 275639149132922880,
  "created_at" : "2012-12-03 16:34:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275637574129815553",
  "text" : "who am i?",
  "id" : 275637574129815553,
  "created_at" : "2012-12-03 16:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Rohr, OFM",
      "screen_name" : "RichardRohrOFM",
      "indices" : [ 3, 18 ],
      "id_str" : "399080466",
      "id" : 399080466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275635146844164096",
  "text" : "RT @RichardRohrOFM: God is always bigger than the boxes we build for God, so we should not waste too much time protecting the boxes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274635429913980928",
    "text" : "God is always bigger than the boxes we build for God, so we should not waste too much time protecting the boxes.",
    "id" : 274635429913980928,
    "created_at" : "2012-11-30 22:06:03 +0000",
    "user" : {
      "name" : "Richard Rohr, OFM",
      "screen_name" : "RichardRohrOFM",
      "protected" : false,
      "id_str" : "399080466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569930543957942272\/TXCMulVA_normal.jpeg",
      "id" : 399080466,
      "verified" : false
    }
  },
  "id" : 275635146844164096,
  "created_at" : "2012-12-03 16:18:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Baker",
      "screen_name" : "DeanBaker13",
      "indices" : [ 3, 15 ],
      "id_str" : "330361451",
      "id" : 330361451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275629570647019520",
  "text" : "RT @DeanBaker13: In the interest of accuracy, the \"fiscal cliff\" will now be referred to as the \"fiscal bluff.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275628805438177283",
    "text" : "In the interest of accuracy, the \"fiscal cliff\" will now be referred to as the \"fiscal bluff.\"",
    "id" : 275628805438177283,
    "created_at" : "2012-12-03 15:53:22 +0000",
    "user" : {
      "name" : "Dean Baker",
      "screen_name" : "DeanBaker13",
      "protected" : false,
      "id_str" : "330361451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1464065133\/baker_thumbnail_normal.jpg",
      "id" : 330361451,
      "verified" : false
    }
  },
  "id" : 275629570647019520,
  "created_at" : "2012-12-03 15:56:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275628969569681408",
  "text" : ". @Skeptical_Lady omg.. the poor sheep again!",
  "id" : 275628969569681408,
  "created_at" : "2012-12-03 15:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/fIWQkaU2",
      "expanded_url" : "http:\/\/tinyurl.com\/6sjm24d",
      "display_url" : "tinyurl.com\/6sjm24d"
    } ]
  },
  "geo" : { },
  "id_str" : "275628045358989312",
  "text" : "RT @Seeds4Parents: Anything is possible. Take it from the mouse. http:\/\/t.co\/fIWQkaU2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/fIWQkaU2",
        "expanded_url" : "http:\/\/tinyurl.com\/6sjm24d",
        "display_url" : "tinyurl.com\/6sjm24d"
      } ]
    },
    "geo" : { },
    "id_str" : "275624521820680193",
    "text" : "Anything is possible. Take it from the mouse. http:\/\/t.co\/fIWQkaU2",
    "id" : 275624521820680193,
    "created_at" : "2012-12-03 15:36:21 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 275628045358989312,
  "created_at" : "2012-12-03 15:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "Michelle9647",
      "indices" : [ 3, 16 ],
      "id_str" : "75630518",
      "id" : 75630518
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 37, 50 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275626873780854785",
  "text" : "RT @Michelle9647: I just got sick RT @YourAnonNews: Patents already filed for handcuffs with built-in electroshock equipment http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 19, 32 ],
        "id_str" : "279390084",
        "id" : 279390084
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/X21R2lUU",
        "expanded_url" : "http:\/\/bit.ly\/SFNbGU",
        "display_url" : "bit.ly\/SFNbGU"
      } ]
    },
    "geo" : { },
    "id_str" : "275623042145738754",
    "text" : "I just got sick RT @YourAnonNews: Patents already filed for handcuffs with built-in electroshock equipment http:\/\/t.co\/X21R2lUU\"",
    "id" : 275623042145738754,
    "created_at" : "2012-12-03 15:30:28 +0000",
    "user" : {
      "name" : "Michelle",
      "screen_name" : "Michelle9647",
      "protected" : false,
      "id_str" : "75630518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519174269511954432\/CnsXIjCo_normal.jpeg",
      "id" : 75630518,
      "verified" : false
    }
  },
  "id" : 275626873780854785,
  "created_at" : "2012-12-03 15:45:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zozzat",
      "screen_name" : "zozzat",
      "indices" : [ 3, 10 ],
      "id_str" : "2229553094",
      "id" : 2229553094
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Zozzat\/status\/274268795957284866\/photo\/1",
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/prvuTb18",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A85mBEyCEAAaj8H.jpg",
      "id_str" : "274268795965673472",
      "id" : 274268795965673472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A85mBEyCEAAaj8H.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/prvuTb18"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275626448562307073",
  "text" : "RT @Zozzat: hahaha Dog noses look like aliens ~~~&gt; http:\/\/t.co\/prvuTb18",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Zozzat\/status\/274268795957284866\/photo\/1",
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/prvuTb18",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A85mBEyCEAAaj8H.jpg",
        "id_str" : "274268795965673472",
        "id" : 274268795965673472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A85mBEyCEAAaj8H.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/prvuTb18"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274268795957284866",
    "text" : "hahaha Dog noses look like aliens ~~~&gt; http:\/\/t.co\/prvuTb18",
    "id" : 274268795957284866,
    "created_at" : "2012-11-29 21:49:11 +0000",
    "user" : {
      "name" : "Z o \u00EB \u2661\u2661\u2661",
      "screen_name" : "ZoeBeeBeauty",
      "protected" : false,
      "id_str" : "288708721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800147044946034688\/MNtXNBRr_normal.jpg",
      "id" : 288708721,
      "verified" : false
    }
  },
  "id" : 275626448562307073,
  "created_at" : "2012-12-03 15:44:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hgtv",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275625503124254720",
  "text" : "Candice Tells All #hgtv",
  "id" : 275625503124254720,
  "created_at" : "2012-12-03 15:40:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKilluminati",
      "screen_name" : "An0nKn0wledge",
      "indices" : [ 3, 17 ],
      "id_str" : "30886757",
      "id" : 30886757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275410136120578048",
  "text" : "RT @An0nkn0wledge: December 3rd 2012: Planetary Alignment Venus,Mars,Mercury over the GIZA pyramids 1 hour after sunrise tomorrow. http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/An0nkn0wledge\/status\/275404642689630209\/photo\/1",
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/4x3jeYfP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9JvEDmCQAAqUjU.jpg",
        "id_str" : "275404642698018816",
        "id" : 275404642698018816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9JvEDmCQAAqUjU.jpg",
        "sizes" : [ {
          "h" : 446,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4x3jeYfP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275404642689630209",
    "text" : "December 3rd 2012: Planetary Alignment Venus,Mars,Mercury over the GIZA pyramids 1 hour after sunrise tomorrow. http:\/\/t.co\/4x3jeYfP",
    "id" : 275404642689630209,
    "created_at" : "2012-12-03 01:02:38 +0000",
    "user" : {
      "name" : "AKilluminati",
      "screen_name" : "An0nKn0wledge",
      "protected" : false,
      "id_str" : "30886757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794812028422602752\/YRdQB94J_normal.jpg",
      "id" : 30886757,
      "verified" : false
    }
  },
  "id" : 275410136120578048,
  "created_at" : "2012-12-03 01:24:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275394015657078785",
  "geo" : { },
  "id_str" : "275394691283968000",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth heehee.. ive got a website but there are quite a few others who use the moniker abfabgab and that bothers me to no end.",
  "id" : 275394691283968000,
  "in_reply_to_status_id" : 275394015657078785,
  "created_at" : "2012-12-03 00:23:05 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275393566342250496",
  "text" : "well, you people are not very helpful... sigh...",
  "id" : 275393566342250496,
  "created_at" : "2012-12-03 00:18:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275385479594139648",
  "geo" : { },
  "id_str" : "275387582467166209",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny lol ; )",
  "id" : 275387582467166209,
  "in_reply_to_status_id" : 275385479594139648,
  "created_at" : "2012-12-02 23:54:50 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275386984296509440",
  "text" : "i could switch to moosebegab .. seems to be free...",
  "id" : 275386984296509440,
  "created_at" : "2012-12-02 23:52:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275380014025940992",
  "text" : "its a lot of PITA work to change my username, though. sigh. whattodowhattodo...",
  "id" : 275380014025940992,
  "created_at" : "2012-12-02 23:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275378882201399297",
  "text" : "there are other abfabgab's out there. this does not work for me...",
  "id" : 275378882201399297,
  "created_at" : "2012-12-02 23:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "valerija bykova",
      "screen_name" : "abefun",
      "indices" : [ 90, 97 ],
      "id_str" : "1304207515",
      "id" : 1304207515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275357501485092864",
  "text" : "RT @BasharETcontact: Your worthiness cannot be earned _nor proven _Only accepted _or not.~@AbeFun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "valerija bykova",
        "screen_name" : "abefun",
        "indices" : [ 69, 76 ],
        "id_str" : "1304207515",
        "id" : 1304207515
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275356595645452288",
    "text" : "Your worthiness cannot be earned _nor proven _Only accepted _or not.~@AbeFun",
    "id" : 275356595645452288,
    "created_at" : "2012-12-02 21:51:42 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 275357501485092864,
  "created_at" : "2012-12-02 21:55:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275345875130273792",
  "geo" : { },
  "id_str" : "275348741140131840",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver aww.. shucks.. lol",
  "id" : 275348741140131840,
  "in_reply_to_status_id" : 275345875130273792,
  "created_at" : "2012-12-02 21:20:30 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275344611801718784",
  "text" : "RT @luminanceriver: Tomorrow is a big alignment with Giza Pyramids and the belt of Orion over the points, all three of them. The 12th di ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275344397154009088",
    "text" : "Tomorrow is a big alignment with Giza Pyramids and the belt of Orion over the points, all three of them. The 12th dimensional gateway here.",
    "id" : 275344397154009088,
    "created_at" : "2012-12-02 21:03:14 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 275344611801718784,
  "created_at" : "2012-12-02 21:04:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275330291290222592",
  "geo" : { },
  "id_str" : "275331690132557824",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell LOL : )",
  "id" : 275331690132557824,
  "in_reply_to_status_id" : 275330291290222592,
  "created_at" : "2012-12-02 20:12:45 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 3, 18 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LoveHonorTruth\/status\/275328981039980544\/photo\/1",
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/N7jnFFlI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9IqP9-CIAAWxGe.jpg",
      "id_str" : "275328981044174848",
      "id" : 275328981044174848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9IqP9-CIAAWxGe.jpg",
      "sizes" : [ {
        "h" : 265,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/N7jnFFlI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275330192015245312",
  "text" : "RT @LoveHonorTruth: Truth. http:\/\/t.co\/N7jnFFlI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LoveHonorTruth\/status\/275328981039980544\/photo\/1",
        "indices" : [ 7, 27 ],
        "url" : "http:\/\/t.co\/N7jnFFlI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9IqP9-CIAAWxGe.jpg",
        "id_str" : "275328981044174848",
        "id" : 275328981044174848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9IqP9-CIAAWxGe.jpg",
        "sizes" : [ {
          "h" : 265,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/N7jnFFlI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275328981039980544",
    "text" : "Truth. http:\/\/t.co\/N7jnFFlI",
    "id" : 275328981039980544,
    "created_at" : "2012-12-02 20:02:03 +0000",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "protected" : false,
      "id_str" : "167958125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525129289336107008\/HMsrT9oV_normal.jpeg",
      "id" : 167958125,
      "verified" : false
    }
  },
  "id" : 275330192015245312,
  "created_at" : "2012-12-02 20:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beautiful Disaster\uD83D\uDC8B",
      "screen_name" : "kweezy_420",
      "indices" : [ 3, 14 ],
      "id_str" : "449515182",
      "id" : 449515182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275282258989035522",
  "text" : "RT @kweezy_420: I mean seriously,  life is so much easier if you just get along with everyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275273769264758785",
    "text" : "I mean seriously,  life is so much easier if you just get along with everyone.",
    "id" : 275273769264758785,
    "created_at" : "2012-12-02 16:22:35 +0000",
    "user" : {
      "name" : "KelseaLouiseMeador\u270C",
      "screen_name" : "_KelseaLouise_",
      "protected" : false,
      "id_str" : "343116623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544945375933911041\/D1pZNcbE_normal.jpeg",
      "id" : 343116623,
      "verified" : false
    }
  },
  "id" : 275282258989035522,
  "created_at" : "2012-12-02 16:56:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275272503553835008",
  "text" : "RT @luminanceriver: I really look forward to what the galactic alignment on 12\/21 will bring us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275271146381914112",
    "text" : "I really look forward to what the galactic alignment on 12\/21 will bring us.",
    "id" : 275271146381914112,
    "created_at" : "2012-12-02 16:12:10 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 275272503553835008,
  "created_at" : "2012-12-02 16:17:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274992707695411200",
  "text" : "russell brand is a funny guy",
  "id" : 274992707695411200,
  "created_at" : "2012-12-01 21:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/pBBgpl84",
      "expanded_url" : "http:\/\/youtu.be\/OBA6qlHW8po",
      "display_url" : "youtu.be\/OBA6qlHW8po"
    } ]
  },
  "geo" : { },
  "id_str" : "274991365065154560",
  "text" : "OFFICIAL Video: Russell Brand Interviews Westboro Baptist Church: http:\/\/t.co\/pBBgpl84 via",
  "id" : 274991365065154560,
  "created_at" : "2012-12-01 21:40:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274967588780527616",
  "geo" : { },
  "id_str" : "274968709360128000",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone lol.. he's been here forever. he lives behind stove and likes to drag things there.",
  "id" : 274968709360128000,
  "in_reply_to_status_id" : 274967588780527616,
  "created_at" : "2012-12-01 20:10:23 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274966122284068864",
  "geo" : { },
  "id_str" : "274966577403797504",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous : ( yeah...",
  "id" : 274966577403797504,
  "in_reply_to_status_id" : 274966122284068864,
  "created_at" : "2012-12-01 20:01:55 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dashiell",
      "screen_name" : "cdashiell",
      "indices" : [ 3, 13 ],
      "id_str" : "26670829",
      "id" : 26670829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274966196481298435",
  "text" : "RT @cdashiell: The job creators need you to work longer and not expect a pension. For freedom.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274964901628362752",
    "text" : "The job creators need you to work longer and not expect a pension. For freedom.",
    "id" : 274964901628362752,
    "created_at" : "2012-12-01 19:55:15 +0000",
    "user" : {
      "name" : "Chris Dashiell",
      "screen_name" : "cdashiell",
      "protected" : false,
      "id_str" : "26670829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1287469240\/falcon_normal.jpg",
      "id" : 26670829,
      "verified" : false
    }
  },
  "id" : 274966196481298435,
  "created_at" : "2012-12-01 20:00:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274965880331436032",
  "text" : "a very bold mouse lives in our kitchen",
  "id" : 274965880331436032,
  "created_at" : "2012-12-01 19:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274965693986918400",
  "text" : "@1stCitizenKane hey, me, too! lol",
  "id" : 274965693986918400,
  "created_at" : "2012-12-01 19:58:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "indices" : [ 3, 13 ],
      "id_str" : "17052345",
      "id" : 17052345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274928521686708224",
  "text" : "RT @TedDekker: Want a free copy of my next book? Here we go, only this time, everyone who puts their name in the hat, gets it.... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/kve1U9Is",
        "expanded_url" : "http:\/\/fb.me\/1dCGLfpkR",
        "display_url" : "fb.me\/1dCGLfpkR"
      } ]
    },
    "geo" : { },
    "id_str" : "274920803898884096",
    "text" : "Want a free copy of my next book? Here we go, only this time, everyone who puts their name in the hat, gets it.... http:\/\/t.co\/kve1U9Is",
    "id" : 274920803898884096,
    "created_at" : "2012-12-01 17:00:02 +0000",
    "user" : {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "protected" : false,
      "id_str" : "17052345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742685559\/Picture_2_normal.png",
      "id" : 17052345,
      "verified" : false
    }
  },
  "id" : 274928521686708224,
  "created_at" : "2012-12-01 17:30:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274907421049225216",
  "text" : "DD making me coffee... hmm..",
  "id" : 274907421049225216,
  "created_at" : "2012-12-01 16:06:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274907226186080257",
  "text" : "@RedFlagTheology good morning.. another name change? lol just dont do pic AND name at same time..",
  "id" : 274907226186080257,
  "created_at" : "2012-12-01 16:06:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwBirthday",
      "screen_name" : "TwBirthday",
      "indices" : [ 3, 14 ],
      "id_str" : "39750199",
      "id" : 39750199
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 16, 27 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/abgcgxBB",
      "expanded_url" : "http:\/\/twbirthday.com\/moosebegab\/",
      "display_url" : "twbirthday.com\/moosebegab\/"
    } ]
  },
  "geo" : { },
  "id_str" : "274900329148084224",
  "text" : "RT @TwBirthday: @moosebegab Happy 3rd TwBirthday! You've been around since 01 December 2009! http:\/\/t.co\/abgcgxBB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twbirthday.com\/\" rel=\"nofollow\"\u003ETwBirthday\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/abgcgxBB",
        "expanded_url" : "http:\/\/twbirthday.com\/moosebegab\/",
        "display_url" : "twbirthday.com\/moosebegab\/"
      } ]
    },
    "geo" : { },
    "id_str" : "274740146174308353",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab Happy 3rd TwBirthday! You've been around since 01 December 2009! http:\/\/t.co\/abgcgxBB",
    "id" : 274740146174308353,
    "created_at" : "2012-12-01 05:02:09 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "TwBirthday",
      "screen_name" : "TwBirthday",
      "protected" : false,
      "id_str" : "39750199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1128112250\/twitter_avatar_normal.png",
      "id" : 39750199,
      "verified" : false
    }
  },
  "id" : 274900329148084224,
  "created_at" : "2012-12-01 15:38:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]