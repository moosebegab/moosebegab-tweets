Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BmQrqc6rRZ",
      "expanded_url" : "http:\/\/florida.newszap.com\/belleglade\/122791-113\/summer-solstice-pagan-festival-has-pahokee-residents-outraged",
      "display_url" : "florida.newszap.com\/belleglade\/122\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340613042695962624",
  "text" : "\u201CWe are opening ourselves up to things we should not, like belly dancing and magic spells,\u201D  http:\/\/t.co\/BmQrqc6rRZ",
  "id" : 340613042695962624,
  "created_at" : "2013-05-31 23:37:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340561593098178560",
  "geo" : { },
  "id_str" : "340563115072704512",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist hmm...",
  "id" : 340563115072704512,
  "in_reply_to_status_id" : 340561593098178560,
  "created_at" : "2013-05-31 20:19:08 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_chrisfleming",
      "screen_name" : "_chrisfleming",
      "indices" : [ 3, 17 ],
      "id_str" : "2546988498",
      "id" : 2546988498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340561648660127745",
  "text" : "RT @_chrisfleming: WE are all one, what we do for others we do for the whole. Hurt another you also hurt yourself, heal another you also he\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340536526607900672",
    "text" : "WE are all one, what we do for others we do for the whole. Hurt another you also hurt yourself, heal another you also heal yourself.",
    "id" : 340536526607900672,
    "created_at" : "2013-05-31 18:33:29 +0000",
    "user" : {
      "name" : "Chris Fleming",
      "screen_name" : "chrisfleming91",
      "protected" : false,
      "id_str" : "130710804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798325129088376832\/M4DwHmfo_normal.jpg",
      "id" : 130710804,
      "verified" : false
    }
  },
  "id" : 340561648660127745,
  "created_at" : "2013-05-31 20:13:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340541585643159553",
  "geo" : { },
  "id_str" : "340560962044174337",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist why?",
  "id" : 340560962044174337,
  "in_reply_to_status_id" : 340541585643159553,
  "created_at" : "2013-05-31 20:10:35 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 2, 12 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340548996093313025",
  "geo" : { },
  "id_str" : "340559067284127744",
  "in_reply_to_user_id" : 93341555,
  "text" : ". @wow_trees shh.. let's keep it a secret, shall we?",
  "id" : 340559067284127744,
  "in_reply_to_status_id" : 340548996093313025,
  "created_at" : "2013-05-31 20:03:03 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340558335747174401",
  "text" : "RT @micahjmurray: When people say \"none of us deserve anything but hell\" I wonder, have you forgotten we were created in His image? Is ther\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340550560635817986",
    "text" : "When people say \"none of us deserve anything but hell\" I wonder, have you forgotten we were created in His image? Is there no worth in that?",
    "id" : 340550560635817986,
    "created_at" : "2013-05-31 19:29:15 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 340558335747174401,
  "created_at" : "2013-05-31 20:00:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nameless & Formless",
      "screen_name" : "SriSadguru",
      "indices" : [ 3, 14 ],
      "id_str" : "323293974",
      "id" : 323293974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340518279984582657",
  "text" : "RT @SriSadguru: Q: When did it first appear(the universe )? A:When you saw it. In reality, there is nothing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340509005174673408",
    "text" : "Q: When did it first appear(the universe )? A:When you saw it. In reality, there is nothing.",
    "id" : 340509005174673408,
    "created_at" : "2013-05-31 16:44:07 +0000",
    "user" : {
      "name" : "Nameless & Formless",
      "screen_name" : "SriSadguru",
      "protected" : false,
      "id_str" : "323293974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1411248315\/Siddharamphoto1_normal.jpg",
      "id" : 323293974,
      "verified" : false
    }
  },
  "id" : 340518279984582657,
  "created_at" : "2013-05-31 17:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "indices" : [ 3, 13 ],
      "id_str" : "17052345",
      "id" : 17052345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340506837738717184",
  "text" : "RT @TedDekker: Want a FREE copy of the Books of Mortals series? Read on...\n\nThe story that's taken readers on a redemptive... http:\/\/t.co\/S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Sznr0VSAuE",
        "expanded_url" : "http:\/\/fb.me\/2mlTKIZlE",
        "display_url" : "fb.me\/2mlTKIZlE"
      } ]
    },
    "geo" : { },
    "id_str" : "340494487392509952",
    "text" : "Want a FREE copy of the Books of Mortals series? Read on...\n\nThe story that's taken readers on a redemptive... http:\/\/t.co\/Sznr0VSAuE",
    "id" : 340494487392509952,
    "created_at" : "2013-05-31 15:46:26 +0000",
    "user" : {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "protected" : false,
      "id_str" : "17052345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742685559\/Picture_2_normal.png",
      "id" : 17052345,
      "verified" : false
    }
  },
  "id" : 340506837738717184,
  "created_at" : "2013-05-31 16:35:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 2, 14 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340499724853469184",
  "geo" : { },
  "id_str" : "340506075889553408",
  "in_reply_to_user_id" : 51880276,
  "text" : ". @VirgoJohnny haha.. no thanks. ive got enough trying to handle my own crazy, let alone another's..lol",
  "id" : 340506075889553408,
  "in_reply_to_status_id" : 340499724853469184,
  "created_at" : "2013-05-31 16:32:29 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K. Hulegaard",
      "screen_name" : "HulegaardBooks",
      "indices" : [ 3, 18 ],
      "id_str" : "216410258",
      "id" : 216410258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340490181121548288",
  "text" : "RT @HulegaardBooks: My book Strangers--six dark and twisted short stories--is available for FREE on Kindle through 6\/4! Check it out: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/RkCptGK08j",
        "expanded_url" : "http:\/\/bit.ly\/StrangersPromo",
        "display_url" : "bit.ly\/StrangersPromo"
      } ]
    },
    "geo" : { },
    "id_str" : "340487956588552194",
    "text" : "My book Strangers--six dark and twisted short stories--is available for FREE on Kindle through 6\/4! Check it out: http:\/\/t.co\/RkCptGK08j",
    "id" : 340487956588552194,
    "created_at" : "2013-05-31 15:20:29 +0000",
    "user" : {
      "name" : "David K. Hulegaard",
      "screen_name" : "HulegaardBooks",
      "protected" : false,
      "id_str" : "216410258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432974144804626432\/nwds5WEI_normal.jpeg",
      "id" : 216410258,
      "verified" : false
    }
  },
  "id" : 340490181121548288,
  "created_at" : "2013-05-31 15:29:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340489028371640322",
  "geo" : { },
  "id_str" : "340489722327601152",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist oh my...lol",
  "id" : 340489722327601152,
  "in_reply_to_status_id" : 340489028371640322,
  "created_at" : "2013-05-31 15:27:30 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annamatopoeia",
      "screen_name" : "annamac84",
      "indices" : [ 3, 13 ],
      "id_str" : "24010252",
      "id" : 24010252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340481679737098241",
  "text" : "RT @annamac84: You never know what another person is going through. Please keep that in mind as you go through your day, and be kind withou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340479193710211072",
    "text" : "You never know what another person is going through. Please keep that in mind as you go through your day, and be kind without bias.",
    "id" : 340479193710211072,
    "created_at" : "2013-05-31 14:45:40 +0000",
    "user" : {
      "name" : "Annamatopoeia",
      "screen_name" : "annamac84",
      "protected" : false,
      "id_str" : "24010252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776576049899528192\/ukxJR-E5_normal.jpg",
      "id" : 24010252,
      "verified" : false
    }
  },
  "id" : 340481679737098241,
  "created_at" : "2013-05-31 14:55:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "skullpuppy",
      "screen_name" : "skullpuppy11",
      "indices" : [ 3, 16 ],
      "id_str" : "216258307",
      "id" : 216258307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340481305546465281",
  "text" : "RT @skullpuppy11: My last words will probably be \"I wonder what this button does?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192429556714586113",
    "text" : "My last words will probably be \"I wonder what this button does?\"",
    "id" : 192429556714586113,
    "created_at" : "2012-04-18 01:49:16 +0000",
    "user" : {
      "name" : "skullpuppy",
      "screen_name" : "skullpuppy11",
      "protected" : false,
      "id_str" : "216258307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501172806806409217\/AZog7jTg_normal.jpeg",
      "id" : 216258307,
      "verified" : false
    }
  },
  "id" : 340481305546465281,
  "created_at" : "2013-05-31 14:54:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 17, 32 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JulianneGarska\/status\/340479301164081153\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/uRFCDNDqyR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLmgHtfCIAAPrPS.jpg",
      "id_str" : "340479301172469760",
      "id" : 340479301172469760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLmgHtfCIAAPrPS.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/uRFCDNDqyR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340479301164081153",
  "geo" : { },
  "id_str" : "340481029548683264",
  "in_reply_to_user_id" : 75708394,
  "text" : "awesome tree! RT @JulianneGarska Big tree. http:\/\/t.co\/uRFCDNDqyR",
  "id" : 340481029548683264,
  "in_reply_to_status_id" : 340479301164081153,
  "created_at" : "2013-05-31 14:52:57 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 2, 15 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogsarelove",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340476834552639489",
  "geo" : { },
  "id_str" : "340477764668895233",
  "in_reply_to_user_id" : 29913475,
  "text" : ". @grouchypuppy dog spelled backward... ; ) #dogsarelove",
  "id" : 340477764668895233,
  "in_reply_to_status_id" : 340476834552639489,
  "created_at" : "2013-05-31 14:39:59 +0000",
  "in_reply_to_screen_name" : "grouchypuppy",
  "in_reply_to_user_id_str" : "29913475",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 2, 18 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340468046680453121",
  "geo" : { },
  "id_str" : "340477303014440962",
  "in_reply_to_user_id" : 140060120,
  "text" : ". @davidpakmanshow bryan fischer is a twat.. a very big twat.",
  "id" : 340477303014440962,
  "in_reply_to_status_id" : 340468046680453121,
  "created_at" : "2013-05-31 14:38:09 +0000",
  "in_reply_to_screen_name" : "davidpakmanshow",
  "in_reply_to_user_id_str" : "140060120",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 3, 18 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340476616721432576",
  "text" : "RT @JulianneGarska: I did get a photo of the Swan flying by me.  I think this is the first.  The second time was closer and over my head. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JulianneGarska\/status\/340475297570885632\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/40BkVw7pkU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLmceq7CEAISlxC.jpg",
        "id_str" : "340475297575079938",
        "id" : 340475297575079938,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLmceq7CEAISlxC.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/40BkVw7pkU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340475297570885632",
    "text" : "I did get a photo of the Swan flying by me.  I think this is the first.  The second time was closer and over my head. http:\/\/t.co\/40BkVw7pkU",
    "id" : 340475297570885632,
    "created_at" : "2013-05-31 14:30:11 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 340476616721432576,
  "created_at" : "2013-05-31 14:35:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340473687373385729",
  "geo" : { },
  "id_str" : "340474794690629632",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 we've got raccoons and they tend to take over and sometimes return when i refill dish for possum.",
  "id" : 340474794690629632,
  "in_reply_to_status_id" : 340473687373385729,
  "created_at" : "2013-05-31 14:28:11 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340473687373385729",
  "geo" : { },
  "id_str" : "340474191595839488",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 lol.. me, too. but i've developed a great fondness for possums past few years. so gentle, quiet, just waddling along..lol",
  "id" : 340474191595839488,
  "in_reply_to_status_id" : 340473687373385729,
  "created_at" : "2013-05-31 14:25:47 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340472484656730112",
  "geo" : { },
  "id_str" : "340473210489417730",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater omg.. how intrusive.",
  "id" : 340473210489417730,
  "in_reply_to_status_id" : 340472484656730112,
  "created_at" : "2013-05-31 14:21:53 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340467328397500416",
  "text" : "im neurotic about making sure possum gets his share. last night was circus.",
  "id" : 340467328397500416,
  "created_at" : "2013-05-31 13:58:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340459503478796290",
  "geo" : { },
  "id_str" : "340465935964057600",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska nice!!",
  "id" : 340465935964057600,
  "in_reply_to_status_id" : 340459503478796290,
  "created_at" : "2013-05-31 13:52:59 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Minor",
      "screen_name" : "BrightMoments",
      "indices" : [ 3, 17 ],
      "id_str" : "15999336",
      "id" : 15999336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340465526822285313",
  "text" : "RT @BrightMoments: \"You are the only mystery worth solving\" ~ Doctor Who",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339836639113277441",
    "text" : "\"You are the only mystery worth solving\" ~ Doctor Who",
    "id" : 339836639113277441,
    "created_at" : "2013-05-29 20:12:23 +0000",
    "user" : {
      "name" : "A.Minor",
      "screen_name" : "BrightMoments",
      "protected" : false,
      "id_str" : "15999336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798182900923584512\/Af6QWVfO_normal.jpg",
      "id" : 15999336,
      "verified" : false
    }
  },
  "id" : 340465526822285313,
  "created_at" : "2013-05-31 13:51:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340461558205411328",
  "geo" : { },
  "id_str" : "340465453740744704",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow you're torturing me..lol. love all those windows!",
  "id" : 340465453740744704,
  "in_reply_to_status_id" : 340461558205411328,
  "created_at" : "2013-05-31 13:51:04 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340211220240007168",
  "geo" : { },
  "id_str" : "340212628586627072",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny mocha.. yum!",
  "id" : 340212628586627072,
  "in_reply_to_status_id" : 340211220240007168,
  "created_at" : "2013-05-30 21:06:26 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340212318518509568",
  "text" : "RT @ChrisCapparell: or choosing to forget, that at the end of the game, the kings and the pawns return to the same box. [2\/2]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.anacoder.com\" rel=\"nofollow\"\u003EFat Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340211966993920000",
    "text" : "or choosing to forget, that at the end of the game, the kings and the pawns return to the same box. [2\/2]",
    "id" : 340211966993920000,
    "created_at" : "2013-05-30 21:03:48 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 340212318518509568,
  "created_at" : "2013-05-30 21:05:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340212302164930560",
  "text" : "RT @ChrisCapparell: Just as a dream is only real while you're asleep, life is only real while you're alive. You control reality by choosing\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.anacoder.com\" rel=\"nofollow\"\u003EFat Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340211964045324288",
    "text" : "Just as a dream is only real while you're asleep, life is only real while you're alive. You control reality by choosing to remember, [1\/2]",
    "id" : 340211964045324288,
    "created_at" : "2013-05-30 21:03:47 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 340212302164930560,
  "created_at" : "2013-05-30 21:05:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339851804827328512",
  "text" : "RT @micahjmurray: \"Fundamentalism isn\u2019t so much a set of beliefs as a sense of inflexibility in terms of how those beliefs are held.\" -@Kev\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Miller",
        "screen_name" : "KevinMillerXI",
        "indices" : [ 117, 131 ],
        "id_str" : "1402772510",
        "id" : 1402772510
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339848701419876353",
    "text" : "\"Fundamentalism isn\u2019t so much a set of beliefs as a sense of inflexibility in terms of how those beliefs are held.\" -@KevinMillerXI",
    "id" : 339848701419876353,
    "created_at" : "2013-05-29 21:00:19 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 339851804827328512,
  "created_at" : "2013-05-29 21:12:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339828408290775040",
  "text" : "RT @JeremyCShipp: I don't have a panic room but I do have a freak out area under my blanket.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339827437137444867",
    "text" : "I don't have a panic room but I do have a freak out area under my blanket.",
    "id" : 339827437137444867,
    "created_at" : "2013-05-29 19:35:49 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 339828408290775040,
  "created_at" : "2013-05-29 19:39:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.wildfireapp.com\/?utm_source=Twitter&utm_medium=Tweet&utm_campaign=via%2BWildfire%2BSuite\" rel=\"nofollow\"\u003EWildfire Suite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/oxo7uGQHVH",
      "expanded_url" : "http:\/\/wfi.re\/uiqyj",
      "display_url" : "wfi.re\/uiqyj"
    } ]
  },
  "geo" : { },
  "id_str" : "339828030115553280",
  "text" : "I entered the Erin Healy's \"Afloat\" Giveaway for a chance to win an iPad Mini!: http:\/\/t.co\/oxo7uGQHVH",
  "id" : 339828030115553280,
  "created_at" : "2013-05-29 19:38:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 122, 135 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339826241785966592",
  "text" : "@BibleAlsoSays hmm.. i disagree. i see them same as fundy xtians. my motto is live and let live. kindness is my religion. @SisterSadist",
  "id" : 339826241785966592,
  "created_at" : "2013-05-29 19:31:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 84, 98 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339825035944534017",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist i'd say he seems to be thinking of a small group of militant atheists @BibleAlsoSays",
  "id" : 339825035944534017,
  "created_at" : "2013-05-29 19:26:16 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 76, 89 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339823585151569920",
  "text" : "@BibleAlsoSays it really is just a ride. and ppl take it way too seriously. @SisterSadist",
  "id" : 339823585151569920,
  "created_at" : "2013-05-29 19:20:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 53, 66 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339823104027160576",
  "text" : "@BibleAlsoSays i will never grow up. its all misery. @SisterSadist",
  "id" : 339823104027160576,
  "created_at" : "2013-05-29 19:18:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339784452806946816",
  "text" : "RT @TheDailyHug: Just when you think there may be no hope - hope shows up with a giant hug and a way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339784052641001474",
    "text" : "Just when you think there may be no hope - hope shows up with a giant hug and a way.",
    "id" : 339784052641001474,
    "created_at" : "2013-05-29 16:43:25 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 339784452806946816,
  "created_at" : "2013-05-29 16:45:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 0, 12 ],
      "id_str" : "16691399",
      "id" : 16691399
    }, {
      "name" : "eReaderIQ",
      "screen_name" : "eReaderIQ",
      "indices" : [ 55, 65 ],
      "id_str" : "153435359",
      "id" : 153435359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paperwhite",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339778603992633345",
  "geo" : { },
  "id_str" : "339780494403182593",
  "in_reply_to_user_id" : 16691399,
  "text" : "@fearfuldogs love my kindle #paperwhite .. big plus is @eReaderIQ which i use to track books i want.",
  "id" : 339780494403182593,
  "in_reply_to_status_id" : 339778603992633345,
  "created_at" : "2013-05-29 16:29:17 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Ovc4QSwO8S",
      "expanded_url" : "http:\/\/www.nybooks.com\/articles\/archives\/2013\/jun\/06\/time-regained\/?page=2#.UaYqxqFHtLA.twitter",
      "display_url" : "nybooks.com\/articles\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339778479291768832",
  "text" : "\"Our senses tell us all sorts of lies.\" Time Regained! by James Gleick  http:\/\/t.co\/Ovc4QSwO8S",
  "id" : 339778479291768832,
  "created_at" : "2013-05-29 16:21:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339775455114706945",
  "geo" : { },
  "id_str" : "339775754684465153",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides bug me",
  "id" : 339775754684465153,
  "in_reply_to_status_id" : 339775455114706945,
  "created_at" : "2013-05-29 16:10:27 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 3, 17 ],
      "id_str" : "112762057",
      "id" : 112762057
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 81, 90 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Books",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/nV60k4YtZj",
      "expanded_url" : "http:\/\/ow.ly\/lvAMy",
      "display_url" : "ow.ly\/lvAMy"
    } ]
  },
  "geo" : { },
  "id_str" : "339774183309447168",
  "text" : "RT @loveofreading: 25 Signs You\u2019re Addicted To #Books http:\/\/t.co\/nV60k4YtZj via @buzzfeed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 62, 71 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Books",
        "indices" : [ 28, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/nV60k4YtZj",
        "expanded_url" : "http:\/\/ow.ly\/lvAMy",
        "display_url" : "ow.ly\/lvAMy"
      } ]
    },
    "geo" : { },
    "id_str" : "339772178641854464",
    "text" : "25 Signs You\u2019re Addicted To #Books http:\/\/t.co\/nV60k4YtZj via @buzzfeed",
    "id" : 339772178641854464,
    "created_at" : "2013-05-29 15:56:14 +0000",
    "user" : {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "protected" : false,
      "id_str" : "112762057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/807514027\/loricon2_normal.jpg",
      "id" : 112762057,
      "verified" : false
    }
  },
  "id" : 339774183309447168,
  "created_at" : "2013-05-29 16:04:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339768855893258240",
  "geo" : { },
  "id_str" : "339771562163064832",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray a result of our stressful, fear-based society...",
  "id" : 339771562163064832,
  "in_reply_to_status_id" : 339768855893258240,
  "created_at" : "2013-05-29 15:53:47 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339770640691249152",
  "text" : "what is love? what is humor? can it be measured? how do they work?",
  "id" : 339770640691249152,
  "created_at" : "2013-05-29 15:50:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 52, 65 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/hCeyiDlq4h",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B00CJUMT2G\/ref=cm_sw_r_tw_ask_P9WdF.1N80A29",
      "display_url" : "amazon.com\/dp\/B00CJUMT2G\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339770178558636032",
  "text" : "I just bought: 'Plato Blinked' by Heather Pioro via @amazonkindle http:\/\/t.co\/hCeyiDlq4h",
  "id" : 339770178558636032,
  "created_at" : "2013-05-29 15:48:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339769859531489280",
  "text" : "RT @parkstepp: \u201CHumor allows us to see that ultimately things don\u2019t make sense. The only thing that truly makes sense is\u2026\u201D http:\/\/t.co\/hiMH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/hiMHsdIrM5",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNym6PMW4",
        "display_url" : "tmblr.co\/ZwrrNym6PMW4"
      } ]
    },
    "geo" : { },
    "id_str" : "339766431057059841",
    "text" : "\u201CHumor allows us to see that ultimately things don\u2019t make sense. The only thing that truly makes sense is\u2026\u201D http:\/\/t.co\/hiMHsdIrM5",
    "id" : 339766431057059841,
    "created_at" : "2013-05-29 15:33:24 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 339769859531489280,
  "created_at" : "2013-05-29 15:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339514706396065792",
  "geo" : { },
  "id_str" : "339526827641016321",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 take it easy.. maybe some nice tea. feel better.",
  "id" : 339526827641016321,
  "in_reply_to_status_id" : 339514706396065792,
  "created_at" : "2013-05-28 23:41:18 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/bkOvxSVBU5",
      "expanded_url" : "http:\/\/gawker.com\/teacher-in-trouble-for-telling-kids-they-can-skip-drug-510084832",
      "display_url" : "gawker.com\/teacher-in-tro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339478839833010177",
  "text" : "Teacher In Trouble for Telling Kids They Can Skip Drug Use Q's on Test http:\/\/t.co\/bkOvxSVBU5",
  "id" : 339478839833010177,
  "created_at" : "2013-05-28 20:30:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 3, 18 ],
      "id_str" : "17376893",
      "id" : 17376893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BE0bfycM9O",
      "expanded_url" : "http:\/\/bit.ly\/118n40H",
      "display_url" : "bit.ly\/118n40H"
    } ]
  },
  "geo" : { },
  "id_str" : "339475855468273665",
  "text" : "RT @RightWingWatch: Rick Perry warns Boy Scouts leaders will \"be held accountable\" by God for approving gay members http:\/\/t.co\/BE0bfycM9O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/BE0bfycM9O",
        "expanded_url" : "http:\/\/bit.ly\/118n40H",
        "display_url" : "bit.ly\/118n40H"
      } ]
    },
    "geo" : { },
    "id_str" : "339452052994408448",
    "text" : "Rick Perry warns Boy Scouts leaders will \"be held accountable\" by God for approving gay members http:\/\/t.co\/BE0bfycM9O",
    "id" : 339452052994408448,
    "created_at" : "2013-05-28 18:44:10 +0000",
    "user" : {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "protected" : false,
      "id_str" : "17376893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64767765\/rww-twitter130_normal.jpg",
      "id" : 17376893,
      "verified" : false
    }
  },
  "id" : 339475855468273665,
  "created_at" : "2013-05-28 20:18:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339475080641908737",
  "text" : "RT @PNHP: The poorest in the US will remain uninsured and without access to care, thanks to states opting out of Medicaid: http:\/\/t.co\/0dq9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/0dq9aLZRUR",
        "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/may\/millions-of-the-poorest-will-remain-uninsured",
        "display_url" : "pnhp.org\/news\/2013\/may\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339468500336795650",
    "text" : "The poorest in the US will remain uninsured and without access to care, thanks to states opting out of Medicaid: http:\/\/t.co\/0dq9aLZRUR",
    "id" : 339468500336795650,
    "created_at" : "2013-05-28 19:49:32 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 339475080641908737,
  "created_at" : "2013-05-28 20:15:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chirpit",
      "screen_name" : "chirpit",
      "indices" : [ 77, 85 ],
      "id_str" : "15173602",
      "id" : 15173602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/nD4hJxY9pn",
      "expanded_url" : "http:\/\/www.chirpit.co?lrRef=ucodM",
      "display_url" : "chirpit.co\/?lrRef=ucodM"
    } ]
  },
  "geo" : { },
  "id_str" : "339461829052997632",
  "text" : "App helps bird watchers identify birds by Sound.  http:\/\/t.co\/nD4hJxY9pn via @ChirpIt",
  "id" : 339461829052997632,
  "created_at" : "2013-05-28 19:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 49, 62 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/FLTDXUHUs5",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B003QCIPGK\/ref=cm_sw_r_tw_ask_EYzcF.0J6JD5Y",
      "display_url" : "amazon.com\/dp\/B003QCIPGK\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339175323251912704",
  "text" : "I just bought: 'Half Way Home' by Hugh Howey via @amazonkindle http:\/\/t.co\/FLTDXUHUs5",
  "id" : 339175323251912704,
  "created_at" : "2013-05-28 00:24:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 50, 60 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/QSidp7Qjay",
      "expanded_url" : "http:\/\/shar.es\/ZM5UQ",
      "display_url" : "shar.es\/ZM5UQ"
    } ]
  },
  "geo" : { },
  "id_str" : "339172407774412802",
  "text" : "Information Overload!\n http:\/\/t.co\/QSidp7Qjay via @sharethis",
  "id" : 339172407774412802,
  "created_at" : "2013-05-28 00:12:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 3, 17 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 19, 34 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339059557886201856",
  "text" : "RT @allthewayleft: @AnnotatedBible We don't. You've discovered the awful secret: We are all in The Matrix.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/gleek.liquiddaffodil.com\" rel=\"nofollow\"\u003Egl\u018F\u018Fk!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FusionTheism.com",
        "screen_name" : "AnnotatedBible",
        "indices" : [ 0, 15 ],
        "id_str" : "242204735",
        "id" : 242204735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "339042146181083137",
    "geo" : { },
    "id_str" : "339058760683245568",
    "in_reply_to_user_id" : 242204735,
    "text" : "@AnnotatedBible We don't. You've discovered the awful secret: We are all in The Matrix.",
    "id" : 339058760683245568,
    "in_reply_to_status_id" : 339042146181083137,
    "created_at" : "2013-05-27 16:41:22 +0000",
    "in_reply_to_screen_name" : "AnnotatedBible",
    "in_reply_to_user_id_str" : "242204735",
    "user" : {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "protected" : false,
      "id_str" : "345207173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000852111499\/8d917b25d9062fc1d0af08d0f98ccd71_normal.jpeg",
      "id" : 345207173,
      "verified" : false
    }
  },
  "id" : 339059557886201856,
  "created_at" : "2013-05-27 16:44:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/5JaCukwfWc",
      "expanded_url" : "http:\/\/amzn.to\/RTpdXa",
      "display_url" : "amzn.to\/RTpdXa"
    } ]
  },
  "geo" : { },
  "id_str" : "338852313013817344",
  "text" : "finished The Blessed and the Damned (Righteous Series #4) by Michael Wallace http:\/\/t.co\/5JaCukwfWc",
  "id" : 338852313013817344,
  "created_at" : "2013-05-27 03:01:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Vjy0CD46sh",
      "expanded_url" : "http:\/\/www.trishascott.com\/my-feet-the-headless-way\/",
      "display_url" : "trishascott.com\/my-feet-the-he\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338845915077038080",
  "text" : "My Feet &amp; The Headless Way http:\/\/t.co\/Vjy0CD46sh",
  "id" : 338845915077038080,
  "created_at" : "2013-05-27 02:35:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 52, 65 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/XMfCTA4YqI",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B00A7X0RQM\/ref=cm_sw_r_tw_ask_5UfcF.0HAGSC6",
      "display_url" : "amazon.com\/dp\/B00A7X0RQM\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338831451598495744",
  "text" : "I just bought: 'The Body Departed' by J.R. Rain via @amazonkindle  http:\/\/t.co\/XMfCTA4YqI",
  "id" : 338831451598495744,
  "created_at" : "2013-05-27 01:38:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/xdOVxVfmyA",
      "expanded_url" : "http:\/\/ow.ly\/lmsRX",
      "display_url" : "ow.ly\/lmsRX"
    } ]
  },
  "geo" : { },
  "id_str" : "338660067555557378",
  "text" : "RT @davidpakmanshow: Judge gets sentenced for selling children to private prisons. 28 years. Enough time? http:\/\/t.co\/xdOVxVfmyA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xdOVxVfmyA",
        "expanded_url" : "http:\/\/ow.ly\/lmsRX",
        "display_url" : "ow.ly\/lmsRX"
      } ]
    },
    "geo" : { },
    "id_str" : "338656555245375488",
    "text" : "Judge gets sentenced for selling children to private prisons. 28 years. Enough time? http:\/\/t.co\/xdOVxVfmyA",
    "id" : 338656555245375488,
    "created_at" : "2013-05-26 14:03:09 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 338660067555557378,
  "created_at" : "2013-05-26 14:17:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338636830683582464",
  "geo" : { },
  "id_str" : "338658665366163456",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow im jealous ; )",
  "id" : 338658665366163456,
  "in_reply_to_status_id" : 338636830683582464,
  "created_at" : "2013-05-26 14:11:32 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338647175875661826",
  "geo" : { },
  "id_str" : "338656361237843968",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny LOL.. even zombies can outrun me..lolol",
  "id" : 338656361237843968,
  "in_reply_to_status_id" : 338647175875661826,
  "created_at" : "2013-05-26 14:02:23 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "Sky_Meadows_State_Park_VA",
      "indices" : [ 89, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Y5StWeDgLa",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/15498",
      "display_url" : "wildobs.com\/wo\/15498"
    } ]
  },
  "geo" : { },
  "id_str" : "338479770272669697",
  "text" : "RT @wildobs: For the late crowd: Eastern Bluebird http:\/\/t.co\/Y5StWeDgLa #EOTD #wildlife #Sky_Meadows_State_Park_VA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 60, 65 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "Sky_Meadows_State_Park_VA",
        "indices" : [ 76, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/Y5StWeDgLa",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/15498",
        "display_url" : "wildobs.com\/wo\/15498"
      } ]
    },
    "geo" : { },
    "id_str" : "338477376725987329",
    "text" : "For the late crowd: Eastern Bluebird http:\/\/t.co\/Y5StWeDgLa #EOTD #wildlife #Sky_Meadows_State_Park_VA",
    "id" : 338477376725987329,
    "created_at" : "2013-05-26 02:11:09 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 338479770272669697,
  "created_at" : "2013-05-26 02:20:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UltraRob",
      "screen_name" : "UltraRob",
      "indices" : [ 3, 12 ],
      "id_str" : "12099472",
      "id" : 12099472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/UhBks1XNjd",
      "expanded_url" : "http:\/\/twitpic.com\/ct8be3",
      "display_url" : "twitpic.com\/ct8be3"
    } ]
  },
  "geo" : { },
  "id_str" : "338474923423039488",
  "text" : "RT @UltraRob: Moose in Rocky Mountain National Park http:\/\/t.co\/UhBks1XNjd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/UhBks1XNjd",
        "expanded_url" : "http:\/\/twitpic.com\/ct8be3",
        "display_url" : "twitpic.com\/ct8be3"
      } ]
    },
    "geo" : { },
    "id_str" : "338470799738560512",
    "text" : "Moose in Rocky Mountain National Park http:\/\/t.co\/UhBks1XNjd",
    "id" : 338470799738560512,
    "created_at" : "2013-05-26 01:45:01 +0000",
    "user" : {
      "name" : "UltraRob",
      "screen_name" : "UltraRob",
      "protected" : false,
      "id_str" : "12099472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2562897379\/i2zll6hfabmi2k38tbsk_normal.jpeg",
      "id" : 12099472,
      "verified" : false
    }
  },
  "id" : 338474923423039488,
  "created_at" : "2013-05-26 02:01:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aetna",
      "indices" : [ 57, 63 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 112, 124 ]
    }, {
      "text" : "HCR",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338459173715062784",
  "text" : "RT @AllOnMedicare: If you made $47 MILLION\/year like the #Aetna CEO, wouldn't you try and scare Americans about #SinglePayer and #HCR, too?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Aetna",
        "indices" : [ 38, 44 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 93, 105 ]
      }, {
        "text" : "HCR",
        "indices" : [ 110, 114 ]
      }, {
        "text" : "p2",
        "indices" : [ 121, 124 ]
      }, {
        "text" : "PublicOption",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338453764212150273",
    "text" : "If you made $47 MILLION\/year like the #Aetna CEO, wouldn't you try and scare Americans about #SinglePayer and #HCR, too? #p2 #PublicOption",
    "id" : 338453764212150273,
    "created_at" : "2013-05-26 00:37:20 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 338459173715062784,
  "created_at" : "2013-05-26 00:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338459112364969984",
  "text" : "RT @AllOnMedicare: In America, those who can least afford to pay for health care pay the most. The rich pay the least with the best insuran\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 124, 136 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338453148496699392",
    "text" : "In America, those who can least afford to pay for health care pay the most. The rich pay the least with the best insurance. #SinglePayer #p2",
    "id" : 338453148496699392,
    "created_at" : "2013-05-26 00:34:53 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 338459112364969984,
  "created_at" : "2013-05-26 00:58:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/e897yHDtiw",
      "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/may\/cruelty-or-care-the-choice-is-yours#.UaFZ5paeW40.twitter",
      "display_url" : "pnhp.org\/news\/2013\/may\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338458849491173376",
  "text" : "RT @AllOnMedicare: Cruelty or Care? The Choice is Yours | Physicians for a National Health Program http:\/\/t.co\/e897yHDtiw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/e897yHDtiw",
        "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/may\/cruelty-or-care-the-choice-is-yours#.UaFZ5paeW40.twitter",
        "display_url" : "pnhp.org\/news\/2013\/may\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "338454528464670720",
    "text" : "Cruelty or Care? The Choice is Yours | Physicians for a National Health Program http:\/\/t.co\/e897yHDtiw",
    "id" : 338454528464670720,
    "created_at" : "2013-05-26 00:40:22 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 338458849491173376,
  "created_at" : "2013-05-26 00:57:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senryu",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338458520842285056",
  "text" : "RT @CoyoteSings: the hiss of the downtown bus \u2022 as it curtsies \u2022 to say hello | #senryu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "senryu",
        "indices" : [ 63, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338454583158386689",
    "text" : "the hiss of the downtown bus \u2022 as it curtsies \u2022 to say hello | #senryu",
    "id" : 338454583158386689,
    "created_at" : "2013-05-26 00:40:35 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 338458520842285056,
  "created_at" : "2013-05-26 00:56:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aetna",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 117, 129 ]
    }, {
      "text" : "p2",
      "indices" : [ 130, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338457846767300608",
  "text" : "RT @AllOnMedicare: The CEO of #Aetna made $47 MILLION last year, but YOU need to pay higher co-pays and deductibles. #SinglePayer #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Aetna",
        "indices" : [ 11, 17 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 98, 110 ]
      }, {
        "text" : "p2",
        "indices" : [ 111, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338452318578167808",
    "text" : "The CEO of #Aetna made $47 MILLION last year, but YOU need to pay higher co-pays and deductibles. #SinglePayer #p2",
    "id" : 338452318578167808,
    "created_at" : "2013-05-26 00:31:35 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 338457846767300608,
  "created_at" : "2013-05-26 00:53:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338448993497522176",
  "text" : "RT @CoyoteSings: The *average* CEO brings home $9.7m\/year, approximately $26,575 a *day*. Poverty level is $24K\/year.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338446776241618944",
    "text" : "The *average* CEO brings home $9.7m\/year, approximately $26,575 a *day*. Poverty level is $24K\/year.",
    "id" : 338446776241618944,
    "created_at" : "2013-05-26 00:09:34 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 338448993497522176,
  "created_at" : "2013-05-26 00:18:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lena Dunham",
      "screen_name" : "lenadunham",
      "indices" : [ 3, 14 ],
      "id_str" : "31080039",
      "id" : 31080039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338446160429723648",
  "text" : "RT @lenadunham: It is my sincerest hope that the act of dying feels like finally peeing after a long bumpy car ride.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338425517235634177",
    "text" : "It is my sincerest hope that the act of dying feels like finally peeing after a long bumpy car ride.",
    "id" : 338425517235634177,
    "created_at" : "2013-05-25 22:45:05 +0000",
    "user" : {
      "name" : "Lena Dunham",
      "screen_name" : "lenadunham",
      "protected" : false,
      "id_str" : "31080039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776012272116391936\/d82w5wgI_normal.jpg",
      "id" : 31080039,
      "verified" : true
    }
  },
  "id" : 338446160429723648,
  "created_at" : "2013-05-26 00:07:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 0, 10 ],
      "id_str" : "574554751",
      "id" : 574554751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338355165927178243",
  "geo" : { },
  "id_str" : "338371997241319424",
  "in_reply_to_user_id" : 574554751,
  "text" : "@CosmoTyme awwww...",
  "id" : 338371997241319424,
  "in_reply_to_status_id" : 338355165927178243,
  "created_at" : "2013-05-25 19:12:25 +0000",
  "in_reply_to_screen_name" : "CosmoTyme",
  "in_reply_to_user_id_str" : "574554751",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "birds",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/sLg2LKRP1e",
      "expanded_url" : "http:\/\/goo.gl\/BQw6S",
      "display_url" : "goo.gl\/BQw6S"
    } ]
  },
  "geo" : { },
  "id_str" : "338371018534027265",
  "text" : "RT @KerriFar: A Very Wet Dove ~ http:\/\/t.co\/sLg2LKRP1e ~ #nature #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 43, 50 ]
      }, {
        "text" : "birds",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/sLg2LKRP1e",
        "expanded_url" : "http:\/\/goo.gl\/BQw6S",
        "display_url" : "goo.gl\/BQw6S"
      } ]
    },
    "geo" : { },
    "id_str" : "338365485152358401",
    "text" : "A Very Wet Dove ~ http:\/\/t.co\/sLg2LKRP1e ~ #nature #birds",
    "id" : 338365485152358401,
    "created_at" : "2013-05-25 18:46:32 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 338371018534027265,
  "created_at" : "2013-05-25 19:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    }, {
      "name" : "Charlotte BizJournal",
      "screen_name" : "CBJnewsroom",
      "indices" : [ 26, 38 ],
      "id_str" : "23783609",
      "id" : 23783609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338334209385046017",
  "text" : "RT @PNHP: #SinglePayer RT @CBJnewsroom: Economist: NC could save $18.7B by adopting single-payer model for health care: http:\/\/t.co\/PM3REl5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlotte BizJournal",
        "screen_name" : "CBJnewsroom",
        "indices" : [ 16, 28 ],
        "id_str" : "23783609",
        "id" : 23783609
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/PM3REl5o8b",
        "expanded_url" : "http:\/\/dlvr.it\/3QMjJn",
        "display_url" : "dlvr.it\/3QMjJn"
      } ]
    },
    "geo" : { },
    "id_str" : "338016875193716736",
    "text" : "#SinglePayer RT @CBJnewsroom: Economist: NC could save $18.7B by adopting single-payer model for health care: http:\/\/t.co\/PM3REl5o8b",
    "id" : 338016875193716736,
    "created_at" : "2013-05-24 19:41:17 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 338334209385046017,
  "created_at" : "2013-05-25 16:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FCC",
      "indices" : [ 106, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338328240563302400",
  "text" : "RT @SenSanders: In 1983, 50 corporations controlled a majority of American media. Now that number is six. #FCC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FCC",
        "indices" : [ 90, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338327609383469056",
    "text" : "In 1983, 50 corporations controlled a majority of American media. Now that number is six. #FCC",
    "id" : 338327609383469056,
    "created_at" : "2013-05-25 16:16:02 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 338328240563302400,
  "created_at" : "2013-05-25 16:18:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338294552353964034",
  "text" : "@Skeptical_Lady thats really interesting...",
  "id" : 338294552353964034,
  "created_at" : "2013-05-25 14:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KanyeTwitty",
      "screen_name" : "10uhseejed",
      "indices" : [ 0, 11 ],
      "id_str" : "1284299556",
      "id" : 1284299556
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 60, 72 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338131319613702144",
  "geo" : { },
  "id_str" : "338293267319889920",
  "in_reply_to_user_id" : 1284299556,
  "text" : "@10uhseejed that he thinks he used to be gay and now is not @VirgoJohnny",
  "id" : 338293267319889920,
  "in_reply_to_status_id" : 338131319613702144,
  "created_at" : "2013-05-25 13:59:34 +0000",
  "in_reply_to_screen_name" : "10uhseejed",
  "in_reply_to_user_id_str" : "1284299556",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 0, 10 ],
      "id_str" : "574554751",
      "id" : 574554751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338096016031096832",
  "geo" : { },
  "id_str" : "338099872890761216",
  "in_reply_to_user_id" : 574554751,
  "text" : "@CosmoTyme awesome!",
  "id" : 338099872890761216,
  "in_reply_to_status_id" : 338096016031096832,
  "created_at" : "2013-05-25 01:11:05 +0000",
  "in_reply_to_screen_name" : "CosmoTyme",
  "in_reply_to_user_id_str" : "574554751",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 0, 10 ],
      "id_str" : "574554751",
      "id" : 574554751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338096604647129088",
  "geo" : { },
  "id_str" : "338099643713982464",
  "in_reply_to_user_id" : 574554751,
  "text" : "@CosmoTyme does she have attitude cuz she looks like it..lol. beautiful baby.",
  "id" : 338099643713982464,
  "in_reply_to_status_id" : 338096604647129088,
  "created_at" : "2013-05-25 01:10:11 +0000",
  "in_reply_to_screen_name" : "CosmoTyme",
  "in_reply_to_user_id_str" : "574554751",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338090043031842818",
  "geo" : { },
  "id_str" : "338096834872496129",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist ..and you are very sweet. : )",
  "id" : 338096834872496129,
  "in_reply_to_status_id" : 338090043031842818,
  "created_at" : "2013-05-25 00:59:01 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/SliU8CxFIK",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=149361288585409&set=a.140280772826794.1073741827.139911216197083&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338095171868700672",
  "text" : "RT @DwayneReaves: Huge moon tonight https:\/\/t.co\/SliU8CxFIK #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 42, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/SliU8CxFIK",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=149361288585409&set=a.140280772826794.1073741827.139911216197083&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "338094779009232897",
    "text" : "Huge moon tonight https:\/\/t.co\/SliU8CxFIK #photo",
    "id" : 338094779009232897,
    "created_at" : "2013-05-25 00:50:51 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 338095171868700672,
  "created_at" : "2013-05-25 00:52:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338087871451906048",
  "geo" : { },
  "id_str" : "338088662485041152",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist not mine...",
  "id" : 338088662485041152,
  "in_reply_to_status_id" : 338087871451906048,
  "created_at" : "2013-05-25 00:26:33 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338088079510351872",
  "text" : "@KevinRDaugherty thats what i consider myself but i dont say it cuz it sounds condescending.",
  "id" : 338088079510351872,
  "created_at" : "2013-05-25 00:24:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "KanyeTwitty",
      "screen_name" : "10uhseejed",
      "indices" : [ 26, 37 ],
      "id_str" : "1284299556",
      "id" : 1284299556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338085724920365056",
  "geo" : { },
  "id_str" : "338087623518199810",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny thats sad... @10uhseejed",
  "id" : 338087623518199810,
  "in_reply_to_status_id" : 338085724920365056,
  "created_at" : "2013-05-25 00:22:25 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doubt",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/y8iPGsxDJY",
      "expanded_url" : "http:\/\/tinyurl.com\/79tzvxz",
      "display_url" : "tinyurl.com\/79tzvxz"
    } ]
  },
  "geo" : { },
  "id_str" : "338055581522862080",
  "text" : "RT @Soulseedzforall: Trust the process of your #doubt. http:\/\/t.co\/y8iPGsxDJY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "doubt",
        "indices" : [ 26, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/y8iPGsxDJY",
        "expanded_url" : "http:\/\/tinyurl.com\/79tzvxz",
        "display_url" : "tinyurl.com\/79tzvxz"
      } ]
    },
    "geo" : { },
    "id_str" : "338054772764590080",
    "text" : "Trust the process of your #doubt. http:\/\/t.co\/y8iPGsxDJY",
    "id" : 338054772764590080,
    "created_at" : "2013-05-24 22:11:53 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 338055581522862080,
  "created_at" : "2013-05-24 22:15:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338054556548210690",
  "text" : "the bees are dying, the world is ending. let's have a party.",
  "id" : 338054556548210690,
  "created_at" : "2013-05-24 22:11:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338038643098787840",
  "text" : "RT @SoonerShoeGirl: I just rescued this guy from the middle-of-the-road, and now he is trying to get under my front seat.\u2026 http:\/\/t.co\/vVmz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/vVmzpoFKh7",
        "expanded_url" : "http:\/\/instagram.com\/p\/ZtWLp4pxUU\/",
        "display_url" : "instagram.com\/p\/ZtWLp4pxUU\/"
      } ]
    },
    "geo" : { },
    "id_str" : "338034704626380801",
    "text" : "I just rescued this guy from the middle-of-the-road, and now he is trying to get under my front seat.\u2026 http:\/\/t.co\/vVmzpoFKh7",
    "id" : 338034704626380801,
    "created_at" : "2013-05-24 20:52:08 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 338038643098787840,
  "created_at" : "2013-05-24 21:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bluebird",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "birds",
      "indices" : [ 73, 79 ]
    }, {
      "text" : "nature",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/TLFFIdnLax",
      "expanded_url" : "http:\/\/ow.ly\/lnwBp",
      "display_url" : "ow.ly\/lnwBp"
    } ]
  },
  "geo" : { },
  "id_str" : "338037847552573440",
  "text" : "RT @KerriFar: Carrying the Sky ~ http:\/\/t.co\/TLFFIdnLax  ~ A #bluebird ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bluebird",
        "indices" : [ 47, 56 ]
      }, {
        "text" : "birds",
        "indices" : [ 59, 65 ]
      }, {
        "text" : "nature",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/TLFFIdnLax",
        "expanded_url" : "http:\/\/ow.ly\/lnwBp",
        "display_url" : "ow.ly\/lnwBp"
      } ]
    },
    "geo" : { },
    "id_str" : "338028789164568577",
    "text" : "Carrying the Sky ~ http:\/\/t.co\/TLFFIdnLax  ~ A #bluebird ~ #birds #nature",
    "id" : 338028789164568577,
    "created_at" : "2013-05-24 20:28:38 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 338037847552573440,
  "created_at" : "2013-05-24 21:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338035904612536320",
  "text" : "RT @micahjmurray: To those who troll blogs, spewing Bible verses, condemning everyone as \u201CLIBERAL\u201D: You seem mean &amp; miserable. Why would I \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338032194071187456",
    "text" : "To those who troll blogs, spewing Bible verses, condemning everyone as \u201CLIBERAL\u201D: You seem mean &amp; miserable. Why would I want your religion?",
    "id" : 338032194071187456,
    "created_at" : "2013-05-24 20:42:10 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 338035904612536320,
  "created_at" : "2013-05-24 20:56:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "birds",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "nature",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/WvZ9mwqCPf",
      "expanded_url" : "http:\/\/ow.ly\/lnpZF",
      "display_url" : "ow.ly\/lnpZF"
    } ]
  },
  "geo" : { },
  "id_str" : "338035051801477120",
  "text" : "RT @KerriFar: #Bluebird couple   ~ http:\/\/t.co\/WvZ9mwqCPf  ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "birds",
        "indices" : [ 47, 53 ]
      }, {
        "text" : "nature",
        "indices" : [ 54, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/WvZ9mwqCPf",
        "expanded_url" : "http:\/\/ow.ly\/lnpZF",
        "display_url" : "ow.ly\/lnpZF"
      } ]
    },
    "geo" : { },
    "id_str" : "338033057711919104",
    "text" : "#Bluebird couple   ~ http:\/\/t.co\/WvZ9mwqCPf  ~ #birds #nature",
    "id" : 338033057711919104,
    "created_at" : "2013-05-24 20:45:35 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 338035051801477120,
  "created_at" : "2013-05-24 20:53:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moose",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "springbabies",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "alaska",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "nature",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/0jEOSx1Iik",
      "expanded_url" : "http:\/\/alaskanaturephotography.zenfolio.com\/p561146566\/e6944ffe7",
      "display_url" : "alaskanaturephotography.zenfolio.com\/p561146566\/e69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338016934320807938",
  "text" : "RT @Alaskachic907: Alaska Nature Photography | Moose | Image 1 http:\/\/t.co\/0jEOSx1Iik #moose #springbabies #wildlife ##alaska #nature #phot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moose",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "springbabies",
        "indices" : [ 74, 87 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "alaska",
        "indices" : [ 99, 106 ]
      }, {
        "text" : "nature",
        "indices" : [ 107, 114 ]
      }, {
        "text" : "photography",
        "indices" : [ 115, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/0jEOSx1Iik",
        "expanded_url" : "http:\/\/alaskanaturephotography.zenfolio.com\/p561146566\/e6944ffe7",
        "display_url" : "alaskanaturephotography.zenfolio.com\/p561146566\/e69\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "338014202973282304",
    "text" : "Alaska Nature Photography | Moose | Image 1 http:\/\/t.co\/0jEOSx1Iik #moose #springbabies #wildlife ##alaska #nature #photography",
    "id" : 338014202973282304,
    "created_at" : "2013-05-24 19:30:40 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 338016934320807938,
  "created_at" : "2013-05-24 19:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/OFLoF9rsdu",
      "expanded_url" : "http:\/\/bit.ly\/ZiZXlB",
      "display_url" : "bit.ly\/ZiZXlB"
    } ]
  },
  "geo" : { },
  "id_str" : "338010896720871424",
  "text" : "RT @FreeRangeKids: Dying, mentally competent people can now end their lives peacefully in VT: A human right! http:\/\/t.co\/OFLoF9rsdu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/OFLoF9rsdu",
        "expanded_url" : "http:\/\/bit.ly\/ZiZXlB",
        "display_url" : "bit.ly\/ZiZXlB"
      } ]
    },
    "geo" : { },
    "id_str" : "338010685491523584",
    "text" : "Dying, mentally competent people can now end their lives peacefully in VT: A human right! http:\/\/t.co\/OFLoF9rsdu",
    "id" : 338010685491523584,
    "created_at" : "2013-05-24 19:16:42 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 338010896720871424,
  "created_at" : "2013-05-24 19:17:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337990124849737728",
  "text" : ". @SamsaricWarrior i am quite different offline than online.. hardly a peep out of me offline! lol",
  "id" : 337990124849737728,
  "created_at" : "2013-05-24 17:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imgoinginsane",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337982018912653312",
  "text" : "again.. i need a job.. or a hobby. pref a job.. i like money : ) #imgoinginsane",
  "id" : 337982018912653312,
  "created_at" : "2013-05-24 17:22:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Paolini",
      "screen_name" : "paolini",
      "indices" : [ 3, 11 ],
      "id_str" : "404283614",
      "id" : 404283614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/vhI0jqc4ge",
      "expanded_url" : "http:\/\/io9.com\/the-first-image-ever-of-a-hydrogen-atoms-orbital-struc-509684901",
      "display_url" : "io9.com\/the-first-imag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337980604656271360",
  "text" : "RT @paolini: The first actual picture of an atom. This is AWESOME!!! http:\/\/t.co\/vhI0jqc4ge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/vhI0jqc4ge",
        "expanded_url" : "http:\/\/io9.com\/the-first-image-ever-of-a-hydrogen-atoms-orbital-struc-509684901",
        "display_url" : "io9.com\/the-first-imag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337975373230915584",
    "text" : "The first actual picture of an atom. This is AWESOME!!! http:\/\/t.co\/vhI0jqc4ge",
    "id" : 337975373230915584,
    "created_at" : "2013-05-24 16:56:22 +0000",
    "user" : {
      "name" : "Christopher Paolini",
      "screen_name" : "paolini",
      "protected" : false,
      "id_str" : "404283614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3144980726\/21e3bd9a7e8ab40a9e84f82b821e0ddc_normal.jpeg",
      "id" : 404283614,
      "verified" : true
    }
  },
  "id" : 337980604656271360,
  "created_at" : "2013-05-24 17:17:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337978255988633602",
  "geo" : { },
  "id_str" : "337979013786128384",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom i didn't even think of that!! my brain is so messed up..lol",
  "id" : 337979013786128384,
  "in_reply_to_status_id" : 337978255988633602,
  "created_at" : "2013-05-24 17:10:50 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337978172211617792",
  "geo" : { },
  "id_str" : "337978790917599232",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits ohh, nice!",
  "id" : 337978790917599232,
  "in_reply_to_status_id" : 337978172211617792,
  "created_at" : "2013-05-24 17:09:57 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337976488253091841",
  "geo" : { },
  "id_str" : "337978010105950208",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom really? no circumstances? what if someone holds a gun to my head.. \"sharpen that pen or else!\"",
  "id" : 337978010105950208,
  "in_reply_to_status_id" : 337976488253091841,
  "created_at" : "2013-05-24 17:06:51 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337953731536625665",
  "text" : "RT @damienechols: It does not matter how you try to justify it - negativity is still negativity.\nNo one can force you to be negative. It's \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337953525197844481",
    "text" : "It does not matter how you try to justify it - negativity is still negativity.\nNo one can force you to be negative. It's a choice.",
    "id" : 337953525197844481,
    "created_at" : "2013-05-24 15:29:33 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 337953731536625665,
  "created_at" : "2013-05-24 15:30:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337952998355521536",
  "geo" : { },
  "id_str" : "337953397720354816",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom shapeshifting FTW! : )",
  "id" : 337953397720354816,
  "in_reply_to_status_id" : 337952998355521536,
  "created_at" : "2013-05-24 15:29:03 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337952691969990657",
  "text" : "every single one of us has natural bias due to combo of genetics and environment. its a matter of becoming aware of them.",
  "id" : 337952691969990657,
  "created_at" : "2013-05-24 15:26:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337952293745999874",
  "text" : "ppl crying \"biased!\" yet using bias themselves to back up their views...",
  "id" : 337952293745999874,
  "created_at" : "2013-05-24 15:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337949561903517696",
  "text" : "@1stCitizenKane yes!",
  "id" : 337949561903517696,
  "created_at" : "2013-05-24 15:13:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337949004778336257",
  "text" : "if you focus on the haters, bashers, etc.. it becomes a part of you.",
  "id" : 337949004778336257,
  "created_at" : "2013-05-24 15:11:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337948732005941248",
  "text" : "following angry ppl makes me angry.. becomes domino effect. my anger rubs off on others.",
  "id" : 337948732005941248,
  "created_at" : "2013-05-24 15:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337948137849225218",
  "text" : "must stop reading comments.. messing w my aura!",
  "id" : 337948137849225218,
  "created_at" : "2013-05-24 15:08:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337733191278399488",
  "geo" : { },
  "id_str" : "337733776111185920",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind because all life is equal (from prev tweet?)",
  "id" : 337733776111185920,
  "in_reply_to_status_id" : 337733191278399488,
  "created_at" : "2013-05-24 00:56:21 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337730653892247552",
  "geo" : { },
  "id_str" : "337732404972249089",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind oh there's that buddhist in you..hehe ; )",
  "id" : 337732404972249089,
  "in_reply_to_status_id" : 337730653892247552,
  "created_at" : "2013-05-24 00:50:54 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337715559301017600",
  "geo" : { },
  "id_str" : "337731594158747648",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 we need professional juries.",
  "id" : 337731594158747648,
  "in_reply_to_status_id" : 337715559301017600,
  "created_at" : "2013-05-24 00:47:41 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337719018620338176",
  "geo" : { },
  "id_str" : "337731026048675840",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 ahh.. thats what i thought i missed.. i saw the hung jury verdict. wow.",
  "id" : 337731026048675840,
  "in_reply_to_status_id" : 337719018620338176,
  "created_at" : "2013-05-24 00:45:26 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337716899418882048",
  "geo" : { },
  "id_str" : "337726035514765312",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 did I miss it?",
  "id" : 337726035514765312,
  "in_reply_to_status_id" : 337716899418882048,
  "created_at" : "2013-05-24 00:25:36 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337725496735444992",
  "text" : "Hmm.. no timeline via web but getting it on my kindle fire..",
  "id" : 337725496735444992,
  "created_at" : "2013-05-24 00:23:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337722653622296576",
  "text" : "why is my timeline gone (empty?) gah.",
  "id" : 337722653622296576,
  "created_at" : "2013-05-24 00:12:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 91, 103 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/8KDgAu3Lfo",
      "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2013\/05\/buckhalter-mississippi-stillbirth-manslaughter",
      "display_url" : "motherjones.com\/politics\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337672230819487744",
  "text" : "Mississippi Could Soon Jail Women for Stillbirths, Miscarriages http:\/\/t.co\/8KDgAu3Lfo via @motherjones",
  "id" : 337672230819487744,
  "created_at" : "2013-05-23 20:51:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337596563905970176",
  "text" : "RT @howtobesick: \u201CThe Empty Boat\u201D (as it\u2019s come to be called) is one of my favorite parables. It\u2019s from the 4th Century BCE... http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/liqm7Qc98S",
        "expanded_url" : "http:\/\/fb.me\/2H4pfblTy",
        "display_url" : "fb.me\/2H4pfblTy"
      } ]
    },
    "geo" : { },
    "id_str" : "337595578978562049",
    "text" : "\u201CThe Empty Boat\u201D (as it\u2019s come to be called) is one of my favorite parables. It\u2019s from the 4th Century BCE... http:\/\/t.co\/liqm7Qc98S",
    "id" : 337595578978562049,
    "created_at" : "2013-05-23 15:47:12 +0000",
    "user" : {
      "name" : "Toni Bernhard",
      "screen_name" : "toni_bernhard",
      "protected" : false,
      "id_str" : "169982819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759869867449196544\/dEV7yImo_normal.jpg",
      "id" : 169982819,
      "verified" : false
    }
  },
  "id" : 337596563905970176,
  "created_at" : "2013-05-23 15:51:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2HC0IXJfGc",
      "expanded_url" : "http:\/\/shar.es\/ZiMbX",
      "display_url" : "shar.es\/ZiMbX"
    } ]
  },
  "geo" : { },
  "id_str" : "337594132421816320",
  "text" : "\"Jodi\u2019s ego is an entirely different fruit. It is an exotic fruit, rarely seen or experienced. It is not normal.\" http:\/\/t.co\/2HC0IXJfGc",
  "id" : 337594132421816320,
  "created_at" : "2013-05-23 15:41:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337592930996994048",
  "text" : "RT @dhammagirl: Peace Peace Peace...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337589647377043456",
    "text" : "Peace Peace Peace...",
    "id" : 337589647377043456,
    "created_at" : "2013-05-23 15:23:38 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 337592930996994048,
  "created_at" : "2013-05-23 15:36:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/w3153JOGqx",
      "expanded_url" : "http:\/\/kristinarandle.com\/blog\/jodi-arias-upcoming-testimony-the-dilemma\/",
      "display_url" : "kristinarandle.com\/blog\/jodi-aria\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337592871337205761",
  "text" : "Jodi Arias' Upcoming Testimony: The Dilemma http:\/\/t.co\/w3153JOGqx",
  "id" : 337592871337205761,
  "created_at" : "2013-05-23 15:36:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337589798220996608",
  "text" : "why do humans have an ego? what does it do?",
  "id" : 337589798220996608,
  "created_at" : "2013-05-23 15:24:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Coyote",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "photo",
      "indices" : [ 55, 61 ]
    }, {
      "text" : "Yellowstone",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/85o1cuHdqZ",
      "expanded_url" : "http:\/\/bit.ly\/10MVOAs",
      "display_url" : "bit.ly\/10MVOAs"
    } ]
  },
  "geo" : { },
  "id_str" : "337588864224997378",
  "text" : "RT @MartinBelan: Grumpy #Coyote http:\/\/t.co\/85o1cuHdqZ #photo #Yellowstone",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Coyote",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "photo",
        "indices" : [ 38, 44 ]
      }, {
        "text" : "Yellowstone",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/85o1cuHdqZ",
        "expanded_url" : "http:\/\/bit.ly\/10MVOAs",
        "display_url" : "bit.ly\/10MVOAs"
      } ]
    },
    "geo" : { },
    "id_str" : "337588479162732544",
    "text" : "Grumpy #Coyote http:\/\/t.co\/85o1cuHdqZ #photo #Yellowstone",
    "id" : 337588479162732544,
    "created_at" : "2013-05-23 15:19:00 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 337588864224997378,
  "created_at" : "2013-05-23 15:20:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337586315241603074",
  "text" : "RT @CoyotesWisdom: Never be afraid to eat the last donut.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337583950484606976",
    "text" : "Never be afraid to eat the last donut.",
    "id" : 337583950484606976,
    "created_at" : "2013-05-23 15:01:00 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 337586315241603074,
  "created_at" : "2013-05-23 15:10:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337584341104340992",
  "geo" : { },
  "id_str" : "337586156269084673",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible there's no making sense of westboro. the guy that heads it is crazy and has brainwashed the others (mostly family)",
  "id" : 337586156269084673,
  "in_reply_to_status_id" : 337584341104340992,
  "created_at" : "2013-05-23 15:09:46 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 38, 49 ],
      "id_str" : "264530860",
      "id" : 264530860
    }, {
      "name" : "BIBLE: Holy Spirit",
      "screen_name" : "BIBLEHolySpirit",
      "indices" : [ 50, 66 ],
      "id_str" : "414209427",
      "id" : 414209427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337578080291913728",
  "geo" : { },
  "id_str" : "337585110838816769",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom hmm.. what about egos? @Raven_Luni @BIBLEHolySpirit",
  "id" : 337585110838816769,
  "in_reply_to_status_id" : 337578080291913728,
  "created_at" : "2013-05-23 15:05:37 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 38, 49 ],
      "id_str" : "264530860",
      "id" : 264530860
    }, {
      "name" : "BIBLE: Holy Spirit",
      "screen_name" : "BIBLEHolySpirit",
      "indices" : [ 50, 66 ],
      "id_str" : "414209427",
      "id" : 414209427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337578080291913728",
  "geo" : { },
  "id_str" : "337584765861494785",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom lol.. yes, they do : ) @Raven_Luni @BIBLEHolySpirit",
  "id" : 337584765861494785,
  "in_reply_to_status_id" : 337578080291913728,
  "created_at" : "2013-05-23 15:04:14 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 77, 88 ],
      "id_str" : "264530860",
      "id" : 264530860
    }, {
      "name" : "BIBLE: Holy Spirit",
      "screen_name" : "BIBLEHolySpirit",
      "indices" : [ 89, 105 ],
      "id_str" : "414209427",
      "id" : 414209427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337571282172399616",
  "geo" : { },
  "id_str" : "337574298900385792",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom its hard to be human.. all those pesky emotions and the ego.. @Raven_Luni @BIBLEHolySpirit",
  "id" : 337574298900385792,
  "in_reply_to_status_id" : 337571282172399616,
  "created_at" : "2013-05-23 14:22:39 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa623",
      "screen_name" : "Teresa623",
      "indices" : [ 0, 10 ],
      "id_str" : "66849648",
      "id" : 66849648
    }, {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 18, 25 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337566358353113088",
  "geo" : { },
  "id_str" : "337566914245177344",
  "in_reply_to_user_id" : 66849648,
  "text" : "@Teresa623 agreed @BestAt",
  "id" : 337566914245177344,
  "in_reply_to_status_id" : 337566358353113088,
  "created_at" : "2013-05-23 13:53:18 +0000",
  "in_reply_to_screen_name" : "Teresa623",
  "in_reply_to_user_id_str" : "66849648",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337564519662489600",
  "text" : "@Skeptical_Lady haha.. i know : )",
  "id" : 337564519662489600,
  "created_at" : "2013-05-23 13:43:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337556609649758208",
  "geo" : { },
  "id_str" : "337558411505987584",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal ((hugs))",
  "id" : 337558411505987584,
  "in_reply_to_status_id" : 337556609649758208,
  "created_at" : "2013-05-23 13:19:31 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337556088310333440",
  "text" : "@HEATHENRABBIT absolutely! : )",
  "id" : 337556088310333440,
  "created_at" : "2013-05-23 13:10:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ilikesheep",
      "indices" : [ 83, 94 ]
    }, {
      "text" : "baaa",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337555294471204864",
  "text" : ". @Skeptical_Lady im so torn.. i want to RT but those poor sheep, always a bad rap #ilikesheep #baaa",
  "id" : 337555294471204864,
  "created_at" : "2013-05-23 13:07:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/fC1xt02hrg",
      "expanded_url" : "http:\/\/amzn.to\/H0HWsi",
      "display_url" : "amzn.to\/H0HWsi"
    } ]
  },
  "geo" : { },
  "id_str" : "337397573998501888",
  "text" : "finished The Wicked (Righteous Series #3) by Michael Wallace http:\/\/t.co\/fC1xt02hrg",
  "id" : 337397573998501888,
  "created_at" : "2013-05-23 02:40:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337376933509730304",
  "geo" : { },
  "id_str" : "337377367842488320",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater 3 mischief makers!",
  "id" : 337377367842488320,
  "in_reply_to_status_id" : 337376933509730304,
  "created_at" : "2013-05-23 01:20:07 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Atheists",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "onestepatatime",
      "indices" : [ 127, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/IN5u0iwOpz",
      "expanded_url" : "http:\/\/huff.to\/10lpauu",
      "display_url" : "huff.to\/10lpauu"
    } ]
  },
  "geo" : { },
  "id_str" : "337370426957262848",
  "text" : "huh.. moving forward! &gt;&gt; Pope Francis Says #Atheists Who Do Good Are Redeemed, Not Just Catholics http:\/\/t.co\/IN5u0iwOpz #onestepatatime",
  "id" : 337370426957262848,
  "created_at" : "2013-05-23 00:52:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337350647701708800",
  "geo" : { },
  "id_str" : "337369143256952832",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu im one of those 4! LOL .. that's ok, i still like you : )",
  "id" : 337369143256952832,
  "in_reply_to_status_id" : 337350647701708800,
  "created_at" : "2013-05-23 00:47:26 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337364140123357184",
  "text" : "MasterChef is on tonight!",
  "id" : 337364140123357184,
  "created_at" : "2013-05-23 00:27:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337319031361118208",
  "text" : "RT @JeremyCShipp: What if trees screamed constantly and we just had to live with it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337318437795790848",
    "text" : "What if trees screamed constantly and we just had to live with it?",
    "id" : 337318437795790848,
    "created_at" : "2013-05-22 21:25:57 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 337319031361118208,
  "created_at" : "2013-05-22 21:28:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337318442438901760",
  "text" : "RT @TheGodLight: You must not give in to the ways of others, if it does not suit you, you must walk away &amp; walk the path made for you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337316709490892801",
    "text" : "You must not give in to the ways of others, if it does not suit you, you must walk away &amp; walk the path made for you.",
    "id" : 337316709490892801,
    "created_at" : "2013-05-22 21:19:05 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 337318442438901760,
  "created_at" : "2013-05-22 21:25:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Yellowstone",
      "indices" : [ 17, 29 ]
    }, {
      "text" : "photo",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "nature",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ZGZJ7MGqij",
      "expanded_url" : "http:\/\/bit.ly\/1818Y5G",
      "display_url" : "bit.ly\/1818Y5G"
    } ]
  },
  "geo" : { },
  "id_str" : "337317175230603264",
  "text" : "RT @MartinBelan: #Yellowstone, Bison Calf http:\/\/t.co\/ZGZJ7MGqij #photo #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Yellowstone",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "photo",
        "indices" : [ 48, 54 ]
      }, {
        "text" : "nature",
        "indices" : [ 55, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/ZGZJ7MGqij",
        "expanded_url" : "http:\/\/bit.ly\/1818Y5G",
        "display_url" : "bit.ly\/1818Y5G"
      } ]
    },
    "geo" : { },
    "id_str" : "337314676197163008",
    "text" : "#Yellowstone, Bison Calf http:\/\/t.co\/ZGZJ7MGqij #photo #nature",
    "id" : 337314676197163008,
    "created_at" : "2013-05-22 21:11:00 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 337317175230603264,
  "created_at" : "2013-05-22 21:20:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myss Lyss",
      "screen_name" : "kryptress",
      "indices" : [ 0, 10 ],
      "id_str" : "224022154",
      "id" : 224022154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337309006093774848",
  "geo" : { },
  "id_str" : "337310621647388672",
  "in_reply_to_user_id" : 224022154,
  "text" : "@kryptress i agree. what she did was horrific and i think she can be a danger if free but she's def not quite with it.",
  "id" : 337310621647388672,
  "in_reply_to_status_id" : 337309006093774848,
  "created_at" : "2013-05-22 20:54:53 +0000",
  "in_reply_to_screen_name" : "kryptress",
  "in_reply_to_user_id_str" : "224022154",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CaptivatingNews",
      "screen_name" : "CaptivatingNews",
      "indices" : [ 3, 19 ],
      "id_str" : "292374563",
      "id" : 292374563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337294805149302784",
  "text" : "RT @CaptivatingNews: Health Care For A Family Of Four Now Costs More Than The Groceries To Feed Them For An Entire Year http:\/\/t.co\/LQSL3yB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 122, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/LQSL3yBraw",
        "expanded_url" : "http:\/\/tinyurl.com\/o5gjlwb",
        "display_url" : "tinyurl.com\/o5gjlwb"
      } ]
    },
    "geo" : { },
    "id_str" : "337285015710871552",
    "text" : "Health Care For A Family Of Four Now Costs More Than The Groceries To Feed Them For An Entire Year http:\/\/t.co\/LQSL3yBraw #p2",
    "id" : 337285015710871552,
    "created_at" : "2013-05-22 19:13:08 +0000",
    "user" : {
      "name" : "CaptivatingNews",
      "screen_name" : "CaptivatingNews",
      "protected" : false,
      "id_str" : "292374563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3292130652\/cc0d43ad6f16d34ba82b95463e99df52_normal.jpeg",
      "id" : 292374563,
      "verified" : false
    }
  },
  "id" : 337294805149302784,
  "created_at" : "2013-05-22 19:52:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "photo",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ImthGVGUgS",
      "expanded_url" : "http:\/\/ow.ly\/lhd3T",
      "display_url" : "ow.ly\/lhd3T"
    } ]
  },
  "geo" : { },
  "id_str" : "337294664661082112",
  "text" : "RT @KerriFar: \"Between every two pines ..... a doorway...\" ~ http:\/\/t.co\/ImthGVGUgS  ~ #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "photo",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/ImthGVGUgS",
        "expanded_url" : "http:\/\/ow.ly\/lhd3T",
        "display_url" : "ow.ly\/lhd3T"
      } ]
    },
    "geo" : { },
    "id_str" : "337285815656923136",
    "text" : "\"Between every two pines ..... a doorway...\" ~ http:\/\/t.co\/ImthGVGUgS  ~ #nature #photo",
    "id" : 337285815656923136,
    "created_at" : "2013-05-22 19:16:19 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 337294664661082112,
  "created_at" : "2013-05-22 19:51:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 3, 16 ],
      "id_str" : "43298413",
      "id" : 43298413
    }, {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 18, 32 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337294496222019584",
  "text" : "RT @NathanDunbar: @johnnie_cakes I think this is a core failing of society today. People aren't taught that sometimes you don't win, and TH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John",
        "screen_name" : "johnnie_cakes",
        "indices" : [ 0, 14 ],
        "id_str" : "16901470",
        "id" : 16901470
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "337285448714043393",
    "geo" : { },
    "id_str" : "337286281769938944",
    "in_reply_to_user_id" : 16901470,
    "text" : "@johnnie_cakes I think this is a core failing of society today. People aren't taught that sometimes you don't win, and THAT'S OK.",
    "id" : 337286281769938944,
    "in_reply_to_status_id" : 337285448714043393,
    "created_at" : "2013-05-22 19:18:10 +0000",
    "in_reply_to_screen_name" : "johnnie_cakes",
    "in_reply_to_user_id_str" : "16901470",
    "user" : {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "protected" : false,
      "id_str" : "43298413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683069342842503169\/t-eR15ya_normal.jpg",
      "id" : 43298413,
      "verified" : false
    }
  },
  "id" : 337294496222019584,
  "created_at" : "2013-05-22 19:50:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yesimbeingselfrighteous",
      "indices" : [ 74, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337293415194710017",
  "text" : "so many angry ppl out there.. gotta stop reading comments.. makes me ill. #yesimbeingselfrighteous",
  "id" : 337293415194710017,
  "created_at" : "2013-05-22 19:46:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "indices" : [ 3, 14 ],
      "id_str" : "511243584",
      "id" : 511243584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/7vHWml0joV",
      "expanded_url" : "http:\/\/abcnews.go.com\/GMA\/video\/jodi-arias-interview-2013-arias-calls-reporter-hater-19231549",
      "display_url" : "abcnews.go.com\/GMA\/video\/jodi\u2026"
    }, {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/PzznR4Qmrq",
      "expanded_url" : "http:\/\/www.azcentral.com\/12news\/articles\/20130521jodi-arias-talks-before-sentencing.html",
      "display_url" : "azcentral.com\/12news\/article\u2026"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/80KcCHuWzg",
      "expanded_url" : "http:\/\/www.myfoxphoenix.com\/story\/22380878\/2013\/05\/22\/jodi-arias-speaks-out-to-choice-media-before-sentencing",
      "display_url" : "myfoxphoenix.com\/story\/22380878\u2026"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Ps65MANJUK",
      "expanded_url" : "http:\/\/ktar.com\/22\/1636198\/Jodi-Arias-gives-3-interviews-after-day-of-pleading-for-life",
      "display_url" : "ktar.com\/22\/1636198\/Jod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337265636638081024",
  "text" : "RT @becwaddell: #JodiArias interviews:\n\nhttp:\/\/t.co\/7vHWml0joV\n\nhttp:\/\/t.co\/PzznR4Qmrq\n\nhttp:\/\/t.co\/80KcCHuWzg\n\nhttp:\/\/t.co\/Ps65MANJUK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/7vHWml0joV",
        "expanded_url" : "http:\/\/abcnews.go.com\/GMA\/video\/jodi-arias-interview-2013-arias-calls-reporter-hater-19231549",
        "display_url" : "abcnews.go.com\/GMA\/video\/jodi\u2026"
      }, {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/PzznR4Qmrq",
        "expanded_url" : "http:\/\/www.azcentral.com\/12news\/articles\/20130521jodi-arias-talks-before-sentencing.html",
        "display_url" : "azcentral.com\/12news\/article\u2026"
      }, {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/80KcCHuWzg",
        "expanded_url" : "http:\/\/www.myfoxphoenix.com\/story\/22380878\/2013\/05\/22\/jodi-arias-speaks-out-to-choice-media-before-sentencing",
        "display_url" : "myfoxphoenix.com\/story\/22380878\u2026"
      }, {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Ps65MANJUK",
        "expanded_url" : "http:\/\/ktar.com\/22\/1636198\/Jodi-Arias-gives-3-interviews-after-day-of-pleading-for-life",
        "display_url" : "ktar.com\/22\/1636198\/Jod\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337264629673754624",
    "text" : "#JodiArias interviews:\n\nhttp:\/\/t.co\/7vHWml0joV\n\nhttp:\/\/t.co\/PzznR4Qmrq\n\nhttp:\/\/t.co\/80KcCHuWzg\n\nhttp:\/\/t.co\/Ps65MANJUK",
    "id" : 337264629673754624,
    "created_at" : "2013-05-22 17:52:08 +0000",
    "user" : {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "protected" : false,
      "id_str" : "511243584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604077917094596608\/YsEVFvZs_normal.jpg",
      "id" : 511243584,
      "verified" : false
    }
  },
  "id" : 337265636638081024,
  "created_at" : "2013-05-22 17:56:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337265285323165697",
  "text" : "RT @bend_time: \u2018The swim was a highlight in my life; one that left me charmed, in love and paradoxically saddened. For the (cont) http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/zilQ0DIgra",
        "expanded_url" : "http:\/\/tl.gd\/n_1rke6bq",
        "display_url" : "tl.gd\/n_1rke6bq"
      } ]
    },
    "geo" : { },
    "id_str" : "337263919934607361",
    "text" : "\u2018The swim was a highlight in my life; one that left me charmed, in love and paradoxically saddened. For the (cont) http:\/\/t.co\/zilQ0DIgra",
    "id" : 337263919934607361,
    "created_at" : "2013-05-22 17:49:19 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 337265285323165697,
  "created_at" : "2013-05-22 17:54:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "indices" : [ 0, 11 ],
      "id_str" : "511243584",
      "id" : 511243584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337246053936025600",
  "geo" : { },
  "id_str" : "337252544780849152",
  "in_reply_to_user_id" : 511243584,
  "text" : "@becwaddell while she knows right from wrong.. she is delusional. she is not right in the head. thx 4 sharing links.",
  "id" : 337252544780849152,
  "in_reply_to_status_id" : 337246053936025600,
  "created_at" : "2013-05-22 17:04:07 +0000",
  "in_reply_to_screen_name" : "becwaddell",
  "in_reply_to_user_id_str" : "511243584",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337249865312636929",
  "text" : "@SamsaricWarrior the way women are viewed in society i think.",
  "id" : 337249865312636929,
  "created_at" : "2013-05-22 16:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/xLWYYCttwH",
      "expanded_url" : "http:\/\/shar.es\/ZAS0U",
      "display_url" : "shar.es\/ZAS0U"
    } ]
  },
  "geo" : { },
  "id_str" : "337245928715075584",
  "text" : "Obituary of the Day: Ohio http:\/\/t.co\/xLWYYCttwH \"Died a couple of days ago which wasn't exactly unexpected...\"",
  "id" : 337245928715075584,
  "created_at" : "2013-05-22 16:37:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 3, 16 ],
      "id_str" : "88882302",
      "id" : 88882302
    }, {
      "name" : "Marti Green",
      "screen_name" : "MartiGreen2",
      "indices" : [ 126, 138 ],
      "id_str" : "939538867",
      "id" : 939538867
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337230878403067904",
  "text" : "RT @TweetTheBook: #FREE 05\/22-05\/23 \"...an engrossing, well conceived legal thriller.\" #Kindle=&gt;Unintended Consequences by @MartiGreen2 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marti Green",
        "screen_name" : "MartiGreen2",
        "indices" : [ 108, 120 ],
        "id_str" : "939538867",
        "id" : 939538867
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FREE",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/3nLvxTx593",
        "expanded_url" : "http:\/\/ow.ly\/lhqHQ",
        "display_url" : "ow.ly\/lhqHQ"
      } ]
    },
    "geo" : { },
    "id_str" : "337226564947283968",
    "text" : "#FREE 05\/22-05\/23 \"...an engrossing, well conceived legal thriller.\" #Kindle=&gt;Unintended Consequences by @MartiGreen2 http:\/\/t.co\/3nLvxTx593",
    "id" : 337226564947283968,
    "created_at" : "2013-05-22 15:20:53 +0000",
    "user" : {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "protected" : false,
      "id_str" : "88882302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723538520174780416\/myOVJeXG_normal.jpg",
      "id" : 88882302,
      "verified" : false
    }
  },
  "id" : 337230878403067904,
  "created_at" : "2013-05-22 15:38:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6ESloDiSj8",
      "expanded_url" : "http:\/\/coyotesings.weebly.com\/trickster-thoughts.html",
      "display_url" : "coyotesings.weebly.com\/trickster-thou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337226938030628866",
  "text" : "RT @CoyoteSings: How our Trickster Thoughts keep the vicious cycle of the thoughts of depression spinning.. http:\/\/t.co\/6ESloDiSj8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/6ESloDiSj8",
        "expanded_url" : "http:\/\/coyotesings.weebly.com\/trickster-thoughts.html",
        "display_url" : "coyotesings.weebly.com\/trickster-thou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337222467414269952",
    "text" : "How our Trickster Thoughts keep the vicious cycle of the thoughts of depression spinning.. http:\/\/t.co\/6ESloDiSj8",
    "id" : 337222467414269952,
    "created_at" : "2013-05-22 15:04:36 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 337226938030628866,
  "created_at" : "2013-05-22 15:22:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337223618650075138",
  "geo" : { },
  "id_str" : "337226420164116480",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog congrats! looking forward to 5000th post! : )",
  "id" : 337226420164116480,
  "in_reply_to_status_id" : 337223618650075138,
  "created_at" : "2013-05-22 15:20:18 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337224923900674048",
  "text" : "RT @bookwiseblog: 2500th Post: This is the 2500th post on Bookwi.se. \u00A0Thanks for supporting us.The post 2500th Post appeared fir... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/7GK6dtcUeG",
        "expanded_url" : "http:\/\/bit.ly\/14xCR9O",
        "display_url" : "bit.ly\/14xCR9O"
      } ]
    },
    "geo" : { },
    "id_str" : "337223618650075138",
    "text" : "2500th Post: This is the 2500th post on Bookwi.se. \u00A0Thanks for supporting us.The post 2500th Post appeared fir... http:\/\/t.co\/7GK6dtcUeG",
    "id" : 337223618650075138,
    "created_at" : "2013-05-22 15:09:10 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 337224923900674048,
  "created_at" : "2013-05-22 15:14:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337219324391591937",
  "text" : "RT @virtusetveritas: starting a series on taking back the words I was forbidden and looking for guest posts. Let's get this party started! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Dtexxk2hl4",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-8B",
        "display_url" : "wp.me\/p372Ye-8B"
      } ]
    },
    "geo" : { },
    "id_str" : "337212239885004801",
    "text" : "starting a series on taking back the words I was forbidden and looking for guest posts. Let's get this party started! http:\/\/t.co\/Dtexxk2hl4",
    "id" : 337212239885004801,
    "created_at" : "2013-05-22 14:23:57 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 337219324391591937,
  "created_at" : "2013-05-22 14:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MadroX",
      "screen_name" : "IllinLaneCraig",
      "indices" : [ 0, 15 ],
      "id_str" : "601064772",
      "id" : 601064772
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 57, 72 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 73, 89 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337214284809519104",
  "geo" : { },
  "id_str" : "337217661337481216",
  "in_reply_to_user_id" : 601064772,
  "text" : "@IllinLaneCraig the us govt rapes its citizens every day @AnnotatedBible @CounterApologis",
  "id" : 337217661337481216,
  "in_reply_to_status_id" : 337214284809519104,
  "created_at" : "2013-05-22 14:45:30 +0000",
  "in_reply_to_screen_name" : "IllinLaneCraig",
  "in_reply_to_user_id_str" : "601064772",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/f7mCpiXXOw",
      "expanded_url" : "http:\/\/instagram.com\/p\/Zl7JY5BH9G\/",
      "display_url" : "instagram.com\/p\/Zl7JY5BH9G\/"
    } ]
  },
  "geo" : { },
  "id_str" : "337001865608830976",
  "text" : "RT @ducksandclucks: It's sprinkling, so the crow is on my chair and I'm hiding out in the duck pens to stay dry. http:\/\/t.co\/f7mCpiXXOw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/f7mCpiXXOw",
        "expanded_url" : "http:\/\/instagram.com\/p\/Zl7JY5BH9G\/",
        "display_url" : "instagram.com\/p\/Zl7JY5BH9G\/"
      } ]
    },
    "geo" : { },
    "id_str" : "336989946256691200",
    "text" : "It's sprinkling, so the crow is on my chair and I'm hiding out in the duck pens to stay dry. http:\/\/t.co\/f7mCpiXXOw",
    "id" : 336989946256691200,
    "created_at" : "2013-05-21 23:40:38 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 337001865608830976,
  "created_at" : "2013-05-22 00:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "THE Way is YOUR Way",
      "screen_name" : "CheesesCrust_",
      "indices" : [ 18, 32 ],
      "id_str" : "941818458",
      "id" : 941818458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336976599868116994",
  "geo" : { },
  "id_str" : "336976832819761152",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind heehee @CheesesCrust_",
  "id" : 336976832819761152,
  "in_reply_to_status_id" : 336976599868116994,
  "created_at" : "2013-05-21 22:48:32 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/5w4tCuR9t4",
      "expanded_url" : "http:\/\/tinyurl.com\/9n4n2bt",
      "display_url" : "tinyurl.com\/9n4n2bt"
    } ]
  },
  "geo" : { },
  "id_str" : "336976650711482370",
  "text" : "RT @Soulseedzforall: There are as many views as there are eyes to see them. http:\/\/t.co\/5w4tCuR9t4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/5w4tCuR9t4",
        "expanded_url" : "http:\/\/tinyurl.com\/9n4n2bt",
        "display_url" : "tinyurl.com\/9n4n2bt"
      } ]
    },
    "geo" : { },
    "id_str" : "336975213940064256",
    "text" : "There are as many views as there are eyes to see them. http:\/\/t.co\/5w4tCuR9t4",
    "id" : 336975213940064256,
    "created_at" : "2013-05-21 22:42:06 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 336976650711482370,
  "created_at" : "2013-05-21 22:47:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "laineymc23",
      "indices" : [ 0, 11 ],
      "id_str" : "244956629",
      "id" : 244956629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336974516087554048",
  "geo" : { },
  "id_str" : "336975188417712128",
  "in_reply_to_user_id" : 244956629,
  "text" : "@laineymc23 i don't think any of us will ever be normal again :p",
  "id" : 336975188417712128,
  "in_reply_to_status_id" : 336974516087554048,
  "created_at" : "2013-05-21 22:42:00 +0000",
  "in_reply_to_screen_name" : "laineymc23",
  "in_reply_to_user_id_str" : "244956629",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/336965029020696577\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/vcGnnoifcf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BK0j6JkCAAAjkVj.jpg",
      "id_str" : "336965029029085184",
      "id" : 336965029029085184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK0j6JkCAAAjkVj.jpg",
      "sizes" : [ {
        "h" : 717,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/vcGnnoifcf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336966035217453056",
  "text" : "RT @marseelee: It's like the universe is screaming in your face: http:\/\/t.co\/vcGnnoifcf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/336965029020696577\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/vcGnnoifcf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BK0j6JkCAAAjkVj.jpg",
        "id_str" : "336965029029085184",
        "id" : 336965029029085184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK0j6JkCAAAjkVj.jpg",
        "sizes" : [ {
          "h" : 717,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/vcGnnoifcf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336965029020696577",
    "text" : "It's like the universe is screaming in your face: http:\/\/t.co\/vcGnnoifcf",
    "id" : 336965029020696577,
    "created_at" : "2013-05-21 22:01:38 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 336966035217453056,
  "created_at" : "2013-05-21 22:05:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sheep",
      "indices" : [ 26, 32 ]
    }, {
      "text" : "photo",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "Yellowstone",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/R6YVf8AdnA",
      "expanded_url" : "http:\/\/bit.ly\/163GyIw",
      "display_url" : "bit.ly\/163GyIw"
    } ]
  },
  "geo" : { },
  "id_str" : "336952932186603520",
  "text" : "RT @MartinBelan: Big Horn #Sheep Stare Down http:\/\/t.co\/R6YVf8AdnA #photo #Yellowstone",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sheep",
        "indices" : [ 9, 15 ]
      }, {
        "text" : "photo",
        "indices" : [ 50, 56 ]
      }, {
        "text" : "Yellowstone",
        "indices" : [ 57, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/R6YVf8AdnA",
        "expanded_url" : "http:\/\/bit.ly\/163GyIw",
        "display_url" : "bit.ly\/163GyIw"
      } ]
    },
    "geo" : { },
    "id_str" : "336952035188555780",
    "text" : "Big Horn #Sheep Stare Down http:\/\/t.co\/R6YVf8AdnA #photo #Yellowstone",
    "id" : 336952035188555780,
    "created_at" : "2013-05-21 21:10:00 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 336952932186603520,
  "created_at" : "2013-05-21 21:13:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336950499272175617",
  "text" : "@1stCitizenKane really? someone really said that? ((facepalm))",
  "id" : 336950499272175617,
  "created_at" : "2013-05-21 21:03:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Now tweeting @KFILE",
      "screen_name" : "BuzzFeedAndrew",
      "indices" : [ 3, 18 ],
      "id_str" : "782351672639094785",
      "id" : 782351672639094785
    }, {
      "name" : "Oklahoma Co. Sheriff",
      "screen_name" : "OkCountySheriff",
      "indices" : [ 28, 44 ],
      "id_str" : "21781549",
      "id" : 21781549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336942891622600704",
  "text" : "RT @BuzzFeedAndrew: Wow. RT @OkCountySheriff: This dog was guarding it's deceased owner.  Taken to shelter; deputy plans on adopting. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oklahoma Co. Sheriff",
        "screen_name" : "OkCountySheriff",
        "indices" : [ 8, 24 ],
        "id_str" : "21781549",
        "id" : 21781549
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OkCountySheriff\/status\/336937283334836226\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UiirnbWVRV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BK0KrI1CEAM1QSq.jpg",
        "id_str" : "336937283343224835",
        "id" : 336937283343224835,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK0KrI1CEAM1QSq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1371,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1371,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UiirnbWVRV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336940642620039169",
    "text" : "Wow. RT @OkCountySheriff: This dog was guarding it's deceased owner.  Taken to shelter; deputy plans on adopting. http:\/\/t.co\/UiirnbWVRV",
    "id" : 336940642620039169,
    "created_at" : "2013-05-21 20:24:43 +0000",
    "user" : {
      "name" : "andrew kaczynski",
      "screen_name" : "KFILE",
      "protected" : false,
      "id_str" : "326255267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774267754526470145\/6S_9hYNm_normal.jpg",
      "id" : 326255267,
      "verified" : true
    }
  },
  "id" : 336942891622600704,
  "created_at" : "2013-05-21 20:33:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336940787105423361",
  "text" : "i love the birds in my yard.. they remind me that life is intrinsically good. thank you, precious little creatures. #gratitude",
  "id" : 336940787105423361,
  "created_at" : "2013-05-21 20:25:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336939804216401920",
  "text" : "RT @TheGoldenMirror: The fact that you've blocked out the pain, doesn't mean you're not still hurt. On the contrary, in means that you stil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336939331891642368",
    "text" : "The fact that you've blocked out the pain, doesn't mean you're not still hurt. On the contrary, in means that you still have wounds to heal.",
    "id" : 336939331891642368,
    "created_at" : "2013-05-21 20:19:31 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 336939804216401920,
  "created_at" : "2013-05-21 20:21:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336936320708521984",
  "text" : "RT @ChristianDems: Matt 26:51-52 \"Put your sword back in its place,\" Jesus said to him, \"for all who draw the sword will die by the sword.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336935503758761984",
    "text" : "Matt 26:51-52 \"Put your sword back in its place,\" Jesus said to him, \"for all who draw the sword will die by the sword.\"",
    "id" : 336935503758761984,
    "created_at" : "2013-05-21 20:04:18 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 336936320708521984,
  "created_at" : "2013-05-21 20:07:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Laura Barrett",
      "screen_name" : "lol929",
      "indices" : [ 40, 47 ],
      "id_str" : "255477701",
      "id" : 255477701
    }, {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 52, 64 ],
      "id_str" : "409492415",
      "id" : 409492415
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/336776083053608960\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/N7kRH9vvql",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKx4EC-CAAEASyN.jpg",
      "id_str" : "336776083057803265",
      "id" : 336776083057803265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKx4EC-CAAEASyN.jpg",
      "sizes" : [ {
        "h" : 1243,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2154,
        "resize" : "fit",
        "w" : 1774
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/N7kRH9vvql"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336929767309848577",
  "text" : "RT @KerriFar: Cute Alert!  Adorable! RT @lol929: RT @Coyotetooth: angry bird at window sill http:\/\/t.co\/N7kRH9vvql",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Barrett",
        "screen_name" : "lol929",
        "indices" : [ 26, 33 ],
        "id_str" : "255477701",
        "id" : 255477701
      }, {
        "name" : "Stefano  Anders",
        "screen_name" : "Coyotetooth",
        "indices" : [ 38, 50 ],
        "id_str" : "409492415",
        "id" : 409492415
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/336776083053608960\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/N7kRH9vvql",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKx4EC-CAAEASyN.jpg",
        "id_str" : "336776083057803265",
        "id" : 336776083057803265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKx4EC-CAAEASyN.jpg",
        "sizes" : [ {
          "h" : 1243,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2154,
          "resize" : "fit",
          "w" : 1774
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N7kRH9vvql"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336929472005677057",
    "text" : "Cute Alert!  Adorable! RT @lol929: RT @Coyotetooth: angry bird at window sill http:\/\/t.co\/N7kRH9vvql",
    "id" : 336929472005677057,
    "created_at" : "2013-05-21 19:40:20 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 336929767309848577,
  "created_at" : "2013-05-21 19:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tux Penguin",
      "screen_name" : "thetuxpenguin",
      "indices" : [ 0, 14 ],
      "id_str" : "416762535",
      "id" : 416762535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336922285552332803",
  "geo" : { },
  "id_str" : "336926842785239044",
  "in_reply_to_user_id" : 416762535,
  "text" : "@thetuxpenguin oh i'm fine. just frustrated w world and usual chronic existential crisis...",
  "id" : 336926842785239044,
  "in_reply_to_status_id" : 336922285552332803,
  "created_at" : "2013-05-21 19:29:53 +0000",
  "in_reply_to_screen_name" : "thetuxpenguin",
  "in_reply_to_user_id_str" : "416762535",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 2, 15 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336919862628724737",
  "geo" : { },
  "id_str" : "336925031839981568",
  "in_reply_to_user_id" : 15364301,
  "text" : ". @BrianMerritt love Saint Therese of Lisieux. read The Story of a Soul (on my bookshelf, too.) Her \"little way\" influences me.",
  "id" : 336925031839981568,
  "in_reply_to_status_id" : 336919862628724737,
  "created_at" : "2013-05-21 19:22:42 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336922934281117696",
  "text" : "RT @davidpakmanshow: Very interesting story, parking meter 'Robin Hoods' who save people from parking tickets are getting sued http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/vVESOalhTX",
        "expanded_url" : "http:\/\/ow.ly\/lfYzi",
        "display_url" : "ow.ly\/lfYzi"
      } ]
    },
    "geo" : { },
    "id_str" : "336922257689546752",
    "text" : "Very interesting story, parking meter 'Robin Hoods' who save people from parking tickets are getting sued http:\/\/t.co\/vVESOalhTX",
    "id" : 336922257689546752,
    "created_at" : "2013-05-21 19:11:40 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 336922934281117696,
  "created_at" : "2013-05-21 19:14:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336922201355857920",
  "text" : "either he was so bad previously that i'm his punishment.. or he's advanced angel w the exp to handle me.. (I lean to the 2nd)",
  "id" : 336922201355857920,
  "created_at" : "2013-05-21 19:11:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336921635795914752",
  "text" : "Hubby deserves a big mansion (Jesus\/many mansions) for marrying me. He is my caretaker, keeps me out of trouble. Bless him.",
  "id" : 336921635795914752,
  "created_at" : "2013-05-21 19:09:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336920989382344704",
  "text" : "\"There but for the grace of God, go I.\" I could have easily, easily been many \"bad\" things; done so much worse; caused more pain.",
  "id" : 336920989382344704,
  "created_at" : "2013-05-21 19:06:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336920363629961216",
  "text" : "i'm not always gentle and sweet. i've been cruel.",
  "id" : 336920363629961216,
  "created_at" : "2013-05-21 19:04:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336919972251049984",
  "text" : "go ahead and judge me.. go ahead. i'd love it if you would. tell me why you don't like me.",
  "id" : 336919972251049984,
  "created_at" : "2013-05-21 19:02:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336891494906617856",
  "geo" : { },
  "id_str" : "336892951525462016",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl nice! peaceful...",
  "id" : 336892951525462016,
  "in_reply_to_status_id" : 336891494906617856,
  "created_at" : "2013-05-21 17:15:13 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336884634006740993",
  "geo" : { },
  "id_str" : "336886418095886336",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen never thought about cows getting a bath..lol",
  "id" : 336886418095886336,
  "in_reply_to_status_id" : 336884634006740993,
  "created_at" : "2013-05-21 16:49:15 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoulPancake",
      "screen_name" : "soulpancake",
      "indices" : [ 75, 87 ],
      "id_str" : "19636959",
      "id" : 19636959
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 93, 102 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/XumfjIz5ER",
      "expanded_url" : "http:\/\/www.upworthy.com\/this-kid-just-died-what-he-left-behind-is-wondtacular-rip?g=2",
      "display_url" : "upworthy.com\/this-kid-just-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336836033515778048",
  "text" : "Zach Sobiech: \"You don't have to find out you're dying to start living\" By @soulpancake (via @Upworthy) http:\/\/t.co\/XumfjIz5ER",
  "id" : 336836033515778048,
  "created_at" : "2013-05-21 13:29:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 0, 10 ],
      "id_str" : "574554751",
      "id" : 574554751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336526173297324032",
  "geo" : { },
  "id_str" : "336527033037373441",
  "in_reply_to_user_id" : 574554751,
  "text" : "@CosmoTyme would a lion feel remorse for killing the zebra? in her mind, it was a necessary act to relieve her psychological pain.",
  "id" : 336527033037373441,
  "in_reply_to_status_id" : 336526173297324032,
  "created_at" : "2013-05-20 17:01:11 +0000",
  "in_reply_to_screen_name" : "CosmoTyme",
  "in_reply_to_user_id_str" : "574554751",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Comedy",
      "screen_name" : "HuffPostComedy",
      "indices" : [ 3, 18 ],
      "id_str" : "16232843",
      "id" : 16232843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/JFp1qfiqZo",
      "expanded_url" : "http:\/\/huff.to\/19Vl3pu",
      "display_url" : "huff.to\/19Vl3pu"
    } ]
  },
  "geo" : { },
  "id_str" : "336512110412570625",
  "text" : "RT @HuffPostComedy: Roosters and live television do NOT mix http:\/\/t.co\/JFp1qfiqZo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/JFp1qfiqZo",
        "expanded_url" : "http:\/\/huff.to\/19Vl3pu",
        "display_url" : "huff.to\/19Vl3pu"
      } ]
    },
    "geo" : { },
    "id_str" : "336504150810558466",
    "text" : "Roosters and live television do NOT mix http:\/\/t.co\/JFp1qfiqZo",
    "id" : 336504150810558466,
    "created_at" : "2013-05-20 15:30:16 +0000",
    "user" : {
      "name" : "HuffPost Comedy",
      "screen_name" : "HuffPostComedy",
      "protected" : false,
      "id_str" : "16232843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780410169058549765\/ogrtSe9d_normal.jpg",
      "id" : 16232843,
      "verified" : true
    }
  },
  "id" : 336512110412570625,
  "created_at" : "2013-05-20 16:01:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "105926473",
      "id" : 105926473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/r6inrBvUoi",
      "expanded_url" : "http:\/\/tinyurl.com\/bj4etrj",
      "display_url" : "tinyurl.com\/bj4etrj"
    } ]
  },
  "geo" : { },
  "id_str" : "336510145842524161",
  "text" : "RT @consciousbridge: Your Opinion of the Health Care Bill-Coming from Love or Fear? http:\/\/t.co\/r6inrBvUoi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/r6inrBvUoi",
        "expanded_url" : "http:\/\/tinyurl.com\/bj4etrj",
        "display_url" : "tinyurl.com\/bj4etrj"
      } ]
    },
    "geo" : { },
    "id_str" : "336509413747736576",
    "text" : "Your Opinion of the Health Care Bill-Coming from Love or Fear? http:\/\/t.co\/r6inrBvUoi",
    "id" : 336509413747736576,
    "created_at" : "2013-05-20 15:51:10 +0000",
    "user" : {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "protected" : false,
      "id_str" : "105926473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200394907\/172_normal.JPG",
      "id" : 105926473,
      "verified" : false
    }
  },
  "id" : 336510145842524161,
  "created_at" : "2013-05-20 15:54:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336509755554136065",
  "text" : "RT @wildwitchyju: Be open to receiving the most beautiful blessings today and give thanks for the miracle of being alive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336508206488641536",
    "text" : "Be open to receiving the most beautiful blessings today and give thanks for the miracle of being alive.",
    "id" : 336508206488641536,
    "created_at" : "2013-05-20 15:46:23 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 336509755554136065,
  "created_at" : "2013-05-20 15:52:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin-Health Nut News",
      "screen_name" : "unhealthytruth",
      "indices" : [ 3, 18 ],
      "id_str" : "18093097",
      "id" : 18093097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336507152623607808",
  "text" : "RT @unhealthytruth: Powerade has a controversial ingredient &amp; unlabeled allergen that sent a kid to the ER &amp; parent into action.Please RT h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/QbPzTj2WRm",
        "expanded_url" : "http:\/\/bit.ly\/13FR2dw",
        "display_url" : "bit.ly\/13FR2dw"
      } ]
    },
    "geo" : { },
    "id_str" : "336506632651563008",
    "text" : "Powerade has a controversial ingredient &amp; unlabeled allergen that sent a kid to the ER &amp; parent into action.Please RT http:\/\/t.co\/QbPzTj2WRm",
    "id" : 336506632651563008,
    "created_at" : "2013-05-20 15:40:07 +0000",
    "user" : {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "protected" : false,
      "id_str" : "25056239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684904916184256512\/Zr_EBvr0_normal.jpg",
      "id" : 25056239,
      "verified" : false
    }
  },
  "id" : 336507152623607808,
  "created_at" : "2013-05-20 15:42:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 0, 16 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336504272437006336",
  "geo" : { },
  "id_str" : "336504689921257473",
  "in_reply_to_user_id" : 175204121,
  "text" : "@WildlifeGadgets : (((",
  "id" : 336504689921257473,
  "in_reply_to_status_id" : 336504272437006336,
  "created_at" : "2013-05-20 15:32:24 +0000",
  "in_reply_to_screen_name" : "WildlifeGadgets",
  "in_reply_to_user_id_str" : "175204121",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/spxUwFpNR8",
      "expanded_url" : "http:\/\/fineartamerica.com\/contests\/national-tv-photo-contest-2.html?tab=vote&artworkid=7358513",
      "display_url" : "fineartamerica.com\/contests\/natio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336504064525340672",
  "text" : "RT @DwayneReaves: I need to get 250 votes for my photo, can you help me out? Thanks. http:\/\/t.co\/spxUwFpNR8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/spxUwFpNR8",
        "expanded_url" : "http:\/\/fineartamerica.com\/contests\/national-tv-photo-contest-2.html?tab=vote&artworkid=7358513",
        "display_url" : "fineartamerica.com\/contests\/natio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336501071730049025",
    "text" : "I need to get 250 votes for my photo, can you help me out? Thanks. http:\/\/t.co\/spxUwFpNR8",
    "id" : 336501071730049025,
    "created_at" : "2013-05-20 15:18:02 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 336504064525340672,
  "created_at" : "2013-05-20 15:29:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336494410323881984",
  "geo" : { },
  "id_str" : "336496665802457088",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 hehe",
  "id" : 336496665802457088,
  "in_reply_to_status_id" : 336494410323881984,
  "created_at" : "2013-05-20 15:00:31 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336493281431150592",
  "geo" : { },
  "id_str" : "336493924908691456",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 ahh.. so 1:00 est so prob start about 2:00 or so..lol",
  "id" : 336493924908691456,
  "in_reply_to_status_id" : 336493281431150592,
  "created_at" : "2013-05-20 14:49:38 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336492616143216640",
  "geo" : { },
  "id_str" : "336493544632111104",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 ya, got hln on, too.. i cannot imagine what she's going to come up with on the stand...",
  "id" : 336493544632111104,
  "in_reply_to_status_id" : 336492616143216640,
  "created_at" : "2013-05-20 14:48:07 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336487413809553410",
  "geo" : { },
  "id_str" : "336492011983093761",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 what time is it \"supposed\" to start?",
  "id" : 336492011983093761,
  "in_reply_to_status_id" : 336487413809553410,
  "created_at" : "2013-05-20 14:42:02 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 3, 13 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ggs6ZBKvov",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/feature.html\/ref=s9_hps_bw_feat?ie=UTF8&docId=1000677541&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=right-1&pf_rd_r=1THTBXEQPQ96K1W1V6TA&pf_rd_t=101&pf_rd_p=1468847422&pf_rd_i=133141011",
      "display_url" : "amazon.com\/gp\/feature.htm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336255661379817472",
  "text" : "RT @hughhowey: WOOL and SHIFT are $1.99 until midnight! (And the full unabridged audiobook is 99 cents!) http:\/\/t.co\/ggs6ZBKvov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/ggs6ZBKvov",
        "expanded_url" : "http:\/\/www.amazon.com\/gp\/feature.html\/ref=s9_hps_bw_feat?ie=UTF8&docId=1000677541&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=right-1&pf_rd_r=1THTBXEQPQ96K1W1V6TA&pf_rd_t=101&pf_rd_p=1468847422&pf_rd_i=133141011",
        "display_url" : "amazon.com\/gp\/feature.htm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336254834644754433",
    "text" : "WOOL and SHIFT are $1.99 until midnight! (And the full unabridged audiobook is 99 cents!) http:\/\/t.co\/ggs6ZBKvov",
    "id" : 336254834644754433,
    "created_at" : "2013-05-19 22:59:34 +0000",
    "user" : {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "protected" : false,
      "id_str" : "42300167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2894618046\/60e0fd687df4f1b155723ae931e53909_normal.jpeg",
      "id" : 42300167,
      "verified" : true
    }
  },
  "id" : 336255661379817472,
  "created_at" : "2013-05-19 23:02:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 3, 19 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Wma2l8E4AK",
      "expanded_url" : "http:\/\/twitpic.com\/crt3sd",
      "display_url" : "twitpic.com\/crt3sd"
    } ]
  },
  "geo" : { },
  "id_str" : "336253734503976961",
  "text" : "RT @HighlandFarmsME: Doris' world.  http:\/\/t.co\/Wma2l8E4AK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/Wma2l8E4AK",
        "expanded_url" : "http:\/\/twitpic.com\/crt3sd",
        "display_url" : "twitpic.com\/crt3sd"
      } ]
    },
    "geo" : { },
    "id_str" : "336252328753635329",
    "text" : "Doris' world.  http:\/\/t.co\/Wma2l8E4AK",
    "id" : 336252328753635329,
    "created_at" : "2013-05-19 22:49:37 +0000",
    "user" : {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "protected" : false,
      "id_str" : "1050419874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046136643\/52b682fed61ae8e3cd6692fcb7e54ab8_normal.jpeg",
      "id" : 1050419874,
      "verified" : false
    }
  },
  "id" : 336253734503976961,
  "created_at" : "2013-05-19 22:55:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fear",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336198130573918208",
  "geo" : { },
  "id_str" : "336199796635365376",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist sometimes reason and knowledge make you think theres no way out... #fear",
  "id" : 336199796635365376,
  "in_reply_to_status_id" : 336198130573918208,
  "created_at" : "2013-05-19 19:20:52 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 0, 12 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336181848638119936",
  "text" : "@embreeology omg.. you, too? thought i was only one...",
  "id" : 336181848638119936,
  "created_at" : "2013-05-19 18:09:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336179207438753793",
  "geo" : { },
  "id_str" : "336180873537929216",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 ouch! ((hugs))",
  "id" : 336180873537929216,
  "in_reply_to_status_id" : 336179207438753793,
  "created_at" : "2013-05-19 18:05:40 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336175815437987840",
  "text" : "RT @ZachsMind: not surprising: follow the money. RT @hpolak_es: @umairh American health care is more expensive than European health care. C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u2764\uFE0F",
        "screen_name" : "umairh",
        "indices" : [ 49, 56 ],
        "id_str" : "14321959",
        "id" : 14321959
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336173880085458944",
    "text" : "not surprising: follow the money. RT @hpolak_es: @umairh American health care is more expensive than European health care. Curious isn't it?",
    "id" : 336173880085458944,
    "created_at" : "2013-05-19 17:37:53 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 336175815437987840,
  "created_at" : "2013-05-19 17:45:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "indices" : [ 3, 13 ],
      "id_str" : "27142719",
      "id" : 27142719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/7trDzXwWWJ",
      "expanded_url" : "http:\/\/ow.ly\/lbhmp",
      "display_url" : "ow.ly\/lbhmp"
    } ]
  },
  "geo" : { },
  "id_str" : "336175577365102593",
  "text" : "RT @robkroese: If you haven't entered to win the entire Mercury trilogy on audiobook, you should, like, do that. http:\/\/t.co\/7trDzXwWWJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/7trDzXwWWJ",
        "expanded_url" : "http:\/\/ow.ly\/lbhmp",
        "display_url" : "ow.ly\/lbhmp"
      } ]
    },
    "geo" : { },
    "id_str" : "336174639615201280",
    "text" : "If you haven't entered to win the entire Mercury trilogy on audiobook, you should, like, do that. http:\/\/t.co\/7trDzXwWWJ",
    "id" : 336174639615201280,
    "created_at" : "2013-05-19 17:40:54 +0000",
    "user" : {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "protected" : false,
      "id_str" : "27142719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759449467435229184\/Kqa5_jGt_normal.jpg",
      "id" : 27142719,
      "verified" : false
    }
  },
  "id" : 336175577365102593,
  "created_at" : "2013-05-19 17:44:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336170813139066880",
  "geo" : { },
  "id_str" : "336171622551658497",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater \"the look\" .. lol",
  "id" : 336171622551658497,
  "in_reply_to_status_id" : 336170813139066880,
  "created_at" : "2013-05-19 17:28:55 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336171200810205184",
  "text" : "RT @ZachsMind: Everybody wants to go to heaven, but nobody wants to pay the price for a heaven on Earth. Follow the money. You'll find the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336170171653824513",
    "text" : "Everybody wants to go to heaven, but nobody wants to pay the price for a heaven on Earth. Follow the money. You'll find the drains.",
    "id" : 336170171653824513,
    "created_at" : "2013-05-19 17:23:09 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 336171200810205184,
  "created_at" : "2013-05-19 17:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336170111880798210",
  "text" : "i do nothing.. every day. i might as well be in a prison.",
  "id" : 336170111880798210,
  "created_at" : "2013-05-19 17:22:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 0, 12 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336168586454368257",
  "text" : "@embreeology and what is that?",
  "id" : 336168586454368257,
  "created_at" : "2013-05-19 17:16:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 52, 59 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336167611580686336",
  "text" : "RT @ZachsMind: We do. We don't wanna pay for it. RT @umairh: Why do Americans not want the basic public services of a well working country?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u2764\uFE0F",
        "screen_name" : "umairh",
        "indices" : [ 37, 44 ],
        "id_str" : "14321959",
        "id" : 14321959
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336164547440308225",
    "text" : "We do. We don't wanna pay for it. RT @umairh: Why do Americans not want the basic public services of a well working country?",
    "id" : 336164547440308225,
    "created_at" : "2013-05-19 17:00:48 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 336167611580686336,
  "created_at" : "2013-05-19 17:12:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336167042275241984",
  "text" : "i need a new life (dont we all?)",
  "id" : 336167042275241984,
  "created_at" : "2013-05-19 17:10:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336143910822891521",
  "geo" : { },
  "id_str" : "336144820710023170",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses so content!",
  "id" : 336144820710023170,
  "in_reply_to_status_id" : 336143910822891521,
  "created_at" : "2013-05-19 15:42:25 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336139363266211841",
  "text" : "RT @ZachsMind: \"Peace through superior firepower\" is not peace. It's war and the threat of war. Humanity can do better than this but few se\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336138806304579584",
    "text" : "\"Peace through superior firepower\" is not peace. It's war and the threat of war. Humanity can do better than this but few seem to want it.",
    "id" : 336138806304579584,
    "created_at" : "2013-05-19 15:18:31 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 336139363266211841,
  "created_at" : "2013-05-19 15:20:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336139327635595265",
  "text" : "RT @bend_time: hv you seen one single mind changed b\/c of tweets? or do opposite 'sides' dig in more deeply when confronted w\/ opposing vie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "think",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336138821907390464",
    "text" : "hv you seen one single mind changed b\/c of tweets? or do opposite 'sides' dig in more deeply when confronted w\/ opposing views\/facts? #think",
    "id" : 336138821907390464,
    "created_at" : "2013-05-19 15:18:34 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 336139327635595265,
  "created_at" : "2013-05-19 15:20:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/j6NSZ14dIN",
      "expanded_url" : "http:\/\/amzn.to\/GBKsYZ",
      "display_url" : "amzn.to\/GBKsYZ"
    } ]
  },
  "geo" : { },
  "id_str" : "335954473774108673",
  "text" : "finished Mighty and Strong (Righteous Series #2) by Michael Wallace http:\/\/t.co\/j6NSZ14dIN",
  "id" : 335954473774108673,
  "created_at" : "2013-05-19 03:06:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335866661695533056",
  "geo" : { },
  "id_str" : "335875710801567745",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist i like the love stuff.. dont like the sinner stuff.",
  "id" : 335875710801567745,
  "in_reply_to_status_id" : 335866661695533056,
  "created_at" : "2013-05-18 21:53:04 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335875195426451457",
  "text" : "RT @alanhdawe: While doctors look at heredity, food intolerances, biological and psychological causes, the high-speed world is the real cul\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335867682597519360",
    "text" : "While doctors look at heredity, food intolerances, biological and psychological causes, the high-speed world is the real culprit. #TGFBook",
    "id" : 335867682597519360,
    "created_at" : "2013-05-18 21:21:10 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 335875195426451457,
  "created_at" : "2013-05-18 21:51:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335845520448827394",
  "text" : "i need a job .. or a hobby.. or im going to go insane..",
  "id" : 335845520448827394,
  "created_at" : "2013-05-18 19:53:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335845363799973888",
  "text" : "i need a big change...",
  "id" : 335845363799973888,
  "created_at" : "2013-05-18 19:52:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335806669319716864",
  "geo" : { },
  "id_str" : "335807606226575360",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny lol.. i knew you'd like that one!",
  "id" : 335807606226575360,
  "in_reply_to_status_id" : 335806669319716864,
  "created_at" : "2013-05-18 17:22:26 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335802950112915457",
  "geo" : { },
  "id_str" : "335805831184531456",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny stop denying your existence! ; )",
  "id" : 335805831184531456,
  "in_reply_to_status_id" : 335802950112915457,
  "created_at" : "2013-05-18 17:15:23 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335804784969924608",
  "geo" : { },
  "id_str" : "335805358616498176",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOL",
  "id" : 335805358616498176,
  "in_reply_to_status_id" : 335804784969924608,
  "created_at" : "2013-05-18 17:13:31 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Wilkinson",
      "screen_name" : "CoolingTwilight",
      "indices" : [ 3, 19 ],
      "id_str" : "906684116",
      "id" : 906684116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/RpDitqoHLb",
      "expanded_url" : "http:\/\/wp.me\/p2LYEl-Gp",
      "display_url" : "wp.me\/p2LYEl-Gp"
    } ]
  },
  "geo" : { },
  "id_str" : "335560824498307075",
  "text" : "RT @CoolingTwilight: New post: Why Homosexuality Isn't A Sin http:\/\/t.co\/RpDitqoHLb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coolingtwilight.com\" rel=\"nofollow\"\u003ECooling Twilight\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/RpDitqoHLb",
        "expanded_url" : "http:\/\/wp.me\/p2LYEl-Gp",
        "display_url" : "wp.me\/p2LYEl-Gp"
      } ]
    },
    "geo" : { },
    "id_str" : "335500328516603904",
    "text" : "New post: Why Homosexuality Isn't A Sin http:\/\/t.co\/RpDitqoHLb",
    "id" : 335500328516603904,
    "created_at" : "2013-05-17 21:01:26 +0000",
    "user" : {
      "name" : "Dan Wilkinson",
      "screen_name" : "CoolingTwilight",
      "protected" : false,
      "id_str" : "906684116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796564332708384768\/AgjQjD5j_normal.jpg",
      "id" : 906684116,
      "verified" : false
    }
  },
  "id" : 335560824498307075,
  "created_at" : "2013-05-18 01:01:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/iM1wSACxNy",
      "expanded_url" : "http:\/\/via.me\/-c7b0bkk",
      "display_url" : "via.me\/-c7b0bkk"
    } ]
  },
  "geo" : { },
  "id_str" : "335486292378910720",
  "text" : "Two very pale toads http:\/\/t.co\/iM1wSACxNy",
  "id" : 335486292378910720,
  "created_at" : "2013-05-17 20:05:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335387092874047489",
  "text" : "the office finale was well done.",
  "id" : 335387092874047489,
  "created_at" : "2013-05-17 13:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335186117710204928",
  "text" : "my beautiful bubby is back since mothers day. peckpeckpeck",
  "id" : 335186117710204928,
  "created_at" : "2013-05-17 00:12:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335185705892454400",
  "text" : "love the birds in my yard. makes me so happy to watch and listen to them.",
  "id" : 335185705892454400,
  "created_at" : "2013-05-17 00:11:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sad",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335185542717267968",
  "text" : "the office finale #sad didnt watch much after michael left but still.. i hate endings.",
  "id" : 335185542717267968,
  "created_at" : "2013-05-17 00:10:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335185347535331328",
  "text" : "i dont agree w angelina jolie's choice but its her choice to make.",
  "id" : 335185347535331328,
  "created_at" : "2013-05-17 00:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wild About Trial",
      "screen_name" : "WildAboutTrial",
      "indices" : [ 3, 18 ],
      "id_str" : "465781550",
      "id" : 465781550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334740271688458241",
  "text" : "RT @WildAboutTrial: Juan has the image of the sink up. He asks for everyone to sit for 2 minutes in quiet to get the feel for the time this\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334739707852357632",
    "text" : "Juan has the image of the sink up. He asks for everyone to sit for 2 minutes in quiet to get the feel for the time this all took #JodiArias",
    "id" : 334739707852357632,
    "created_at" : "2013-05-15 18:39:00 +0000",
    "user" : {
      "name" : "Wild About Trial",
      "screen_name" : "WildAboutTrial",
      "protected" : false,
      "id_str" : "465781550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3667498584\/1d606d795dee365931e819091f2a575f_normal.png",
      "id" : 465781550,
      "verified" : false
    }
  },
  "id" : 334740271688458241,
  "created_at" : "2013-05-15 18:41:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/tVFIHKEXZD",
      "expanded_url" : "http:\/\/shar.es\/ZfM0y",
      "display_url" : "shar.es\/ZfM0y"
    } ]
  },
  "geo" : { },
  "id_str" : "334735338599747585",
  "text" : "North Carolina Flowers, so many different kinds!\n http:\/\/t.co\/tVFIHKEXZD",
  "id" : 334735338599747585,
  "created_at" : "2013-05-15 18:21:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334724839615102976",
  "text" : "RT @SangyeH: The most powerful thing you can tell a child (of any age): If I had to do it all over again, I would choose YOU over &amp; over &amp; \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334723032373415936",
    "text" : "The most powerful thing you can tell a child (of any age): If I had to do it all over again, I would choose YOU over &amp; over &amp; over again.",
    "id" : 334723032373415936,
    "created_at" : "2013-05-15 17:32:44 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 334724839615102976,
  "created_at" : "2013-05-15 17:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334718722763784192",
  "geo" : { },
  "id_str" : "334719481374965760",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 LOLOL",
  "id" : 334719481374965760,
  "in_reply_to_status_id" : 334718722763784192,
  "created_at" : "2013-05-15 17:18:37 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/JeIskLIbLh",
      "expanded_url" : "http:\/\/amzn.to\/10TZCzP",
      "display_url" : "amzn.to\/10TZCzP"
    } ]
  },
  "geo" : { },
  "id_str" : "334132648719052801",
  "text" : "finished The Doggone Christmas List - and Other Stories by Robb Lightfoot http:\/\/t.co\/JeIskLIbLh",
  "id" : 334132648719052801,
  "created_at" : "2013-05-14 02:26:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "disintermediation",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334099956715622402",
  "text" : "RT @AllOnMedicare: Civilized countries get rid of middlemen in the delivery of social policy. Immediate #disintermediation of health care i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "disintermediation",
        "indices" : [ 85, 103 ]
      }, {
        "text" : "AHIP",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334097222130073602",
    "text" : "Civilized countries get rid of middlemen in the delivery of social policy. Immediate #disintermediation of health care is needed. CC: #AHIP",
    "id" : 334097222130073602,
    "created_at" : "2013-05-14 00:05:59 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 334099956715622402,
  "created_at" : "2013-05-14 00:16:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 3, 17 ],
      "id_str" : "186154646",
      "id" : 186154646
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cmdr_Hadfield\/status\/334011022815944705\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/iVgyUihqEN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKKlQW6CYAAmILu.jpg",
      "id_str" : "334011022824333312",
      "id" : 334011022824333312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKKlQW6CYAAmILu.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iVgyUihqEN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334034054716473344",
  "text" : "RT @Cmdr_Hadfield: Spaceflight finale: To some this may look like a sunset. But it's a new dawn. http:\/\/t.co\/iVgyUihqEN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cmdr_Hadfield\/status\/334011022815944705\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/iVgyUihqEN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKKlQW6CYAAmILu.jpg",
        "id_str" : "334011022824333312",
        "id" : 334011022824333312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKKlQW6CYAAmILu.jpg",
        "sizes" : [ {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/iVgyUihqEN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334011022815944705",
    "text" : "Spaceflight finale: To some this may look like a sunset. But it's a new dawn. http:\/\/t.co\/iVgyUihqEN",
    "id" : 334011022815944705,
    "created_at" : "2013-05-13 18:23:28 +0000",
    "user" : {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "protected" : false,
      "id_str" : "186154646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620788674414952456\/y_ozO3uO_normal.png",
      "id" : 186154646,
      "verified" : true
    }
  },
  "id" : 334034054716473344,
  "created_at" : "2013-05-13 19:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoMuchForChristianMorality",
      "indices" : [ 104, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Gw9Xlvb4Gt",
      "expanded_url" : "http:\/\/freethoughtblogs.com\/greta\/2013\/05\/09\/victim-of-murder-for-hire-plot-a-bitch-cunt-slut-who-probably-deserved-it\/",
      "display_url" : "freethoughtblogs.com\/greta\/2013\/05\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334031348044009473",
  "text" : "RT @atheistlady76: Victim of Murder-fo\u2026 http:\/\/t.co\/Gw9Xlvb4Gt &lt;&lt;What is wrong with these people? #SoMuchForChristianMorality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoMuchForChristianMorality",
        "indices" : [ 85, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/Gw9Xlvb4Gt",
        "expanded_url" : "http:\/\/freethoughtblogs.com\/greta\/2013\/05\/09\/victim-of-murder-for-hire-plot-a-bitch-cunt-slut-who-probably-deserved-it\/",
        "display_url" : "freethoughtblogs.com\/greta\/2013\/05\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334025295516545025",
    "text" : "Victim of Murder-fo\u2026 http:\/\/t.co\/Gw9Xlvb4Gt &lt;&lt;What is wrong with these people? #SoMuchForChristianMorality",
    "id" : 334025295516545025,
    "created_at" : "2013-05-13 19:20:10 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 334031348044009473,
  "created_at" : "2013-05-13 19:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Kadrey",
      "screen_name" : "Richard_Kadrey",
      "indices" : [ 65, 80 ],
      "id_str" : "18935127",
      "id" : 18935127
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fantasy",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "thriller",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "kindle",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334019555955449857",
  "text" : "Sandman Slim, Kill The Dead, Aloha From Hell, Devil Said Bang by @Richard_Kadrey on sale @ amazon $1.99 #fantasy #thriller #kindle",
  "id" : 334019555955449857,
  "created_at" : "2013-05-13 18:57:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "philosophical",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333742486453366784",
  "text" : "what is love anyway? does it really exist? #philosophical",
  "id" : 333742486453366784,
  "created_at" : "2013-05-13 00:36:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333640608021360640",
  "text" : "my chocolate cake came out sooo lopsided.. its an embarassment to cakes everywhere!! : (",
  "id" : 333640608021360640,
  "created_at" : "2013-05-12 17:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333622941671628800",
  "geo" : { },
  "id_str" : "333629498211831808",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings yes.. sometimes i dont have the words but want to acknowledge what they posted...",
  "id" : 333629498211831808,
  "in_reply_to_status_id" : 333622941671628800,
  "created_at" : "2013-05-12 17:07:25 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ripmommy",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333604422011740160",
  "text" : "my mom was not high tech.. but she would have loved listening about all my tweeps : ) #ripmommy",
  "id" : 333604422011740160,
  "created_at" : "2013-05-12 15:27:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333590441016565760",
  "geo" : { },
  "id_str" : "333603286806573057",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ((hugs)) my mom would have loved you. she was actress, progressive, liberal. loved watching news, politics.",
  "id" : 333603286806573057,
  "in_reply_to_status_id" : 333590441016565760,
  "created_at" : "2013-05-12 15:23:16 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333590072991547394",
  "text" : "I've been blessed with two wonderful mothers.. the one who raised me (rip mommy) and the one who raised my hubby.",
  "id" : 333590072991547394,
  "created_at" : "2013-05-12 14:30:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bluebird",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333586366149586944",
  "text" : "Bubby's back!!! #bluebird at my bedroom window",
  "id" : 333586366149586944,
  "created_at" : "2013-05-12 14:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/uUz3HKwMlL",
      "expanded_url" : "http:\/\/amzn.to\/10qE79W",
      "display_url" : "amzn.to\/10qE79W"
    } ]
  },
  "geo" : { },
  "id_str" : "333401160453083139",
  "text" : "finished 101 Moments of Trust by Marion Bond West http:\/\/t.co\/uUz3HKwMlL",
  "id" : 333401160453083139,
  "created_at" : "2013-05-12 02:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333393276063322115",
  "text" : "RT @ZachsMind: so long as we separate ourselves from the monsters lurking inside our own shadows, we will continue to make the same mistake\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333390569663516674",
    "text" : "so long as we separate ourselves from the monsters lurking inside our own shadows, we will continue to make the same mistakes over and over.",
    "id" : 333390569663516674,
    "created_at" : "2013-05-12 01:18:00 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 333393276063322115,
  "created_at" : "2013-05-12 01:28:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 52, 64 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333030802315165696",
  "text" : "even w health insurance, not everything is covered! #SinglePayer #MedicareForAll",
  "id" : 333030802315165696,
  "created_at" : "2013-05-11 01:28:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 84, 96 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333030519962996736",
  "text" : "even w health insurance, many cannot afford the copay, deductible or prescriptions! #SinglePayer #MedicareForAll",
  "id" : 333030519962996736,
  "created_at" : "2013-05-11 01:27:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 56, 70 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "FF",
      "indices" : [ 52, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333029507210555392",
  "text" : "everyone deserves right to healthcare #SinglePayer  #FF @AllOnMedicare",
  "id" : 333029507210555392,
  "created_at" : "2013-05-11 01:23:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333019768426725376",
  "geo" : { },
  "id_str" : "333022623019704320",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 aww.. precious.",
  "id" : 333022623019704320,
  "in_reply_to_status_id" : 333019768426725376,
  "created_at" : "2013-05-11 00:55:55 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 15, 31 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332876869584158720",
  "text" : "Happy Birthday @JourneyTheHedgi (even though you won't see this..lol) xoxoxo",
  "id" : 332876869584158720,
  "created_at" : "2013-05-10 15:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/YWCPUqFYRV",
      "expanded_url" : "http:\/\/amzn.to\/xRgI9q",
      "display_url" : "amzn.to\/xRgI9q"
    } ]
  },
  "geo" : { },
  "id_str" : "332690062141693955",
  "text" : "finished Seven Dogs in Heaven by Leland Dirks and Angelo Dirks http:\/\/t.co\/YWCPUqFYRV",
  "id" : 332690062141693955,
  "created_at" : "2013-05-10 02:54:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theygrowuptoofast",
      "indices" : [ 62, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332643866782081024",
  "text" : "after tomorrow, there will be no minor living in our house... #theygrowuptoofast",
  "id" : 332643866782081024,
  "created_at" : "2013-05-09 23:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332585472578695168",
  "text" : "RT @AllOnMedicare: Health insurance companies are literally just investment banks that gamble w\/ ur premium dollars while denying your clai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 124, 127 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332574128924143617",
    "text" : "Health insurance companies are literally just investment banks that gamble w\/ ur premium dollars while denying your claims. #p2 #SinglePayer",
    "id" : 332574128924143617,
    "created_at" : "2013-05-09 19:13:45 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 332585472578695168,
  "created_at" : "2013-05-09 19:58:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 48, 63 ]
    }, {
      "text" : "Aetna",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "Cigna",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332584958344445953",
  "text" : "RT @AllOnMedicare: RT if you favor #SinglePayer #MedicareForAll and don't want corporate bureaucrats at #Aetna or #Cigna getting between yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 16, 28 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 29, 44 ]
      }, {
        "text" : "Aetna",
        "indices" : [ 85, 91 ]
      }, {
        "text" : "Cigna",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "p2",
        "indices" : [ 135, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332577372970819585",
    "text" : "RT if you favor #SinglePayer #MedicareForAll and don't want corporate bureaucrats at #Aetna or #Cigna getting between you and your doc #p2",
    "id" : 332577372970819585,
    "created_at" : "2013-05-09 19:26:39 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 332584958344445953,
  "created_at" : "2013-05-09 19:56:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/vOiL9Q5Dj6",
      "expanded_url" : "http:\/\/amzn.to\/190Op5s",
      "display_url" : "amzn.to\/190Op5s"
    } ]
  },
  "geo" : { },
  "id_str" : "332312307038318592",
  "text" : "finished The Paradise Lie by Paul Emil http:\/\/t.co\/vOiL9Q5Dj6",
  "id" : 332312307038318592,
  "created_at" : "2013-05-09 01:53:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 3, 13 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332302667537846273",
  "text" : "RT @UberFacts: You can painlessly kill someone through nitrogen asphyxiation - Cutting off oxygen while supplying nitrogen so the person do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332265421472407554",
    "text" : "You can painlessly kill someone through nitrogen asphyxiation - Cutting off oxygen while supplying nitrogen so the person doesn't suffocate.",
    "id" : 332265421472407554,
    "created_at" : "2013-05-08 22:47:04 +0000",
    "user" : {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "protected" : false,
      "id_str" : "95023423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615696617165885440\/JDbUuo9H_normal.jpg",
      "id" : 95023423,
      "verified" : true
    }
  },
  "id" : 332302667537846273,
  "created_at" : "2013-05-09 01:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S.E.B. MD",
      "screen_name" : "ircrc",
      "indices" : [ 3, 9 ],
      "id_str" : "19193740",
      "id" : 19193740
    }, {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 11, 23 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    }, {
      "name" : "Fr. Daniel O'Mullane",
      "screen_name" : "fatherdano",
      "indices" : [ 24, 35 ],
      "id_str" : "413925900",
      "id" : 413925900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332295658876833792",
  "text" : "RT @ircrc: @HelloPoodle @fatherdano @manjo1997 Maternity imprisonment is starting to happen in places: http:\/\/t.co\/O66MbVq586 #MaternalPers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HelloPoodle",
        "screen_name" : "HelloPoodle",
        "indices" : [ 0, 12 ],
        "id_str" : "4873061806",
        "id" : 4873061806
      }, {
        "name" : "Fr. Daniel O'Mullane",
        "screen_name" : "fatherdano",
        "indices" : [ 13, 24 ],
        "id_str" : "413925900",
        "id" : 413925900
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MaternalPersonhood",
        "indices" : [ 115, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/O66MbVq586",
        "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2013\/01\/14\/troubling-number-of-women-denied-constitutional-rights-due-to-pregnancy\/",
        "display_url" : "rawstory.com\/rs\/2013\/01\/14\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "332286790679547904",
    "text" : "@HelloPoodle @fatherdano @manjo1997 Maternity imprisonment is starting to happen in places: http:\/\/t.co\/O66MbVq586 #MaternalPersonhood",
    "id" : 332286790679547904,
    "created_at" : "2013-05-09 00:11:59 +0000",
    "user" : {
      "name" : "S.E.B. MD",
      "screen_name" : "ircrc",
      "protected" : false,
      "id_str" : "19193740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478680934577762304\/uY1fyoeF_normal.jpeg",
      "id" : 19193740,
      "verified" : false
    }
  },
  "id" : 332295658876833792,
  "created_at" : "2013-05-09 00:47:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "Occupy_Oklahoma",
      "indices" : [ 3, 19 ],
      "id_str" : "381296607",
      "id" : 381296607
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/m3knFqnjgs",
      "expanded_url" : "http:\/\/fdl.me\/12e29sN",
      "display_url" : "fdl.me\/12e29sN"
    } ]
  },
  "geo" : { },
  "id_str" : "332260724967616513",
  "text" : "RT @Occupy_Oklahoma: The Insanity of What Hospitals Charge and the Solution No One is Talking About http:\/\/t.co\/m3knFqnjgs #HCR #Medicarefo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HCR",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "MedicareforAll",
        "indices" : [ 107, 122 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/m3knFqnjgs",
        "expanded_url" : "http:\/\/fdl.me\/12e29sN",
        "display_url" : "fdl.me\/12e29sN"
      } ]
    },
    "geo" : { },
    "id_str" : "332253252693397505",
    "text" : "The Insanity of What Hospitals Charge and the Solution No One is Talking About http:\/\/t.co\/m3knFqnjgs #HCR #MedicareforAll #SinglePayer",
    "id" : 332253252693397505,
    "created_at" : "2013-05-08 21:58:43 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "Occupy_Oklahoma",
      "protected" : false,
      "id_str" : "381296607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2012373714\/291794_239202166131006_100001236735160_719331_166387000_n_normal.jpg",
      "id" : 381296607,
      "verified" : false
    }
  },
  "id" : 332260724967616513,
  "created_at" : "2013-05-08 22:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332242506148347907",
  "text" : "RT @JacksonPearce: Did people *ever* think Abercrombie was fat friendly?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332241923710525442",
    "text" : "Did people *ever* think Abercrombie was fat friendly?",
    "id" : 332241923710525442,
    "created_at" : "2013-05-08 21:13:42 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 332242506148347907,
  "created_at" : "2013-05-08 21:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332236998674882560",
  "geo" : { },
  "id_str" : "332241502971510786",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste bless him...",
  "id" : 332241502971510786,
  "in_reply_to_status_id" : 332236998674882560,
  "created_at" : "2013-05-08 21:12:01 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmonic Institute",
      "screen_name" : "caebling",
      "indices" : [ 0, 9 ],
      "id_str" : "22560761",
      "id" : 22560761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332238377883672576",
  "geo" : { },
  "id_str" : "332240883468607489",
  "in_reply_to_user_id" : 22560761,
  "text" : "@caebling yeah.. that bothered me as well..",
  "id" : 332240883468607489,
  "in_reply_to_status_id" : 332238377883672576,
  "created_at" : "2013-05-08 21:09:34 +0000",
  "in_reply_to_screen_name" : "caebling",
  "in_reply_to_user_id_str" : "22560761",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OccupyGreed",
      "screen_name" : "OccupyGreed",
      "indices" : [ 3, 15 ],
      "id_str" : "2663878302",
      "id" : 2663878302
    }, {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 17, 31 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Yale New Haven Hosp",
      "screen_name" : "YNHH",
      "indices" : [ 32, 37 ],
      "id_str" : "17368500",
      "id" : 17368500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332227808388579328",
  "text" : "RT @OccupyGreed: @AllOnMedicare @YNHH &lt;&gt; US HEALTH CARE COSTS SUCK &lt;&gt; Cost of Bowel Surgery varies between $31K - $557K &lt;&gt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All On Medicare",
        "screen_name" : "AllOnMedicare",
        "indices" : [ 0, 14 ],
        "id_str" : "1067293117",
        "id" : 1067293117
      }, {
        "name" : "Yale New Haven Hosp",
        "screen_name" : "YNHH",
        "indices" : [ 15, 20 ],
        "id_str" : "17368500",
        "id" : 17368500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 135, 157 ],
        "url" : "http:\/\/t.co\/VRaxxvwgan",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/05\/08\/1207730\/-Variable-Cost-of-Bowel-Surgery-in-USA-31K-557K",
        "display_url" : "dailykos.com\/story\/2013\/05\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "332221646897295360",
    "geo" : { },
    "id_str" : "332222186280595456",
    "in_reply_to_user_id" : 1067293117,
    "text" : "@AllOnMedicare @YNHH &lt;&gt; US HEALTH CARE COSTS SUCK &lt;&gt; Cost of Bowel Surgery varies between $31K - $557K &lt;&gt; See Charts http:\/\/t.co\/VRaxxvwgan",
    "id" : 332222186280595456,
    "in_reply_to_status_id" : 332221646897295360,
    "created_at" : "2013-05-08 19:55:16 +0000",
    "in_reply_to_screen_name" : "AllOnMedicare",
    "in_reply_to_user_id_str" : "1067293117",
    "user" : {
      "name" : "OccupyGreed",
      "screen_name" : "HealthFoody",
      "protected" : false,
      "id_str" : "392119546",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
      "id" : 392119546,
      "verified" : false
    }
  },
  "id" : 332227808388579328,
  "created_at" : "2013-05-08 20:17:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 3, 11 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332203495354662913",
  "text" : "RT @NBCNews: A verdict has been reached in the #JodiArias trial. Verdict to be read at 4:30pm ET\/1:30pm PT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 34, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332201483795853314",
    "text" : "A verdict has been reached in the #JodiArias trial. Verdict to be read at 4:30pm ET\/1:30pm PT",
    "id" : 332201483795853314,
    "created_at" : "2013-05-08 18:33:00 +0000",
    "user" : {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "protected" : false,
      "id_str" : "14173315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721554521957138436\/tTocueCd_normal.jpg",
      "id" : 14173315,
      "verified" : true
    }
  },
  "id" : 332203495354662913,
  "created_at" : "2013-05-08 18:40:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jrf",
      "screen_name" : "dontbhasty",
      "indices" : [ 3, 14 ],
      "id_str" : "21270494",
      "id" : 21270494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jPmtfKSYS1",
      "expanded_url" : "http:\/\/www.sfgate.com\/news\/article\/BEHIND-CLOSED-DOORS-Two-jury-members-were-2663861.php",
      "display_url" : "sfgate.com\/news\/article\/B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332186363208286208",
  "text" : "RT @dontbhasty: How Scott Peterson jury decided DP. Helpful insight as to how #jodiarias jury could be deliberating.  http:\/\/t.co\/jPmtfKSYS1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 62, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/jPmtfKSYS1",
        "expanded_url" : "http:\/\/www.sfgate.com\/news\/article\/BEHIND-CLOSED-DOORS-Two-jury-members-were-2663861.php",
        "display_url" : "sfgate.com\/news\/article\/B\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "332185180750098433",
    "text" : "How Scott Peterson jury decided DP. Helpful insight as to how #jodiarias jury could be deliberating.  http:\/\/t.co\/jPmtfKSYS1",
    "id" : 332185180750098433,
    "created_at" : "2013-05-08 17:28:13 +0000",
    "user" : {
      "name" : "jrf",
      "screen_name" : "dontbhasty",
      "protected" : false,
      "id_str" : "21270494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796187841432813568\/WVIFW7pB_normal.jpg",
      "id" : 21270494,
      "verified" : false
    }
  },
  "id" : 332186363208286208,
  "created_at" : "2013-05-08 17:32:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 0, 12 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332174471937007616",
  "geo" : { },
  "id_str" : "332180753515421697",
  "in_reply_to_user_id" : 45674330,
  "text" : "@oceanshaman pattern?",
  "id" : 332180753515421697,
  "in_reply_to_status_id" : 332174471937007616,
  "created_at" : "2013-05-08 17:10:37 +0000",
  "in_reply_to_screen_name" : "oceanshaman",
  "in_reply_to_user_id_str" : "45674330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Michael Brooks",
      "screen_name" : "_michaelbrooks",
      "indices" : [ 22, 37 ],
      "id_str" : "249547283",
      "id" : 249547283
    }, {
      "name" : "Majority Report",
      "screen_name" : "majorityfm",
      "indices" : [ 78, 89 ],
      "id_str" : "208361818",
      "id" : 208361818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/gO6OgBLfBl",
      "expanded_url" : "http:\/\/majority.fm\/",
      "display_url" : "majority.fm"
    } ]
  },
  "geo" : { },
  "id_str" : "332168750801494016",
  "text" : "RT @CharlesBivona: RT @_michaelbrooks: Now Why Universities Should Be Free on @majorityfm http:\/\/t.co\/gO6OgBLfBl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Brooks",
        "screen_name" : "_michaelbrooks",
        "indices" : [ 3, 18 ],
        "id_str" : "249547283",
        "id" : 249547283
      }, {
        "name" : "Majority Report",
        "screen_name" : "majorityfm",
        "indices" : [ 59, 70 ],
        "id_str" : "208361818",
        "id" : 208361818
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/gO6OgBLfBl",
        "expanded_url" : "http:\/\/majority.fm\/",
        "display_url" : "majority.fm"
      } ]
    },
    "geo" : { },
    "id_str" : "332165921764417538",
    "text" : "RT @_michaelbrooks: Now Why Universities Should Be Free on @majorityfm http:\/\/t.co\/gO6OgBLfBl",
    "id" : 332165921764417538,
    "created_at" : "2013-05-08 16:11:41 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 332168750801494016,
  "created_at" : "2013-05-08 16:22:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlackDog MGriz Heidi",
      "screen_name" : "MaBlackDog",
      "indices" : [ 3, 14 ],
      "id_str" : "22725253",
      "id" : 22725253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canada",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/tckZsvyWu0",
      "expanded_url" : "http:\/\/twitpic.com\/cp11gf",
      "display_url" : "twitpic.com\/cp11gf"
    } ]
  },
  "geo" : { },
  "id_str" : "331947034863083520",
  "text" : "RT @MaBlackDog: Moose Pass... our driveway #Canada ;) http:\/\/t.co\/tckZsvyWu0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Canada",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/tckZsvyWu0",
        "expanded_url" : "http:\/\/twitpic.com\/cp11gf",
        "display_url" : "twitpic.com\/cp11gf"
      } ]
    },
    "geo" : { },
    "id_str" : "331946721972211712",
    "text" : "Moose Pass... our driveway #Canada ;) http:\/\/t.co\/tckZsvyWu0",
    "id" : 331946721972211712,
    "created_at" : "2013-05-08 01:40:40 +0000",
    "user" : {
      "name" : "BlackDog MGriz Heidi",
      "screen_name" : "MaBlackDog",
      "protected" : false,
      "id_str" : "22725253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94038964\/zuluTwitter_normal.jpg",
      "id" : 22725253,
      "verified" : false
    }
  },
  "id" : 331947034863083520,
  "created_at" : "2013-05-08 01:41:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331861139153641472",
  "geo" : { },
  "id_str" : "331861638397435905",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields oh cool!",
  "id" : 331861638397435905,
  "in_reply_to_status_id" : 331861139153641472,
  "created_at" : "2013-05-07 20:02:34 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331858231649505280",
  "geo" : { },
  "id_str" : "331860845711720449",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields awwwwww : ) (we wanted to know but DD was NOT cooperative at all..LOL)",
  "id" : 331860845711720449,
  "in_reply_to_status_id" : 331858231649505280,
  "created_at" : "2013-05-07 19:59:25 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331827634327666689",
  "geo" : { },
  "id_str" : "331829089180741632",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time not from scratch..lol. i make it every year cuz mama likes her coconut : D",
  "id" : 331829089180741632,
  "in_reply_to_status_id" : 331827634327666689,
  "created_at" : "2013-05-07 17:53:14 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331826114987175936",
  "text" : "making a coconut cake for my MIL birthday while waiting for #jodiarias verdict...",
  "id" : 331826114987175936,
  "created_at" : "2013-05-07 17:41:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jav",
      "screen_name" : "joonsgooz",
      "indices" : [ 3, 13 ],
      "id_str" : "1163873018",
      "id" : 1163873018
    }, {
      "name" : "Ross Douthat",
      "screen_name" : "DouthatNYT",
      "indices" : [ 15, 26 ],
      "id_str" : "546135718",
      "id" : 546135718
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 27, 39 ]
    }, {
      "text" : "universalhealthcare",
      "indices" : [ 40, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331580239547334657",
  "text" : "RT @joonsgooz: @DouthatNYT #singlepayer #universalhealthcare case closed. Health shouldn't be for profit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ross Douthat",
        "screen_name" : "DouthatNYT",
        "indices" : [ 0, 11 ],
        "id_str" : "546135718",
        "id" : 546135718
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 12, 24 ]
      }, {
        "text" : "universalhealthcare",
        "indices" : [ 25, 45 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "329738860114358272",
    "geo" : { },
    "id_str" : "331520602194198529",
    "in_reply_to_user_id" : 546135718,
    "text" : "@DouthatNYT #singlepayer #universalhealthcare case closed. Health shouldn't be for profit.",
    "id" : 331520602194198529,
    "in_reply_to_status_id" : 329738860114358272,
    "created_at" : "2013-05-06 21:27:26 +0000",
    "in_reply_to_screen_name" : "DouthatNYT",
    "in_reply_to_user_id_str" : "546135718",
    "user" : {
      "name" : "jav",
      "screen_name" : "joonsgooz",
      "protected" : false,
      "id_str" : "1163873018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000321885201\/fc1a5c5c2964a675e37f6625dd953efe_normal.jpeg",
      "id" : 1163873018,
      "verified" : false
    }
  },
  "id" : 331580239547334657,
  "created_at" : "2013-05-07 01:24:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pray",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/W0CES4lbEP",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=491211557599309&set=at.491211527599312.1073741832.100001314086053.1389253826&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331514207516368896",
  "text" : "RT @SangyeH: Please #pray for this terrified dog's rescue. Brought in by his owner, too terrified to walk. https:\/\/t.co\/W0CES4lbEP Pls RT. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pray",
        "indices" : [ 7, 12 ]
      }, {
        "text" : "anipals",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/W0CES4lbEP",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=491211557599309&set=at.491211527599312.1073741832.100001314086053.1389253826&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331511744818212864",
    "text" : "Please #pray for this terrified dog's rescue. Brought in by his owner, too terrified to walk. https:\/\/t.co\/W0CES4lbEP Pls RT. #anipals",
    "id" : 331511744818212864,
    "created_at" : "2013-05-06 20:52:13 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 331514207516368896,
  "created_at" : "2013-05-06 21:02:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 33, 46 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331185684310278145",
  "geo" : { },
  "id_str" : "331196714272837632",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste I love Jon Stewart @TheDailyShow .. he's awesome!",
  "id" : 331196714272837632,
  "in_reply_to_status_id" : 331185684310278145,
  "created_at" : "2013-05-06 00:00:24 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnificent Black",
      "screen_name" : "MagnificentBlak",
      "indices" : [ 0, 16 ],
      "id_str" : "1033645693",
      "id" : 1033645693
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 42, 57 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331187833761050624",
  "geo" : { },
  "id_str" : "331196266409230336",
  "in_reply_to_user_id" : 1033645693,
  "text" : "@MagnificentBlak lol.. i like that.. hehe @AnnotatedBible",
  "id" : 331196266409230336,
  "in_reply_to_status_id" : 331187833761050624,
  "created_at" : "2013-05-05 23:58:37 +0000",
  "in_reply_to_screen_name" : "MagnificentBlak",
  "in_reply_to_user_id_str" : "1033645693",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oshum",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331190119124045825",
  "text" : "RT @oshum: Don't lose yourself in someone else's reality. #oshum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oshum",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331184447296786432",
    "text" : "Don't lose yourself in someone else's reality. #oshum",
    "id" : 331184447296786432,
    "created_at" : "2013-05-05 23:11:40 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 331190119124045825,
  "created_at" : "2013-05-05 23:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331146972364959744",
  "geo" : { },
  "id_str" : "331151892837191681",
  "in_reply_to_user_id" : 140291463,
  "text" : "@SkypilotOfHope nice... he doesn't look 70! : )",
  "id" : 331151892837191681,
  "in_reply_to_status_id" : 331146972364959744,
  "created_at" : "2013-05-05 21:02:18 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331099395401584641",
  "text" : "RT @jonlieffmd: Hour + Skype interview of Dr. Lieff on mind and brain: intelligence in animals, plants, microbes: evolution http:\/\/t.co\/8QD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/8QDsU70zSI",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=iQkmn6Ztjok",
        "display_url" : "youtube.com\/watch?v=iQkmn6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331098358410276865",
    "text" : "Hour + Skype interview of Dr. Lieff on mind and brain: intelligence in animals, plants, microbes: evolution http:\/\/t.co\/8QDsU70zSI",
    "id" : 331098358410276865,
    "created_at" : "2013-05-05 17:29:34 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 331099395401584641,
  "created_at" : "2013-05-05 17:33:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331076451464007680",
  "geo" : { },
  "id_str" : "331077647130042368",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis (((hugs)))",
  "id" : 331077647130042368,
  "in_reply_to_status_id" : 331076451464007680,
  "created_at" : "2013-05-05 16:07:16 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Godless Atheist",
      "screen_name" : "GodlessAtheist",
      "indices" : [ 3, 18 ],
      "id_str" : "136401087",
      "id" : 136401087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamJesus",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331077055422795776",
  "text" : "RT @GodlessAtheist: Why does god create those who he knows in advance will go to hell? #TeamJesus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamJesus",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295778935839526912",
    "text" : "Why does god create those who he knows in advance will go to hell? #TeamJesus",
    "id" : 295778935839526912,
    "created_at" : "2013-01-28 06:22:48 +0000",
    "user" : {
      "name" : "Godless Atheist",
      "screen_name" : "GodlessAtheist",
      "protected" : false,
      "id_str" : "136401087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3448409682\/acd835550d2d361f971b152cf5ff309e_normal.jpeg",
      "id" : 136401087,
      "verified" : false
    }
  },
  "id" : 331077055422795776,
  "created_at" : "2013-05-05 16:04:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oshum",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331068039074299906",
  "text" : "RT @oshum: Just as there are many perceptions, there are many doors to understanding...opening into the house of wisdom. #oshum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oshum",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331061456214835203",
    "text" : "Just as there are many perceptions, there are many doors to understanding...opening into the house of wisdom. #oshum",
    "id" : 331061456214835203,
    "created_at" : "2013-05-05 15:02:56 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 331068039074299906,
  "created_at" : "2013-05-05 15:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 3, 18 ],
      "id_str" : "18725718",
      "id" : 18725718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5WFrEKXqee",
      "expanded_url" : "http:\/\/shar.es\/leReI",
      "display_url" : "shar.es\/leReI"
    } ]
  },
  "geo" : { },
  "id_str" : "330865658931855363",
  "text" : "RT @christianpiatt: The cross-examination: Hell and the Love of God Debate (pt 3 of 3) VIDEO http:\/\/t.co\/5WFrEKXqee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/5WFrEKXqee",
        "expanded_url" : "http:\/\/shar.es\/leReI",
        "display_url" : "shar.es\/leReI"
      } ]
    },
    "geo" : { },
    "id_str" : "330862644942741504",
    "text" : "The cross-examination: Hell and the Love of God Debate (pt 3 of 3) VIDEO http:\/\/t.co\/5WFrEKXqee",
    "id" : 330862644942741504,
    "created_at" : "2013-05-05 01:52:56 +0000",
    "user" : {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "protected" : false,
      "id_str" : "18725718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765072572337704960\/hMj5pUf0_normal.jpg",
      "id" : 18725718,
      "verified" : false
    }
  },
  "id" : 330865658931855363,
  "created_at" : "2013-05-05 02:04:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tiny free beast",
      "screen_name" : "tinyseabeast",
      "indices" : [ 3, 16 ],
      "id_str" : "16435375",
      "id" : 16435375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330865431541858304",
  "text" : "RT @tinyseabeast: when cvs and aetna make it difficult to get your birth control corporate america wants you to get pregnant I guess",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329348175578157057",
    "text" : "when cvs and aetna make it difficult to get your birth control corporate america wants you to get pregnant I guess",
    "id" : 329348175578157057,
    "created_at" : "2013-04-30 21:34:58 +0000",
    "user" : {
      "name" : "tiny free beast",
      "screen_name" : "tinyseabeast",
      "protected" : false,
      "id_str" : "16435375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2485584677\/z493zb0wgptvs8pz9hgg_normal.jpeg",
      "id" : 16435375,
      "verified" : false
    }
  },
  "id" : 330865431541858304,
  "created_at" : "2013-05-05 02:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 3, 16 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330849974554337280",
  "text" : "RT @JoanneMFirth: One more follower, a real one to make 400. Please pass this around. An achievment would be good right about now. Thank yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330845453614714880",
    "text" : "One more follower, a real one to make 400. Please pass this around. An achievment would be good right about now. Thank you.",
    "id" : 330845453614714880,
    "created_at" : "2013-05-05 00:44:37 +0000",
    "user" : {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "protected" : false,
      "id_str" : "133780513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781251467135029255\/diCGFaAe_normal.jpg",
      "id" : 133780513,
      "verified" : false
    }
  },
  "id" : 330849974554337280,
  "created_at" : "2013-05-05 01:02:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 7, 20 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330750604655857665",
  "text" : "I wish @AmazonKindle would make it easier to deal with our kindle books.. like bulk delete and better organization of archive\/cloud.",
  "id" : 330750604655857665,
  "created_at" : "2013-05-04 18:27:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 50, 63 ],
      "id_str" : "121055499",
      "id" : 121055499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330715235117846529",
  "geo" : { },
  "id_str" : "330722164598788097",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist no problem. it's just my view. : ) @SpecterTracy",
  "id" : 330722164598788097,
  "in_reply_to_status_id" : 330715235117846529,
  "created_at" : "2013-05-04 16:34:43 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 65, 78 ],
      "id_str" : "121055499",
      "id" : 121055499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330693689154351104",
  "geo" : { },
  "id_str" : "330714875640819713",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist gut feeling, books ive read tha make sense to me. @SpecterTracy",
  "id" : 330714875640819713,
  "in_reply_to_status_id" : 330693689154351104,
  "created_at" : "2013-05-04 16:05:45 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 72, 85 ],
      "id_str" : "121055499",
      "id" : 121055499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330505821911912448",
  "geo" : { },
  "id_str" : "330679124484050945",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist consciousness was 1st cause. everything comes from that. @SpecterTracy",
  "id" : 330679124484050945,
  "in_reply_to_status_id" : 330505821911912448,
  "created_at" : "2013-05-04 13:43:41 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 0, 13 ],
      "id_str" : "121055499",
      "id" : 121055499
    }, {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 55, 69 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330513662865448960",
  "geo" : { },
  "id_str" : "330678659184726017",
  "in_reply_to_user_id" : 121055499,
  "text" : "@SpecterTracy correct. we are not our bodies or minds. @hungryatheist",
  "id" : 330678659184726017,
  "in_reply_to_status_id" : 330513662865448960,
  "created_at" : "2013-05-04 13:41:50 +0000",
  "in_reply_to_screen_name" : "SpecterTracy",
  "in_reply_to_user_id_str" : "121055499",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shanti Ramdeen",
      "screen_name" : "ShantiRamdeen",
      "indices" : [ 0, 14 ],
      "id_str" : "35062566",
      "id" : 35062566
    }, {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 64, 77 ],
      "id_str" : "121055499",
      "id" : 121055499
    }, {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 78, 92 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330480516186910720",
  "geo" : { },
  "id_str" : "330489642006765568",
  "in_reply_to_user_id" : 35062566,
  "text" : "@ShantiRamdeen yes, (imho) we are beyond our physical life exp. @SpecterTracy @hungryatheist",
  "id" : 330489642006765568,
  "in_reply_to_status_id" : 330480516186910720,
  "created_at" : "2013-05-04 01:10:45 +0000",
  "in_reply_to_screen_name" : "ShantiRamdeen",
  "in_reply_to_user_id_str" : "35062566",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Specter Tracy",
      "screen_name" : "SpecterTracy",
      "indices" : [ 0, 13 ],
      "id_str" : "121055499",
      "id" : 121055499
    }, {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 80, 94 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330478234816897026",
  "geo" : { },
  "id_str" : "330489163537317888",
  "in_reply_to_user_id" : 121055499,
  "text" : "@SpecterTracy i have come to conclusion that there is nothing but consciousness @hungryatheist",
  "id" : 330489163537317888,
  "in_reply_to_status_id" : 330478234816897026,
  "created_at" : "2013-05-04 01:08:51 +0000",
  "in_reply_to_screen_name" : "SpecterTracy",
  "in_reply_to_user_id_str" : "121055499",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330449572512006145",
  "text" : "i feel like crying... #jodiarias time for jury to deliberate...",
  "id" : 330449572512006145,
  "created_at" : "2013-05-03 22:31:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "John Connolly",
      "screen_name" : "jconnollybooks",
      "indices" : [ 65, 80 ],
      "id_str" : "207632907",
      "id" : 207632907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/4axudycT40",
      "expanded_url" : "http:\/\/ow.ly\/haou7",
      "display_url" : "ow.ly\/haou7"
    } ]
  },
  "geo" : { },
  "id_str" : "330446602827345920",
  "text" : "RT @CandyTX: Get in on the book giveaway! The Wrath of Angels by @jconnollybooks http:\/\/t.co\/4axudycT40",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Connolly",
        "screen_name" : "jconnollybooks",
        "indices" : [ 52, 67 ],
        "id_str" : "207632907",
        "id" : 207632907
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/4axudycT40",
        "expanded_url" : "http:\/\/ow.ly\/haou7",
        "display_url" : "ow.ly\/haou7"
      } ]
    },
    "geo" : { },
    "id_str" : "330444299797921792",
    "text" : "Get in on the book giveaway! The Wrath of Angels by @jconnollybooks http:\/\/t.co\/4axudycT40",
    "id" : 330444299797921792,
    "created_at" : "2013-05-03 22:10:35 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 330446602827345920,
  "created_at" : "2013-05-03 22:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330367059118678016",
  "geo" : { },
  "id_str" : "330368029387018240",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 LOLOL.. hubby chuckled at that one!",
  "id" : 330368029387018240,
  "in_reply_to_status_id" : 330367059118678016,
  "created_at" : "2013-05-03 17:07:30 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "APenAndADream",
      "screen_name" : "APenAndADream",
      "indices" : [ 48, 62 ],
      "id_str" : "740926623759863808",
      "id" : 740926623759863808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 119, 129 ]
    }, {
      "text" : "weddings",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330366138930302978",
  "text" : "RT @Matth3ous: Wanted: a TARDIS cake topper for @APenAndADream and my wedding cake, including groom and bride figures. #DoctorWho #weddings\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "APenAndADream",
        "screen_name" : "APenAndADream",
        "indices" : [ 33, 47 ],
        "id_str" : "740926623759863808",
        "id" : 740926623759863808
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 104, 114 ]
      }, {
        "text" : "weddings",
        "indices" : [ 115, 124 ]
      }, {
        "text" : "marriage",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330364958300848128",
    "text" : "Wanted: a TARDIS cake topper for @APenAndADream and my wedding cake, including groom and bride figures. #DoctorWho #weddings #marriage",
    "id" : 330364958300848128,
    "created_at" : "2013-05-03 16:55:18 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 330366138930302978,
  "created_at" : "2013-05-03 17:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330362955436810240",
  "text" : ". @1stCitizenKane yup.. been there...",
  "id" : 330362955436810240,
  "created_at" : "2013-05-03 16:47:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cLAiRe \uD83E\uDD82 \uD83E\uDD83",
      "screen_name" : "mohiclaire",
      "indices" : [ 3, 14 ],
      "id_str" : "37321285",
      "id" : 37321285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330360687698264066",
  "text" : "RT @mohiclaire: You will NEVER prove self-defense due to one single FACT: OVERKILL. #jodiarias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330359155166703618",
    "text" : "You will NEVER prove self-defense due to one single FACT: OVERKILL. #jodiarias",
    "id" : 330359155166703618,
    "created_at" : "2013-05-03 16:32:15 +0000",
    "user" : {
      "name" : "cLAiRe \uD83E\uDD82 \uD83E\uDD83",
      "screen_name" : "mohiclaire",
      "protected" : false,
      "id_str" : "37321285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776267940605726720\/sFCpX4Gc_normal.jpg",
      "id" : 37321285,
      "verified" : false
    }
  },
  "id" : 330360687698264066,
  "created_at" : "2013-05-03 16:38:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia",
      "screen_name" : "JuliaGulia809",
      "indices" : [ 3, 17 ],
      "id_str" : "179831374",
      "id" : 179831374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330360470945009666",
  "text" : "RT @JuliaGulia809: Nurmi, baling water out of the Titanic with a teacup. #JodiArias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 54, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330359148745199616",
    "text" : "Nurmi, baling water out of the Titanic with a teacup. #JodiArias",
    "id" : 330359148745199616,
    "created_at" : "2013-05-03 16:32:13 +0000",
    "user" : {
      "name" : "Julia",
      "screen_name" : "JuliaGulia809",
      "protected" : false,
      "id_str" : "179831374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776878626587283456\/mfUOXzx4_normal.jpg",
      "id" : 179831374,
      "verified" : false
    }
  },
  "id" : 330360470945009666,
  "created_at" : "2013-05-03 16:37:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "indices" : [ 0, 11 ],
      "id_str" : "20016044",
      "id" : 20016044
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 60, 75 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330359269063000064",
  "geo" : { },
  "id_str" : "330360136805797889",
  "in_reply_to_user_id" : 20016044,
  "text" : "@annihilist yes, he is pretty cool. love his questions. : ) @AnnotatedBible",
  "id" : 330360136805797889,
  "in_reply_to_status_id" : 330359269063000064,
  "created_at" : "2013-05-03 16:36:09 +0000",
  "in_reply_to_screen_name" : "annihilist",
  "in_reply_to_user_id_str" : "20016044",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "indices" : [ 81, 92 ],
      "id_str" : "20016044",
      "id" : 20016044
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 93, 108 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330355718513360896",
  "geo" : { },
  "id_str" : "330357976231735296",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray i think our true nature IS love but the ego can \/ does block that. @annihilist @AnnotatedBible",
  "id" : 330357976231735296,
  "in_reply_to_status_id" : 330355718513360896,
  "created_at" : "2013-05-03 16:27:33 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 3, 17 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/VSPEf73D1O",
      "expanded_url" : "http:\/\/thkpr.gs\/100a8t9",
      "display_url" : "thkpr.gs\/100a8t9"
    } ]
  },
  "geo" : { },
  "id_str" : "330343195097563136",
  "text" : "RT @thinkprogress: Fox News freaks out over Obama\u2019s Plan B decision: Teen sex is \u2018criminal behavior\u2019 http:\/\/t.co\/VSPEf73D1O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/VSPEf73D1O",
        "expanded_url" : "http:\/\/thkpr.gs\/100a8t9",
        "display_url" : "thkpr.gs\/100a8t9"
      } ]
    },
    "geo" : { },
    "id_str" : "330341574682763265",
    "text" : "Fox News freaks out over Obama\u2019s Plan B decision: Teen sex is \u2018criminal behavior\u2019 http:\/\/t.co\/VSPEf73D1O",
    "id" : 330341574682763265,
    "created_at" : "2013-05-03 15:22:23 +0000",
    "user" : {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "protected" : false,
      "id_str" : "55355654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762609394265632768\/H_UR_W7r_normal.jpg",
      "id" : 55355654,
      "verified" : true
    }
  },
  "id" : 330343195097563136,
  "created_at" : "2013-05-03 15:28:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "indices" : [ 3, 13 ],
      "id_str" : "606549103",
      "id" : 606549103
    }, {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "indices" : [ 15, 25 ],
      "id_str" : "606549103",
      "id" : 606549103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330336677937688576",
  "text" : "RT @ethriller: @ethriller now requesting books for review - email your thriller description to mike@e-thriller.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ethriller",
        "screen_name" : "ethriller",
        "indices" : [ 0, 10 ],
        "id_str" : "606549103",
        "id" : 606549103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330335899445522432",
    "in_reply_to_user_id" : 606549103,
    "text" : "@ethriller now requesting books for review - email your thriller description to mike@e-thriller.com",
    "id" : 330335899445522432,
    "created_at" : "2013-05-03 14:59:50 +0000",
    "in_reply_to_screen_name" : "ethriller",
    "in_reply_to_user_id_str" : "606549103",
    "user" : {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "protected" : false,
      "id_str" : "606549103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2437765921\/ai9fug2o1ypcz1lpcfed_normal.png",
      "id" : 606549103,
      "verified" : false
    }
  },
  "id" : 330336677937688576,
  "created_at" : "2013-05-03 15:02:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330120680655974401",
  "geo" : { },
  "id_str" : "330333487221592065",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 is that the judge's decision (life or death?) @BattyBrooke",
  "id" : 330333487221592065,
  "in_reply_to_status_id" : 330120680655974401,
  "created_at" : "2013-05-03 14:50:15 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kanjin Tor \u2122",
      "screen_name" : "xugla",
      "indices" : [ 3, 9 ],
      "id_str" : "141161261",
      "id" : 141161261
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/xugla\/status\/329940022834917377\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LwFUxful46",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJQus-LCcAAURgC.jpg",
      "id_str" : "329940022843305984",
      "id" : 329940022843305984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJQus-LCcAAURgC.jpg",
      "sizes" : [ {
        "h" : 542,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 528
      } ],
      "display_url" : "pic.twitter.com\/LwFUxful46"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330128912841576448",
  "text" : "RT @xugla: Who on Earth could possibly think this a 'good idea'?\n\nhttps:\/\/t.co\/LwFUxful46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/xugla\/status\/329940022834917377\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/LwFUxful46",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJQus-LCcAAURgC.jpg",
        "id_str" : "329940022843305984",
        "id" : 329940022843305984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJQus-LCcAAURgC.jpg",
        "sizes" : [ {
          "h" : 542,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 528
        } ],
        "display_url" : "pic.twitter.com\/LwFUxful46"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330122323850047489",
    "text" : "Who on Earth could possibly think this a 'good idea'?\n\nhttps:\/\/t.co\/LwFUxful46",
    "id" : 330122323850047489,
    "created_at" : "2013-05-03 00:51:10 +0000",
    "user" : {
      "name" : "Kanjin Tor \u2122",
      "screen_name" : "xugla",
      "protected" : false,
      "id_str" : "141161261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2899182651\/8352d7540a93f6dcc4d2b811fcdff437_normal.png",
      "id" : 141161261,
      "verified" : false
    }
  },
  "id" : 330128912841576448,
  "created_at" : "2013-05-03 01:17:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330110855637266432",
  "text" : "sometimes i just break out in a southern accent and babble..lol.. cuz its fun.",
  "id" : 330110855637266432,
  "created_at" : "2013-05-03 00:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330109190469210112",
  "geo" : { },
  "id_str" : "330109701083774977",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind omg.. all those pharma commercials drive me nuts..",
  "id" : 330109701083774977,
  "in_reply_to_status_id" : 330109190469210112,
  "created_at" : "2013-05-03 00:01:00 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "indices" : [ 3, 12 ],
      "id_str" : "394134197",
      "id" : 394134197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ooSJIZHWUa",
      "expanded_url" : "http:\/\/ow.ly\/kEPWV",
      "display_url" : "ow.ly\/kEPWV"
    } ]
  },
  "geo" : { },
  "id_str" : "330107855673884672",
  "text" : "RT @mfpenney: 16-Year-Old Girl Arrested and Charged With a Felony For Science Project Mistake - http:\/\/t.co\/ooSJIZHWUa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/ooSJIZHWUa",
        "expanded_url" : "http:\/\/ow.ly\/kEPWV",
        "display_url" : "ow.ly\/kEPWV"
      } ]
    },
    "geo" : { },
    "id_str" : "330107062027706368",
    "text" : "16-Year-Old Girl Arrested and Charged With a Felony For Science Project Mistake - http:\/\/t.co\/ooSJIZHWUa",
    "id" : 330107062027706368,
    "created_at" : "2013-05-02 23:50:31 +0000",
    "user" : {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "protected" : false,
      "id_str" : "394134197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596470057\/DSCN0545_normal.jpg",
      "id" : 394134197,
      "verified" : false
    }
  },
  "id" : 330107855673884672,
  "created_at" : "2013-05-02 23:53:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330092221904846848",
  "geo" : { },
  "id_str" : "330095016338915329",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 im thinking the jurors wont get case until monday am.. nurmi will take all day tomorrow?",
  "id" : 330095016338915329,
  "in_reply_to_status_id" : 330092221904846848,
  "created_at" : "2013-05-02 23:02:39 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/IiAF1x0jg1",
      "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyk4L6vy",
      "display_url" : "tmblr.co\/ZwrrNyk4L6vy"
    } ]
  },
  "geo" : { },
  "id_str" : "330083222698475520",
  "text" : "RT @parkstepp: \"You\u2019re all Buddhas, pretending not to be. You\u2019re all the Christ, pretending not to be. You\u2019re all...\" http:\/\/t.co\/IiAF1x0jg1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/IiAF1x0jg1",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyk4L6vy",
        "display_url" : "tmblr.co\/ZwrrNyk4L6vy"
      } ]
    },
    "geo" : { },
    "id_str" : "330082302065524736",
    "text" : "\"You\u2019re all Buddhas, pretending not to be. You\u2019re all the Christ, pretending not to be. You\u2019re all...\" http:\/\/t.co\/IiAF1x0jg1",
    "id" : 330082302065524736,
    "created_at" : "2013-05-02 22:12:08 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 330083222698475520,
  "created_at" : "2013-05-02 22:15:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330082229189484544",
  "text" : "RT @ChrisCapparell: Don't worry, it's safe to be open-minded. Your brain will not fall out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330080576453349376",
    "text" : "Don't worry, it's safe to be open-minded. Your brain will not fall out.",
    "id" : 330080576453349376,
    "created_at" : "2013-05-02 22:05:16 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 330082229189484544,
  "created_at" : "2013-05-02 22:11:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 3, 18 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DjQ0s0gjYV",
      "expanded_url" : "http:\/\/fb.me\/27vohjBak",
      "display_url" : "fb.me\/27vohjBak"
    } ]
  },
  "geo" : { },
  "id_str" : "330078293757919232",
  "text" : "RT @hippopotatomus: Missing Capybara in Colliers, West Virginia! She has gone walkabout. Please repost! http:\/\/t.co\/DjQ0s0gjYV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/DjQ0s0gjYV",
        "expanded_url" : "http:\/\/fb.me\/27vohjBak",
        "display_url" : "fb.me\/27vohjBak"
      } ]
    },
    "geo" : { },
    "id_str" : "330075108037251072",
    "text" : "Missing Capybara in Colliers, West Virginia! She has gone walkabout. Please repost! http:\/\/t.co\/DjQ0s0gjYV",
    "id" : 330075108037251072,
    "created_at" : "2013-05-02 21:43:32 +0000",
    "user" : {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "protected" : false,
      "id_str" : "48001363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1507916960\/flatdobbys2_normal.jpg",
      "id" : 48001363,
      "verified" : false
    }
  },
  "id" : 330078293757919232,
  "created_at" : "2013-05-02 21:56:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/kKRQQ8QlcI",
      "expanded_url" : "http:\/\/www.wngd.org\/",
      "display_url" : "wngd.org"
    } ]
  },
  "geo" : { },
  "id_str" : "330064619404144642",
  "text" : "interesting &gt;&gt; Tenth Annual World Naked Gardening Day http:\/\/t.co\/kKRQQ8QlcI",
  "id" : 330064619404144642,
  "created_at" : "2013-05-02 21:01:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329993594490466304",
  "geo" : { },
  "id_str" : "329999878774210560",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth nice... love the color!",
  "id" : 329999878774210560,
  "in_reply_to_status_id" : 329993594490466304,
  "created_at" : "2013-05-02 16:44:36 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329998840319078400",
  "text" : "@shiniestmarble pour some sugar on me, baby! LOL",
  "id" : 329998840319078400,
  "created_at" : "2013-05-02 16:40:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329976598541504512",
  "text" : "RT @TheTweetOfGod: People, it's time we had a talk about the birds and the bees. See, you're killing the birds and the bees.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329425630473117696",
    "text" : "People, it's time we had a talk about the birds and the bees. See, you're killing the birds and the bees.",
    "id" : 329425630473117696,
    "created_at" : "2013-05-01 02:42:45 +0000",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577952058680070144\/6hlNZ0_Y_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 329976598541504512,
  "created_at" : "2013-05-02 15:12:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329975831587872771",
  "text" : "@Skeptical_Lady yup, that's exactly it.. made no sense to me.. it's sado-masochism.",
  "id" : 329975831587872771,
  "created_at" : "2013-05-02 15:09:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InLinkz",
      "screen_name" : "inlinkz",
      "indices" : [ 3, 11 ],
      "id_str" : "89799722",
      "id" : 89799722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/9PeZHoIwmM",
      "expanded_url" : "http:\/\/ow.ly\/kDJLE",
      "display_url" : "ow.ly\/kDJLE"
    } ]
  },
  "geo" : { },
  "id_str" : "329974957708812289",
  "text" : "RT @inlinkz: You are invited to add your blog links to the future inlinkz examples page here: http:\/\/t.co\/9PeZHoIwmM . Don't be shy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/9PeZHoIwmM",
        "expanded_url" : "http:\/\/ow.ly\/kDJLE",
        "display_url" : "ow.ly\/kDJLE"
      } ]
    },
    "geo" : { },
    "id_str" : "329965217545068544",
    "text" : "You are invited to add your blog links to the future inlinkz examples page here: http:\/\/t.co\/9PeZHoIwmM . Don't be shy!",
    "id" : 329965217545068544,
    "created_at" : "2013-05-02 14:26:52 +0000",
    "user" : {
      "name" : "InLinkz",
      "screen_name" : "inlinkz",
      "protected" : false,
      "id_str" : "89799722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427533497066991616\/soWaayG0_normal.png",
      "id" : 89799722,
      "verified" : false
    }
  },
  "id" : 329974957708812289,
  "created_at" : "2013-05-02 15:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "indices" : [ 0, 10 ],
      "id_str" : "540023255",
      "id" : 540023255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tooslow",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329966250451152896",
  "geo" : { },
  "id_str" : "329972855838236672",
  "in_reply_to_user_id" : 540023255,
  "text" : "@chrisbr40 i dunno if i can stand listening to him if he does...lol #tooslow",
  "id" : 329972855838236672,
  "in_reply_to_status_id" : 329966250451152896,
  "created_at" : "2013-05-02 14:57:14 +0000",
  "in_reply_to_screen_name" : "chrisbr40",
  "in_reply_to_user_id_str" : "540023255",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 4, 17 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329967102045859840",
  "geo" : { },
  "id_str" : "329971971691540480",
  "in_reply_to_user_id" : 73908822,
  "text" : "omg @DwayneReaves he's fricking 2 years old!! good for you!!",
  "id" : 329971971691540480,
  "in_reply_to_status_id" : 329967102045859840,
  "created_at" : "2013-05-02 14:53:43 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nursing World",
      "screen_name" : "nursingworld",
      "indices" : [ 3, 16 ],
      "id_str" : "1542786522",
      "id" : 1542786522
    }, {
      "name" : "The Pew Trusts",
      "screen_name" : "pewtrusts",
      "indices" : [ 63, 73 ],
      "id_str" : "15738935",
      "id" : 15738935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NlGEHnkvlf",
      "expanded_url" : "http:\/\/ow.ly\/kDKNB",
      "display_url" : "ow.ly\/kDKNB"
    } ]
  },
  "geo" : { },
  "id_str" : "329971225872961538",
  "text" : "RT @nursingworld: Where do states stand on Medicaid expansion? @pewtrusts has a great resource to keep you informed http:\/\/t.co\/NlGEHnkvlf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Pew Trusts",
        "screen_name" : "pewtrusts",
        "indices" : [ 45, 55 ],
        "id_str" : "15738935",
        "id" : 15738935
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/NlGEHnkvlf",
        "expanded_url" : "http:\/\/ow.ly\/kDKNB",
        "display_url" : "ow.ly\/kDKNB"
      } ]
    },
    "geo" : { },
    "id_str" : "329968544798343168",
    "text" : "Where do states stand on Medicaid expansion? @pewtrusts has a great resource to keep you informed http:\/\/t.co\/NlGEHnkvlf",
    "id" : 329968544798343168,
    "created_at" : "2013-05-02 14:40:06 +0000",
    "user" : {
      "name" : "RN Action",
      "screen_name" : "RNAction",
      "protected" : false,
      "id_str" : "21873714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712340899590701056\/pXV6nj1N_normal.jpg",
      "id" : 21873714,
      "verified" : false
    }
  },
  "id" : 329971225872961538,
  "created_at" : "2013-05-02 14:50:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329970511801094144",
  "text" : "#jodiarias i really like listening to expert witness dr. jill hayes",
  "id" : 329970511801094144,
  "created_at" : "2013-05-02 14:47:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "indices" : [ 3, 14 ],
      "id_str" : "21497211",
      "id" : 21497211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329778064529694720",
  "text" : "RT @jedwards06: An elementary school in MA took their entire security budget and funded arts programming. Give that principal a medal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329777427666587648",
    "text" : "An elementary school in MA took their entire security budget and funded arts programming. Give that principal a medal.",
    "id" : 329777427666587648,
    "created_at" : "2013-05-02 02:00:40 +0000",
    "user" : {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "protected" : true,
      "id_str" : "21497211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000439787062\/5787c041baa171cae2de77bcf3d3a28e_normal.png",
      "id" : 21497211,
      "verified" : false
    }
  },
  "id" : 329778064529694720,
  "created_at" : "2013-05-02 02:03:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T\u1ECD\u0301p\u1EB9\u0301 F\u00E1d\u00ECran",
      "screen_name" : "graceishuman",
      "indices" : [ 3, 16 ],
      "id_str" : "167426475",
      "id" : 167426475
    }, {
      "name" : "Neil Bhaerman",
      "screen_name" : "NeilAnAlien",
      "indices" : [ 19, 31 ],
      "id_str" : "141749260",
      "id" : 141749260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329773081952391169",
  "text" : "RT @graceishuman: \"@NeilAnAlien 5 y.o.s can be trusted with guns. 14 y.o.s can't be trusted w\/ EC. teachers should be armed &amp; science e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Bhaerman",
        "screen_name" : "NeilAnAlien",
        "indices" : [ 1, 13 ],
        "id_str" : "141749260",
        "id" : 141749260
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "329765466425937921",
    "geo" : { },
    "id_str" : "329765568976654337",
    "in_reply_to_user_id" : 141749260,
    "text" : "\"@NeilAnAlien 5 y.o.s can be trusted with guns. 14 y.o.s can't be trusted w\/ EC. teachers should be armed &amp; science experiments are illegal\"",
    "id" : 329765568976654337,
    "in_reply_to_status_id" : 329765466425937921,
    "created_at" : "2013-05-02 01:13:33 +0000",
    "in_reply_to_screen_name" : "NeilAnAlien",
    "in_reply_to_user_id_str" : "141749260",
    "user" : {
      "name" : "T\u1ECD\u0301p\u1EB9\u0301 F\u00E1d\u00ECran",
      "screen_name" : "graceishuman",
      "protected" : false,
      "id_str" : "167426475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720018818777681920\/V4velIra_normal.jpg",
      "id" : 167426475,
      "verified" : false
    }
  },
  "id" : 329773081952391169,
  "created_at" : "2013-05-02 01:43:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trucker Gitty",
      "screen_name" : "TruckerGitty",
      "indices" : [ 3, 16 ],
      "id_str" : "276292665",
      "id" : 276292665
    }, {
      "name" : "Carol  Falk",
      "screen_name" : "CAFalk",
      "indices" : [ 18, 25 ],
      "id_str" : "49388157",
      "id" : 49388157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329763454959362048",
  "text" : "RT @TruckerGitty: @CAFalk My husband got a prescription 4 a new med $1200 4 a 30 days bottle. He will be doing without. That was the price \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carol  Falk",
        "screen_name" : "CAFalk",
        "indices" : [ 0, 7 ],
        "id_str" : "49388157",
        "id" : 49388157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "329758674757234689",
    "geo" : { },
    "id_str" : "329759431778762752",
    "in_reply_to_user_id" : 49388157,
    "text" : "@CAFalk My husband got a prescription 4 a new med $1200 4 a 30 days bottle. He will be doing without. That was the price after insurance.",
    "id" : 329759431778762752,
    "in_reply_to_status_id" : 329758674757234689,
    "created_at" : "2013-05-02 00:49:09 +0000",
    "in_reply_to_screen_name" : "CAFalk",
    "in_reply_to_user_id_str" : "49388157",
    "user" : {
      "name" : "Trucker Gitty",
      "screen_name" : "TruckerGitty",
      "protected" : false,
      "id_str" : "276292665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794362501269889024\/4_e9mD80_normal.jpg",
      "id" : 276292665,
      "verified" : false
    }
  },
  "id" : 329763454959362048,
  "created_at" : "2013-05-02 01:05:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Marie",
      "screen_name" : "skinnykiss",
      "indices" : [ 3, 14 ],
      "id_str" : "123739105",
      "id" : 123739105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOJUAN",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "Jodiarias",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329762467301425152",
  "text" : "RT @skinnykiss: LMAO! Do you go to the Alyce Laviolette school? #GOJUAN #Jodiarias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOJUAN",
        "indices" : [ 48, 55 ]
      }, {
        "text" : "Jodiarias",
        "indices" : [ 56, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329761730861346817",
    "text" : "LMAO! Do you go to the Alyce Laviolette school? #GOJUAN #Jodiarias",
    "id" : 329761730861346817,
    "created_at" : "2013-05-02 00:58:17 +0000",
    "user" : {
      "name" : "Alicia Marie",
      "screen_name" : "skinnykiss",
      "protected" : false,
      "id_str" : "123739105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695712448637222916\/UW6GY2CJ_normal.jpg",
      "id" : 123739105,
      "verified" : false
    }
  },
  "id" : 329762467301425152,
  "created_at" : "2013-05-02 01:01:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329733672687243264",
  "geo" : { },
  "id_str" : "329748380140072960",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible while i dont consider myself a christian per se, I appreciate your words. you are very kind. : )",
  "id" : 329748380140072960,
  "in_reply_to_status_id" : 329733672687243264,
  "created_at" : "2013-05-02 00:05:14 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Third Place Books",
      "screen_name" : "ThirdPlaceBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "38320158",
      "id" : 38320158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329692112834666496",
  "text" : "RT @ThirdPlaceBooks: 5 year old customer: I don't want a bookmark. \nUs: Its for when you stop reading. \n5 year old: I'm never going to stop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329677143615344641",
    "text" : "5 year old customer: I don't want a bookmark. \nUs: Its for when you stop reading. \n5 year old: I'm never going to stop reading.",
    "id" : 329677143615344641,
    "created_at" : "2013-05-01 19:22:10 +0000",
    "user" : {
      "name" : "Third Place Books",
      "screen_name" : "ThirdPlaceBooks",
      "protected" : false,
      "id_str" : "38320158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/201115028\/Type2_Box_normal.jpg",
      "id" : 38320158,
      "verified" : false
    }
  },
  "id" : 329692112834666496,
  "created_at" : "2013-05-01 20:21:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/uA9kb4htAd",
      "expanded_url" : "http:\/\/donnasicko.blogspot.com\/2013\/05\/damn-you-mom-and-dad.html",
      "display_url" : "donnasicko.blogspot.com\/2013\/05\/damn-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329690970415325184",
  "text" : "Uninsured and Pretty Pissed About It, A Journal http:\/\/t.co\/uA9kb4htAd",
  "id" : 329690970415325184,
  "created_at" : "2013-05-01 20:17:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u0430\u0448\u0430 \u0412\u0430\u0448\u0430",
      "screen_name" : "marco_iO9",
      "indices" : [ 0, 10 ],
      "id_str" : "2376695382",
      "id" : 2376695382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329671201205145600",
  "geo" : { },
  "id_str" : "329690055654391809",
  "in_reply_to_user_id" : 255741252,
  "text" : "@marco_iO9 yeah, i know. i was just agreeing w you.. in terms of being decent. combine ego and free will, there's bound to be friction..lol",
  "id" : 329690055654391809,
  "in_reply_to_status_id" : 329671201205145600,
  "created_at" : "2013-05-01 20:13:29 +0000",
  "in_reply_to_screen_name" : "CEKBooks",
  "in_reply_to_user_id_str" : "255741252",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/M5WTIkrIc5",
      "expanded_url" : "http:\/\/www.today.com\/news\/meet-family-who-sent-six-kids-college-age-12-1C9316706",
      "display_url" : "today.com\/news\/meet-fami\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329685893487144960",
  "text" : "Meet the family who sent six kids to college by age 12 http:\/\/t.co\/M5WTIkrIc5",
  "id" : 329685893487144960,
  "created_at" : "2013-05-01 19:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u0430\u0448\u0430 \u0412\u0430\u0448\u0430",
      "screen_name" : "marco_iO9",
      "indices" : [ 0, 10 ],
      "id_str" : "2376695382",
      "id" : 2376695382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329669304775757824",
  "geo" : { },
  "id_str" : "329670858874433536",
  "in_reply_to_user_id" : 255741252,
  "text" : "@marco_iO9 eh, you'll be just fine. no worries. : )",
  "id" : 329670858874433536,
  "in_reply_to_status_id" : 329669304775757824,
  "created_at" : "2013-05-01 18:57:12 +0000",
  "in_reply_to_screen_name" : "CEKBooks",
  "in_reply_to_user_id_str" : "255741252",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329670566632124417",
  "text" : "his tablet was hooked up to keyboard so my brain was thinking \"laptop\" not tablet..lol",
  "id" : 329670566632124417,
  "created_at" : "2013-05-01 18:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329670305423425536",
  "text" : "yesterday hubby needed a phone number off his tablet.. I couldnt figure out how to scroll, not realizing I could touch screen.. gah!",
  "id" : 329670305423425536,
  "created_at" : "2013-05-01 18:55:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Education Week",
      "screen_name" : "educationweek",
      "indices" : [ 3, 17 ],
      "id_str" : "15147042",
      "id" : 15147042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruraled",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/QMx4zpFLoy",
      "expanded_url" : "http:\/\/bit.ly\/ZUXux9",
      "display_url" : "bit.ly\/ZUXux9"
    } ]
  },
  "geo" : { },
  "id_str" : "329600715980943362",
  "text" : "RT @educationweek: Blog: W. Va. Will Be First State to Offer Free Meals to All Students http:\/\/t.co\/QMx4zpFLoy #ruraled",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ruraled",
        "indices" : [ 92, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/QMx4zpFLoy",
        "expanded_url" : "http:\/\/bit.ly\/ZUXux9",
        "display_url" : "bit.ly\/ZUXux9"
      } ]
    },
    "geo" : { },
    "id_str" : "329597694425329664",
    "text" : "Blog: W. Va. Will Be First State to Offer Free Meals to All Students http:\/\/t.co\/QMx4zpFLoy #ruraled",
    "id" : 329597694425329664,
    "created_at" : "2013-05-01 14:06:28 +0000",
    "user" : {
      "name" : "Education Week",
      "screen_name" : "educationweek",
      "protected" : false,
      "id_str" : "15147042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460768184279117825\/KVtl_fK__normal.png",
      "id" : 15147042,
      "verified" : true
    }
  },
  "id" : 329600715980943362,
  "created_at" : "2013-05-01 14:18:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Aaron\/Bach",
      "screen_name" : "Rachel_Aaron",
      "indices" : [ 3, 16 ],
      "id_str" : "132431600",
      "id" : 132431600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329600451450372097",
  "text" : "RT @Rachel_Aaron: Hachette Books (my publisher's parent co) is offering its full ebook catalog to libraries, including new releases! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/AYxm5GUdLg",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/business\/hachette-book-group-publisher-of-stephenie-meyer-expands-library-e-book-catalog\/2013\/05\/01\/ffc1b122-b22e-11e2-9fb1-62de9581c946_story.html",
        "display_url" : "washingtonpost.com\/business\/hache\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329597440820912129",
    "text" : "Hachette Books (my publisher's parent co) is offering its full ebook catalog to libraries, including new releases! http:\/\/t.co\/AYxm5GUdLg",
    "id" : 329597440820912129,
    "created_at" : "2013-05-01 14:05:28 +0000",
    "user" : {
      "name" : "Rachel Aaron\/Bach",
      "screen_name" : "Rachel_Aaron",
      "protected" : false,
      "id_str" : "132431600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721551805000187909\/kmSD0mlN_normal.jpg",
      "id" : 132431600,
      "verified" : false
    }
  },
  "id" : 329600451450372097,
  "created_at" : "2013-05-01 14:17:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]