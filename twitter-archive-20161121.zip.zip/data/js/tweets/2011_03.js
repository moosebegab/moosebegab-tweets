Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53582437074206720",
  "text" : "RT @Joeandrasi93: Reality is merely an illusion, albeit a very persistent one. \n ~Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53579587774451712",
    "text" : "Reality is merely an illusion, albeit a very persistent one. \n ~Albert Einstein",
    "id" : 53579587774451712,
    "created_at" : "2011-03-31 22:09:03 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 53582437074206720,
  "created_at" : "2011-03-31 22:20:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Sanderson",
      "screen_name" : "BrandSanderson",
      "indices" : [ 17, 32 ],
      "id_str" : "28187205",
      "id" : 28187205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53559925904912384",
  "text" : "a bit harsh?? on @BrandSanderson http:\/\/bit.ly\/hqWrY5 Homophobia In Publishing: Why It Matters",
  "id" : 53559925904912384,
  "created_at" : "2011-03-31 20:50:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53549085319368704",
  "text" : "I kick at the bag, then the small pad, then pad in front of board.",
  "id" : 53549085319368704,
  "created_at" : "2011-03-31 20:07:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53547788318932993",
  "text" : "tkd tonight. sr.master working w me to help me w kicks..so I get extra workout after class.",
  "id" : 53547788318932993,
  "created_at" : "2011-03-31 20:02:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53547380359970817",
  "text" : "my dear girl came home early yesterday & home today being ill. poor hubby started it!",
  "id" : 53547380359970817,
  "created_at" : "2011-03-31 20:01:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53547077040480256",
  "text" : "I am now achy to go along with scratchy\/semi-sore throat but I am sooo grateful it's not a sick stomach (hear that Universe..grateful!) lol",
  "id" : 53547077040480256,
  "created_at" : "2011-03-31 19:59:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "indices" : [ 3, 17 ],
      "id_str" : "23372297",
      "id" : 23372297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bronxzooscobra",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/cTGy0B6",
      "expanded_url" : "http:\/\/twitpic.com\/4feqio",
      "display_url" : "twitpic.com\/4feqio"
    } ]
  },
  "geo" : { },
  "id_str" : "53542971605397504",
  "text" : "RT @LorenzoTheCat: Bronx Zoo Cobra caught, but not before he swallowed a cat  http:\/\/t.co\/cTGy0B6      #bronxzooscobra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bronxzooscobra",
        "indices" : [ 84, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 78 ],
        "url" : "http:\/\/t.co\/cTGy0B6",
        "expanded_url" : "http:\/\/twitpic.com\/4feqio",
        "display_url" : "twitpic.com\/4feqio"
      } ]
    },
    "geo" : { },
    "id_str" : "53541445008752641",
    "text" : "Bronx Zoo Cobra caught, but not before he swallowed a cat  http:\/\/t.co\/cTGy0B6      #bronxzooscobra",
    "id" : 53541445008752641,
    "created_at" : "2011-03-31 19:37:29 +0000",
    "user" : {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "protected" : false,
      "id_str" : "23372297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1047336743\/Marked-Americana_normal.jpg",
      "id" : 23372297,
      "verified" : true
    }
  },
  "id" : 53542971605397504,
  "created_at" : "2011-03-31 19:43:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly",
      "screen_name" : "bitsyblingbooks",
      "indices" : [ 3, 19 ],
      "id_str" : "100888434",
      "id" : 100888434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53542504980676608",
  "text" : "RT @bitsyblingbooks: Twitter is going to be so boring now that the cobra is caged.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53539293112709120",
    "text" : "Twitter is going to be so boring now that the cobra is caged.",
    "id" : 53539293112709120,
    "created_at" : "2011-03-31 19:28:56 +0000",
    "user" : {
      "name" : "Kelly",
      "screen_name" : "bitsyblingbooks",
      "protected" : false,
      "id_str" : "100888434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796278760567754752\/WtJ7zjP__normal.jpg",
      "id" : 100888434,
      "verified" : false
    }
  },
  "id" : 53542504980676608,
  "created_at" : "2011-03-31 19:41:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "Dmitry",
      "screen_name" : "mrdime",
      "indices" : [ 35, 42 ],
      "id_str" : "20631644",
      "id" : 20631644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53532061167927297",
  "text" : "RT @UnseeingEyes: Oh of course not @mrdime ...there is NO MONEY IN CURES...only money in TREATMENTS. They stopped curing us after Polio.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dmitry",
        "screen_name" : "mrdime",
        "indices" : [ 17, 24 ],
        "id_str" : "20631644",
        "id" : 20631644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53531593310093312",
    "text" : "Oh of course not @mrdime ...there is NO MONEY IN CURES...only money in TREATMENTS. They stopped curing us after Polio.",
    "id" : 53531593310093312,
    "created_at" : "2011-03-31 18:58:21 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 53532061167927297,
  "created_at" : "2011-03-31 19:00:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Schatz",
      "screen_name" : "raschatz",
      "indices" : [ 3, 12 ],
      "id_str" : "33545031",
      "id" : 33545031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53528472731131904",
  "text" : "RT @raschatz: Just learned that Spring has been delayed somewhere in the southern hemisphere due to visa problems. Stay tuned for updates.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53526239910182912",
    "text" : "Just learned that Spring has been delayed somewhere in the southern hemisphere due to visa problems. Stay tuned for updates.",
    "id" : 53526239910182912,
    "created_at" : "2011-03-31 18:37:04 +0000",
    "user" : {
      "name" : "Allen Schatz",
      "screen_name" : "raschatz",
      "protected" : false,
      "id_str" : "33545031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781267051469873152\/qPqU9wO7_normal.jpg",
      "id" : 33545031,
      "verified" : false
    }
  },
  "id" : 53528472731131904,
  "created_at" : "2011-03-31 18:45:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53501575846559745",
  "geo" : { },
  "id_str" : "53514144070115328",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL.. a prev tweet mentioned arm in sling for 3 wks so no bra..",
  "id" : 53514144070115328,
  "in_reply_to_status_id" : 53501575846559745,
  "created_at" : "2011-03-31 17:49:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53466708492566528",
  "text" : "Authors, make it ez 2 buy yr books. Clearly show where (store,country) & all formats available! TY : )",
  "id" : 53466708492566528,
  "created_at" : "2011-03-31 14:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53449618150797312",
  "text" : "RT @JimBrownBooks: You know you're lazy if you're on the couch & you use your cell phone to call someone in the kitchen. FYI I've only d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 132, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53441454453948417",
    "text" : "You know you're lazy if you're on the couch & you use your cell phone to call someone in the kitchen. FYI I've only done this twice #fb",
    "id" : 53441454453948417,
    "created_at" : "2011-03-31 13:00:10 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 53449618150797312,
  "created_at" : "2011-03-31 13:32:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Beck",
      "screen_name" : "TheKevinBeck",
      "indices" : [ 3, 16 ],
      "id_str" : "299086582",
      "id" : 299086582
    }, {
      "name" : "Bronx Zoo's Cobra",
      "screen_name" : "BronxZoosCobra",
      "indices" : [ 29, 44 ],
      "id_str" : "273531261",
      "id" : 273531261
    }, {
      "name" : "The Church Mouse",
      "screen_name" : "thechurchmouse",
      "indices" : [ 57, 72 ],
      "id_str" : "19914329",
      "id" : 19914329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53449152704679936",
  "text" : "RT @TheKevinBeck: I hope the @bronxzooscobra doesn't eat @thechurchmouse.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bronx Zoo's Cobra",
        "screen_name" : "BronxZoosCobra",
        "indices" : [ 11, 26 ],
        "id_str" : "273531261",
        "id" : 273531261
      }, {
        "name" : "The Church Mouse",
        "screen_name" : "thechurchmouse",
        "indices" : [ 39, 54 ],
        "id_str" : "19914329",
        "id" : 19914329
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53444690451775489",
    "text" : "I hope the @bronxzooscobra doesn't eat @thechurchmouse.",
    "id" : 53444690451775489,
    "created_at" : "2011-03-31 13:13:01 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "protected" : true,
      "id_str" : "21812702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747936103886270464\/QfwMeqJj_normal.jpg",
      "id" : 21812702,
      "verified" : false
    }
  },
  "id" : 53449152704679936,
  "created_at" : "2011-03-31 13:30:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53269743712473089",
  "text" : "RT @GaribaldiRous: This is my beautiful pink nose earlier today. It is still just that pink and just that cute! http:\/\/yfrog.com\/h0hxivnj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53267163561209856",
    "text" : "This is my beautiful pink nose earlier today. It is still just that pink and just that cute! http:\/\/yfrog.com\/h0hxivnj",
    "id" : 53267163561209856,
    "created_at" : "2011-03-31 01:27:36 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 53269743712473089,
  "created_at" : "2011-03-31 01:37:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53188809533300736",
  "text" : "I really dont like that red-haired judge (cant think of name ATM) on The People's Court. I want to smack her.",
  "id" : 53188809533300736,
  "created_at" : "2011-03-30 20:16:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53152219251478528",
  "text" : "RT @ShhDragon: Nonviolent resistance http:\/\/plixi.com\/p\/88120962",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53151089930928128",
    "text" : "Nonviolent resistance http:\/\/plixi.com\/p\/88120962",
    "id" : 53151089930928128,
    "created_at" : "2011-03-30 17:46:21 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 53152219251478528,
  "created_at" : "2011-03-30 17:50:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53145010132103168",
  "text" : "I will take a sore throat over a sick stomach any day! scratchy throat.. got it from hubby..lol",
  "id" : 53145010132103168,
  "created_at" : "2011-03-30 17:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 31, 44 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DWTS",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53141781377851392",
  "text" : "I'm only watching #DWTS to see @RalphMacchio .. he's going to crush them! Go Ralph! \u2665",
  "id" : 53141781377851392,
  "created_at" : "2011-03-30 17:09:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bronx",
      "screen_name" : "bronxzoocobra",
      "indices" : [ 6, 20 ],
      "id_str" : "273513361",
      "id" : 273513361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53134159207612416",
  "text" : "I see @bronxzoocobra account is gone.. was enjoying the tweets..lol",
  "id" : 53134159207612416,
  "created_at" : "2011-03-30 16:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53131815594098688",
  "text" : "Nostalgia From Yesterday's Conversations: A Twitter Murder Mystery http:\/\/bit.ly\/f2pKCu 03\/30 7pm EST",
  "id" : 53131815594098688,
  "created_at" : "2011-03-30 16:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53125669391040512",
  "text" : "RT @abe_quotes: Abraham: You don't go on a vacation to get it over with, do you?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53124868299948033",
    "text" : "Abraham: You don't go on a vacation to get it over with, do you?",
    "id" : 53124868299948033,
    "created_at" : "2011-03-30 16:02:10 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 53125669391040512,
  "created_at" : "2011-03-30 16:05:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 70, 81 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52858973317120000",
  "geo" : { },
  "id_str" : "52859936786493441",
  "in_reply_to_user_id" : 176864114,
  "text" : "aww, she's got magical ears like our Kari.. up,down,all around! lol \u2665 @mimismutts",
  "id" : 52859936786493441,
  "in_reply_to_status_id" : 52858973317120000,
  "created_at" : "2011-03-29 22:29:25 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52850835192950784",
  "geo" : { },
  "id_str" : "52854296139661312",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts Yay! ((highfive)) Nellie!",
  "id" : 52854296139661312,
  "in_reply_to_status_id" : 52850835192950784,
  "created_at" : "2011-03-29 22:07:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52783111620145152",
  "geo" : { },
  "id_str" : "52787039367729152",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I think she's beautiful! smooches!",
  "id" : 52787039367729152,
  "in_reply_to_status_id" : 52783111620145152,
  "created_at" : "2011-03-29 17:39:45 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52786106130894848",
  "text" : "RT @bend_time: so- why exactly did we approve nuclear power? i mean- the dangers are so enormous. doesnt make sense to me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52785562880446464",
    "text" : "so- why exactly did we approve nuclear power? i mean- the dangers are so enormous. doesnt make sense to me.",
    "id" : 52785562880446464,
    "created_at" : "2011-03-29 17:33:53 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 52786106130894848,
  "created_at" : "2011-03-29 17:36:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52778238375759872",
  "text" : "Mr Flapper Duck Lessons from Flapper: Listening http:\/\/bit.ly\/eGFyFp",
  "id" : 52778238375759872,
  "created_at" : "2011-03-29 17:04:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52698679555014656",
  "text" : "\"You are the filling in an Oreo, no more, no less.\" http:\/\/bit.ly\/eUQxnI",
  "id" : 52698679555014656,
  "created_at" : "2011-03-29 11:48:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52695223347855361",
  "text" : "I love to see great minds meeting in my tweet stream.",
  "id" : 52695223347855361,
  "created_at" : "2011-03-29 11:34:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dwts",
      "indices" : [ 9, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52546610680430593",
  "text" : "Ralph! \u2665 #dwts",
  "id" : 52546610680430593,
  "created_at" : "2011-03-29 01:44:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52538604890763264",
  "text" : "@tragic_pizza very happy to hear this!",
  "id" : 52538604890763264,
  "created_at" : "2011-03-29 01:12:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "mystery",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 109 ],
      "url" : "http:\/\/t.co\/CBUqlQm",
      "expanded_url" : "http:\/\/amzn.to\/gXjLht",
      "display_url" : "amzn.to\/gXjLht"
    } ]
  },
  "geo" : { },
  "id_str" : "52522921150775296",
  "text" : "LIQUID FEAR: What would you pay to forget your worst nightmare? 99 cents #kindle #mystery http:\/\/t.co\/CBUqlQm",
  "id" : 52522921150775296,
  "created_at" : "2011-03-29 00:10:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52506151232872449",
  "text" : "RT @earthXplorer: New Friends are just a tweet away....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52505219048812544",
    "text" : "New Friends are just a tweet away....",
    "id" : 52505219048812544,
    "created_at" : "2011-03-28 22:59:54 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 52506151232872449,
  "created_at" : "2011-03-28 23:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52505421612711936",
  "text" : "Doranna Durgin The Heart of Dog   http:\/\/bit.ly\/ikhKP2",
  "id" : 52505421612711936,
  "created_at" : "2011-03-28 23:00:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52483520760778752",
  "text" : "RT @paulocoelho: Sorry to tell you this, but whether you agree or disagree, one day you are going to die. Stop procrastinating.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52483231152488448",
    "text" : "Sorry to tell you this, but whether you agree or disagree, one day you are going to die. Stop procrastinating.",
    "id" : 52483231152488448,
    "created_at" : "2011-03-28 21:32:32 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 52483520760778752,
  "created_at" : "2011-03-28 21:33:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52470827039469569",
  "text" : "RT @FreeRangeKids: A mom fighting for recess at her kids' grammar school, which says it takes VALUABLE TIME away from larnin' : http:\/\/b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52468932371693568",
    "text" : "A mom fighting for recess at her kids' grammar school, which says it takes VALUABLE TIME away from larnin' : http:\/\/bit.ly\/f5im5x",
    "id" : 52468932371693568,
    "created_at" : "2011-03-28 20:35:42 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 52470827039469569,
  "created_at" : "2011-03-28 20:43:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 21, 32 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52435879473577984",
  "text" : "the books I won from @modernevil came in today.. yay! The First Untrue Trilogy http:\/\/bit.ly\/f3HEGq",
  "id" : 52435879473577984,
  "created_at" : "2011-03-28 18:24:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wake Up!",
      "screen_name" : "WakeUpConnect",
      "indices" : [ 3, 17 ],
      "id_str" : "170065237",
      "id" : 170065237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52406369348890625",
  "text" : "RT @WakeUpConnect: Why is a medium able to see the future? Cause time does not exist. Why is a medium able to see a place far away? Caus ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52400627556425729",
    "text" : "Why is a medium able to see the future? Cause time does not exist. Why is a medium able to see a place far away? Cause distance is illusion",
    "id" : 52400627556425729,
    "created_at" : "2011-03-28 16:04:17 +0000",
    "user" : {
      "name" : "Wake Up!",
      "screen_name" : "WakeUpConnect",
      "protected" : false,
      "id_str" : "170065237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120293350\/WakeUp__logo_vierkant_neg_normal.jpg",
      "id" : 170065237,
      "verified" : false
    }
  },
  "id" : 52406369348890625,
  "created_at" : "2011-03-28 16:27:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52364286466592768",
  "geo" : { },
  "id_str" : "52369921438519296",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott not sure that's helpful..LOL.. years..oy!",
  "id" : 52369921438519296,
  "in_reply_to_status_id" : 52364286466592768,
  "created_at" : "2011-03-28 14:02:16 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52363791140257792",
  "geo" : { },
  "id_str" : "52369811019268097",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulzMayBe today I'm good. : )",
  "id" : 52369811019268097,
  "in_reply_to_status_id" : 52363791140257792,
  "created_at" : "2011-03-28 14:01:50 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 0, 14 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52366084807999488",
  "geo" : { },
  "id_str" : "52369170167365633",
  "in_reply_to_user_id" : 15855422,
  "text" : "@MelodyLeaLamb opens fine for me : )",
  "id" : 52369170167365633,
  "in_reply_to_status_id" : 52366084807999488,
  "created_at" : "2011-03-28 13:59:17 +0000",
  "in_reply_to_screen_name" : "MelodyLeaLamb",
  "in_reply_to_user_id_str" : "15855422",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52360876929462272",
  "text" : "Im so neurotic about my stomach that I dont like even reading about someone else being sick... like I'll catch it..lol",
  "id" : 52360876929462272,
  "created_at" : "2011-03-28 13:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52355895904047104",
  "geo" : { },
  "id_str" : "52360269585842176",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulzMayBe feel better! lots of viruses going around.",
  "id" : 52360269585842176,
  "in_reply_to_status_id" : 52355895904047104,
  "created_at" : "2011-03-28 13:23:55 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfpub",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "indieauthors",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52359881851813888",
  "text" : "RT @JAScribbles: Promo and other tips for new #selfpub and #indieauthors http:\/\/bit.ly\/eUtMGc  I'm not an expert - these are just my tho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfpub",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "indieauthors",
        "indices" : [ 42, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52357323636748288",
    "text" : "Promo and other tips for new #selfpub and #indieauthors http:\/\/bit.ly\/eUtMGc  I'm not an expert - these are just my thoughts.",
    "id" : 52357323636748288,
    "created_at" : "2011-03-28 13:12:13 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 52359881851813888,
  "created_at" : "2011-03-28 13:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 56, 67 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52357394189131777",
  "geo" : { },
  "id_str" : "52359798603255808",
  "in_reply_to_user_id" : 6994832,
  "text" : "Frankly, I cant wait for this whole thing to be over... @TrishScott",
  "id" : 52359798603255808,
  "in_reply_to_status_id" : 52357394189131777,
  "created_at" : "2011-03-28 13:22:03 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52353704883523584",
  "text" : "RT @FreeRangeKids: Cool study: Do pre-schoolers learn more by direct instruction or by experimenting? http:\/\/slate.me\/f6DE0p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52351362603827200",
    "text" : "Cool study: Do pre-schoolers learn more by direct instruction or by experimenting? http:\/\/slate.me\/f6DE0p",
    "id" : 52351362603827200,
    "created_at" : "2011-03-28 12:48:32 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 52353704883523584,
  "created_at" : "2011-03-28 12:57:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "okay",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "maybenot",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "butclose",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52350205944795136",
  "text" : "RT @ThrillersRockT: Finding an awesome new #thriller author is better than Christmas. #okay #maybenot #butclose",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 23, 32 ]
      }, {
        "text" : "okay",
        "indices" : [ 66, 71 ]
      }, {
        "text" : "maybenot",
        "indices" : [ 72, 81 ]
      }, {
        "text" : "butclose",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52347779447668736",
    "text" : "Finding an awesome new #thriller author is better than Christmas. #okay #maybenot #butclose",
    "id" : 52347779447668736,
    "created_at" : "2011-03-28 12:34:17 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 52350205944795136,
  "created_at" : "2011-03-28 12:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 66, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52350112265027584",
  "text" : "RT @Mahala: Good morning fellow worshipers of the Columbian bean. #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 54, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52348553514856448",
    "text" : "Good morning fellow worshipers of the Columbian bean. #fb",
    "id" : 52348553514856448,
    "created_at" : "2011-03-28 12:37:22 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 52350112265027584,
  "created_at" : "2011-03-28 12:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52349658084818944",
  "text" : "RT @screek: My Photos For The Day \"Coyote In The Middle Of The Day\" http:\/\/bit.ly\/i4vt31",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52335853757923328",
    "text" : "My Photos For The Day \"Coyote In The Middle Of The Day\" http:\/\/bit.ly\/i4vt31",
    "id" : 52335853757923328,
    "created_at" : "2011-03-28 11:46:54 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 52349658084818944,
  "created_at" : "2011-03-28 12:41:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52343303567458304",
  "text" : "Jacob Barnett,12, with higher IQ than Einstein develops his own theory of relativity http:\/\/bit.ly\/gjt9Bx",
  "id" : 52343303567458304,
  "created_at" : "2011-03-28 12:16:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52187942323634176",
  "text" : "I love Twitter.. ppl, ideas, sharing, learning.",
  "id" : 52187942323634176,
  "created_at" : "2011-03-28 01:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 13, 26 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52184987117690880",
  "geo" : { },
  "id_str" : "52185160766066688",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms @CrystalLewis Angela.. YES!! : )",
  "id" : 52185160766066688,
  "in_reply_to_status_id" : 52184987117690880,
  "created_at" : "2011-03-28 01:48:06 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 13, 26 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52184665582346240",
  "geo" : { },
  "id_str" : "52185016368775168",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms @CrystalLewis oh yes, CoG is good, too!",
  "id" : 52185016368775168,
  "in_reply_to_status_id" : 52184665582346240,
  "created_at" : "2011-03-28 01:47:32 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 14, 26 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52183244564729857",
  "geo" : { },
  "id_str" : "52184769936633856",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis @angelaharms @Reformation_Now I consider myself a spiritual mutt..haha.. sometimes I use term christian pagan.",
  "id" : 52184769936633856,
  "in_reply_to_status_id" : 52183244564729857,
  "created_at" : "2011-03-28 01:46:33 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52182492647665664",
  "geo" : { },
  "id_str" : "52183571456204800",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis A New Earth (Eckart Tolle) & A Course In Miracles. I'll check out Sallie McFugue..thx!",
  "id" : 52183571456204800,
  "in_reply_to_status_id" : 52182492647665664,
  "created_at" : "2011-03-28 01:41:47 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52180108315852800",
  "geo" : { },
  "id_str" : "52182109762232320",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis I think Im heading that way. still hard 2 give up God as \"God\"..",
  "id" : 52182109762232320,
  "in_reply_to_status_id" : 52180108315852800,
  "created_at" : "2011-03-28 01:35:59 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52177296521576448",
  "geo" : { },
  "id_str" : "52179858117246976",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis yr view is as valid as anyone else. : ) dont let anyone tell you its not!",
  "id" : 52179858117246976,
  "in_reply_to_status_id" : 52177296521576448,
  "created_at" : "2011-03-28 01:27:02 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52177296521576448",
  "geo" : { },
  "id_str" : "52179624393838592",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis thats ok. follow yr heart. my idea of God has changed (morphed?) a lot over past 3-5 yrs.",
  "id" : 52179624393838592,
  "in_reply_to_status_id" : 52177296521576448,
  "created_at" : "2011-03-28 01:26:06 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ 3, 14 ],
      "id_str" : "129845242",
      "id" : 129845242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52167253361299456",
  "text" : "RT @Inspire_Us: Why are you trying so hard to fit in when you were born to stand out?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52145422478737408",
    "text" : "Why are you trying so hard to fit in when you were born to stand out?",
    "id" : 52145422478737408,
    "created_at" : "2011-03-27 23:10:12 +0000",
    "user" : {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "protected" : false,
      "id_str" : "129845242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1154181325\/Inspire_Big_Bang_Twitter_Profile_Image555_-_Rounded_Corners_normal.png",
      "id" : 129845242,
      "verified" : false
    }
  },
  "id" : 52167253361299456,
  "created_at" : "2011-03-28 00:36:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52081712666120192",
  "text" : "Alonzo Mourning stops busy Miami traffic to assist a pedestrian -  http:\/\/yhoo.it\/dF0Lbv",
  "id" : 52081712666120192,
  "created_at" : "2011-03-27 18:57:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "105926473",
      "id" : 105926473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52031290328879104",
  "text" : "RT @consciousbridge: There are 2 kinds of people in the world~those who divide everyone into 2 groups and those who don't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52026077241028608",
    "text" : "There are 2 kinds of people in the world~those who divide everyone into 2 groups and those who don't.",
    "id" : 52026077241028608,
    "created_at" : "2011-03-27 15:15:58 +0000",
    "user" : {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "protected" : false,
      "id_str" : "105926473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200394907\/172_normal.JPG",
      "id" : 105926473,
      "verified" : false
    }
  },
  "id" : 52031290328879104,
  "created_at" : "2011-03-27 15:36:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tanka",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "gogyohka",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52030954327375872",
  "text" : "RT @CoyoteSings: \/\/ echo \u2022 from the side of my house \u2022 morning dove \u2022 makes a crow \u2022 laugh \/\/ #tanka #gogyohka",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tanka",
        "indices" : [ 77, 83 ]
      }, {
        "text" : "gogyohka",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52030041604890624",
    "text" : "\/\/ echo \u2022 from the side of my house \u2022 morning dove \u2022 makes a crow \u2022 laugh \/\/ #tanka #gogyohka",
    "id" : 52030041604890624,
    "created_at" : "2011-03-27 15:31:43 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 52030954327375872,
  "created_at" : "2011-03-27 15:35:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51817772182806528",
  "geo" : { },
  "id_str" : "51821829249187840",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad hope he feels better soon..poor thing.",
  "id" : 51821829249187840,
  "in_reply_to_status_id" : 51817772182806528,
  "created_at" : "2011-03-27 01:44:21 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51821401765707778",
  "text" : "RT @CrystalLewis: It isn't that \"God is not this\" or \"God is that.\" God simply *is*. And that's okay.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51820676025286657",
    "text" : "It isn't that \"God is not this\" or \"God is that.\" God simply *is*. And that's okay.",
    "id" : 51820676025286657,
    "created_at" : "2011-03-27 01:39:46 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 51821401765707778,
  "created_at" : "2011-03-27 01:42:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51820110880583680",
  "geo" : { },
  "id_str" : "51820441240735744",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis wise, indeed : )",
  "id" : 51820441240735744,
  "in_reply_to_status_id" : 51820110880583680,
  "created_at" : "2011-03-27 01:38:50 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr Flapper Duck",
      "screen_name" : "mrflapper",
      "indices" : [ 3, 13 ],
      "id_str" : "42080374",
      "id" : 42080374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51815384315215872",
  "text" : "RT @mrflapper: If you want to continue following us to keep up with O'Malley, Petunia, the goobers and the whole crew, follow @ducksandc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ducks and Clucks",
        "screen_name" : "ducksandclucks",
        "indices" : [ 111, 126 ],
        "id_str" : "272595921",
        "id" : 272595921
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51815053539807232",
    "text" : "If you want to continue following us to keep up with O'Malley, Petunia, the goobers and the whole crew, follow @ducksandclucks . Thanks.",
    "id" : 51815053539807232,
    "created_at" : "2011-03-27 01:17:26 +0000",
    "user" : {
      "name" : "Mr Flapper Duck",
      "screen_name" : "mrflapper",
      "protected" : false,
      "id_str" : "42080374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1290791380\/flapper_farewell_normal.jpg",
      "id" : 42080374,
      "verified" : false
    }
  },
  "id" : 51815384315215872,
  "created_at" : "2011-03-27 01:18:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 123, 138 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51812839362531328",
  "geo" : { },
  "id_str" : "51815164630147072",
  "in_reply_to_user_id" : 16114141,
  "text" : "def read more w Kindle due to convenience (freebies, lending, ordeering online) I dont get out much since stopped working. @KreelanWarrior",
  "id" : 51815164630147072,
  "in_reply_to_status_id" : 51812839362531328,
  "created_at" : "2011-03-27 01:17:52 +0000",
  "in_reply_to_screen_name" : "KreelanWarrior",
  "in_reply_to_user_id_str" : "16114141",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 34, 49 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51807296359120896",
  "geo" : { },
  "id_str" : "51811547135213568",
  "in_reply_to_user_id" : 16114141,
  "text" : "with my Sony & then Kindle 4 to 8 @KreelanWarrior",
  "id" : 51811547135213568,
  "in_reply_to_status_id" : 51807296359120896,
  "created_at" : "2011-03-27 01:03:30 +0000",
  "in_reply_to_screen_name" : "KreelanWarrior",
  "in_reply_to_user_id_str" : "16114141",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "indices" : [ 3, 15 ],
      "id_str" : "14345566",
      "id" : 14345566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51803601970016256",
  "text" : "RT @TheBloggess: http:\/\/justlinda.net\/blog\/?p=1936  A poignant reminder for those of us picked last for kickball, and a plea for those w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51799236118970368",
    "text" : "http:\/\/justlinda.net\/blog\/?p=1936  A poignant reminder for those of us picked last for kickball, and a plea for those who aren't.",
    "id" : 51799236118970368,
    "created_at" : "2011-03-27 00:14:34 +0000",
    "user" : {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "protected" : false,
      "id_str" : "14345566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1459362861\/cheesecake_copy2_normal.jpg",
      "id" : 14345566,
      "verified" : true
    }
  },
  "id" : 51803601970016256,
  "created_at" : "2011-03-27 00:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51801075258359808",
  "text" : "mini reeses? I'll have to try them! yum",
  "id" : 51801075258359808,
  "created_at" : "2011-03-27 00:21:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51794710804705280",
  "text" : "I see DR on tues for med rx. not sure if I want to tell her all my ailments..lol",
  "id" : 51794710804705280,
  "created_at" : "2011-03-26 23:56:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51794422379200512",
  "text" : "I think my eye pain might be from fluid behind eye. well, a guess.",
  "id" : 51794422379200512,
  "created_at" : "2011-03-26 23:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51794125036593152",
  "text" : "forgot to tell you that I saw UFO thurs eve. bright square flash then gone.",
  "id" : 51794125036593152,
  "created_at" : "2011-03-26 23:54:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 92, 107 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51783112786587648",
  "geo" : { },
  "id_str" : "51792030497640449",
  "in_reply_to_user_id" : 63804234,
  "text" : "I dont like to stay in jammies all day (unless sick) but I do get in them early like 5..lol @PeggySueCusses",
  "id" : 51792030497640449,
  "in_reply_to_status_id" : 51783112786587648,
  "created_at" : "2011-03-26 23:45:56 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 0, 15 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51777133487472640",
  "geo" : { },
  "id_str" : "51782824793088000",
  "in_reply_to_user_id" : 30825946,
  "text" : "@JonathanElliot LOL",
  "id" : 51782824793088000,
  "in_reply_to_status_id" : 51777133487472640,
  "created_at" : "2011-03-26 23:09:22 +0000",
  "in_reply_to_screen_name" : "JonathanElliot",
  "in_reply_to_user_id_str" : "30825946",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 33, 48 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51739464069947392",
  "geo" : { },
  "id_str" : "51743389842026497",
  "in_reply_to_user_id" : 63804234,
  "text" : "I don't like clowns, either! lol @PeggySueCusses",
  "id" : 51743389842026497,
  "in_reply_to_status_id" : 51739464069947392,
  "created_at" : "2011-03-26 20:32:40 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51728763339288577",
  "text" : "we had turkeys roaming our yard today.",
  "id" : 51728763339288577,
  "created_at" : "2011-03-26 19:34:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51727934171521024",
  "text" : "RT @JimBrownBooks: If I eat right I'll live longer which seems like a mean thing to do to the people who tolerate me #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51720136675164160",
    "text" : "If I eat right I'll live longer which seems like a mean thing to do to the people who tolerate me #fb",
    "id" : 51720136675164160,
    "created_at" : "2011-03-26 19:00:16 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 51727934171521024,
  "created_at" : "2011-03-26 19:31:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 24, 32 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51707912359387136",
  "geo" : { },
  "id_str" : "51709003591454720",
  "in_reply_to_user_id" : 54744689,
  "text" : "what a funny girl..hehe @SangyeH",
  "id" : 51709003591454720,
  "in_reply_to_status_id" : 51707912359387136,
  "created_at" : "2011-03-26 18:16:01 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amwriting",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51665281688408064",
  "text" : "RT @JAScribbles: Author friends - @ me about your ebook. I will buy two more this weekend. #amwriting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amwriting",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51662776007008257",
    "text" : "Author friends - @ me about your ebook. I will buy two more this weekend. #amwriting",
    "id" : 51662776007008257,
    "created_at" : "2011-03-26 15:12:20 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 51665281688408064,
  "created_at" : "2011-03-26 15:22:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51665042634055680",
  "text" : "RT @JAScribbles: If someone walked up to you on the street and said - tell me about your book, I want to buy it. Would you walk away fro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51664345226162176",
    "text" : "If someone walked up to you on the street and said - tell me about your book, I want to buy it. Would you walk away from them?",
    "id" : 51664345226162176,
    "created_at" : "2011-03-26 15:18:34 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 51665042634055680,
  "created_at" : "2011-03-26 15:21:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Steven B",
      "screen_name" : "_isolar_",
      "indices" : [ 19, 28 ],
      "id_str" : "124166373",
      "id" : 124166373
    }, {
      "name" : "Will Senior",
      "screen_name" : "WilSenior",
      "indices" : [ 33, 43 ],
      "id_str" : "104905488",
      "id" : 104905488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51644952429604864",
  "text" : "RT @TrishScott: RT @_isolar_: RT @WilSenior: I have found that there is nothing to find.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven B",
        "screen_name" : "_isolar_",
        "indices" : [ 3, 12 ],
        "id_str" : "124166373",
        "id" : 124166373
      }, {
        "name" : "Will Senior",
        "screen_name" : "WilSenior",
        "indices" : [ 17, 27 ],
        "id_str" : "104905488",
        "id" : 104905488
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51643299706048512",
    "text" : "RT @_isolar_: RT @WilSenior: I have found that there is nothing to find.",
    "id" : 51643299706048512,
    "created_at" : "2011-03-26 13:54:56 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 51644952429604864,
  "created_at" : "2011-03-26 14:01:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51644218829049857",
  "text" : "RT @JeremyCShipp: Check out my wife's newest blog post! You can enter to win a lace bookmark that she made: http:\/\/tinyurl.com\/4z5xe9a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51638942495289344",
    "text" : "Check out my wife's newest blog post! You can enter to win a lace bookmark that she made: http:\/\/tinyurl.com\/4z5xe9a",
    "id" : 51638942495289344,
    "created_at" : "2011-03-26 13:37:37 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 51644218829049857,
  "created_at" : "2011-03-26 13:58:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51643776560660480",
  "text" : "@HEATHENRABBIT Mom's doing well. I'm up & down w my stomach. Guess I'll have to ask DR.. bleh. Not bad ATM, tho. : )",
  "id" : 51643776560660480,
  "created_at" : "2011-03-26 13:56:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 77, 91 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/MGDuXFn",
      "expanded_url" : "http:\/\/beadedartshop.blogspot.com\/2011\/03\/big-easter-basket-give-away.html",
      "display_url" : "beadedartshop.blogspot.com\/2011\/03\/big-ea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "51434359311433728",
  "text" : "The Beaded Art Shop: The Big Easter Basket Give Away http:\/\/t.co\/MGDuXFn via @MelodyLeaLamb",
  "id" : 51434359311433728,
  "created_at" : "2011-03-26 00:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfpub",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51386761510793216",
  "text" : "RT @JAScribbles: I am going to buy a few ebooks this weekend. Go ahead and pitch me yours if it's under $3. I will buy it. #selfpub #ind ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfpub",
        "indices" : [ 106, 114 ]
      }, {
        "text" : "indieauthor",
        "indices" : [ 115, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51382445395812352",
    "text" : "I am going to buy a few ebooks this weekend. Go ahead and pitch me yours if it's under $3. I will buy it. #selfpub #indieauthor",
    "id" : 51382445395812352,
    "created_at" : "2011-03-25 20:38:24 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 51386761510793216,
  "created_at" : "2011-03-25 20:55:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Beck",
      "screen_name" : "TheKevinBeck",
      "indices" : [ 3, 16 ],
      "id_str" : "299086582",
      "id" : 299086582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51386622633197568",
  "text" : "RT @TheKevinBeck: Life is hard. Show some compassion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51383858171609088",
    "text" : "Life is hard. Show some compassion.",
    "id" : 51383858171609088,
    "created_at" : "2011-03-25 20:44:01 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "protected" : true,
      "id_str" : "21812702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747936103886270464\/QfwMeqJj_normal.jpg",
      "id" : 21812702,
      "verified" : false
    }
  },
  "id" : 51386622633197568,
  "created_at" : "2011-03-25 20:55:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 39, 53 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51330930299768833",
  "geo" : { },
  "id_str" : "51332520008097792",
  "in_reply_to_user_id" : 73908822,
  "text" : "you're a good dad. enjoy your day! : ) @Dwayne_Reaves",
  "id" : 51332520008097792,
  "in_reply_to_status_id" : 51330930299768833,
  "created_at" : "2011-03-25 17:20:01 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr Flapper Duck",
      "screen_name" : "mrflapper",
      "indices" : [ 3, 13 ],
      "id_str" : "42080374",
      "id" : 42080374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51312283980271616",
  "text" : "RT @mrflapper: My sweet boy Flapper passed away in my arms peacefully and quietly this morning at 7:20am. Rest in peace little super bud ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51307730178289664",
    "text" : "My sweet boy Flapper passed away in my arms peacefully and quietly this morning at 7:20am. Rest in peace little super buddy. XOXOX - Tiff",
    "id" : 51307730178289664,
    "created_at" : "2011-03-25 15:41:30 +0000",
    "user" : {
      "name" : "Mr Flapper Duck",
      "screen_name" : "mrflapper",
      "protected" : false,
      "id_str" : "42080374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1290791380\/flapper_farewell_normal.jpg",
      "id" : 42080374,
      "verified" : false
    }
  },
  "id" : 51312283980271616,
  "created_at" : "2011-03-25 15:59:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 0, 12 ],
      "id_str" : "130344581",
      "id" : 130344581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51094965408899072",
  "geo" : { },
  "id_str" : "51105838236049408",
  "in_reply_to_user_id" : 130344581,
  "text" : "@_karmadorje omg'ness.. sorry to hear that. ive never had leg cramps but hubby has. ((hugs))",
  "id" : 51105838236049408,
  "in_reply_to_status_id" : 51094965408899072,
  "created_at" : "2011-03-25 02:19:15 +0000",
  "in_reply_to_screen_name" : "_karmadorje",
  "in_reply_to_user_id_str" : "130344581",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50941812583579648",
  "text" : "RT @wow_trees: Solar power & alternative fuels can easily be replace nuke & oil. But...it won't make the elites as much money as death & ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50937057232683008",
    "text" : "Solar power & alternative fuels can easily be replace nuke & oil. But...it won't make the elites as much money as death & destruction.",
    "id" : 50937057232683008,
    "created_at" : "2011-03-24 15:08:35 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 50941812583579648,
  "created_at" : "2011-03-24 15:27:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 27, 39 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50921937681121280",
  "geo" : { },
  "id_str" : "50932182755192832",
  "in_reply_to_user_id" : 71118021,
  "text" : "yeah, rub it in : P .. lol @CaroleODell",
  "id" : 50932182755192832,
  "in_reply_to_status_id" : 50921937681121280,
  "created_at" : "2011-03-24 14:49:13 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 76, 88 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50909349249429504",
  "geo" : { },
  "id_str" : "50914293683720192",
  "in_reply_to_user_id" : 15349954,
  "text" : "oh definitely, its the journey. by learning to \"fail\", I'm learning to try! @angelaharms",
  "id" : 50914293683720192,
  "in_reply_to_status_id" : 50909349249429504,
  "created_at" : "2011-03-24 13:38:08 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 22, 34 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 35, 45 ],
      "id_str" : "15572724",
      "id" : 15572724
    }, {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 46, 58 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50913867454361600",
  "text" : "Thanks peeps ((hugs)) @angelaharms @ShhDragon @JAScribbles yup, I'll do it. proud how far I've come already! : )",
  "id" : 50913867454361600,
  "created_at" : "2011-03-24 13:36:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50907842475065345",
  "text" : "btw.. I got a No Change for testing. No red belt for me just yet. Didn't break my board.. again.",
  "id" : 50907842475065345,
  "created_at" : "2011-03-24 13:12:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookLending.com",
      "screen_name" : "BookLending",
      "indices" : [ 61, 73 ],
      "id_str" : "233470432",
      "id" : 233470432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50907434818093056",
  "text" : "What will I read? LOL I've got so many books out on loan via @BookLending ; )",
  "id" : 50907434818093056,
  "created_at" : "2011-03-24 13:10:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50903568529625088",
  "text" : "Who's in hell? Pastor's book sparks eternal debate http:\/\/yhoo.it\/erpanu",
  "id" : 50903568529625088,
  "created_at" : "2011-03-24 12:55:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kari",
      "screen_name" : "WiltingSoul",
      "indices" : [ 21, 33 ],
      "id_str" : "24330014",
      "id" : 24330014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50604409721323520",
  "geo" : { },
  "id_str" : "50609073460232192",
  "in_reply_to_user_id" : 24330014,
  "text" : "feel better ((hugs)) @WiltingSoul",
  "id" : 50609073460232192,
  "in_reply_to_status_id" : 50604409721323520,
  "created_at" : "2011-03-23 17:25:18 +0000",
  "in_reply_to_screen_name" : "WiltingSoul",
  "in_reply_to_user_id_str" : "24330014",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50596403877126144",
  "text" : "A Survey for Married Couples | One Mystake at a Tyme http:\/\/bit.ly\/gtaQoX",
  "id" : 50596403877126144,
  "created_at" : "2011-03-23 16:34:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 80, 93 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50548923198210048",
  "geo" : { },
  "id_str" : "50549382700990464",
  "in_reply_to_user_id" : 44101564,
  "text" : "when my Dad transitioned, I said he was set free from shackles of his body..lol @Joeandrasi93",
  "id" : 50549382700990464,
  "in_reply_to_status_id" : 50548923198210048,
  "created_at" : "2011-03-23 13:28:06 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 32, 45 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50548196715397120",
  "geo" : { },
  "id_str" : "50548619715153920",
  "in_reply_to_user_id" : 44101564,
  "text" : "transitioned.. I like that! : ) @Joeandrasi93",
  "id" : 50548619715153920,
  "in_reply_to_status_id" : 50548196715397120,
  "created_at" : "2011-03-23 13:25:04 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50546712493830144",
  "geo" : { },
  "id_str" : "50548438647046144",
  "in_reply_to_user_id" : 75708394,
  "text" : "my mom loved her and was told she looked like her, too. they are same age. @JulzMayBe",
  "id" : 50548438647046144,
  "in_reply_to_status_id" : 50546712493830144,
  "created_at" : "2011-03-23 13:24:21 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breaking News",
      "screen_name" : "BreakingNews",
      "indices" : [ 3, 16 ],
      "id_str" : "6017542",
      "id" : 6017542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50546065392418817",
  "text" : "RT @BreakingNews: Actress Elizabeth Taylor has died, NBC News confirms",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.breakingnews.com\" rel=\"nofollow\"\u003Ebreakingnews.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50542894402117632",
    "text" : "Actress Elizabeth Taylor has died, NBC News confirms",
    "id" : 50542894402117632,
    "created_at" : "2011-03-23 13:02:19 +0000",
    "user" : {
      "name" : "Breaking News",
      "screen_name" : "BreakingNews",
      "protected" : false,
      "id_str" : "6017542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000700003994\/53d967d27656bd5941e7e1fcddf47e0b_normal.png",
      "id" : 6017542,
      "verified" : true
    }
  },
  "id" : 50546065392418817,
  "created_at" : "2011-03-23 13:14:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 100, 115 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50536841807536129",
  "geo" : { },
  "id_str" : "50545681886224384",
  "in_reply_to_user_id" : 143989898,
  "text" : "thrillers are my mainstay..lol.. and I love indies. maybe find some here: http:\/\/budurl.com\/myreads @ThrillersRockT",
  "id" : 50545681886224384,
  "in_reply_to_status_id" : 50536841807536129,
  "created_at" : "2011-03-23 13:13:24 +0000",
  "in_reply_to_screen_name" : "ThrillersRockT",
  "in_reply_to_user_id_str" : "143989898",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "indices" : [ 3, 12 ],
      "id_str" : "48164887",
      "id" : 48164887
    }, {
      "name" : "Miriam Dunn",
      "screen_name" : "Miridunn",
      "indices" : [ 17, 26 ],
      "id_str" : "33475365",
      "id" : 33475365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gogyohka",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50544190727270401",
  "text" : "RT @amoz1939: RT @Miridunn: The Crow ~ speaks to me ~ in tongues ~ I do not ~ understand #gogyohka",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Miriam Dunn",
        "screen_name" : "Miridunn",
        "indices" : [ 3, 12 ],
        "id_str" : "33475365",
        "id" : 33475365
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gogyohka",
        "indices" : [ 75, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50539210716876800",
    "text" : "RT @Miridunn: The Crow ~ speaks to me ~ in tongues ~ I do not ~ understand #gogyohka",
    "id" : 50539210716876800,
    "created_at" : "2011-03-23 12:47:41 +0000",
    "user" : {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "protected" : false,
      "id_str" : "48164887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775135706238758913\/cwiqEl_8_normal.jpg",
      "id" : 48164887,
      "verified" : false
    }
  },
  "id" : 50544190727270401,
  "created_at" : "2011-03-23 13:07:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "indices" : [ 3, 12 ],
      "id_str" : "48164887",
      "id" : 48164887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50544148515790848",
  "text" : "RT @amoz1939: RT @I_Anubhuti: There are wonders ~ almost at every step of our lives ~ so how can there be ~ only ~ Seven Wonders of the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gogyohka",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50539267935584256",
    "text" : "RT @I_Anubhuti: There are wonders ~ almost at every step of our lives ~ so how can there be ~ only ~ Seven Wonders of the World? #Gogyohka",
    "id" : 50539267935584256,
    "created_at" : "2011-03-23 12:47:55 +0000",
    "user" : {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "protected" : false,
      "id_str" : "48164887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775135706238758913\/cwiqEl_8_normal.jpg",
      "id" : 48164887,
      "verified" : false
    }
  },
  "id" : 50544148515790848,
  "created_at" : "2011-03-23 13:07:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50542980196614144",
  "text" : "I am learning, always learning.. and that excites me!",
  "id" : 50542980196614144,
  "created_at" : "2011-03-23 13:02:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50363520008720384",
  "text" : "RT @Dwayne_Reaves: When you think your life is a mess, stop and think of all the things you don't have, that you don't want!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50362266570326016",
    "text" : "When you think your life is a mess, stop and think of all the things you don't have, that you don't want!",
    "id" : 50362266570326016,
    "created_at" : "2011-03-23 01:04:34 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 50363520008720384,
  "created_at" : "2011-03-23 01:09:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xhanch Studio",
      "screen_name" : "xhanch",
      "indices" : [ 3, 10 ],
      "id_str" : "100507813",
      "id" : 100507813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50329596796747778",
  "text" : "RT @xhanch: Xhanch  My Twitter - 2.5.8 is released - http:\/\/forum.xhanch.com\/index.php\/topic,155.0.html",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/xhanch.com\/wp-plugin-my-twitter\/\" rel=\"nofollow\"\u003EXhanch - MT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50322279627890688",
    "text" : "Xhanch  My Twitter - 2.5.8 is released - http:\/\/forum.xhanch.com\/index.php\/topic,155.0.html",
    "id" : 50322279627890688,
    "created_at" : "2011-03-22 22:25:41 +0000",
    "user" : {
      "name" : "Xhanch Studio",
      "screen_name" : "xhanch",
      "protected" : false,
      "id_str" : "100507813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600496022\/logo_normal.png",
      "id" : 100507813,
      "verified" : false
    }
  },
  "id" : 50329596796747778,
  "created_at" : "2011-03-22 22:54:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50328915507548160",
  "text" : "RT @stevetheseeker: 7 words to freedom:  The kingdom of God is within you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50326862542544897",
    "text" : "7 words to freedom:  The kingdom of God is within you.",
    "id" : 50326862542544897,
    "created_at" : "2011-03-22 22:43:53 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 50328915507548160,
  "created_at" : "2011-03-22 22:52:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BookNooz",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50307138244972544",
  "text" : "RT @KreelanWarrior: Writer and author friends, if you want your info to appear in #BookNooz, just let me know! :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BookNooz",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50305379325837313",
    "text" : "Writer and author friends, if you want your info to appear in #BookNooz, just let me know! :-)",
    "id" : 50305379325837313,
    "created_at" : "2011-03-22 21:18:31 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 50307138244972544,
  "created_at" : "2011-03-22 21:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 3, 16 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50263184313040897",
  "text" : "RT @ralphmacchio: 4 those asking - here's the link to FB page http:\/\/www.facebook.com\/pages\/Ralph-Macchio\/170464219667457?sk=wall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50261794379403265",
    "text" : "4 those asking - here's the link to FB page http:\/\/www.facebook.com\/pages\/Ralph-Macchio\/170464219667457?sk=wall",
    "id" : 50261794379403265,
    "created_at" : "2011-03-22 18:25:20 +0000",
    "user" : {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "protected" : false,
      "id_str" : "44163738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535851580667346944\/DCmtbKbq_normal.jpeg",
      "id" : 44163738,
      "verified" : true
    }
  },
  "id" : 50263184313040897,
  "created_at" : "2011-03-22 18:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50249392048967681",
  "text" : "A Victorian RV-The Steampunk Workshop http:\/\/bit.ly\/e2eZpQ",
  "id" : 50249392048967681,
  "created_at" : "2011-03-22 17:36:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50230565244383232",
  "text" : "I look like an escaped convict yet again on my drivers license.. sigh.",
  "id" : 50230565244383232,
  "created_at" : "2011-03-22 16:21:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50228658601852928",
  "text" : "I went with having my lemon ginger probiotic tea w a big slurp of honey!",
  "id" : 50228658601852928,
  "created_at" : "2011-03-22 16:13:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "indices" : [ 15, 21 ],
      "id_str" : "9930742",
      "id" : 9930742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50227854465699840",
  "text" : "RT @BestAt: RT @sween: It takes 89 magnets to stick my cat to the fridge. I really should stop feeding my cat magnets.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Sweeney",
        "screen_name" : "sween",
        "indices" : [ 3, 9 ],
        "id_str" : "9930742",
        "id" : 9930742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50226317207158784",
    "text" : "RT @sween: It takes 89 magnets to stick my cat to the fridge. I really should stop feeding my cat magnets.",
    "id" : 50226317207158784,
    "created_at" : "2011-03-22 16:04:21 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 50227854465699840,
  "created_at" : "2011-03-22 16:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50219113901072384",
  "text" : "I want a 2nd cup of coffee but not sure what tummy thinks...",
  "id" : 50219113901072384,
  "created_at" : "2011-03-22 15:35:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50215345918717952",
  "text" : "RT @TrishScott: LOL I can relate. RT @nottoolikely: I think I'll slip into something more comfortable. Like a coma.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50210625040814080",
    "text" : "LOL I can relate. RT @nottoolikely: I think I'll slip into something more comfortable. Like a coma.",
    "id" : 50210625040814080,
    "created_at" : "2011-03-22 15:02:00 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 50215345918717952,
  "created_at" : "2011-03-22 15:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 55, 65 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50193677443805184",
  "geo" : { },
  "id_str" : "50194421995675648",
  "in_reply_to_user_id" : 15572724,
  "text" : "nope.. don't see Saki catching things.. nope,nope. lol @ShhDragon",
  "id" : 50194421995675648,
  "in_reply_to_status_id" : 50193677443805184,
  "created_at" : "2011-03-22 13:57:37 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 61, 77 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50184990553677824",
  "geo" : { },
  "id_str" : "50187033045516288",
  "in_reply_to_user_id" : 26547903,
  "text" : "glad you're ok ((bighugs)) ive been in one so know its scary @SparklingReview",
  "id" : 50187033045516288,
  "in_reply_to_status_id" : 50184990553677824,
  "created_at" : "2011-03-22 13:28:15 +0000",
  "in_reply_to_screen_name" : "SparklingReview",
  "in_reply_to_user_id_str" : "26547903",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "Don Maiden",
      "screen_name" : "dwmaiden",
      "indices" : [ 30, 39 ],
      "id_str" : "74191788",
      "id" : 74191788
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "birding",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "robin",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "photography",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "vabird",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50013821435256833",
  "text" : "RT @screek: Funny capture! RT @dwmaiden: Preaching to the Choir http:\/\/bit.ly\/gOzVho #birds #birding #robin #photography #vabird",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Don Maiden",
        "screen_name" : "dwmaiden",
        "indices" : [ 18, 27 ],
        "id_str" : "74191788",
        "id" : 74191788
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 73, 79 ]
      }, {
        "text" : "birding",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "robin",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "photography",
        "indices" : [ 96, 108 ]
      }, {
        "text" : "vabird",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50011449644433408",
    "text" : "Funny capture! RT @dwmaiden: Preaching to the Choir http:\/\/bit.ly\/gOzVho #birds #birding #robin #photography #vabird",
    "id" : 50011449644433408,
    "created_at" : "2011-03-22 01:50:33 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 50013821435256833,
  "created_at" : "2011-03-22 01:59:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessy Grondin",
      "screen_name" : "JesstheWanderer",
      "indices" : [ 3, 19 ],
      "id_str" : "79761886",
      "id" : 79761886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50006885423792128",
  "text" : "RT @JesstheWanderer: Sometimes I want to tap a total stranger on the shoulder and yell, \"YOU'RE IT!!\" and then run away.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50004185499967490",
    "text" : "Sometimes I want to tap a total stranger on the shoulder and yell, \"YOU'RE IT!!\" and then run away.",
    "id" : 50004185499967490,
    "created_at" : "2011-03-22 01:21:41 +0000",
    "user" : {
      "name" : "Jessy Grondin",
      "screen_name" : "JesstheWanderer",
      "protected" : false,
      "id_str" : "79761886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798189503190093825\/oyKqKaXB_normal.jpg",
      "id" : 79761886,
      "verified" : false
    }
  },
  "id" : 50006885423792128,
  "created_at" : "2011-03-22 01:32:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50006524596191233",
  "text" : "RT @mimismutts: RT @STXherry: RT @mllyssa: The 46 stages of Twitter http:\/\/dld.bz\/DMhZ | So right on! Too funny!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mllyssa",
        "screen_name" : "mllyssa",
        "indices" : [ 17, 25 ],
        "id_str" : "2492942953",
        "id" : 2492942953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "50002358545035264",
    "text" : "RT @STXherry: RT @mllyssa: The 46 stages of Twitter http:\/\/dld.bz\/DMhZ | So right on! Too funny!!",
    "id" : 50002358545035264,
    "created_at" : "2011-03-22 01:14:25 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 50006524596191233,
  "created_at" : "2011-03-22 01:30:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No Chance Jim",
      "screen_name" : "JimnBL",
      "indices" : [ 3, 10 ],
      "id_str" : "17232340",
      "id" : 17232340
    }, {
      "name" : "Peter Flom",
      "screen_name" : "peterflom",
      "indices" : [ 15, 25 ],
      "id_str" : "72112616",
      "id" : 72112616
    }, {
      "name" : "Bob Abston",
      "screen_name" : "nNomad_",
      "indices" : [ 26, 34 ],
      "id_str" : "67711100",
      "id" : 67711100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gop",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50000010603008000",
  "text" : "RT @JimnBL: RT @peterflom @nnomad_ MN #gop [trying to] make it a crime 4 people on public assistance 2 have more $20 cash  http:\/\/bit.ly ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Flom",
        "screen_name" : "peterflom",
        "indices" : [ 3, 13 ],
        "id_str" : "72112616",
        "id" : 72112616
      }, {
        "name" : "Bob Abston",
        "screen_name" : "nNomad_",
        "indices" : [ 14, 22 ],
        "id_str" : "67711100",
        "id" : 67711100
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gop",
        "indices" : [ 26, 30 ]
      }, {
        "text" : "p2",
        "indices" : [ 132, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49449355605852160",
    "text" : "RT @peterflom @nnomad_ MN #gop [trying to] make it a crime 4 people on public assistance 2 have more $20 cash  http:\/\/bit.ly\/gg6Jiz #p2",
    "id" : 49449355605852160,
    "created_at" : "2011-03-20 12:36:59 +0000",
    "user" : {
      "name" : "No Chance Jim",
      "screen_name" : "JimnBL",
      "protected" : false,
      "id_str" : "17232340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000765422133\/8ce25456ab8dfed43ee3bb157f3df9c6_normal.png",
      "id" : 17232340,
      "verified" : false
    }
  },
  "id" : 50000010603008000,
  "created_at" : "2011-03-22 01:05:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49999635695157249",
  "text" : "good news.. got my 2 forms and really got some kicks in at sparring! bad news: that stupid blue board.. ack! : )",
  "id" : 49999635695157249,
  "created_at" : "2011-03-22 01:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49999244442087424",
  "text" : "so.. I have a temp 99. didnt have one last week with virus.",
  "id" : 49999244442087424,
  "created_at" : "2011-03-22 01:02:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 56, 69 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49967286068580352",
  "geo" : { },
  "id_str" : "49998151289016320",
  "in_reply_to_user_id" : 124594428,
  "text" : "oh good.. on my list! : ) will there be kindle version? @golden_books",
  "id" : 49998151289016320,
  "in_reply_to_status_id" : 49967286068580352,
  "created_at" : "2011-03-22 00:57:42 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49971067493679104",
  "geo" : { },
  "id_str" : "49997487846604800",
  "in_reply_to_user_id" : 31386920,
  "text" : "hmm.. not red or itchy but pressure, yes @MPMcDonald64",
  "id" : 49997487846604800,
  "in_reply_to_status_id" : 49971067493679104,
  "created_at" : "2011-03-22 00:55:04 +0000",
  "in_reply_to_screen_name" : "MarkTaylorBooks",
  "in_reply_to_user_id_str" : "31386920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 21, 34 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49946943840993280",
  "geo" : { },
  "id_str" : "49949987806777344",
  "in_reply_to_user_id" : 124594428,
  "text" : "oh.. a thriller? : ) @golden_books",
  "id" : 49949987806777344,
  "in_reply_to_status_id" : 49946943840993280,
  "created_at" : "2011-03-21 21:46:19 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49949706176040960",
  "text" : "RT @Mysticsales: Collective fear stimulates herd instinct, and tends to produce ferocity toward those who are not regarded as members of ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49948994507522048",
    "text" : "Collective fear stimulates herd instinct, and tends to produce ferocity toward those who are not regarded as members of the herd.",
    "id" : 49948994507522048,
    "created_at" : "2011-03-21 21:42:22 +0000",
    "user" : {
      "name" : "Paul And Victoria",
      "screen_name" : "TAC_ModelingCo",
      "protected" : false,
      "id_str" : "198346653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781096340432392192\/3O0iuXIJ_normal.jpg",
      "id" : 198346653,
      "verified" : false
    }
  },
  "id" : 49949706176040960,
  "created_at" : "2011-03-21 21:45:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49949577054388225",
  "text" : "ugh. feeling pukey and have testing tonight.",
  "id" : 49949577054388225,
  "created_at" : "2011-03-21 21:44:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49942156139442177",
  "geo" : { },
  "id_str" : "49949402575548416",
  "in_reply_to_user_id" : 31386920,
  "text" : "dont think so. its hard to explain. feels like not in right position. @MPMcDonald64",
  "id" : 49949402575548416,
  "in_reply_to_status_id" : 49942156139442177,
  "created_at" : "2011-03-21 21:44:00 +0000",
  "in_reply_to_screen_name" : "MarkTaylorBooks",
  "in_reply_to_user_id_str" : "31386920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49938993420316674",
  "text" : "Author Kelly Moran: Blog Tour and Giveaways http:\/\/bit.ly\/fGweIM",
  "id" : 49938993420316674,
  "created_at" : "2011-03-21 21:02:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49937110714687488",
  "text" : "my eye hurts. not the eye itself so much as all around it. this is common occurence.",
  "id" : 49937110714687488,
  "created_at" : "2011-03-21 20:55:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 114, 121 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49931780299554816",
  "geo" : { },
  "id_str" : "49936808569602048",
  "in_reply_to_user_id" : 13118692,
  "text" : "omg.. no, no! lol.. those judge shows drive me nuts. judge always pouncing on the ppl. better than news, tho..lol @moosep",
  "id" : 49936808569602048,
  "in_reply_to_status_id" : 49931780299554816,
  "created_at" : "2011-03-21 20:53:57 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 42, 49 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49929586192027648",
  "geo" : { },
  "id_str" : "49931194502103041",
  "in_reply_to_user_id" : 13118692,
  "text" : "then don't watch it! bad 4 yr health! ; ) @moosep",
  "id" : 49931194502103041,
  "in_reply_to_status_id" : 49929586192027648,
  "created_at" : "2011-03-21 20:31:39 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49929548728516608",
  "text" : "Authors! Free Banner Ads on The Inner Bean  http:\/\/bit.ly\/hlupiC",
  "id" : 49929548728516608,
  "created_at" : "2011-03-21 20:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49900472877850624",
  "text" : "stomach is off today. does it ever end? ugh.",
  "id" : 49900472877850624,
  "created_at" : "2011-03-21 18:29:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linky",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49900153146060800",
  "text" : "Got a book giveaway going on? Add to book giveaway #linky &gt;&gt; http:\/\/budurl.com\/readerswinlinky Plz RT & TY! New every Friday.",
  "id" : 49900153146060800,
  "created_at" : "2011-03-21 18:28:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 90, 103 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49874395350577152",
  "geo" : { },
  "id_str" : "49876795780120576",
  "in_reply_to_user_id" : 15364301,
  "text" : "you are wise! ; ) same 4 me, if something irritates, I know I should investigate why..lol @BrianMerritt",
  "id" : 49876795780120576,
  "in_reply_to_status_id" : 49874395350577152,
  "created_at" : "2011-03-21 16:55:29 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49876283475234816",
  "text" : "RT @GraveStomper: Just for today: try directing all of your social media communication to\/for\/about your audience rather than yourself & ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49874559473680384",
    "text" : "Just for today: try directing all of your social media communication to\/for\/about your audience rather than yourself & observe what happens.",
    "id" : 49874559473680384,
    "created_at" : "2011-03-21 16:46:36 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 49876283475234816,
  "created_at" : "2011-03-21 16:53:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "indices" : [ 3, 14 ],
      "id_str" : "15767534",
      "id" : 15767534
    }, {
      "name" : "Aric Clark",
      "screen_name" : "aricclark",
      "indices" : [ 30, 40 ],
      "id_str" : "17847731",
      "id" : 17847731
    }, {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 42, 55 ],
      "id_str" : "15364301",
      "id" : 15364301
    }, {
      "name" : "ApologeticSubversive",
      "screen_name" : "AndAFool",
      "indices" : [ 56, 65 ],
      "id_str" : "151113305",
      "id" : 151113305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49862282255138816",
  "text" : "RT @micahbales: Agreed! \/\/ RT @aricclark: @BrianMerritt @AndAFool I think calling pacifism \"idealistic\" and war \"pragmatic\" is a huge ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aric Clark",
        "screen_name" : "aricclark",
        "indices" : [ 14, 24 ],
        "id_str" : "17847731",
        "id" : 17847731
      }, {
        "name" : "BrianMerritt",
        "screen_name" : "BrianMerritt",
        "indices" : [ 26, 39 ],
        "id_str" : "15364301",
        "id" : 15364301
      }, {
        "name" : "ApologeticSubversive",
        "screen_name" : "AndAFool",
        "indices" : [ 40, 49 ],
        "id_str" : "151113305",
        "id" : 151113305
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49862045549596672",
    "text" : "Agreed! \/\/ RT @aricclark: @BrianMerritt @AndAFool I think calling pacifism \"idealistic\" and war \"pragmatic\" is a huge category mistake.",
    "id" : 49862045549596672,
    "created_at" : "2011-03-21 15:56:52 +0000",
    "user" : {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "protected" : false,
      "id_str" : "15767534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523109819654230017\/RlmyhCrv_normal.png",
      "id" : 15767534,
      "verified" : false
    }
  },
  "id" : 49862282255138816,
  "created_at" : "2011-03-21 15:57:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49854167870738433",
  "text" : "I've discovered Tumblr...",
  "id" : 49854167870738433,
  "created_at" : "2011-03-21 15:25:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Izikio",
      "screen_name" : "zakaraya",
      "indices" : [ 3, 12 ],
      "id_str" : "24639845",
      "id" : 24639845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49853538985181184",
  "text" : "RT @zakaraya: Count five blessings before you earn the right to one worry .",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49852379952193536",
    "text" : "Count five blessings before you earn the right to one worry .",
    "id" : 49852379952193536,
    "created_at" : "2011-03-21 15:18:28 +0000",
    "user" : {
      "name" : "Izikio",
      "screen_name" : "zakaraya",
      "protected" : false,
      "id_str" : "24639845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601175358835064832\/xYKJEQ-7_normal.jpg",
      "id" : 24639845,
      "verified" : false
    }
  },
  "id" : 49853538985181184,
  "created_at" : "2011-03-21 15:23:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49837149259960320",
  "text" : "Kristin M. Swenson, Ph.D.: Five Things Everyone Should Know About The Bible, Believe It or Not http:\/\/huff.to\/hkj4lP",
  "id" : 49837149259960320,
  "created_at" : "2011-03-21 14:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 25, 38 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49811672960999424",
  "geo" : { },
  "id_str" : "49813686738632705",
  "in_reply_to_user_id" : 135615040,
  "text" : "Happy birthday dear! : ) @CrystalLewis",
  "id" : 49813686738632705,
  "in_reply_to_status_id" : 49811672960999424,
  "created_at" : "2011-03-21 12:44:43 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49804126204342272",
  "text" : "there was no white stuff when I went to bed! ack!",
  "id" : 49804126204342272,
  "created_at" : "2011-03-21 12:06:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49803251507404800",
  "text" : "RT @Buddhaworld: no to lifes are the same, that makes it impossible to follow somebody elses judgement.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49797770411913217",
    "text" : "no to lifes are the same, that makes it impossible to follow somebody elses judgement.",
    "id" : 49797770411913217,
    "created_at" : "2011-03-21 11:41:28 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 49803251507404800,
  "created_at" : "2011-03-21 12:03:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49803210327736320",
  "text" : "RT @Buddhaworld: be authentic, follow nobodys but your own rules.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49798015241818112",
    "text" : "be authentic, follow nobodys but your own rules.",
    "id" : 49798015241818112,
    "created_at" : "2011-03-21 11:42:26 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 49803210327736320,
  "created_at" : "2011-03-21 12:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Bowman",
      "screen_name" : "bandedearth",
      "indices" : [ 3, 15 ],
      "id_str" : "129816498",
      "id" : 129816498
    }, {
      "name" : "E. L. Boyce",
      "screen_name" : "rockinrev",
      "indices" : [ 20, 30 ],
      "id_str" : "16187353",
      "id" : 16187353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49803034062098432",
  "text" : "RT @bandedearth: RT @rockinrev: Wondering why the USA is involved in Libya? can you say crude oil shortages and high gas prices! \/\/All a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "E. L. Boyce",
        "screen_name" : "rockinrev",
        "indices" : [ 3, 13 ],
        "id_str" : "16187353",
        "id" : 16187353
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49799940213452800",
    "text" : "RT @rockinrev: Wondering why the USA is involved in Libya? can you say crude oil shortages and high gas prices! \/\/All about the Benjamins!!!",
    "id" : 49799940213452800,
    "created_at" : "2011-03-21 11:50:05 +0000",
    "user" : {
      "name" : "Kevin Bowman",
      "screen_name" : "bandedearth",
      "protected" : false,
      "id_str" : "129816498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1343241358\/ProfilePhoto_normal.png",
      "id" : 129816498,
      "verified" : false
    }
  },
  "id" : 49803034062098432,
  "created_at" : "2011-03-21 12:02:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 3, 16 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49627975175516160",
  "text" : "RT @golden_books: Though you may disagree, you can't fault someone for seeing the world through their own eyes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49625866724065281",
    "text" : "Though you may disagree, you can't fault someone for seeing the world through their own eyes.",
    "id" : 49625866724065281,
    "created_at" : "2011-03-21 00:18:23 +0000",
    "user" : {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "protected" : false,
      "id_str" : "124594428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707724561714905089\/xr54lDFv_normal.jpg",
      "id" : 124594428,
      "verified" : false
    }
  },
  "id" : 49627975175516160,
  "created_at" : "2011-03-21 00:26:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 33, 44 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49293385403596800",
  "geo" : { },
  "id_str" : "49306272566231040",
  "in_reply_to_user_id" : 7482152,
  "text" : "totally understand that feeling! @modernevil",
  "id" : 49306272566231040,
  "in_reply_to_status_id" : 49293385403596800,
  "created_at" : "2011-03-20 03:08:26 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 25, 36 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49293089742913536",
  "geo" : { },
  "id_str" : "49305993691148288",
  "in_reply_to_user_id" : 7482152,
  "text" : "social event.. *shudder* @modernevil",
  "id" : 49305993691148288,
  "in_reply_to_status_id" : 49293089742913536,
  "created_at" : "2011-03-20 03:07:19 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 73, 84 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49254091150458880",
  "geo" : { },
  "id_str" : "49267747464548352",
  "in_reply_to_user_id" : 7482152,
  "text" : "hiding in my little cave of life as well..lol. what was so intimidating? @modernevil",
  "id" : 49267747464548352,
  "in_reply_to_status_id" : 49254091150458880,
  "created_at" : "2011-03-20 00:35:21 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 24, 36 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49229896177819648",
  "geo" : { },
  "id_str" : "49233878480728064",
  "in_reply_to_user_id" : 15349954,
  "text" : "whoa!! conditions? bleh @angelaharms",
  "id" : 49233878480728064,
  "in_reply_to_status_id" : 49229896177819648,
  "created_at" : "2011-03-19 22:20:46 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49230086448230400",
  "text" : "Thrillers R Us: I\u2019m looking for kindle ebook donations. http:\/\/bit.ly\/htoDX5",
  "id" : 49230086448230400,
  "created_at" : "2011-03-19 22:05:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49137530909622272",
  "text" : "RT @TrishScott: Let go of the reigns!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49137048698884097",
    "text" : "Let go of the reigns!!!",
    "id" : 49137048698884097,
    "created_at" : "2011-03-19 15:55:59 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 49137530909622272,
  "created_at" : "2011-03-19 15:57:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Breaking News",
      "screen_name" : "BreakingNews",
      "indices" : [ 19, 32 ],
      "id_str" : "6017542",
      "id" : 6017542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49137415666925568",
  "text" : "RT @mimismutts: RT @BreakingNews: Berlin zoo official says polar bear Knut has died in his compound - AP \/ WHAT???",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Breaking News",
        "screen_name" : "BreakingNews",
        "indices" : [ 3, 16 ],
        "id_str" : "6017542",
        "id" : 6017542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49133259484958720",
    "text" : "RT @BreakingNews: Berlin zoo official says polar bear Knut has died in his compound - AP \/ WHAT???",
    "id" : 49133259484958720,
    "created_at" : "2011-03-19 15:40:56 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 49137415666925568,
  "created_at" : "2011-03-19 15:57:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49131045009895425",
  "text" : "I did pick it out, but MIL got me cool neon green shirt w matching pants (navy blue w green stripe.) Love it!",
  "id" : 49131045009895425,
  "created_at" : "2011-03-19 15:32:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linky",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49120112174825472",
  "text" : "Got a book giveaway going on? Add to book giveaway #linky &gt;&gt; http:\/\/budurl.com\/readerswinlinky Plz RT & TY!",
  "id" : 49120112174825472,
  "created_at" : "2011-03-19 14:48:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49118724774567936",
  "text" : "RT @wow_trees: Religion distracts from universal truth http:\/\/bit.ly\/f4lD4b &lt;This zen master is in town. I want to meet him.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49109870569472000",
    "text" : "Religion distracts from universal truth http:\/\/bit.ly\/f4lD4b &lt;This zen master is in town. I want to meet him.",
    "id" : 49109870569472000,
    "created_at" : "2011-03-19 14:08:00 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 49118724774567936,
  "created_at" : "2011-03-19 14:43:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie Wilkerson",
      "screen_name" : "barefoot_exec",
      "indices" : [ 3, 17 ],
      "id_str" : "16494601",
      "id" : 16494601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49117778099191808",
  "text" : "RT @barefoot_exec: Swim your own race. Stay in your own lane. Quit the comparison nonsense.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48957516410916864",
    "text" : "Swim your own race. Stay in your own lane. Quit the comparison nonsense.",
    "id" : 48957516410916864,
    "created_at" : "2011-03-19 04:02:36 +0000",
    "user" : {
      "name" : "Carrie Wilkerson",
      "screen_name" : "CarrieWilkerson",
      "protected" : false,
      "id_str" : "14433007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776309056923283456\/XxRxkGMf_normal.jpg",
      "id" : 14433007,
      "verified" : true
    }
  },
  "id" : 49117778099191808,
  "created_at" : "2011-03-19 14:39:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49110974904532992",
  "geo" : { },
  "id_str" : "49115945817477120",
  "in_reply_to_user_id" : 40585382,
  "text" : "she has every right 2 her opinion. I happen 2 disagree w her. @Reverend_Sue",
  "id" : 49115945817477120,
  "in_reply_to_status_id" : 49110974904532992,
  "created_at" : "2011-03-19 14:32:08 +0000",
  "in_reply_to_screen_name" : "ReverendSue",
  "in_reply_to_user_id_str" : "40585382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48928596017946624",
  "text" : "RT @brandonrofl: If you don't have a sense of humor, you might as well be dead.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48925471462797312",
    "text" : "If you don't have a sense of humor, you might as well be dead.",
    "id" : 48925471462797312,
    "created_at" : "2011-03-19 01:55:16 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 48928596017946624,
  "created_at" : "2011-03-19 02:07:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48878838150733824",
  "text" : "RT @Davescotperth: What was the first thing Adam said to Eve?  \"stand back i don't know how big this thing gets\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48871048145416192",
    "text" : "What was the first thing Adam said to Eve?  \"stand back i don't know how big this thing gets\"",
    "id" : 48871048145416192,
    "created_at" : "2011-03-18 22:19:00 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 48878838150733824,
  "created_at" : "2011-03-18 22:49:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25CF \u25CF \u25CF",
      "screen_name" : "ten_ten_ten",
      "indices" : [ 3, 15 ],
      "id_str" : "87978943",
      "id" : 87978943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48832356894781441",
  "text" : "RT @ten_ten_ten: empty birdfeeder \/ my squirrels fatter than most \/ the yard full of forgotten acorns full of hope \/ reaching up \/ up #g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gogyohka",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48828140272877568",
    "text" : "empty birdfeeder \/ my squirrels fatter than most \/ the yard full of forgotten acorns full of hope \/ reaching up \/ up #gogyohka",
    "id" : 48828140272877568,
    "created_at" : "2011-03-18 19:28:30 +0000",
    "user" : {
      "name" : "\u25CF \u25CF \u25CF",
      "screen_name" : "ten_ten_ten",
      "protected" : false,
      "id_str" : "87978943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798006517987319808\/j84_69X3_normal.jpg",
      "id" : 87978943,
      "verified" : false
    }
  },
  "id" : 48832356894781441,
  "created_at" : "2011-03-18 19:45:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merralin",
      "screen_name" : "Merralin",
      "indices" : [ 3, 12 ],
      "id_str" : "4783081",
      "id" : 4783081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48765251113586688",
  "text" : "RT @Merralin: Yale law school students can check out therapy dog at library http:\/\/bit.ly\/h2FHsE Monty circulates for 30 minutes (via @L ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Library Journal",
        "screen_name" : "LibraryJournal",
        "indices" : [ 120, 135 ],
        "id_str" : "15169290",
        "id" : 15169290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48761530304573440",
    "text" : "Yale law school students can check out therapy dog at library http:\/\/bit.ly\/h2FHsE Monty circulates for 30 minutes (via @LibraryJournal)",
    "id" : 48761530304573440,
    "created_at" : "2011-03-18 15:03:49 +0000",
    "user" : {
      "name" : "Merralin",
      "screen_name" : "Merralin",
      "protected" : false,
      "id_str" : "4783081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790742885977042945\/9hm4MN_o_normal.jpg",
      "id" : 4783081,
      "verified" : false
    }
  },
  "id" : 48765251113586688,
  "created_at" : "2011-03-18 15:18:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48764885408038913",
  "text" : "RT @mssuzcatsilver: The amount of time it takes you to get from where you are to where you want to be, is only the amount of time it (co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48761755630960640",
    "text" : "The amount of time it takes you to get from where you are to where you want to be, is only the amount of time it (cont) http:\/\/tl.gd\/9bjrb0",
    "id" : 48761755630960640,
    "created_at" : "2011-03-18 15:04:43 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 48764885408038913,
  "created_at" : "2011-03-18 15:17:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48536753203720192",
  "text" : "RT @ThrillersRockT: Here's my golden standard for a good #thriller. It needs to elevate my heart rate enough so I don't need to exercise ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 37, 46 ]
      }, {
        "text" : "isthatbad",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48535916079349760",
    "text" : "Here's my golden standard for a good #thriller. It needs to elevate my heart rate enough so I don't need to exercise. #isthatbad?",
    "id" : 48535916079349760,
    "created_at" : "2011-03-18 00:07:18 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 48536753203720192,
  "created_at" : "2011-03-18 00:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USE",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48535848681095168",
  "text" : "RT @UnseeingEyes: \"More laws render us into idiots.\" #USE -V-",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USE",
        "indices" : [ 35, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48529073936416769",
    "text" : "\"More laws render us into idiots.\" #USE -V-",
    "id" : 48529073936416769,
    "created_at" : "2011-03-17 23:40:07 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 48535848681095168,
  "created_at" : "2011-03-18 00:07:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Physics Update",
      "screen_name" : "PhysicsUpdate",
      "indices" : [ 3, 17 ],
      "id_str" : "117538279",
      "id" : 117538279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48510343961509889",
  "text" : "RT @PhysicsUpdate: Theory: Large Hadron Collider Could Be Used As Time Machine  http:\/\/sns.ly\/1wcXy9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.snsanalytics.com\" rel=\"nofollow\"\u003ESNS Analytics\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48504575845609472",
    "text" : "Theory: Large Hadron Collider Could Be Used As Time Machine  http:\/\/sns.ly\/1wcXy9",
    "id" : 48504575845609472,
    "created_at" : "2011-03-17 22:02:46 +0000",
    "user" : {
      "name" : "Physics Update",
      "screen_name" : "PhysicsUpdate",
      "protected" : false,
      "id_str" : "117538279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1134292217\/Physics_normal.jpg",
      "id" : 117538279,
      "verified" : false
    }
  },
  "id" : 48510343961509889,
  "created_at" : "2011-03-17 22:25:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48508062159470593",
  "text" : "sweet12yoGSD needs rescue in NW IN http:\/\/on.fb.me\/geMaBx",
  "id" : 48508062159470593,
  "created_at" : "2011-03-17 22:16:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Effie Mcintosh",
      "screen_name" : "AKbirder",
      "indices" : [ 25, 34 ],
      "id_str" : "4202024795",
      "id" : 4202024795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48484184146186241",
  "text" : "RT @KerriFar: Beauty! RT @AKbirder: The ruffed grouse is back under the feeder. He's visiting every morning & evening now. http:\/\/yfrog. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Effie Mcintosh",
        "screen_name" : "AKbirder",
        "indices" : [ 11, 20 ],
        "id_str" : "4202024795",
        "id" : 4202024795
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48483750203502592",
    "text" : "Beauty! RT @AKbirder: The ruffed grouse is back under the feeder. He's visiting every morning & evening now. http:\/\/yfrog.com\/h0u4tzsj\u201D",
    "id" : 48483750203502592,
    "created_at" : "2011-03-17 20:40:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 48484184146186241,
  "created_at" : "2011-03-17 20:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48479221768658944",
  "text" : "stomach virus in jan, feb(2x) and now. im keeping a sick journal to keep track.",
  "id" : 48479221768658944,
  "created_at" : "2011-03-17 20:22:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48478584100241408",
  "text" : "RT @GraveStomper: It's exciting to see the possibilities present during this time of change.  You just have to want to see them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48476713239322624",
    "text" : "It's exciting to see the possibilities present during this time of change.  You just have to want to see them.",
    "id" : 48476713239322624,
    "created_at" : "2011-03-17 20:12:03 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 48478584100241408,
  "created_at" : "2011-03-17 20:19:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 24, 37 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48344201968099328",
  "geo" : { },
  "id_str" : "48366052832313344",
  "in_reply_to_user_id" : 35585695,
  "text" : "LOL.. im sure you will! @derekrootboy",
  "id" : 48366052832313344,
  "in_reply_to_status_id" : 48344201968099328,
  "created_at" : "2011-03-17 12:52:20 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Clara Llum",
      "screen_name" : "lux1008",
      "indices" : [ 19, 27 ],
      "id_str" : "3846751",
      "id" : 3846751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48365737785556992",
  "text" : "RT @TrishScott: RT @lux1008: there's no way out other than realizing you are not in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clara Llum",
        "screen_name" : "lux1008",
        "indices" : [ 3, 11 ],
        "id_str" : "3846751",
        "id" : 3846751
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48344747596726272",
    "text" : "RT @lux1008: there's no way out other than realizing you are not in",
    "id" : 48344747596726272,
    "created_at" : "2011-03-17 11:27:40 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 48365737785556992,
  "created_at" : "2011-03-17 12:51:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GMO",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "thriller",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48364605667414018",
  "text" : "RT @KreelanWarrior: \"Worried about #GMO's? You'll be terrified after you read the #thriller SEASON OF THE HARVEST - #Kindle http:\/\/ow.ly ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GMO",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "thriller",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 96, 103 ]
      }, {
        "text" : "goodreads",
        "indices" : [ 123, 133 ]
      }, {
        "text" : "RT",
        "indices" : [ 134, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48353136158584832",
    "text" : "\"Worried about #GMO's? You'll be terrified after you read the #thriller SEASON OF THE HARVEST - #Kindle http:\/\/ow.ly\/3S0oQ #goodreads #RT",
    "id" : 48353136158584832,
    "created_at" : "2011-03-17 12:01:00 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 48364605667414018,
  "created_at" : "2011-03-17 12:46:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Izikio",
      "screen_name" : "zakaraya",
      "indices" : [ 3, 12 ],
      "id_str" : "24639845",
      "id" : 24639845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48363702507941889",
  "text" : "RT @zakaraya: Everyone is gifted - but some people never open their package.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48362813160308736",
    "text" : "Everyone is gifted - but some people never open their package.",
    "id" : 48362813160308736,
    "created_at" : "2011-03-17 12:39:27 +0000",
    "user" : {
      "name" : "Izikio",
      "screen_name" : "zakaraya",
      "protected" : false,
      "id_str" : "24639845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601175358835064832\/xYKJEQ-7_normal.jpg",
      "id" : 24639845,
      "verified" : false
    }
  },
  "id" : 48363702507941889,
  "created_at" : "2011-03-17 12:42:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tahereh Mafi",
      "screen_name" : "TaherehMafi",
      "indices" : [ 3, 15 ],
      "id_str" : "90510113",
      "id" : 90510113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48067740795281410",
  "text" : "RT @TaherehMafi: RT THIS TWEET for a chance to win a $20 Amazon gift card. Random.org will choose TWO winners.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48056594012979200",
    "text" : "RT THIS TWEET for a chance to win a $20 Amazon gift card. Random.org will choose TWO winners.",
    "id" : 48056594012979200,
    "created_at" : "2011-03-16 16:22:39 +0000",
    "user" : {
      "name" : "Tahereh Mafi",
      "screen_name" : "TaherehMafi",
      "protected" : false,
      "id_str" : "90510113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759520406583652353\/KolDhiyx_normal.jpg",
      "id" : 90510113,
      "verified" : true
    }
  },
  "id" : 48067740795281410,
  "created_at" : "2011-03-16 17:06:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48061320955830272",
  "text" : "Squirrel attacking residents of Vt. neighborhood -  http:\/\/yhoo.it\/fa2Nyr",
  "id" : 48061320955830272,
  "created_at" : "2011-03-16 16:41:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48055840309125121",
  "text" : "RT @dubiouslygreat: A woman in Iowa was jailed for the thoughtcrime of CONSIDERING abortion. This is not a joke. I can't even. http:\/\/j. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prochoice",
        "indices" : [ 126, 136 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48053476718161920",
    "text" : "A woman in Iowa was jailed for the thoughtcrime of CONSIDERING abortion. This is not a joke. I can't even. http:\/\/j.mp\/ha1leT #prochoice #p2",
    "id" : 48053476718161920,
    "created_at" : "2011-03-16 16:10:16 +0000",
    "user" : {
      "name" : "Amanda",
      "screen_name" : "andalongjacket",
      "protected" : false,
      "id_str" : "15151023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606568621041545216\/LRWZ61Lq_normal.jpg",
      "id" : 15151023,
      "verified" : false
    }
  },
  "id" : 48055840309125121,
  "created_at" : "2011-03-16 16:19:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 91, 105 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48021673580044288",
  "text" : "potato, potatoe.. its all the same, just a different name. you're cool w me, BaS! ((hugs)) @BibleAlsoSays @christopherr615",
  "id" : 48021673580044288,
  "created_at" : "2011-03-16 14:03:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 3, 15 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CherryPickingSins",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48021174483034112",
  "text" : "RT @GeorgeTakei: Tomorrow I'm going to violate Leviticus by wearing a cotton\/polyester blend.  #CherryPickingSins",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CherryPickingSins",
        "indices" : [ 78, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47855874554867712",
    "text" : "Tomorrow I'm going to violate Leviticus by wearing a cotton\/polyester blend.  #CherryPickingSins",
    "id" : 47855874554867712,
    "created_at" : "2011-03-16 03:05:04 +0000",
    "user" : {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "protected" : false,
      "id_str" : "237845487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700355030117937152\/3uW9IKHD_normal.png",
      "id" : 237845487,
      "verified" : true
    }
  },
  "id" : 48021174483034112,
  "created_at" : "2011-03-16 14:01:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linky",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48007240715735040",
  "text" : "Got a book giveaway going on? Add to book giveaway #linky &gt;&gt; http:\/\/budurl.com\/readerswinlinky Plz RT-TY!",
  "id" : 48007240715735040,
  "created_at" : "2011-03-16 13:06:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "burdr",
      "screen_name" : "burdr",
      "indices" : [ 3, 9 ],
      "id_str" : "18826472",
      "id" : 18826472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "birding",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47994946719985664",
  "text" : "RT @burdr: \"Be nice, you never know who could end up being your friend!\" http:\/\/ow.ly\/4fnYf #birds #birding",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "birding",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47993021924519936",
    "text" : "\"Be nice, you never know who could end up being your friend!\" http:\/\/ow.ly\/4fnYf #birds #birding",
    "id" : 47993021924519936,
    "created_at" : "2011-03-16 12:10:02 +0000",
    "user" : {
      "name" : "burdr",
      "screen_name" : "burdr",
      "protected" : false,
      "id_str" : "18826472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1349213818\/IMG_0448_normal.jpg",
      "id" : 18826472,
      "verified" : false
    }
  },
  "id" : 47994946719985664,
  "created_at" : "2011-03-16 12:17:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47828392275492864",
  "text" : "RT @fearfuldogs: i've decided that eating hot fudge out of the jar is a good calorie cutting measure. skip the ice cream",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47819420378214401",
    "text" : "i've decided that eating hot fudge out of the jar is a good calorie cutting measure. skip the ice cream",
    "id" : 47819420378214401,
    "created_at" : "2011-03-16 00:40:12 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 47828392275492864,
  "created_at" : "2011-03-16 01:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linky",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47641610145640448",
  "text" : "Book bloggers.. got a giveaway going on? Add to book giveaway #linky &gt;&gt; http:\/\/budurl.com\/readerswinlinky Plz RT & TY!",
  "id" : 47641610145640448,
  "created_at" : "2011-03-15 12:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 0, 10 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47507200662454272",
  "geo" : { },
  "id_str" : "47621230811021312",
  "in_reply_to_user_id" : 56280847,
  "text" : "@DougDorow not an author.. just a reader & kindle fan : )",
  "id" : 47621230811021312,
  "in_reply_to_status_id" : 47507200662454272,
  "created_at" : "2011-03-15 11:32:40 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "numbers",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 56 ],
      "url" : "http:\/\/t.co\/uo9YTVP",
      "expanded_url" : "https:\/\/blog.twitter.com\/2011\/03\/numbers.html",
      "display_url" : "blog.twitter.com\/2011\/03\/number\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "47475661308297216",
  "text" : "RT @twitter: New blog post: #numbers http:\/\/t.co\/uo9YTVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "numbers",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 43 ],
        "url" : "http:\/\/t.co\/uo9YTVP",
        "expanded_url" : "https:\/\/blog.twitter.com\/2011\/03\/numbers.html",
        "display_url" : "blog.twitter.com\/2011\/03\/number\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "47366664894951424",
    "text" : "New blog post: #numbers http:\/\/t.co\/uo9YTVP",
    "id" : 47366664894951424,
    "created_at" : "2011-03-14 18:41:07 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767879603977191425\/29zfZY6I_normal.jpg",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 47475661308297216,
  "created_at" : "2011-03-15 01:54:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47456384450707457",
  "text" : "Moose calf off Alaska Highway near Beaver Creek, Yukon - asorum \u00B7 WildObs - Find your nature http:\/\/bit.ly\/eT2QSl",
  "id" : 47456384450707457,
  "created_at" : "2011-03-15 00:37:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "mentionmonday",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47425207035625473",
  "text" : "RT @DougDorow: R U a #kindle author? Have an ebook you could donate?  http:\/\/ow.ly\/4deaH #mentionmonday Plz RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 6, 13 ]
      }, {
        "text" : "mentionmonday",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47424346192494592",
    "text" : "R U a #kindle author? Have an ebook you could donate?  http:\/\/ow.ly\/4deaH #mentionmonday Plz RT",
    "id" : 47424346192494592,
    "created_at" : "2011-03-14 22:30:19 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 47425207035625473,
  "created_at" : "2011-03-14 22:33:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "March21",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47393582096723968",
  "text" : "RT @bcmouser: So... I'm having a really difficult time deciding if I want to go to the Rapture on #March21. Is anyone else planning on a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "March21",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47392594661093376",
    "text" : "So... I'm having a really difficult time deciding if I want to go to the Rapture on #March21. Is anyone else planning on attending?",
    "id" : 47392594661093376,
    "created_at" : "2011-03-14 20:24:09 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 47393582096723968,
  "created_at" : "2011-03-14 20:28:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shelby fero",
      "screen_name" : "shelbyfero",
      "indices" : [ 3, 14 ],
      "id_str" : "35097545",
      "id" : 35097545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47375020162416640",
  "text" : "RT @shelbyfero: Just realized all books are different combinations of the same 26 letters. This is bullshit!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "46748401471209473",
    "text" : "Just realized all books are different combinations of the same 26 letters. This is bullshit!",
    "id" : 46748401471209473,
    "created_at" : "2011-03-13 01:44:22 +0000",
    "user" : {
      "name" : "shelby fero",
      "screen_name" : "shelbyfero",
      "protected" : false,
      "id_str" : "35097545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797275134943903744\/quYw3oJU_normal.jpg",
      "id" : 35097545,
      "verified" : false
    }
  },
  "id" : 47375020162416640,
  "created_at" : "2011-03-14 19:14:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47374672253300737",
  "text" : "awww.. so cute! @statue_dog",
  "id" : 47374672253300737,
  "created_at" : "2011-03-14 19:12:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47352066598912000",
  "text" : "RT @bunnybuddhism: When I let go of the bunny I am, I become the bunny I might be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47349110906437632",
    "text" : "When I let go of the bunny I am, I become the bunny I might be.",
    "id" : 47349110906437632,
    "created_at" : "2011-03-14 17:31:22 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 47352066598912000,
  "created_at" : "2011-03-14 17:43:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47344748771549184",
  "text" : "Got a book giveaway going on? Add it to Linky: http:\/\/budurl.com\/readerswinlinky",
  "id" : 47344748771549184,
  "created_at" : "2011-03-14 17:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47335354637881344",
  "text" : "RT @GeneDoucette: Is there anything quite as exciting for an adult as \"my new eyeglasses are ready!\" I think not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47333710776905728",
    "text" : "Is there anything quite as exciting for an adult as \"my new eyeglasses are ready!\" I think not.",
    "id" : 47333710776905728,
    "created_at" : "2011-03-14 16:30:10 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 47335354637881344,
  "created_at" : "2011-03-14 16:36:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marion Ross PhD",
      "screen_name" : "docmarion",
      "indices" : [ 3, 13 ],
      "id_str" : "14547574",
      "id" : 14547574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47281819560849408",
  "text" : "RT @docmarion: Japan earthquake & tsunami tilts world's axis by 25cm - could even cost us a microsecond a day Some coastline shifts 2.4m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "47279289653145600",
    "text" : "Japan earthquake & tsunami tilts world's axis by 25cm - could even cost us a microsecond a day Some coastline shifts 2.4m http:\/\/ow.ly\/4dUi2",
    "id" : 47279289653145600,
    "created_at" : "2011-03-14 12:53:55 +0000",
    "user" : {
      "name" : "Marion Ross PhD",
      "screen_name" : "docmarion",
      "protected" : false,
      "id_str" : "14547574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/229682603\/twitter_normal.jpg",
      "id" : 14547574,
      "verified" : false
    }
  },
  "id" : 47281819560849408,
  "created_at" : "2011-03-14 13:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47274109343760384",
  "text" : "Happy Pi Day!",
  "id" : 47274109343760384,
  "created_at" : "2011-03-14 12:33:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47123285623832576",
  "text" : "http:\/\/amzn.com\/k\/16ESM90VDD1V8 #Kindle",
  "id" : 47123285623832576,
  "created_at" : "2011-03-14 02:34:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47121103486857217",
  "text" : "http:\/\/amzn.com\/k\/3SUFFZ0M80VCK #Kindle",
  "id" : 47121103486857217,
  "created_at" : "2011-03-14 02:25:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47120810460188672",
  "text" : "http:\/\/amzn.com\/k\/2R5NVM9UHDP8S #Kindle",
  "id" : 47120810460188672,
  "created_at" : "2011-03-14 02:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47104298466803712",
  "text" : "Thrillers R Us: looking for kindle ebook donations http:\/\/bit.ly\/htoDX5",
  "id" : 47104298466803712,
  "created_at" : "2011-03-14 01:18:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46378007484571648",
  "text" : "I was referring to your blog..lol @christopherr615",
  "id" : 46378007484571648,
  "created_at" : "2011-03-12 01:12:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46377515098456064",
  "text" : "RT @TrishScott: The whole \"time\" thing is bad enough but \"daylight savings time\" is an abomination.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "46376521715298304",
    "text" : "The whole \"time\" thing is bad enough but \"daylight savings time\" is an abomination.",
    "id" : 46376521715298304,
    "created_at" : "2011-03-12 01:06:39 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 46377515098456064,
  "created_at" : "2011-03-12 01:10:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan D'Elia",
      "screen_name" : "SusanDElia",
      "indices" : [ 3, 14 ],
      "id_str" : "14523408",
      "id" : 14523408
    }, {
      "name" : "Jeff Ashcroft",
      "screen_name" : "JeffAshcroft",
      "indices" : [ 19, 32 ],
      "id_str" : "21132950",
      "id" : 21132950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46377438577573888",
  "text" : "RT @SusanDElia: RT @JeffAshcroft: Japan earthquake factbox: Entire Japan coast shifted 2.4 metres, earth axis moves ten inches http:\/\/bi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Ashcroft",
        "screen_name" : "JeffAshcroft",
        "indices" : [ 3, 16 ],
        "id_str" : "21132950",
        "id" : 21132950
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "46368311675588610",
    "text" : "RT @JeffAshcroft: Japan earthquake factbox: Entire Japan coast shifted 2.4 metres, earth axis moves ten inches http:\/\/bit.ly\/h3XdaS #science",
    "id" : 46368311675588610,
    "created_at" : "2011-03-12 00:34:01 +0000",
    "user" : {
      "name" : "Susan D'Elia",
      "screen_name" : "SusanDElia",
      "protected" : false,
      "id_str" : "14523408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1207902510\/DSC_0160_01_normal.jpg",
      "id" : 14523408,
      "verified" : false
    }
  },
  "id" : 46377438577573888,
  "created_at" : "2011-03-12 01:10:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46374023608799232",
  "text" : "sounds like it would contain thought provoking material @christopherr615",
  "id" : 46374023608799232,
  "created_at" : "2011-03-12 00:56:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46373764556001280",
  "text" : "my hubby is so sweet.. he ordered tv for Mom so she could watch news in hospital.",
  "id" : 46373764556001280,
  "created_at" : "2011-03-12 00:55:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45901463972610048",
  "geo" : { },
  "id_str" : "45930480624865280",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH she has pneumonia. was rushed to er from nursing home yesterday. was def uncomfortable. better today.",
  "id" : 45930480624865280,
  "in_reply_to_status_id" : 45901463972610048,
  "created_at" : "2011-03-10 19:34:14 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45901226877005824",
  "text" : "My sister called. She saw my Mom & she is much better today! yay!",
  "id" : 45901226877005824,
  "created_at" : "2011-03-10 17:37:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45670224288153600",
  "text" : "RT @JAScribbles: Hi - take a look at my new website http:\/\/www.JennaScribbles.com I will be keeping my blog. This is just for overflow r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45667318541467648",
    "text" : "Hi - take a look at my new website http:\/\/www.JennaScribbles.com I will be keeping my blog. This is just for overflow rambling.",
    "id" : 45667318541467648,
    "created_at" : "2011-03-10 02:08:31 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 45670224288153600,
  "created_at" : "2011-03-10 02:20:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45668577289834496",
  "geo" : { },
  "id_str" : "45669991885971456",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles Thank you",
  "id" : 45669991885971456,
  "in_reply_to_status_id" : 45668577289834496,
  "created_at" : "2011-03-10 02:19:09 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45669701547864064",
  "text" : "I wish you a speedy & uneventful recovery! @bookhound78",
  "id" : 45669701547864064,
  "created_at" : "2011-03-10 02:18:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45662233841250304",
  "text" : "My mommy is in hospital with pneumonia. I hope she feels better soon.",
  "id" : 45662233841250304,
  "created_at" : "2011-03-10 01:48:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45504196673404928",
  "text" : "really think pole reversal and such messing w ppls bodies...",
  "id" : 45504196673404928,
  "created_at" : "2011-03-09 15:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45501323755524096",
  "geo" : { },
  "id_str" : "45503881412755456",
  "in_reply_to_user_id" : 99910224,
  "text" : "hope the DR can help. I seem 2 have more sick days than well... ((hugs)) @PaganGmaSayin",
  "id" : 45503881412755456,
  "in_reply_to_status_id" : 45501323755524096,
  "created_at" : "2011-03-09 15:19:05 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45498457389137920",
  "geo" : { },
  "id_str" : "45499385534103552",
  "in_reply_to_user_id" : 113395189,
  "text" : "no, you're not. I'm like that, too. @Jeansandpolo",
  "id" : 45499385534103552,
  "in_reply_to_status_id" : 45498457389137920,
  "created_at" : "2011-03-09 15:01:13 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 78, 88 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45482223616528385",
  "geo" : { },
  "id_str" : "45484073308790784",
  "in_reply_to_user_id" : 38944844,
  "text" : "tis my fave quote. reminds me of St Therese of Lisieux.. little things matter @TracyLatz",
  "id" : 45484073308790784,
  "in_reply_to_status_id" : 45482223616528385,
  "created_at" : "2011-03-09 14:00:22 +0000",
  "in_reply_to_screen_name" : "TracyLatz",
  "in_reply_to_user_id_str" : "38944844",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45483549901586432",
  "text" : "RT @TracyLatz: No act of kindness, no matter how small, is ever wasted. Aesop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45482223616528385",
    "text" : "No act of kindness, no matter how small, is ever wasted. Aesop",
    "id" : 45482223616528385,
    "created_at" : "2011-03-09 13:53:01 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 45483549901586432,
  "created_at" : "2011-03-09 13:58:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grim Reaper",
      "screen_name" : "DeathMacabre",
      "indices" : [ 3, 16 ],
      "id_str" : "119727875",
      "id" : 119727875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45477055965577216",
  "text" : "RT @DeathMacabre: \"The fear of death is the most unjustified of all fears, for there's no risk of accident for someone who's dead.\" ~Alb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45466540702834688",
    "text" : "\"The fear of death is the most unjustified of all fears, for there's no risk of accident for someone who's dead.\" ~Albert Einstein",
    "id" : 45466540702834688,
    "created_at" : "2011-03-09 12:50:42 +0000",
    "user" : {
      "name" : "Grim Reaper",
      "screen_name" : "DeathMacabre",
      "protected" : false,
      "id_str" : "119727875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000808403820\/23afd2905a658e2b23ac9e274a66c2c9_normal.jpeg",
      "id" : 119727875,
      "verified" : false
    }
  },
  "id" : 45477055965577216,
  "created_at" : "2011-03-09 13:32:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 47, 58 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45314433165180928",
  "geo" : { },
  "id_str" : "45314911622017024",
  "in_reply_to_user_id" : 39331231,
  "text" : "((hugs)) hope your meditation lessens the blah @dhammagirl",
  "id" : 45314911622017024,
  "in_reply_to_status_id" : 45314433165180928,
  "created_at" : "2011-03-09 02:48:11 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 33, 46 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45228042552999936",
  "geo" : { },
  "id_str" : "45230408438259712",
  "in_reply_to_user_id" : 68905287,
  "text" : "yeah, it will be ok : ) ((hugs)) @ChrisGroove1",
  "id" : 45230408438259712,
  "in_reply_to_status_id" : 45228042552999936,
  "created_at" : "2011-03-08 21:12:24 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim McKay",
      "screen_name" : "jimmckay",
      "indices" : [ 3, 12 ],
      "id_str" : "14899307",
      "id" : 14899307
    }, {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 14, 24 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45218474829692928",
  "text" : "RT @jimmckay: @ShhDragon And why is Saki skulking in the shadows.  Is he perfecting his skulking technique?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShhDragon",
        "screen_name" : "ShhDragon",
        "indices" : [ 0, 10 ],
        "id_str" : "15572724",
        "id" : 15572724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "45205399485431808",
    "geo" : { },
    "id_str" : "45212652087156737",
    "in_reply_to_user_id" : 15572724,
    "text" : "@ShhDragon And why is Saki skulking in the shadows.  Is he perfecting his skulking technique?",
    "id" : 45212652087156737,
    "in_reply_to_status_id" : 45205399485431808,
    "created_at" : "2011-03-08 20:01:50 +0000",
    "in_reply_to_screen_name" : "ShhDragon",
    "in_reply_to_user_id_str" : "15572724",
    "user" : {
      "name" : "Jim McKay",
      "screen_name" : "jimmckay",
      "protected" : false,
      "id_str" : "14899307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/54642683\/puss_normal.jpg",
      "id" : 14899307,
      "verified" : false
    }
  },
  "id" : 45218474829692928,
  "created_at" : "2011-03-08 20:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NativeRemedies",
      "screen_name" : "NativeRemedies",
      "indices" : [ 30, 45 ],
      "id_str" : "14924947",
      "id" : 14924947
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nervous",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45190451162136576",
  "text" : "No.. 2 birds, 1 stone..lol RT @NativeRemedies Did you know Chinese Yam is an excellent natural liver and #nervous system tonic?",
  "id" : 45190451162136576,
  "created_at" : "2011-03-08 18:33:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NativeRemedies",
      "screen_name" : "NativeRemedies",
      "indices" : [ 3, 18 ],
      "id_str" : "14924947",
      "id" : 14924947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45189818438795264",
  "text" : "RT @NativeRemedies: Chamomile is a natural nervous system tonic that supports healthy, restful sleep patterns.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45183547367112704",
    "text" : "Chamomile is a natural nervous system tonic that supports healthy, restful sleep patterns.",
    "id" : 45183547367112704,
    "created_at" : "2011-03-08 18:06:11 +0000",
    "user" : {
      "name" : "NativeRemedies",
      "screen_name" : "NativeRemedies",
      "protected" : false,
      "id_str" : "14924947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469471357550338050\/iI9euuEu_normal.jpeg",
      "id" : 14924947,
      "verified" : false
    }
  },
  "id" : 45189818438795264,
  "created_at" : "2011-03-08 18:31:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NativeRemedies",
      "screen_name" : "NativeRemedies",
      "indices" : [ 3, 18 ],
      "id_str" : "14924947",
      "id" : 14924947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45189173375807488",
  "text" : "RT @NativeRemedies: Passionflower is a naturally soothing remedy which acts as a safe, effective and non-addictive nerve tonic.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45187942477594624",
    "text" : "Passionflower is a naturally soothing remedy which acts as a safe, effective and non-addictive nerve tonic.",
    "id" : 45187942477594624,
    "created_at" : "2011-03-08 18:23:39 +0000",
    "user" : {
      "name" : "NativeRemedies",
      "screen_name" : "NativeRemedies",
      "protected" : false,
      "id_str" : "14924947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469471357550338050\/iI9euuEu_normal.jpeg",
      "id" : 14924947,
      "verified" : false
    }
  },
  "id" : 45189173375807488,
  "created_at" : "2011-03-08 18:28:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45144640885768193",
  "geo" : { },
  "id_str" : "45145165630939136",
  "in_reply_to_user_id" : 75708394,
  "text" : "((hugs)) you are adorable! thx 4 being my friend! @JulzMayBe",
  "id" : 45145165630939136,
  "in_reply_to_status_id" : 45144640885768193,
  "created_at" : "2011-03-08 15:33:40 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 65, 74 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45144047760846848",
  "geo" : { },
  "id_str" : "45144672707936256",
  "in_reply_to_user_id" : 14986977,
  "text" : "hehe.. nah, just the way I think.. my mind is all over the place @Teawench",
  "id" : 45144672707936256,
  "in_reply_to_status_id" : 45144047760846848,
  "created_at" : "2011-03-08 15:31:43 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yvette Nicole Brown",
      "screen_name" : "yvettenbrown",
      "indices" : [ 3, 16 ],
      "id_str" : "2400883705",
      "id" : 2400883705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45144245513895936",
  "text" : "RT @yvettenbrown: I am so grateful for all of you who follow me. It is not a small thing that you let me randomly pop up on your timelin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45141065753305089",
    "text" : "I am so grateful for all of you who follow me. It is not a small thing that you let me randomly pop up on your timelines. Thank you so much!",
    "id" : 45141065753305089,
    "created_at" : "2011-03-08 15:17:23 +0000",
    "user" : {
      "name" : "yvette nicole brown",
      "screen_name" : "YNB",
      "protected" : false,
      "id_str" : "23314049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800180854232231936\/Z7Zl23pX_normal.jpg",
      "id" : 23314049,
      "verified" : true
    }
  },
  "id" : 45144245513895936,
  "created_at" : "2011-03-08 15:30:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 67, 76 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45138013377933312",
  "geo" : { },
  "id_str" : "45143546608619520",
  "in_reply_to_user_id" : 14986977,
  "text" : "took me a minute 2 figure out which IT you were talking about..lol @Teawench",
  "id" : 45143546608619520,
  "in_reply_to_status_id" : 45138013377933312,
  "created_at" : "2011-03-08 15:27:14 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45139098192723969",
  "text" : "RT @Dwayne_Reaves: To everyone is given the key to heaven; the same key opens the gates of hell.  ~Ancient Proverb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45134644370341890",
    "text" : "To everyone is given the key to heaven; the same key opens the gates of hell.  ~Ancient Proverb",
    "id" : 45134644370341890,
    "created_at" : "2011-03-08 14:51:52 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 45139098192723969,
  "created_at" : "2011-03-08 15:09:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0411\u0435\u043B\u0438\u043A\u043E\u0432 \u041C\u0438\u0445\u0430\u0438\u043B",
      "screen_name" : "LMStull",
      "indices" : [ 50, 58 ],
      "id_str" : "2835376119",
      "id" : 2835376119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45131396964040704",
  "geo" : { },
  "id_str" : "45135740597846017",
  "in_reply_to_user_id" : 164312699,
  "text" : "I added yr link to my ebook site under book blogs @LMStull",
  "id" : 45135740597846017,
  "in_reply_to_status_id" : 45131396964040704,
  "created_at" : "2011-03-08 14:56:13 +0000",
  "in_reply_to_screen_name" : "LisaMGott",
  "in_reply_to_user_id_str" : "164312699",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KindleBoards",
      "screen_name" : "kindleboards",
      "indices" : [ 0, 13 ],
      "id_str" : "37188815",
      "id" : 37188815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45132216723963904",
  "in_reply_to_user_id" : 37188815,
  "text" : "@kindleboards curious.. do you keep a list of kb full banner ads that are run? if not, you should..lol. trying 2 remember book that ran : )",
  "id" : 45132216723963904,
  "created_at" : "2011-03-08 14:42:13 +0000",
  "in_reply_to_screen_name" : "kindleboards",
  "in_reply_to_user_id_str" : "37188815",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 19, 34 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "readthem",
      "indices" : [ 46, 55 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 56, 63 ]
    }, {
      "text" : "kindle",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45130979895025664",
  "text" : "thx 4 replies! : ) @KreelanWarrior @byoung210 #readthem #ebooks #kindle",
  "id" : 45130979895025664,
  "created_at" : "2011-03-08 14:37:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45122279578939392",
  "text" : "weeks ago, saw an ad for a book on kindleboards.. but didnt wishlist it. now cant remember it.. sigh.",
  "id" : 45122279578939392,
  "created_at" : "2011-03-08 14:02:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45121959935229952",
  "text" : "Never be less than who you are. Never apologize for being you.",
  "id" : 45121959935229952,
  "created_at" : "2011-03-08 14:01:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kanta Sharma",
      "screen_name" : "kanta_sharma",
      "indices" : [ 3, 16 ],
      "id_str" : "44834175",
      "id" : 44834175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45121723129008128",
  "text" : "RT @kanta_sharma: Believe in miracles.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45116363123068928",
    "text" : "Believe in miracles.",
    "id" : 45116363123068928,
    "created_at" : "2011-03-08 13:39:13 +0000",
    "user" : {
      "name" : "Kanta Sharma",
      "screen_name" : "kanta_sharma",
      "protected" : false,
      "id_str" : "44834175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2769907026\/ba2f76023873b87e44b64e10c182bc63_normal.jpeg",
      "id" : 44834175,
      "verified" : false
    }
  },
  "id" : 45121723129008128,
  "created_at" : "2011-03-08 14:00:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45121509496332288",
  "text" : "RT @WarriorBanker: RT @mcmuffinofdoom: You know, I really can't understand Sarah Palin at times. | What do you mean, \"at times\"?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45115694043500544",
    "text" : "RT @mcmuffinofdoom: You know, I really can't understand Sarah Palin at times. | What do you mean, \"at times\"?",
    "id" : 45115694043500544,
    "created_at" : "2011-03-08 13:36:34 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 45121509496332288,
  "created_at" : "2011-03-08 13:59:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 4, 17 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45096244674183168",
  "geo" : { },
  "id_str" : "45112635401830400",
  "in_reply_to_user_id" : 135615040,
  "text" : "LOL @CrystalLewis",
  "id" : 45112635401830400,
  "in_reply_to_status_id" : 45096244674183168,
  "created_at" : "2011-03-08 13:24:25 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45111473441218560",
  "text" : "RT @byoung210: Blog entry today gets personal. Find out how I met my wife at 12 PM EST. http:\/\/the-time-capsule.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45106615095001088",
    "text" : "Blog entry today gets personal. Find out how I met my wife at 12 PM EST. http:\/\/the-time-capsule.com",
    "id" : 45106615095001088,
    "created_at" : "2011-03-08 13:00:29 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 45111473441218560,
  "created_at" : "2011-03-08 13:19:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44949230770597888",
  "text" : "no right being you... http:\/\/amzn.com\/k\/3KU1FV0P78LI #Kindle",
  "id" : 44949230770597888,
  "created_at" : "2011-03-08 02:35:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44929501175623680",
  "text" : "RT @scottsigler: My dog is old. I apparently don't take her outside for a walk anymore. Now I take her out for a stand. Just standing th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44913657624264704",
    "text" : "My dog is old. I apparently don't take her outside for a walk anymore. Now I take her out for a stand. Just standing there, looking around.",
    "id" : 44913657624264704,
    "created_at" : "2011-03-08 00:13:45 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 44929501175623680,
  "created_at" : "2011-03-08 01:16:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/W3bf1gl",
      "expanded_url" : "http:\/\/lessthanthis.com\/2011\/03\/oops-my-new-books-are-available\/",
      "display_url" : "lessthanthis.com\/2011\/03\/oops-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "44926956118097921",
  "text" : "RT @modernevil: Oops, my new books are available: New post w\/details on buying\/winning my new books, http:\/\/t.co\/W3bf1gl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 104 ],
        "url" : "http:\/\/t.co\/W3bf1gl",
        "expanded_url" : "http:\/\/lessthanthis.com\/2011\/03\/oops-my-new-books-are-available\/",
        "display_url" : "lessthanthis.com\/2011\/03\/oops-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "44921062630227968",
    "text" : "Oops, my new books are available: New post w\/details on buying\/winning my new books, http:\/\/t.co\/W3bf1gl",
    "id" : 44921062630227968,
    "created_at" : "2011-03-08 00:43:10 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 44926956118097921,
  "created_at" : "2011-03-08 01:06:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebookweek",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "readanebookweek",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44773781260079104",
  "text" : "http:\/\/budurl.com\/ebookweek #ebookweek #readanebookweek",
  "id" : 44773781260079104,
  "created_at" : "2011-03-07 14:57:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44760842562052096",
  "text" : "dog was freaking out last night over ice storm.. panting, trembling. ended up in top bunk w sissy.",
  "id" : 44760842562052096,
  "created_at" : "2011-03-07 14:06:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44576144984514560",
  "text" : "RT @Wylieknowords: Go to the motels where homeless children in America live & explain to those hungry children why we can't help them bu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44575577436463104",
    "text" : "Go to the motels where homeless children in America live & explain to those hungry children why we can't help them but can fight 2 wars.",
    "id" : 44575577436463104,
    "created_at" : "2011-03-07 01:50:20 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 44576144984514560,
  "created_at" : "2011-03-07 01:52:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44566360889630720",
  "text" : "Frankly, yes.. ignoring all the bad stuff has worked for me thus far..lol",
  "id" : 44566360889630720,
  "created_at" : "2011-03-07 01:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 6, 15 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44560453992587264",
  "geo" : { },
  "id_str" : "44566037382959104",
  "in_reply_to_user_id" : 23538653,
  "text" : "LOLOL @Fernwise",
  "id" : 44566037382959104,
  "in_reply_to_status_id" : 44560453992587264,
  "created_at" : "2011-03-07 01:12:25 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44565005080858624",
  "text" : "via FB: Denise Pilon-Morrison Success\/Results Coach: \"In order to succeed, you must first be willing to fail\" &lt;&lt; #TKD teaches me this!",
  "id" : 44565005080858624,
  "created_at" : "2011-03-07 01:08:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "indices" : [ 3, 15 ],
      "id_str" : "45727491",
      "id" : 45727491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "ereader",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "education",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44545850659180544",
  "text" : "RT @kindleworld: Kindles in schools - several new projects the last week. http:\/\/bit.ly\/kwksch #kindle  #ereader #education #ebooks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "ereader",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "education",
        "indices" : [ 96, 106 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44543787502022656",
    "text" : "Kindles in schools - several new projects the last week. http:\/\/bit.ly\/kwksch #kindle  #ereader #education #ebooks",
    "id" : 44543787502022656,
    "created_at" : "2011-03-06 23:44:01 +0000",
    "user" : {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "protected" : false,
      "id_str" : "45727491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477176032563167233\/rnTxZldx_normal.jpeg",
      "id" : 45727491,
      "verified" : false
    }
  },
  "id" : 44545850659180544,
  "created_at" : "2011-03-06 23:52:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "ads60nyc",
      "indices" : [ 3, 12 ],
      "id_str" : "53427397",
      "id" : 53427397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44544191140864000",
  "text" : "RT @ads60nyc: Bell is a stunning 3-yr-old Russian Blue. She is friendly & pregnant. Bell has a cold and is on death row at NYC ACC. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44539617051029505",
    "text" : "Bell is a stunning 3-yr-old Russian Blue. She is friendly & pregnant. Bell has a cold and is on death row at NYC ACC. http:\/\/on.fb.me\/hO3VVe",
    "id" : 44539617051029505,
    "created_at" : "2011-03-06 23:27:26 +0000",
    "user" : {
      "name" : "Andrew",
      "screen_name" : "ads60nyc",
      "protected" : false,
      "id_str" : "53427397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573266687002222593\/VHHuAD_p_normal.jpeg",
      "id" : 53427397,
      "verified" : false
    }
  },
  "id" : 44544191140864000,
  "created_at" : "2011-03-06 23:45:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 80, 93 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 94, 109 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44529248656044032",
  "geo" : { },
  "id_str" : "44531581465014272",
  "in_reply_to_user_id" : 36008885,
  "text" : "I believe you can D\/L samples on Amazon or his website http:\/\/www.hairfield.com @UnseeingEyes @AnAmericanMonk",
  "id" : 44531581465014272,
  "in_reply_to_status_id" : 44529248656044032,
  "created_at" : "2011-03-06 22:55:31 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Walker's SUV",
      "screen_name" : "ScottWalkersSUV",
      "indices" : [ 12, 28 ],
      "id_str" : "231957475",
      "id" : 231957475
    }, {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 29, 38 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44468379536457728",
  "text" : "WHAT? :( RT @ScottWalkersSUV @WahminSC\nScott Walker s budget reduction plan sell unclaimed dogs for research for (cont) http:\/\/tl.gd\/951vgf",
  "id" : 44468379536457728,
  "created_at" : "2011-03-06 18:44:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 30, 39 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44409785789067264",
  "text" : "glad yr kitty is ok. ((hugs)) @Tideliar",
  "id" : 44409785789067264,
  "created_at" : "2011-03-06 14:51:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44408261537038336",
  "text" : "Find some goodies during Ebook Week http:\/\/budurl.com\/ebookweek",
  "id" : 44408261537038336,
  "created_at" : "2011-03-06 14:45:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44407775345901568",
  "text" : "Check out Indie Writers! http:\/\/budurl.com\/samplesunday",
  "id" : 44407775345901568,
  "created_at" : "2011-03-06 14:43:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Shaddock",
      "screen_name" : "samshaddock",
      "indices" : [ 3, 15 ],
      "id_str" : "6303252",
      "id" : 6303252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44232348086173696",
  "text" : "RT @samshaddock: Lost cat on Upper West Side (68th and Riverside Blvd.). Black and white, with shaved patches. Age: 11. Will die without ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44120323544719360",
    "text" : "Lost cat on Upper West Side (68th and Riverside Blvd.). Black and white, with shaved patches. Age: 11. Will die without meds. Please repost.",
    "id" : 44120323544719360,
    "created_at" : "2011-03-05 19:41:19 +0000",
    "user" : {
      "name" : "Samantha Shaddock",
      "screen_name" : "samshaddock",
      "protected" : false,
      "id_str" : "6303252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661270970955526144\/KtTffIwB_normal.jpg",
      "id" : 6303252,
      "verified" : true
    }
  },
  "id" : 44232348086173696,
  "created_at" : "2011-03-06 03:06:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Shaddock",
      "screen_name" : "samshaddock",
      "indices" : [ 3, 15 ],
      "id_str" : "6303252",
      "id" : 6303252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44232262119735296",
  "text" : "RT @samshaddock: If you see this cat, contact me immediately. Please send to all your New York contacts. Thank you.  http:\/\/plixi.com\/p\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44125717671313408",
    "text" : "If you see this cat, contact me immediately. Please send to all your New York contacts. Thank you.  http:\/\/plixi.com\/p\/81835029",
    "id" : 44125717671313408,
    "created_at" : "2011-03-05 20:02:45 +0000",
    "user" : {
      "name" : "Samantha Shaddock",
      "screen_name" : "samshaddock",
      "protected" : false,
      "id_str" : "6303252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661270970955526144\/KtTffIwB_normal.jpg",
      "id" : 6303252,
      "verified" : true
    }
  },
  "id" : 44232262119735296,
  "created_at" : "2011-03-06 03:06:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "SheilaRose \uF8FF\uD83D\uDC94",
      "screen_name" : "ShebaJo",
      "indices" : [ 21, 29 ],
      "id_str" : "22235918",
      "id" : 22235918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "humor",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44180062563602432",
  "text" : "RT @MyNatureApps: RT @ShebaJo: Maybe this world is another planet's hell. ~Aldous Huxley #quote #humor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SheilaRose \uF8FF\uD83D\uDC94",
        "screen_name" : "ShebaJo",
        "indices" : [ 3, 11 ],
        "id_str" : "22235918",
        "id" : 22235918
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 71, 77 ]
      }, {
        "text" : "humor",
        "indices" : [ 78, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44178564207222784",
    "text" : "RT @ShebaJo: Maybe this world is another planet's hell. ~Aldous Huxley #quote #humor",
    "id" : 44178564207222784,
    "created_at" : "2011-03-05 23:32:45 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 44180062563602432,
  "created_at" : "2011-03-05 23:38:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebookweek",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44151964577169408",
  "text" : "Read an Ebook Week...who else is offering books? http:\/\/bit.ly\/iaUYwv #ebookweek",
  "id" : 44151964577169408,
  "created_at" : "2011-03-05 21:47:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 88, 104 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44137221439242240",
  "text" : "RT @TrishScott: finished Alison Wonderland by Helen Smith http:\/\/amzn.to\/hMWsM7 #Kindle @emperorsclothes",
  "id" : 44137221439242240,
  "created_at" : "2011-03-05 20:48:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pj johnson Yukon",
      "screen_name" : "pjjohnsonYukon",
      "indices" : [ 3, 18 ],
      "id_str" : "113514329",
      "id" : 113514329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44133060475752448",
  "text" : "RT @pjjohnsonYukon: Sad how quick people are to ridicule Charlie Sheen ~ He is not a well man. ~It's hard to watch a person self-destruc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44124928500445185",
    "text" : "Sad how quick people are to ridicule Charlie Sheen ~ He is not a well man. ~It's hard to watch a person self-destruct. He is in my prayers.",
    "id" : 44124928500445185,
    "created_at" : "2011-03-05 19:59:37 +0000",
    "user" : {
      "name" : "pj johnson Yukon",
      "screen_name" : "pjjohnsonYukon",
      "protected" : false,
      "id_str" : "113514329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762329024680951808\/xaVPixN8_normal.jpg",
      "id" : 113514329,
      "verified" : false
    }
  },
  "id" : 44133060475752448,
  "created_at" : "2011-03-05 20:31:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Premium-Hosts.com",
      "screen_name" : "premhosts",
      "indices" : [ 25, 35 ],
      "id_str" : "242830330",
      "id" : 242830330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44119415163338752",
  "text" : "Happy Birthday to BK : ) @premhosts",
  "id" : 44119415163338752,
  "created_at" : "2011-03-05 19:37:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Robert rGyatso",
      "screen_name" : "rgyatso",
      "indices" : [ 21, 29 ],
      "id_str" : "19478009",
      "id" : 19478009
    }, {
      "name" : "Sandro Stealth",
      "screen_name" : "mutalabala",
      "indices" : [ 31, 42 ],
      "id_str" : "245750555",
      "id" : 245750555
    }, {
      "name" : "John Peter  Thompson",
      "screen_name" : "InvasiveNotes",
      "indices" : [ 43, 57 ],
      "id_str" : "41100077",
      "id" : 41100077
    }, {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 58, 67 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44117429634342912",
  "text" : "RT @neardeathdoc: RT @rgyatso: @mutalabala @InvasiveNotes @gemswinc So question is, does something with self-awareness have a soul. I fi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert rGyatso",
        "screen_name" : "rgyatso",
        "indices" : [ 3, 11 ],
        "id_str" : "19478009",
        "id" : 19478009
      }, {
        "name" : "Sandro Stealth",
        "screen_name" : "mutalabala",
        "indices" : [ 13, 24 ],
        "id_str" : "245750555",
        "id" : 245750555
      }, {
        "name" : "John Peter  Thompson",
        "screen_name" : "InvasiveNotes",
        "indices" : [ 25, 39 ],
        "id_str" : "41100077",
        "id" : 41100077
      }, {
        "name" : "Cindy",
        "screen_name" : "gemswinc",
        "indices" : [ 40, 49 ],
        "id_str" : "13112692",
        "id" : 13112692
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44109781459410944",
    "text" : "RT @rgyatso: @mutalabala @InvasiveNotes @gemswinc So question is, does something with self-awareness have a soul. I figure, same thing.",
    "id" : 44109781459410944,
    "created_at" : "2011-03-05 18:59:26 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 44117429634342912,
  "created_at" : "2011-03-05 19:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44051441274462208",
  "text" : "75 Geese Running Down The Street http:\/\/bit.ly\/hMVhNA",
  "id" : 44051441274462208,
  "created_at" : "2011-03-05 15:07:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 7, 22 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43852137431695361",
  "text" : "LOL RT @PeggySueCusses: I forgot my husbands damn birthday until I saw it on Facebook.",
  "id" : 43852137431695361,
  "created_at" : "2011-03-05 01:55:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43781960790843392",
  "text" : "IOW, they couldnt get a man so their kids are starving... sigh. Wacko. \"There aren't really a lot of single moms (cont) http:\/\/tl.gd\/941djg",
  "id" : 43781960790843392,
  "created_at" : "2011-03-04 21:16:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43780876894613506",
  "text" : "ok, then. o-O \"He didn't give her the most wonderful gift, which would be a wedding ring!\"  http:\/\/yhoo.it\/ieBV2k",
  "id" : 43780876894613506,
  "created_at" : "2011-03-04 21:12:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43671869894836224",
  "geo" : { },
  "id_str" : "43683733051674624",
  "in_reply_to_user_id" : 75708394,
  "text" : "I \u2665 Ralph. Hadnt seen that. Made me grin! lol @JulzMayBe",
  "id" : 43683733051674624,
  "in_reply_to_status_id" : 43671869894836224,
  "created_at" : "2011-03-04 14:46:28 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43683484899880960",
  "text" : "RT @JulzMayBe: haha The Karate kid --&gt; http:\/\/tumbl.in\/t\/1lvb9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43671869894836224",
    "text" : "haha The Karate kid --&gt; http:\/\/tumbl.in\/t\/1lvb9",
    "id" : 43671869894836224,
    "created_at" : "2011-03-04 13:59:19 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 43683484899880960,
  "created_at" : "2011-03-04 14:45:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 10, 13 ]
    }, {
      "text" : "thankyouverymuch",
      "indices" : [ 34, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43680880027373568",
  "text" : "I will do #FF however way I want. #thankyouverymuch",
  "id" : 43680880027373568,
  "created_at" : "2011-03-04 14:35:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43679650836258817",
  "text" : "RT @dubiouslygreat: Reminder, ladies: as soon as you have sex, your bodily autonomy is subject to negotiation. This is sickening: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prochoice",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43675932459933696",
    "text" : "Reminder, ladies: as soon as you have sex, your bodily autonomy is subject to negotiation. This is sickening: http:\/\/j.mp\/evW9mH #prochoice",
    "id" : 43675932459933696,
    "created_at" : "2011-03-04 14:15:28 +0000",
    "user" : {
      "name" : "Amanda",
      "screen_name" : "andalongjacket",
      "protected" : false,
      "id_str" : "15151023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606568621041545216\/LRWZ61Lq_normal.jpg",
      "id" : 15151023,
      "verified" : false
    }
  },
  "id" : 43679650836258817,
  "created_at" : "2011-03-04 14:30:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "indices" : [ 3, 16 ],
      "id_str" : "15120037",
      "id" : 15120037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43679143296110592",
  "text" : "RT @AnissaMayhew: When filling out forms they ask for \"sexual orientation\".  Upside down is never an option.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43673904140656641",
    "text" : "When filling out forms they ask for \"sexual orientation\".  Upside down is never an option.",
    "id" : 43673904140656641,
    "created_at" : "2011-03-04 14:07:24 +0000",
    "user" : {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "protected" : false,
      "id_str" : "15120037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3062161006\/ad2239750e205707bab7b90d1b5e5373_normal.jpeg",
      "id" : 15120037,
      "verified" : false
    }
  },
  "id" : 43679143296110592,
  "created_at" : "2011-03-04 14:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43677433588756480",
  "text" : "RT @JeremyCShipp: I was taught never to shout fire in a crowded room, so when I noticed the flames, I quietly took my leave.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43673108175003648",
    "text" : "I was taught never to shout fire in a crowded room, so when I noticed the flames, I quietly took my leave.",
    "id" : 43673108175003648,
    "created_at" : "2011-03-04 14:04:15 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 43677433588756480,
  "created_at" : "2011-03-04 14:21:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43677251887312896",
  "text" : "RT @bunnybuddhism: No bunny can tell you the secret to bunniness because no bunny knows what it looks like to you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43673753254772736",
    "text" : "No bunny can tell you the secret to bunniness because no bunny knows what it looks like to you.",
    "id" : 43673753254772736,
    "created_at" : "2011-03-04 14:06:48 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 43677251887312896,
  "created_at" : "2011-03-04 14:20:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43677163328765952",
  "text" : "RT @InfantileAdult: I've NEVER understood why people get so offended by women breastfeeding in public. What the fuck do you think they're..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43674445981827072",
    "text" : "I've NEVER understood why people get so offended by women breastfeeding in public. What the fuck do you think they're..",
    "id" : 43674445981827072,
    "created_at" : "2011-03-04 14:09:34 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 43677163328765952,
  "created_at" : "2011-03-04 14:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 51, 67 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43663904039112705",
  "geo" : { },
  "id_str" : "43665769791361024",
  "in_reply_to_user_id" : 20245651,
  "text" : "the universe uses all avenues to \"speak\" to me : ) @hauntedcomputer",
  "id" : 43665769791361024,
  "in_reply_to_status_id" : 43663904039112705,
  "created_at" : "2011-03-04 13:35:05 +0000",
  "in_reply_to_screen_name" : "eScottNicholson",
  "in_reply_to_user_id_str" : "20245651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 58, 70 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43659258948091904",
  "geo" : { },
  "id_str" : "43663868635004929",
  "in_reply_to_user_id" : 143654638,
  "text" : "havent tried yoga but I bet it would give similar results @JAScribbles",
  "id" : 43663868635004929,
  "in_reply_to_status_id" : 43659258948091904,
  "created_at" : "2011-03-04 13:27:32 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachid H",
      "screen_name" : "rachidH",
      "indices" : [ 3, 11 ],
      "id_str" : "18059728",
      "id" : 18059728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "Cairo",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "nature",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "Photography",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43663100930564096",
  "text" : "RT @rachidH: This is for my nest http:\/\/twitpic.com\/45ox6g Black-hooded crow #birds #Cairo #nature #Photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 64, 70 ]
      }, {
        "text" : "Cairo",
        "indices" : [ 71, 77 ]
      }, {
        "text" : "nature",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "Photography",
        "indices" : [ 86, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43651538291404800",
    "text" : "This is for my nest http:\/\/twitpic.com\/45ox6g Black-hooded crow #birds #Cairo #nature #Photography",
    "id" : 43651538291404800,
    "created_at" : "2011-03-04 12:38:32 +0000",
    "user" : {
      "name" : "Rachid H",
      "screen_name" : "rachidH",
      "protected" : false,
      "id_str" : "18059728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099528640\/CIMG1815_normal.JPG",
      "id" : 18059728,
      "verified" : false
    }
  },
  "id" : 43663100930564096,
  "created_at" : "2011-03-04 13:24:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tkd",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43658119506694145",
  "text" : "important point: #tkd is physical, yes, but its discipline of the mind! I am slowly but surely absorbing my lessons!",
  "id" : 43658119506694145,
  "created_at" : "2011-03-04 13:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43657478663184385",
  "text" : "But I did it for her. She stuck it out for 1 year. I almost didnt continue. But I felt bad. I liked my instructors & classmates. So I stayed",
  "id" : 43657478663184385,
  "created_at" : "2011-03-04 13:02:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tkd",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43656953519538176",
  "text" : "I only got into #tkd trying to get my DD to stick with it (she expressed interest previously.) To get on that mat took all I had.",
  "id" : 43656953519538176,
  "created_at" : "2011-03-04 13:00:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tkd",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43656357685108736",
  "text" : "really, the more I think about it.. the universe conspired to get me into #tkd .. I would have never done it on my own.",
  "id" : 43656357685108736,
  "created_at" : "2011-03-04 12:57:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 74, 87 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43503981259010048",
  "geo" : { },
  "id_str" : "43505044909326336",
  "in_reply_to_user_id" : 124594428,
  "text" : "it wasnt violent or anything..just 2 egos trying 2 assert themselves..lol @golden_books",
  "id" : 43505044909326336,
  "in_reply_to_status_id" : 43503981259010048,
  "created_at" : "2011-03-04 02:56:25 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43503666698784768",
  "text" : "still cant break my board at #TKD :\/ ...but Sr.Master worked w me tonight : )",
  "id" : 43503666698784768,
  "created_at" : "2011-03-04 02:50:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43503363568058370",
  "text" : "RT @ShhDragon: The stars tonight\nremind me of\nwhat I've yet \nto know\n\nBy being where\nI've yet to go\nand yet where\n\nI'm from",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43502088222814209",
    "text" : "The stars tonight\nremind me of\nwhat I've yet \nto know\n\nBy being where\nI've yet to go\nand yet where\n\nI'm from",
    "id" : 43502088222814209,
    "created_at" : "2011-03-04 02:44:40 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 43503363568058370,
  "created_at" : "2011-03-04 02:49:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 109, 120 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 121, 134 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43503250326036481",
  "text" : "I was mad at hub for going upstairs, getting in my way B4 leaving 4 TKD class & escalated. its fine now. : ) @mimismutts @golden_books",
  "id" : 43503250326036481,
  "created_at" : "2011-03-04 02:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 15, 22 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43497683540918272",
  "geo" : { },
  "id_str" : "43501482703716353",
  "in_reply_to_user_id" : 122393631,
  "text" : "good night : ) @SsmDad",
  "id" : 43501482703716353,
  "in_reply_to_status_id" : 43497683540918272,
  "created_at" : "2011-03-04 02:42:16 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 28, 35 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43497566188486657",
  "geo" : { },
  "id_str" : "43501398599532544",
  "in_reply_to_user_id" : 122393631,
  "text" : "why would you do that?? o-O @SsmDad",
  "id" : 43501398599532544,
  "in_reply_to_status_id" : 43497566188486657,
  "created_at" : "2011-03-04 02:41:56 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 24, 31 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43494613788528640",
  "geo" : { },
  "id_str" : "43501216923262976",
  "in_reply_to_user_id" : 122393631,
  "text" : "adorable! wish I could. @SsmDad",
  "id" : 43501216923262976,
  "in_reply_to_status_id" : 43494613788528640,
  "created_at" : "2011-03-04 02:41:12 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 8, 15 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43488220431908864",
  "geo" : { },
  "id_str" : "43500808284807168",
  "in_reply_to_user_id" : 122393631,
  "text" : "hmmm... @SsmDad",
  "id" : 43500808284807168,
  "in_reply_to_status_id" : 43488220431908864,
  "created_at" : "2011-03-04 02:39:35 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43464609298006017",
  "geo" : { },
  "id_str" : "43500050634117120",
  "in_reply_to_user_id" : 113395189,
  "text" : "lovely, indeed! ur forgiven. : ) @Jeansandpolo",
  "id" : 43500050634117120,
  "in_reply_to_status_id" : 43464609298006017,
  "created_at" : "2011-03-04 02:36:34 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43458999709999104",
  "text" : "BIG BIG fight here. GRRRR!!!",
  "id" : 43458999709999104,
  "created_at" : "2011-03-03 23:53:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43446561488900098",
  "text" : "RT @modernevil: Just finished the blog post I've been working on for ... 3-4 hours? It's over 2k words. New books coming soon: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 130 ],
        "url" : "http:\/\/t.co\/9h1duWD",
        "expanded_url" : "http:\/\/lessthanthis.com\/2011\/03\/new-books-coming-soon\/",
        "display_url" : "lessthanthis.com\/2011\/03\/new-bo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "43223908685582336",
    "text" : "Just finished the blog post I've been working on for ... 3-4 hours? It's over 2k words. New books coming soon: http:\/\/t.co\/9h1duWD",
    "id" : 43223908685582336,
    "created_at" : "2011-03-03 08:19:17 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 43446561488900098,
  "created_at" : "2011-03-03 23:04:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon & Schuster",
      "screen_name" : "simonschuster",
      "indices" : [ 3, 17 ],
      "id_str" : "24886025",
      "id" : 24886025
    }, {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 104, 119 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43441299071840257",
  "text" : "RT @simonschuster: 9th RT wins THE THIEVES OF DARKNESS and THE 13TH HOUR, two irresistible thrillers by @richarddoetsch http:\/\/cot.ag\/eSI8Q3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "richard doetsch",
        "screen_name" : "richarddoetsch",
        "indices" : [ 85, 100 ],
        "id_str" : "105049016",
        "id" : 105049016
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43404025755996160",
    "text" : "9th RT wins THE THIEVES OF DARKNESS and THE 13TH HOUR, two irresistible thrillers by @richarddoetsch http:\/\/cot.ag\/eSI8Q3",
    "id" : 43404025755996160,
    "created_at" : "2011-03-03 20:15:00 +0000",
    "user" : {
      "name" : "Simon & Schuster",
      "screen_name" : "simonschuster",
      "protected" : false,
      "id_str" : "24886025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570600737525096448\/Hl2OHpQQ_normal.png",
      "id" : 24886025,
      "verified" : true
    }
  },
  "id" : 43441299071840257,
  "created_at" : "2011-03-03 22:43:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 87, 97 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 98, 113 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43430257696571392",
  "geo" : { },
  "id_str" : "43437410964611072",
  "in_reply_to_user_id" : 48215218,
  "text" : "Season Of The Harvest was excellent. Nonstop action! Also, makes you afraid of corn... @bend_time @KreelanWarrior",
  "id" : 43437410964611072,
  "in_reply_to_status_id" : 43430257696571392,
  "created_at" : "2011-03-03 22:27:40 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43424990363783168",
  "text" : "RT @ShhDragon: Still too much snow to require de-napping http:\/\/plixi.com\/p\/81343049",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43417528424349696",
    "text" : "Still too much snow to require de-napping http:\/\/plixi.com\/p\/81343049",
    "id" : 43417528424349696,
    "created_at" : "2011-03-03 21:08:40 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 43424990363783168,
  "created_at" : "2011-03-03 21:38:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/plixi.com\" rel=\"nofollow\"\u003EPlixi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43424811594166272",
  "text" : "I just voted for this photo  http:\/\/plixi.com\/p\/81343049",
  "id" : 43424811594166272,
  "created_at" : "2011-03-03 21:37:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43358583815024640",
  "text" : "The President who told the Truth about illuminati Vlad TV http:\/\/bit.ly\/gD40nV",
  "id" : 43358583815024640,
  "created_at" : "2011-03-03 17:14:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 81, 93 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43333720152870913",
  "geo" : { },
  "id_str" : "43335332128763904",
  "in_reply_to_user_id" : 71118021,
  "text" : "depends how they are used. also, I like being able to unsubscribe automatically. @CaroleODell",
  "id" : 43335332128763904,
  "in_reply_to_status_id" : 43333720152870913,
  "created_at" : "2011-03-03 15:42:02 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Egbert Sukop",
      "screen_name" : "esukop",
      "indices" : [ 19, 26 ],
      "id_str" : "17936052",
      "id" : 17936052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43334376150405121",
  "text" : "RT @TrishScott: RT @esukop: \"Being president is like running a cemetery; you've got a lot of people under you and nobody is listening.\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Egbert Sukop",
        "screen_name" : "esukop",
        "indices" : [ 3, 10 ],
        "id_str" : "17936052",
        "id" : 17936052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43329164241158144",
    "text" : "RT @esukop: \"Being president is like running a cemetery; you've got a lot of people under you and nobody is listening.\" --Bill Clinton",
    "id" : 43329164241158144,
    "created_at" : "2011-03-03 15:17:32 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 43334376150405121,
  "created_at" : "2011-03-03 15:38:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vlad Dolezal",
      "screen_name" : "VladDolezal",
      "indices" : [ 3, 15 ],
      "id_str" : "17063146",
      "id" : 17063146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43334212274749441",
  "text" : "RT @VladDolezal: Go to thesaurus.com and type in \"Ninjas\". It comes back with \"Ninjas can not be found.\" Well played ninjas, well played.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43329945493184512",
    "text" : "Go to thesaurus.com and type in \"Ninjas\". It comes back with \"Ninjas can not be found.\" Well played ninjas, well played.",
    "id" : 43329945493184512,
    "created_at" : "2011-03-03 15:20:38 +0000",
    "user" : {
      "name" : "Vlad Dolezal",
      "screen_name" : "VladDolezal",
      "protected" : false,
      "id_str" : "17063146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3310208257\/9ae19dee232c5256b1a7c3fd7d22250a_normal.png",
      "id" : 17063146,
      "verified" : false
    }
  },
  "id" : 43334212274749441,
  "created_at" : "2011-03-03 15:37:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tkd",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43133259764346880",
  "text" : "still didnt break my board at #tkd",
  "id" : 43133259764346880,
  "created_at" : "2011-03-03 02:19:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43061451459530752",
  "text" : "my eyes are like an old tv. works for awhile then fades..",
  "id" : 43061451459530752,
  "created_at" : "2011-03-02 21:33:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43060058485035009",
  "text" : "RT @CrystalLewis: I'm not kidding... You all are the most interesting people I've never met. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43050692964917248",
    "text" : "I'm not kidding... You all are the most interesting people I've never met. :)",
    "id" : 43050692964917248,
    "created_at" : "2011-03-02 20:50:59 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 43060058485035009,
  "created_at" : "2011-03-02 21:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 23, 35 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43050847785066496",
  "geo" : { },
  "id_str" : "43059725004320769",
  "in_reply_to_user_id" : 143654638,
  "text" : "Jenna! Hi. (waves) : ) @JAScribbles",
  "id" : 43059725004320769,
  "in_reply_to_status_id" : 43050847785066496,
  "created_at" : "2011-03-02 21:26:53 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "indices" : [ 3, 14 ],
      "id_str" : "190004285",
      "id" : 190004285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "under1bargainbin",
      "indices" : [ 83, 100 ]
    }, {
      "text" : "sciencefiction",
      "indices" : [ 101, 116 ]
    }, {
      "text" : "thriller",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "uk",
      "indices" : [ 127, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43027026940145664",
  "text" : "RT @PixelofInk: [Bargain Kindle Book] Season Of The Harvest http:\/\/goo.gl\/fb\/4R5LF #under1bargainbin #sciencefiction #thriller #uk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "under1bargainbin",
        "indices" : [ 67, 84 ]
      }, {
        "text" : "sciencefiction",
        "indices" : [ 85, 100 ]
      }, {
        "text" : "thriller",
        "indices" : [ 101, 110 ]
      }, {
        "text" : "uk",
        "indices" : [ 111, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43026574412488704",
    "text" : "[Bargain Kindle Book] Season Of The Harvest http:\/\/goo.gl\/fb\/4R5LF #under1bargainbin #sciencefiction #thriller #uk",
    "id" : 43026574412488704,
    "created_at" : "2011-03-02 19:15:09 +0000",
    "user" : {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "protected" : false,
      "id_str" : "190004285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1954428066\/PixelOfInk_Avatar_200x200_normal.png",
      "id" : 190004285,
      "verified" : false
    }
  },
  "id" : 43027026940145664,
  "created_at" : "2011-03-02 19:16:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 3, 15 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43026884770004992",
  "text" : "RT @PuaTamandua: We won! Thank you. http:\/\/animalconscious.wordpress.com\/2011\/03\/02\/winner\/ http:\/\/fb.me\/Lzh7XAp5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43025505909342208",
    "text" : "We won! Thank you. http:\/\/animalconscious.wordpress.com\/2011\/03\/02\/winner\/ http:\/\/fb.me\/Lzh7XAp5",
    "id" : 43025505909342208,
    "created_at" : "2011-03-02 19:10:54 +0000",
    "user" : {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "protected" : false,
      "id_str" : "17218256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63782435\/shirt_normal.jpg",
      "id" : 17218256,
      "verified" : false
    }
  },
  "id" : 43026884770004992,
  "created_at" : "2011-03-02 19:16:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43026621665525760",
  "text" : "RT @CreativeArtwks: \"Karate-Diva\"--NOTE-CARDS-Pkg-of-8 by Lenore Garnhum http:\/\/bit.ly\/fUPWPx  Click on 'all artwork' to see more!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43020371871543296",
    "text" : "\"Karate-Diva\"--NOTE-CARDS-Pkg-of-8 by Lenore Garnhum http:\/\/bit.ly\/fUPWPx  Click on 'all artwork' to see more!",
    "id" : 43020371871543296,
    "created_at" : "2011-03-02 18:50:30 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 43026621665525760,
  "created_at" : "2011-03-02 19:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43026345789374464",
  "text" : "RT @thesexyatheist: \u201CI cannot believe in a God who wants to be praised all the time.\u201D Fred Nietzsche. Kriss (that's me), \"Ditto.\" #athei ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 110, 118 ]
      }, {
        "text" : "awesome",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "fred",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43021853903683584",
    "text" : "\u201CI cannot believe in a God who wants to be praised all the time.\u201D Fred Nietzsche. Kriss (that's me), \"Ditto.\" #atheist #awesome #fred",
    "id" : 43021853903683584,
    "created_at" : "2011-03-02 18:56:23 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 43026345789374464,
  "created_at" : "2011-03-02 19:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43026267284570112",
  "text" : "RT @Wylieknowords: Breaking News:  More exciting than the i-Pad 2 or Xoom 16 or Kindle 39.  Here is the invention: A,B,C,D,E,F,G,H,I,J,K ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43022012024758272",
    "text" : "Breaking News:  More exciting than the i-Pad 2 or Xoom 16 or Kindle 39.  Here is the invention: A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,",
    "id" : 43022012024758272,
    "created_at" : "2011-03-02 18:57:01 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 43026267284570112,
  "created_at" : "2011-03-02 19:13:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 62, 73 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43023611283521536",
  "geo" : { },
  "id_str" : "43025956893495296",
  "in_reply_to_user_id" : 7482152,
  "text" : "How are you & wife liking Kindle? Doing ok w just 1 for both? @modernevil",
  "id" : 43025956893495296,
  "in_reply_to_status_id" : 43023611283521536,
  "created_at" : "2011-03-02 19:12:42 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 53, 68 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43005856845021185",
  "text" : "I have A Metaphysical Interpretation of the Bible by @anamericanmonk on my kindle but havent read yet..will soon!",
  "id" : 43005856845021185,
  "created_at" : "2011-03-02 17:52:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 53, 68 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43005552028172288",
  "text" : "I have read The Twelve Sacred Principles of Karma by @anamericanmonk",
  "id" : 43005552028172288,
  "created_at" : "2011-03-02 17:51:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 31, 46 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43003883852795904",
  "text" : "I \u2665 watching youtube videos by @anamericanmonk about 2012, the soul, etc. : )",
  "id" : 43003883852795904,
  "created_at" : "2011-03-02 17:44:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 11, 19 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42992414880825344",
  "text" : "Agreed! RT @arphaus So far 'Outliers' has been a revealing read - except for advocating more school. Giving kids (cont) http:\/\/tl.gd\/9301tr",
  "id" : 42992414880825344,
  "created_at" : "2011-03-02 16:59:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 3, 18 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42990819212398592",
  "text" : "RT @JonathanElliot: Woohoo! My very first remix for sale, ever! http:\/\/bit.ly\/h6Br6L Also available on eMusic etc! Please RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42988540887441408",
    "text" : "Woohoo! My very first remix for sale, ever! http:\/\/bit.ly\/h6Br6L Also available on eMusic etc! Please RT",
    "id" : 42988540887441408,
    "created_at" : "2011-03-02 16:44:01 +0000",
    "user" : {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "protected" : false,
      "id_str" : "30825946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1534911961\/black_square_normal.jpg",
      "id" : 30825946,
      "verified" : false
    }
  },
  "id" : 42990819212398592,
  "created_at" : "2011-03-02 16:53:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "Mike McDowell",
      "screen_name" : "mcdomik",
      "indices" : [ 46, 54 ],
      "id_str" : "59966336",
      "id" : 59966336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42990752858517505",
  "text" : "RT @DawnFine: AWESOME Video!!! must see!: Via @mcdomik Feeding Chickadees! http:\/\/bit.ly\/dOCPYr #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike McDowell",
        "screen_name" : "mcdomik",
        "indices" : [ 32, 40 ],
        "id_str" : "59966336",
        "id" : 59966336
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 82, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42988963111251968",
    "text" : "AWESOME Video!!! must see!: Via @mcdomik Feeding Chickadees! http:\/\/bit.ly\/dOCPYr #birds",
    "id" : 42988963111251968,
    "created_at" : "2011-03-02 16:45:42 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 42990752858517505,
  "created_at" : "2011-03-02 16:52:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "John Peter  Thompson",
      "screen_name" : "InvasiveNotes",
      "indices" : [ 98, 112 ],
      "id_str" : "41100077",
      "id" : 41100077
    }, {
      "name" : "Winston Hearn",
      "screen_name" : "justwinston",
      "indices" : [ 113, 125 ],
      "id_str" : "2351075282",
      "id" : 2351075282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42990267640455168",
  "text" : "RT @neardeathdoc: While just an ultrasound diagnosis, there still remained infinite possibilities @InvasiveNotes @justwinston",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Peter  Thompson",
        "screen_name" : "InvasiveNotes",
        "indices" : [ 80, 94 ],
        "id_str" : "41100077",
        "id" : 41100077
      }, {
        "name" : "Winston Hearn",
        "screen_name" : "justwinston",
        "indices" : [ 95, 107 ],
        "id_str" : "2351075282",
        "id" : 2351075282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42989707851866112",
    "text" : "While just an ultrasound diagnosis, there still remained infinite possibilities @InvasiveNotes @justwinston",
    "id" : 42989707851866112,
    "created_at" : "2011-03-02 16:48:39 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 42990267640455168,
  "created_at" : "2011-03-02 16:50:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "John Peter  Thompson",
      "screen_name" : "InvasiveNotes",
      "indices" : [ 109, 123 ],
      "id_str" : "41100077",
      "id" : 41100077
    }, {
      "name" : "Winston Hearn",
      "screen_name" : "justwinston",
      "indices" : [ 124, 136 ],
      "id_str" : "2351075282",
      "id" : 2351075282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42990236824903680",
  "text" : "RT @neardeathdoc: I  had a patient diagnosed in utero by ultrasound with no brain. Yet healthy baby was born @InvasiveNotes @justwinston",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Peter  Thompson",
        "screen_name" : "InvasiveNotes",
        "indices" : [ 91, 105 ],
        "id_str" : "41100077",
        "id" : 41100077
      }, {
        "name" : "Winston Hearn",
        "screen_name" : "justwinston",
        "indices" : [ 106, 118 ],
        "id_str" : "2351075282",
        "id" : 2351075282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42989347154296833",
    "text" : "I  had a patient diagnosed in utero by ultrasound with no brain. Yet healthy baby was born @InvasiveNotes @justwinston",
    "id" : 42989347154296833,
    "created_at" : "2011-03-02 16:47:13 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 42990236824903680,
  "created_at" : "2011-03-02 16:50:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hauntedebook",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42980692820365313",
  "text" : "19th-century ghosts use 21st century technology http:\/\/amzn.to\/dXudkY #hauntedebook",
  "id" : 42980692820365313,
  "created_at" : "2011-03-02 16:12:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xhanch Studio",
      "screen_name" : "xhanch",
      "indices" : [ 7, 14 ],
      "id_str" : "100507813",
      "id" : 100507813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42977932091731968",
  "text" : "I love @xhanch My Twitter wordpress plugin! Active plugin author updates often. : )",
  "id" : 42977932091731968,
  "created_at" : "2011-03-02 16:01:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42976593135677441",
  "text" : "we have aliens living among us... they are called animals.",
  "id" : 42976593135677441,
  "created_at" : "2011-03-02 15:56:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Free",
      "indices" : [ 15, 20 ]
    }, {
      "text" : "Ebook",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42950812686745600",
  "text" : "RT @byoung210: #Free #Ebook promotion extended by one day. Get Miscorrection: Arrogation for free. Details here: http:\/\/wp.me\/p15Plj-6r  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Free",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "Ebook",
        "indices" : [ 6, 12 ]
      }, {
        "text" : "kindle",
        "indices" : [ 121, 128 ]
      }, {
        "text" : "nook",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42944602482814976",
    "text" : "#Free #Ebook promotion extended by one day. Get Miscorrection: Arrogation for free. Details here: http:\/\/wp.me\/p15Plj-6r #kindle #nook",
    "id" : 42944602482814976,
    "created_at" : "2011-03-02 13:49:25 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 42950812686745600,
  "created_at" : "2011-03-02 14:14:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 48, 61 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42757758973517825",
  "text" : "Happy Birthday! Im so glad 2B following you : ) @Joeandrasi93",
  "id" : 42757758973517825,
  "created_at" : "2011-03-02 01:26:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42757431184470016",
  "text" : "RT @Joeandrasi93: Inside every older person is a younger person wondering what happened.\n~Jennifer Yane",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42598164116668416",
    "text" : "Inside every older person is a younger person wondering what happened.\n~Jennifer Yane",
    "id" : 42598164116668416,
    "created_at" : "2011-03-01 14:52:48 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 42757431184470016,
  "created_at" : "2011-03-02 01:25:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42757220215177217",
  "text" : "RT @AnAmericanMonk: Is it really all that important the we place judgment upon ourselves and others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42756486656561152",
    "text" : "Is it really all that important the we place judgment upon ourselves and others.",
    "id" : 42756486656561152,
    "created_at" : "2011-03-02 01:21:55 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 42757220215177217,
  "created_at" : "2011-03-02 01:24:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 29, 37 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42748780679933953",
  "geo" : { },
  "id_str" : "42756880132612097",
  "in_reply_to_user_id" : 54744689,
  "text" : "yeah, I get what ur saying.. @SangyeH",
  "id" : 42756880132612097,
  "in_reply_to_status_id" : 42748780679933953,
  "created_at" : "2011-03-02 01:23:29 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42747932310642688",
  "text" : "my eyes are getting blurry reading on laptop. this is something new.",
  "id" : 42747932310642688,
  "created_at" : "2011-03-02 00:47:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 31, 44 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42729406413799424",
  "geo" : { },
  "id_str" : "42740981891743744",
  "in_reply_to_user_id" : 124594428,
  "text" : "a lot more with my kindle..lol @golden_books",
  "id" : 42740981891743744,
  "in_reply_to_status_id" : 42729406413799424,
  "created_at" : "2011-03-02 00:20:18 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42692349725380608",
  "text" : "shedding skins http:\/\/amzn.com\/k\/2MVBB6Z599DC5 #Kindle",
  "id" : 42692349725380608,
  "created_at" : "2011-03-01 21:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42647399704969216",
  "text" : "RT @richarddoetsch: \u265EDoesn't \"expecting the unexpected\" make the unexpected expected?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42642633457278976",
    "text" : "\u265EDoesn't \"expecting the unexpected\" make the unexpected expected?",
    "id" : 42642633457278976,
    "created_at" : "2011-03-01 17:49:30 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 42647399704969216,
  "created_at" : "2011-03-01 18:08:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "indices" : [ 3, 17 ],
      "id_str" : "37490555",
      "id" : 37490555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42647162781319168",
  "text" : "RT @doggiestylish: What rabbits do for fun :D http:\/\/fb.me\/I8q5TKJI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42644131645882368",
    "text" : "What rabbits do for fun :D http:\/\/fb.me\/I8q5TKJI",
    "id" : 42644131645882368,
    "created_at" : "2011-03-01 17:55:27 +0000",
    "user" : {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "protected" : false,
      "id_str" : "37490555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466092491\/jersey_normal.jpg",
      "id" : 37490555,
      "verified" : false
    }
  },
  "id" : 42647162781319168,
  "created_at" : "2011-03-01 18:07:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42638774118785024",
  "text" : "You can't think beyond the level you're at. Let new ideas percolate!",
  "id" : 42638774118785024,
  "created_at" : "2011-03-01 17:34:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 3, 13 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42638241488318464",
  "text" : "RT @ScottBaio: Guess I will be voting for my buddy Ralph on DWTS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42634338906546176",
    "text" : "Guess I will be voting for my buddy Ralph on DWTS.",
    "id" : 42634338906546176,
    "created_at" : "2011-03-01 17:16:33 +0000",
    "user" : {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "protected" : false,
      "id_str" : "82447359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742477919801335816\/O6okGPN6_normal.jpg",
      "id" : 82447359,
      "verified" : true
    }
  },
  "id" : 42638241488318464,
  "created_at" : "2011-03-01 17:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42624517952122880",
  "text" : "RT @WestofMars: I like being interviewed so much, I'm giving away 10 copies of Trevor's Song! http:\/\/bit.ly\/fBVhMs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42622955905236992",
    "text" : "I like being interviewed so much, I'm giving away 10 copies of Trevor's Song! http:\/\/bit.ly\/fBVhMs",
    "id" : 42622955905236992,
    "created_at" : "2011-03-01 16:31:19 +0000",
    "user" : {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "protected" : false,
      "id_str" : "34258680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454321783588413442\/gndVsGba_normal.png",
      "id" : 34258680,
      "verified" : false
    }
  },
  "id" : 42624517952122880,
  "created_at" : "2011-03-01 16:37:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/ZP3YLo5",
      "expanded_url" : "http:\/\/bookhoundsden.blogspot.com\/2011\/03\/crooked-stick-figures-by-lee-thompson.html?spref=tw",
      "display_url" : "bookhoundsden.blogspot.com\/2011\/03\/crooke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "42619191521591297",
  "text" : "Bookhound's Den: \"Crooked Stick Figures\" by Lee Thompson http:\/\/t.co\/ZP3YLo5",
  "id" : 42619191521591297,
  "created_at" : "2011-03-01 16:16:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/uZOJTxI",
      "expanded_url" : "http:\/\/wp.me\/p15Plj-6r",
      "display_url" : "wp.me\/p15Plj-6r"
    } ]
  },
  "geo" : { },
  "id_str" : "42590744191574016",
  "text" : "Arrogation Ebook Contest: http:\/\/t.co\/uZOJTxI",
  "id" : 42590744191574016,
  "created_at" : "2011-03-01 14:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42574264985071617",
  "text" : "RT @PortalChronicle: Giveaway coming up!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42568762431508480",
    "text" : "Giveaway coming up!",
    "id" : 42568762431508480,
    "created_at" : "2011-03-01 12:55:58 +0000",
    "user" : {
      "name" : "IMOGEN ROSE",
      "screen_name" : "ImogenRoseTweet",
      "protected" : false,
      "id_str" : "102568232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1265710799\/profile1_normal.jpg",
      "id" : 102568232,
      "verified" : false
    }
  },
  "id" : 42574264985071617,
  "created_at" : "2011-03-01 13:17:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42574150128250880",
  "text" : "RT @mssuzcatsilver: Discern rather than judge. You cannot imagine what any one else's experience of life & all that is IS! & I\u2026 (cont) h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42570541080657922",
    "text" : "Discern rather than judge. You cannot imagine what any one else's experience of life & all that is IS! & I\u2026 (cont) http:\/\/deck.ly\/~E1EO3",
    "id" : 42570541080657922,
    "created_at" : "2011-03-01 13:03:02 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 42574150128250880,
  "created_at" : "2011-03-01 13:17:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]